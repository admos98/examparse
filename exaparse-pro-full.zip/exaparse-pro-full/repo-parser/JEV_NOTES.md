# JEV_NOTES.md — Jev judge research + integration map

Researched 2026-09-27. Every claim below is source-checked; unverified items are explicitly marked.
Rule we followed: **nothing unverifiable is hardcoded.** The native client only encodes the two
request shapes confirmed by primary docs; everything else routes through our existing LLM provider
(fallback), and the swap points for a native client are marked `SWAP-IN POINT` below.

---

## 1. What Jev is (verified)

Jev is **TypeSafe's "System One" decision model** — the first of a model class built to make fast,
structured decisions for software. It is *not* an autoregressive LLM:

- It does **not generate text**. You send a `state` (the data to judge) plus one or more **typed
  questions**; it returns **typed answers with calibrated probabilities**.
  → https://docs.typesafe.ai/concepts/system-one
- **No rationale**: it returns no reasoning/explanation. If you need prose, use an LLM judge.
  → https://langfuse.com/docs/evaluation/evaluation-methods/jev-as-a-judge
- **Deterministic**: does not sample text — same state + same questions ⇒ same verdict. Good for
  regression gating. (Langfuse, LangChain)
- **Cannot abstain**: it always picks an answer, so Choice questions need an explicit escape-hatch
  option (`other` / `unclear`). (Langfuse)
- Text-only input (string, JSON object, array of text). No image/audio/video (yet).
- Calibration is group-level ("probabilities optimized against outcomes"); it does not guarantee an
  individual answer is correct. (TypeSafe docs)

## 2. Decision primitives (verified against the HTTP API reference)

Source: https://docs.typesafe.ai/api.md — all three primitives share `type` + `instructions`
(string | object | array); each adds `criteria`.

| Primitive | Question shape | Answer shape |
|---|---|---|
| **Noul** (yes/no) | `{type:"noul", instructions, criteria?:{true?:str,false?:str}}` | `{type:"noul", noul: P(true) ∈ [0,1]}` |
| **Choice** (pick one label) | `{type:"choice", instructions, criteria: map<option, desc\|null>}` — **2–255 options** | `{type:"choice", choice: option, probabilities: map<option,float> (Σ=1), confidence: float}` |
| **Score** (ordered scale) | `{type:"score", instructions, criteria: [2–10 ordered level descriptions]}` | `{type:"score", score: prob-weighted float (can land between levels), legend: map<levelIdx,desc>, probabilities, confidence}` |

Example noul answer: `{"type":"noul","noul":0.95}`. Example choice answer:
`{"type":"choice","choice":"billing","probabilities":{"billing":0.88,"technical":0.12,"sales":0.0},"confidence":0.81}`.
Response envelope: `{model, answers: map<questionId, Answer>, usage:{input_tokens,output_tokens}}`.

## 3. Many questions per request — the whole efficiency story (verified)

- One request = **one `state` + a map of many named questions**. The state is ingested **once** and
  every question is evaluated **in parallel against it**; "adding a second or tenth question barely
  changes latency and only costs the tokens of that question." (Langfuse)
- API limits: questions per evaluator **1–50** (Langfuse UI limit), Choice ≤255 options, Score 2–10
  levels, state ≈ **32k tokens** (state + longest question; 64k total request budget).
- Measured batching win (TypeSafe cookbook): a 13-question regulatory briefing in ONE call =
  **12.2× cheaper and 10.0× faster** than separate calls, answers unchanged.
  → https://docs.typesafe.ai/cookbooks/parallel_questions
- Questions must be **atomic** — one decision per question; split compound criteria into separate
  questions (they're answered in the same call anyway). (TypeSafe docs)
- Rate limits (model card, dynamic): 250k tokens/s, 1,200 requests/min. 429/529 ⇒ exponential
  backoff, honor `retry-after`.

**⇒ Our design maps exactly onto this:** per exam batch we send ONE `state` (exam header + shared
context) and per-question typed question bundles (noul correctness + choice category + optional
score quality), batched ~`jevBatchSize` questions per call (default 25, configurable).

## 4. Access paths (verified)

| Path | Endpoint / package | Auth | Notes |
|---|---|---|---|
| **TypeSafe direct REST** | `POST https://api.typesafe.ai/v1/systemone` | `Authorization: Bearer <TypeSafe key>` (`jv_live_…` per third-party guides) | Canonical. Models: `jev-latest`, `jev-1.13.0` |
| **OpenRouter (same shape!)** | `POST https://openrouter.ai/api/v1/systemone` | `Authorization: Bearer <OpenRouter key>` | OpenAPI-verified: identical `{state, questions, model}` body; model `typesafe/jev-1.13` (bare `jev-1.13`/`jev-latest` auto-mapped to `typesafe/` namespace). **Not** the chat-completions endpoint — chat SDKs will not work. → openrouter.ai/docs/api/api-reference/systemone/submit-a-system-one-request |
| **JS SDK** | `npm i @typesafe-ai/sdk` → `new TypeSafeClient()` + `client.systemOne({state, questions})`, helpers `choice()`, `noul()`, `score()` | `TYPESAFE_API_KEY` env | ESM+CJS+types; can be pointed at OpenRouter (openrouter.ai/docs/guides/community/typesafe-sdk) |
| **Langfuse** | evaluator type "decision-model" (adapter `typesafe`) | upstream key | Upstreams: **TypeSafe / Vercel AI Gateway / OpenRouter** — "Vercel AI Gateway and OpenRouter expose TypeSafe's API, so evaluators behave the same on every upstream" |
| **DeepEval** | **JevEval** metric ("Jev-as-a-judge") | — | Bounded evaluation questions → Jev probabilities → DeepEval computes score. Introduced by Jeffrey Ip (Confident AI), Sep 2026 (deepeval.com, jevmade.com — secondary sources) |
| **LangSmith** | Jev-as-a-Judge agent evals (LangChain blog Sep 20 2026) | — | Independent benchmark, see §5 |

**For ExaParse we use the raw REST shape (1 or 2) via our own server proxy** — no new npm dep, fits
the existing per-request-key provider config. Both verified base URLs are offered in Settings;
default = OpenRouter (more likely reachable from geo-blocked regions, and the user already uses
OpenRouter-compatible providers). `SWAP-IN POINT`: `judgeProvider.ts → callNativeJev()` is the only
function that talks HTTP; replacing it with `@typesafe-ai/sdk` later touches nothing else.

## 5. Pricing / latency / consistency (verified numbers)

- **Price**: `$0.042 / 1M input tokens` (=$42/Btok), **output tokens free** — TypeSafe model card +
  OpenRouter (`$0.042 / $0 per 1M`) agree. LangChain measured **$0.00035/call avg**.
- **Latency**: OpenRouter P50 **0.20 s**; LangChain experiment avg **0.44 s**; TypeSafe claims 20–200×
  faster than comparable LLMs (vendor claim).
- **Cost claims**: 40–400× cheaper than frontier models on classification (TypeSafe vendor claim,
  repeated by Langfuse/LangChain).
- **Variance**: LangChain's Jev-as-a-Judge benchmark — quality-score **variance 92–913× lower** than
  GPT-5.6 (Luna/Terra) and Claude Sonnet 4.6 on continuous scoring.
- Context: **64k/request total; 32k for state + longest question.**

## 6. Data / retention caveats (verified)

- State + questions are sent to TypeSafe's API (or through Vercel AI Gateway / OpenRouter if chosen).
  Langfuse's own doc says: review the terms of your upstream **and** TypeSafe before evaluating
  sensitive data; use masking where needed.
- TypeSafe legal (docs.typesafe.ai/legal): Data Processing Agreement covers **data retention**;
  Privacy Policy includes a **commitment not to train models on user data**; **zero-data-retention
  (ZDR) is enterprise-only** (sales contact).
- OpenRouter model page: "hosted by one provider. OpenRouter forwards every request to it directly."
- ⇒ Exam content (stems/options/passage) leaves the machine when native Jev is enabled. Our docs +
  Settings help text say this plainly; offline users simply leave Jev off (everything else works).

## 7. Recommended confidence cascade (verified pattern)

- TypeSafe: answers carry `confidence` "so you can decide when to act and when to escalate to a
  person or a reasoning model"; pattern page **Confidence-gated routing**: "the answer tells you
  what; confidence tells you whether to act." → docs.typesafe.ai/patterns/confidence-routing
- Langfuse: pick a threshold per risk tolerance, or use **three bands: act / review / ignore**.
- Langfuse FAQ + LangChain: run **Jev on everything, an LLM judge on the flagged/uncertain cases**.
- OpenRouter cookbook **"Cut LLM Cost with a Jev-Verified Cascade"**: verify cheap answers, escalate
  only the unsupported ones. TypeSafe cookbook **Self-consistency: nouls**: route *uncertain
  probabilities* to human review, keep the raw noul visible.

**⇒ Our cascade** (matches the user's spec):
1. `pCorrect ≥ threshold (default 0.9)` → **accept** (`verdict:'correct'`, strengthens trust).
2. `pCorrect ≤ (1 − threshold)… low band (default ≤0.1…<0.35)` → **accept as incorrect** → becomes a
   contested/soft finding (never auto-writes an answer).
3. **mid band (default 0.1/0.35…<0.9)** → `verdict:'uncertain'` → escalate **only these** to the
   existing 3-vote `/api/adjudicate` LLM path. Bands are configurable; escalate-nothing-by-default
   would defeat the cost model, escalate-everything defeats the savings.

## 8. What could NOT be verified (honesty list)

- OpenRouter **Alpha `/decisions` router** shape — alpha endpoint, not needed (we use `/systemone`).
- DeepEval **JevEval** exact metric API signature — confirmed only via secondary sources; we don't
  depend on it.
- Vercel AI Gateway as upstream — mentioned by Langfuse; not independently verified; not wired.
- TypeSafe key prefix `jv_live_` — seen only on third-party sites; we don't validate prefixes.
- Enterprise pricing / SLAs — not published.

## 9. Exactly how to swap in the native client later

All native HTTP lives in **one place**: `src/server/judgeProvider.ts → callNativeJev()`.
It takes `{baseUrl, apiKey, model, state, questions}` and returns normalized
`{answers, model, usage}`. To switch to the official SDK:

```ts
// npm i @typesafe-ai/sdk
import { TypeSafeClient, noul, choice, score } from "@typesafe-ai/sdk";
const client = new TypeSafeClient(); // TYPESAFE_API_KEY env
const res = await client.systemOne({ state, questions: { … } });
```

…and map `res.answers` into the same normalized shape. Nothing else in the pipeline changes:
`/api/judge` → `jevJudge.ts` (client batching/cache/cascade) → `trustEngine.ts` → UI chips.
If `api.typesafe.ai` is geo-blocked, set Settings base URL to `https://openrouter.ai/api/v1`
(verified same request/response shape, model `typesafe/jev-1.13`). If both are unreachable, the
existing LLM fallback produces the **same result objects** and the feature still works.

## 10. Sources (primary first)

1. https://docs.typesafe.ai/api.md — HTTP API reference (endpoint, auth, request/response, errors)
2. https://docs.typesafe.ai/concepts/system-one — System One model class, primitives table
3. https://docs.typesafe.ai/models.md — jev-1.13.0 price/limits/context/aliases
4. https://docs.typesafe.ai/confidence.md — confidence semantics
5. https://docs.typesafe.ai/patterns/confidence-routing.md — confidence-gated escalation
6. https://docs.typesafe.ai/cookbooks/parallel_questions.md — batching 12.2×/10.0×
7. https://docs.typesafe.ai/legal.md — DPA / no-training / ZDR
8. https://docs.typesafe.ai/sdk/javascript.md — @typesafe-ai/sdk quickstart
9. https://openrouter.ai/typesafe/jev-1.13 — OpenRouter listing ($0.042/$0, 32K ctx, 0.20 s P50,
   "Decisions API, not chat-compatible")
10. https://openrouter.ai/docs/api/api-reference/systemone/submit-a-system-one-request.md —
    OpenRouter /systemone shape (same as TypeSafe; `typesafe/` namespace)
11. https://langfuse.com/docs/evaluation/evaluation-methods/jev-as-a-judge — question limits (1–50),
    state ≈32k, no rationale, cannot abstain, act/review/ignore bands, data-handling note,
    upstreams (TypeSafe / Vercel AI Gateway / OpenRouter)
12. https://www.langchain.com/blog/jev-agent-evals-langsmith — benchmark: 0.44 s, $0.00035/call,
    variance 92–913× lower; reproducibility notes
13. https://deepeval.com (JevEval announcement), https://jevmade.com summary — DeepEval integration
    (secondary)
14. https://openrouter.ai/docs/cookbook/evaluate-and-optimize/jev-verified-cascade.md — cascade
    cookbook (referenced via llms.txt index)
