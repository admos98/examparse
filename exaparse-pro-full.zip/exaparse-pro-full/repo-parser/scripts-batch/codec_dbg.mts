/** Debug W1 labels: key boundaries, headers, options on suspicious files. */
import fs from 'node:fs';
import path from 'node:path';
import { runLayoutBrain, classifyTables, perceive, toLatinDigits, matchSubject } from '../src/utils/layoutBrain';
import { PKG_ROOT } from './wsPaths.mts';

const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-qu2');
const norm = (s: string) => toLatinDigits(s).replace(/\s+/g, ' ').trim();

for (const stem of process.argv.slice(2)) {
  const rawDoc = JSON.parse(fs.readFileSync(path.join(BRAIN_DIR, stem + '.json'), 'utf8'));
  const cls = classifyTables(rawDoc);
  const perc = perceive(cls);
  const brain = runLayoutBrain(rawDoc);
  const lines = brain.lines;
  console.log(`\n===== ${stem}: ${lines.length} lines, ${brain.sections.length} sections (${brain.sections.filter((s) => s.confirmed && !s.demoted).length} confirmed)`);
  console.log('keyBoundary:', JSON.stringify(brain.keyBoundary));
  console.log('headers:', perc.headers.length, 'optionLines:', perc.optionLines.size, 'letterOpeners:', perc.letterOpeners.length, 'numberOpeners:', perc.numberOpeners.length, 'markTokens:', perc.markTokens.length);
  const kb = brain.keyBoundary;
  if (kb) {
    const idx = lines.findIndex((l) => l.page > kb.page || (l.page === kb.page && l.bbox[1] >= kb.y - 2));
    console.log(`key cut at line ${idx}/${lines.length}; boundary text: ${kb.text}`);
    if (idx >= 0) for (let i = Math.max(0, idx - 2); i < Math.min(lines.length, idx + 6); i++)
      console.log(`  [${i}] p${lines[i].page} ${JSON.stringify(lines[i].text.slice(0, 60))}`);
    // what precedes the boundary?
  }
  // show first 12 headers with subject matches
  let shown = 0;
  for (const h of perc.headers) {
    if (shown++ > 10) break;
    console.log(`  HDR p${(h as unknown as { page?: number }).page} ${JSON.stringify(h.text.slice(0, 50))} subj=${matchSubject(h.text) ?? '-'}`);
  }
}
