/** Sample option-like lines to design the OPT pattern. */
import fs from 'node:fs';
import path from 'node:path';
import { runLayoutBrain, toLatinDigits } from '../src/utils/layoutBrain';
import { PKG_ROOT } from './wsPaths.mts';
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-qu2');
for (const stem of process.argv.slice(2)) {
  const brain = runLayoutBrain(JSON.parse(fs.readFileSync(path.join(BRAIN_DIR, stem + '.json'), 'utf8')));
  const lines = brain.lines;
  console.log('=====', stem);
  let n = 0;
  for (let i = 0; i < lines.length && n < 25; i++) {
    const t = toLatinDigits(lines[i].text).replace(/\s+/g, ' ').trim();
    if (/^(?:\(?[a-dA-D1-4ﺍ-ﻲابپتثجچ][).:.])\s*\S/.test(t) && t.length < 60) {
      console.log(`  [${i}] p${lines[i].page} sz${lines[i].size.toFixed(1)} ${JSON.stringify(t.slice(0, 55))}`);
      n++;
    }
  }
}
