/**
 * codec_label.mts — W1/W2 TEACHER LABELER (dev-side only, never shipped).
 *
 * Builds the line-level training corpus for the semantic codec (W1) and the
 * structure transformer (W2) from the 47-file qu2 BrainDoc sidecars.
 *
 * Teacher sources (the full-evidence stack the deployed student will NOT
 * have — classic distillation):
 *   - layoutBrain receipts (confirmed sections/rows, key boundary, marks)
 *   - deterministic perception (pageNumbers, optionLines, markTokens,
 *     letterOpeners, numberOpeners, headers) — the SAME perception the
 *     runtime oracle can compute, so features and labels stay honest
 *   - conservative text lexicons (instructions, totals, furniture)
 *
 * Output: scratch/w1w2/labeled.json
 *   { files: [{ file, fold, keyIdx, printedTotal,
 *               lines: [{ x, s, b, t, pg }],
 *               roles: number[], subj: number[], instr: number[],
 *               markVal: (number|null)[], events: number[] }] }
 *
 * Features are NOT stored — the trainer recomputes them from the BrainDoc
 * via codecFeatures (the exact code path the runtime uses), so train/serve
 * skew is impossible by construction.
 */
import fs from 'node:fs';
import path from 'node:path';
import {
  runLayoutBrain,
  classifyTables,
  perceive,
  toLatinDigits,
  matchSubject,
  isRowLetterToken,
  letterRank,
  type BrainDoc,
  type BrainLine,
} from '../src/utils/layoutBrain';
import { ROLES, SUBJECTS, INSTRS, type Role } from '../src/utils/codecFeatures';
import { WS_ROOT, PKG_ROOT } from './wsPaths.mts';

// brain sidecars live in the package-local scratch (restored with the tree);
// outputs go to the workspace scratch next to the GT corpora.
const BRAIN_DIR = process.env.BRAIN_DIR ?? path.join(PKG_ROOT, 'scratch', 'brain-qu2');
const OUT_PATH = path.join(WS_ROOT, 'scratch', 'w1w2', 'labeled.json');

const roleIdx = (r: Role) => ROLES.indexOf(r);
const subjIdx = (s: string) => Math.max(0, SUBJECTS.indexOf(s as (typeof SUBJECTS)[number]));
const instrIdx = (i: string) => Math.max(0, INSTRS.indexOf(i as (typeof INSTRS)[number]));
const EV: Record<string, number> = { CONT: 0, SEC: 1, ROW: 2, MARK: 3, KEY: 4, TOTAL: 5, PASS: 6 };

const nfkc = (s: string) => {
  try {
    return s.normalize('NFKC');
  } catch {
    return s;
  }
};
const norm = (s: string) => nfkc(toLatinDigits(s)).replace(/\s+/g, ' ').trim();
const revOf = (s: string) => norm(s).split('').reverse().join('');

/** Identity across normalized/copied line arrays: page|bbox|text. */
const keyOf = (l: BrainLine, page: number) => `${page}|${l.bbox.map((n) => Math.round(n * 10)).join(',')}|${l.text}`;

// furniture lexicon (assessment-center headers/footers, name/date strips)
const FURN_RE = /نام و نام خانوادگی|نام ونام خانوادگی|تاریخ امتحان|مدت امتحان|درس :|کلاس|دبیرستان|دبستان|مدرسه|صفحه|name:|class:|date:/i;
const TOTAL_RE = /جمع بارم|جمع|total/i;

function wordCount(s: string): number {
  const t = norm(s);
  return t ? t.split(' ').length : 0;
}

/**
 * Latin option line: a) b) c. d) — non-bold, near body size, short. Persian
 * letter options stay ambiguous with row openers (handled by run context).
 */
function isLatinOption(l: BrainLine, t: string): boolean {
  if (l.bold) return false;
  const m = t.match(/^\(?([a-d])[).:.]\s*(\S.*)?$/i);
  if (!m) return false;
  const words = m[2] ? m[2].split(/\s+/).length : 0;
  return words <= 12;
}

/** Row-letter rank of a line's leading opener token ("الف) x" / "b)" / "ج"), if any. */
function openerRank(t: string): number | undefined {
  const m = t.match(/^\(?([A-Za-z\u0600-\u06FF]{1,3})[).:ـ]?(?:\s|$)/);
  if (!m) return undefined;
  const tok = m[1].trim();
  if (!isRowLetterToken(tok)) return undefined;
  return letterRank(tok.toUpperCase() === tok ? tok.toUpperCase() : tok);
}

function instrLex(t: string): string | null {
  const LEX: [string, string[]][] = [
    ['fillin', ['جاهای خالی', 'جا های خالی', 'پر کنید', 'پرکنید', 'fill in', 'complete the']],
    ['mcq', ['گزینه', 'انتخاب کنید', 'مناسب ترین', 'صحیح', 'گدام', 'choose', 'select']],
    ['match', ['وصل کنید', 'طاب', 'طبقه بندی', 'match', 'connect']],
    ['cloze', ['cloze', 'متن زیر', 'read the text']],
    ['truefalse', ['true', 'false', 'درست', 'غلط', 'نادرست']],
    ['define', ['تعریف', 'define', 'معنی', 'متظادل', 'مترادف', 'opposite', 'synonym', 'definition']],
    ['write', ['بنویسید', 'بنویس', 'write', 'تولید کنید']],
    ['translate', ['ترجمه', 'translate']],
    ['other', ['با توجه به', 'according to', 'به تصویر', 'look at', 'listen', 'گوش کنید']],
  ];
  const low = t.toLowerCase();
  for (const [name, keys] of LEX)
    for (const k of keys) if (low.includes(k.toLowerCase())) return name;
  return null;
}

function labelFile(stem: string, fold: number) {
  const docPath = path.join(BRAIN_DIR, stem + '.json');
  const rawDoc = JSON.parse(fs.readFileSync(docPath, 'utf8')) as BrainDoc;
  if (!rawDoc || !Array.isArray(rawDoc.pages)) return null; // report/index files
  // classify a feature copy (kinds for marks-table detection); runLayoutBrain
  // normalizes/classifies its own copy internally.
  const cls = classifyTables(rawDoc);
  const perc = perceive(cls);
  const brain = runLayoutBrain(rawDoc);
  const lines = brain.lines;
  if (!lines.length) return null;

  // ---- line identity maps: brain.lines position <-> key (with page), and a
  // page-free key set for perception membership (perception lines are the
  // classifier's own copies without page attachment).
  const posByKey = new Map<string, number>();
  lines.forEach((l, i) => posByKey.set(keyOf(l, l.page), i));
  const noPageKey = (l: BrainLine) => `${l.bbox.map((n) => Math.round(n * 10)).join(',')}|${l.text}`;
  const clsKeys = new Set<string>();
  for (const p of cls.pages) for (const l of p.lines) clsKeys.add(noPageKey(l));

  const pageNums = new Set<number>();
  for (const pn of perc.pageNumbers) if (clsKeys.has(noPageKey(pn.line))) {
    const pi = posByKey.get(keyOf(pn.line, pn.line.page ?? 0));
    if (pi !== undefined) pageNums.add(pi);
  }
  const inPercSet = (s: Set<BrainLine>) => {
    const out = new Set<number>();
    for (const line of s) {
      if (!clsKeys.has(noPageKey(line))) continue;
      const pi = posByKey.get(keyOf(line, (line as unknown as { page?: number }).page ?? 0));
      if (pi !== undefined) out.add(pi);
    }
    return out;
  };
  const optionLines = inPercSet(perc.optionLines);
  const letterOpeners = inPercSet(new Set(perc.letterOpeners.map((o) => o.line)));
  const numberOpeners = inPercSet(new Set(perc.numberOpeners.map((o) => o.line)));
  const bareBoldNums = inPercSet(new Set(perc.bareBoldNums.map((o) => o.line)));
  const headers = inPercSet(new Set(perc.headers));
  void headers; // perception headers available; section receipts are the label source

  // ---- marks tables (bbox ranges for cell-line labeling)
  const marksTables: { page: number; bbox: number[] }[] = [];
  cls.pages.forEach((p, pi) => {
    for (const t of p.tables) if (t.kind === 'marksTable') marksTables.push({ page: pi, bbox: t.bbox });
  });
  const inMarksTable = (i: number) => {
    const l = lines[i];
    const xc = (l.bbox[0] + l.bbox[2]) / 2;
    const yc = (l.bbox[1] + l.bbox[3]) / 2;
    return marksTables.some(
      (t) => t.page === l.page && xc >= t.bbox[0] && xc <= t.bbox[2] && yc >= t.bbox[1] && yc <= t.bbox[3]
    );
  };

  // ---- brain receipts: confirmed-section membership + header/row lines
  const confirmedSections = brain.sections.filter((s) => s.confirmed && !s.demoted);
  const sectionOf = new Map<number, number>();
  for (let si = 0; si < confirmedSections.length; si++)
    for (const l of confirmedSections[si].lines) {
      const pi = posByKey.get(keyOf(l, l.page));
      if (pi !== undefined && !sectionOf.has(pi)) sectionOf.set(pi, si);
    }
  const headerReceipts = new Set<number>();
  // header receipt: find the line whose normalized text equals the section
  // header AND sits inside/at the section's span
  const normOf = lines.map((l) => norm(l.text));
  for (const s of confirmedSections) {
    if (!s.headerText) continue;
    const ht = norm(s.headerText);
    const inSpan = s.lines.map((l) => posByKey.get(keyOf(l, l.page))).filter((v): v is number => v !== undefined);
    const idx = inSpan.find((i) => normOf[i] === ht);
    if (idx !== undefined) headerReceipts.add(idx);
  }

  // ---- key boundary
  let keyIdx = lines.length;
  if (brain.keyBoundary) {
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      if (
        l.page > brain.keyBoundary.page ||
        (l.page === brain.keyBoundary.page && l.bbox[1] >= brain.keyBoundary.y - 2)
      ) {
        keyIdx = i;
        break;
      }
    }
  }

  const isBareNum = (t: string) => /^\d{1,2}(\.\d)?$/.test(t);

  const roles: number[] = [];
  const subj: number[] = [];
  const instr: number[] = [];
  const markVal: (number | null)[] = [];
  const outLines: { x: number[]; s: number; b: number; t: string; pg: number }[] = [];
  let activeSubj = 0;
  let prevRoleVal = -1;
  let lastRowRank = -1; // letter-ladder approximation for option-run guard

  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    const t = normOf[i];
    const tr = revOf(l.text);
    let role: Role;
    let mv: number | null = null;
    let lineSubj: string | undefined;
    const subjHit = matchSubject(l.text);
    const words = wordCount(t);
    // key-row surface: STRICTLY letter answers — "1. b" pairs or "1) b) text";
    // bare "1. word" lines stay ambiguous with numbered stems on purpose
    const letterPairs = /(?:\d{1,2}\s*[).\-:]?\s*[a-dA-D]\b[\s.,]*){2,}/.test(t);
    const letterAnswer = /^\d{1,2}\s*[).\-:]\s*[a-dA-D]\b/.test(t);
    const keyRowPat = letterPairs || letterAnswer;

    if (i >= keyIdx && keyRowPat) {
      role = 'KEY';
    } else if (pageNums.has(i)) {
      role = 'FURN';
    } else if (TOTAL_RE.test(t) || TOTAL_RE.test(tr)) {
      role = 'TOTAL';
    } else if (inMarksTable(i) && (isBareNum(t) || /بارم/.test(t) || /بارم/.test(tr))) {
      if (isBareNum(t)) mv = parseFloat(t);
      role = 'MARK';
    } else if (subjHit && (headers.has(i) || l.bold) && !letterOpeners.has(i)) {
      role = 'SUBJ';
      lineSubj = subjHit;
    } else if (headerReceipts.has(i) && !letterOpeners.has(i)) {
      role = 'SUBJ';
      lineSubj = subjHit ?? undefined;
    } else if (numberOpeners.has(i)) {
      role = 'SUBJ';
      lineSubj = subjHit ?? undefined;
    } else if (letterOpeners.has(i) && !inMarksTable(i)) {
      const rank = openerRank(t);
      if (isLatinOption(l, t) && (words <= 12 || prevRoleVal === roleIdx('OPT'))) {
        role = 'OPT';
      } else if (
        rank !== undefined &&
        lastRowRank >= 0 &&
        rank <= lastRowRank &&
        prevRoleVal !== roleIdx('SUBJ') &&
        !l.bold
      ) {
        // letter REGRESSION against the row ladder: an option run restarting
        // at الف/a inside a row — never a row opener
        role = 'OPT';
      } else {
        role = 'ROW';
        if (rank !== undefined) lastRowRank = Math.max(lastRowRank, rank);
      }
    } else if (bareBoldNums.has(i) && !inMarksTable(i)) {
      role = 'ROW'; // numeric radif opener (bare bold digit) — ladder-checked downstream
    } else if (isLatinOption(l, t) && (words <= 12 || prevRoleVal === roleIdx('OPT'))) {
      role = 'OPT';
    } else if (FURN_RE.test(t) || FURN_RE.test(tr)) {
      role = 'FURN';
    } else if (/بارم/.test(t) || /بارم/.test(tr)) {
      role = 'MARK';
    } else if (optionLines.has(i)) {
      role = 'OPT';
    } else if (isBareNum(t) && words === 1 && !inMarksTable(i)) {
      role = 'IDX';
    } else if (/(\S+\s*\/\s*\S+){2,}/.test(t) || (t.match(/\s[-–—]\s/g) ?? []).length >= 3) {
      role = 'WORD';
    } else {
      role = 'STEM';
    }
    prevRoleVal = roles.length ? roles[roles.length - 1] : -1;

    // PASS override: long prose inside a Reading/Listening confirmed section
    if (role === 'STEM' && wordCount(t) >= 12) {
      const si = sectionOf.get(i);
      if (si !== undefined) {
        const ssubj = confirmedSections[si].subject;
        if (ssubj === 'Reading' || ssubj === 'Listening') role = 'PASS';
      }
    }

    // instruction axis (context for every line; short instruction-ish stems
    // promote to INSTR lines)
    let instrLabel = 'none';
    if (role !== 'KEY' && role !== 'FURN') {
      for (const cand of [t, tr]) {
        const hit = instrLex(cand);
        if (hit) {
          instrLabel = hit;
          break;
        }
      }
      if (role === 'STEM' && instrLabel !== 'none' && wordCount(t) <= 14) role = 'INSTR';
    }

    // subject propagation
    if (role === 'SUBJ') {
      const m = lineSubj ?? matchSubject(l.text);
      if (m) activeSubj = subjIdx(m);
    }
    if (role === 'KEY') activeSubj = 0;

    roles.push(roleIdx(role));
    subj.push(role === 'SUBJ' && lineSubj ? subjIdx(lineSubj) : activeSubj);
    instr.push(instrIdx(instrLabel));
    markVal.push(mv);
    outLines.push({ x: l.bbox, s: l.size, b: l.bold ? 1 : 0, t: l.text, pg: l.page });
  }

  // ---- W2 event stream (derived from the label stream)
  const events: number[] = new Array(roles.length).fill(EV.CONT);
  let prevRole = -1;
  for (let i = 0; i < roles.length; i++) {
    const r = ROLES[roles[i]];
    if (r === 'SUBJ') events[i] = EV.SEC;
    else if (r === 'ROW') events[i] = EV.ROW;
    else if (r === 'MARK' && markVal[i] !== null) events[i] = EV.MARK;
    else if (r === 'KEY' && prevRole !== roleIdx('KEY')) events[i] = EV.KEY;
    else if (r === 'TOTAL') events[i] = EV.TOTAL;
    else if (r === 'PASS' && ROLES[prevRole] !== 'PASS') events[i] = EV.PASS;
    prevRole = roles[i];
  }

  return {
    file: stem + '.pdf',
    fold,
    keyIdx,
    printedTotal: brain.stats.printedTotal ?? null,
    lines: outLines,
    roles,
    subj,
    instr,
    markVal,
    events,
  };
}

function main() {
  const stems = fs
    .readdirSync(BRAIN_DIR)
    .filter((f) => f.endsWith('.json') && !f.startsWith('index') && !f.startsWith('report'))
    .map((f) => f.replace(/\.json$/, ''))
    .sort();
  const out: NonNullable<ReturnType<typeof labelFile>>[] = [];
  let skipped = 0;
  for (let i = 0; i < stems.length; i++) {
    const fold = i % 6;
    try {
      const rec = labelFile(stems[i], fold);
      if (rec) out.push(rec);
      else skipped++;
    } catch (e) {
      console.error(`LABEL FAIL ${stems[i]}:`, e instanceof Error ? e.message : e);
      skipped++;
    }
  }
  fs.mkdirSync(path.dirname(OUT_PATH), { recursive: true });
  fs.writeFileSync(OUT_PATH, JSON.stringify({ files: out }));
  const dist = new Array(ROLES.length).fill(0);
  for (const f of out) for (const r of f.roles) dist[r]++;
  const total = out.reduce((n, f) => n + f.roles.length, 0);
  console.log(`labeled ${out.length} files (${total} lines, ${skipped} skipped) -> ${OUT_PATH}`);
  console.log(
    'role distribution:',
    ROLES.map((r, i) => `${r}=${dist[i]} (${((dist[i] / total) * 100).toFixed(1)}%)`).join('  ')
  );
  const evDist = new Array(7).fill(0);
  for (const f of out) for (const e of f.events) evDist[e]++;
  console.log('event distribution:', Object.keys(EV).map((k) => `${k}=${evDist[EV[k]]}`).join('  '));
  // key-region sanity: flag files whose key region eats >45% of lines
  for (const f of out) {
    const frac = (f.roles.length - f.keyIdx) / Math.max(1, f.roles.length);
    if (frac > 0.45) console.log(`KEY-HEAVY ${f.file}: ${(frac * 100).toFixed(0)}% of lines past key boundary`);
  }
}

main();
