/**
 * codec_train.mts — W1 SEMANTIC CODEC TRAINER (dev-side only, never shipped).
 *
 * fastText-style hashed char-n-gram classifier with THREE softmax heads over
 * the closed alphabets (ROLE 12 / SUBJECT 9 / INSTRUCTION 10). The composed
 * symbol stream it emits is the language the W2 structure transformer reads.
 *
 * - Features: codecFeatures.featureTokens (identical code path to runtime)
 * - Model:    mean-hashed bag -> linear -> 3 softmax heads (multi-task CE)
 * - Eval:     6-fold CV grouped BY FILE (generalization to unseen layouts)
 * - Ship:     final model trained on all 47 files, int8-quantized into
 *             src/utils/codecWeights.ts (base64 blob, S26 fail-safe at load)
 */
import fs from 'node:fs';
import path from 'node:path';
import {
  featureTokens,
  extractGeom,
  bodySizeOf,
  tokenWeight,
  ROLES,
  SUBJECTS,
  INSTRS,
} from '../src/utils/codecFeatures';
import { classifyTables, type BrainDoc } from '../src/utils/layoutBrain';
import { WS_ROOT, PKG_ROOT } from './wsPaths.mts';

const DATA = path.join(WS_ROOT, 'scratch', 'w1w2', 'labeled.json');
const OUT_TS = path.join(PKG_ROOT, 'src', 'utils', 'codecWeights.ts');
const DIM = 8192;
const K = ROLES.length + SUBJECTS.length + INSTRS.length; // 31
const N_ROLES = ROLES.length;
const N_SUBJ = SUBJECTS.length;
const N_INSTRS = INSTRS.length;

interface LabeledLine {
  x: number[];
  s: number;
  b: number;
  t: string;
  pg: number;
}
interface LabeledFile {
  file: string;
  fold: number;
  keyIdx: number;
  printedTotal: number | null;
  lines: LabeledLine[];
  roles: number[];
  subj: number[];
  instr: number[];
  markVal: (number | null)[];
  events: number[];
}

// ---------------------------------------------------------------- features

/** Sparse hashed example: bucket ids (with multiplicity, then averaged). */
function encode(tokens: string[]): Int32Array {
  const ids = new Int32Array(tokens.length);
  for (let i = 0; i < tokens.length; i++) ids[i] = featureHash(tokens[i]);
  return ids;
}
// MUST match runtime hashToken: FNV-1a then modulo DIM.
function featureHash(tok: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < tok.length; i++) {
    h ^= tok.charCodeAt(i);
    h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
  }
  return h % DIM;
}

interface Ex {
  ids: Int32Array;
  ws: Float32Array;
  role: number;
  subj: number;
  instr: number;
  fold: number;
  file: string;
}

function buildExamples(files: LabeledFile[]): { ex: Ex[]; geomTokens: number } {
  const ex: Ex[] = [];
  let geomTokens = 0;
  for (const f of files) {
    const doc = JSON.parse(
      fs.readFileSync(path.join(PKG_ROOT, 'scratch', 'brain-qu2', f.file.replace(/\.pdf$/, '') + '.json'), 'utf8')
    ) as BrainDoc;
    const cls = classifyTables(doc);
    const body = bodySizeOf(cls);
    for (let i = 0; i < f.lines.length; i++) {
      const L = f.lines[i];
      const stub = {
        text: L.t,
        size: L.s,
        bold: !!L.b,
        bbox: L.x,
        page: L.pg,
      };
      const geom = extractGeom(cls, stub, body, f.lines.length > 1 ? i / (f.lines.length - 1) : 0);
      const toks = featureTokens(L.t, geom);
      geomTokens += toks.length;
      const ids = new Int32Array(toks.length);
      const ws = new Float32Array(toks.length);
      for (let j = 0; j < toks.length; j++) {
        ids[j] = featureHash(toks[j]);
        ws[j] = tokenWeight(toks[j]);
      }
      ex.push({ ids, ws, role: f.roles[i], subj: f.subj[i], instr: f.instr[i], fold: f.fold, file: f.file });
    }
  }
  return { ex, geomTokens };
}

// ---------------------------------------------------------------- training

function softmax(v: number[], off: number, n: number): number[] {
  const out = new Array<number>(n);
  let max = -Infinity;
  for (let i = 0; i < n; i++) max = Math.max(max, v[off + i]);
  let sum = 0;
  for (let i = 0; i < n; i++) {
    out[i] = Math.exp(v[off + i] - max);
    sum += out[i];
  }
  for (let i = 0; i < n; i++) out[i] /= sum;
  return out;
}

class Codec {
  W: Float32Array; // DIM x K
  b: Float32Array; // K
  t = 0;
  /** per-class loss weights (inverse sqrt frequency, mean-normalized). */
  cwRole: Float32Array;
  cwSubj: Float32Array;
  cwInstr: Float32Array;
  constructor(classes: { role: number[]; subj: number[]; instr: number[] }) {
    this.W = new Float32Array(DIM * K);
    this.b = new Float32Array(K);
    this.cwRole = classWeights(classes.role, N_ROLES);
    this.cwSubj = classWeights(classes.subj, N_SUBJ);
    this.cwInstr = classWeights(classes.instr, N_INSTRS);
  }

  logits(ids: Int32Array, ws: Float32Array, buf: Float32Array): void {
    buf.fill(0);
    let wsum = 0;
    for (let i = 0; i < ids.length; i++) wsum += ws[i];
    if (wsum <= 0) wsum = 1;
    for (let i = 0; i < ids.length; i++) {
      const off = ids[i] * K;
      const w = ws[i] / wsum;
      for (let k = 0; k < K; k++) buf[k] += this.W[off + k] * w;
    }
    for (let k = 0; k < K; k++) buf[k] += this.b[k];
  }

  /** One SGD step on one example; returns weighted multi-task CE loss. */
  step(ex: Ex, lr: number, l2: number, axisW: number): number {
    const z = new Float32Array(K);
    this.logits(ex.ids, ex.ws, z);
    const wsum = ex.ws.reduce((a, v) => a + v, 0) || 1;
    const pRole = softmax(Array.from(z), 0, N_ROLES);
    const pSubj = softmax(Array.from(z), N_ROLES, N_SUBJ);
    const pInstr = softmax(Array.from(z), N_ROLES + N_SUBJ, N_INSTRS);
    let loss = 0;
    let axisSum = 0;
    const g = new Float32Array(K);
    // role head (axis weight 3 — the primary structural signal)
    for (let k = 0; k < N_ROLES; k++) {
      const cw = this.cwRole[k];
      const d = pRole[k] - (k === ex.role ? 1 : 0);
      g[k] += axisW * 3 * cw * d;
      if (k === ex.role) {
        loss -= axisW * 3 * cw * Math.log(Math.max(1e-12, pRole[k]));
        axisSum += axisW * 3 * cw;
      } else axisSum += 0;
    }
    for (let k = 0; k < N_SUBJ; k++) {
      const cw = this.cwSubj[k];
      const d = pSubj[k] - (k === ex.subj ? 1 : 0);
      g[N_ROLES + k] += axisW * cw * d;
      if (k === ex.subj) {
        loss -= axisW * cw * Math.log(Math.max(1e-12, pSubj[k]));
        axisSum += axisW * cw;
      }
    }
    for (let k = 0; k < N_INSTRS; k++) {
      const cw = this.cwInstr[k];
      const d = pInstr[k] - (k === ex.instr ? 1 : 0);
      g[N_ROLES + N_SUBJ + k] += axisW * cw * d;
      if (k === ex.instr) {
        loss -= axisW * cw * Math.log(Math.max(1e-12, pInstr[k]));
        axisSum += axisW * cw;
      }
    }
    // backprop into W rows: dL/dW_i = g * (w_i / wsum). The per-token weight
    // already carries 1/wsum — do NOT divide g again (that bug cost ~650x of
    // effective learning rate and collapsed the model to the prior).
    for (let i = 0; i < ex.ids.length; i++) {
      const off = ex.ids[i] * K;
      const w = ex.ws[i] / wsum;
      for (let k = 0; k < K; k++) this.W[off + k] -= lr * (g[k] * w + l2 * this.W[off + k]);
    }
    for (let k = 0; k < K; k++) this.b[k] -= lr * g[k];
    return loss / Math.max(1e-9, axisSum);
  }

  predict(ids: Int32Array, ws: Float32Array): { role: number; subj: number; instr: number; pr: number; ps: number; pi: number } {
    const z = new Float32Array(K);
    this.logits(ids, ws, z);
    const pr = softmax(Array.from(z), 0, N_ROLES);
    const ps = softmax(Array.from(z), N_ROLES, N_SUBJ);
    const pi = softmax(Array.from(z), N_ROLES + N_SUBJ, N_INSTRS);
    const argmax = (a: number[]) => a.reduce((bi, v, i) => (v > a[bi] ? i : bi), 0);
    return { role: argmax(pr), subj: argmax(ps), instr: argmax(pi), pr: pr[argmax(pr)], ps: ps[argmax(ps)], pi: pi[argmax(pi)] };
  }
}

/** inverse-sqrt-frequency class weights, mean-normalized to 1 */
function classWeights(counts: number[], n: number): Float32Array {
  const w = new Float32Array(n);
  let sum = 0;
  for (let k = 0; k < n; k++) {
    w[k] = 1 / Math.sqrt(Math.max(1, counts[k]));
    sum += w[k];
  }
  for (let k = 0; k < n; k++) w[k] *= n / sum;
  return w;
}

function evaluate(model: Codec, ex: Ex[]) {
  const roleHit = new Array(N_ROLES).fill(0);
  const roleTot = new Array(N_ROLES).fill(0);
  let subjHit = 0;
  let instrHit = 0;
  let hit = 0;
  for (const e of ex) {
    const p = model.predict(e.ids, e.ws);
    if (p.role === e.role) hit++;
    roleTot[e.role]++;
    if (p.role === e.role) roleHit[e.role]++;
    if (p.subj === e.subj) subjHit++;
    if (p.instr === e.instr) instrHit++;
  }
  return { hit, n: ex.length, roleHit, roleTot, subjHit, instrHit };
}

function main() {
  const data = JSON.parse(fs.readFileSync(DATA, 'utf8')) as { files: LabeledFile[] };
  console.log(`building examples from ${data.files.length} files...`);
  const { ex, geomTokens } = buildExamples(data.files);
  console.log(`${ex.length} examples, ~${(geomTokens / ex.length).toFixed(0)} tokens/line, K=${K}, DIM=${DIM}`);
  const freq = {
    role: new Array(N_ROLES).fill(0),
    subj: new Array(N_SUBJ).fill(0),
    instr: new Array(N_INSTRS).fill(0),
  };
  for (const e of ex) {
    freq.role[e.role]++;
    freq.subj[e.subj]++;
    freq.instr[e.instr]++;
  }

  // ---- 6-fold CV grouped by file (fold is assigned per file in the labeler)
  const folds = 6;
  let cvHit = 0;
  let cvN = 0;
  const perRoleHit = new Array(N_ROLES).fill(0);
  const perRoleTot = new Array(N_ROLES).fill(0);
  for (let f = 0; f < folds; f++) {
    const train = ex.filter((e) => e.fold !== f);
    const test = ex.filter((e) => e.fold === f);
    const freqT = {
      role: new Array(N_ROLES).fill(0),
      subj: new Array(N_SUBJ).fill(0),
      instr: new Array(N_INSTRS).fill(0),
    };
    for (const e of train) {
      freqT.role[e.role]++;
      freqT.subj[e.subj]++;
      freqT.instr[e.instr]++;
    }
    const m = new Codec(freqT);
    const idx = train.map((_, i) => i);
    const lr0 = 3.0;
    for (let epoch = 0; epoch < 20; epoch++) {
      // deterministic shuffle (LCG) — reproducible builds
      for (let i = idx.length - 1; i > 0; i--) {
        const j = (1103515245 * i + 12345 + epoch * 7919) % (i + 1);
        [idx[i], idx[j]] = [idx[j], idx[i]];
      }
      let loss = 0;
      for (const ti of idx) loss += m.step(train[ti], lr0 / (1 + epoch * 0.35), 1e-7, 1);
    }
    const r = evaluate(m, test);
    cvHit += r.hit;
    cvN += r.n;
    for (let k = 0; k < N_ROLES; k++) {
      perRoleHit[k] += r.roleHit[k];
      perRoleTot[k] += r.roleTot[k];
    }
    console.log(`fold${f}: role acc ${(r.hit / r.n * 100).toFixed(1)}% (${r.n} lines)`);
  }
  console.log(`\nW1 CV (file-grouped): role acc ${(cvHit / cvN * 100).toFixed(2)}% over ${cvN} lines`);
  for (let k = 0; k < N_ROLES; k++)
    if (perRoleTot[k] > 0)
      console.log(`  ${ROLES[k].padEnd(6)} ${(perRoleHit[k] / perRoleTot[k] * 100).toFixed(1)}%  (n=${perRoleTot[k]})`);

  // ---- final model on ALL files
  console.log('\ntraining final model on all 47 files...');
  const m = new Codec(freq);
  const idx = ex.map((_, i) => i);
  const lr0 = 3.0;
  for (let epoch = 0; epoch < 30; epoch++) {
    for (let i = idx.length - 1; i > 0; i--) {
      const j = (1103515245 * i + 12345 + epoch * 7919) % (i + 1);
      [idx[i], idx[j]] = [idx[j], idx[i]];
    }
    let loss = 0;
    for (const ti of idx) loss += m.step(ex[ti], lr0 / (1 + epoch * 0.35), 1e-7, 1);
    if (epoch % 5 === 0 || epoch === 29) console.log(`  epoch${epoch}: loss=${(loss / ex.length).toFixed(4)}`);
  }
  const self = evaluate(m, ex);
  console.log(`final train accuracy: role ${(self.hit / self.n * 100).toFixed(2)}%, subj ${(self.subjHit / self.n * 100).toFixed(2)}%, instr ${(self.instrHit / self.n * 100).toFixed(2)}%`);

  // ---- int8 quantize + emit TS module
  let maxAbs = 0;
  for (let i = 0; i < m.W.length; i++) maxAbs = Math.max(maxAbs, Math.abs(m.W[i]));
  const scale = maxAbs / 127;
  const q = new Int8Array(m.W.length);
  for (let i = 0; i < m.W.length; i++) q[i] = Math.round(m.W[i] / scale);
  const b64 = Buffer.from(q.buffer).toString('base64');
  const bias = Array.from(m.b, (v) => Math.round(v * 1e5) / 1e5);

  const ts = `/**
 * codecWeights.ts — W1 SEMANTIC CODEC, trained weights (GENERATED FILE).
 *
 * Source of truth: scripts-batch/codec_train.mts over the labeled qu2 corpus
 * (${ex.length} lines, 47 files). FastText-style hashed char-n-gram features
 * (codecFeatures.featureTokens), int8-quantized, three softmax heads:
 * ROLE(${N_ROLES}) + SUBJECT(${N_SUBJ}) + INSTRUCTION(${N_INSTRS}) = K=${K}.
 *
 * Budget: ${(b64.length / 1024).toFixed(0)}KB base64 (~${(q.length / 1024).toFixed(0)}KB int8) — the codec layer of the
 * Specialist architecture stays a fraction of a megabyte.
 *
 * S26 CONTRACT: the runtime treats ANY decode failure as "codec absent" and
 * falls back to current behavior — weights are data, never a hazard.
 */
export const CODEC_DIM = ${DIM};
export const CODEC_K = ${K};
export const CODEC_N_ROLES = ${N_ROLES};
export const CODEC_N_SUBJ = ${N_SUBJ};
export const CODEC_N_INSTRS = ${N_INSTRS};
export const CODEC_SCALE = ${scale.toExponential(6)};
export const CODEC_BIAS: number[] = [${bias.join(', ')}];
export const CODEC_DATA = '${b64}';
`;
  fs.writeFileSync(OUT_TS, ts);
  console.log(`\nwrote ${OUT_TS} (${(b64.length / 1024).toFixed(0)}KB base64, scale=${scale.toExponential(3)})`);
}

main();
