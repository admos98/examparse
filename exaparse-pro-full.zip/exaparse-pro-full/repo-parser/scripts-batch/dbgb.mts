import fs from 'node:fs';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from './wsPaths.mts';
const text = fs.readFileSync(WS_ROOT + '/scratch/texts/9th_1-3.pdf.txt', 'utf8');
const doc = parseExamRawText(text, 't', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
const s = doc.sections.find(x => x.rowId === 'B')!;
console.log('B:', JSON.stringify({cat: s.majorCategory, hp: s.hasPassage, pt: (s.passageText||'').slice(0,50), nq: s.questions.length}));
for (const q of s.questions) console.log('  q'+q.number, JSON.stringify((q.receipt as any)?.ruleChain), JSON.stringify(q.stem.slice(0,40)));
