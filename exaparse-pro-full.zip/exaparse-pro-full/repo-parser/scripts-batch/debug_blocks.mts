/** Debug segmenter blocks for section B of grade7 pdf. */
import { classifyLines, segmentQuestionBlocks } from '../src/utils/parserRules';

const secB = `1.25  در هر سوال گزینه صحیح را انتخاب کنید.
5-nine forty in the evening means ………………
a. 9: 40p.m  b. 9: 40a. m  c. 9: 14a. m  d. 9: 14p.m
6- A: who is that ………………?
B: my aunt.
a. man  b. boy  c. woman  d. Ladan
7-A: how old is your brother sara?
B: …………….. 10 years old.
a. he’s  b. she’s  c. it’s  d. that’s
8- A: let’s have something to drink.
B: sounds good I’m ………………. Too.
a. hungry  b. cake  c. water  d. thirsty
9- A: which one is your uncle?
B: He is the man wearing …………………. .
a. black scarf  b. white shirt  c. yellow dress  d. gray chador
B`;

const lines = secB.split('\n');
const cls = classifyLines(lines);
for (const c of cls) {
  if (c.text.trim()) console.log(`[${c.kind}/${c.ruleId}/${c.confidence}] ${c.text.slice(0, 55)}`);
}
console.log('--- blocks ---');
const blocks = segmentQuestionBlocks(cls);
for (const b of blocks) console.log(`Q${b.number}: ${JSON.stringify(b.text.slice(0, 120))}`);
