/** Debug docx numbering extraction. */
import fs from 'node:fs';
import { extractTextFromDocx } from '../src/utils/fileExtractor';
import { WS_ROOT } from './wsPaths.mts';

async function main() {
  const buf = fs.readFileSync(WS_ROOT + '/samples/qu/کلاس هشتم پایانی.docx');
  const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
  const text = await extractTextFromDocx(ab as ArrayBuffer);
  const lines = text.split('\n');
  console.log('I enjoy line:', JSON.stringify(lines.find((l) => l.includes('I enjoy'))));
  console.log('father line:', JSON.stringify(lines.find((l) => l.includes('your father'))));
  console.log('bushehr line:', JSON.stringify(lines.find((l) => l.includes('bushehr is in'))));
}
main();
