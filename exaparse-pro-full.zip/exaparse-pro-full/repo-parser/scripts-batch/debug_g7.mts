/** Debug classifier + segmenter + MCQ extractor on real lines. */
import { classifyLines, segmentQuestionBlocks } from '../src/utils/parserRules';
import { parseExamRawText } from '../src/utils/parserEngine';
import fs from 'node:fs';
import { WS_ROOT } from './wsPaths.mts';

const text = fs.readFileSync(WS_ROOT + '/scratch/texts/کلاس_هفتم_پایانی.pdf.txt', 'utf8');
const normText = text;

const probe = [
  '32- (that / this) is a motorcycle.',
  '33- My teacher is the (old / young) man.',
  'a. 9: 40p.m  b. 9: 40a. m  c. 9: 14a. m  d. 9: 14p.m',
  '5-nine forty in the evening means ………………',
  '1.25  در هر سوال گزینه صحیح را انتخاب کنید.',
];
const cls = classifyLines(probe);
for (const c of cls) console.log(`[${c.kind}/${c.ruleId}/${c.confidence}] ${c.text.slice(0, 60)}`);

console.log('--- MCQ extractor probe ---');
// import the private function via engine? It's not exported. Test through full parse instead.
const doc = parseExamRawText(normText, 'g7.pdf');
const secB = doc.sections.find((s) => s.rowId === 'B');
console.log('B types:', secB?.questions.map((q) => `${q.number}:${q.type}`).join(' '));

console.log('--- trace: rules histogram ---');
const rules = doc.parseTrace?.rules || [];
console.log(rules.map((r) => `${r.id}(${r.kind}):${r.hits}`).join(' '));
