/** Debug section I slice through classify+segment. */
import { classifyLines, segmentQuestionBlocks } from '../src/utils/parserRules';

const secI = `0.5  با توجه به تصاویر عبارت صحیح درون پرانتز را مشخص کنید.
32- (that / this) is a motorcycle.
33- My teacher is the (old / young) man.
I`;

const cls = classifyLines(secI.split('\n'));
for (const c of cls) console.log(`[${c.kind}/${c.ruleId}/${c.confidence}] ${JSON.stringify(c.text.slice(0, 60))}`);
const blocks = segmentQuestionBlocks(cls);
console.log('blocks:', blocks.map((b) => `Q${b.number} [${b.lineStart}-${b.lineEnd}]`).join(' '));
console.log(JSON.stringify(blocks.map((b) => b.text), null, 1));

// Now the FULL engine parse for section I questions
import { parseExamRawText } from '../src/utils/parserEngine';
import fs from 'node:fs';
import { WS_ROOT } from './wsPaths.mts';
const text = fs.readFileSync(WS_ROOT + '/scratch/texts/کلاس_هفتم_پایانی.pdf.txt', 'utf8');
const doc = parseExamRawText(text, 'g7.pdf');
const sec = doc.sections.find((s) => s.rowId === 'I');
console.log('Engine I questions:', sec?.questions.map((q) => `${q.number}:${q.type}:${q.stem.slice(0, 40)}`));
