/** Debug parseDocxNumbering logic standalone. */
import fs from 'node:fs';
import JSZip from 'jszip';
import { WS_ROOT } from './wsPaths.mts';

async function main() {
  const buf = fs.readFileSync(WS_ROOT + '/samples/qu/کلاس هشتم پایانی.docx');
  const zip = await JSZip.loadAsync(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength));
  const numberingXml = await zip.file('word/numbering.xml')!.async('text');

  const absRe = /<w:abstractNum\s+[^>]*w:abstractNumId="([^"]+)"[\s\S]*?<\/w:abstractNum>/g;
  let m: RegExpExecArray | null;
  const ids: string[] = [];
  while ((m = absRe.exec(numberingXml)) !== null) {
    ids.push(m[1]);
    if (m[1] === '16') {
      const seg = m[0];
      console.log('abs16 seg len:', seg.length);
      console.log('has lvl:', seg.includes('<w:lvl'));
      const lvlRe = /<w:lvl\s+[^>]*w:ilvl="(\d+)"[^>]*>([\s\S]*?)<\/w:lvl>/g;
      const lm = [...seg.matchAll(lvlRe)];
      console.log('lvls found:', lm.map((x) => x[1]).join(','));
      console.log('lvl open tag:', seg.match(/<w:lvl [^>]*>/)?.[0]);
      console.log('numFmt in seg:', seg.match(/<w:numFmt w:val="([^"]+)"/)?.[1]);
    }
  }
  console.log('abstract ids:', ids.join(','));
}
main();
