/** Debug numbering.xml parsing. */
import fs from 'node:fs';
import JSZip from 'jszip';
import { WS_ROOT } from './wsPaths.mts';

async function main() {
  const buf = fs.readFileSync(WS_ROOT + '/samples/qu/کلاس هشتم پایانی.docx');
  const zip = await JSZip.loadAsync(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength));
  const numberingXml = await zip.file('word/numbering.xml')!.async('text');
  const docXml = await zip.file('word/document.xml')!.async('text');

  const numRe = /<w:num\s+[^>]*w:numId="([^"]+)"[^>]*>[\s\S]*?<w:abstractNumId\s+w:val="([^"]+)"[^>]*\/?>[\s\S]*?<\/w:num>/g;
  const pairs = [...numberingXml.matchAll(numRe)].map((m) => [m[1], m[2]]);
  console.log('num pairs found:', pairs.length, 'first:', pairs.slice(0, 3));

  const pRe = /<w:p(?:\s+[^>]*)?>([\s\S]*?)<\/w:p>/gi;
  let m: RegExpExecArray | null;
  let withNumPr = 0;
  while ((m = pRe.exec(docXml)) !== null) {
    if (m[1].includes('<w:numPr>')) {
      withNumPr++;
      if (withNumPr <= 2) {
        const np = m[1].match(/<w:numPr>[\s\S]*?<\/w:numPr>/);
        console.log('sample numPr:', JSON.stringify(np![0].slice(0, 120)));
      }
    }
  }
  console.log('paragraphs with numPr:', withNumPr);

  // check the actual <w:num ...> element shape
  const raw = numberingXml.match(/<w:num [^>]*>/);
  console.log('raw num open tag:', raw && raw[0]);
}
main();
