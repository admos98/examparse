/**
 * Debug harness: parse one mock text file and dump section/question details.
 * Usage: npx tsx scripts-batch/debug_one.mts <textfile> [sectionId]
 */
import fs from 'node:fs';
import { parseExamRawText } from '../src/utils/parserEngine';

const file = process.argv[2];
const onlySec = process.argv[3];
const text = fs.readFileSync(file, 'utf8');
const doc = parseExamRawText(text, 'debug.docx', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
for (const s of doc.sections) {
  if (onlySec && s.rowId !== onlySec) continue;
  console.log(`[${s.rowId}] cat=${s.majorCategory} mark=${s.markTotal} title="${(s.title || '').slice(0, 70)}"`);
  console.log(`   faInstr="${(s.persianInstruction || '').slice(0, 90)}"`);
  console.log(`   enInstr="${(s.englishInstruction || '').slice(0, 90)}"`);
  console.log(`   wordBank=${JSON.stringify(s.wordBank ?? [])}`);
  for (const q of s.questions) {
    const rc = (q as any).receipt?.ruleChain?.join('>') ?? 'none';
    console.log(`   q${q.number} [${q.type}] mark=${q.mark} opts=${q.options ? q.options.map((o) => o.text).join('|') : '-'} rc=${rc} stem="${q.stem.slice(0, 90).replace(/\n/g, ' ¶ ')}"`);
  }
}
