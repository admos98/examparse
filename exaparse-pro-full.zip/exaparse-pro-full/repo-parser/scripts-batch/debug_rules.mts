/**
 * Dump the rule-table classification + segmentation for one mock text file.
 * Usage: npx tsx scripts-batch/debug_rules.mts <textfile> [fromLine toLine]
 */
import fs from 'node:fs';
import { classifyLines, segmentQuestionBlocks } from '../src/utils/parserRules';

const file = process.argv[2];
const from = process.argv[3] ? parseInt(process.argv[3], 10) : 0;
const to = process.argv[4] ? parseInt(process.argv[4], 10) : 999;
const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
const cls = classifyLines(lines);
lines.forEach((l, i) => {
  if (i < from || i > to) return;
  const c = cls[i];
  console.log(`${String(i).padStart(3)} [${(c as any).kind ?? (c as any).type ?? '?'}] ${l.slice(0, 80)}`);
});
const blocks = segmentQuestionBlocks(cls);
console.log('--- blocks ---');
for (const b of blocks) {
  console.log(`#${b.number} [${b.lineStart}-${b.lineEnd}] ${b.ruleChain.join('>')} :: ${(b.text || '').slice(0, 60).replace(/\n/g, ' ¶ ')}`);
}
