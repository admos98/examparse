/**
 * Batch extractor for the 30-sample corpus.
 * Replicates fileExtractor.ts ingestion EXACTLY for Node:
 *  - docx: JSZip -> word/document.xml -> <w:p>/<w:t> regex path (same as fileExtractor regex fallback)
 *  - pdf:  pdfjs text layer with the same y-tolerance(6) line grouping as extractPdfDetailed Path A
 * Then runs the REAL parseExamRawText and writes both artifacts to scratch/.
 */
import fs from 'node:fs';
import path from 'node:path';
import { getDocument } from 'pdfjs-dist/legacy/build/pdf.mjs';
import { extractTextFromDocx, extractPdfTextDetailed } from './pdfDocxExtract.mts';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from './wsPaths.mts';

const CORPUS = process.env.CORPUS_DIR ?? WS_ROOT + '/samples/qu';
const OUT_TXT = process.env.OUT_TXT ?? WS_ROOT + '/scratch/texts';
const OUT_JSON = process.env.OUT_JSON ?? WS_ROOT + '/scratch/parsed';
fs.mkdirSync(OUT_TXT, { recursive: true });
fs.mkdirSync(OUT_JSON, { recursive: true });

async function main() {
  const files = fs.readdirSync(CORPUS).filter((f) => /\.(pdf|docx)$/i.test(f)).sort();
  console.log(`Corpus: ${files.length} files`);
  const summary: any[] = [];

  for (const fname of files) {
    const full = path.join(CORPUS, fname);
    const data = fs.readFileSync(full);
    const ab = new Uint8Array(data).buffer as ArrayBuffer;
    const safeName = fname.replace(/[^\p{L}\p{N}.\-]+/gu, '_');
    try {
      let text = '';
      let sourceType = '';
      let pages = 1;
      if (fname.toLowerCase().endsWith('.docx')) {
        text = await extractTextFromDocx(ab);
        sourceType = 'docx';
      } else {
        const r = await extractPdfTextDetailed(ab);
        text = r.text;
        pages = r.pages;
        sourceType = r.chars >= 30 ? 'pdf_text' : 'SCANNED_NEEDS_OCR';
      }
      fs.writeFileSync(path.join(OUT_TXT, safeName + '.txt'), text, 'utf8');

      // Run the REAL parser on the extracted text.
      let qCount = -1;
      let secCount = -1;
      let parseErr = '';
      try {
        const doc = parseExamRawText(text, fname, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
        qCount = doc.totalQuestions;
        secCount = doc.sections.length;
        fs.writeFileSync(path.join(OUT_JSON, safeName + '.json'), JSON.stringify(doc, null, 2), 'utf8');
      } catch (e: any) {
        parseErr = e?.message || String(e);
      }

      const firstLine = text.split('\n').find((l) => l.trim()) || '';
      summary.push({ fname, sourceType, pages, chars: text.length, questions: qCount, sections: secCount, parseErr, firstLine: firstLine.slice(0, 80) });
      console.log(`${sourceType.padEnd(18)} q=${String(qCount).padStart(3)} sec=${String(secCount).padStart(2)}  ${fname}`);
      if (parseErr) console.log(`   PARSE ERROR: ${parseErr}`);
    } catch (e: any) {
      summary.push({ fname, error: e?.message || String(e) });
      console.log(`EXTRACT FAIL: ${fname}: ${e?.message}`);
    }
  }
  fs.writeFileSync(process.env.SUMMARY_JSON ?? WS_ROOT + '/scratch/extract-summary.json', JSON.stringify(summary, null, 2));
  console.log('\nDone. Texts ->', OUT_TXT, ' Parsed ->', OUT_JSON);
}

// Top-level await: callers that import() this module (scripts-batch/mocks.mts)
// must observe FULL completion before their next phase — a floating main()
// made the mock-grade runner race its own extraction and grade stale texts.
await main().catch((e) => { console.error(e); process.exit(1); });
