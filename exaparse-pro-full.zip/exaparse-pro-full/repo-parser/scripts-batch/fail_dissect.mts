/**
 * fail_dissect.mts — corpus-wide failure taxonomy.
 *
 * For every GT'd qu2 file: run the SHIPPED baseline parse (oracle off,
 * brain drive), grade it, and bucket every issue into a family.
 * Output: per-file score + family histogram, then corpus-wide aggregate
 * so the dominant failure modes are unmistakable.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { buildBrainPreSplit } from '../src/utils/brainStep';
import type { BrainDoc } from '../src/utils/layoutBrain';
import { WS_ROOT, PKG_ROOT } from './wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-qu2');
const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-qu2');

process.env.EXAM_ORACLE = 'off';

function family(issue: string): string {
  if (issue.startsWith('section ids:')) return 'STRUCT.ids';
  if (issue.includes(' MISSING')) return 'STRUCT.missing-section';
  if (issue.includes(' category:')) return 'category';
  if (issue.includes(' markTotal:')) return 'marks.section';
  if (issue.includes(' count:')) return 'q.count';
  if (issue.includes(' q# at pos')) return 'q.number';
  if (/ q\d+ type:/.test(issue)) return 'q.type';
  if (/ q\d+ stem/.test(issue)) return 'q.stem';
  if (issue.startsWith('header.')) return 'header';
  if (issue.startsWith('totalMarks')) return 'marks.total';
  if (/ q\d+ missing/.test(issue)) return 'q.missing-for-stem';
  return 'other:' + issue.slice(0, 40);
}

function main() {
  const gtFiles = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  const corpusFam = new Map<string, number>();
  const famFiles = new Map<string, Set<string>>();
  const detail: string[] = [];

  for (const gf of gtFiles) {
    const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, gf), 'utf8'));
    const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const text = fs.readFileSync(textPath, 'utf8');
    const brainPath = path.join(BRAIN_DIR, gt.file.replace(/\.pdf$/, '') + '.json');
    const brainDoc = fs.existsSync(brainPath) ? (JSON.parse(fs.readFileSync(brainPath, 'utf8')) as BrainDoc) : undefined;

    const step = buildBrainPreSplit(brainDoc, 'drive');
    const parsed = parseExamRawText(text, gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true }, step.preSplit, step.source);
    const g = gradeParse(parsed, gt);

    const famCount = new Map<string, number>();
    for (const i of g.issues) {
      const f = family(i);
      famCount.set(f, (famCount.get(f) ?? 0) + 1);
      corpusFam.set(f, (corpusFam.get(f) ?? 0) + 1);
      if (!famFiles.has(f)) famFiles.set(f, new Set());
      famFiles.get(f)!.add(gt.file);
    }
    const mode = step.report?.mode ?? 'none';
    const top = [...famCount.entries()].sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k}=${v}`).join(' ');
    detail.push(`${g.score >= 90 ? 'OK' : '!!'} ${gt.file}  ${g.score.toFixed(1)}% (${g.issues.length}/${g.total})  [${mode}]  ${top}`);
  }

  console.log('=== PER FILE ===');
  for (const d of detail) console.log(d);
  console.log('\n=== CORPUS FAMILY HISTOGRAM (issue count | files affected) ===');
  for (const [f, c] of [...corpusFam.entries()].sort((a, b) => b[1] - a[1])) {
    console.log(`${f.padEnd(24)} ${String(c).padStart(4)}  (${famFiles.get(f)!.size} files)`);
  }
}

main();
