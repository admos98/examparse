/**
 * fail_instr.mts — verify the instruction-capture hypothesis.
 * For the worst files: per section, print captured instruction text,
 * category got/want, and the q-type got/want sequence.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { buildBrainPreSplit } from '../src/utils/brainStep';
import type { BrainDoc } from '../src/utils/layoutBrain';
import { WS_ROOT, PKG_ROOT } from './wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-qu2');
const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-qu2');
process.env.EXAM_ORACLE = 'off';

const TARGETS = process.argv[2] ? process.argv[2].split(',') : ['14041009p4tk9v2803.pdf', '14050504p4p187l300.pdf', '13991010p3iy8yh87.pdf'];

for (const tf of TARGETS) {
  const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, tf.replace('.pdf', '-pdf.json')), 'utf8'));
  const textPath = path.join(TEXT_DIR, tf.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
  if (!fs.existsSync(textPath)) { console.log(`no text for ${tf}`); continue; }
  const text = fs.readFileSync(textPath, 'utf8');
  const brainPath = path.join(BRAIN_DIR, tf.replace('.pdf', '.json'));
  const brainDoc = fs.existsSync(brainPath) ? (JSON.parse(fs.readFileSync(brainPath, 'utf8')) as BrainDoc) : undefined;
  const step = buildBrainPreSplit(brainDoc, 'drive');
  const parsed = parseExamRawText(text, tf, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true }, step.preSplit, step.source);
  const g = gradeParse(parsed, gt);

  console.log(`\n########## ${tf}  score ${g.score}% ##########`);
  const gtByOccurrence = new Map<string, number>();
  for (const sec of parsed.sections) {
    const occ = gtByOccurrence.get(sec.rowId) ?? 0;
    gtByOccurrence.set(sec.rowId, occ + 1);
    const gts = gt.sections.filter((s: any) => s.id === sec.rowId)[occ];
    const wantTypes = gts ? gts.qs.flatMap((q: any) => (q.stem !== undefined ? [] : Array.isArray(q.n) ? q.n.map(() => q.t) : [q.t])) : null;
    const gotTypes = sec.questions.map((q) => q.type);
    console.log(`--- section ${sec.rowId} "${(sec.title || '').slice(0, 60)}"`);
    console.log(`    cat got=${sec.majorCategory} want=${gts?.cat ?? '?'}   marks got=${sec.markTotal} want=${gts?.mark ?? '?'}`);
    if (sec.persianInstruction || sec.englishInstruction) {
      console.log(`    INSTR.fa: ${(sec.persianInstruction || '').slice(0, 140)}`);
      console.log(`    INSTR.en: ${(sec.englishInstruction || '').slice(0, 140)}`);
    } else {
      console.log(`    INSTR: (none captured)`);
    }
    const mism = [];
    const n = Math.min(gotTypes.length, (wantTypes ?? []).length);
    for (let i = 0; i < n; i++) if (gotTypes[i] !== (wantTypes ?? [])[i]) mism.push(`#${sec.questions[i]?.number}:${gotTypes[i]}≠${(wantTypes ?? [])[i]}`);
    console.log(`    types got=[${gotTypes.join(',')}]`);
    console.log(`           want=[${(wantTypes ?? []).join(',')}]`);
    if (mism.length) console.log(`    MISMATCH: ${mism.join(' ')}`);
  }
}
