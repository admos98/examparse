/**
 * fail_root.mts — confusion-matrix drill-down for the dominant families.
 * Aggregates got→want pairs for q.type, category, q.number (as offsets),
 * marks.section and marks.total across the whole corpus.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { buildBrainPreSplit } from '../src/utils/brainStep';
import type { BrainDoc } from '../src/utils/layoutBrain';
import { WS_ROOT, PKG_ROOT } from './wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-qu2');
const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-qu2');

process.env.EXAM_ORACLE = 'off';

type Counter<T> = Map<string, number>;
function bump(m: Counter<unknown>, k: string) { m.set(k, (m.get(k) ?? 0) + 1); }

function main() {
  const gtFiles = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  const typeConf = new Map<string, number>();
  const catConf = new Map<string, number>();
  const numPattern = new Map<string, number>();
  const markSec = new Map<string, number>();
  const markTot = new Map<string, number>();
  const headerIssues = new Map<string, number>();

  for (const gf of gtFiles) {
    const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, gf), 'utf8'));
    const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const text = fs.readFileSync(textPath, 'utf8');
    const brainPath = path.join(BRAIN_DIR, gt.file.replace(/\.pdf$/, '') + '.json');
    const brainDoc = fs.existsSync(brainPath) ? (JSON.parse(fs.readFileSync(brainPath, 'utf8')) as BrainDoc) : undefined;

    const step = buildBrainPreSplit(brainDoc, 'drive');
    const parsed = parseExamRawText(text, gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true }, step.preSplit, step.source);
    const g = gradeParse(parsed, gt);

    for (const issue of g.issues) {
      let m = /^(.+?) q(\d+) type: got (\S+) want (\S+)$/.exec(issue);
      if (m) { bump(typeConf, `${m[3]} -> ${m[4]}`); continue; }
      m = /^(.+?) category: got (\S+) want (\S+)$/.exec(issue);
      if (m) { bump(catConf, `${m[2]} -> ${m[3]}`); continue; }
      m = /^(.+?) q# at pos (\d+): got (\S+) want (\S+)$/.exec(issue);
      if (m) {
        const gn = Number(m[3]), wn = Number(m[4]);
        if (Number.isFinite(gn) && Number.isFinite(wn)) {
          const d = gn - wn;
          bump(numPattern, d === 0 ? 'equal-but-flagged' : d > 0 ? `got +${d}` : `got ${d}`);
        } else bump(numPattern, `nonnum got=${m[3]} want=${m[4]}`);
        continue;
      }
      m = /^(.+?) markTotal: got (\S+) want (\S+)$/.exec(issue);
      if (m) { bump(markSec, `got ${m[2]} want ${m[3]}`); continue; }
      m = /^totalMarks: got (\S+) want (\S+)$/.exec(issue);
      if (m) { bump(markTot, `got ${m[1]} want ${m[2]}`); continue; }
      m = /^header\.(\S+): got "(.*)" want "(.*)"$/.exec(issue);
      if (m) { bump(headerIssues, `${m[1]}: "${m[2].slice(0, 25)}" vs "${m[3].slice(0, 25)}"`); continue; }
    }
  }

  const dump = (title: string, map: Map<string, number>, limit = 40) => {
    console.log(`\n=== ${title} ===`);
    for (const [k, v] of [...map.entries()].sort((a, b) => b[1] - a[1]).slice(0, limit)) console.log(`${String(v).padStart(4)}  ${k}`);
  };
  dump('TYPE CONFUSIONS (got -> want)', typeConf);
  dump('CATEGORY CONFUSIONS (got -> want)', catConf);
  dump('QUESTION-NUMBER DELTAS (got - want)', numPattern);
  dump('SECTION MARKS (got vs want)', markSec);
  dump('TOTAL MARKS (got vs want)', markTot);
  dump('HEADER', headerIssues);
}

main();
