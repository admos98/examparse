/**
 * fail_sbs.mts — side-by-side GT vs parse for chosen files.
 * Shows, per section: parsed id/cat/mark/count + per-question (number,type)
 * against GT, so the exact failure mechanics are visible.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { buildBrainPreSplit } from '../src/utils/brainStep';
import type { BrainDoc } from '../src/utils/layoutBrain';
import { WS_ROOT, PKG_ROOT } from './wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-qu2');
const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-qu2');

const files = process.argv.slice(2);
if (!files.length) {
  console.error('usage: tsx fail_sbs.mts <fileStem> [...]');
  process.exit(1);
}

const TYPE_ABBR: Record<string, string> = {
  multiple_choice: 'MCQ', true_false: 'TF', fill_blank: 'FB', short_answer: 'SA',
  matching: 'MAT', word_bank_fill: 'WBF', inline_choice: 'ILC', form_in_parentheses: 'FIP',
  unscramble: 'UNSC', ordering: 'ORD', error_correction: 'ERRC', cloze: 'CLZ',
  writing: 'WRT', define: 'DEF', translation: 'TRN', listening_numbered: 'LNUM',
};

for (const stem of files) {
  const gf = fs.readdirSync(GT_DIR).find((f) => f.startsWith(stem));
  if (!gf) { console.log(`NO GT for ${stem}`); continue; }
  const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, gf), 'utf8'));
  const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
  const text = fs.readFileSync(textPath, 'utf8');
  const brainPath = path.join(BRAIN_DIR, gt.file.replace(/\.pdf$/, '') + '.json');
  const brainDoc = fs.existsSync(brainPath) ? (JSON.parse(fs.readFileSync(brainPath, 'utf8')) as BrainDoc) : undefined;
  const step = buildBrainPreSplit(brainDoc, 'drive');
  const parsed = parseExamRawText(text, gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true }, step.preSplit, step.source);

  console.log(`\n########## ${gt.file} [${step.report?.mode ?? 'none'}] ##########`);
  console.log(`sections: got ${parsed.sections.length} want ${gt.sections.length}`);

  const gtAbbr = (t: string) => TYPE_ABBR[t] ?? t.slice(0, 4);
  for (let i = 0; i < Math.max(gt.sections.length, parsed.sections.length); i++) {
    const g = gt.sections[i];
    const p = parsed.sections[i];
    const gqs = g ? g.qs.filter((q: { stem?: unknown }) => q.stem === undefined).flatMap((q: { n: number | number[]; t: string }) => (Array.isArray(q.n) ? q.n : [q.n]).map((n: number) => `${n}:${gtAbbr(q.t)}`)) : [];
    const pqs = p ? p.questions.map((q) => `${q.number}:${TYPE_ABBR[q.type] ?? q.type.slice(0, 4)}`) : [];
    const gLine = g ? `GT  ${g.id}[${gtAbbr(g.cat)}] m=${g.mark} n=${gqs.length} | ${gqs.join(' ')}` : 'GT  —';
    const pLine = p ? `PS  ${p.rowId}[${TYPE_ABBR[p.majorCategory] ?? p.majorCategory}] m=${p.markTotal} n=${pqs.length} | ${pqs.join(' ')}` : 'PS  —';
    console.log(gLine);
    console.log(pLine);
  }
}
