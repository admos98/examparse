/**
 * fail_splitter.mts — which splitter does each GT'd file take, and what
 * section/mark skeleton does it produce? One line per file.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { buildBrainPreSplit } from '../src/utils/brainStep';
import type { BrainDoc } from '../src/utils/layoutBrain';
import { WS_ROOT, PKG_ROOT } from './wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-qu2');
const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-qu2');

const only = process.argv.slice(2);

for (const gf of fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort()) {
  const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, gf), 'utf8'));
  if (only.length && !only.some((o) => gt.file.includes(o))) continue;
  const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
  if (!fs.existsSync(textPath)) continue;
  const text = fs.readFileSync(textPath, 'utf8');
  const brainPath = path.join(BRAIN_DIR, gt.file.replace(/\.pdf$/, '') + '.json');
  const brainDoc = fs.existsSync(brainPath) ? (JSON.parse(fs.readFileSync(brainPath, 'utf8')) as BrainDoc) : undefined;
  const step = buildBrainPreSplit(brainDoc, 'drive');
  const stderrWrite = process.stderr.write.bind(process.stderr);
  let splitter = '';
  process.stderr.write = (chunk: any) => {
    const s = String(chunk);
    const m = s.match(/\[splitter\] (\S+)/);
    if (m) splitter = m[1];
    return true;
  };
  const parsed = parseExamRawText(text, gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true }, step.preSplit, step.source);
  process.stderr.write = stderrWrite;
  const skel = parsed.sections.map((s) => `${s.rowId}[${(s.majorCategory || '?').slice(0, 4)}]m${s.markTotal}n${s.questions.length}`).join(' ');
  console.log(`${gt.file.replace('.pdf', '').slice(9)}  via=${(splitter || 'fallback').padEnd(12)} got=${parsed.sections.length} want=${gt.sections.length}\n    ${skel}`);
}
