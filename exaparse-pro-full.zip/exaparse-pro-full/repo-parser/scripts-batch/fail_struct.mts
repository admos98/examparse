/**
 * fail_struct.mts — structural triage of the negative-scorer family.
 * For each GT'd file below a threshold: print GT section ids (with q counts
 * and marks) vs the parsed section ids, so the subject-span / phantom-section
 * / key-tail failure shape is visible in one screen.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { buildBrainPreSplit } from '../src/utils/brainStep';
import type { BrainDoc } from '../src/utils/layoutBrain';
import { WS_ROOT, PKG_ROOT } from './wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-qu2');
const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-qu2');

process.env.EXAM_ORACLE = 'off';

const FOCUS = process.argv[2]
  ? process.argv[2].split(',')
  : null;

function main() {
  const gtFiles = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  for (const gf of gtFiles) {
    const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, gf), 'utf8'));
    if (FOCUS && !FOCUS.some((f: string) => gt.file.includes(f))) continue;
    const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const text = fs.readFileSync(textPath, 'utf8');
    const brainPath = path.join(BRAIN_DIR, gt.file.replace(/\.pdf$/, '') + '.json');
    const brainDoc = fs.existsSync(brainPath) ? (JSON.parse(fs.readFileSync(brainPath, 'utf8')) as BrainDoc) : undefined;

    const step = buildBrainPreSplit(brainDoc, 'drive');
    const parsed = parseExamRawText(text, gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true }, step.preSplit, step.source);
    const g = gradeParse(parsed, gt);
    if (g.score >= 70 && !FOCUS) continue;

    console.log(`\n##### ${gt.file}  score=${g.score.toFixed(1)}% (${g.issues.length}/${g.total}) [${step.report?.mode ?? 'none'}]`);
    console.log(` GT  : ${gt.sections.map((s: any) => `${s.id}(${s.cat.slice(0, 4)},m${s.mark},q${s.qs.length})`).join(' ')}`);
    console.log(` GOT : ${parsed.sections.map((s: any) => `${s.rowId}(${String(s.majorCategory).slice(0, 4)},m${s.markTotal},q${s.questions.length})`).join(' ') || '(none)'}`);
    // first 3 issues for shape
    for (const i of g.issues.slice(0, 4)) console.log(`   - ${i.slice(0, 150)}`);
  }
}
main();
