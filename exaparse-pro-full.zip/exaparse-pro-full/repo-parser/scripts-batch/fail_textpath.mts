/**
 * fail_textpath.mts — compare brain-drive parse vs pure text-path parse
 * per GT'd file, so we know exactly which files the brain path is DRAGGING DOWN.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { buildBrainPreSplit } from '../src/utils/brainStep';
import type { BrainDoc } from '../src/utils/layoutBrain';
import { WS_ROOT, PKG_ROOT } from './wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-qu2');
const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-qu2');

process.env.EXAM_ORACLE = 'off';

function main() {
  const gtFiles = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  const rows: string[] = [];
  let driveBetter = 0, textBetter = 0, tie = 0;
  for (const gf of gtFiles) {
    const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, gf), 'utf8'));
    const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const text = fs.readFileSync(textPath, 'utf8');
    const brainPath = path.join(BRAIN_DIR, gt.file.replace(/\.pdf$/, '') + '.json');
    const brainDoc = fs.existsSync(brainPath) ? (JSON.parse(fs.readFileSync(brainPath, 'utf8')) as BrainDoc) : undefined;

    const step = buildBrainPreSplit(brainDoc, 'drive');
    const drive = parseExamRawText(text, gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true }, step.preSplit, step.source);
    const plain = parseExamRawText(text, gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
    const gd = gradeParse(drive, gt);
    const gp = gradeParse(plain, gt);
    const mode = step.report?.mode ?? 'none';
    if (gd.score > gp.score + 0.01) driveBetter++;
    else if (gp.score > gd.score + 0.01) textBetter++;
    else tie++;
    rows.push(`${gd.score >= 90 ? 'OK' : '!!'} ${gt.file}  drive=${gd.score.toFixed(1).padStart(7)} [${mode}]  text=${gp.score.toFixed(1).padStart(7)}  delta=${(gd.score - gp.score).toFixed(1)}`);
  }
  console.log(rows.join('\n'));
  console.log(`\ndrive better: ${driveBetter} | text better: ${textBetter} | tie: ${tie}`);
}
main();
