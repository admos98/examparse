/**
 * golden.mts — runner for the strict 30-exam golden grading phase of the
 * verify gate (cross-platform: no shell env-prefix syntax).
 *
 * Thin wrapper that PINS the corpus size: the regression line is "30/30 at
 * 100%", so a lost/renamed ground-truth file must fail the gate instead of
 * silently degrading to "29/29 at 100%". Directory defaults still derive
 * from wsPaths.mts inside grade.mts (GT_DIR/TEXT_DIR env-overridable).
 */
import { WS_ROOT } from './wsPaths.mts';

process.env.GT_DIR = process.env.GT_DIR ?? WS_ROOT + '/scratch/gt';
process.env.GT_MIN_FILES = '30';
await import('./grade.mts');
