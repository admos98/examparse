/**
 * Golden grader: compares parser output against hand-built ground truth.
 * 100% = every section rowId/order/category, every question number/type,
 * section marks, totals, header fields, and stem spot-checks all match.
 *
 * Grading semantics live in src/utils/goldenGrade.ts (shared with the rule
 * miner, so mined rules are judged by exactly the same yardstick).
 *
 * The mined-rules layer (Idea 1) is part of the graded surface: live rules
 * from data/mined-rules.json are applied to every parse before grading, so a
 * bad future rule import FAILS THIS GATE instead of passing silently.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse, GoldenGT } from '../src/utils/goldenGrade';
import { applyMinedRules, MinedRule } from '../src/utils/ruleMiner';
import { WS_ROOT, PKG_ROOT } from './wsPaths.mts';

const GT_DIR = process.env.GT_DIR ?? WS_ROOT + '/scratch/gt';
const TEXT_DIR = process.env.TEXT_DIR ?? WS_ROOT + '/scratch/texts';
// Package-owned data, resolved from the package root (NOT the process cwd) so
// the grader is correct from any working directory on any OS.
const MINED_RULES_PATH =
  process.env.MINED_RULES_PATH ?? path.join(PKG_ROOT, 'data', 'mined-rules.json');

function loadLiveMinedRules(): MinedRule[] {
  try {
    if (!fs.existsSync(MINED_RULES_PATH)) return [];
    const parsed = JSON.parse(fs.readFileSync(MINED_RULES_PATH, 'utf8'));
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((r) => r && r.status === 'live');
  } catch (e) {
    console.warn(`(mined rules unreadable at ${MINED_RULES_PATH} — continuing with none)`);
    return [];
  }
}

function gradeOne(gt: GoldenGT, liveRules: MinedRule[]): { score: number; issues: string[]; total: number } {
  const text = fs.readFileSync(path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt'), 'utf8');
  const parsed = parseExamRawText(text, gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  const doc = liveRules.length > 0 ? applyMinedRules(parsed, liveRules) : parsed;
  return gradeParse(doc, gt);
}

function main() {
  const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json'));
  // STRICT PIN (GT_MIN_FILES): the regression line is "30/30 + 20/20 at 100%"
  // — a corpus that silently SHRINKS (a lost/renamed GT file) used to slide
  // through as "19/19 at 100%". The runners pin the expected minimums;
  // ad-hoc runs with a custom GT_DIR stay un-pinned (min 0).
  const minFiles = Number(process.env.GT_MIN_FILES ?? 0);
  if (Number.isFinite(minFiles) && minFiles > 0 && files.length < minFiles) {
    console.error(`GRADER FAIL: GT corpus shrank — ${files.length} files in ${GT_DIR}, minimum ${minFiles}. A ground-truth file was lost or renamed; the ${minFiles}/${minFiles} line is not enforceable.`);
    process.exit(1);
  }
  if (minFiles > 0) console.log(`(strict pin: at least ${minFiles} GT files required — found ${files.length})`);
  const liveRules = loadLiveMinedRules();
  if (liveRules.length > 0) console.log(`(grading with ${liveRules.length} live mined rule(s) applied)`);
  let allIssues: string[] = [];
  let perfect = 0;
  let skipped = 0;
  for (const f of files) {
    const gt: GoldenGT = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
    if (!fs.existsSync(TEXT_DIR + '/' + gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt')) {
      console.log(`SKIP ${gt.file} (no text)`);
      skipped++;
      continue;
    }
    const { score, issues, total } = gradeOne(gt, liveRules);
    const icon = issues.length === 0 ? 'PASS' : 'FAIL';
    if (issues.length === 0) perfect++;
    console.log(`${icon} ${score.toFixed(1)}% (${total - issues.length}/${total}) ${gt.file}`);
    for (const i of issues.slice(0, 12)) console.log(`   - ${i}`);
    allIssues = allIssues.concat(issues);
  }
  console.log(`\n${perfect}/${files.length} files at 100%`);
  // Strict gate mode: a red grade, a skipped file, or an empty GT dir must FAIL
  // the calling chain (npm run verify). Silent passes are how fixes get dropped.
  if (files.length === 0) {
    console.error(`GRADER FAIL: no ground-truth files found in ${GT_DIR}`);
    process.exit(1);
  }
  if (allIssues.length > 0 || perfect !== files.length || skipped > 0) {
    console.error(`GRADER FAIL: ${perfect}/${files.length} at 100%, ${allIssues.length} issue(s), ${skipped} skipped`);
    process.exit(1);
  }
}

// Top-level await: import()-based runners (scripts-batch/mocks.mts) must see
// the grader COMPLETE (including its strict exit-1 on any FAIL/SKIP) before
// anything else runs.
await main();
