/**
 * mocks.mts — cross-platform runner for the 20-mock strict grading gate.
 *
 * Replaces the Unix-only npm script
 *   "CORPUS_DIR=../samples/mocks ... tsx scripts-batch/extract_all.mts && GT_DIR=... tsx scripts-batch/grade.mts"
 * whose `VAR=value` prefixes are NOT valid cmd.exe / PowerShell syntax —
 * `npm run mocks` (and therefore `npm run verify`) failed out-of-the-box on
 * Windows. Both phases now run IN-PROCESS with the exact same env contract:
 *
 *   phase 1  extract_all.mts   samples/mocks  -> scratch/texts-mocks (+ parsed JSON + summary)
 *   phase 2  grade.mts         scratch/gt-mocks vs scratch/texts-mocks (STRICT: any issue = exit 1)
 *
 * Every default still derives from wsPaths.mts (workspace root) and stays
 * env-overridable — this runner only supplies the mock-corpus overrides the
 * old shell prefix used to. A failing phase exits non-zero and fails the
 * calling `npm run verify` chain.
 */
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { PKG_ROOT, WS_ROOT } from './wsPaths.mts';

const HERE = path.dirname(fileURLToPath(import.meta.url));

// Keep the data dirs inside the bundle/workspace layout (same values the old
// npm script passed): repo-parser + ../samples + ../scratch side by side.
const CORPUS_DIR = path.join(WS_ROOT, 'samples', 'mocks');
const TEXTS = path.join(WS_ROOT, 'scratch', 'texts-mocks');
const PARSED = path.join(WS_ROOT, 'scratch', 'parsed-mocks');

// ---- phase 1: extract + parse the 20 mock exams ----
console.error('[mocks] phase 1: extract + parse (samples/mocks -> scratch/texts-mocks)');
process.env.CORPUS_DIR = CORPUS_DIR;
process.env.OUT_TXT = TEXTS;
process.env.OUT_JSON = PARSED;
process.env.SUMMARY_JSON = path.join(WS_ROOT, 'scratch', 'extract-mocks-summary.json');
await import('./extract_all.mts');

// ---- phase 2: strict-grade against the hand-built mock ground truth ----
console.error('[mocks] phase 2: strict grade (scratch/gt-mocks)');
process.env.GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-mocks');
process.env.TEXT_DIR = TEXTS;
// STRICT PIN: the regression line is "20/20 at 100%" — a lost GT file must
// fail the gate, never silently degrade the line to 19/19.
process.env.GT_MIN_FILES = '20';
// Mined rules live inside the package (data/mined-rules.json) — resolved from
// the package root, not the process cwd, so the gate works from any directory.
process.env.MINED_RULES_PATH = path.join(PKG_ROOT, 'data', 'mined-rules.json');
await import('./grade.mts');
