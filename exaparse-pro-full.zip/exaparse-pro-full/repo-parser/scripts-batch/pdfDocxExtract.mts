/** Node bridge: reuse the REAL fileExtractor docx path (incl. auto-numbering),
 * plus a pdfjs text-layer extraction identical to extractPdfDetailed Path A. */
import { getDocument } from 'pdfjs-dist/legacy/build/pdf.mjs';
import { normalizeOcrText } from '../src/utils/ocrPreprocessor';

export { extractTextFromDocx } from '../src/utils/fileExtractor';

export async function extractPdfTextDetailed(
  data: ArrayBuffer,
): Promise<{ text: string; chars: number; pages: number }> {
  const loadingTask = getDocument({ data: new Uint8Array(data), useSystemFonts: true });
  const pdf = await loadingTask.promise;
  const pageTexts: string[] = [];
  let totalTextChars = 0;

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    type PendingLine = { text: string; y: number };
    const pending: PendingLine[] = [];
    for (const item of content.items as any[]) {
      if (!('str' in item) || !item.str) continue;
      const yBase = item.transform[5];
      const last = pending[pending.length - 1];
      if (last && Math.abs(yBase - last.y) <= 6) {
        last.text += (last.text.endsWith(' ') ? '' : ' ') + item.str;
      } else {
        pending.push({ text: item.str, y: yBase });
      }
    }
    const joined = pending.map((pl) => pl.text.trim()).filter(Boolean).join('\n');
    if (joined) {
      pageTexts.push(joined);
      totalTextChars += joined.length;
    }
  }
  return {
    text: normalizeOcrText(pageTexts.join('\n\n')),
    chars: totalTextChars,
    pages: pdf.numPages,
  };
}
