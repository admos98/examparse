import fs from 'node:fs';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from './wsPaths.mts';
const text = fs.readFileSync(WS_ROOT + '/scratch/texts/11th_first.pdf.txt', 'utf8');
const doc = parseExamRawText(text, 't', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
console.log('HEADER:', JSON.stringify(doc.header).slice(0,140));
console.log('TOTAL:', doc.totalMarks, 'SECTIONS:', doc.sections.map(s => s.rowId+':'+s.markTotal).join(','));
for (const s of doc.sections) { console.log('SEC', s.rowId, '['+s.majorCategory+']', 'nq='+s.questions.length, s.questions.map(q=>q.number+' '+q.type.slice(0,4)).join(' | ').slice(0,100)); }
