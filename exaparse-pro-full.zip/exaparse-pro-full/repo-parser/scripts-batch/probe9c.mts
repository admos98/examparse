import fs from 'node:fs';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from './wsPaths.mts';
const text = fs.readFileSync(WS_ROOT + '/scratch/texts/انگلیسی_9_مستمر_چهار.docx.txt', 'utf8');
const doc = parseExamRawText(text, 'انگلیسی 9 مستمر چهار.docx', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
console.log('TOTAL:', doc.totalMarks);
for (const s of doc.sections) {
  console.log(`SEC ${s.rowId} [${s.majorCategory}] mark=${s.markTotal}`);
  for (const q of s.questions) console.log(`   q${q.number} ${q.type} :: ${(q.stem||'').slice(0,55).replace(/\n/g,' ')}`);
}
