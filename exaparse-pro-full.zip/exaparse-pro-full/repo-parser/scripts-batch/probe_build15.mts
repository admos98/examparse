import fs from 'node:fs';
import { runParsePipeline } from '../src/utils/parsePipeline';
import { WS_ROOT } from './wsPaths.mts';

const text = fs.readFileSync(WS_ROOT + '/scratch/texts/real_14050319.pdf.txt', 'utf8');
const res = runParsePipeline({ rawText: text, filename: '14050319px3c5v1338.pdf' });
if (!res.ok) {
  console.error('PARSE FAILED:', res.error);
  process.exit(1);
}
const doc = res.doc;
console.log('durationMinutes:', doc.header.durationMinutes);
console.log('totalQuestions:', doc.totalQuestions, 'totalMarks:', doc.totalMarks);
let flat = 0;
for (const s of doc.sections) {
  flat += s.questions.length;
  console.log(`\n== SEC ${s.rowId} [${s.majorCategory}] nq=${s.questions.length} wb=${JSON.stringify(s.wordBank)} ctx=${s.hasWordBank ? 'bank' : s.hasPassage ? 'passage' : '-'}${s.passageTitle ? ' ' + s.passageTitle : ''}`);
  console.log('   faInstr:', (s.persianInstruction || '').slice(0, 110));
  console.log('   enInstr:', (s.englishInstruction || '').slice(0, 90));
  for (const q of s.questions) {
    const stem = (q.stem || '').replace(/\n/g, ' | ').slice(0, 80);
    const opts = (q.options || []).map((o) => o.id + '=' + o.text.slice(0, 14)).join(';');
    console.log(`  q${q.number} [${q.type}] wbW=${JSON.stringify(q.wordBankWords)?.slice(0, 50) ?? '-'} pctx=${q.parentContextType ?? '-'} stem="${stem}"${opts ? ' opts=' + opts : ''}`);
  }
}
console.log('\nFLAT:', flat);
const inv = doc.invariants;
if (inv) {
  console.log('INVARIANTS: passed', inv.passed, '/', inv.total);
  for (const v of inv.violations) console.log(`  - ${v.rule} ${v.severity} ${v.sectionRowId ?? ''} ${v.questionId ?? ''}: ${v.message.slice(0, 90)}`);
}
