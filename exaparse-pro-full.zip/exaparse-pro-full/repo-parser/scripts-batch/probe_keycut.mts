/** probe_keycut.mts — where does findKeySheetBoundary cut each file? */
import fs from 'node:fs';
import path from 'node:path';
import { findKeySheetBoundary } from '../src/utils/parserEngine';
import { WS_ROOT } from './wsPaths.mts';

const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
for (const f of process.argv.slice(2)) {
  const text = fs.readFileSync(path.join(TEXT_DIR, f), 'utf8');
  const cut = findKeySheetBoundary(text);
  console.log(`\n=== ${f}  cut=${cut} (${(100 * cut / text.length).toFixed(0)}%)`);
  if (cut >= 0) {
    const before = text.slice(0, cut).split(/\r?\n/).slice(-2);
    const after = text.slice(cut).split(/\r?\n/).slice(0, 3);
    console.log('  ...before:', JSON.stringify(before));
    console.log('  after   :', JSON.stringify(after));
  }
}
