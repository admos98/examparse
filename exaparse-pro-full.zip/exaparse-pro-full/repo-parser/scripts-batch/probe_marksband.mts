/** probe_marksband.mts — why does splitMarksTableSections bail on band files? */
import fs from 'node:fs';
import path from 'node:path';
import { splitMarksTableSections, splitRadifNumberedSections, splitKanoonRowSections, splitRuleRuledSections } from '../src/utils/parserEngine';
import { WS_ROOT } from './wsPaths.mts';

const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
for (const f of process.argv.slice(2)) {
  const text = fs.readFileSync(path.join(TEXT_DIR, f), 'utf8');
  const head = text.split(/\r?\n/).slice(0, 15).map((l) => l.trim());
  console.log(`\n=== ${f}`);
  console.log('head lines:', JSON.stringify(head.filter((l) => l).slice(0, 12)));
  console.log('marks-table:', splitMarksTableSections(text)?.length ?? 'NULL');
  console.log('radif:', splitRadifNumberedSections(text)?.length ?? 'NULL');
  console.log('kanoon:', splitKanoonRowSections(text)?.length ?? 'NULL');
  console.log('rule-ruled:', splitRuleRuledSections(text)?.length ?? 'NULL');
}
