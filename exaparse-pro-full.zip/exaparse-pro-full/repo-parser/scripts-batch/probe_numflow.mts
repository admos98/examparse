/** probe_numflow.mts — prototype: question-number flow runs vs radif blocks.
 *  A run = maximal sequence of question numbers where each next > current.
 *  If runs == blocks and some block holds a drop inside, a retile to runs
 *  reconstructs the true rows. */
import fs from 'node:fs';
import path from 'node:path';
import { splitRadifNumberedSections } from '../src/utils/parserEngine';
import { canonicalize } from '../src/utils/textCanonical';
import { normalizeOcrText } from '../src/utils/ocrPreprocessor';
import { WS_ROOT } from './wsPaths.mts';

const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');

interface Qtok { line: number; n: number }
function scanQuestionFlow(text: string): Qtok[] {
  const toks: Qtok[] = [];
  const lines = text.split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const t = lines[i].trim();
    if (!t) continue;
    // line-start numbered question: "12. text" / "13) text" / "5 - text"
    let m = t.match(/^(\d{1,3})\s*[.)\/\-–—]\s*(?=[^\d\s])(.*)$/);
    if (m) { toks.push({ line: i, n: parseInt(m[1], 10) }); continue; }
    // inline paren-number blank slot: "(12)………" — number + blank marker right after
    const inline = t.match(/\((\d{1,3})\)\s*(?:\.{2,}|…+|_{2,}|-{3,}|—{2,})/);
    if (inline) toks.push({ line: i, n: parseInt(inline[1], 10) });
  }
  return toks;
}

for (const f of process.argv.slice(2)) {
  const raw = fs.readFileSync(path.join(TEXT_DIR, f), 'utf8');
  const norm = normalizeOcrText(canonicalize(raw).text);
  const blocks = splitRadifNumberedSections(norm);
  const toks = scanQuestionFlow(norm);
  // build runs
  const runs: Qtok[][] = [];
  for (const tk of toks) {
    const cur = runs[runs.length - 1];
    if (!cur || tk.n <= cur[cur.length - 1].n) runs.push([tk]);
    else cur.push(tk);
  }
  console.log(`\n=== ${f}: blocks=${blocks ? blocks.length : 'NULL'} toks=${toks.length} runs=${runs.length}`);
  console.log('runs:', runs.map((r) => `${r[0].n}-${r[r.length - 1].n}@L${r[0].line}`).join(' '));
  if (blocks) {
    const lineOf = (b: typeof blocks[number]) => norm.slice(0, b.startIndex).split('\n').length - 1;
    console.log('blocks:', blocks.map((b) => `${b.rowId}@L${lineOf(b)}`).join(' '));
  }
}
