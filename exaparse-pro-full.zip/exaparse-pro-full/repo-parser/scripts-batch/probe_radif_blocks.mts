/** probe_radif_blocks.mts — dump radif blocks (rowId, mark, question numbers)
 *  for a file, alongside the standalone-number lines, to expose rung/mark
 *  confusion. */
import fs from 'node:fs';
import path from 'node:path';
import { splitRadifNumberedSections } from '../src/utils/parserEngine';
import { canonicalize } from '../src/utils/textCanonical';
import { normalizeOcrText } from '../src/utils/ocrPreprocessor';
import { WS_ROOT } from './wsPaths.mts';

const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
for (const f of process.argv.slice(2)) {
  const raw = fs.readFileSync(path.join(TEXT_DIR, f), 'utf8');
  const norm = normalizeOcrText(canonicalize(raw).text);
  const blocks = splitRadifNumberedSections(norm);
  console.log(`\n=== ${f}: ${blocks ? blocks.length : 'NULL'} radif blocks`);
  if (!blocks) continue;
  const lines = norm.split(/\r?\n/);
  for (const b of blocks) {
    const startLine = norm.slice(0, b.startIndex).split('\n').length - 1;
    const qNums = (b.text.match(/(?:^|\n)\s*(\d{1,3})\s*[.)\/]\s*(?=[^\d\s])/g) || [])
      .map((m) => m.replace(/[^0-9]/g, '')).slice(0, 12).join(',');
    const head = b.text.split(/\r?\n/).filter((l) => l.trim()).slice(0, 2).map((l) => l.slice(0, 40));
    console.log(`  ${b.rowId}@L${startLine} m=${b.mark} cat=${b.category} qs=[${qNums}] | ${head.join(' / ')}`);
  }
  // standalone number lines map
  const nums: string[] = [];
  lines.forEach((l, i) => {
    if (/^\.?\d{1,2}(?:\s*\/\s*\d{1,2})?(?:[.,]\d{1,2})?$/.test(l.trim())) nums.push(`${i}:${l.trim()}`);
  });
  console.log('standalone numbers:', nums.join(' '));
}
