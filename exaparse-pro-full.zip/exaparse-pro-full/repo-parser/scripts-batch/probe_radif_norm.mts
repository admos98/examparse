/** probe_radif_norm.mts — why does splitRadifNumberedSections bail on the
 *  ENGINE's normalized text while firing on the raw file text? */
import fs from 'node:fs';
import path from 'node:path';
import { splitRadifNumberedSections, findKeySheetBoundary } from '../src/utils/parserEngine';
import { canonicalize } from '../src/utils/textCanonical';
import { normalizeOcrText } from '../src/utils/ocrPreprocessor';
import { WS_ROOT } from './wsPaths.mts';

const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
for (const f of process.argv.slice(2)) {
  const raw = fs.readFileSync(path.join(TEXT_DIR, f), 'utf8');
  const canon = canonicalize(raw).text;
  const norm = normalizeOcrText(canon);
  const keyCut = findKeySheetBoundary(norm);
  const scan = keyCut >= 0 ? norm.slice(0, keyCut) : norm;
  console.log(`\n=== ${f}`);
  console.log('raw:', splitRadifNumberedSections(raw)?.length ?? 'NULL',
    '| canon:', splitRadifNumberedSections(canon)?.length ?? 'NULL',
    '| norm:', splitRadifNumberedSections(norm)?.length ?? 'NULL',
    '| scan(keyCut=' + keyCut + '):', splitRadifNumberedSections(scan)?.length ?? 'NULL');
}
