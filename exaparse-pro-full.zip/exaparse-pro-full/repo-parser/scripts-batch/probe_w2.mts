/**
 * probe_w2.mts — diagnostic: does the W2 event head learn AT ALL?
 *
 * Trains briefly on the real seqs, then dumps full event softmax rows at
 * known event positions of TRAINING windows (overfit check) + evalModel
 * on a slice. Disambiguates "model can't separate" vs "eval broken".
 */
import fs from 'node:fs';
import path from 'node:path';
import { Model, forward, N_EV, N_SUBJ, CTX, STRIDE, EV_NAMES } from './structure_model.mts';
import { backward, allocBwd } from './structure_backward.mts';
import { extractGeom, bodySizeOf, geomSummaryToken, normText } from '../src/utils/codecFeatures';
import { classifyTables, type BrainDoc } from '../src/utils/layoutBrain';
import { WS_ROOT, PKG_ROOT } from './wsPaths.mts';

const DATA = path.join(WS_ROOT, 'scratch', 'w1w2', 'labeled.json');

interface LabeledFile {
  file: string; fold: number; keyIdx: number; printedTotal: number | null;
  lines: { x: number[]; s: number; b: number; t: string; pg: number }[];
  roles: number[]; subj: number[]; instr: number[];
  markVal: (number | null)[]; events: number[];
}
interface Seq {
  file: string; fold: number;
  role: Int32Array; subj: Int32Array; instr: Int32Array; geom: Int32Array; ev: Int32Array; len: number;
}

function hashG(tok: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < tok.length; i++) { h ^= tok.charCodeAt(i); h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0; }
  return h % 64;
}

function loadSeqs(): Seq[] {
  const data = JSON.parse(fs.readFileSync(DATA, 'utf8')) as { files: LabeledFile[] };
  const seqs: Seq[] = [];
  for (const f of data.files) {
    const doc = JSON.parse(fs.readFileSync(path.join(PKG_ROOT, 'scratch', 'brain-qu2', f.file.replace(/\.pdf$/, '') + '.json'), 'utf8')) as BrainDoc;
    const cls = classifyTables(doc);
    const body = bodySizeOf(cls);
    const n = f.lines.length;
    const role = new Int32Array(n), subj = new Int32Array(n), instr = new Int32Array(n), geom = new Int32Array(n);
    for (let i = 0; i < n; i++) {
      const L = f.lines[i];
      const g = extractGeom(cls, { text: L.t, size: L.s, bold: !!L.b, bbox: L.x, page: L.pg }, body, n > 1 ? i / (n - 1) : 0);
      role[i] = f.roles[i]; subj[i] = f.subj[i]; instr[i] = f.instr[i];
      geom[i] = hashG(geomSummaryToken(g, normText(L.t)));
    }
    seqs.push({ file: f.file, fold: f.fold, role, subj, instr, geom, ev: Int32Array.from(f.events), len: n });
  }
  return seqs;
}

let lcg = 12345;
const rnd = () => { lcg = (lcg * 1103515245 + 12345) & 0x7fffffff; return lcg / 0x7fffffff; };

function main() {
  const seqs = loadSeqs();
  console.log(`loaded ${seqs.length} seqs`);

  // event distribution per ROLE — is the mapping role->event learnable?
  const roleEv = new Map<number, Map<number, number>>();
  let tot = 0;
  for (const s of seqs) for (let i = 0; i < s.len; i++) {
    tot++;
    const r = s.role[i], e = s.ev[i];
    if (!roleEv.has(r)) roleEv.set(r, new Map());
    const m = roleEv.get(r)!;
    m.set(e, (m.get(e) ?? 0) + 1);
  }
  console.log(`\nevent distribution conditioned on codec-role label (n=${tot}):`);
  const roles = [...roleEv.keys()].sort((a, b) => b - a);
  for (const r of roles) {
    const m = roleEv.get(r)!;
    const parts = [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 4).map(([e, c]) => `${EV_NAMES[e]}:${c}`);
    console.log(`  role ${String(r).padStart(2)}: ${parts.join(' ')}`);
  }

  // class weights (clipped, same as trainer)
  const cnt = new Array(N_EV).fill(0);
  for (const s of seqs) for (let i = 0; i < s.len; i++) cnt[s.ev[i]]++;
  const wRaw = cnt.map((c) => 1 / Math.sqrt(Math.max(1, c)));
  const mean = wRaw.reduce((a, b) => a + b, 0) / N_EV;
  const classW = Float32Array.from(wRaw.map((v) => Math.min(4, Math.max(0.25, v / mean))));
  console.log('\nclassW:', EV_NAMES.map((e, k) => `${e}:${classW[k].toFixed(2)}`).join(' '));

  // event-bearing windows
  const evWins: { si: number; start: number; len: number }[] = [];
  for (let si = 0; si < seqs.length; si++) {
    const s = seqs[si];
    for (let start = 0; start < s.len; start += STRIDE) {
      const len = Math.min(CTX, s.len - start);
      if (start + len < s.len && len < 16) continue;
      let has = false;
      for (let i = start; i < start + len && !has; i++) if (s.ev[i] !== 0) has = true;
      if (has) evWins.push({ si, start, len });
    }
  }
  console.log(`event windows: ${evWins.length}`);

  const M = new Model(false);
  const pool = new Map<number, { c: ReturnType<typeof forward>['cache']; w: ReturnType<typeof allocBwd> }>();
  const getWs = (len: number) => {
    let e = pool.get(len);
    if (!e) {
      const c0 = forward(M, { role: new Int32Array(len), subj: new Int32Array(len), instr: new Int32Array(len), geom: new Int32Array(len) }).cache;
      e = { c: c0, w: allocBwd(c0) };
      pool.set(len, e);
    }
    return e;
  };

  // capture one fixed event window for the overfit probe
  const probeWin = evWins[Math.floor(evWins.length * 0.37)];
  const probeSeq = seqs[probeWin.si];
  const probeInp = {
    role: probeSeq.role.subarray(probeWin.start, probeWin.start + probeWin.len),
    subj: probeSeq.subj.subarray(probeWin.start, probeWin.start + probeWin.len),
    instr: probeSeq.instr.subarray(probeWin.start, probeWin.start + probeWin.len),
    geom: probeSeq.geom.subarray(probeWin.start, probeWin.start + probeWin.len),
    ev: probeSeq.ev.subarray(probeWin.start, probeWin.start + probeWin.len),
  };
  const evPositions: number[] = [];
  for (let i = 0; i < probeWin.len; i++) if (probeSeq.ev[probeWin.start + i] !== 0) evPositions.push(i);

  const probsAt = () => {
    const { cache } = forward(M, probeInp);
    for (const i of evPositions.slice(0, 6)) {
      const t = probeSeq.ev[probeWin.start + i];
      const off = i * N_EV;
      const ps: string[] = [];
      for (let k = 0; k < N_EV; k++) {
        // softmax row
        let mx = -Infinity;
        for (let j = 0; j < N_EV; j++) mx = Math.max(mx, cache.logitsE[off + j]);
        let s = 0;
        for (let j = 0; j < N_EV; j++) s += Math.exp(cache.logitsE[off + j] - mx);
        ps.push(`${EV_NAMES[k]}=${(Math.exp(cache.logitsE[off + k] - mx) / s).toFixed(3)}`);
      }
      console.log(`    pos ${i} true=${EV_NAMES[t].padEnd(5)} ${ps.join(' ')}`);
    }
  };

  console.log(`\nprobe window: ${probeSeq.file} [${probeWin.start}..${probeWin.start + probeWin.len}) events at ${evPositions.join(',')}`);
  console.log('BEFORE training:'); probsAt();

  // train ONLY on this one window (pure overfit test) — with per-window
  // CONT-mass rebalancing (same as the trainer)
  let rareMass = 0, nCont = 0;
  for (let i = 0; i < probeWin.len; i++) {
    const e = probeSeq.ev[probeWin.start + i];
    if (e === 0) nCont++; else rareMass += classW[e];
  }
  const eff = Float32Array.from(classW);
  if (rareMass > 0 && nCont > 0) eff[0] = Math.min(classW[0], (2 * rareMass) / nCont);
  console.log(`effW CONT=${eff[0].toFixed(3)} (rareMass=${rareMass.toFixed(2)}, nCont=${nCont})`);
  const ws1 = getWs(probeWin.len);
  for (let it = 0; it < 60; it++) {
    for (const t of M.all) t.zeroGrad();
    forward(M, { ...probeInp, classW: eff, subjW: 0.5 }, ws1.c);
    backward(M, { ...probeInp, classW: eff, subjW: 0.5 }, ws1.c, ws1.w);
    for (const t of M.all) t.adamStep(3e-3, it + 1);
    if (it % 20 === 0) console.log(`  single-window step ${it}: loss=${forward(M, { ...probeInp, classW: eff, subjW: 0.5 }).loss.toFixed(4)}`);
  }
  console.log('AFTER 60 steps on the SINGLE window (overfit check):'); probsAt();

  // now train normally on event windows for 300 steps and watch loss
  let step = 0;
  for (let it = 0; it < 300; it++) {
    for (const t of M.all) t.zeroGrad();
    let loss = 0;
    for (let b = 0; b < 4; b++) {
      const w = evWins[Math.floor(rnd() * evWins.length)];
      const s = seqs[w.si];
      const inp = {
        role: s.role.subarray(w.start, w.start + w.len),
        subj: s.subj.subarray(w.start, w.start + w.len),
        instr: s.instr.subarray(w.start, w.start + w.len),
        geom: s.geom.subarray(w.start, w.start + w.len),
        ev: s.ev.subarray(w.start, w.start + w.len),
      };
      const ws = getWs(w.len);
      let rm = 0, nc = 0;
      for (let i = 0; i < w.len; i++) { const e = s.ev[w.start + i]; if (e === 0) nc++; else rm += classW[e]; }
      const eff2 = Float32Array.from(classW);
      if (rm > 0 && nc > 0) eff2[0] = Math.min(classW[0], (2 * rm) / nc);
      const r = forward(M, { ...inp, classW: eff2, subjW: 0.5 }, ws.c);
      loss += r.loss;
      backward(M, { ...inp, classW: eff2, subjW: 0.5 }, ws.c, ws.w);
    }
    step++;
    for (const t of M.all) t.adamStep(3e-3, step);
    if (it % 100 === 0) console.log(`event-window-only step ${it}: loss=${(loss / 4).toFixed(4)}`);
  }
  console.log('AFTER 300 event-window steps:'); probsAt();

  void N_SUBJ;
}
main();
