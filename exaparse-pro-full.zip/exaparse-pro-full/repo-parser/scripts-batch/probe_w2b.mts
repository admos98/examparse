/**
 * probe_w2b.mts — rebuild the checkpointed CV model from w2-state.json and
 * compare, on the SAME positions: (a) the trainer's pooled-cache eval path,
 * (b) a fresh forward per window. If (a) says CONT and (b) says otherwise,
 * the eval path is buggy; if both say CONT on TRAIN data too, the model is
 * genuinely collapsed.
 */
import fs from 'node:fs';
import path from 'node:path';
import { Model, forward, N_EV, CTX, EV_NAMES } from './structure_model.mts';
import { extractGeom, bodySizeOf, geomSummaryToken, normText } from '../src/utils/codecFeatures';
import { classifyTables, type BrainDoc } from '../src/utils/layoutBrain';
import { WS_ROOT, PKG_ROOT } from './wsPaths.mts';

const DATA = path.join(WS_ROOT, 'scratch', 'w1w2', 'labeled.json');
const STATE = path.join(WS_ROOT, 'scratch', 'w1w2', 'w2-state.json');

interface LabeledFile {
  file: string; fold: number; keyIdx: number; printedTotal: number | null;
  lines: { x: number[]; s: number; b: number; t: string; pg: number }[];
  roles: number[]; subj: number[]; instr: number[];
  markVal: (number | null)[]; events: number[];
}
interface Seq {
  file: string; fold: number;
  role: Int32Array; subj: Int32Array; instr: Int32Array; geom: Int32Array; ev: Int32Array; len: number;
}

function hashG(tok: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < tok.length; i++) { h ^= tok.charCodeAt(i); h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0; }
  return h % 64;
}

function loadSeqs(): Seq[] {
  const data = JSON.parse(fs.readFileSync(DATA, 'utf8')) as { files: LabeledFile[] };
  const seqs: Seq[] = [];
  for (const f of data.files) {
    const doc = JSON.parse(fs.readFileSync(path.join(PKG_ROOT, 'scratch', 'brain-qu2', f.file.replace(/\.pdf$/, '') + '.json'), 'utf8')) as BrainDoc;
    const cls = classifyTables(doc);
    const body = bodySizeOf(cls);
    const n = f.lines.length;
    const role = new Int32Array(n), subj = new Int32Array(n), instr = new Int32Array(n), geom = new Int32Array(n);
    for (let i = 0; i < n; i++) {
      const L = f.lines[i];
      const g = extractGeom(cls, { text: L.t, size: L.s, bold: !!L.b, bbox: L.x, page: L.pg }, body, n > 1 ? i / (n - 1) : 0);
      role[i] = f.roles[i]; subj[i] = f.subj[i]; instr[i] = f.instr[i];
      geom[i] = hashG(geomSummaryToken(g, normText(L.t)));
    }
    seqs.push({ file: f.file, fold: f.fold, role, subj, instr, geom, ev: Int32Array.from(f.events), len: n });
  }
  return seqs;
}

function softmaxRow(logits: Float32Array, off: number): number[] {
  let mx = -Infinity;
  for (let k = 0; k < N_EV; k++) mx = Math.max(mx, logits[off + k]);
  let s = 0;
  const p: number[] = [];
  for (let k = 0; k < N_EV; k++) { const e = Math.exp(logits[off + k] - mx); p.push(e); s += e; }
  return p.map((e) => e / s);
}

function main() {
  // rebuild model from state
  const state = JSON.parse(fs.readFileSync(STATE, 'utf8')) as {
    tensors: Record<string, { p: string; m: string; v: string }> | null;
  };
  if (!state.tensors) { console.error('no tensors in state'); process.exit(1); }
  const M = new Model(false);
  for (const t of M.all) {
    const b = state.tensors[t.name];
    if (!b) { console.error(`missing tensor ${t.name}`); process.exit(1); }
    t.p.set(new Float32Array(Buffer.from(b.p, 'base64').buffer, 0, t.p.length));
  }
  console.log('model rebuilt from state tensors');

  const seqs = loadSeqs();
  // cv5 was training when checkpointed -> its held-out fold is 5; train fold sample: 0
  const held = seqs.filter((s) => s.fold === 5);
  const train = seqs.filter((s) => s.fold === 0);
  console.log(`held-out fold5 docs: ${held.length}, train fold0 docs: ${train.length}`);

  const scan = (label: string, group: Seq[]) => {
    let nonCont = 0, tot = 0, evHit = 0, evTot = 0;
    for (const s of group) {
      // pooled path (identical to trainer eval)
      const acc = new Float32Array(s.len * N_EV);
      const cov = new Int32Array(s.len);
      for (let start = 0; start < s.len; start += CTX) {
        const len = Math.min(CTX, s.len - start);
        if (len < 4 && start > 0) break;
        const inp = {
          role: s.role.subarray(start, start + len),
          subj: s.subj.subarray(start, start + len),
          instr: s.instr.subarray(start, start + len),
          geom: s.geom.subarray(start, start + len),
        };
        const { cache } = forward(M, inp); // FRESH forward, no reuse
        for (let i = 0; i < len; i++) {
          const p = start + i;
          if (cov[p] > 0) continue;
          cov[p] = 1;
          const ps = softmaxRow(cache.logitsE, i * N_EV);
          for (let k = 0; k < N_EV; k++) acc[p * N_EV + k] = ps[k];
        }
      }
      for (let i = 0; i < s.len; i++) {
        let bi = 0;
        for (let k = 1; k < N_EV; k++) if (acc[i * N_EV + k] > acc[i * N_EV + bi]) bi = k;
        tot++;
        if (bi !== 0) nonCont++;
        if (s.ev[i] !== 0) { evTot++; if (bi === s.ev[i]) evHit++; }
      }
    }
    console.log(`${label}: positions=${tot} nonCONT-argmax=${nonCont}  event-recall=${evHit}/${evTot}`);
  };

  scan('HELD-OUT fold5 (fresh fwd)', held);
  scan('TRAIN fold0 (fresh fwd)', train);

  // detailed dump on one held-out doc with events
  const s = held.find((x) => x.ev.some((e) => e !== 0))!;
  console.log(`\ndetail: ${s.file} (${s.len} lines)`);
  let shown = 0;
  for (let start = 0; start < s.len && shown < 8; start += CTX) {
    const len = Math.min(CTX, s.len - start);
    const inp = {
      role: s.role.subarray(start, start + len),
      subj: s.subj.subarray(start, start + len),
      instr: s.instr.subarray(start, start + len),
      geom: s.geom.subarray(start, start + len),
    };
    const { cache } = forward(M, inp);
    for (let i = 0; i < len && shown < 8; i++) {
      const p = start + i;
      if (s.ev[p] === 0) continue;
      const ps = softmaxRow(cache.logitsE, i * N_EV);
      const top = ps.map((v, k) => `${EV_NAMES[k]}=${v.toFixed(3)}`).join(' ');
      console.log(`  pos ${p} true=${EV_NAMES[s.ev[p]].padEnd(5)} role=${s.role[p]} -> ${top}`);
      shown++;
    }
  }
}
main();
