/**
 * probe_w2c.mts — the minimal learnability test.
 *
 * Stage A: NO transformer. logits[t] = We^T x[t] + be, where
 *          x[t] = Er[role]+Es[subj]+Ei[instr]+Eg[geom] (random frozen).
 *          Trains We/be ONLY, with the trainer's rebalanced weighted CE.
 *          If THIS cannot reach high event-recall in 700 steps, the
 *          loss/backward plumbing is broken. If it can, the transformer
 *          stage is what breaks learning.
 *
 * Stage B: same but embeddings also train (still no attention).
 */
import fs from 'node:fs';
import path from 'node:path';
import { Model, forward, N_EV, EV_NAMES, D } from './structure_model.mts';
import { WS_ROOT, PKG_ROOT } from './wsPaths.mts';
import { extractGeom, bodySizeOf, geomSummaryToken, normText } from '../src/utils/codecFeatures';
import { classifyTables, type BrainDoc } from '../src/utils/layoutBrain';

const DATA = path.join(WS_ROOT, 'scratch', 'w1w2', 'labeled.json');

interface LabeledFile {
  file: string; fold: number; keyIdx: number; printedTotal: number | null;
  lines: { x: number[]; s: number; b: number; t: string; pg: number }[];
  roles: number[]; subj: number[]; instr: number[];
  markVal: (number | null)[]; events: number[];
}
interface Seq { role: Int32Array; subj: Int32Array; instr: Int32Array; geom: Int32Array; ev: Int32Array; len: number }

function hashG(tok: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < tok.length; i++) { h ^= tok.charCodeAt(i); h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0; }
  return h % 64;
}

function loadSeqs(): Seq[] {
  const data = JSON.parse(fs.readFileSync(DATA, 'utf8')) as { files: LabeledFile[] };
  const seqs: Seq[] = [];
  for (const f of data.files) {
    const doc = JSON.parse(fs.readFileSync(path.join(PKG_ROOT, 'scratch', 'brain-qu2', f.file.replace(/\.pdf$/, '') + '.json'), 'utf8')) as BrainDoc;
    const cls = classifyTables(doc);
    const body = bodySizeOf(cls);
    const n = f.lines.length;
    const role = new Int32Array(n), subj = new Int32Array(n), instr = new Int32Array(n), geom = new Int32Array(n);
    for (let i = 0; i < n; i++) {
      const L = f.lines[i];
      const g = extractGeom(cls, { text: L.t, size: L.s, bold: !!L.b, bbox: L.x, page: L.pg }, body, n > 1 ? i / (n - 1) : 0);
      role[i] = f.roles[i]; subj[i] = f.subj[i]; instr[i] = f.instr[i];
      geom[i] = hashG(geomSummaryToken(g, normText(L.t)));
    }
    seqs.push({ role, subj, instr, geom, ev: Int32Array.from(f.events), len: n });
  }
  return seqs;
}

// ---- minimal softmax regression over frozen random embeddings
class Mini {
  E = new Float32Array((12 + 9 + 10 + 64) * D); // frozen random embeddings
  We = new Float32Array(D * N_EV);
  be = new Float32Array(N_EV);
  gWe = new Float32Array(D * N_EV);
  gbe = new Float32Array(N_EV);
  mWe = new Float32Array(D * N_EV); vWe = new Float32Array(D * N_EV);
  mbe = new Float32Array(N_EV); vbe = new Float32Array(N_EV);
  constructor() {
    let s = 99;
    const rnd = () => { s = (s * 1103515245 + 12345) & 0x7fffffff; return s / 0x7fffffff; };
    for (let i = 0; i < this.E.length; i++) this.E[i] = (rnd() * 2 - 1) * 0.3;
    for (let i = 0; i < this.We.length; i++) this.We[i] = (rnd() * 2 - 1) * 0.25;
  }
  logitsOf(x: Float32Array, out: Float32Array): void {
    for (let k = 0; k < N_EV; k++) out[k] = this.be[k];
    for (let i = 0; i < D; i++) {
      const v = x[i];
      if (v === 0) continue;
      const o = i * N_EV;
      for (let k = 0; k < N_EV; k++) out[k] += v * this.We[o + k];
    }
  }
}

function main() {
  const seqs = loadSeqs();
  const M = new Mini();
  // class weights (clipped) + window machinery, same as trainer
  const cnt = new Array(N_EV).fill(0);
  for (const s of seqs) for (let i = 0; i < s.len; i++) cnt[s.ev[i]]++;
  const wRaw = cnt.map((c) => 1 / Math.sqrt(Math.max(1, c)));
  const mean = wRaw.reduce((a, b) => a + b, 0) / N_EV;
  const classW = wRaw.map((v) => Math.min(4, Math.max(0.25, v / mean)));

  // event windows
  const CTX = 72, STRIDE = 36;
  const evWins: { si: number; start: number; len: number }[] = [];
  for (let si = 0; si < seqs.length; si++) {
    const s = seqs[si];
    for (let start = 0; start < s.len; start += STRIDE) {
      const len = Math.min(CTX, s.len - start);
      if (start + len < s.len && len < 16) continue;
      let has = false;
      for (let i = start; i < start + len && !has; i++) if (s.ev[i] !== 0) has = true;
      if (has) evWins.push({ si, start, len });
    }
  }
  let lcg = 4242;
  const rnd = () => { lcg = (lcg * 1103515245 + 12345) & 0x7fffffff; return lcg / 0x7fffffff; };

  const x = new Float32Array(D);
  const z = new Float32Array(N_EV);
  const embed = (s: Seq, pos: number) => {
    x.fill(0);
    const ro = s.role[pos] * D, so = (12 + s.subj[pos]) * D, io = (21 + s.instr[pos]) * D, go = (31 + s.geom[pos]) * D;
    for (let k = 0; k < D; k++) x[k] = M.E[ro + k] + M.E[so + k] + M.E[io + k] + M.E[go + k];
  };

  // train
  for (let it = 0; it < 700; it++) {
    M.gWe.fill(0); M.gbe.fill(0);
    let loss = 0;
    for (let b = 0; b < 4; b++) {
      const w = evWins[Math.floor(rnd() * evWins.length)];
      const s = seqs[w.si];
      // rebalance CONT
      let rareMass = 0, nCont = 0;
      for (let i = w.start; i < w.start + w.len; i++) { const e = s.ev[i]; if (e === 0) nCont++; else rareMass += classW[e]; }
      let w0 = classW[0];
      if (rareMass > 0 && nCont > 0) w0 = Math.min(classW[0], (2 * rareMass) / nCont);
      let wSum = nCont * w0 + rareMass;
      for (let i = w.start; i < w.start + w.len; i++) {
        const e = s.ev[i];
        embed(s, i);
        M.logitsOf(x, z);
        let mx = -Infinity;
        for (let k = 0; k < N_EV; k++) mx = Math.max(mx, z[k]);
        let sum = 0;
        for (let k = 0; k < N_EV; k++) sum += Math.exp(z[k] - mx);
        const wt = e === 0 ? w0 : classW[e];
        loss += wt * -Math.log(Math.max(1e-12, Math.exp(z[e] - mx) / sum));
        // grads
        const gscale = (wt / (wSum > 0 ? wSum : 1));
        for (let k = 0; k < N_EV; k++) {
          const p = Math.exp(z[k] - mx) / sum;
          const g = gscale * (p - (k === e ? 1 : 0));
          M.gbe[k] += g;
          for (let d2 = 0; d2 < D; d2++) M.gWe[d2 * N_EV + k] += g * x[d2];
        }
      }
    }
    // adam
    const b1 = 0.9, b2 = 0.999, eps = 1e-8, lr = 3e-3;
    for (let i = 0; i < M.We.length; i++) {
      M.mWe[i] = b1 * M.mWe[i] + (1 - b1) * M.gWe[i];
      M.vWe[i] = b2 * M.vWe[i] + (1 - b2) * M.gWe[i] * M.gWe[i];
      const c1 = 1 - Math.pow(b1, it + 1), c2 = 1 - Math.pow(b2, it + 1);
      M.We[i] -= (lr * (M.mWe[i] / c1)) / (Math.sqrt(M.vWe[i] / c2) + eps);
    }
    for (let k = 0; k < N_EV; k++) {
      M.mbe[k] = b1 * M.mbe[k] + (1 - b1) * M.gbe[k];
      M.vbe[k] = b2 * M.vbe[k] + (1 - b2) * M.gbe[k] * M.gbe[k];
      const c1 = 1 - Math.pow(b1, it + 1), c2 = 1 - Math.pow(b2, it + 1);
      M.be[k] -= (lr * (M.mbe[k] / c1)) / (Math.sqrt(M.vbe[k] / c2) + eps);
    }
    if (it % 100 === 0) console.log(`step ${it}: loss=${(loss / 4).toFixed(4)}`);
  }

  // eval: argmax over ALL positions
  const hit = new Array(N_EV).fill(0), n = new Array(N_EV).fill(0);
  let ok = 0, tot = 0;
  for (const s of seqs) {
    for (let i = 0; i < s.len; i++) {
      embed(s, i);
      M.logitsOf(x, z);
      let bi = 0;
      for (let k = 1; k < N_EV; k++) if (z[k] > z[bi]) bi = k;
      tot++; if (bi === s.ev[i]) ok++;
      n[s.ev[i]]++; if (bi === s.ev[i]) hit[s.ev[i]]++;
    }
  }
  console.log(`\nMINI (frozen embeddings, head only): acc ${(100 * ok / tot).toFixed(1)}%`);
  for (let k = 0; k < N_EV; k++) console.log(`  ${EV_NAMES[k].padEnd(5)} recall ${hit[k]}/${n[k]}`);
  void forward;
}
main();
