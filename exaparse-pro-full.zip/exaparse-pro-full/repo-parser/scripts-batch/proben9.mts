import fs from 'node:fs';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from './wsPaths.mts';
const text = fs.readFileSync(WS_ROOT + '/scratch/texts/نهم_مستمر.pdf.txt', 'utf8');
const doc = parseExamRawText(text, 't', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
console.log('HEADER:', JSON.stringify(doc.header));
console.log('TOTAL:', doc.totalMarks, 'SECTIONS:', doc.sections.map(s => s.rowId).join(','));
for (const s of doc.sections) {
  console.log(`SEC ${s.rowId} [${s.majorCategory}] mark=${s.markTotal} bank=${s.wordBank?.length||0}`);
  for (const q of s.questions) console.log(`   q${q.number} ${q.type} :: ${(q.stem||'').slice(0,55).replace(/\n/g,' ')}`);
}
