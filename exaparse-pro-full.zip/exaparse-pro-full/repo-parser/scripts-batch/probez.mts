import fs from 'node:fs';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from './wsPaths.mts';
for (const f of ['زمان_آزمون.docx', 'زمان_آزمون.pdf']) {
  const text = fs.readFileSync(WS_ROOT + '/scratch/texts/' + f + '.txt', 'utf8');
  const doc = parseExamRawText(text, f, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  console.log('=== ' + f + ' TOTAL:', doc.totalMarks, 'SECTIONS:', doc.sections.map(s => s.rowId).join(','));
  if (f === 'زمان_آزمون.pdf') {
    for (const s of doc.sections) {
      console.log(`SEC ${s.rowId} [${s.majorCategory}] mark=${s.markTotal} bank=${s.wordBank?.length||0} match=${!!s.matchingColumns}`);
      for (const q of s.questions) console.log(`   q${q.number} ${q.type} :: ${(q.stem||'').slice(0,45).replace(/\n/g,' ')}`);
    }
  }
}
