import fs from 'node:fs';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from './wsPaths.mts';
const text = fs.readFileSync(WS_ROOT + '/scratch/texts/زمان_آزمون.docx.txt', 'utf8');
const doc = parseExamRawText(text, 't', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
console.log('HEADER:', JSON.stringify(doc.header));
for (const s of doc.sections) {
  console.log(`SEC ${s.rowId} [${s.majorCategory}] mark=${s.markTotal} nq=${s.questions.length}`);
}
