import fs from 'node:fs';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from './wsPaths.mts';
for (const f of ['زمان_آزمون.docx', 'زمان_آزمون.pdf']) {
  const text = fs.readFileSync(WS_ROOT + '/scratch/texts/' + f + '.txt', 'utf8');
  const doc = parseExamRawText(text, f, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  console.log(f, 'DUR:', doc.header.durationMinutes, 'SCHOOL:', doc.header.schoolName, 'TOTAL:', doc.totalMarks);
  const e = doc.sections.find(s => s.rowId === 'E')!;
  console.log('  E q28:', JSON.stringify(e.questions[7].stem), 'distractors:', e.questions[7].matchingDistractors?.length);
  const a = doc.sections.find(s => s.rowId === 'A')!;
  console.log('  A bank:', a.wordBank?.length, 'q1 stem:', JSON.stringify(a.questions[0].stem?.slice(0,30)));
  const f5 = doc.sections.find(s => s.rowId === 'F')!;
  console.log('  F q31:', f5.questions[2].type);
}
