/**
 * qu2golden.mts — pinned runner for the qu2 files PROMOTED to the strict
 * gate (#qu2 wave 3, user decision: every qu2 file that reaches 100% joins
 * the permanent regression suite so it can never silently break again).
 *
 * Promotion protocol: a qu2 file qualifies when the qu2 scorecard grades it
 * at exactly 100%; its GT (already hand-built in scratch/gt-qu2) then gets
 * listed in PINNED_QU2 below and this runner gates on "N/N at 100%" with
 * GT_MIN_FILES = N. The scorecard (qu2report.mts) stays the non-gating
 * progress report for the whole 32-file set.
 */
import { WS_ROOT } from './wsPaths.mts';

/** Promoted qu2 files (frozen GT copies in scratch/gt-qu2-pinned). */
const PINNED_QU2 = ['13991009pq89w65173-pdf.json', '14050401pm57p5s814-pdf.json', '14050320p8214n5896-pdf.json', '14040822pc4i517871-pdf.json', '14050320p43266n364-pdf.json', '14050319p566h5f982-pdf.json'];

process.env.GT_DIR = process.env.GT_DIR ?? WS_ROOT + '/scratch/gt-qu2-pinned';
process.env.TEXT_DIR = process.env.TEXT_DIR ?? WS_ROOT + '/scratch/texts-qu2';
process.env.GT_MIN_FILES = String(PINNED_QU2.length);
await import('./grade.mts');
