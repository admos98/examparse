/**
 * structure_backward.mts — W2 hand-written backward pass.
 *
 * Every gradient gets its own NAMED buffer (no scratch reuse, no in-place
 * aliasing) — the bugs that bite hand-rolled autodiff are exactly aliasing
 * and ordering, and buffers are cheap at Tn<=72, d=64.
 *
 * Chain (matching forward in structure_model.mts):
 *   loss -> dlogits -> final LN -> blocks (FF, attention, LN, residuals,
 *   reversed) -> embedding scatter (Er/Es/Ei/Eg/P).
 */
import {
  Model, FwdCache, linBackward, lnBackward, N_SUBJ, type StepInput,
} from './structure_model.mts';

export interface BwdWorkspace {
  Tn: number;
  d: number;
  ff: number;
  heads: number;
  layers: number;
  dh: number;
  nEv: number;
  dLE: Float32Array;
  dLS: Float32Array;
  dhf: Float32Array;
  dh2: Float32Array; // gradient flowing into block l's output (residual stream)
  // per-layer buffers allocated per layer to keep them independent:
  dl: {
    dh1: Float32Array; // from h2 = h1 + f2 (both branches)
    df2: Float32Array;
    df1: Float32Array;
    da2: Float32Array;
    dh1ff: Float32Array; // from LN(F) branch
    datt: Float32Array;
    dO: Float32Array;
    dA: Float32Array; // heads x T x T
    dS: Float32Array;
    dQ: Float32Array; dK: Float32Array; dV: Float32Array;
    da1: Float32Array;
    dxIn: Float32Array;
  }[];
  dxEmb: Float32Array;
}

export function allocBwd(c: FwdCache): BwdWorkspace {
  const { Tn, d, ff, heads, layers, micro } = c;
  const dh = d / heads;
  const nEv = micro ? 3 : 7;
  const dl = [];
  for (let l = 0; l < layers; l++)
    dl.push({
      dh1: new Float32Array(Tn * d),
      df2: new Float32Array(Tn * d),
      df1: new Float32Array(Tn * ff),
      da2: new Float32Array(Tn * d),
      dh1ff: new Float32Array(Tn * d),
      datt: new Float32Array(Tn * d),
      dO: new Float32Array(Tn * d),
      dA: new Float32Array(heads * Tn * Tn),
      dS: new Float32Array(heads * Tn * Tn),
      dQ: new Float32Array(Tn * d),
      dK: new Float32Array(Tn * d),
      dV: new Float32Array(Tn * d),
      da1: new Float32Array(Tn * d),
      dxIn: new Float32Array(Tn * d),
    });
  return {
    Tn, d, ff, heads, layers, dh, nEv,
    dLE: new Float32Array(Tn * nEv),
    dLS: new Float32Array(Tn * N_SUBJ),
    dhf: new Float32Array(Tn * d),
    dh2: new Float32Array(Tn * d),
    dl,
    dxEmb: new Float32Array(Tn * d),
  };
}

/**
 * Accumulates gradients into every M.all[i].g from the loss computed by
 * forward() (which ALSO computed dlogits — replicated here for clarity).
 * Returns nothing; weights' .g arrays are the output.
 */
export function backward(M: Model, inp: StepInput, c: FwdCache, w: BwdWorkspace): void {
  const { Tn, d, ff, heads, dh, layers } = w;
  const nEv = w.nEv;

  // ---- 0. ZERO the per-call accumulated buffers. The workspace is POOLED
  // and reused across batches; dQ/dK/dV accumulate with += inside the
  // attention backward (across heads and causal positions). Without this
  // reset, every batch's attention gradients START from the running sum of
  // ALL previous batches — Wq/Wk/Wv train on garbage, the corrupted V-path
  // drowns the role signal in the residual stream, and the event head
  // collapses to priors (the all-CONT / KEY-PASS degenerate modes observed
  // in training while gradcheck still passed: it uses a FRESH workspace).
  for (let l = 0; l < layers; l++) {
    w.dl[l].dQ.fill(0);
    w.dl[l].dK.fill(0);
    w.dl[l].dV.fill(0);
  }

  // ---- 1. loss gradient at the logits
  w.dLE.fill(0);
  w.dLS.fill(0);
  let wSum = 0;
  for (let t = 0; t < Tn; t++) wSum += inp.classW ? inp.classW[inp.ev![t]] : 1;
  const norm = wSum > 0 ? wSum : 1;
  for (let t = 0; t < Tn; t++) {
    const tgt = inp.ev![t];
    const off = t * nEv;
    let mx = -Infinity;
    for (let k = 0; k < nEv; k++) mx = Math.max(mx, c.logitsE[off + k]);
    let sum = 0;
    for (let k = 0; k < nEv; k++) sum += Math.exp(c.logitsE[off + k] - mx);
    const wt = (inp.classW ? inp.classW[tgt] : 1) / norm;
    for (let k = 0; k < nEv; k++) {
      const p = Math.exp(c.logitsE[off + k] - mx) / sum;
      w.dLE[off + k] = wt * (p - (k === tgt ? 1 : 0));
    }
    if (inp.secPos && inp.secPos[t] && inp.subjTarget) {
      const so = t * N_SUBJ;
      const st = inp.subjTarget[t];
      let smx = -Infinity;
      for (let k = 0; k < N_SUBJ; k++) smx = Math.max(smx, c.logitsS[so + k]);
      let ssum = 0;
      for (let k = 0; k < N_SUBJ; k++) ssum += Math.exp(c.logitsS[so + k] - smx);
      const sw = (inp.subjW ?? 0) / norm;
      for (let k = 0; k < N_SUBJ; k++) {
        const p = Math.exp(c.logitsS[so + k] - smx) / ssum;
        w.dLS[so + k] = sw * (p - (k === st ? 1 : 0));
      }
    }
  }

  // ---- 2. heads -> dhf (We path via linBackward; Ws path added manually)
  linBackward(c.hf, M.We.p, w.dLE, w.dhf, M.We.g, M.be.g, Tn, d, nEv);
  for (let t = 0; t < Tn; t++) {
    for (let i = 0; i < d; i++) {
      let acc = 0;
      for (let n = 0; n < N_SUBJ; n++) acc += w.dLS[t * N_SUBJ + n] * M.Ws.p[i * N_SUBJ + n];
      w.dhf[t * d + i] += acc;
    }
  }
  for (let t = 0; t < Tn; t++)
    for (let n = 0; n < N_SUBJ; n++) M.bs.g[n] += w.dLS[t * N_SUBJ + n];
  for (let t = 0; t < Tn; t++)
    for (let i = 0; i < d; i++) {
      const v = c.hf[t * d + i];
      if (v === 0) continue;
      for (let n = 0; n < N_SUBJ; n++) M.Ws.g[i * N_SUBJ + n] += v * w.dLS[t * N_SUBJ + n];
    }

  // ---- 3. final LN
  w.dh2.fill(0);
  lnBackward(c.lc[layers - 1].h2, w.dhf, M.lnL.p, c.mf, c.rf, w.dh2, M.lnL.g.subarray(0, d), M.lnL.g.subarray(d), Tn, d);

  // ---- 4. blocks in reverse
  for (let l = layers - 1; l >= 0; l--) {
    const L = M.layers[l];
    const lc = c.lc[l];
    const b = w.dl[l];
    // (a) residuals
    b.dh1.set(w.dh2); // h2 = h1 + f2: both branches carry dh2
    b.df2.set(w.dh2);
    // (b) FF backward: f2 = f1 W2 + b2
    linBackward(lc.f1, L.W2.p, b.df2, b.df1, L.W2.g, L.b2.g, Tn, ff, d);
    // (c) relu mask (f1 stored post-relu; mask = f1>0)
    for (let i = 0; i < Tn * ff; i++) if (lc.f1[i] <= 0) b.df1[i] = 0;
    // (d) f1 = relu(a2 W1 + b1)
    linBackward(lc.a2, L.W1.p, b.df1, b.da2, L.W1.g, L.b1.g, Tn, d, ff);
    // (e) LN(F) backward -> attention-branch gradient into h1
    b.dh1ff.fill(0);
    lnBackward(lc.h1, b.da2, L.lnF.p, lc.m2, lc.r2, b.dh1ff, L.lnF.g.subarray(0, d), L.lnF.g.subarray(d), Tn, d);
    for (let i = 0; i < Tn * d; i++) b.dh1[i] += b.dh1ff[i];
    // (g) h1 = xin + att
    b.datt.set(b.dh1);
    // (h) Wo projection
    linBackward(lc.O, L.Wo.p, b.datt, b.dO, L.Wo.g, L.bo.g, Tn, d, d);
    // (i) attention backward per head
    const scale = 1 / Math.sqrt(dh);
    for (let h = 0; h < heads; h++) {
      const hq = h * dh;
      const sOff = h * Tn * Tn;
      for (let t = 0; t < Tn; t++) {
        // dA[t][u] = sum_k dO[t,k] * V[u,k]  (k over this head's slice)
        for (let u = 0; u <= t; u++) {
          let acc = 0;
          for (let k = 0; k < dh; k++) acc += b.dO[t * d + hq + k] * lc.V[u * d + hq + k];
          b.dA[sOff + t * Tn + u] = acc;
        }
        // softmax backward: dS = A . (dA - <dA, A>)
        let dot = 0;
        for (let u = 0; u <= t; u++) dot += b.dA[sOff + t * Tn + u] * lc.A[sOff + t * Tn + u];
        for (let u = 0; u <= t; u++)
          b.dS[sOff + t * Tn + u] = lc.A[sOff + t * Tn + u] * (b.dA[sOff + t * Tn + u] - dot) * scale;
      }
      // dV: A^T dO ; dQ: dS K ; dK: dS^T Q
      for (let t = 0; t < Tn; t++)
        for (let k = 0; k < dh; k++) {
          let dQacc = 0;
          for (let u = 0; u <= t; u++) {
            b.dV[u * d + hq + k] += lc.A[sOff + t * Tn + u] * b.dO[t * d + hq + k];
            dQacc += b.dS[sOff + t * Tn + u] * lc.K[u * d + hq + k];
          }
          b.dQ[t * d + hq + k] += dQacc;
        }
      for (let t = 0; t < Tn; t++)
        for (let u = 0; u <= t; u++) {
          const g = b.dS[sOff + t * Tn + u];
          if (g === 0) continue;
          for (let k = 0; k < dh; k++) b.dK[u * d + hq + k] += g * lc.Q[t * d + hq + k];
        }
    }
    // (k) projections back to a1
    b.da1.fill(0);
    {
      // zero dx buffers used by linBackward via manual accumulation pattern:
      const dQ0 = new Float32Array(b.dQ);
      const dK0 = new Float32Array(b.dK);
      const dV0 = new Float32Array(b.dV);
      const tmp = new Float32Array(Tn * d); // linBackward zeroes this
      linBackward(lc.a1, L.Wq.p, dQ0, tmp, L.Wq.g, L.bq.g, Tn, d, d);
      for (let i = 0; i < Tn * d; i++) b.da1[i] += tmp[i];
      linBackward(lc.a1, L.Wk.p, dK0, tmp, L.Wk.g, L.bk.g, Tn, d, d);
      for (let i = 0; i < Tn * d; i++) b.da1[i] += tmp[i];
      linBackward(lc.a1, L.Wv.p, dV0, tmp, L.Wv.g, L.bv.g, Tn, d, d);
      for (let i = 0; i < Tn * d; i++) b.da1[i] += tmp[i];
    }
    // (l) LN(A) backward
    b.dxIn.fill(0);
    lnBackward(lc.xIn, b.da1, L.lnA.p, lc.m1, lc.r1, b.dxIn, L.lnA.g.subarray(0, d), L.lnA.g.subarray(d), Tn, d);
    // (m) residual from h1 = xin + att: xin also carries dh1 directly
    for (let i = 0; i < Tn * d; i++) b.dxIn[i] += b.dh1[i];
    // pass to the previous block (or embeddings)
    if (l > 0) w.dh2.set(b.dxIn);
    else w.dxEmb.set(b.dxIn);
  }

  // ---- 5. embedding scatter
  for (let t = 0; t < Tn; t++) {
    const xo = t * d;
    for (let k = 0; k < d; k++) {
      const g = w.dxEmb[xo + k];
      M.Er.g[inp.role[t] * d + k] += g;
      M.Es.g[inp.subj[t] * d + k] += g;
      M.Ei.g[inp.instr[t] * d + k] += g;
      M.Eg.g[inp.geom[t] * d + k] += g;
      M.P.g[t * d + k] += g;
    }
  }
}
