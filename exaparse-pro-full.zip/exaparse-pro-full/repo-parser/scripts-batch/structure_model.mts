/**
 * structure_model.mts — W2 STRUCTURE TRANSFORMER: tensors + forward + loss.
 * Pure TypeScript, Float32Array only, no dependencies.
 *
 * Causal decoder over the W1 codec's symbol stream. Each position carries
 * Emb(role) + Emb(subject) + Emb(instruction) + Emb(geometry-hash) + Pos.
 * Two pre-LN causal-attention blocks; final LN; event head (7 structural
 * events) and subject head (9 classes, trained at section-start positions).
 *
 * Backward lives in structure_backward.mts and is verified against central
 * differences BEFORE training (structure_train.mts).
 *
 * Tensor layout: every weight is a T(rows, cols). Linear weights are
 * W[rows=I, cols=N] row-major: out[t*N+n] = b[n] + sum_i x[t*I+i]*W[i*N+n].
 * LayerNorm weights pack gamma (row 0) and beta (row 1) in one 2-row tensor.
 */

export const D = 64;
export const HEADS = 2;
export const DH = D / HEADS;
export const FF = 128;
export const LAYERS = 2;
export const CTX = 72;
export const STRIDE = 36; // training window stride
export const N_EV = 7; // CONT SEC ROW MARK KEY TOTAL PASS
export const N_SUBJ = 9;
export const EV_NAMES = ['CONT', 'SEC', 'ROW', 'MARK', 'KEY', 'TOTAL', 'PASS'] as const;

let seed = 99;
export function resetSeed(s: number): void {
  seed = s >>> 0;
}
function rnd(): number {
  seed = (seed * 1103515245 + 12345) & 0x7fffffff;
  return seed / 0x7fffffff;
}

export class T {
  p: Float32Array;
  g: Float32Array;
  m: Float32Array;
  v: Float32Array;
  constructor(
    public rows: number,
    public cols: number,
    public name: string,
    scale: number,
  ) {
    const n = rows * cols;
    this.p = new Float32Array(n);
    for (let i = 0; i < n; i++) this.p[i] = (rnd() * 2 - 1) * scale;
    this.g = new Float32Array(n);
    this.m = new Float32Array(n);
    this.v = new Float32Array(n);
  }
  zeroGrad(): void {
    this.g.fill(0);
  }
  adamStep(lr: number, step: number, wd = 0): void {
    const b1 = 0.9,
      b2 = 0.999,
      eps = 1e-8;
    const c1 = 1 - Math.pow(b1, step);
    const c2 = 1 - Math.pow(b2, step);
    for (let i = 0; i < this.p.length; i++) {
      const gi = this.g[i] + wd * this.p[i];
      this.m[i] = b1 * this.m[i] + (1 - b1) * gi;
      this.v[i] = b2 * this.v[i] + (1 - b2) * gi * gi;
      this.p[i] -= (lr * (this.m[i] / c1)) / (Math.sqrt(this.v[i] / c2) + eps);
    }
  }
}

export interface LayerWeights {
  lnA: T; Wq: T; bq: T; Wk: T; bk: T; Wv: T; bv: T; Wo: T; bo: T;
  lnF: T; W1: T; b1: T; W2: T; b2: T;
}

export class Model {
  Er: T; Es: T; Ei: T; Eg: T; P: T;
  layers: LayerWeights[] = [];
  lnL: T;
  We: T; be: T; Ws: T; bs: T;
  all: T[] = [];
  dims = { d: D, ff: FF, heads: HEADS, dh: DH, ctx: CTX, layers: LAYERS };

  constructor(micro = false) {
    const d = micro ? 8 : D;
    const ff = micro ? 10 : FF;
    const heads = 2;
    const dh = d / heads;
    const ctx = micro ? 6 : CTX;
    this.dims = { d, ff, heads, dh, ctx, layers: micro ? 1 : LAYERS };
    const mk = (rows: number, cols: number, name: string, scale: number) => new T(rows, cols, name, scale);
    const s = 1 / Math.sqrt(d);
    this.Er = mk(micro ? 4 : 12, d, 'Er', 0.3);
    this.Es = mk(N_SUBJ, d, 'Es', 0.3);
    this.Ei = mk(micro ? 3 : 10, d, 'Ei', 0.3);
    this.Eg = mk(micro ? 5 : 64, d, 'Eg', 0.3);
    this.P = mk(ctx, d, 'P', 0.1);
    for (let l = 0; l < this.dims.layers; l++) {
      this.layers.push({
        lnA: mk(2, d, `L${l}.lnA`, 0),
        Wq: mk(d, d, `L${l}.Wq`, s), bq: mk(1, d, `L${l}.bq`, 0),
        Wk: mk(d, d, `L${l}.Wk`, s), bk: mk(1, d, `L${l}.bk`, 0),
        Wv: mk(d, d, `L${l}.Wv`, s), bv: mk(1, d, `L${l}.bv`, 0),
        Wo: mk(d, d, `L${l}.Wo`, s), bo: mk(1, d, `L${l}.bo`, 0),
        lnF: mk(2, d, `L${l}.lnF`, 0),
        W1: mk(d, ff, `L${l}.W1`, s), b1: mk(1, ff, `L${l}.b1`, 0),
        W2: mk(ff, d, `L${l}.W2`, 1 / Math.sqrt(ff)), b2: mk(1, d, `L${l}.b2`, 0),
      });
    }
    this.lnL = mk(2, d, 'lnL', 0);
    this.We = mk(d, micro ? 3 : N_EV, 'We', 0.25);
    this.be = mk(1, micro ? 3 : N_EV, 'be', 0);
    this.Ws = mk(d, N_SUBJ, 'Ws', 0.25);
    this.bs = mk(1, N_SUBJ, 'bs', 0);
    this.all = [
      this.Er, this.Es, this.Ei, this.Eg, this.P,
      ...this.layers.flatMap((L) => [
        L.lnA, L.Wq, L.bq, L.Wk, L.bk, L.Wv, L.bv, L.Wo, L.bo, L.lnF, L.W1, L.b1, L.W2, L.b2,
      ]),
      this.lnL, this.We, this.be, this.Ws, this.bs,
    ];
    for (const t of this.all) t.zeroGrad();
  }
}

// ------------------------------------------------------------- primitives
export function linForward(x: Float32Array, W: Float32Array, b: Float32Array, y: Float32Array, Tn: number, I: number, N: number): void {
  for (let t = 0; t < Tn; t++) {
    const xo = t * I, yo = t * N;
    for (let n = 0; n < N; n++) y[yo + n] = b[n];
    for (let i = 0; i < I; i++) {
      const v = x[xo + i];
      if (v === 0) continue;
      const wOff = i * N;
      for (let n = 0; n < N; n++) y[yo + n] += v * W[wOff + n];
    }
  }
}

export function lnForward(
  x: Float32Array, gamma: Float32Array, beta: Float32Array,
  y: Float32Array, mean: Float32Array, rstd: Float32Array, Tn: number, d: number,
): void {
  for (let t = 0; t < Tn; t++) {
    const o = t * d;
    let mu = 0;
    for (let k = 0; k < d; k++) mu += x[o + k];
    mu /= d;
    let va = 0;
    for (let k = 0; k < d; k++) {
      const dv = x[o + k] - mu;
      va += dv * dv;
    }
    va /= d;
    const rs = 1 / Math.sqrt(va + 1e-5);
    mean[t] = mu;
    rstd[t] = rs;
    for (let k = 0; k < d; k++) y[o + k] = (x[o + k] - mu) * rs * gamma[k] + beta[k];
  }
}

/** dx is ACCUMULATED (+=) after being zeroed at entry (dx==null skips x-grad). */
export function linBackward(
  x: Float32Array, W: Float32Array, dy: Float32Array,
  dx: Float32Array | null, dW: Float32Array, db: Float32Array,
  Tn: number, I: number, N: number,
): void {
  if (dx) dx.fill(0);
  for (let t = 0; t < Tn; t++) {
    const xo = t * I;
    const yo = t * N;
    for (let n = 0; n < N; n++) db[n] += dy[yo + n];
    for (let i = 0; i < I; i++) {
      const v = x[xo + i];
      const wOff = i * N;
      let dsum = 0;
      for (let n = 0; n < N; n++) {
        const g = dy[yo + n];
        dsum += g * W[wOff + n];
        dW[wOff + n] += v * g;
      }
      if (dx) dx[xo + i] += dsum;
    }
  }
}

/** Full-LN backward. dx ACCUMULATED (zeroed at entry when non-null). */
export function lnBackward(
  x: Float32Array, dy: Float32Array, gamma: Float32Array,
  mean: Float32Array, rstd: Float32Array,
  dx: Float32Array | null, dGamma: Float32Array, dBeta: Float32Array,
  Tn: number, d: number, gammaOff = 0,
): void {
  for (let t = 0; t < Tn; t++) {
    const o = t * d;
    const mu = mean[t];
    const rs = rstd[t];
    let dotNormGamma = 0;
    let dotNormXhat = 0;
    for (let k = 0; k < d; k++) {
      const xhat = (x[o + k] - mu) * rs;
      const g = gamma[gammaOff + k];
      dotNormGamma += dy[o + k] * g;
      dotNormXhat += dy[o + k] * g * xhat;
      dGamma[gammaOff + k] += dy[o + k] * xhat;
      dBeta[gammaOff + k] += dy[o + k];
    }
    if (dx) {
      const a = dotNormGamma / d;
      const bCoef = (dotNormXhat * rs) / d;
      for (let k = 0; k < d; k++) {
        const xhat = (x[o + k] - mu) * rs;
        const g = gamma[gammaOff + k];
        dx[o + k] += rs * (dy[o + k] * g - a - bCoef * xhat);
      }
    }
  }
}

// ------------------------------------------------------------------ caches
export interface LayerCache {
  xIn: Float32Array; a1: Float32Array; m1: Float32Array; r1: Float32Array;
  Q: Float32Array; K: Float32Array; V: Float32Array;
  S: Float32Array; A: Float32Array; // heads x T x T
  O: Float32Array; att: Float32Array; h1: Float32Array;
  a2: Float32Array; m2: Float32Array; r2: Float32Array;
  f1: Float32Array; f2: Float32Array; h2: Float32Array;
}
export interface FwdCache {
  Tn: number; d: number; ff: number; heads: number; layers: number;
  micro: boolean;
  x: Float32Array;
  lc: LayerCache[];
  hf: Float32Array; mf: Float32Array; rf: Float32Array;
  logitsE: Float32Array; logitsS: Float32Array;
}

function allocCache(Tn: number, d: number, ff: number, heads: number, layers: number, micro: boolean): FwdCache {
  const nEv = micro ? 3 : N_EV;
  const lc: LayerCache[] = [];
  for (let l = 0; l < layers; l++)
    lc.push({
      xIn: new Float32Array(Tn * d), a1: new Float32Array(Tn * d), m1: new Float32Array(Tn), r1: new Float32Array(Tn),
      Q: new Float32Array(Tn * d), K: new Float32Array(Tn * d), V: new Float32Array(Tn * d),
      S: new Float32Array(heads * Tn * Tn), A: new Float32Array(heads * Tn * Tn),
      O: new Float32Array(Tn * d), att: new Float32Array(Tn * d), h1: new Float32Array(Tn * d),
      a2: new Float32Array(Tn * d), m2: new Float32Array(Tn), r2: new Float32Array(Tn),
      f1: new Float32Array(Tn * ff), f2: new Float32Array(Tn * d), h2: new Float32Array(Tn * d),
    });
  return {
    Tn, d, ff, heads, layers, micro,
    x: new Float32Array(Tn * d), lc,
    hf: new Float32Array(Tn * d), mf: new Float32Array(Tn), rf: new Float32Array(Tn),
    logitsE: new Float32Array(Tn * nEv), logitsS: new Float32Array(Tn * N_SUBJ),
  };
}

export interface StepInput {
  role: Int32Array;
  subj: Int32Array;
  instr: Int32Array;
  geom: Int32Array;
  ev?: Int32Array | null;
  classW?: Float32Array;
  secPos?: boolean[] | null;
  subjTarget?: Int32Array | null;
  subjW?: number;
}

/**
 * Forward pass. With targets: returns weighted CE loss (events, class-
 * weighted + subject CE at secPos, averaged over the event weight mass).
 * Without targets: inference only (logits in cache). The backward pass in
 * structure_backward.mts reads this cache — keep every intermediate.
 */
export function forward(M: Model, inp: StepInput, reuse?: FwdCache): { loss: number; cache: FwdCache } {
  const { d, ff, heads, dh, layers } = M.dims;
  const nEv = M.We.cols;
  const micro = d !== D;
  const Tn = inp.role.length;
  const c = reuse && reuse.Tn === Tn && reuse.d === d && reuse.lc.length === layers
    ? reuse
    : allocCache(Tn, d, ff, heads, layers, micro);

  for (let t = 0; t < Tn; t++) {
    const ro = inp.role[t] * d, so = inp.subj[t] * d, io = inp.instr[t] * d, go = inp.geom[t] * d;
    const xo = t * d;
    for (let k = 0; k < d; k++)
      c.x[xo + k] = M.Er.p[ro + k] + M.Es.p[so + k] + M.Ei.p[io + k] + M.Eg.p[go + k] + M.P.p[t * d + k];
  }

  for (let l = 0; l < layers; l++) {
    const L = M.layers[l];
    const lc = c.lc[l];
    const xin = l === 0 ? c.x : c.lc[l - 1].h2;
    lc.xIn.set(xin);
    lnForward(xin, L.lnA.p.subarray(0, d), L.lnA.p.subarray(d), lc.a1, lc.m1, lc.r1, Tn, d);
    linForward(lc.a1, L.Wq.p, L.bq.p, lc.Q, Tn, d, d);
    linForward(lc.a1, L.Wk.p, L.bk.p, lc.K, Tn, d, d);
    linForward(lc.a1, L.Wv.p, L.bv.p, lc.V, Tn, d, d);
    const scale = 1 / Math.sqrt(dh);
    for (let h = 0; h < heads; h++) {
      const hq = h * dh;
      const sOff = h * Tn * Tn;
      for (let t = 0; t < Tn; t++) {
        for (let u = 0; u <= t; u++) {
          let dot = 0;
          for (let k = 0; k < dh; k++) dot += lc.Q[t * d + hq + k] * lc.K[u * d + hq + k];
          lc.S[sOff + t * Tn + u] = dot * scale;
        }
        let mx = -Infinity;
        for (let u = 0; u <= t; u++) mx = Math.max(mx, lc.S[sOff + t * Tn + u]);
        let sum = 0;
        for (let u = 0; u <= t; u++) {
          const e = Math.exp(lc.S[sOff + t * Tn + u] - mx);
          lc.A[sOff + t * Tn + u] = e;
          sum += e;
        }
        for (let u = 0; u <= t; u++) lc.A[sOff + t * Tn + u] /= sum;
        for (let k = 0; k < dh; k++) {
          let acc = 0;
          for (let u = 0; u <= t; u++) acc += lc.A[sOff + t * Tn + u] * lc.V[u * d + hq + k];
          lc.O[t * d + hq + k] = acc;
        }
        for (let u = t + 1; u < Tn; u++) lc.A[sOff + t * Tn + u] = 0;
      }
    }
    linForward(lc.O, L.Wo.p, L.bo.p, lc.att, Tn, d, d);
    for (let i = 0; i < Tn * d; i++) lc.h1[i] = xin[i] + lc.att[i];
    lnForward(lc.h1, L.lnF.p.subarray(0, d), L.lnF.p.subarray(d), lc.a2, lc.m2, lc.r2, Tn, d);
    linForward(lc.a2, L.W1.p, L.b1.p, lc.f1, Tn, d, ff);
    for (let i = 0; i < Tn * ff; i++) lc.f1[i] = lc.f1[i] > 0 ? lc.f1[i] : 0;
    linForward(lc.f1, L.W2.p, L.b2.p, lc.f2, Tn, ff, d);
    for (let i = 0; i < Tn * d; i++) lc.h2[i] = lc.h1[i] + lc.f2[i];
  }

  const last = c.lc[layers - 1];
  lnForward(last.h2, M.lnL.p.subarray(0, d), M.lnL.p.subarray(d), c.hf, c.mf, c.rf, Tn, d);
  linForward(c.hf, M.We.p, M.be.p, c.logitsE, Tn, d, nEv);
  linForward(c.hf, M.Ws.p, M.bs.p, c.logitsS, Tn, d, N_SUBJ);

  if (!inp.ev) return { loss: 0, cache: c };

  let loss = 0;
  let wSum = 0;
  for (let t = 0; t < Tn; t++) {
    const tgt = inp.ev[t];
    const off = t * nEv;
    let mx = -Infinity;
    for (let k = 0; k < nEv; k++) mx = Math.max(mx, c.logitsE[off + k]);
    let sum = 0;
    for (let k = 0; k < nEv; k++) sum += Math.exp(c.logitsE[off + k] - mx);
    const w = inp.classW ? inp.classW[tgt] : 1;
    loss += w * -Math.log(Math.max(1e-12, Math.exp(c.logitsE[off + tgt] - mx) / sum));
    wSum += w;
    if (inp.secPos && inp.secPos[t] && inp.subjTarget) {
      const so = t * N_SUBJ;
      const st = inp.subjTarget[t];
      let smx = -Infinity;
      for (let k = 0; k < N_SUBJ; k++) smx = Math.max(smx, c.logitsS[so + k]);
      let ssum = 0;
      for (let k = 0; k < N_SUBJ; k++) ssum += Math.exp(c.logitsS[so + k] - smx);
      loss += (inp.subjW ?? 0) * -Math.log(Math.max(1e-12, Math.exp(c.logitsS[so + st] - smx) / ssum));
    }
  }
  return { loss: loss / (wSum > 0 ? wSum : 1), cache: c };
}

/** argmax event per position from a filled cache. */
export function predictEvents(M: Model, c: FwdCache): Int32Array {
  const nEv = M.We.cols;
  const out = new Int32Array(c.Tn);
  for (let t = 0; t < c.Tn; t++) {
    let bi = 0;
    for (let k = 1; k < nEv; k++) if (c.logitsE[t * nEv + k] > c.logitsE[t * nEv + bi]) bi = k;
    out[t] = bi;
  }
  return out;
}
