/**
 * structure_train.mts — W2 STRUCTURE TRANSFORMER training driver (dev-side).
 *
 * Pipeline: gradcheck (micro config, central differences — ABORTS on fail)
 *   -> 6-fold file-grouped CV (held-out event accuracy / per-class F1)
 *   -> final fit on all 47 files -> threshold sweep per event class
 *   -> int8-quantized src/utils/structureWeights.ts
 */
import fs from 'node:fs';
import path from 'node:path';
import {
  Model,
  forward,
  predictEvents,
  resetSeed,
  T,
  N_EV,
  N_SUBJ,
  CTX,
  STRIDE,
  EV_NAMES,
} from './structure_model.mts';
import { backward, allocBwd } from './structure_backward.mts';
import {
  extractGeom,
  bodySizeOf,
  geomSummaryToken,
  normText,
} from '../src/utils/codecFeatures';
import { classifyTables, type BrainDoc } from '../src/utils/layoutBrain';
import { WS_ROOT, PKG_ROOT } from './wsPaths.mts';

const DATA = path.join(WS_ROOT, 'scratch', 'w1w2', 'labeled.json');
const OUT_TS = path.join(PKG_ROOT, 'src', 'utils', 'structureWeights.ts');
const STATE = path.join(WS_ROOT, 'scratch', 'w1w2', 'w2-state.json');
// background processes do not survive between tool calls in this sandbox —
// the trainer is BUDGETED: `--budget <seconds>` stops at a checkpoint and a
// fresh invocation resumes from w2-state.json (tensors + Adam moments + RNG).

interface LabeledFile {
  file: string;
  fold: number;
  keyIdx: number;
  printedTotal: number | null;
  lines: { x: number[]; s: number; b: number; t: string; pg: number }[];
  roles: number[];
  subj: number[];
  instr: number[];
  markVal: (number | null)[];
  events: number[];
}

interface Seq {
  file: string;
  fold: number;
  role: Int32Array;
  subj: Int32Array;
  instr: Int32Array;
  geom: Int32Array;
  ev: Int32Array;
  sec: boolean[];
  len: number;
}

function hashG(tok: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < tok.length; i++) {
    h ^= tok.charCodeAt(i);
    h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
  }
  return h % 64;
}

function loadSeqs(): Seq[] {
  const data = JSON.parse(fs.readFileSync(DATA, 'utf8')) as { files: LabeledFile[] };
  const seqs: Seq[] = [];
  for (const f of data.files) {
    const doc = JSON.parse(
      fs.readFileSync(
        path.join(PKG_ROOT, 'scratch', 'brain-qu2', f.file.replace(/\.pdf$/, '') + '.json'),
        'utf8',
      ),
    ) as BrainDoc;
    const cls = classifyTables(doc);
    const body = bodySizeOf(cls);
    const n = f.lines.length;
    const role = new Int32Array(n);
    const subj = new Int32Array(n);
    const instr = new Int32Array(n);
    const geom = new Int32Array(n);
    const sec: boolean[] = new Array(n).fill(false);
    for (let i = 0; i < n; i++) {
      const L = f.lines[i];
      const g = extractGeom(
        cls,
        { text: L.t, size: L.s, bold: !!L.b, bbox: L.x, page: L.pg },
        body,
        n > 1 ? i / (n - 1) : 0,
      );
      role[i] = f.roles[i];
      subj[i] = f.subj[i];
      instr[i] = f.instr[i];
      geom[i] = hashG(geomSummaryToken(g, normText(L.t)));
      sec[i] = f.events[i] === 1; // SEC
    }
    seqs.push({ file: f.file, fold: f.fold, role, subj, instr, geom, ev: Int32Array.from(f.events), sec, len: n });
  }
  return seqs;
}

interface Win {
  si: number;
  start: number;
  len: number;
}
function buildWindows(seqs: Seq[]): Win[] {
  const wins: Win[] = [];
  for (let si = 0; si < seqs.length; si++) {
    const s = seqs[si];
    for (let start = 0; start < s.len; start += STRIDE) {
      const len = Math.min(CTX, s.len - start);
      if (start + len < s.len && len < 16) continue; // skip tiny sliding tails
      wins.push({ si, start, len });
    }
  }
  return wins;
}

/** Windows containing at least one non-CONT position — the stratified-batch
 *  source. Random windows are ~1.2% event-bearing; without this, most batches
 *  carry ZERO rare-class gradient and the event head never separates. */
function eventWindows(seqs: Seq[]): Win[] {
  const wins: Win[] = [];
  for (let si = 0; si < seqs.length; si++) {
    const s = seqs[si];
    for (let start = 0; start < s.len; start += STRIDE) {
      const len = Math.min(CTX, s.len - start);
      if (start + len < s.len && len < 16) continue;
      let hasEv = false;
      for (let i = start; i < start + len && !hasEv; i++) if (s.ev[i] !== 0) hasEv = true;
      if (hasEv) wins.push({ si, start, len });
    }
  }
  return wins;
}

/** Mixed batch draw: half event-bearing windows, half uniform. */
function drawWin(wins: Win[], evWins: Win[], b: number): Win {
  const pool = b % 2 === 0 && evWins.length > 0 ? evWins : wins;
  return pool[Math.floor(lcg() * pool.length)];
}

/**
 * Per-window CONT-mass rebalancing: cap the CONT class weight so the
 * window's CONT gradient mass is at most 2x its event mass. Without this,
 * 68 CONT positions out-weight a lone event ~17:1 and descent slides down
 * the shared CONT pathway (bias be[CONT] + We[:,CONT]) first — observed as
 * p(CONT)=0.990 at a TRUE-ROW position after 60 single-window Adam steps,
 * and SEC/ROW/MARK F1=0.00 corpus-wide despite falling loss. Pure-CONT
 * windows keep the full weight (they are the majority teacher).
 */
function rebalancedW(classW: Float32Array, ev: Int32Array): Float32Array {
  let rareMass = 0;
  let nCont = 0;
  for (let i = 0; i < ev.length; i++) {
    if (ev[i] === 0) nCont++;
    else rareMass += classW[ev[i]];
  }
  if (rareMass <= 0 || nCont === 0) return classW;
  const cap = (2 * rareMass) / nCont;
  if (classW[0] <= cap) return classW;
  const eff = Float32Array.from(classW);
  eff[0] = cap;
  return eff;
}

function classWeightsOf(seqs: Seq[]): Float32Array {
  const cnt = new Array(N_EV).fill(0);
  let tot = 0;
  for (const s of seqs) for (let i = 0; i < s.len; i++) (cnt[s.ev[i]]++, tot++);
  const w = cnt.map((c: number) => 1 / Math.sqrt(Math.max(1, c)));
  const mean = w.reduce((a: number, b: number) => a + b, 0) / N_EV;
  // CLIP [0.25, 4]: unclipped, CONT's weight collapses to ~0.08 and the
  // loss-minimizing solution is "predict CONT everywhere, park rare classes
  // at chance" (observed as SEC/ROW/MARK F1=0.00 at 92.97% self-acc). The
  // clip keeps the majority learnable while rare events still dominate.
  return Float32Array.from(w.map((v: number) => Math.min(4, Math.max(0.25, v / mean))));
}

let lcgState = 12345;
function lcg(): number {
  lcgState = (lcgState * 1103515245 + 12345) & 0x7fffffff;
  return lcgState / 0x7fffffff;
}

/**
 * FROZEN EMBEDDINGS — the decisive fix. The probe_w2c minimal test proved a
 * softmax head over FROZEN random embeddings separates the event stream at
 * 99.5% (SEC 228/228, ROW 751/751): the role→event mapping is linear in the
 * embedding symbols. Training the embeddings JOINTLY at Adam pace makes the
 * head's target move every step; descent then settles into degenerate basins
 * (observed: all-CONT argmax at 700 steps, KEY/PASS garbage at 450, F1=0
 * everywhere, across three loss-balance regimes). Freezing the bottom keeps
 * the signal stationary so the transformer + heads only have to learn the
 * readout and the context cleanup. Embeddings are still EMITTED (the
 * runtime needs them); they just never update.
 */
const FROZEN = new Set(['Er', 'Es', 'Ei', 'Eg', 'P']);
function adamStepAll(M: Model, lr: number, step: number): void {
  for (const t of M.all) if (!FROZEN.has(t.name)) t.adamStep(lr, step);
}

function stepInputFor(seqs: Seq[], w: Win) {
  const s = seqs[w.si];
  return {
    role: s.role.subarray(w.start, w.start + w.len),
    subj: s.subj.subarray(w.start, w.start + w.len),
    instr: s.instr.subarray(w.start, w.start + w.len),
    geom: s.geom.subarray(w.start, w.start + w.len),
    ev: s.ev.subarray(w.start, w.start + w.len),
    secPos: s.sec.slice(w.start, w.start + w.len),
    subjTarget: s.subj.subarray(w.start, w.start + w.len),
  };
}

function trainOn(seqs: Seq[], steps: number, label: string): Model {
  const M = new Model(false);
  const classW = classWeightsOf(seqs);
  const wins = buildWindows(seqs);
  const evWins = eventWindows(seqs);
  // per-length forward/backward workspace pool — a shorter window with a
  // CTX-sized workspace reads past the end (undefined -> NaN) and that is
  // exactly the kind of silent corruption the pool prevents.
  const pool = new Map<number, { c: ReturnType<typeof forward>['cache']; w: ReturnType<typeof allocBwd> }>();
  const getWs = (len: number) => {
    let e = pool.get(len);
    if (!e) {
      const c0 = forward(M, { role: new Int32Array(len), subj: new Int32Array(len), instr: new Int32Array(len), geom: new Int32Array(len) }).cache;
      e = { c: c0, w: allocBwd(c0) };
      pool.set(len, e);
    }
    return e;
  };
  let step = 0;
  for (let it = 0; it < steps; it++) {
    for (const t of M.all) t.zeroGrad();
    let loss = 0;
    for (let b = 0; b < 4; b++) {
      const w = drawWin(wins, evWins, b);
      const inp = stepInputFor(seqs, w);
      const effW = rebalancedW(classW, inp.ev);
      const ws = getWs(w.len);
      const r = forward(M, { ...inp, classW: effW, subjW: 0.5 }, ws.c);
      if (!Number.isFinite(r.loss)) continue; // defensive: never train on a bad batch
      loss += r.loss;
      backward(M, { ...inp, classW: effW, subjW: 0.5 }, ws.c, ws.w);
    }
    step++;
    adamStepAll(M, 3e-3, step);
    if (it % 100 === 0) console.log(`  [${label}] step ${it}: loss=${(loss / 4).toFixed(4)}`);
  }
  return M;
}

/** Sliding-window inference over a full doc; first (longest-context) window wins. */
function docEventProbs(M: Model, s: Seq): Float32Array {
  const n = s.len;
  const nEv = N_EV;
  const acc = new Float32Array(n * nEv);
  const cov = new Int32Array(n);
  const windows: Win[] = [];
  for (let start = 0; start < n; start += CTX) {
    const len = Math.min(CTX, n - start);
    if (len < 4 && start > 0) break;
    windows.push({ si: 0, start, len });
  }
  const pool = new Map<number, ReturnType<typeof forward>['cache']>();
  for (const w of windows) {
    let cache = pool.get(w.len);
    if (!cache) {
      cache = forward(M, { role: new Int32Array(w.len), subj: new Int32Array(w.len), instr: new Int32Array(w.len), geom: new Int32Array(w.len) }).cache;
      pool.set(w.len, cache);
    }
    const inp = {
      role: s.role.subarray(w.start, w.start + w.len),
      subj: s.subj.subarray(w.start, w.start + w.len),
      instr: s.instr.subarray(w.start, w.start + w.len),
      geom: s.geom.subarray(w.start, w.start + w.len),
    };
    const { cache: c2 } = forward(M, inp, cache);
    for (let i = 0; i < w.len; i++) {
      const p = w.start + i;
      if (cov[p] > 0) continue; // earlier window = longer left context
      cov[p] = 1;
      let mx = -Infinity;
      for (let k = 0; k < nEv; k++) mx = Math.max(mx, c2.logitsE[i * nEv + k]);
      let sum = 0;
      for (let k = 0; k < nEv; k++) sum += Math.exp(c2.logitsE[i * nEv + k] - mx);
      for (let k = 0; k < nEv; k++) acc[p * nEv + k] = Math.exp(c2.logitsE[i * nEv + k] - mx) / sum;
    }
  }
  return acc;
}

function evalModel(M: Model, seqs: Seq[]): { acc: number; f1: { ev: string; p: number; r: number; f1: number; n: number }[] } {
  let hit = 0;
  let tot = 0;
  const tp = new Array(N_EV).fill(0);
  const fp = new Array(N_EV).fill(0);
  const fn = new Array(N_EV).fill(0);
  for (const s of seqs) {
    const probs = docEventProbs(M, s);
    for (let i = 0; i < s.len; i++) {
      let bi = 0;
      for (let k = 1; k < N_EV; k++) if (probs[i * N_EV + k] > probs[i * N_EV + bi]) bi = k;
      hit += bi === s.ev[i] ? 1 : 0;
      tot++;
      tp[s.ev[i]] += bi === s.ev[i] ? 1 : 0;
      if (bi === s.ev[i] && s.ev[i] !== bi) fp[bi]++;
      if (bi !== s.ev[i]) {
        fp[bi] += bi === s.ev[i] ? 0 : 1;
        fn[s.ev[i]]++;
      }
    }
  }
  const f1 = EV_NAMES.map((ev: string, k: number) => {
    const p = tp[k] / Math.max(1, tp[k] + fp[k]);
    const r = tp[k] / Math.max(1, tp[k] + fn[k]);
    return { ev, p, r, f1: 2 * p * r / Math.max(1e-9, p + r), n: tp[k] + fn[k] };
  });
  return { acc: tot ? hit / tot : 0, f1 };
}

// ---------------------------------------------------------------- gradcheck
function gradCheck(): boolean {
  console.log('GRADCHECK (micro config, central differences)...');
  resetSeed(7);
  const M = new Model(true);
  const Tn = 6;
  const role = Int32Array.from({ length: Tn }, () => Math.floor(lcg() * 4));
  const subj = Int32Array.from({ length: Tn }, () => Math.floor(lcg() * N_SUBJ));
  const instr = Int32Array.from({ length: Tn }, () => Math.floor(lcg() * 3));
  const geom = Int32Array.from({ length: Tn }, () => Math.floor(lcg() * 5));
  const ev = Int32Array.from({ length: Tn }, () => Math.floor(lcg() * 3));
  const secPos = Array.from({ length: Tn }, () => lcg() < 0.4);
  const subjTarget = Int32Array.from({ length: Tn }, () => Math.floor(lcg() * N_SUBJ));
  const classW = Float32Array.from({ length: 3 }, () => 0.5 + lcg());
  const base = { role, subj, instr, geom, ev, classW, secPos, subjTarget, subjW: 0.5 };

  const lossOf = (): number => forward(M, base).loss;
  const l0 = lossOf();
  const { cache } = forward(M, base);
  const bwd = allocBwd(cache);
  for (const t of M.all) t.zeroGrad();
  backward(M, base, cache, bwd);

  const h = 1e-2;
  let worst = 0;
  let worstName = '';
  let checked = 0;
  for (const t of M.all) {
    const samples = Math.min(6, t.p.length);
    for (let s = 0; s < samples; s++) {
      const idx = Math.floor((s * t.p.length) / samples);
      const orig = t.p[idx];
      t.p[idx] = orig + h;
      const lp = lossOf();
      t.p[idx] = orig - h;
      const lm = lossOf();
      t.p[idx] = orig;
      const fd = (lp - lm) / (2 * h);
      const an = t.g[idx];
      const rel = Math.abs(an - fd) / Math.max(1e-6, Math.abs(an) + Math.abs(fd));
      checked++;
      if (rel > worst) {
        worst = rel;
        worstName = `${t.name}[${idx}] an=${an.toExponential(3)} fd=${fd.toExponential(3)}`;
      }
    }
  }
  console.log(`gradcheck: ${checked} params sampled, worst rel err ${worst.toExponential(2)} (${worstName}), loss=${l0.toFixed(4)}`);
  if (worst > 0.05) {
    console.error('GRADCHECK FAILED — backward disagrees with finite differences. ABORTING before training.');
    return false;
  }
  console.log('gradcheck PASSED');
  return true;
}

// ---------------------------------------------------------------- main
function main() {
  const budgetArg = process.argv.indexOf('--budget');
  const budget = budgetArg > 0 ? Number(process.argv[budgetArg + 1]) : Infinity;
  const t0 = Date.now();
  const outOfTime = () => Date.now() - t0 > budget * 1000;

  if (!gradCheck()) process.exit(1);
  const seqs = loadSeqs();
  console.log(`loaded ${seqs.length} docs, ${seqs.reduce((a, s) => a + s.len, 0)} lines`);

  interface State {
    cv: { fold: number; acc: number; f1: { ev: string; p: number; r: number; f1: number; n: number }[] }[];
    cvStep: number[];
    finalStep: number;
    tensors: Record<string, { p: string; m: string; v: string }> | null;
    lcg: number;
    done: boolean;
  }
  const blank: State = { cv: [], cvStep: [0, 0, 0, 0, 0, 0], finalStep: 0, tensors: null, lcg: 999, done: false };
  let state: State = blank;
  if (fs.existsSync(STATE)) {
    try {
      state = JSON.parse(fs.readFileSync(STATE, 'utf8')) as State;
      console.log(`resuming: cv folds done ${state.cv.length}, final steps ${state.finalStep}`);
    } catch {
      state = blank;
    }
  }

  const saveState = (M: Model | null) => {
    const out: State = {
      cv: state.cv,
      cvStep: state.cvStep,
      finalStep: state.finalStep,
      lcg: lcgState,
      done: state.done,
      tensors: M
        ? Object.fromEntries(
            M.all.map((t) => [
              t.name,
              {
                p: Buffer.from(t.p.buffer, t.p.byteOffset, t.p.byteLength).toString('base64'),
                m: Buffer.from(t.m.buffer, t.m.byteOffset, t.m.byteLength).toString('base64'),
                v: Buffer.from(t.v.buffer, t.v.byteOffset, t.v.byteLength).toString('base64'),
              },
            ]),
          )
        : null,
    };
    fs.writeFileSync(STATE, JSON.stringify(out));
  };

  const foldSeqs = (f: number) => seqs.filter((s) => s.fold !== f);
  const folds = 6;
  let accSum = 0;
  for (let f = 0; f < folds; f++) {
    const rec = state.cv.find((r) => r.fold === f);
    if (rec) {
      accSum += rec.acc;
      console.log(`cv${f}: cached acc ${(rec.acc * 100).toFixed(1)}%`);
      continue;
    }
    lcgState = 999 + f;
    const M = new Model(false);
    // resume within-fold training state when present
    let startStep = 0;
    if (state.tensors && state.cvStep[f] > 0) {
      lcgState = state.lcg;
      for (const t of M.all) {
        const b = state.tensors[t.name];
        if (!b) continue;
        t.p.set(new Float32Array(Buffer.from(b.p, 'base64').buffer, 0, t.p.length));
        t.m.set(new Float32Array(Buffer.from(b.m, 'base64').buffer, 0, t.m.length));
        t.v.set(new Float32Array(Buffer.from(b.v, 'base64').buffer, 0, t.v.length));
      }
      startStep = state.cvStep[f];
      console.log(`cv${f}: resuming at step ${startStep}`);
    }
    const foldS = foldSeqs(f);
    const classW = classWeightsOf(foldS);
    const wins = buildWindows(foldS);
    const evWins = eventWindows(foldS);
    const pool = new Map<number, { c: ReturnType<typeof forward>['cache']; w: ReturnType<typeof allocBwd> }>();
    const getWs = (len: number) => {
      let e = pool.get(len);
      if (!e) {
        const c0 = forward(M, { role: new Int32Array(len), subj: new Int32Array(len), instr: new Int32Array(len), geom: new Int32Array(len) }).cache;
        e = { c: c0, w: allocBwd(c0) };
        pool.set(len, e);
      }
      return e;
    };
    const CV_STEPS = 700;
    for (let it = startStep; it < CV_STEPS; it++) {
      for (const t of M.all) t.zeroGrad();
      let loss = 0;
      for (let b = 0; b < 4; b++) {
        const w = drawWin(wins, evWins, b);
        const inp = stepInputFor(foldS, w);
        const effW = rebalancedW(classW, inp.ev);
        const ws = getWs(w.len);
        const r = forward(M, { ...inp, classW: effW, subjW: 0.5 }, ws.c);
        if (!Number.isFinite(r.loss)) continue;
        loss += r.loss;
        backward(M, { ...inp, classW: effW, subjW: 0.5 }, ws.c, ws.w);
      }
      adamStepAll(M, 3e-3, it + 1);
      if ((it + 1) % 100 === 0) console.log(`  [cv${f}] step ${it + 1}: loss=${(loss / 4).toFixed(4)}`);
      if (outOfTime() && (it + 1) % 25 === 0) {
        state.cvStep[f] = it + 1;
        saveState(M);
        console.log(`BUDGET: checkpointed cv${f} at step ${it + 1}; rerun to resume.`);
        return;
      }
    }
    const r = evalModel(M, seqs.filter((s) => s.fold === f));
    state.cv.push({ fold: f, acc: r.acc, f1: r.f1 });
    accSum += r.acc;
    state.cvStep[f] = 0;
    state.tensors = null;
    saveState(null);
    console.log(`cv${f}: event acc ${(r.acc * 100).toFixed(1)}%  |  ${r.f1.filter((x) => x.ev !== 'CONT').map((x) => `${x.ev} F1=${x.f1.toFixed(2)}`).join('  ')}`);
    if (outOfTime()) {
      console.log('BUDGET: fold complete, state saved. Rerun to continue.');
      return;
    }
  }
  console.log(`\nW2 CV mean event acc: ${((accSum / folds) * 100).toFixed(2)}%`);

  // ---- final fit on everything + threshold sweep
  console.log('\nfinal fit on all docs...');
  resetSeed(42);
  lcgState = 4242;
  const M = trainOn(seqs, 3500, 'final');
  const r = evalModel(M, seqs);
  console.log(`self event acc: ${(r.acc * 100).toFixed(2)}%`);
  for (const x of r.f1) console.log(`  ${x.ev.padEnd(5)} P=${x.p.toFixed(2)} R=${x.r.toFixed(2)} F1=${x.f1.toFixed(2)} (n=${x.n})`);

  // threshold sweep per event class (except CONT) on self-probs
  const thresholds: Record<string, number> = {};
  const probsByDoc = seqs.map((s) => docEventProbs(M, s));
  for (let k = 1; k < N_EV; k++) {
    let bestF1 = 0;
    let bestT = 0.5;
    for (let t = 0.05; t <= 0.95; t += 0.05) {
      let tp = 0, fp = 0, fn = 0;
      for (let si = 0; si < seqs.length; si++) {
        const s = seqs[si];
        for (let i = 0; i < s.len; i++) {
          const pred = probsByDoc[si][i * N_EV + k] >= t;
          const isTrue = s.ev[i] === k;
          if (pred && isTrue) tp++;
          else if (pred && !isTrue) fp++;
          else if (!pred && isTrue) fn++;
        }
      }
      const p = tp / Math.max(1, tp + fp);
      const rc = tp / Math.max(1, tp + fn);
      const f1 = (2 * p * rc) / Math.max(1e-9, p + rc);
      if (f1 > bestF1) {
        bestF1 = f1;
        bestT = Math.round(t * 100) / 100;
      }
    }
    thresholds[EV_NAMES[k]] = bestT;
    console.log(`threshold ${EV_NAMES[k]}: ${bestT} (F1 ${bestF1.toFixed(2)})`);
  }

  // ---- emit weights module
  emit(M, thresholds);
}

function emit(M: Model, thresholds: Record<string, number>): void {
  const tensors = M.all.map((t: T) => {
    let maxAbs = 0;
    for (let i = 0; i < t.p.length; i++) maxAbs = Math.max(maxAbs, Math.abs(t.p[i]));
    const scale = maxAbs / 127 || 1;
    const q = new Int8Array(t.p.length);
    for (let i = 0; i < t.p.length; i++) q[i] = Math.round(t.p[i] / scale);
    return { name: t.name, rows: t.rows, cols: t.cols, scale, b64: Buffer.from(q.buffer).toString('base64') };
  });
  const totalKB = tensors.reduce((a, t) => a + t.b64.length, 0) / 1024;
  const body = tensors
    .map((t: { name: string; rows: number; cols: number; scale: number; b64: string }) => `  { n: '${t.name}', r: ${t.rows}, c: ${t.cols}, s: ${t.scale.toExponential(6)}, d: '${t.b64}' },`)
    .join('\n');
  const ts = `/**
 * structureWeights.ts — W2 STRUCTURE TRANSFORMER, trained weights (GENERATED).
 *
 * Source of truth: scripts-batch/structure_train.mts over the labeled qu2
 * corpus (47 files, file-grouped CV before the final fit). Tiny causal
 * decoder over the W1 codec symbol stream: 2 pre-LN blocks, D=64, 2 heads,
 * FF=128, ctx=72; event head (7) + subject head (9).
 *
 * The event thresholds below were swept per class for best F1 on the
 * training corpus; the oracle (structureOracle.ts) consumes them verbatim.
 *
 * Budget: ~${totalKB.toFixed(0)}KB int8. S26 contract: decode failure = oracle
 * absent = current behavior. Weights are data, never a hazard.
 */
export const STRUCTURE_CFG = {
  D: ${M.dims.d},
  heads: ${M.dims.heads},
  ff: ${M.dims.ff},
  layers: ${M.dims.layers},
  ctx: ${M.dims.ctx},
  nEv: ${M.We.cols},
  nSubj: ${N_SUBJ},
} as const;

export const STRUCTURE_THRESHOLDS: Record<string, number> = ${JSON.stringify(thresholds)};

export const STRUCTURE_TENSORS: { n: string; r: number; c: number; s: number; d: string }[] = [
${body}
];
`;
  fs.writeFileSync(OUT_TS, ts);
  console.log(`\nwrote ${OUT_TS} (${totalKB.toFixed(0)}KB int8 base64)`);
}

main();
