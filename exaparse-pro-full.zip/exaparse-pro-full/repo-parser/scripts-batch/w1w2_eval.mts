/**
 * w1w2_eval.mts — W1/W2 (Specialist wave) corpus A/B: oracle OFF vs ON.
 *
 * For every GT'd qu2 file: parse with the layout brain in drive mode
 * (baseline = shipped G5 behavior, EXAM_ORACLE=off), then again with the
 * W1+W2 oracle allowed to propose when the brain's gate refuses
 * (EXAM_ORACLE=on). Grade both against the hand-built GTs and report
 * better / worse / tie per file plus score deltas.
 *
 * Gate files (the 6 pinned qu2 GTs) MUST stay identical — the oracle only
 * fires when the brain's drive gate refuses, and those files drive.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { buildBrainPreSplit } from '../src/utils/brainStep';
import type { BrainDoc } from '../src/utils/layoutBrain';
import { WS_ROOT, PKG_ROOT } from './wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-qu2');
const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-qu2');

interface Row {
  file: string;
  baseScore: number;
  oracleScore: number;
  baseIssues: number;
  oracleIssues: number;
  baseMode: string;
  oracleMode: string;
  oracleDrove: boolean;
}

function parseWith(text: string, file: string, brainDoc: BrainDoc | undefined, oracle: boolean) {
  process.env.EXAM_ORACLE = oracle ? 'on' : 'off';
  const step = buildBrainPreSplit(brainDoc, 'drive');
  const parsed = parseExamRawText(text, file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true }, step.preSplit, step.source);
  const oracleDrove = step.source === 'oracle' && (parsed.validationFlags ?? []).some((f) => f.includes('kept ORACLE'));
  return { parsed, mode: step.report?.mode ?? 'none', notes: step.report?.notes ?? [], oracleDrove };
}

function main() {
  const gtFiles = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  const rows: Row[] = [];
  for (const gf of gtFiles) {
    const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, gf), 'utf8'));
    const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const text = fs.readFileSync(textPath, 'utf8');
    const brainPath = path.join(BRAIN_DIR, gt.file.replace(/\.pdf$/, '') + '.json');
    const brainDoc = fs.existsSync(brainPath) ? (JSON.parse(fs.readFileSync(brainPath, 'utf8')) as BrainDoc) : undefined;

    const base = parseWith(text, gt.file, brainDoc, false);
    const gBase = gradeParse(base.parsed, gt);
    const orc = parseWith(text, gt.file, brainDoc, true);
    const gOrc = gradeParse(orc.parsed, gt);

    const oracleDrove = orc.oracleDrove;
    rows.push({
      file: gt.file,
      baseScore: gBase.score,
      oracleScore: gOrc.score,
      baseIssues: gBase.issues.length,
      oracleIssues: gOrc.issues.length,
      baseMode: base.mode,
      oracleMode: orc.mode,
      oracleDrove,
    });
    const delta = gOrc.score - gBase.score;
    const icon = delta > 0 ? '▲' : delta < 0 ? '▼' : '=';
    console.log(
      `${icon} ${gt.file}  base ${gBase.score.toFixed(1)}% (${gBase.issues.length} iss, ${base.mode})  oracle ${gOrc.score.toFixed(1)}% (${gOrc.issues.length} iss, ${orc.mode}${oracleDrove ? ' ORACLE-DROVE' : ''})  Δ${delta >= 0 ? '+' : ''}${delta.toFixed(1)}`
    );
    if (delta < 0) for (const i of gOrc.issues.slice(0, 6)) console.log(`   oracle-issue: ${i}`);
    if (delta > 0) for (const i of gBase.issues.slice(0, 6)) console.log(`   base-issue: ${i}`);
  }
  const better = rows.filter((r) => r.oracleScore > r.baseScore);
  const worse = rows.filter((r) => r.oracleScore < r.baseScore);
  const tie = rows.length - better.length - worse.length;
  const avgBase = rows.reduce((a, r) => a + r.baseScore, 0) / Math.max(1, rows.length);
  const avgOrc = rows.reduce((a, r) => a + r.oracleScore, 0) / Math.max(1, rows.length);
  const drove = rows.filter((r) => r.oracleDrove);
  console.log(`\n=== W1+W2 oracle A/B over ${rows.length} GT files ===`);
  console.log(`better ${better.length} / worse ${worse.length} / tie ${tie}   avg ${avgBase.toFixed(2)}% -> ${avgOrc.toFixed(2)}%`);
  console.log(`oracle actually drove ${drove.length} parse(s): ${drove.map((r) => r.file).join(', ') || '(none)'}`);
  for (const r of better) console.log(`  ▲ ${r.file}: ${r.baseScore.toFixed(1)} -> ${r.oracleScore.toFixed(1)}`);
  for (const r of worse) console.log(`  ▼ ${r.file}: ${r.baseScore.toFixed(1)} -> ${r.oracleScore.toFixed(1)}`);
}

main();
