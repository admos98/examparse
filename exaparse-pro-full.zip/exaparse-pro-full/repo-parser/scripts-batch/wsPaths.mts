/**
 * Workspace-path resolution for every batch tool and gate runner.
 *
 * Layout contract (workspace AND unzipped bundle are identical — unzip at
 * project root):
 *   <WS_ROOT>/repo-parser/   this package (npm scripts run here)
 *   <WS_ROOT>/scripts/       verify suites + golden corpus + runners
 *   <WS_ROOT>/scratch/       golden GT + extracted texts (shipped in bundle)
 *   <WS_ROOT>/samples/       source exam corpora (shipped in bundle)
 *
 * Defaults derive from THIS file's own location, never from an absolute
 * machine path, so `npm run verify` works out-of-the-box anywhere the
 * workspace or bundle is placed. Every default stays env-overridable.
 */
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url)); // <pkg>/scripts-batch
export const PKG_ROOT = path.resolve(HERE, '..');           // repo-parser/
export const WS_ROOT = path.resolve(HERE, '..', '..');      // workspace/bundle root

/** Env override (absolute or cwd-relative), else workspace-relative default. */
export function wsEnv(envValue: string | undefined, wsRelativeDefault: string): string {
  return envValue ?? path.join(WS_ROOT, wsRelativeDefault);
}
