/**
 * autopsy_20 — WHY is the corpus average ~20%?
 * Runs BOTH paths (text / brain-wired) exactly like brain_bridge_report,
 * but dumps gradeParse issues bucketed by failure class, corpus-wide.
 *
 * Buckets:
 *   ids      — section id sequence mismatch (split errors)
 *   missing  — a GT section not present in the parse (cascade of a bad split)
 *   category — section category typing
 *   mark     — section markTotal
 *   count    — question count mismatch in a section
 *   qnum     — question number at position (numbering / segmentation)
 *   qtype    — question type mismatch
 *   stem     — stem spot-check
 *   header   — header field mismatches
 *   total    — totalMarks mismatch
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { runLayoutBrain } from '../src/utils/layoutBrain';
import { bridgeBrainResult } from '../src/utils/brainBridge';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2');
const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

type Bucket = 'ids' | 'missing' | 'category' | 'mark' | 'count' | 'qnum' | 'qtype' | 'stem' | 'header' | 'total';

function bucketOf(issue: string): Bucket {
  if (issue.startsWith('section ids')) return 'ids';
  if (issue.includes(' MISSING')) return 'missing';
  if (issue.includes(' category: ')) return 'category';
  if (issue.includes(' markTotal: ')) return 'mark';
  if (/ count: got /.test(issue)) return 'count';
  if (issue.includes(' q# at pos ')) return 'qnum';
  if (/ q\d+ type: /.test(issue)) return 'qtype';
  if (/ q\d+ (stem|missing for stem)/.test(issue)) return 'stem';
  if (issue.startsWith('header.')) return 'header';
  if (issue.startsWith('totalMarks')) return 'total';
  return 'stem';
}

function main() {
  const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  const corpusBuckets = new Map<Bucket, number>();
  const perFile: { file: string; score: number; total: number; issues: number; buckets: Record<string, number> }[] = [];
  const samples = new Map<Bucket, string[]>();

  for (const f of files) {
    const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
    const stem = gt.file.replace(/\.pdf$/i, '');
    const textPath = path.join(APP_TEXT_DIR, stem + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const text = fs.readFileSync(textPath, 'utf8');
    const opts = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const;

    // shipped default = brain drives when it can, else text path
    let score = -1;
    let issues: string[] = [];
    let total = 0;
    let mode = 'text';
    try {
      const brainPath = path.join(BRAIN_DIR, stem + '.json');
      let blocks: Parameters<typeof parseExamRawText>[3] | undefined;
      if (fs.existsSync(brainPath)) {
        const brainDoc = JSON.parse(fs.readFileSync(brainPath, 'utf8'));
        const res = runLayoutBrain(brainDoc);
        const bridged = bridgeBrainResult(res);
        if (bridged) {
          blocks = bridged.blocks;
          mode = 'brain';
        }
      }
      const doc = parseExamRawText(text, gt.file, opts, blocks);
      const g = gradeParse(doc, gt);
      score = g.score; issues = g.issues; total = g.total;
    } catch (e) {
      issues = [`FATAL: ${String(e).slice(0, 120)}`];
      total = 1;
    }

    const buckets: Record<string, number> = {};
    for (const iss of issues) {
      const b = issues.length === 1 && iss.startsWith('FATAL') ? 'header' : bucketOf(iss);
      buckets[b] = (buckets[b] ?? 0) + 1;
      corpusBuckets.set(b, (corpusBuckets.get(b) ?? 0) + 1);
      if (!samples.has(b)) samples.set(b, []);
      const arr = samples.get(b)!;
      if (arr.length < 6) arr.push(`${gt.file.slice(0, 22)} :: ${iss.slice(0, 110)}`);
    }
    perFile.push({ file: gt.file, score, total, issues: issues.length, buckets });
  }

  console.log('=== PER FILE (shipped default path) ===');
  for (const r of perFile) {
    const top = Object.entries(r.buckets).sort((a, b) => b[1] - a[1]).slice(0, 3)
      .map(([k, v]) => `${k}:${v}`).join(' ');
    console.log(`${String(r.score.toFixed(1)).padStart(7)}  total=${String(r.total).padStart(3)} issues=${String(r.issues).padStart(3)} mode=${mode0(r)}  ${top.padEnd(28)} ${r.file}`);
  }
  function mode0(r: { buckets: Record<string, number> }) { return r.buckets['FATAL'] ? 'FATAL' : ''; }

  console.log('\n=== CORPUS-WIDE ISSUE BUCKETS ===');
  const sorted = [...corpusBuckets.entries()].sort((a, b) => b[1] - a[1]);
  const sum = sorted.reduce((s, [, v]) => s + v, 0);
  for (const [b, v] of sorted) console.log(`${b.padEnd(9)} ${String(v).padStart(5)}  (${((v / sum) * 100).toFixed(1)}%)`);
  console.log(`TOTAL issues: ${sum}`);

  console.log('\n=== SAMPLES PER BUCKET ===');
  for (const [b, arr] of [...samples.entries()].sort((a, b) => (corpusBuckets.get(b[0]) ?? 0) - (corpusBuckets.get(a[0]) ?? 0))) {
    console.log(`\n-- ${b} --`);
    for (const s of arr) console.log('   ' + s);
  }
}

main();
