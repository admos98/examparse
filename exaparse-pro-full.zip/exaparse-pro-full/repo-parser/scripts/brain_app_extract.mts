/**
 * brain_app_extract — build APP-DOMAIN geometry sidecars with the SAME code
 * path the browser uses (pdf.js textContent grouping + operator-list shapes),
 * so the bridge report measures the SHIPPED pipeline, not the pdftotext
 * sidecars (which carry glyph-reversed Persian — a harness artifact).
 *
 * Per PDF: scratch/brain-app-qu2/<stem>.json  { file, pages:[BrainPage] }
 *          scratch/brain-app-qu2/texts/<stem>.txt  (app-normalized rawText)
 *
 * Usage: npx tsx scripts/brain_app_extract.mts [pdfDir]
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const here = path.dirname(fileURLToPath(import.meta.url));
const PDF_DIR = process.argv[2] ?? path.join(WS_ROOT, 'samples', 'qu2');
const OUT_DIR = path.join(here, '..', 'scratch', 'brain-app-qu2');
const TEXT_DIR = path.join(OUT_DIR, 'texts');

async function main() {
  const pdfjs: any = await import('pdfjs-dist/legacy/build/pdf.mjs');
  const { normalizeOcrText } = await import('../src/utils/ocrPreprocessor');
  fs.mkdirSync(TEXT_DIR, { recursive: true });

  const pdfs = fs.readdirSync(PDF_DIR).filter((f) => f.toLowerCase().endsWith('.pdf')).sort();
  let ok = 0;
  let fail = 0;
  for (const name of pdfs) {
    const stem = name.replace(/\.pdf$/i, '');
    try {
      const data = new Uint8Array(fs.readFileSync(path.join(PDF_DIR, name)));
      const doc = await pdfjs.getDocument({ data, useSystemFonts: true, isEvalSupported: false }).promise;
      const pages: any[] = [];
      const pageTexts: string[] = [];
      for (let i = 1; i <= doc.numPages; i++) {
        const page = await doc.getPage(i);
        const viewport = page.getViewport({ scale: 1 });
        const pageHeight = viewport.height;
        const pageWidth = viewport.width;

        // shapes FIRST (fonts load into commonObjs for the bold lookups)
        const shapes = await extractShapes(page, pageHeight, pdfjs.OPS);
        const content = await page.getTextContent();
        const fontBold = new Map<string, boolean>();
        const boldOf = async (fontName: string): Promise<boolean> => {
          const hit = fontBold.get(fontName);
          if (hit !== undefined) return hit;
          let bold = false;
          try {
            const f: any = await page.commonObjs.get(fontName);
            if (f) bold = !!f.bold || /bold|black|heavy|titr|lalezar|morvarid|kostar/i.test(String(f.name || ''));
          } catch {
            bold = false;
          }
          fontBold.set(fontName, bold);
          return bold;
        };

        type PendingLine = { text: string; x0: number; x1: number; y0: number; y1: number; y: number; size: number; bold: boolean };
        const pending: PendingLine[] = [];
        for (const item of content.items) {
          if (!('str' in item) || !item.str) continue;
          const x = item.transform[4];
          const yBase = item.transform[5];
          const w = item.width || 0;
          const h = item.height || 10;
          const size = Math.hypot(item.transform[0], item.transform[1]) || h || 10;
          const bold = await boldOf(item.fontName);
          const last = pending[pending.length - 1];
          if (last && Math.abs(yBase - last.y) <= 6) {
            last.text += (last.text.endsWith(' ') ? '' : ' ') + item.str;
            last.x0 = Math.min(last.x0, x);
            last.x1 = Math.max(last.x1, x + w);
            last.y0 = Math.max(last.y0, yBase);
            last.y1 = Math.min(last.y1, yBase - h);
            last.size = Math.max(last.size, size);
            last.bold = last.bold || bold;
          } else {
            pending.push({ text: item.str, x0: x, x1: x + w, y0: yBase, y1: yBase - h, y: yBase, size, bold });
          }
        }

        const brainLines: any[] = [];
        const textLines: string[] = [];
        for (const pl of pending) {
          const t = pl.text.trim();
          if (!t) continue;
          textLines.push(t);
          const bTop = pageHeight - pl.y0;
          const bH = Math.abs(pl.y0 - pl.y1) || pl.size * 1.2 || 10;
          brainLines.push({ text: t, size: pl.size, bold: pl.bold, bbox: [pl.x0, bTop, pl.x1, bTop + bH], page: i - 1 });
        }
        if (textLines.length) pageTexts.push(textLines.join('\n'));
        pages.push({ width: pageWidth, height: pageHeight, hlines: shapes.hlines, rects: shapes.rects, tables: [], lines: brainLines });
      }

      const rawText = normalizeOcrText(pageTexts.join('\n\n'));
      fs.writeFileSync(path.join(OUT_DIR, stem + '.json'), JSON.stringify({ file: name, pages }));
      fs.writeFileSync(path.join(TEXT_DIR, stem + '.txt'), rawText);
      ok++;
      process.stdout.write(`app-geo ok ${name} (${pages.length}p, ${rawText.length} chars)\n`);
    } catch (e: any) {
      fail++;
      console.error(`app-geo FAIL ${name}: ${e?.message || e}`);
    }
  }
  console.log(`\napp-geo: ${ok} ok, ${fail} failed -> ${OUT_DIR}`);
}

/** Mirrors fileExtractor.extractPdfShapes (browser) for the Node harness. */
async function extractShapes(page: any, pageHeight: number, OPS: any): Promise<{ hlines: number[][]; rects: number[][] }> {
  const hlines: number[][] = [];
  const rects: number[][] = [];
  try {
    const ops = await page.getOperatorList();
    const fnArr: number[] = ops.fnArray;
    const argsArr: any[] = ops.argsArray;
    if (!fnArr || fnArr.length > 400_000) return { hlines, rects };
    for (let k = 0; k < fnArr.length; k++) {
      if (fnArr[k] !== OPS.constructPath) continue;
      collectPathPaint(argsArr[k], OPS, hlines, rects, pageHeight);
    }
  } catch (e) {
    console.debug('extractShapes failed:', e);
  }
  return { hlines: hlines.slice(0, 40000), rects: rects.slice(0, 40000) };
}

/** Decode one constructPath (pdf.js v6 flat-triple format, v5 fallback) and
 *  apply its paint rule: stroked horizontal segments -> hlines, filled
 *  rects -> rects (thin ones -> hlines). Coordinates flip to top-down. */
function collectPathPaint(args: any[], OPS: any, hlines: number[][], rects: number[][], pageHeight: number): void {
  const segs: number[][] = [];
  const rcts: number[][] = [];
  if (typeof args[0] === 'number') {
    // pdf.js >= 6: [paintOp, [subpath...], minMax] — the paint is baked in.
    const paintOp: number = args[0];
    if (paintOp === OPS.endPath) return; // unpainted (clip bookkeeping)
    const isStroke = paintOp === OPS.stroke || paintOp === OPS.closeStroke;
    const isFill = paintOp === OPS.fill || paintOp === OPS.eoFill || paintOp === OPS.fillStroke || paintOp === OPS.closeFillStroke || paintOp === OPS.eoFillStroke;
    if (!isStroke && !isFill) return;
    const paths = args[1];
    if (!Array.isArray(paths)) return;
    for (const rec of paths) {
      if (!rec || typeof rec.length !== 'number') continue;
      let i = 0;
      let sx = 0, sy = 0, cx = 0, cy = 0;
      while (i < rec.length) {
        const op = rec[i];
        if (op === 0) { cx = rec[i + 1]; cy = rec[i + 2]; sx = cx; sy = cy; i += 3; } // moveTo
        else if (op === 1) { const nx = rec[i + 1], ny = rec[i + 2]; segs.push([cx, cy, nx, ny]); cx = nx; cy = ny; i += 3; } // lineTo
        else if (op === 2 || op === 3) { i += 7; } // curve (op + 6 coords)
        else if (op === 4) { segs.push([cx, cy, sx, sy]); i += 1; } // closePath
        else break;
      }
    }
    applyPaint(isStroke, isFill, segs, rcts, hlines, rects, pageHeight);
    return;
  }
  // pdf.js 3.x-5.x: [opsArray, coordsArray, minMax] with the paint op as the
  // NEXT operator.
  const pathOps: number[] = args[0];
  const coords: number[] = args[1];
  if (!Array.isArray(pathOps) || !coords) return;
  let ci = 0;
  let sx = 0, sy = 0, cx = 0, cy = 0;
  for (const po of pathOps) {
    if (po === OPS.moveTo) { cx = coords[ci]; cy = coords[ci + 1]; sx = cx; sy = cy; ci += 2; }
    else if (po === OPS.lineTo) { const nx = coords[ci], ny = coords[ci + 1]; segs.push([cx, cy, nx, ny]); cx = nx; cy = ny; ci += 2; }
    else if (po === OPS.rectangle) { const x = coords[ci], y = coords[ci + 1], w2 = coords[ci + 2], h2 = coords[ci + 3]; rcts.push([x, y, x + w2, y + h2]); ci += 4; }
    else if (po === OPS.curveTo || po === OPS.curveTo2 || po === OPS.curveTo3) { ci += 6; }
    else if (po === OPS.closePath) { segs.push([cx, cy, sx, sy]); }
    else return; // unknown inner op: skip
  }
  const paint: number = args[3] ?? -1; // unused in v5 path (paired via caller)
  void paint;
}

function applyPaint(
  isStroke: boolean,
  isFill: boolean,
  segs: number[][],
  rcts: number[][],
  hlines: number[][],
  rects: number[][],
  pageHeight: number,
): void {
  if (isStroke) {
    for (const [x1, y1, x2, y2] of segs) {
      if (Math.abs(y1 - y2) <= 1.5 && Math.abs(x2 - x1) >= 20) {
        hlines.push([Math.min(x1, x2), pageHeight - Math.max(y1, y2), Math.abs(x2 - x1)]);
      }
    }
  } else if (isFill) {
    // v6 fills arrive as moveTo/lineTo/close polygons — use the polygon bbox
    // (exam furniture — bubbles, boxes, shaded rules — is axis-aligned)
    const polys = [...rcts];
    if (segs.length) {
      let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
      for (const [ax, ay, bx, by] of segs) {
        x0 = Math.min(x0, ax, bx); x1 = Math.max(x1, ax, bx);
        y0 = Math.min(y0, ay, by); y1 = Math.max(y1, ay, by);
      }
      polys.push([x0, y0, x1, y1]);
    }
    for (const [rx0, ry0, rx1, ry1] of polys) {
      const w2 = rx1 - rx0, h2 = ry1 - ry0;
      if (h2 <= 2.5 && w2 >= 20) hlines.push([rx0, pageHeight - Math.max(ry0, ry1), w2]);
      else if (w2 > 4 && h2 > 4) rects.push([rx0, pageHeight - Math.max(ry0, ry1), rx1, pageHeight - Math.min(ry0, ry1)]);
    }
  }
}

main();
