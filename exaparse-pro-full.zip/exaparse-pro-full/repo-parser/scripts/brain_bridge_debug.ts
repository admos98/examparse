/**
 * brain_bridge_debug — inspect ONE file's wired parse vs text parse.
 * Usage: npx tsx scripts/brain_bridge_debug.ts <stem> [sectionIndex]
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseExamRawText } from '../src/utils/parserEngine';
import { runLayoutBrain } from '../src/utils/layoutBrain';
import { bridgeBrainResult } from '../src/utils/brainBridge';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const here = path.dirname(fileURLToPath(import.meta.url));
const stem = process.argv[2] || '14050401pm57p5s814';
const brainPath = path.join(here, '..', 'scratch', 'brain-qu2', stem + '.json');
const textPath = path.join(WS_ROOT, 'scratch', 'texts-qu2', stem + '.pdf.txt');

const brainDoc = JSON.parse(fs.readFileSync(brainPath, 'utf8'));
const res = runLayoutBrain(brainDoc, { debug: true });
const bridged = bridgeBrainResult(res);
if (!bridged) {
  console.log('bridge abstained');
  process.exit(0);
}
const text = fs.readFileSync(textPath, 'utf8');
const opts = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const;
const doc = parseExamRawText(text, stem + '.pdf', opts, bridged.blocks);

console.log('=== brain blocks ===');
for (const b of bridged.blocks) {
  const q = b.text.split(/\r?\n/).length;
  console.log(`block ${b.rowId.padEnd(4)} cat=${b.category.padEnd(11)} mark=${String(b.mark).padStart(4)} lines=${String(q).padStart(3)} conf=${b.brain?.confidence} kind=${b.brain?.boundaryKind} | ${b.text.split(/\r?\n/)[0].slice(0, 60)}`);
}
console.log('\n=== wired parse sections ===');
for (const s of doc.sections) {
  console.log(`sec ${s.rowId.padEnd(6)} cat=${(s.majorCategory || '').padEnd(11)} markTotal=${String(s.markTotal).padStart(5)} questions=${s.questions.length}`);
}
console.log(`total: sections=${doc.sections.length} questions=${doc.totalQuestions} marks=${doc.totalMarks}`);
console.log('brainReport:', JSON.stringify(bridged.report.mode), 'confirmed', bridged.report.confirmed, '/', bridged.report.sections, 'sumMarks', bridged.report.sumMarks);
