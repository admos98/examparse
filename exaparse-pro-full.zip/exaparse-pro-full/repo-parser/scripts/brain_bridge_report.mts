/**
 * brain_bridge_report — the HONEST end-to-end measurement of the wired path.
 *
 * For every qu2 GT file with a brain input: geometry -> brain -> bridge ->
 * parseExamRawText(preSplit) -> goldenGrade, side by side with today's
 * text-only path on the same text. REPORT ONLY (non-gating): it shows where
 * the brain-first architecture stands corpus-wide without touching the strict
 * gate (which stays on the text splitters by construction).
 *
 * Usage: npx tsx scripts/brain_bridge_report.mts
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { runLayoutBrain } from '../src/utils/layoutBrain';
import { bridgeBrainResult } from '../src/utils/brainBridge';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
// APP-DOMAIN harness (scripts/brain_app_extract.mts): geometry + text built
// by the SAME pdf.js code path the browser runs, so this measures the SHIPPED
// pipeline (the old pdftotext sidecars carry glyph-reversed Persian — a
// harness artifact, not an app defect).
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2');
const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

function main() {
  if (!fs.existsSync(GT_DIR)) {
    console.log('(bridge report: no GT dir — skipped)');
    return;
  }
  const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  let textWins = 0;
  let brainWins = 0;
  let ties = 0;
  let noBrain = 0;
  const rows: { file: string; text: number; brain: number; delta: number; blocks: number; mode: string }[] = [];
  for (const f of files) {
    const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
    const stem = gt.file.replace(/\.pdf$/i, '');
    const textPath = path.join(APP_TEXT_DIR, stem + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const text = fs.readFileSync(textPath, 'utf8');
    const opts = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const;

    // Path A (status quo): text splitters only, on the app-domain rawText
    const docA = parseExamRawText(text, gt.file, opts);
    const a = gradeParse(docA, gt);

    // Path B (wired): brain blocks when the geometry confirms something
    const brainPath = path.join(BRAIN_DIR, stem + '.json');
    let brain = -1;
    let mode = 'none';
    let blockCount = 0;
    if (fs.existsSync(brainPath)) {
      try {
        const brainDoc = JSON.parse(fs.readFileSync(brainPath, 'utf8'));
        const res = runLayoutBrain(brainDoc);
        const bridged = bridgeBrainResult(res);
        if (bridged) {
          const docB = parseExamRawText(text, gt.file, opts, bridged.blocks);
          const b = gradeParse(docB, gt);
          brain = b.score;
          mode = bridged.report.mode;
          blockCount = bridged.blocks.length;
        } else {
          brain = a.score; // abstain -> identical text path
          mode = 'abstained';
        }
      } catch (e) {
        brain = a.score;
        mode = 'failed';
      }
    } else {
      noBrain++;
      brain = a.score;
    }

    const d = Math.round((brain - a.score) * 10) / 10;
    if (d > 0) brainWins++;
    else if (d < 0) textWins++;
    else ties++;
    rows.push({ file: gt.file, text: a.score, brain, delta: d, blocks: blockCount, mode });
  }
  for (const r of rows) {
    const arrow = r.delta > 0 ? 'UP  ' : r.delta < 0 ? 'DOWN' : '    ';
    console.log(`bridge ${arrow} text=${String(r.text.toFixed(1)).padStart(6)} brain=${String(r.brain.toFixed(1)).padStart(6)} delta=${String(r.delta.toFixed(1)).padStart(6)} blocks=${String(r.blocks).padStart(3)} mode=${r.mode.padEnd(9)} ${r.file}`);
  }
  console.log(`\nbridge report: brain-better ${brainWins} • text-better ${textWins} • ties ${ties} • (no brain input: ${noBrain})`);
  const avgText = rows.reduce((s, r) => s + r.text, 0) / Math.max(1, rows.length);
  const avgBrain = rows.reduce((s, r) => s + r.brain, 0) / Math.max(1, rows.length);
  console.log(`bridge report: corpus average text=${avgText.toFixed(1)}% brain-wired=${avgBrain.toFixed(1)}%`);
  const perfect = rows.filter((r) => r.brain === 100).length;
  console.log(`bridge report: files at exactly 100% via brain-wired path: ${perfect}`);
  console.log(
    `\nSHIP POSTURE: the brain DRIVES by default (Wave G5): geometry-verified boundaries are the section\n` +
      `split whenever the drive gate passes — full confirmation + coverage + marks closure. Everything else\n` +
      `abstains to the text splitters with the reason flagged. Gate contract: worst case = status quo.\n` +
      `'Layout brain drives' on ParseScreen is now the opt-OUT.`
  );
}

main();
