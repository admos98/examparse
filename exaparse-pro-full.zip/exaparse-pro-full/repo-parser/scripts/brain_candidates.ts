/**
 * brain_candidates — candidate-level debug dump for the layout brain.
 * Prints the fused boundary events and the candidate sections BEFORE the
 * COMMIT merges, so placement bugs (strip-merge targets, key remnants) are
 * visible at the source.
 * Usage: npx tsx scripts/brain_candidates.ts <stem> [...]
 */
import { runLayoutBrain, BrainDoc } from '../src/utils/layoutBrain';
import * as fs from 'fs';
import * as path from 'path';

const stems = process.argv.slice(2);
if (!stems.length) {
  console.error('usage: npx tsx scripts/brain_candidates.ts <stem> [...]');
  process.exit(1);
}

for (const stem of stems) {
  const p = path.join('scratch/brain-qu2', stem + '.json');
  if (!fs.existsSync(p)) {
    console.log(`${stem}: no brain input`);
    continue;
  }
  const raw = JSON.parse(fs.readFileSync(p, 'utf8')) as BrainDoc;
  const res = runLayoutBrain(raw, { debug: true });
  const dbg = res.__debug!;
  console.log(`\n===== ${stem} — events (${dbg.events.length})`);
  for (const e of dbg.events) {
    const rows = e.rows?.length ? ` rows=[${e.rows.map((r) => r.letter + (r.mark !== undefined ? ':' + r.mark : '')).join(',')}]` : '';
    console.log(
      `  ${e.kind.padEnd(9)} pg${e.page + 1} y=${String(e.y).padStart(4)}` +
        `${e.letter ? ` ${e.letter}` : ''}${e.mark !== undefined ? ` mark=${e.mark}` : ''}${rows}` +
        `${e.headerText && e.kind === 'header' ? ` "${e.headerText.slice(0, 30)}"` : ''} | ${e.note}`
    );
  }
  console.log(`--- candidates (${dbg.candidates.length}); dropped=[${dbg.dropped.join(',')}]`);
  for (const c of dbg.candidates) {
    const ev = c.evidence;
    const flags = `${ev.header ? 'H' : '.'}${ev.letter ? 'L' : '.'}${ev.mark ? 'M' : '.'}${ev.table ? 'T' : '.'}${
      ev.ladder >= 3 ? 'Q' : '.'
    }${ev.rules ? 'R' : '.'}${ev.boxes ? 'B' : '.'}`;
    const rows = c.rows.length ? ` rows=[${c.rows.map((r) => r.letter + (r.mark !== undefined ? ':' + r.mark : '')).join(',')}]` : '';
    console.log(
      `  #${String(c.index).padStart(2, '0')} ${c.confidence.toFixed(2)} [${flags}]${rows} pg${c.page + 1} n=${c.lineCount}` +
        ` subj=${c.subject ?? '-'} | ${c.note.slice(0, 70)}`
    );
  }
}
