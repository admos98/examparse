/**
 * brain_corpus — run the layout brain over ALL brain-qu2 inputs and emit a
 * corpus-wide uncertainty report.
 *
 * Per file: confirmed vs fallback sections, marks cross-check (sumOfMarks vs
 * printedTotal), and the brain's own audit notes. Aggregates the corpus into
 * three postures: COMMIT (>=1 confirmed section), MIXED, ABSTAIN (all fb).
 *
 * Usage: npx tsx scripts/brain_corpus.ts   -> scratch/brain-qu2/report.json
 */
import { runLayoutBrain, BrainDoc } from '../src/utils/layoutBrain';
import * as fs from 'fs';
import * as path from 'path';

const dir = 'scratch/brain-qu2';
const stems = fs
  .readdirSync(dir)
  .filter((f) => f.endsWith('.json') && f !== 'report.json')
  .map((f) => f.replace(/\.json$/, ''))
  .sort();

interface FileReport {
  file: string;
  posture: 'COMMIT' | 'MIXED' | 'ABSTAIN';
  sections: number;
  confirmed: number;
  fallbacks: number;
  sumMarks: number;
  printedTotal?: number;
  marksOk?: boolean;
  notes: string[];
  outline: string[];
}

const reports: FileReport[] = [];
for (const stem of stems) {
  const raw = JSON.parse(fs.readFileSync(path.join(dir, stem + '.json'), 'utf8')) as BrainDoc;
  const res = runLayoutBrain(raw);
  const confirmed = res.sections.filter((s) => s.confirmed).length;
  const fallbacks = res.sections.length - confirmed;
  const posture = confirmed === 0 ? 'ABSTAIN' : fallbacks === 0 ? 'COMMIT' : 'MIXED';
  const marksOk =
    res.stats.printedTotal !== undefined && res.stats.sumOfMarks > 0
      ? Math.abs(res.stats.sumOfMarks - res.stats.printedTotal) <= 0.51
      : undefined;
  reports.push({
    file: stem,
    posture,
    sections: res.sections.length,
    confirmed,
    fallbacks,
    sumMarks: res.stats.sumOfMarks,
    printedTotal: res.stats.printedTotal,
    marksOk,
    notes: res.notes,
    outline: res.sections.map(
      (s) =>
        `${s.confirmed ? 'OK' : 'fb'} ${s.subject ?? s.headerText?.slice(0, 22) ?? '(unlabeled)'}` +
        (s.rows.length ? `[${s.rows.map((r) => r.letter).join('')}]` : '') +
        `@pg${s.pageStart + 1}`
    ),
  });
}

const nCommit = reports.filter((r) => r.posture === 'COMMIT').length;
const nMixed = reports.filter((r) => r.posture === 'MIXED').length;
const nAbstain = reports.filter((r) => r.posture === 'ABSTAIN').length;
const marksChecked = reports.filter((r) => r.marksOk !== undefined);
const marksGood = marksChecked.filter((r) => r.marksOk).length;

console.log(`\n===== layout brain — corpus report (${stems.length} files)`);
console.log(`  COMMIT  (>=1 confirmed section): ${nCommit}`);
console.log(`  MIXED   (some confirmed, some fb): ${nMixed}`);
console.log(`  ABSTAIN (all fallback, flagged):  ${nAbstain}`);
console.log(`  marks cross-check ok: ${marksGood}/${marksChecked.length} (where a printed total exists)`);
console.log('');
for (const r of reports) {
  const mark =
    r.posture === 'COMMIT' ? '++' : r.posture === 'MIXED' ? '+-' : '--';
  const m = r.printedTotal !== undefined ? ` marks=${r.sumMarks}/${r.printedTotal}${r.marksOk ? 'v' : 'X'}` : '';
  console.log(`  ${mark} ${r.file.padEnd(24)} sec=${String(r.confirmed).padStart(2)}+${String(r.fallbacks).padStart(2)}${m}`);
  if (r.posture !== 'ABSTAIN') console.log(`       ${r.outline.join(' | ').slice(0, 160)}`);
  for (const n of r.notes.slice(0, 4)) console.log(`       note: ${n.slice(0, 120)}`);
}

fs.writeFileSync(path.join(dir, 'report.json'), JSON.stringify(reports, null, 2));
console.log(`\n  -> ${path.join(dir, 'report.json')}`);
