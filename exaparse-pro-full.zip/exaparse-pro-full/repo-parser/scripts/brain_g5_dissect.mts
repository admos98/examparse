/**
 * brain_g5_dissect — deep per-file dissection of the wired brain path.
 * Prints: GT sections, bridged blocks, parsed sections, grade issues,
 * and the text-path sections for comparison.
 * Usage: npx tsx scripts/brain_g5_dissect.mts <stem> [stem2 ...]
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { runLayoutBrain } from '../src/utils/layoutBrain';
import { bridgeBrainResult } from '../src/utils/brainBridge';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2');
const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

function brief(s: string, n = 70) {
  const t = s.replace(/\n/g, '⏎').trim();
  return t.length > n ? t.slice(0, n) + '…' : t;
}

function main() {
  for (const stem of process.argv.slice(2)) {
    const gtPath = path.join(GT_DIR, stem + '-pdf.json');
    const gt = JSON.parse(fs.readFileSync(gtPath, 'utf8'));
    const text = fs.readFileSync(path.join(APP_TEXT_DIR, stem + '.txt'), 'utf8');
    console.log(`\n================ ${stem} ================`);
    console.log(`GT: ${gt.sections.length} sections: ${gt.sections.map((s: any) => `${s.id}(${s.cat},${s.mark})`).join(' ')} totalMarks=${gt.totalMarks}`);

    const opts = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const;
    const docA = parseExamRawText(text, gt.file, opts);
    const a = gradeParse(docA, gt);
    console.log(`TEXT path: score=${a.score} splitters=${(docA as any).meta?.splitter ?? '?'} sections=${docA.sections.map((s) => `${s.rowId}[${s.majorCategory[0]}]m${s.markTotal}q${s.questions.length}`).join(' ')}`);

    const brainDoc = JSON.parse(fs.readFileSync(path.join(BRAIN_DIR, stem + '.json'), 'utf8'));
    const res = runLayoutBrain(brainDoc);
    const bridged = bridgeBrainResult(res);
    if (!bridged) { console.log('BRIDGE: abstained'); continue; }
    console.log(`BRAIN: mode=${bridged.report.mode} confirmed=${bridged.report.confirmed}/${bridged.report.sections} sumMarks=${bridged.report.sumMarks}`);
    for (const b of bridged.blocks) {
      console.log(`  block ${b.rowId.padEnd(12)} mark=${String(b.mark).padEnd(5)} conf=${b.brain ? b.brain.confidence.toFixed(2) : '-'} ${b.brain?.boundaryKind ?? ''} lines=${b.text.split('\n').length} "${brief(b.text)}"`);
    }
    const docB = parseExamRawText(text, gt.file, opts, bridged.blocks);
    const b = gradeParse(docB, gt);
    console.log(`BRAIN path: score=${b.score} sections=${docB.sections.map((s) => `${s.rowId}[${s.majorCategory[0]}]m${s.markTotal}q${s.questions.length}`).join(' ')}`);
    for (const iss of b.issues.slice(0, 25)) console.log(`   issue: ${iss}`);
    if (b.issues.length > 25) console.log(`   … +${b.issues.length - 25} more`);
  }
}
main();
