import fs from 'node:fs';
import path from 'node:path';
import { runLayoutBrain } from '../src/utils/layoutBrain';
import { bridgeBrainResult } from '../src/utils/brainBridge';
import { canonicalize } from '../src/utils/textCanonical';
import { normalizeOcrText } from '../src/utils/ocrPreprocessor';
import { PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const stem = process.argv[2];
const text = fs.readFileSync(path.join(PKG_ROOT, 'scratch/brain-app-qu2/texts', stem + '.txt'), 'utf8');
const canon = canonicalize(text);
const normText = normalizeOcrText(canon.text);
const brainDoc = JSON.parse(fs.readFileSync(path.join(PKG_ROOT, 'scratch/brain-app-qu2', stem + '.json'), 'utf8'));
const res = runLayoutBrain(brainDoc);
const bridged = bridgeBrainResult(res);
if (!bridged) { console.log('abstained'); process.exit(0); }
for (const b of bridged.blocks) {
  const probeRaw = b.text.trim().slice(0, 60);
  const probe = normalizeOcrText(canonicalize(probeRaw).text).trim();
  let idx = normText.indexOf(probe);
  let how = 'full';
  if (idx < 0 && probe.length > 20) { idx = normText.indexOf(probe.slice(0, 20)); how = 'short'; }
  console.log(`${b.rowId.padEnd(8)} idx=${String(idx).padStart(6)} ${how} probe="${probe.slice(0, 40).replace(/\n/g, '⏎')}"`);
}
