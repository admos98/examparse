import fs from 'node:fs';
import path from 'node:path';
import { runLayoutBrain } from '../src/utils/layoutBrain';
import { PKG_ROOT } from '../scripts-batch/wsPaths.mts';
const stem = process.argv[2];
const brainDoc = JSON.parse(fs.readFileSync(path.join(PKG_ROOT, 'scratch/brain-app-qu2', stem + '.json'), 'utf8'));
const res = runLayoutBrain(brainDoc);
for (const s of res.sections) {
  console.log(
    `sec#${s.index} ${s.boundaryKind?.padEnd(8)} conf=${s.confidence.toFixed(2)}${s.confirmed ? ' OK' : '  '}${s.demoted ? ' DEMOTED' : ''} subj=${s.subject ?? '-'} rows=[${s.rows.map((r) => r.letter + (r.mark !== undefined ? ':' + r.mark : '') + (r.lines?.length ? `(${r.lines.length}L)` : '')).join(',')}] lines=${s.lines.length} pg${s.pageStart}-${s.pageEnd} notes=${s.notes.slice(0, 2).join(' | ').slice(0, 90)}`
  );
}
console.log('fallbacks:', res.fallbacks.length, 'stats:', JSON.stringify(res.stats));
