import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { runLayoutBrain } from '../src/utils/layoutBrain';
import { bridgeBrainResult } from '../src/utils/brainBridge';
import { PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const stem = process.argv[2];
const rowId = process.argv[3];
const text = fs.readFileSync(path.join(PKG_ROOT, 'scratch/brain-app-qu2/texts', stem + '.txt'), 'utf8');
const opts = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const;
const docA = parseExamRawText(text, stem + '.pdf', opts);
const secA = docA.sections.find((s) => s.rowId === rowId);
console.log('=== TEXT path section', rowId, '===');
console.log(secA ? JSON.stringify(secA.questions.map((q) => [q.number, q.type])) : 'missing');

const brainDoc = JSON.parse(fs.readFileSync(path.join(PKG_ROOT, 'scratch/brain-app-qu2', stem + '.json'), 'utf8'));
const res = runLayoutBrain(brainDoc);
const bridged = bridgeBrainResult(res);
if (!bridged) { console.log('abstained'); process.exit(0); }
const docB = parseExamRawText(text, stem + '.pdf', opts, bridged.blocks);
const secB = docB.sections.find((s) => s.rowId === rowId);
console.log('=== BRAIN path section', rowId, '===');
console.log(secB ? JSON.stringify(secB.questions.map((q) => [q.number, q.type])) : 'missing');
const blk = bridged.blocks.find((b) => b.rowId === rowId);
console.log('--- brain block text ---');
console.log(blk ? blk.text : 'no block');
