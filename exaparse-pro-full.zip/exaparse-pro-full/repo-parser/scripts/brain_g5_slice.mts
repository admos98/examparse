import fs from 'node:fs';
import path from 'node:path';
import { runLayoutBrain } from '../src/utils/layoutBrain';
import { bridgeBrainResult } from '../src/utils/brainBridge';
import { canonicalize } from '../src/utils/textCanonical';
import { normalizeOcrText } from '../src/utils/ocrPreprocessor';
import { PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const stem = '14050319p566h5f982';
const text = fs.readFileSync(path.join(PKG_ROOT, 'scratch/brain-app-qu2/texts', stem + '.txt'), 'utf8');
const normText = normalizeOcrText(canonicalize(text).text);
const brainDoc = JSON.parse(fs.readFileSync(path.join(PKG_ROOT, 'scratch/brain-app-qu2', stem + '.json'), 'utf8'));
const bridged = bridgeBrainResult(runLayoutBrain(brainDoc))!;
const idxs = bridged.blocks.map((b) => {
  const probe = normalizeOcrText(canonicalize(b.text.trim().slice(0, 60)).text).trim();
  let idx = normText.indexOf(probe);
  if (idx < 0 && probe.length > 20) idx = normText.indexOf(probe.slice(0, 20));
  return { b, idx };
}).filter((x) => x.idx >= 0).sort((a, b) => a.idx - b.idx);
for (let i = 0; i < idxs.length; i++) {
  const start = idxs[i].idx;
  const next = i + 1 < idxs.length ? idxs[i + 1].idx : normText.length;
  const slice = normText.slice(start, next);
  if (idxs[i].b.rowId === 'B') {
    console.log('--- B slice ---');
    console.log(JSON.stringify(slice));
  }
}
