import { parseExamRawText } from '../src/utils/parserEngine';
const opts = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const;
const base = `B) Match the definitions with the words. One word is extra.
7. a few a) relating to one country
8. solve b) a small number of people and things
9. domestic c) to find an answer to a problem
10. defend d) to protect someone or something from danger
e) to stop doing something
`;
const variants: [string, string][] = [
  ['no trailing digits', base],
  ['trailing 2', base + '2\n'],
  ['trailing 2 3', base + '2\n3\n'],
];
for (const [name, text] of variants) {
  const doc = parseExamRawText(text, 'v.pdf', opts);
  const sec = doc.sections[0];
  console.log(name, '->', JSON.stringify(sec?.questions.map((q) => [q.number, q.type])), 'cat', sec?.majorCategory);
}
