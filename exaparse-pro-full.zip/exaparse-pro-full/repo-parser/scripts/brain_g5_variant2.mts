import { parseExamRawText } from '../src/utils/parserEngine';
const opts = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const;
const stamp = 'محل مهر یا امضاء مدیر\nwww-kanoon-ir\n';
const g = `G) choose the correct answer.
25. Our ………… teacher talks for hours.
a) history old boring b) boring old history
c) old history boring d) boring history old
26. All foreign passengers……………have their passport at the airport.
a) must b) can c) should d) could
27. Maryam's brother did the experiment…………..
a) ourselves b) herself c) themselves d) himself
28. Always I go to the park ...... the sunset to walk and exercise.
a) in b) at c) to d) on
29. He was listening to the music while he ...... home.
a) drives b) drove c) was driving d) is driving
30. When Amir ……….. the question, he…………….it at once.
a) saw – answered b) was seeing – answered
c) saw – was answering d) was seeing – was answering
`;
for (const [name, text] of [['stamp', stamp], ['G slice', g]] as const) {
  const doc = parseExamRawText(text, name + '.pdf', opts);
  for (const s of doc.sections)
    console.log(name, '->', s.rowId, s.majorCategory, 'q:', s.questions.map((q) => [q.number, q.stem.slice(0, 25)]));
}
