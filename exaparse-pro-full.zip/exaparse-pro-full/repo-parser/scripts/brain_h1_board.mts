/**
 * brain_h1_board — Wave H1 campaign diagnosis board.
 *
 * For every qu2 GT file, side-by-side measurement of:
 *   A. text path score + issue buckets          (today's status quo)
 *   B. brain-wired score, drive gate honored    (shipped behavior)
 *   C. brain FORCED to emit blocks (gate bypass — DIAGNOSTIC ONLY, measures
 *      what a partial drive WOULD score with the current perception)
 * plus the brain's own internals (posture, coverage, marks closure) and the
 * drive-gate refusal note. Output: console table + scratch/h1-board.json.
 *
 * Purpose: pick the highest-leverage GENERAL fixes on the road to 90+% on
 * every file (user charter: general rules, not per-file GT grinding).
 *
 * Usage: npx tsx scripts/brain_h1_board.mts
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { runLayoutBrain } from '../src/utils/layoutBrain';
import { bridgeBrainResult } from '../src/utils/brainBridge';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2');
const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

const OPTS = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const;

interface Buckets {
  misalign: number;
  count: number;
  type: number;
  category: number;
  marks: number;
}
function bucketIssues(issues: string[]): Buckets {
  const b: Buckets = { misalign: 0, count: 0, type: 0, category: 0, marks: 0 };
  for (const iss of issues) {
    const m = String(iss);
    if (m.includes('q# at pos')) b.misalign++;
    else if (/count: got/.test(m)) b.count++;
    else if (/type: got/.test(m)) b.type++;
    else if (/category: got/.test(m)) b.category++;
    else if (/totalMarks/.test(m)) b.marks++;
  }
  return b;
}

function main() {
  const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  const rows: any[] = [];
  for (const f of files) {
    const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
    const stem = gt.file.replace(/\.pdf$/i, '');
    const textPath = path.join(APP_TEXT_DIR, stem + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const text = fs.readFileSync(textPath, 'utf8');

    // A. text path
    const docA = parseExamRawText(text, gt.file, OPTS);
    const a = gradeParse(docA, gt);
    const aBuckets = bucketIssues(a.issues as any);

    // B/C. brain
    const brainPath = path.join(BRAIN_DIR, stem + '.json');
    let forced = -1;
    let gated = -1;
    let mode = 'none';
    let gateNote = '';
    let confirmed = 0;
    let fallbacks = 0;
    let sections = 0;
    let coverage = -1;
    let sumMarks = 0;
    let printedTotal: number | undefined;
    let subjects = '';
    if (fs.existsSync(brainPath)) {
      try {
        const brainDoc = JSON.parse(fs.readFileSync(brainPath, 'utf8'));
        const res = runLayoutBrain(brainDoc);
        sections = res.sections.length;
        confirmed = res.sections.filter((s) => s.confirmed && !s.demoted).length;
        fallbacks = res.fallbacks.length;
        sumMarks = res.stats.sumOfMarks;
        printedTotal = res.stats.printedTotal;
        subjects = res.sections
          .map((s) => (s.confirmed ? (s.subject ?? s.headerText ?? '?').slice(0, 12) : `[fb]${(s.subject ?? s.headerText ?? '?').slice(0, 10)}`))
          .join(' | ');

        const bridgedGated = bridgeBrainResult(res);
        if (bridgedGated) {
          const docB = parseExamRawText(text, gt.file, OPTS, bridgedGated.blocks);
          const b = gradeParse(docB, gt);
          gated = b.score;
          mode = bridgedGated.report.mode;
        } else {
          gated = a.score;
          mode = 'abstained';
          gateNote = res.notes.find((n) => n.startsWith('drive gate:')) ?? res.notes.slice(-1)[0] ?? '';
          // reconstruct coverage from the note
          const cm = gateNote.match(/coverage (\d+)%/);
          if (cm) coverage = Number(cm[1]);
        }

        // C. forced (diagnostic): bypass the gate, keep full-coverage emission
        res.notes.length = 0;
        const bridgedForced = bridgeBrainResult(res, { force: true });
        if (bridgedForced) {
          const docC = parseExamRawText(text, gt.file, OPTS, bridgedForced.blocks);
          const c = gradeParse(docC, gt);
          forced = c.score;
          const cm = gateNote.match(/coverage (\d+)%/);
          if (coverage < 0 && cm) coverage = Number(cm[1]);
          if (!gateNote) {
            gateNote = 'gate passed';
          }
        } else {
          forced = a.score; // nothing confirmed at all
          if (!gateNote) gateNote = 'nothing confirmed';
        }
      } catch (e) {
        gateNote = `brain failed: ${String(e).slice(0, 80)}`;
      }
    } else {
      gateNote = 'no brain sidecar';
    }

    rows.push({
      file: gt.file,
      text: Math.round(a.score * 10) / 10,
      gated: Math.round(gated * 10) / 10,
      forced: Math.round(forced * 10) / 10,
      mode,
      confirmed,
      fallbacks,
      sections,
      coverage,
      sumMarks,
      printedTotal,
      gateNote: gateNote.slice(0, 160),
      subjects: subjects.slice(0, 200),
      aBuckets,
      issues: a.issues.length,
      total: a.total,
    });
  }

  // console table sorted by text score (worst first)
  console.log('file | text | gated | FORCED | conf/fb/sec | cov% | marks/printed | gate note');
  for (const r of rows) {
    const mk = r.printedTotal !== undefined ? `${r.sumMarks}/${r.printedTotal}` : `${r.sumMarks}/-`;
    console.log(
      `${r.file} | ${r.text} | ${r.gated} | ${r.forced} | ${r.confirmed}/${r.fallbacks}/${r.sections} | ${r.coverage} | ${mk} | ${r.gateNote.slice(0, 90)}`,
    );
  }

  const n = rows.length;
  const avg = (k: 'text' | 'gated' | 'forced') => Math.round((rows.reduce((s, r) => s + r[k], 0) / n) * 10) / 10;
  console.log(`\ncorpus averages over ${n} GT files: text=${avg('text')}% gated=${avg('gated')}% FORCED=${avg('forced')}%`);
  const forcedBetter = rows.filter((r) => r.forced > r.text + 0.5).length;
  const forcedWorse = rows.filter((r) => r.forced < r.text - 0.5).length;
  console.log(`forced-better: ${forcedBetter}  forced-worse: ${forcedWorse}  ties: ${n - forcedBetter - forcedWorse}`);

  // bucket totals (text path)
  const tot: Buckets = { misalign: 0, count: 0, type: 0, category: 0, marks: 0 };
  for (const r of rows) for (const k of Object.keys(tot) as (keyof Buckets)[]) tot[k] += r.aBuckets[k];
  console.log(`text-path issue buckets: misalign=${tot.misalign} count=${tot.count} type=${tot.type} category=${tot.category} marks=${tot.marks}`);

  fs.mkdirSync(path.join(PKG_ROOT, 'scratch'), { recursive: true });
  fs.writeFileSync(path.join(PKG_ROOT, 'scratch', 'h1-board.json'), JSON.stringify(rows, null, 1));
  console.log('board -> scratch/h1-board.json');
}

main();
