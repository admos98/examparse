/**
 * brain_h2_dump — side-by-side dump of GT vs parse for one file's sections.
 * Usage: npx tsx scripts/brain_h2_dump.mts <file-substring> [sectionId...]
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-qu2');
const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');
const filter = process.argv[2] || '';
const onlySecs = process.argv.slice(3);

const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json') && f.includes(filter));
for (const f of files) {
  const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
  const stem = gt.file.replace(/\.pdf$/i, '');
  const textPath = path.join(APP_TEXT_DIR, stem + '.txt');
  if (!fs.existsSync(textPath)) continue;
  const text = fs.readFileSync(textPath, 'utf8');
  const doc = parseExamRawText(text, gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });

  const gts = gt.sections.filter((s: any) => !onlySecs.length || onlySecs.includes(String(s.id)));
  const parses = doc.sections.filter((s) => !onlySecs.length || onlySecs.includes(String(s.rowId)));
  console.log(`\n########## ${gt.file} ##########`);
  for (const s of gts) {
    console.log(`GT   id=${s.id} cat=${s.cat} mark=${s.mark} qs=${JSON.stringify(s.qs.map((q: any) => [q.n, q.t]))}`);
  }
  for (const s of parses) {
    console.log(`GOT  id=${s.rowId} cat=${s.majorCategory} mark=${s.markTotal} qs=${JSON.stringify(s.questions.map((q: any) => [q.number, q.type]))}`);
  }
}
