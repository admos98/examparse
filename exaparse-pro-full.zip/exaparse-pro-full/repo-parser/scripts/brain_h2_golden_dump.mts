import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';
const gtFile = process.argv[2] || '10th-first-pdf.json';
const gt = JSON.parse(fs.readFileSync(path.join(WS_ROOT, 'scratch/gt', gtFile), 'utf8'));
const tp = path.join(WS_ROOT, 'scratch/texts', gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
const doc = parseExamRawText(fs.readFileSync(tp, 'utf8'), gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
for (const s of doc.sections) console.log(`GOT id=${s.rowId} cat=${s.majorCategory} mark=${s.markTotal} nq=${s.questions.length} qs=${s.questions.slice(0,6).map(q=>q.number)}`);
