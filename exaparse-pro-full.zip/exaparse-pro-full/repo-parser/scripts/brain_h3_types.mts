/**
 * brain_h3_types — for the top type-confusion pairs, dump the section's
 * printed instructions so the GENERAL cue table can be extended.
 * Usage: npx tsx scripts/brain_h3_types.mts [pair-filter e.g. fill_blank|short_answer]
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-qu2');
const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');
const filter = process.argv[2] || '';

const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
const seen = new Map<string, string[]>();
for (const f of files) {
  const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
  const stem = gt.file.replace(/\.pdf$/i, '');
  const textPath = path.join(APP_TEXT_DIR, stem + '.txt');
  if (!fs.existsSync(textPath)) continue;
  const doc = parseExamRawText(fs.readFileSync(textPath, 'utf8'), gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  const { issues } = gradeParse(doc, gt);
  for (const iss of issues as string[]) {
    const m = iss.match(/^(\S+) q(\d+) type: got (\w+) want (\w+)$/);
    if (!m) continue;
    const [, secId, , got, want] = m;
    if (filter && !(got.includes(filter) || want.includes(filter))) continue;
    const key = `${got} → ${want}`;
    if ((seen.get(key)?.length ?? 0) >= 4) continue;
    const sec = doc.sections.find((s) => s.rowId === secId);
    if (!sec) continue;
    const instr = `${sec.persianInstruction ?? ''} ~~ ${sec.englishInstruction ?? ''}`.slice(0, 150);
    const q = sec.questions[0];
    const stemTxt = (q?.stem ?? '').slice(0, 80);
    if (!seen.has(key)) seen.set(key, []);
    seen.get(key)!.push(`${gt.file} [${secId}] instr="${instr}" q1stem="${stemTxt}"`);
  }
}
for (const [k, arr] of [...seen.entries()].sort((a, b) => b[1].length - a[1].length)) {
  console.log(`\n=== ${k} ===`);
  for (const x of arr) console.log(`  ${x}`);
}
