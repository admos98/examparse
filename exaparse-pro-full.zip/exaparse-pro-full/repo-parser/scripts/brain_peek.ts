/**
 * brain_peek — run the layout brain on brain-qu2 JSONs and print the fused
 * section model with evidence receipts.
 * Usage: npx tsx scripts/brain_peek.ts [stem ...]   (default: pm57p5s814)
 */
import { runLayoutBrain, BrainDoc } from '../src/utils/layoutBrain';
import * as fs from 'fs';
import * as path from 'path';

const stems = process.argv.slice(2);
const list = stems.length ? stems : ['14050401pm57p5s814'];

for (const stem of list) {
  const p = path.join('scratch/brain-qu2', stem + '.json');
  if (!fs.existsSync(p)) {
    console.log(`${stem}: no brain input (build it first)`);
    continue;
  }
  const raw = JSON.parse(fs.readFileSync(p, 'utf8')) as BrainDoc;
  const res = runLayoutBrain(raw);
  const st = res.stats;
  console.log(
    `\n===== ${stem}\n  body=${st.bodySize} headers=${st.headerCount} letters=${st.letterCount} ` +
      `marksTables=${st.marksTables} sumMarks=${st.sumOfMarks}` +
      (st.printedTotal !== undefined ? ` printedTotal=${st.printedTotal}` : '')
  );
  if (res.notes.length) for (const n of res.notes) console.log(`  note: ${n}`);
  for (const s of res.sections) {
    const ev = s.evidence;
    const flags = `${ev.header ? 'H' : '.'}${ev.letter ? 'L' : '.'}${ev.mark ? 'M' : '.'}${ev.table ? 'T' : '.'}${
      ev.ladder >= 3 ? 'Q' : '.'
    }${ev.rules ? 'R' : '.'}${ev.boxes ? 'B' : '.'}`;
    const rows = s.rows.length
      ? ` rows=${s.rows.map((r) => r.letter + (r.mark !== undefined ? ':' + r.mark : '')).join(',')}`
      : '';
    const first = (s.headerText ?? s.lines[0]?.text ?? '')
      .replace(/\s+/g, ' ')
      .slice(0, 46);
    console.log(
      `  #${String(s.index).padStart(2, '0')} ${s.confirmed ? 'OK ' : 'fb '} ${s.confidence.toFixed(2)} [${flags}]${rows} ` +
        `pg${s.pageStart + 1}-${s.pageEnd + 1} n=${s.lines.length} | ${first}`
    );
  }
}
