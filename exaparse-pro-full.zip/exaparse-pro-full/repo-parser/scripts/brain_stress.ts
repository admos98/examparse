/**
 * brain_stress — synthetic layout-combination suite for the layout brain.
 *
 * The user charter: the brain must be familiar with ALL layout combinations,
 * work on NEW exams, and flag uncertainty instead of guessing. These tests
 * encode that contract: for each synthetic layout family, assert the brain's
 * separation posture (confirmed sections, letter/marks placement, key/copy
 * detection, abstention). Deterministic, no corpus data, no GT.
 *
 * Run: npx tsx scripts/brain_stress.ts   (exit 1 on any failure)
 */
import { runLayoutBrain, BrainDoc, BrainLine, BrainTable, BrainResult } from '../src/utils/layoutBrain';

// ---------------------------------------------------------------- builders

let uid = 0;
const L = (text: string, y: number, o?: { size?: number; bold?: boolean; page?: number; x?: number }): BrainLine => ({
  text,
  size: o?.size ?? 12,
  bold: o?.bold ?? false,
  bbox: [o?.x ?? 60, y, (o?.x ?? 60) + Math.min(480, text.length * 6), y + (o?.size ?? 12) * 1.4],
  page: o?.page ?? 0,
});

const mkTable = (
  bbox: number[],
  rows: number,
  cols: number,
  cellTexts: string[][],
  cellBboxes?: number[][]
): BrainTable => ({
  page: 0,
  bbox,
  rows,
  cols,
  cellTexts,
  cellBboxes:
    cellBboxes ??
    cellTexts.flatMap((row, ri) =>
      row.map((_, ci) => [bbox[0] + ci * (bbox[2] - bbox[0]) / cols, bbox[1] + ri * (bbox[3] - bbox[1]) / rows,
        bbox[0] + (ci + 1) * (bbox[2] - bbox[0]) / cols, bbox[1] + (ri + 1) * (bbox[3] - bbox[1]) / rows])
    ),
  cells: [],
  kind: 'empty',
  letterRows: [],
});

interface Opts {
  width?: number;
  height?: number;
  hlines?: number[][];
  rects?: number[][];
  tables?: BrainTable[];
  lines?: BrainLine[];
}
const P = (o: Opts = {}) => ({
  width: o.width ?? 595,
  height: o.height ?? 842,
  hlines: o.hlines ?? [],
  rects: o.rects ?? [],
  tables: o.tables ?? [],
  lines: o.lines ?? [],
});
const doc = (name: string, pages: ReturnType<typeof P>[]): BrainDoc => ({ file: name, pages });

// ---------------------------------------------------------------- harness

let pass = 0;
let fail = 0;
const failures: string[] = [];
function check(name: string, cond: boolean, detail?: string) {
  if (cond) {
    pass++;
    console.log(`  ok  ${name}`);
  } else {
    fail++;
    failures.push(name + (detail ? ` — ${detail}` : ''));
    console.log(`  FAIL ${name}${detail ? ` — ${detail}` : ''}`);
  }
}
const rowsOf = (r: BrainResult) => r.sections.flatMap((s) => s.rows.map((x) => x.letter));
const marksOf = (r: BrainResult) => r.sections.flatMap((s) => s.rows.filter((x) => x.mark !== undefined).map((x) => `${x.letter}:${x.mark}`));
const confirmedSubjects = (r: BrainResult) => r.sections.filter((s) => s.confirmed).map((s) => s.subject ?? s.headerText ?? '(unlabeled)');

// ---------------------------------------------------------------- suite

console.log('\n=== S1: rules-only exam (full-width rules separate lettered rows with marks)');
{
  const lines = [
    L('A) Fill in the blanks.', 80, { bold: true }),
    L('1. She .......... to school every day.', 110),
    L('1', 138, { bold: true }),
    L('B) Match the definitions.', 200, { bold: true }),
    L('2. a person who teaches', 230),
    L('2', 258, { bold: true }),
    L('C) Write the correct form.', 320, { bold: true }),
    L('3. They .......... football now.', 350),
    L('1.5', 378, { bold: true }),
  ];
  const d = doc('s1-rules', [
    P({ lines, hlines: [[60, 180, 475], [60, 300, 475], [60, 700, 475]] }),
  ]);
  const r = runLayoutBrain(d);
  check('S1 sections confirmed', r.sections.filter((s) => s.confirmed).length >= 2, JSON.stringify(r.sections.map((s) => [s.boundaryKind, s.confidence])));
  check('S1 all three letters present', ['A', 'B', 'C'].every((x) => rowsOf(r).includes(x)), JSON.stringify(rowsOf(r)));
  check('S1 marks pair A:1 B:2 C:1.5', ['A:1', 'B:2', 'C:1.5'].every((x) => marksOf(r).includes(x)), JSON.stringify(marksOf(r)));
}

console.log('\n=== S2: keyword subject headers (Persian + English) confirm; generic big text does not');
{
  const lines = [
    L('Vocabulary', 80, { size: 16, bold: true }),
    L('Choose the best word.', 120),
    L('واژگان', 300, { size: 16, bold: true }),
    L('معنی کلمات را بنویسید.', 340),
    L('SOMETHING BIG AND GENERIC', 520, { size: 16, bold: true }),
    L('content under generic big line', 560),
  ];
  const d = doc('s2-headers', [P({ lines })]);
  const r = runLayoutBrain(d);
  const subs = confirmedSubjects(r);
  check('S2 Vocabulary confirms', subs.includes('Vocabulary'), JSON.stringify(subs));
  check('S2 Persian واژگان confirms', subs.includes('Vocabulary') || confirmedSubjects(r).length >= 1, JSON.stringify(subs));
  check('S2 generic big line NOT confirmed', !r.sections.some((s) => s.confirmed && (s.headerText ?? '').includes('GENERIC')), JSON.stringify(subs));
}

console.log('\n=== S3: tables-only document (no headers, no letters) -> content tables are boundaries, flagged');
{
  const t1 = mkTable([60, 100, 540, 420], 4, 2, [
    ['The reading passage first row with longish content', 'second column content here'],
    ['row two content for the passage table', 'more content to raise avg'],
    ['row three content for the passage table', 'more content to raise avg'],
    ['row four content for the passage table', 'more content to raise avg'],
  ]);
  const t2 = mkTable([60, 500, 540, 780], 4, 2, [
    ['Second table first row with longish content', 'second column content here'],
    ['row two content for the second table', 'more content to raise avg'],
    ['row three content for the second table', 'more content to raise avg'],
    ['row four content for the second table', 'more content to raise avg'],
  ]);
  const lines = ['a', 'b', 'c', 'd'].map((x, i) => L(`cell text line ${x} for the extraction flow`, 140 + i * 70));
  const lines2 = ['e', 'f', 'g', 'h'].map((x, i) => L(`second table text line ${x} for extraction`, 540 + i * 55));
  const d = doc('s3-tables', [P({ lines: [...lines, ...lines2], tables: [t1, t2] })]);
  const r = runLayoutBrain(d);
  check('S3 two table sections appear', r.sections.filter((s) => s.boundaryKind === 'content').length >= 2, JSON.stringify(r.sections.map((s) => [s.boundaryKind, s.confidence])));
  check('S3 tables alone do NOT confirm (single-signal uncertainty)', !r.sections.some((s) => s.confirmed && s.boundaryKind === 'content'), JSON.stringify(r.sections.map((s) => [s.boundaryKind, s.confidence, s.confirmed])));
}

console.log('\n=== S4: standalone matching layout table after a rule -> confirms');
{
  const t = mkTable([60, 140, 540, 480], 4, 2, [
    ['A', 'B'],
    ['1. a person who flies planes', 'pilot'],
    ['2. a place where you borrow books', 'library'],
    ['3. very large', 'huge'],
  ]);
  const lines = [
    L('Match the words in A with the meanings in B.', 90),
    ...['pilot', 'library', 'huge', 'borrow'].map((w, i) => L(w, 200 + i * 60)),
  ];
  const d = doc('s4-matching', [P({ lines, hlines: [[60, 120, 475]], tables: [t] })]);
  const r = runLayoutBrain(d);
  check('S4 matching section confirms', r.sections.some((s) => s.confirmed && s.boundaryKind === 'matching'), JSON.stringify(r.sections.map((s) => [s.boundaryKind, s.confidence, s.confirmed])));
}

console.log('\n=== S5: kanoon strip-above-header layout -> strip rows land under the right part');
{
  // strip table rows E:2,F:2,G:1.5 printed ABOVE the Grammar header
  const strip = mkTable([60, 40, 540, 150], 3, 3, [
    ['E', 'Write a report.', '2'],
    ['F', 'Send an email.', '2'],
    ['G', 'Fill the form.', '1.5'],
  ]);
  const lines = [
    ...['E', 'F', 'G'].map((c, i) => L(c, 70 + i * 35, { bold: true })),
    L('Grammar', 220, { size: 16, bold: true }),
    L('Choose the correct option.', 260),
    L('1. He .......... here since 2019.', 290),
  ];
  const d = doc('s5-strip', [P({ lines, tables: [strip] })]);
  const r = runLayoutBrain(d);
  const gram = r.sections.find((s) => s.subject === 'Grammar');
  check('S5 Grammar section exists', !!gram, JSON.stringify(r.sections.map((s) => [s.subject, s.confidence])));
  check('S5 strip rows E,F,G under Grammar', !!gram && ['E', 'F', 'G'].every((x) => gram.rows.some((y) => y.letter === x)), JSON.stringify(gram?.rows));
  check('S5 marks E:2 F:2 G:1.5', !!gram && ['E:2', 'F:2', 'G:1.5'].every((x) => gram.rows.some((y) => `${y.letter}:${y.mark}` === x)), JSON.stringify(gram?.rows.map((x) => `${x.letter}:${x.mark}`)));
}

console.log('\n=== S6: per-part letter restart (A,B under each part header) is KEPT');
{
  const lines = [
    L('Vocabulary', 60, { size: 15, bold: true }),
    L('A) Fill in the blanks.', 100, { bold: true }),
    L('1. question one', 130),
    L('B) Match.', 190, { bold: true }),
    L('2. question two', 220),
    L('Grammar', 320, { size: 15, bold: true }),
    L('A) Choose the best option.', 360, { bold: true }),
    L('3. question three', 390),
    L('B) Rewrite.', 450, { bold: true }),
    L('4. question four', 480),
  ];
  const d = doc('s6-restart', [P({ lines })]);
  const r = runLayoutBrain(d);
  check('S6 restart note present', r.notes.some((n) => n.includes('per-part numbering kept')), JSON.stringify(r.notes));
  const letters = rowsOf(r);
  check('S6 second part rows A,B kept', letters.filter((x) => x === 'A').length >= 1 && letters.filter((x) => x === 'B').length >= 1, JSON.stringify(letters));
}

console.log('\n=== S7: answer-key letter repeat with no separating header is DROPPED');
{
  const lines = [
    L('A) Fill in.', 80, { bold: true }),
    L('1. q one', 110),
    L('B) Fill in.', 180, { bold: true }),
    L('2. q two', 210),
    // printed key: compact letter pairs, no header between
    ...['A', 'B', 'A', 'B'].map((c, i) => L(c, 320 + i * 24, { bold: true })),
  ];
  const d = doc('s7-key', [P({ lines })]);
  const r = runLayoutBrain(d);
  check('S7 key structure dropped (note)', r.notes.some((n) => n.includes('answer-key structure dropped')), JSON.stringify(r.notes));
  check('S7 no rows beyond B', !rowsOf(r).some((x) => x.charCodeAt(0) > 'B'.charCodeAt(0)), JSON.stringify(rowsOf(r)));
}

console.log('\n=== S8: numbered-ladder restart (duplicate answer sheet) demoted to fallback');
{
  const lines = [
    L('English Exam — Grade 9', 40, { bold: true }),
    ...Array.from({ length: 10 }, (_, i) => L(`${i + 1}. question number ${i + 1} text`, 80 + i * 30)),
    // duplicate sheet restarts at 4 with no header — separated by a rule like
    // real duplicated answer sheets
    ...Array.from({ length: 6 }, (_, i) => L(`${i + 4}. duplicate copy question ${i + 4} text`, 500 + i * 30)),
  ];
  const d = doc('s8-copy', [P({ lines, hlines: [[60, 60, 475], [60, 470, 475]] })]);
  const r = runLayoutBrain(d);
  check('S8 restart demoted (note)', r.notes.some((n) => n.includes('numbered ladder restarts')), JSON.stringify(r.notes));
  check('S8 restart region not confirmed', !r.sections.some((s) => s.confirmed && s.lines.some((l) => l.text.includes('duplicate copy'))), '');
}

console.log('\n=== S9: large option lines are NOT headers');
{
  const lines = [
    L('b) he is sick and feels bad', 100, { size: 16, bold: true }),
    L('12- not to touch the paintings', 160, { size: 16, bold: true }),
    L('Real Section', 300, { size: 16, bold: true }),
    L('content', 340),
  ];
  const d = doc('s9-options', [P({ lines })]);
  const r = runLayoutBrain(d);
  check('S9 option lines produce no header sections', !r.sections.some((s) => (s.headerText ?? '').startsWith('b)') || (s.headerText ?? '').startsWith('12-')), JSON.stringify(r.sections.map((s) => s.headerText)));
}

console.log('\n=== S10: no structural signals at all -> abstain');
{
  const lines = Array.from({ length: 20 }, (_, i) => L(`plain sentence line ${i} with no markers at all`, 80 + i * 30));
  const d = doc('s10-plain', [P({ lines })]);
  const r = runLayoutBrain(d);
  check('S10 nothing confirmed', r.sections.filter((s) => s.confirmed).length === 0, JSON.stringify(r.sections.map((s) => [s.boundaryKind, s.confidence])));
}

console.log('\n=== S11: scan-noise page (thousands of rules) -> skipped safely');
{
  const hlines = Array.from({ length: 2000 }, (_, i) => [40, 60 + i * 0.4, 500]);
  const lines = [
    L('Vocabulary', 80, { size: 16, bold: true }),
    ...Array.from({ length: 10 }, (_, i) => L(`question line ${i} of the vocabulary part`, 120 + i * 30)),
  ];
  const d = doc('s11-noise', [P({ lines, hlines })]);
  const r = runLayoutBrain(d);
  check('S11 noise noted', r.notes.some((n) => n.includes('scan noise')), JSON.stringify(r.notes.slice(0, 2)));
  check('S11 header still confirmed', confirmedSubjects(r).includes('Vocabulary'), JSON.stringify(confirmedSubjects(r)));
}

console.log('\n=== S12: marks table (letter|instruction|mark rows) pairs letters with marks');
{
  const t = mkTable([60, 100, 540, 300], 4, 3, [
    ['بارم', 'سوالات', 'ردیف'],
    ['2', 'A) Fill in the blanks with the words.', '1'],
    ['1.5', 'B) Match the definitions.', '2'],
    ['0.5', 'C) Put the words in order.', '3'],
  ]);
  const lines = [L("answer the questions below", 60), ...Array.from({ length: 6 }, (_, i) => L(`follow-up question line ${i + 1} of this part`, 320 + i * 30))];
  const d = doc('s12-marks', [P({ lines, tables: [t] })]);
  const r = runLayoutBrain(d);
  const letters = rowsOf(r);
  check('S12 rows A,B,C present', ['A', 'B', 'C'].every((x) => letters.includes(x)), JSON.stringify(letters));
  check('S12 marks extracted', marksOf(r).length >= 2, JSON.stringify(marksOf(r)));
}

console.log('\n=== S13: garbled text layer -> nothing confirms (abstain, no garbage sections)');
{
  const lines = [
    L('c.o^{;A ence', 80, { size: 16, bold: true }),
    L('1- re F\\<-cU', 120),
    L('6- innprcYgl', 180),
    L('5- lonqevitY', 240),
  ];
  const d = doc('s13-garbled', [P({ lines })]);
  const r = runLayoutBrain(d);
  check('S13 nothing confirmed', r.sections.filter((s) => s.confirmed).length === 0, JSON.stringify(r.sections.map((s) => [s.headerText, s.confidence, s.confirmed])));
}

console.log('\n=== S14: kanoon ad furniture never becomes sections');
{
  const lines = [
    L('کانون بوک', 40, { size: 14, bold: true }),
    L('نمونه سوال کد تخفیف', 70),
    L('را به سر شماره 90008451 ارسال کنید', 100),
    L('Vocabulary', 220, { size: 16, bold: true }),
    ...Array.from({ length: 6 }, (_, i) => L(`question line ${i}`, 260 + i * 30)),
  ];
  const d = doc('s14-ads', [P({ lines })]);
  const r = runLayoutBrain(d);
  check('S14 no ad sections', !r.sections.some((s) => s.lines.some((l) => /کانون|تخفیف|90008451/.test(l.text) && s.headerText === l.text.trim())), JSON.stringify(r.sections.map((s) => s.headerText)));
  check('S14 Vocabulary still confirmed', confirmedSubjects(r).includes('Vocabulary'), JSON.stringify(confirmedSubjects(r)));
}

console.log('\n=== S15: matching table INSIDE a lettered row region defers to the ladder');
{
  const lines = [
    L('Reading', 60, { size: 16, bold: true }),
    L('K) Read the passage.', 100, { bold: true }),
    L('Passage text about a topic that goes on for a while.', 130),
    L('L) Match the words.', 260, { bold: true }),
    L('matching content row one', 290),
  ];
  const matchTable = mkTable([60, 320, 540, 520], 4, 2, [
    ['A', 'B'],
    ['1. someone who teaches', 'teacher'],
    ['2. a large animal', 'elephant'],
    ['3. not difficult', 'easy'],
  ]);
  const d = doc('s15-ladder', [P({ lines, tables: [matchTable] })]);
  const r = runLayoutBrain(d);
  check('S15 no standalone matching section (ladder claims region)', !r.sections.some((s) => s.boundaryKind === 'matching' && s.confirmed), JSON.stringify(r.sections.map((s) => [s.boundaryKind, s.confidence])));
}

console.log('\n=== S16: Persian row letters (الف/ب/ج) fuse, sequence-check and carry own lines');
{
  const lines = [
    L('الف) جاهای خالی را کامل کنید.', 80, { bold: true }),
    L('1. او .......... به مدرسه می‌رود.', 110),
    L('2. آنها .......... بیرون بودند.', 140),
    L('ب) کلمات داده شده را مرتب کنید.', 240, { bold: true }),
    L('3. school / to / goes / she', 270),
    L('ج) با توجه به متن به سوالات پاسخ دهید.', 400, { bold: true }),
    L('4. Where does she go?', 430),
  ];
  const d = doc('s16-persian-rows', [
    P({ lines, hlines: [[60, 220, 475], [60, 380, 475]] }),
  ]);
  const r = runLayoutBrain(d);
  check('S16 Persian rows detected', ['الف', 'ب', 'ج'].every((x) => rowsOf(r).includes(x)), JSON.stringify(rowsOf(r)));
  const allRows = r.sections.flatMap((s) => s.rows);
  check('S16 rows carry own line arrays', allRows.filter((x) => x.letter !== 'الف').every((x) => (x.lines?.length ?? 0) >= 1), JSON.stringify(allRows.map((x) => [x.letter, x.lines?.length ?? -1])));
  // Marks-less letter rows sit at 0.5-0.65: below the 0.70 commit gate ON
  // PURPOSE (uncertainty is flagged; the bridge hands them to the text
  // fallback). The contract here: detected, sequenced, never key-dropped.
  check('S16 rows never dropped as key/regression', !r.sections.every((s) => s.demoted) && r.sections.length >= 1, JSON.stringify(r.sections.map((s) => [s.boundaryKind, s.confidence, s.demoted])));
  // per-row instruction survives in the row text (bridge emits row blocks with it)
  const rowB = allRows.find((x) => x.letter === 'ب');
  check('S16 row b keeps its instruction line', !!rowB && rowB.lines!.some((l) => l.text.includes('کلمات')), JSON.stringify(rowB?.lines?.map((l) => l.text)));
}

console.log('\n=== S17: Persian marks-table letter cells (الف|instruction|mark) classify + extract');
{
  const t = mkTable([60, 60, 540, 260], 4, 3, [
    ['بارم', 'سوالات', 'ردیف'],
    ['1', 'جاهای خالی را کامل کنید.', 'الف'],
    ['2', 'با کلمات داده شده جملات را مرتب کنید.', 'ب'],
    ['1.5', 'متن را بخوانید و پاسخ دهید.', 'ج'],
  ]);
  const lines = [
    L('1. او .......... به مدرسه می‌رود.', 300),
    L('2. She .......... to school.', 330),
    L('3. They .......... at home.', 360),
    L('4. Do they ..........?', 390),
  ];
  const d = doc('s17-persian-marks-table', [P({ lines, tables: [t] })]);
  const r = runLayoutBrain(d);
  check('S17 table classified marksTable', r.stats.marksTables >= 1, JSON.stringify(r.stats));
  const rowLetters = rowsOf(r);
  check('S17 Persian letters extracted from cells', ['الف', 'ب', 'ج'].every((x) => rowLetters.includes(x)), JSON.stringify(rowLetters));
  check('S17 marks paired to Persian letters', ['الف:1', 'ب:2', 'ج:1.5'].every((x) => marksOf(r).includes(x)), JSON.stringify(marksOf(r)));
}

console.log('\n=== S18: malformed geometry docs throw or abstain — never hang, never fabricate');
{
  let threw = false;
  try {
    // @ts-expect-error deliberately broken input
    runLayoutBrain({ file: 'bad', pages: 'not-an-array' });
  } catch (e) {
    threw = true;
  }
  check('S18 pages-not-array throws (caller falls back)', threw);
  const r2 = runLayoutBrain({ file: 'bad2', pages: [null as any, { width: 595, height: 842, hlines: [['x', 'y', 'w'] as any], rects: [null as any], tables: [null as any], lines: [{ text: 42 as any, size: NaN, bold: null as any, bbox: [1, 2] as any }] }] });
  check('S18 garbage fields sanitized (no crash, no sections)', r2.sections.filter((s) => s.confirmed).length === 0, JSON.stringify(r2.notes.slice(0, 3)));
}

console.log('\n=== S19: Latin->Persian alphabet switch resets expectation (no false key/regression)');
{
  const lines = [
    L('A) Choose the best answer.', 80, { bold: true }),
    L('1. She .......... here.', 110),
    L('Vocabulary', 200, { size: 16, bold: true }),
    L('ب) معنی کلمات را بنویسید.', 240, { bold: true }),
    L('1. book', 270),
    L('ج) جمله‌ها را مرتب کنید.', 400, { bold: true }),
    L('2. goes / to / school / he', 430),
  ];
  const d = doc('s19-alphabet-switch', [P({ lines })]);
  const r = runLayoutBrain(d);
  check('S19 both alphabets keep their rows', rowsOf(r).includes('A') && rowsOf(r).includes('ب'), JSON.stringify(rowsOf(r)));
  check('S19 Persian rows not dropped as key/regression', r.sections.some((s) => s.rows.some((x) => x.letter === 'ج') && (s.confirmed || !s.demoted)), JSON.stringify(r.sections.map((s) => [s.confidence, s.rows.map((x) => x.letter), s.notes.slice(0, 2)])));
  check('S19 switch noted in evidence', r.sections.some((s) => s.notes.some((n) => n.includes('alphabet switch') || n.includes('restart') || n.includes('sequence'))), JSON.stringify(r.sections.flatMap((s) => s.notes).slice(0, 6)));
}

console.log('\n=== S20: Persian MCQ option runs (ب/ج/د/ه) are options, not row openers');
{
  const lines = [
    L('Vocabulary', 60, { size: 16, bold: true }),
    L('1. He .......... a student.', 100),
    L('ب) tired', 118),
    L('ج) student', 132),
    L('د) teacher', 146),
    L('ه) book', 160),
    L('2. They .......... at home.', 240),
    L('ب) is', 258),
    L('ج) are', 272),
    L('د) am', 286),
    L('ه) be', 300),
  ];
  const d = doc('s20-persian-options', [P({ lines })]);
  const r = runLayoutBrain(d);
  const optionLetterRows = r.sections.flatMap((s) => s.rows).filter((x) => ['ب', 'ج', 'د', 'ه'].includes(x.letter));
  check('S20 Persian option letters never become rows', optionLetterRows.length === 0, JSON.stringify(rowsOf(r)));
  check('S20 Vocabulary header still confirmed', r.sections.some((s) => s.subject === 'Vocabulary' && s.confirmed), JSON.stringify(confirmedSubjects(r)));
}

console.log('\n=== S21: numeric radif openers ("8 Grammar") claim section identities');
{
  const lines = [
    L('باسمه تعالی', 40),
    L('1 Listening', 90, { bold: true }),
    L('1. She .......... to the radio every day.', 120),
    L('2. They .......... TV at night.', 145),
    L('5 Vocabulary', 300, { bold: true }),
    L('3. Water .......... at 100 degrees.', 330),
    L('4. We .......... English on Mondays.', 355),
  ];
  const d = doc('s21-numeric-radif', [P({ lines })]);
  const r = runLayoutBrain(d);
  const num1 = r.sections.find((s) => s.evidence.numeric === 1);
  const num5 = r.sections.find((s) => s.evidence.numeric === 5);
  check('S21 section 1 perceived with Listening subject', !!num1 && num1.subject === 'Listening', JSON.stringify(r.sections.map((s) => [s.evidence.numeric, s.subject, s.confidence])));
  check('S21 section 5 perceived with Vocabulary subject', !!num5 && num5.subject === 'Vocabulary', JSON.stringify(r.sections.map((s) => [s.evidence.numeric, s.subject])));
  check('S21 numeric sections confirmed', !!num1?.confirmed && !!num5?.confirmed);
}

console.log('\n=== S22: a bold digit in the top margin is a PAGE NUMBER, never a mark');
{
  const lines = [
    L('3', 30, { bold: true }), // top-margin page number
    L('A) Fill in the blanks.', 200, { bold: true }),
    L('1. She .......... to school.', 230),
    L('2', 260, { bold: true }), // the real بارم
    L('B) Match the definitions.', 320, { bold: true }),
    L('2. a person who teaches', 350),
  ];
  const d = doc('s22-page-number', [P({ lines })]);
  const r = runLayoutBrain(d);
  const marks = marksOf(r);
  check('S22 mark pairs to the in-content 2, not the margin 3', marks.includes('A:2') && !marks.includes('A:3'), JSON.stringify(marks));
  check('S22 row A still confirmed', r.sections.some((s) => s.rows.some((x) => x.letter === 'A') && s.confirmed), JSON.stringify(r.sections.map((s) => [s.confidence, s.rows.map((x) => x.letter)])));
}

console.log('\n=== S23: unruled marks strip — ردیف ladder column dropped, بارم column kept');
{
  const lines = [
    L('A)  Fill in the blanks with the given words.', 199, { bold: true, x: 60 }),
    L('1. Do you ...... what she said?', 230, { x: 60 }),
    L('1', 299, { bold: true, x: 557 }), // ردیف col (right edge)
    L('3', 299, { bold: true, x: 38 }), // بارم col (left edge)
    L('B)  Match the definitions.', 380, { bold: true, x: 60 }),
    L('2. a few ......', 410, { x: 60 }),
    L('2', 485, { bold: true, x: 557 }),
    L('2', 485, { bold: true, x: 39 }),
    L('C)  Write a correct preposition.', 560, { bold: true, x: 60 }),
    L('3. I was born...... 2003.', 590, { x: 60 }),
    L('3', 616, { bold: true, x: 557 }),
    L('2', 616, { bold: true, x: 39 }),
    L('D)  Complete the sentences.', 700, { bold: true, x: 60 }),
    L('4. Please talk ...... (quiet).', 730, { x: 60 }),
    L('4', 749, { bold: true, x: 557 }),
    L('2', 749, { bold: true, x: 39 }),
  ];
  const d = doc('s23-unruled-strip', [P({ lines })]);
  const r = runLayoutBrain(d);
  const marks = marksOf(r);
  check('S23 marks taken from the بارم column', ['A:3', 'B:2', 'C:2', 'D:2'].every((m) => marks.includes(m)), JSON.stringify(marks));
  check('S23 ردیف digits never paired as marks', !marks.some((m) => m.endsWith(':1') && m.startsWith('A')), JSON.stringify(marks));
  check('S23 rows A-D all present', ['A', 'B', 'C', 'D'].every((x) => rowsOf(r).includes(x)), JSON.stringify(rowsOf(r)));
}

console.log('\n=== S24: dialogue speakers ("A: ..." / "B: ...") are transcript, not rows');
{
  const lines = [
    L('1 Listening', 60, { bold: true }),
    L('A: Yes, I love playing sports.', 100),
    L('B: Oh, about twice a week.', 130),
    L('A: Do you play volleyball?', 160),
    L('B: No, I do not.', 190),
    L('A: What about you?', 220),
    L('A)  Fill in the blanks.', 400, { bold: true }),
    L('1. She .......... to school.', 430),
  ];
  const d = doc('s24-dialogue', [P({ lines })]);
  const r = runLayoutBrain(d);
  const letters = rowsOf(r);
  check('S24 dialogue letters never become rows', !letters.includes('B'), JSON.stringify(letters));
  check('S24 the real row A survives exactly once', letters.filter((x) => x === 'A').length === 1, JSON.stringify(letters));
}

console.log('\n=== S25: double-printed sheet — the repeated cycle is flagged, not parsed');
{
  const copy = (pg: number) => [
    L('Listening', 80, { size: 16, bold: true, page: pg }),
    L('A)  Is it true or false?', 110, { bold: true, page: pg }),
    L('1. She is a doctor.', 140, { page: pg }),
    L('2. They live in Rome.', 165, { page: pg }),
    L('Vocabulary', 300, { size: 16, bold: true, page: pg }),
    L('B)  Choose the best word.', 330, { bold: true, page: pg }),
    L('3. book / pen', 360, { page: pg }),
    L('Grammar', 500, { size: 16, bold: true, page: pg }),
    L('C)  Write the correct form.', 530, { bold: true, page: pg }),
    L('4. go / went', 560, { page: pg }),
  ];
  const d = doc('s25-duplicate-sheet', [P({ lines: copy(0) }), P({ lines: copy(1) })]);
  const r = runLayoutBrain(d);
  check('S25 duplicate cycle flagged in notes', r.notes.some((n) => n.includes('duplicate sheet')), JSON.stringify(r.notes.slice(0, 4)));
  check('S25 repeated tail demoted (drive gate will abstain)', r.sections.filter((s) => s.demoted).length >= 3, JSON.stringify(r.sections.map((s) => [s.subject, s.demoted ?? false])));
  check('S25 first copy intact', r.sections.slice(0, 3).every((s) => !s.demoted), JSON.stringify(r.sections.map((s) => [s.subject, s.demoted ?? false])));
}

// ---------------------------------------------------------------- summary

console.log(`\n===== brain_stress: ${pass} passed, ${fail} failed`);
if (fail) {
  console.log(failures.map((f) => '  - ' + f).join('\n'));
  process.exit(1);
}
