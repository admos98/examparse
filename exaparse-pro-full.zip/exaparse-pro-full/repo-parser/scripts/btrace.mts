import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';
const text = fs.readFileSync(path.join(WS_ROOT, 'scratch', 'texts-qu2', '14020406p4t7882699.pdf.txt'), 'utf8');
const doc = parseExamRawText(text, 'x.pdf', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
doc.sections.forEach((s, i) => {
  console.log(`#${i} id=${s.rowId} title=${JSON.stringify((s.title ?? '').slice(0, 30))} nq=${s.questions.length}`);
  for (const q of s.questions.slice(0, 3)) {
    console.log('   ', q.number, JSON.stringify((q.stem ?? '').slice(0, 30)), q.receipt?.ruleChain?.join('>'));
  }
});
