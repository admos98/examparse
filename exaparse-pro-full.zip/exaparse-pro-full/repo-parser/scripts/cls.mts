import { classifyLines } from '../src/utils/parserRules';
const lines = [
  '16(This morning I …………..my homework. when you called me.',
  'a) were doing  b) am doing  c) was doing  d) did',
  '17(Zahra………… did the experiment.',
  '23( 11(He changed the………….. to have more light in the room.',
];
for (const l of lines) {
  const cls = classifyLines([l])[0];
  console.log(JSON.stringify({ line: l.slice(0, 32), kind: cls.kind, rule: cls.ruleId, conf: cls.confidence, num: (cls as unknown as { number?: number }).number }));
}
