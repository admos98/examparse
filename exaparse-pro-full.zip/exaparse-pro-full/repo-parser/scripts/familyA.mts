/**
 * familyA — quantify the "fallback renumbering" smoking gun: parse sections
 * whose questions restart at 1 while the GT range starts higher (the block
 * walker dropped the printed numbers and re-numbered from scratch). Also
 * counts word-bank misses and instruction-type misses. Measurement only.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse, GoldenGT } from '../src/utils/goldenGrade';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const TEXT_DIR = process.env.QU2_TEXT_DIR ?? path.join(WS_ROOT, 'scratch', 'texts-qu2');

function main() {
  const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  let renumSecs = 0;
  let renumQs = 0;
  let wbMiss = 0;
  const renumFiles: string[] = [];
  for (const f of files) {
    const gt: GoldenGT = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
    const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const parsed = parseExamRawText(fs.readFileSync(textPath, 'utf8'), gt.file, {
      detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true,
    });
    const idSeen = new Map<string, number>();
    for (const gts of gt.sections) {
      const occ = idSeen.get(gts.id) ?? 0;
      idSeen.set(gts.id, occ + 1);
      const sec = parsed.sections.filter((s) => s.rowId === gts.id)[occ];
      if (!sec) continue;
      const wantQs: number[] = [];
      for (const q of gts.qs) {
        if (q.stem !== undefined) continue;
        if (Array.isArray(q.n)) wantQs.push(...q.n);
        else wantQs.push(q.n as number);
      }
      if (!wantQs.length) continue;
      const gotNums = sec.questions.map((q) => q.number as number);
      // renumbering signature: got starts at/below 2 while GT starts >= 4,
      // OR got is a clean 1..N run while GT is not 1-based
      const startsLow = gotNums.length && gotNums[0] <= 2 && wantQs[0] >= 4;
      const gtNotOneBased = wantQs[0] >= 4;
      if (startsLow && gtNotOneBased) {
        renumSecs++;
        renumQs += wantQs.length;
        if (!renumFiles.includes(gt.file)) renumFiles.push(gt.file);
      }
      // word-bank miss: GT says word_bank_fill, got never types it in the section
      const wantWb = gts.qs.some((q) => q.t === 'word_bank_fill');
      const gotWb = sec.questions.some((q) => q.type === 'word_bank_fill');
      if (wantWb && !gotWb) wbMiss++;
    }
  }
  console.log(`FALLBACK-RENUMBERING sections: ${renumSecs}  (questions affected: ${renumQs}) in ${renumFiles.length} files`);
  console.log('files:', renumFiles.join(' '));
  console.log(`WORD-BANK MISS sections: ${wbMiss}`);
}
main();
