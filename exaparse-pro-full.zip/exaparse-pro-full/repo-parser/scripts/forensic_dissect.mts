/**
 * forensic_dissect — THE smoking-gun hunt (user directive: "what is the root
 * cause, what is the smoking gun").
 *
 * Runs the graded text path over every qu2 GT file, dumps EVERY gradeParse
 * issue, categorizes each into a failure family, and prints the aggregate
 * histogram + per-file family profile. No fixes here — measurement only.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse, GoldenGT } from '../src/utils/goldenGrade';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const TEXT_DIR = process.env.QU2_TEXT_DIR ?? path.join(WS_ROOT, 'scratch', 'texts-qu2');

function family(issue: string): string {
  if (issue.startsWith('section ids:')) return 'SECTION-IDS (structure differs)';
  if (issue.includes(' MISSING')) return 'SECTION-MISSING';
  if (issue.includes(' category:')) return 'CATEGORY';
  if (issue.includes(' markTotal:')) return 'MARKS';
  if (/\bcount: got/.test(issue)) return 'Q-COUNT';
  if (issue.includes(' q# at pos ')) return 'Q-NUMBER-ALIGN';
  if (/\bq\d+ type:/.test(issue)) return 'Q-TYPE';
  if (issue.includes('missing for stem check')) return 'STEM-MISSING-Q';
  if (issue.includes(' stem !~ ') || /\bq\d+ stem:/.test(issue)) return 'STEM-TEXT';
  if (issue.startsWith('header.')) return 'HEADER';
  if (issue.startsWith('totalMarks:')) return 'TOTAL-MARKS';
  return 'OTHER: ' + issue.slice(0, 40);
}

function main() {
  const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  const famCount = new Map<string, number>();
  const perFile: { file: string; score: number; total: number; fams: Map<string, number> }[] = [];
  for (const f of files) {
    const gt: GoldenGT = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
    const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const parsed = parseExamRawText(fs.readFileSync(textPath, 'utf8'), gt.file, {
      detectAnomalies: true,
      normalizeNumbering: true,
      linkClozePassages: true,
    });
    const { score, issues, total } = gradeParse(parsed, gt);
    const fams = new Map<string, number>();
    for (const i of issues) {
      const fam = family(i);
      fams.set(fam, (fams.get(fam) ?? 0) + 1);
      famCount.set(fam, (famCount.get(fam) ?? 0) + 1);
    }
    perFile.push({ file: gt.file, score, total, fams });
  }
  // aggregate histogram
  const sorted = [...famCount.entries()].sort((a, b) => b[1] - a[1]);
  const sum = sorted.reduce((s, [, n]) => s + n, 0);
  console.log('=== FAILURE FAMILY HISTOGRAM (all files, all issues) ===');
  for (const [fam, n] of sorted) console.log(`${String(n).padStart(5)}  ${((n / sum) * 100).toFixed(1)}%  ${fam}`);
  console.log(`TOTAL issues: ${sum}`);
  console.log('\n=== PER-FILE SCORE + TOP FAMILIES ===');
  for (const r of perFile.sort((a, b) => a.score - b.score)) {
    const top = [...r.fams.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([f, n]) => `${f}×${n}`).join(' ');
    console.log(`${String(r.score).padStart(7)}  (${String(r.total).padStart(3)} checks)  ${r.file.replace(/^140\d+\s*/, '')}  ${top}`);
  }
  // deep-dive dumps for the 4 worst
  console.log('\n=== WORST 4 FILES: FULL ISSUE DUMP ===');
  for (const r of perFile.sort((a, b) => a.score - b.score).slice(0, 4)) {
    const gt: GoldenGT = JSON.parse(fs.readFileSync(path.join(GT_DIR, files.find((f) => JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8')).file === r.file)!), 'utf8'));
    const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
    const parsed = parseExamRawText(fs.readFileSync(textPath, 'utf8'), gt.file, {
      detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true,
    });
    const { issues } = gradeParse(parsed, gt);
    console.log(`\n--- ${r.file} (score ${r.score}) ---`);
    console.log(`GT sections: ${gt.sections.map((s) => `${s.id}/${s.cat}/${s.mark}mk/${s.qs.reduce((n, q) => n + (Array.isArray(q.n) ? q.n.length : 1), 0)}q`).join(' | ')}`);
    console.log(`GOT sections: ${parsed.sections.map((s) => `${s.rowId}/${s.majorCategory}/${s.markTotal}mk/${s.questions.length}q`).join(' | ')}`);
    for (const i of issues.slice(0, 25)) console.log('   -', i.slice(0, 150));
  }
}
main();
