import fs from 'node:fs';
import path from 'node:path';
import { findKeySheetBoundary } from '../src/utils/parserEngine';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';
const text = fs.readFileSync(path.join(WS_ROOT, 'scratch', 'texts-qu2', '14020406p4t7882699.pdf.txt'), 'utf8');
const cut = findKeySheetBoundary(text);
console.log('cut =', cut, cut >= 0 ? '→ line ' + text.slice(0, cut).split('\n').length : '');
console.log('total lines =', text.split('\n').length);
if (cut >= 0) console.log('at cut:', JSON.stringify(text.slice(cut, cut + 60)));
