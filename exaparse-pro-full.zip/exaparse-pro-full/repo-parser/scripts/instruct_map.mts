/**
 * instruct_map — per-section dump: the section's own instruction line(s) vs
 * the GT question type vs the parse's question type. Names the exact
 * instruction->type mappings the parser is missing. Measurement only.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse, GoldenGT } from '../src/utils/goldenGrade';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const TEXT_DIR = process.env.QU2_TEXT_DIR ?? path.join(WS_ROOT, 'scratch', 'texts-qu2');
const WANT = process.argv[2] ? new RegExp(process.argv[2]) : null;

function main() {
  const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  for (const f of files) {
    const gt: GoldenGT = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
    if (WANT && !WANT.test(gt.file)) continue;
    const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const parsed = parseExamRawText(fs.readFileSync(textPath, 'utf8'), gt.file, {
      detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true,
    });
    const { score, issues } = gradeParse(parsed, gt);
    const typeIssues = issues.filter((i) => /\bq\d+ type:/.test(i)).length;
    const numIssues = issues.filter((i) => i.includes(' q# at pos ')).length;
    if (typeIssues + numIssues < 4) continue;
    console.log(`\n##### ${gt.file} score=${score} typeIss=${typeIssues} numIss=${numIssues}`);
    const idSeen = new Map<string, number>();
    for (const gts of gt.sections) {
      const occ = idSeen.get(gts.id) ?? 0;
      idSeen.set(gts.id, occ + 1);
      const sec = parsed.sections.filter((s) => s.rowId === gts.id)[occ];
      const wantTypes = gts.qs.filter((q) => q.stem === undefined).map((q) => Array.isArray(q.n) ? `${q.n.join(',')}=${q.t}` : `${q.n}=${q.t}`);
      const gotTypes = sec ? sec.questions.map((q) => `${q.number}=${q.type}`).join(' ') : '(missing)';
      // instruction: the section's own headerLine + the raw text around it
      let instr = sec?.title ?? '';
      if (sec && !instr) {
        // reconstruct from questions' first stem
        instr = sec.questions[0]?.stem?.slice(0, 60) ?? '';
      }
      console.log(`  [${gts.id}] GT(${gts.cat}, ${gts.mark}mk): ${wantTypes.join(' ')}`);
      if (sec) {
        console.log(`      GOT: ${gotTypes.slice(0, 190)}`);
        console.log(`      INSTR: "${instr.slice(0, 110)}"`);
      } else console.log('      GOT: (section missing)');
    }
  }
}
main();
