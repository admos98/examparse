/**
 * Mine section templates (Idea 2) from the parsed corpus and regenerate
 * src/data/minedTemplates.ts. Deterministic: same corpus -> same output.
 *
 * Run:  npx tsx scripts/mineTemplates.mts
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { mineTemplates, MinedSectionInput } from '../src/utils/sectionTemplates';
import { ExamDocument } from '../src/types/exam';

// Workspace root from this file's location (scripts/ sits one level under it) —
// no absolute machine paths, so mining works out-of-the-box anywhere
// (layout contract: repo-parser/scripts-batch/wsPaths.mts).
const WS_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DIRS = [
  path.join(WS_ROOT, 'scratch/parsed'),
  path.join(WS_ROOT, 'scratch/parsed-mocks'),
];
const OUT = path.join(process.cwd(), 'src/data/minedTemplates.ts');

function main() {
  const inputs: MinedSectionInput[] = [];
  const files: string[] = [];
  for (const dir of DIRS) {
    if (!fs.existsSync(dir)) {
      console.warn(`(skipping missing corpus dir ${dir})`);
      continue;
    }
    for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.json')).sort()) {
      const doc = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')) as ExamDocument;
      const file = doc?.filename || f.replace(/\.json$/, '');
      files.push(file);
      for (const sec of doc?.sections || []) {
        inputs.push({ file, section: sec });
      }
    }
  }
  if (inputs.length === 0) {
    console.error('MINING FAIL: no parsed corpus sections found. Run extract_all.mts first.');
    process.exit(1);
  }
  const templates = mineTemplates(inputs);
  console.log(`Mined ${templates.length} templates from ${files.length} exams / ${inputs.length} sections:`);
  for (const t of templates) {
    console.log(
      `  ${t.id.padEnd(16)} -> ${t.suggestsType.padEnd(22)} (${String(t.suggestsCategory).padEnd(10)}) ` +
      `count ${t.countRange[0]}-${t.countRange[1]} weight ${t.weight} from ${t.provenance.minedFrom.length} exam(s)`,
    );
  }

  const banner = `/**
 * MINED SECTION TEMPLATES (Idea 2) — GENERATED FILE, DO NOT EDIT BY HAND.
 * Regenerate with: npx tsx scripts/mineTemplates.mts
 *
 * Mined deterministically from the ${files.length}-exam golden corpus by structural
 * fingerprint clustering. Advisory evidence ONLY — these never stamp types,
 * never enter the grading path, and never demote trust (see
 * src/utils/sectionTemplates.ts for the contract).
 */
export const MINED_TEMPLATES: import('../utils/sectionTemplates').SectionTemplate[] = `;
  fs.writeFileSync(OUT, banner + JSON.stringify(templates, null, 2) + ';\n', 'utf8');
  console.log(`\nWrote ${OUT}`);
}

main();
