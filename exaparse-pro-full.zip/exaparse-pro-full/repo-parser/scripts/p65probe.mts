/**
 * p65probe — per-file score probe for regression bisection.
 * Usage: npx tsx scripts/p65probe.mts [stem]   (default: 14050319p65o69r989)
 * Prints score + per-section structure (id, qnum range, count, mark, types).
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.argv[3] ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const APP_TEXT_DIR = process.argv[4] ?? path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');
const arg = process.argv[2] ?? '14050319p65o69r989';
const stem = arg.replace(/\.pdf$|\.txt$|\.docx$/i, '');
const gtPath = [path.join(GT_DIR, stem + '-pdf.json'), path.join(GT_DIR, stem + '-docx.json'), path.join(GT_DIR, stem + '.json')].find((p) => fs.existsSync(p))!;
const gt = JSON.parse(fs.readFileSync(gtPath, 'utf8'));
const textKey = (gt.file as string).replace(/[^\p{L}\p{N}.\-]+/gu, '_').replace(/\.(pdf|docx)$/i, '');
const textPath = [path.join(APP_TEXT_DIR, textKey + '.txt'), path.join(APP_TEXT_DIR, textKey + '.pdf.txt'), path.join(APP_TEXT_DIR, textKey + '.docx.txt'), path.join(APP_TEXT_DIR, stem + '.txt')].find((p) => fs.existsSync(p))!;
const text = fs.readFileSync(textPath, 'utf8');
const opts = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const;
const doc = parseExamRawText(text, stem + '.pdf', opts);
const g = gradeParse(doc, gt);
console.log(`SCORE ${g.score}  total=${g.total}  issues=${g.issues.length}`);

const sections: any[] = (doc as any).sections ?? [];
for (const s of sections) {
  const qs: any[] = s.questions ?? [];
  const nums = qs.map((q) => q.number ?? q.qnum ?? '?');
  const lo = nums.length ? nums[0] : '-';
  const hi = nums.length ? nums[nums.length - 1] : '-';
  const marks = qs.map((q) => q.mark ?? q.markTotal ?? '?').filter((m) => m !== '?');
  const types: Record<string, number> = {};
  for (const q of qs) {
    const t = q.type ?? q.qtype ?? '?';
    types[t] = (types[t] ?? 0) + 1;
  }
  const typeStr = Object.entries(types).map(([k, v]) => `${k}x${v}`).join(',');
  console.log(
    `sec id=${String(s.id ?? s.sectionId ?? '?').padEnd(3)} n=${String(qs.length).padStart(3)} q=${lo}..${hi}` +
      ` marks=[${marks.slice(0, 8).join(',')}${marks.length > 8 ? ',..' : ''}] ${typeStr}` +
      ` label=${JSON.stringify(s.title ?? s.label ?? s.heading ?? '').slice(0, 60)}`
  );
}

if (process.env.SHOW_ISSUES) {
  const GT_DIR2 = process.argv[3] ?? '';
  void GT_DIR2;
  for (const i of (g as any).issues.slice(0, 30)) console.log('  ISSUE', JSON.stringify(i).slice(0, 160));
}
