/**
 * probe_golden — inspect regressed golden sections after wave-R1 edits.
 * 11th first D + M, 12th first M.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const cases: { file: string; secs: string[] }[] = [
  { file: path.join(WS_ROOT, 'scratch', 'texts', '11th_first.pdf.txt'), secs: ['D', 'M'] },
  { file: path.join(WS_ROOT, 'scratch', 'texts', '12th_first.pdf.txt'), secs: ['M'] },
];

for (const c of cases) {
  const text = fs.readFileSync(c.file, 'utf8');
  const doc = parseExamRawText(text, c.file.split('/').pop() || 'x.pdf', {
    detectAnomalies: true,
    normalizeNumbering: true,
    linkClozePassages: true,
  } as const);
  for (const id of c.secs) {
    const sec = doc.sections.find((s) => s.rowId === id);
    console.log(`\n=== ${c.file.split('/').pop()} section ${id} ===`);
    if (!sec) { console.log('  MISSING'); continue; }
    console.log(`  [${sec.majorCategory}] markTotal=${sec.markTotal}`);
    for (const q of sec.questions) console.log(`  q${q.number} [${q.type}] "${(q.stem || '').slice(0, 58).replace(/\n/g, ' | ')}"`);
  }
}
