/**
 * probe_p3iy — dump p3iy8yh87's parsed sections/questions to see where
 * numbering/typing die.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const stem = '13991010p3iy8yh87';
const text = fs.readFileSync(path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts', stem + '.txt'), 'utf8');
const doc = parseExamRawText(text, stem + '.pdf', {
  detectAnomalies: true,
  normalizeNumbering: true,
  linkClozePassages: true,
} as const);

for (const sec of doc.sections) {
  console.log(`\n=== section ${sec.rowId} [${sec.majorCategory}] markTotal=${sec.markTotal} (${sec.questions.length} questions) ===`);
  for (const q of sec.questions.slice(0, 12)) {
    console.log(`  q${q.number} [${q.type}] "${(q.stem || '').slice(0, 70).replace(/\n/g, ' | ')}"`);
  }
  if (sec.questions.length > 12) console.log(`  ... +${sec.questions.length - 12} more`);
}
