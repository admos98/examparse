/**
 * probe_pm57d — inspect section D typing path after wave-R1 edits.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText, splitRadifNumberedSections } from '../src/utils/parserEngine';
import { canonicalize } from '../src/utils/textCanonical';
import { normalizeOcrText } from '../src/utils/ocrPreprocessor';
import { PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const files = ['14050401pm57p5s814'];
for (const stem of files) {
  // pinned GT texts live in scratch/texts-qu2
  const p1 = path.join(PKG_ROOT, '..', '..', 'scratch', 'texts-qu2', stem + '.txt');
  const p2 = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts', stem + '.txt');
  const fp = fs.existsSync(p1) ? p1 : p2;
  const text = fs.readFileSync(fp, 'utf8');
  console.log('text file:', fp);
  const doc = parseExamRawText(text, stem + '.pdf', {
    detectAnomalies: true,
    normalizeNumbering: true,
    linkClozePassages: true,
  } as const);
  const d = doc.sections.find((s) => s.rowId === 'D');
  if (!d) { console.log('no section D'); continue; }
  console.log(`D [${d.majorCategory}] markTotal=${d.markTotal} ${d.questions.length}q`);
  for (const q of d.questions) console.log(`  q${q.number} [${q.type}] wbWords=${(q as any).wordBankWords?.length ?? 0} "${(q.stem || '').slice(0, 60)}"`);

  // what does the section text look like now?
  const norm = normalizeOcrText(canonicalize(String(text || '')).text);
  const blocks = splitRadifNumberedSections(norm);
  const dBlock = blocks?.find((b) => b.rowId === 'D');
  if (dBlock) {
    console.log('\n--- D block text (first 500) ---');
    console.log(dBlock.text.slice(0, 500));
  }
}
