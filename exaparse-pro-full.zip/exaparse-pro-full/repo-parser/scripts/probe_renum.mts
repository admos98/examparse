/**
 * probe_renum — find every section where the parse RENUMBERED from 1 while
 * the GT wants higher numbers (the "positional renumbering" signature), and
 * print the section's raw text head so the failure shapes can be classified.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-qu2');
const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

for (const f of fs.readdirSync(GT_DIR).filter((x) => x.endsWith('.json')).sort()) {
  const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
  const stem = gt.file.replace(/\.pdf$/i, '');
  const tp = path.join(APP_TEXT_DIR, stem + '.txt');
  if (!fs.existsSync(tp)) continue;
  const text = fs.readFileSync(tp, 'utf8');
  const doc = parseExamRawText(text, gt.file, {
    detectAnomalies: true,
    normalizeNumbering: true,
    linkClozePassages: true,
  } as const);
  const g = gradeParse(doc, gt);
  const renumIssues = g.issues.filter((i) => i.includes(' q# at pos '));
  if (!renumIssues.length) continue;
  // group by section id
  const bySec = new Map<string, { got: number[]; want: number[] }>();
  for (const iss of renumIssues) {
    const m = iss.match(/^(\S+) q# at pos (\d+): got (\d+) want (\d+)/);
    if (!m) continue;
    const [, id, , gotN, wantN] = m;
    const e = bySec.get(id) ?? { got: [], want: [] };
    e.got.push(parseInt(gotN, 10));
    e.want.push(parseInt(wantN, 10));
    bySec.set(id, e);
  }
  for (const [id, e] of bySec) {
    const sec: any = (doc.sections as any[]).find((s: any) => s.rowId === id);
    const gtSec = (gt.sections as any[]).find((s: any) => s.id === id);
    console.log(`\n##### ${gt.file} sec ${id}: got [${e.got.join(',')}] want [${e.want.join(',')}]`);
    if (sec) {
      console.log(`  parsed ${sec.questions.length}q types: ${[...new Set(sec.questions.map((q: any) => q.type))].join(',')}`);
      console.log(`  sec.text head: ${(sec.text ?? '(no text field)').slice(0, 220).replace(/\n/g, ' ⏎ ')}`);
    } else console.log('  (section missing in parse)');
    if (gtSec) console.log(`  gt cat=${gtSec.cat} mark=${gtSec.mark} qtypes=${[...new Set(gtSec.qs.map((q: any) => q.t))].join(',')}`);
  }
}
