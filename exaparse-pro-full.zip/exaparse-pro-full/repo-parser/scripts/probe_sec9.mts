/**
 * probe_sec9 — replicate the engine's view of section 9 (p3iy8yh87):
 * canonicalize + normalize, radif-split, classify the section's lines.
 */
import fs from 'node:fs';
import path from 'node:path';
import { splitRadifNumberedSections } from '../src/utils/parserEngine';
import { canonicalize } from '../src/utils/textCanonical';
import { normalizeOcrText } from '../src/utils/ocrPreprocessor';
import { classifyLines, segmentQuestionBlocks } from '../src/utils/parserRules';
import { PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const text = fs.readFileSync(path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts', '13991010p3iy8yh87.txt'), 'utf8');
const norm = normalizeOcrText(canonicalize(String(text || '')).text);
const blocks = splitRadifNumberedSections(norm);
if (!blocks) {
  console.log('radif splitter returned null');
  process.exit(0);
}
const sec9 = blocks.find((b) => b.rowId === '9');
console.log('sec9 found:', !!sec9);
const t = sec9?.text ?? '';
console.log('--- sec9 text ---');
console.log(t.slice(0, 700));
console.log('--- classifications ---');
for (const c of classifyLines(t.split(/\r?\n/))) {
  if (!c.text.trim()) continue;
  console.log(c.kind.padEnd(15), (c.ruleId + ' ' + c.ruleName).slice(0, 30).padEnd(34), String(c.confidence).padEnd(5), JSON.stringify(c.text.trim().slice(0, 46)));
}
console.log('--- blocks ---');
for (const b of segmentQuestionBlocks(classifyLines(t.split(/\r?\n/)))) {
  console.log(' block', b.number, JSON.stringify(b.text.slice(0, 60)));
}
