import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';
const text = fs.readFileSync(path.join(WS_ROOT, 'scratch', 'texts-qu2', '14050319pw1387r928.pdf.txt'), 'utf8');
const doc = parseExamRawText(text, 'x.pdf', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
for (const s of doc.sections) {
  if (s.rowId !== 'E') continue;
  for (const q of s.questions.slice(0, 2)) {
    console.log(JSON.stringify({ n: q.number, type: q.type, stem: q.stem?.slice(0, 40), receipt: q.receipt }, null, 1));
  }
}
