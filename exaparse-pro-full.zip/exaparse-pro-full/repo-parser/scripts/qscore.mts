import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const stem = process.argv[2] ?? '14041010p265374941';
const opts = (process.argv[3] ?? '') === 'raw' ? {} : { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true };
const dirs = ['scratch/texts-qu2', 'scratch/brain-app-qu2/texts'];
let text: string | null = null;
let used = '';
for (const d of dirs) {
  for (const f of [`${stem}.pdf.txt`, `${stem}.txt`]) {
    const p = path.join(WS_ROOT, d, f);
    if (fs.existsSync(p)) {
      text = fs.readFileSync(p, 'utf8');
      used = p;
      break;
    }
  }
  if (text) break;
}
if (!text) {
  console.error('NO TEXT for', stem);
  process.exit(1);
}
const doc = parseExamRawText(text!, `${stem}.pdf`, opts as never);
const gt = JSON.parse(fs.readFileSync(path.join(WS_ROOT, 'scratch', 'gt-qu2', `${stem}-pdf.json`), 'utf8'));
const g = gradeParse(doc, gt as never);
console.log('TEXT', used);
console.log('SCORE', g.score.toFixed(1), `(${g.total - g.issues.length}/${g.total})`);
for (const s of doc.sections ?? []) {
  const qs = s.questions ?? [];
  const types = [...new Set(qs.map((q: { type: string }) => q.type))].join(',');
  const ids = qs.map((q: { number: number | string }) => Number(q.number));
  const range = ids.length ? `${ids[0]}-${ids[ids.length - 1]}` : '-';
  const sid = (s as unknown as { rowId?: string }).rowId ?? (s as unknown as { id?: string }).id ?? '?';
  const scat = (s as unknown as { majorCategory?: string; category?: string }).majorCategory ?? (s as unknown as { category?: string }).category;
  const smark = (s as unknown as { mark?: number }).mark;
  console.log(`  ${String(sid)} cat=${scat} mark=${smark ?? '-'} n=${qs.length} q=${range} [${types}]`);
}
const shown = process.argv[3] === 'all' ? g.issues.length : Math.min(24, g.issues.length);
for (const i of g.issues.slice(0, shown)) console.log(' -', i);
if (g.issues.length > shown) console.log(`  … +${g.issues.length - shown} more`);
