/**
 * r2_batch — compact GT-vs-parse for the negative-score files.
 * Prints per-section: GT [id]cat/marks/qnums vs PARSE [rowId]cat/marks/qnums(title head)
 * so phantom sections and count inflation are visible at a glance.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { runLayoutBrain } from '../src/utils/layoutBrain';
import { bridgeBrainResult } from '../src/utils/brainBridge';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2');
const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

const FILES = process.argv.slice(2);
const head = (s: string, n = 40) => { const t = String(s ?? '').replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n) + '…' : t; };

for (const stem of FILES) {
  const gtPath = fs.existsSync(path.join(GT_DIR, stem + '.json')) ? path.join(GT_DIR, stem + '.json') : path.join(GT_DIR, stem + '-pdf.json');
  const gt = JSON.parse(fs.readFileSync(gtPath, 'utf8'));
  const text = fs.readFileSync(path.join(APP_TEXT_DIR, stem + '.txt'), 'utf8');
  const opts = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const;
  let blocks: Parameters<typeof parseExamRawText>[3] | undefined;
  const brainPath = path.join(BRAIN_DIR, stem + '.json');
  if (fs.existsSync(brainPath)) {
    try {
      const bridged = bridgeBrainResult(runLayoutBrain(JSON.parse(fs.readFileSync(brainPath, 'utf8'))));
      if (bridged) blocks = bridged.blocks;
    } catch { /* text path */ }
  }
  let doc: any;
  try { doc = parseExamRawText(text, stem + '.pdf', opts, blocks); } catch (e) { console.log(`\n### ${stem} FATAL ${String(e).slice(0, 90)}`); continue; }

  console.log(`\n### ${stem}`);
  const gts = gt.sections ?? [];
  const max = Math.max(gts.length, (doc.sections ?? []).length);
  for (let i = 0; i < max; i++) {
    const g = gts[i];
    const p = (doc.sections ?? [])[i];
    const gl = g ? `[${g.id}] ${g.cat} m=${g.mark} q=${(g.qs ?? []).map((q: any) => Array.isArray(q.n) ? q.n.join('-') : q.n).join(',')} t=${[...new Set((g.qs ?? []).map((q: any) => q.t))].join('/')}` : '--';
    const pl = p ? `[${p.rowId}] ${p.majorCategory} m=${p.markTotal} q=${p.questions.map((q: any) => q.number).join(',')}` : '--';
    const ptypes = p ? [...new Set(p.questions.map((q: any) => q.type))].join('/') : '';
    console.log(`  GT ${gl}`);
    console.log(`  PA ${pl}  ${ptypes}${p && p.questions.length ? '  «' + head(p.questions[0]?.stem ?? p.title, 34) + '»' : ''}`);
  }
}
