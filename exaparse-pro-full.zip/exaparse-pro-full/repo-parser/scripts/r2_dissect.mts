/**
 * r2_dissect — segmentation microscope for one file.
 * Dumps GT sections vs parsed sections side by side:
 *   GT:   id / category / count / markTotal / qnums / types
 *   Parse: same + per-question (num, type, stem head) so phantom questions
 *          (numbers the paper never printed) are visible inline.
 *
 * Usage: npx tsx scripts/r2_dissect.mts <stem> [sectionIdFilter]
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { runLayoutBrain } from '../src/utils/layoutBrain';
import { bridgeBrainResult } from '../src/utils/brainBridge';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2');
const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

const stem = process.argv[2];
if (!stem) { console.error('usage: r2_dissect <stem>'); process.exit(1); }
const secFilter = process.argv[3];

const gtPath = fs.existsSync(path.join(GT_DIR, stem + '.json'))
  ? path.join(GT_DIR, stem + '.json')
  : path.join(GT_DIR, stem + '-pdf.json');
const gt = JSON.parse(fs.readFileSync(gtPath, 'utf8'));
const text = fs.readFileSync(path.join(APP_TEXT_DIR, stem + '.txt'), 'utf8');
const opts = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const;

let blocks: Parameters<typeof parseExamRawText>[3] | undefined;
let mode = 'text';
const brainPath = path.join(BRAIN_DIR, stem + '.json');
if (fs.existsSync(brainPath)) {
  const brainDoc = JSON.parse(fs.readFileSync(brainPath, 'utf8'));
  const res = runLayoutBrain(brainDoc);
  const bridged = bridgeBrainResult(res);
  if (bridged) { blocks = bridged.blocks; mode = 'brain'; }
}
const doc = parseExamRawText(text, stem + '.pdf', opts, blocks);

function head(s: string, n = 48): string {
  const t = s.replace(/\s+/g, ' ').trim();
  return t.length > n ? t.slice(0, n) + '…' : t;
}

console.log(`=== ${stem}  (mode=${mode}) ===\n`);

console.log('--- GT sections ---');
for (const s of gt.sections ?? []) {
  if (secFilter && String(s.id) !== secFilter) continue;
  const qs = s.questions ?? [];
  const nums = qs.map((q: any) => q.num ?? q.number ?? '?');
  const types = [...new Set(qs.map((q: any) => q.type).filter(Boolean))];
  console.log(`[${s.id}] ${s.category ?? '?'} count=${qs.length} marks=${s.markTotal ?? s.marks ?? '?'} nums=${nums.join(',')} types=${types.join('|')}`);
  for (const q of qs.slice(0, 3)) console.log(`     q${q.num ?? q.number}: ${head(q.stem ?? q.text ?? '', 60)}`);
}

console.log('\n--- PARSED sections ---');
const pdoc = doc as unknown as { sections: any[] };
for (const s of pdoc.sections ?? []) {
  if (secFilter && String(s.id) !== secFilter) continue;
  const qs = s.questions ?? [];
  const nums = qs.map((q: any) => q.number ?? '?');
  const types = [...new Set(qs.map((q: any) => q.type).filter(Boolean))];
  console.log(`[${s.id}] ${s.category ?? '?'} count=${qs.length} markTotal=${(s as any).markTotal ?? '?'} nums=${nums.join(',')} types=${types.join('|')}`);
  for (const q of qs) {
    const optsQ = (q as any).options?.length ? ` opts=${(q as any).options.length}` : '';
    console.log(`     q${q.number}: ${(q as any).type}${optsQ} :: ${head(q.stem ?? '', 60)}`);
  }
}
