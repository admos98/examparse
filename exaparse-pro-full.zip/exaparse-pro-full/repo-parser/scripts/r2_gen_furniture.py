#!/usr/bin/env python3
"""Generate the KANOON_FURNITURE_RES block for parserEngine.ts from
hex-codepoint word specs (immune to bidi authoring scrambles), verify each
word against the real corpus lines, and splice it into the source."""

CORPUS = 'scratch/brain-app-qu2/texts'
FILES = [
    '14020228p91294y667', '14050319p65o69r989', '14050401pkhn2yd527',
    '14041010p265374941', '14040203p8zq62e1042', '14040304pt7kkv4576',
    '14050319pv684p2683', '14020406p4t7882699',
]
corpus_text = '\n'.join(open(f'{CORPUS}/{f}.txt').read() for f in FILES)

# logical-order words -> hex codepoints
WORDS = {
    'ادامه':   '627 62f 627 645 647',
    'سوالات':  '633 648 627 644 627 62a',
    'سؤالات':  '633 624 627 644 627 62a',
    'در':      '62f 631',
    'صفحه':    '635 641 62d 647',
    'تعداد':   '62a 639 62f 627 62f',
    'صفحات':   '635 641 62d 627 62a',
    'کل':      '6a9 644',
    'مدت':     '645 62f 62a',
    'آزمون':   '622 632 645 648 646',
    'امتحان':  '627 645 62a 62d 627 646',
    'پاسخگوی': '67e 627 633 62e 6af 648 6cc',
    'ساعت':    '633 627 639 62a',
    'شروع':    '634 631 648 639',
    'اداره':   '627 62f 627 631 647',
    'اموزش':   '627 645 648 632 634',
    'آموزش':   '622 645 648 632 634',
    'جمع':     '62c 645 639',
    'نمرات':   '646 645 631 627 62a',
    'نمره':    '646 645 631 647',
    'بارم':    '628 627 631 645',
    'نام':     '646 627 645',
    'درس':     '62f 631 633',
    'دبیر':    '62f 628 6cc 631',
    'خانوادگ': '62e 627 646 648 627 62f 6af',
    'تاریخ':   '62a 627 631 6cc 62e',
    'سال':     '633 627 644',
    'تحصیلی':  '62a 62d 635 6cc 644 6cc',
    'شماره':   '634 645 627 631 647',
    'صندلی':   '635 646 62f 644 6cc',
    'کارت':    '6a9 627 631 62a',
    'پدر':     '67e 62f 631',
    'محل':     '645 62d 644',
    'مهر':     '645 647 631',
    'بسته':    '628 633 62a 647',
    'جهش':     '62c 647 634',
    'کانون':   '6a9 627 646 648 646',
}

def word(hexes: str) -> str:
    return ''.join(chr(int(h, 16)) for h in hexes.split())

def scramble_variants(w: str) -> list[str]:
    """logical word + the kanoon lam-alef extraction swap (لا -> ال)."""
    variants = [w]
    i = w.find('\u0644\u0627')
    if i >= 0:
        variants.append(w[:i] + '\u0627\u0644' + w[i + 2:])
    return variants

# verify every word (or its scramble) appears in the corpus
print('== corpus verification ==')
for name, hx in WORDS.items():
    vs = scramble_variants(word(hx))
    hit = any(v in corpus_text for v in vs)
    print(('OK ' if hit else 'MISS'), name, '=>', ' | '.join(repr(v) for v in vs))

W = {k: word(v) for k, v in WORDS.items()}
SW = '(?:' + W['سوالات'] + '|' + W['سؤالات'] + ')'

# escape nothing — the words are literal text in a RegExp source
block = f'''/**
 * Printed page/brand furniture (R2). Kanoon/national papers repeat a header
 * block on every page and a watermark + continuation marker in the margin;
 * extraction interleaves them with the questions. Nothing in these lines is
 * ever exam content: the question seeder refuses them as stems, and the
 * radif closer-style spans strip them before parsing.
 * Persian words are composed from hex codepoints (fa) — bidi editors reorder
 * typed Persian regex literals, and the lam-alef extraction scramble
 * (لا -> ال) is tolerated by faPat.
 */
const fa = (hex: string): string =>
  String.fromCodePoint(...hex.split(' ').map((h) => parseInt(h, 16)));
const faPat = (hex: string): string =>
  fa(hex).replace(/\\u0644\\u0627/g, '[\\\\u0644\\\\u0627]{{2}}');
const SW_Q = '(?:' + faPat('{WORDS["سوالات"]}') + '|' + faPat('{WORDS["سؤالات"]}') + ')';
const KANOON_FURNITURE_RES: RegExp[] = [
  new RegExp(fa('{WORDS["ادامه"]}') + '\\\\s*' + SW_Q + '[\\\\u0600-\\\\u06FF]{{0,4}}\\\\s*' + fa('{WORDS["در"]}') + '\\\\s*' + fa('{WORDS["صفحه"]}')), // ادامه سوالات در صفحه N
  /www[\\s.-]*kanoon[\\s.-]*ir/i,                 // margin watermark
  new RegExp('^' + fa('{WORDS["تعداد"]}') + '\\\\s*(?:' + fa('{WORDS["کل"]}') + '\\\\s*)?' + fa('{WORDS["صفحات"]}')), // تعداد (کل) صفحات
  new RegExp('^' + fa('{WORDS["مدت"]}') + '\\\\s*(?:' + fa('{WORDS["آزمون"]}') + '|' + fa('{WORDS["امتحان"]}') + '|' + fa('{WORDS["پاسخگوی"]}') + ')'), // مدت آزمون/امتحان/پاسخگویی
  new RegExp('^' + fa('{WORDS["ساعت"]}') + '\\\\s*' + fa('{WORDS["شروع"]}')), // ساعت شروع
  new RegExp('^' + fa('{WORDS["اداره"]}') + '\\\\s*(?:' + fa('{WORDS["اموزش"]}') + '|' + fa('{WORDS["آموزش"]}') + '|' + fa('{WORDS["کل"]}') + ')'), // اداره آموزش/اموزش/کل
  new RegExp('^' + SW_Q + '\\\\s*\\\\('),        // سوالات (پاسخ نامه دارد)
  new RegExp(fa('{WORDS["جمع"]}') + '\\\\s*(?:' + fa('{WORDS["نمرات"]}') + '|' + fa('{WORDS["بارم"]}') + ')'), // جمع نمرات/بارم
  /^Good\\s*luck\\b/i,                            // farewell tail
  /^Take\\s*a\\s*taxi\\b/i,                       // farewell tail
  new RegExp(fa('{WORDS["بسته"]}') + '\\\\s*' + fa('{WORDS["جهش"]}') + '|' + fa('{WORDS["جهش"]}') + '\\\\s*' + fa('{WORDS["کانون"]}')), // kanoon ad banner
  new RegExp(fa('{WORDS["نام"]}') + '\\\\s*' + fa('{WORDS["درس"]}') + '|' + fa('{WORDS["نام"]}') + '\\\\s*' + fa('{WORDS["دبیر"]}') + '|' + fa('{WORDS["نام"]}') + '\\\\s*' + fa('{WORDS["خانوادگ"]}') + '|' + fa('{WORDS["تاریخ"]}') + '\\\\s*' + fa('{WORDS["امتحان"]}') + '|' + fa('{WORDS["سال"]}') + '\\\\s*' + fa('{WORDS["تحصیلی"]}') + '|' + fa('{WORDS["شماره"]}') + '\\\\s*' + fa('{WORDS["صندلی"]}') + '|' + fa('{WORDS["شماره"]}') + '\\\\s*' + fa('{WORDS["کارت"]}') + '|' + fa('{WORDS["نام"]}') + '\\\\s*' + fa('{WORDS["پدر"]}') + '|' + fa('{WORDS["محل"]}') + '\\\\s*' + fa('{WORDS["مهر"]}')), // student/teacher header fields
  new RegExp('^' + fa('{WORDS["نمره"]}') + '\\\\s*[:؟]?\\\\s*$|^' + fa('{WORDS["بارم"]}') + '\\\\s*[:؟]?\\\\s*$'), // bare نمره/بارم cells
  new RegExp('^' + fa('{WORDS["آزمون"]}') + '\\\\s*' + fa('{WORDS["درس"]}') + '|^' + fa('{WORDS["درس"]}') + '\\\\s*[:：]'), // آزمون درس / درس:
];'''

src = open('src/utils/parserEngine.ts').read()
start = src.find('/**\n * Printed page/brand furniture (R2).')
assert start >= 0, 'old block not found'
end = src.find('];', src.find('KANOON_FURNITURE_RES: RegExp[] = [', start))
assert end >= 0
end += len('];')
out = src[:start] + block + src[end:]
open('src/utils/parserEngine.ts', 'w').write(out)
print('\nblock spliced, new length', len(block))
