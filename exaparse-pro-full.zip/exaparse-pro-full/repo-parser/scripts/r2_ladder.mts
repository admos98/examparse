import fs from 'node:fs';
import { splitRadifNumberedSections } from '../src/utils/parserEngine';
const text = fs.readFileSync('scratch/brain-app-qu2/texts/14020228p91294y667.txt', 'utf8');
const blocks = splitRadifNumberedSections(text);
if (!blocks) { console.log('null'); process.exit(0); }
for (const b of blocks) {
  const lines = b.text.split('\n').filter((l) => l.trim());
  console.log(`rowId=${b.rowId} mark=${b.mark} cat=${b.category} header=${JSON.stringify((b.headerLine || '').slice(0, 50))}`);
  console.log(`   first2: ${JSON.stringify(lines[0]?.slice(0, 60))} | ${JSON.stringify(lines[1]?.slice(0, 60))}`);
  console.log(`   last1:  ${JSON.stringify(lines[lines.length - 1]?.slice(0, 60))}`);
}
