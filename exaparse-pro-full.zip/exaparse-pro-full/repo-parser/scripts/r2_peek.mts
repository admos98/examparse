import fs from 'node:fs';
import { parseExamRawText } from '../src/utils/parserEngine';
const text = fs.readFileSync('scratch/brain-app-qu2/texts/14020228p91294y667.txt', 'utf8');
const doc: any = parseExamRawText(text, 'x.pdf', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const);
const s = doc.sections[2];
console.log('section keys:', Object.keys(s));
console.log('sample q keys:', Object.keys(s.questions[0]));
for (const sec of doc.sections) {
  console.log(`id=${JSON.stringify(sec.id)} number=${JSON.stringify(sec.number)} cat=${sec.category} count=${sec.questions.length} markTotal=${sec.markTotal} title=${JSON.stringify(sec.title ?? null)}`);
}
