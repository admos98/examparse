import fs from 'node:fs';
const text = fs.readFileSync('scratch/brain-app-qu2/texts/14020228p91294y667.txt', 'utf8');
const lines = text.split(/\r?\n/);
const isStandaloneNumber = (l: string) => /^\.?\d{1,2}(?:\s*\/\s*\d{1,2})?(?:[.,]\d{1,2})?$/.test(l.trim());
const parseMark = (s: string): number | null => {
  const t = s.trim();
  let m = t.match(/^(\d{1,2})\s*\/\s*(\d{1,2})$/);
  if (m) return Math.round((parseInt(m[2], 10) + parseInt(m[1], 10) / Math.pow(10, m[1].length)) * 100) / 100;
  m = t.match(/^(\d{1,2})(?:[.,](\d{1,2}))?$/);
  if (m) return Math.round((parseInt(m[1], 10) + (m[2] ? parseInt(m[2], 10) / Math.pow(10, m[2].length) : 0)) * 100) / 100;
  return null;
};
// replicate: print all standalone numbers 0.25..20 with the next substantive line
for (let i = 0; i < lines.length; i++) {
  const t = lines[i].trim();
  if (!isStandaloneNumber(t)) continue;
  const v = parseMark(t);
  if (v === null || v < 0.25 || v > 20) continue;
  // next substantive
  let nxt = -1;
  for (let k = i + 1; k < lines.length; k++) {
    const tt = lines[k].trim();
    if (!tt) continue;
    nxt = k; break;
  }
  console.log(`${String(i).padStart(3)} mark=${String(v).padStart(4)} nxt=${String(nxt).padStart(3)} :: ${JSON.stringify(t)} -> ${JSON.stringify((lines[nxt] ?? '').trim().slice(0, 55))}`);
}
