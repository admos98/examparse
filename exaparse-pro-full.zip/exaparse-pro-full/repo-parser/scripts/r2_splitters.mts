import fs from 'node:fs';
import { splitRadifNumberedSections } from '../src/utils/parserEngine';
import * as PE from '../src/utils/parserEngine';

const show = (name: string, blocks: any) => {
  if (!blocks) { console.log(`${name}: null`); return; }
  console.log(`${name}: ${blocks.length} blocks`);
  for (const b of blocks) {
    const lines = String(b.text).split('\n').filter((l: string) => l.trim());
    console.log(`  [${b.rowId}] m=${b.mark} cat=${b.category} «${(lines[0] || '').slice(0, 45)}» q=${(String(b.text).match(/(?:^|\n)\s*\d{1,3}\s*[\.\)]/g) || []).length}`);
  }
};

for (const f of process.argv.slice(2)) {
  const text = fs.readFileSync(`scratch/brain-app-qu2/texts/${f}.txt`, 'utf8');
  console.log(`\n===== ${f}`);
  show('radif', splitRadifNumberedSections(text));
  // non-exported splitters via engine internals (access through a tiny harness)
  const pe: any = PE;
  for (const [name, fn] of [['marks-table', (pe as any).splitMarksTableSections], ['rule-ruled', (pe as any).splitRuleRuledSections], ['bare-marker', (pe as any).splitBareMarkerSections], ['instr-blocks', (pe as any).splitInstructionBlocks]]) {
    if (typeof fn === 'function') show(name, fn(text));
    else console.log(`${name}: (not accessible)`);
  }
}
