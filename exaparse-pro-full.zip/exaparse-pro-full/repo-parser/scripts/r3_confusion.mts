/**
 * r3_confusion — WHERE does typing fail? Post-R2 confusion matrices.
 * Aggregates qtype + category (got X want Y) pairs corpus-wide,
 * plus per-file qtype mass and concrete stem examples for the top confusions.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { runLayoutBrain } from '../src/utils/layoutBrain';
import { bridgeBrainResult } from '../src/utils/brainBridge';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2');
const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

type PairKey = string;
const qtypePairs = new Map<PairKey, number>();
const catPairs = new Map<PairKey, number>();
const fileQtype = new Map<string, number>();
// examples: pair -> [{file, qnum, stem, got, want}]
const pairExamples = new Map<PairKey, { file: string; q: string; stem: string; got: string; want: string }[]>();
const catExamples = new Map<PairKey, { file: string; sec: string; title: string; persian: string; english: string }[]>();

function bump(m: Map<string, number>, k: string) { m.set(k, (m.get(k) ?? 0) + 1); }

function main() {
  const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  for (const f of files) {
    const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
    const stem = gt.file.replace(/\.pdf$/i, '');
    const textPath = path.join(APP_TEXT_DIR, stem + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const text = fs.readFileSync(textPath, 'utf8');
    const opts = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const;

    const brainPath = path.join(BRAIN_DIR, stem + '.json');
    let blocks: Parameters<typeof parseExamRawText>[3] | undefined;
    if (fs.existsSync(brainPath)) {
      const brainDoc = JSON.parse(fs.readFileSync(brainPath, 'utf8'));
      const res = runLayoutBrain(brainDoc);
      const bridged = bridgeBrainResult(res);
      if (bridged) blocks = bridged.blocks;
    }
    const result = parseExamRawText(text, gt.file, opts, blocks);
    const g = gradeParse(result, gt);
    const issues = g.issues;
    const filePairs = new Map<PairKey, number>();

    for (const issue of issues) {
      const qt = issue.match(/ q(\d+) type: got (\S+) want (\S+)/);
      if (qt) {
        const key = `${qt[2]} -> ${qt[3]}`;
        bump(qtypePairs, key); bump(filePairs, key);
        const ex = pairExamples.get(key) ?? [];
        if (ex.length < 6) {
          const sec = findQuestion(result, qt[1]);
          ex.push({ file: stem, q: qt[1], stem: sec?.stem?.slice(0, 110) ?? '(n/a)', got: qt[2], want: qt[3] });
        }
        pairExamples.set(key, ex);
        continue;
      }
      const cat = issue.match(/(\S+) category: got (\S+) want (\S+)/);
      if (cat) {
        const key = `${cat[2]} -> ${cat[3]}`;
        bump(catPairs, key); bump(filePairs, 'cat:' + key);
        const ex = catExamples.get(key) ?? [];
        if (ex.length < 8) {
          const sec = (result?.sections ?? []).find((s: any) => String(s.rowId ?? s.id ?? '?') === cat[1]);
          ex.push({
            file: stem, sec: cat[1],
            title: (sec?.title ?? '').slice(0, 80),
            persian: (sec?.persianInstruction ?? '').slice(0, 90),
            english: (sec?.englishInstruction ?? '').slice(0, 60),
          });
        }
        catExamples.set(key, ex);
      }
    }
    const qtMass = [...filePairs.entries()].filter(([k]) => !k.startsWith('cat:')).reduce((a, [, v]) => a + v, 0);
    if (qtMass > 0) fileQtype.set(stem, qtMass);
  }

  const rank = (m: Map<string, number>) => [...m.entries()].sort((a, b) => b[1] - a[1]);

  console.log('=== QTYPE CONFUSION MATRIX (got -> want) ===');
  for (const [k, v] of rank(qtypePairs)) console.log(String(v).padStart(4), k);
  console.log('\n=== CATEGORY CONFUSION MATRIX (got -> want) ===');
  for (const [k, v] of rank(catPairs)) console.log(String(v).padStart(4), k);
  console.log('\n=== CATEGORY-PAIR EXAMPLES ===');
  for (const [k, v] of rank(catPairs).slice(0, 8)) {
    console.log(`\n-- ${k} (${v}) --`);
    for (const ex of catExamples.get(k) ?? []) {
      console.log(`   [${ex.file} sec ${ex.sec}] title=${JSON.stringify(ex.title)} fa=${JSON.stringify(ex.persian)} en=${JSON.stringify(ex.english)}`);
    }
  }
  console.log('\n=== FILE QTYPE MASS ===');
  for (const [k, v] of rank(fileQtype)) console.log(String(v).padStart(4), k);
  console.log('\n=== TOP-PAIR EXAMPLES ===');
  for (const [k, v] of rank(qtypePairs).slice(0, 10)) {
    console.log(`\n-- ${k} (${v}) --`);
    for (const ex of pairExamples.get(k) ?? []) {
      console.log(`   [${ex.file} q${ex.q}] ${JSON.stringify(ex.stem)}`);
    }
  }
}

function findQuestion(result: any, qnum: string): any {
  for (const sec of result?.sections ?? []) {
    for (const q of sec.questions ?? []) {
      if (String(q.number) === String(qnum)) return q;
    }
  }
  return null;
}

main();
