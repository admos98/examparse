import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const gtName = process.argv[2] ?? 'zaban-haftom-nobat-avval-pdf.json';
const stem0 = gtName.replace(/(-pdf)?\.json$/i, '');
const gt = JSON.parse(fs.readFileSync(path.join(WS_ROOT, 'scratch', process.env.GT_SUB ?? 'gt', gtName), 'utf8'));
const text = fs.readFileSync(
  process.env.TEXT_SUB ? path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts', stem0 + '.txt') : path.join(WS_ROOT, 'scratch', 'texts', gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt'),
  'utf8',
);
const doc = parseExamRawText(text, gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
const res = gradeParse(doc, gt);
for (const iss of res.issues) console.log(iss);
for (const sec of doc.sections as any[]) {
  const id = String(sec.rowId ?? '');
  const got = String(sec.majorCategory);
  if (process.argv[3] && !process.argv[3].split(',').includes(id)) continue;
  console.log(`--- sec ${id} got ${got} | title: ${JSON.stringify(sec.title?.slice(0, 80))} | fa: ${JSON.stringify(sec.persianInstruction?.slice(0, 100))} | en: ${JSON.stringify(sec.englishInstruction?.slice(0, 80))}`);
  for (const q of (sec.questions ?? []).slice(0, 4)) console.log(`    q${q.number} [${q.type}] ${JSON.stringify((q.stem ?? '').slice(0, 80))}`);
}
