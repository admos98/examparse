/**
 * r3_sections — dump per-section evidence (title / persianInstruction /
 * englishInstruction / category / qtype histogram) for sections involved in
 * the top typing confusions, so the R3 attack is grounded in what the
 * instruction text actually says.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { runLayoutBrain } from '../src/utils/layoutBrain';
import { bridgeBrainResult } from '../src/utils/brainBridge';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2');
const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

// Sections of interest, keyed by file stem -> section rowIds (from GT issues).
const TARGETS: Record<string, { cats: Set<string>; qt: Set<string> }> = {
  p53x7md884: { cats: new Set(['2', '5', '8', '9', '13']), qt: new Set() },     // fill_blank->matching q15-17 + form q27-34
  p91294y667: { cats: new Set(), qt: new Set(['19']) },                          // fill_blank->matching q19-22
  p2657j6465: { cats: new Set(), qt: new Set(['14', '25']) },                    // fill_blank->form_in_parentheses
  p8yp4c9983: { cats: new Set(['A', 'C', 'E', 'F']), qt: new Set() },            // category misses
  p28932i821: { cats: new Set(), qt: new Set(['41']) },                          // fill_blank->short_answer A:...B:...
  p4p187l300: { cats: new Set(), qt: new Set() },                                // top qtype mass 21 — dump all
  pc8er2b581: { cats: new Set(), qt: new Set() },                                // top qtype mass 20 — dump all
  pkc61q4341: { cats: new Set(), qt: new Set() },                                // qtype 18
  p4tk9v2803: { cats: new Set(), qt: new Set() },                                // qtype 18
  pkhn2yd527: { cats: new Set(), qt: new Set() },                                // qtype 18
  paq214l942: { cats: new Set(), qt: new Set() },                                // qtype 11
  pd24nl1531: { cats: new Set(), qt: new Set() },                                // qtype 15
};

function main() {
  const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  for (const f of files) {
    const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
    const stem = gt.file.replace(/\.pdf$/i, '');
    const short = stem.replace(/^140\d+/, '');
    const tgt = TARGETS[short];
    if (!tgt) continue;
    const textPath = path.join(APP_TEXT_DIR, stem + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const text = fs.readFileSync(textPath, 'utf8');
    const opts = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const;

    const brainPath = path.join(BRAIN_DIR, stem + '.json');
    let blocks: Parameters<typeof parseExamRawText>[3] | undefined;
    if (fs.existsSync(brainPath)) {
      const brainDoc = JSON.parse(fs.readFileSync(brainPath, 'utf8'));
      const res = runLayoutBrain(brainDoc);
      const bridged = bridgeBrainResult(res);
      if (bridged) blocks = bridged.blocks;
    }
    const result = parseExamRawText(text, gt.file, opts, blocks);

    // GT side map: section id -> {category, qtype histogram}
    const gtSecs = new Map<string, { cat: string; types: Map<string, number> }>();
    for (const s of gt.sections ?? []) {
      const types = new Map<string, number>();
      for (const q of s.questions ?? []) types.set(q.type, (types.get(q.type) ?? 0) + 1);
      gtSecs.set(String(s.id), { cat: s.category ?? '?', types });
    }

    console.log(`\n########## ${stem} ##########`);
    for (const sec of result.sections ?? []) {
      const id = String((sec as any).rowId ?? '?');
      const gtSec = gtSecs.get(id);
      const hist = new Map<string, number>();
      for (const q of sec.questions ?? []) hist.set(q.type, (hist.get(q.type) ?? 0) + 1);
      const histStr = [...hist.entries()].map(([k, v]) => `${k}:${v}`).join(' ');
      const gtStr = gtSec ? `GT[cat=${gtSec.cat} ${[...gtSec.types.entries()].map(([k, v]) => `${k}:${v}`).join(' ')}]` : 'GT[?]';
      const catHit = (sec as any).majorCategory === gtSec?.cat;
      const interesting =
        tgt.cats.size === 0 && tgt.qt.size === 0
          ? true
          : tgt.cats.has(id) || !catHit || [...hist.keys()].some((t) => gtSec?.types.has(t) === false);
      if (!interesting) continue;
      console.log(`\n== sec ${id} got=${(sec as any).majorCategory} ${gtStr} nq=${sec.questions?.length ?? 0}`);
      console.log(`   title: ${JSON.stringify((sec.title ?? '').slice(0, 90))}`);
      console.log(`   persian: ${JSON.stringify((sec.persianInstruction ?? '').slice(0, 160))}`);
      console.log(`   english: ${JSON.stringify((sec.englishInstruction ?? '').slice(0, 130))}`);
      console.log(`   types: ${histStr}`);
      for (const q of (sec.questions ?? []).slice(0, 4)) {
        console.log(`   q${q.number} [${q.type}] ${JSON.stringify((q.stem ?? '').slice(0, 100))}`);
      }
    }
  }
}

main();
