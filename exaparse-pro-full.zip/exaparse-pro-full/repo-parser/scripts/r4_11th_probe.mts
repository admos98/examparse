/**
 * r4_11th_probe — why does 11th-first P still type cloze_item? Check the
 * contractCloze / isCloze inputs against the actual block + passage text.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const GOLDEN_DIR = path.join(WS_ROOT, 'scratch', 'texts');
const text = fs.readFileSync(path.join(GOLDEN_DIR, '11th_first.pdf.txt'), 'utf8');
const doc: any = parseExamRawText(text, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as any);
for (const s of doc.sections) {
  if (String(s.rowId) !== 'P') continue;
  const p = String((s.questions ?? [])[0]?.parentContextText ?? '');
  console.log('parentContextType=', (s.questions ?? [])[0]?.parentContextType);
  console.log('passage /cloze/i:', /cloze/i.test(p), '| passage /\\[\\d+\\]/:', /\[\d+\]/.test(p));
  console.log('FULL PASSAGE:\n', p);
}
// grep the raw document for cloze
const lines = text.split(/\r?\n/);
lines.forEach((l, i) => {
  if (/cloze/i.test(l)) console.log(`raw line ${i}: ${JSON.stringify(l.slice(0, 100))}`);
});
