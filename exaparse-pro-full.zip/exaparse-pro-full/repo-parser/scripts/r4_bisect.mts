/**
 * r4_bisect — fast per-file gate harness (identical pipeline to grade.mts:
 * parseExamRawText -> applyMinedRules -> gradeParse) for a file-subset, so
 * R4 hunks can be bisected without rerunning the full 30+20+6 gates.
 * Usage: npx tsx scripts/r4_bisect.mts <gtDir> <textDir> <file substring>...
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse, GoldenGT } from '../src/utils/goldenGrade';
import { applyMinedRules, MinedRule } from '../src/utils/ruleMiner';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const [gtDir, textDir, ...filters] = process.argv.slice(2);
const GT_DIR = gtDir.startsWith('/') ? gtDir : path.join(WS_ROOT, gtDir);
const TEXT_DIR = textDir.startsWith('/') ? textDir : path.join(WS_ROOT, textDir);
const MINED_RULES_PATH = path.join(PKG_ROOT, 'data', 'mined-rules.json');

function loadLiveMinedRules(): MinedRule[] {
  try {
    const parsed = JSON.parse(fs.readFileSync(MINED_RULES_PATH, 'utf8'));
    return Array.isArray(parsed) ? parsed.filter((r) => r && r.status === 'live') : [];
  } catch {
    return [];
  }
}

const liveRules = loadLiveMinedRules();
let fails = 0;
for (const f of fs.readdirSync(GT_DIR).filter((x) => x.endsWith('.json')).sort()) {
  const gt: GoldenGT = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
  if (filters.length && !filters.some((s) => gt.file.includes(s))) continue;
  const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
  if (!fs.existsSync(textPath)) { console.log(`SKIP ${gt.file}`); continue; }
  const text = fs.readFileSync(textPath, 'utf8');
  const parsed = parseExamRawText(text, gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  const doc = liveRules.length ? applyMinedRules(parsed, liveRules) : parsed;
  const { score, issues, total } = gradeParse(doc, gt);
  if (issues.length) fails++;
  console.log(`${issues.length ? 'FAIL' : 'PASS'} ${score.toFixed(1)}% (${total - issues.length}/${total}) ${gt.file}`);
  for (const i of issues.slice(0, 14)) console.log(`   - ${i}`);
}
process.exit(fails ? 1 : 0);
