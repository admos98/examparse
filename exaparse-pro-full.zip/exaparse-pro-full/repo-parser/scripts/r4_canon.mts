/**
 * r4_canon — dump the CANONICAL block that splitRadifNumberedSections feeds
 * to detectInitialCategory for the listening sections, codepoint-audited.
 */
import fs from 'node:fs';
import path from 'node:path';
import { canonicalize } from '../src/utils/textCanonical';
import { normalizeOcrText } from '../src/utils/ocrPreprocessor';
import { splitRadifNumberedSections } from '../src/utils/parserEngine';
import { PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

function audit(label: string, s: string) {
  const codes = [...s].slice(0, 40).map((c) => c.codePointAt(0)!.toString(16)).join(' ');
  console.log(`  [${label}] ${JSON.stringify(s.slice(0, 70))}`);
  console.log(`    cps: ${codes}`);
}

const stem = process.argv[2] ?? '14040203p28932i821';
const raw = fs.readFileSync(path.join(APP_TEXT_DIR, stem + '.txt'), 'utf8');
const canon = normalizeOcrText(canonicalize(raw).text);
console.log(`########## ${stem} canonical ##########`);
const blocks = splitRadifNumberedSections(canon);
if (!blocks) { console.log('(radif splitter returned null)'); process.exit(0); }
for (const b of blocks.slice(0, 4)) {
  console.log(`block ${b.rowId} cat=${b.category}`);
  console.log(`  headerLine=${JSON.stringify(b.headerLine.slice(0, 80))}`);
  const firstFa = b.text.split(/\r?\n/).find((l) => /[\u0600-\u06FF]/.test(l)) ?? '';
  audit('first fa line', firstFa);
  const re = /فایل\s*صوتی|گوش\s*دهید|شنیداری|listening|audio/i;
  console.log(`  reListening on full text: ${re.test(b.text)}`);
  const m = b.text.match(/فایل[\s\S]{0,6}صوتی/);
  if (m) audit('فایل…صوتی match', m[0]);
}
