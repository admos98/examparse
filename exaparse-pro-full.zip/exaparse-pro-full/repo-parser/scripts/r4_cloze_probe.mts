/**
 * r4_cloze_probe — dump passage text + option rows for the printedCloze
 * true/false cases to find the discriminator.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');
const GOLDEN_DIR = path.join(WS_ROOT, 'scratch', 'texts');

const CASES: { name: string; textPath: string; want: string }[] = [
  { name: 'FALSE p43266 sec7 (want mcq)', textPath: path.join(APP_TEXT_DIR, '14050320p43266n364.txt'), want: 'mcq' },
  { name: 'FALSE 11th-first P (want mcq)', textPath: path.join(GOLDEN_DIR, '11th_first.pdf.txt'), want: 'mcq' },
  { name: 'TRUE 2657 K (want cloze_item)', textPath: path.join(APP_TEXT_DIR, '14020406p2657j6465.txt'), want: 'cloze_item' },
  { name: 'TRUE pu557 C (want cloze_item)', textPath: path.join(APP_TEXT_DIR, '14040203pu557l5203.txt'), want: 'cloze_item' },
];

for (const c of CASES) {
  if (!fs.existsSync(c.textPath)) { console.log(`(missing ${c.textPath})`); continue; }
  const text = fs.readFileSync(c.textPath, 'utf8');
  console.log(`\n########## ${c.name}`);
  const doc: any = parseExamRawText(text, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as any);
  for (const s of doc.sections) {
    const hasClozeish = / cloze|cloze_passage/.test(JSON.stringify((s.questions ?? []).map((q: any) => q.parentContextType ?? ''))) ;
    const types = [...new Set((s.questions ?? []).map((q: any) => q.type))].join(',');
    const printed = /\.{2,}\s*\d{1,3}\s*\.{2,}|…+\s*\d{1,3}\s*…+/.test(String((s.questions ?? [])[0]?.parentContextText ?? ''));
    if (!printed && !hasClozeish) continue;
    console.log(`  sec ${s.rowId} cat=${s.majorCategory} nq=${s.questions.length} types=${types} printedBlankInPassage=${printed}`);
    const p = String((s.questions ?? [])[0]?.parentContextText ?? '');
    if (printed) {
      console.log(`    PASSAGE: ${JSON.stringify(p.slice(0, 400))}`);
      const hits = [...p.matchAll(/(?:\.{2,}|…+)\s*(\d{1,3})\s*(?:\.{2,}|…+)/g)].map((m) => m[1]);
      console.log(`    passage blank numbers: [${hits.join(',')}]`);
    }
    for (const q of s.questions.slice(0, 8)) {
      console.log(`      q${q.number} [${q.type}] stem=${JSON.stringify((q.stem ?? '').slice(0, 70))} opts=${q.options?.length ?? 0}`);
    }
  }
}
