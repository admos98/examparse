/**
 * r4_cloze_probe2 — section-level instruction + raw block text for the
 * printedCloze true/false cases.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');
const GOLDEN_DIR = path.join(WS_ROOT, 'scratch', 'texts');

const CASES: { name: string; textPath: string; secIds: string[] }[] = [
  { name: 'FALSE p43266 (want mcq)', textPath: path.join(APP_TEXT_DIR, '14050320p43266n364.txt'), secIds: ['7'] },
  { name: 'FALSE 11th-first (want mcq)', textPath: path.join(GOLDEN_DIR, '11th_first.pdf.txt'), secIds: ['P'] },
  { name: 'TRUE 2657 (want cloze_item)', textPath: path.join(APP_TEXT_DIR, '14020406p2657j6465.txt'), secIds: ['K'] },
];

for (const c of CASES) {
  const text = fs.readFileSync(c.textPath, 'utf8');
  console.log(`\n########## ${c.name}`);
  const doc: any = parseExamRawText(text, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as any);
  for (const s of doc.sections) {
    if (!c.secIds.includes(String(s.rowId))) continue;
    console.log(`  sec ${s.rowId} cat=${s.majorCategory}`);
    console.log(`    title=${JSON.stringify(s.title ?? '')}`);
    console.log(`    persianInstruction=${JSON.stringify(String((s as any).persianInstruction ?? '').slice(0, 120))}`);
    console.log(`    englishInstruction=${JSON.stringify(String((s as any).englishInstruction ?? '').slice(0, 120))}`);
    const p = String((s.questions ?? [])[0]?.parentContextText ?? '');
    console.log(`    passageLen=${p.length}`);
    console.log(`    passageTail=${JSON.stringify(p.slice(-220))}`);
    const qnums = (s.questions ?? []).map((q: any) => q.number);
    const blankHits = [...p.matchAll(/(?:\.{2,}|…+)\s*(\d{1,3})\s*(?:\.{2,}|…+)/g)].map((m) => Number(m[1]));
    console.log(`    qnums=${JSON.stringify(qnums)} passageBlanks=${JSON.stringify(blankHits)}`);
  }
}
