/**
 * r4_cloze_probe3 — check the remaining true-positive cloze files' printed
 * contracts (pu557 C, 265374941 L).
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const APP_TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');

const CASES: { name: string; textPath: string; secIds: string[] }[] = [
  { name: 'TRUE pu557 (want cloze_item)', textPath: path.join(APP_TEXT_DIR, '14040215pu557l5203.pdf.txt'), secIds: ['C'] },
  { name: 'TRUE 265374941 (want cloze_item)', textPath: path.join(APP_TEXT_DIR, '14041010p265374941.pdf.txt'), secIds: ['L'] },
];

for (const c of CASES) {
  if (!fs.existsSync(c.textPath)) { console.log(`(missing ${c.textPath})`); continue; }
  const text = fs.readFileSync(c.textPath, 'utf8');
  console.log(`\n########## ${c.name}`);
  const doc: any = parseExamRawText(text, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as any);
  for (const s of doc.sections) {
    if (!c.secIds.includes(String(s.rowId))) continue;
    console.log(`  sec ${s.rowId} cat=${s.majorCategory} nq=${s.questions.length}`);
    console.log(`    title=${JSON.stringify(s.title ?? '')}`);
    console.log(`    persianInstruction=${JSON.stringify(String((s as any).persianInstruction ?? '').slice(0, 140))}`);
    console.log(`    englishInstruction=${JSON.stringify(String((s as any).englishInstruction ?? '').slice(0, 140))}`);
    const types = [...new Set((s.questions ?? []).map((q: any) => q.type))].join(',');
    console.log(`    types=${types}`);
    const p = String((s.questions ?? [])[0]?.parentContextText ?? '');
    console.log(`    passageHead=${JSON.stringify(p.slice(0, 150))}`);
  }
}
