/** r4_dupe — why do splitters emit duplicate section cycles? (p2657 A..L ×2) */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

for (const f of process.argv.slice(2).length ? process.argv.slice(2) : ['14020406p2657j6465.pdf']) {
  const stem = f.replace(/\.pdf$/i, '');
  const text = fs.readFileSync(path.join(WS_ROOT, 'scratch/texts-qu2', stem + '.pdf.txt'), 'utf8');
  const doc: any = parseExamRawText(text, f, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  console.log(`===== ${f} — ${doc.sections?.length} sections`);
  for (const s of doc.sections ?? []) {
    console.log(
      `  id=${s.rowId} cat=${s.majorCategory ?? s.category} mark=${s.mark} markTotal=${s.markTotal ?? s.totalMark} nq=${(s.questions ?? []).length} title=${JSON.stringify(String(s.title ?? '').slice(0, 44))}`,
    );
  }
}
