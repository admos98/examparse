/**
 * r4_gatefight — locate where the R4 banner-less key detector fires on the
 * two regressed golden docx files, and dump the text around the cut.
 */
import fs from 'node:fs';
import path from 'node:path';
import { findKeySheetBoundary } from '../src/utils/parserEngine';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts');
const FILES = ['انگلیسی_8_مستمر_یک.docx.txt', 'انگلیسی_9_مستمر_یک.docx.txt'];

for (const f of FILES) {
  const text = fs.readFileSync(path.join(TEXT_DIR, f), 'utf8');
  const lines = text.split(/\r?\n/);
  const cut = findKeySheetBoundary(text);
  console.log(`\n##### ${f} lines=${lines.length} findKeySheetBoundary=${cut}`);
  if (cut >= 0) {
    // locate the cut line index
    let off = 0;
    for (let i = 0; i < lines.length; i++) {
      if (off >= cut) {
        console.log(`  cut at line ${i}`);
        for (let k = Math.max(0, i - 8); k < Math.min(lines.length, i + 10); k++) {
          console.log(`   ${k === i ? '>>' : '  '} ${k}: ${JSON.stringify(lines[k].slice(0, 100))}`);
        }
        break;
      }
      off += lines[i].length + 1;
    }
  } else {
    console.log('  (no key boundary detected)');
  }
}
