/**
 * r4_gatefight2 — full parse dump for the regressed golden docx files:
 * section boundaries, categories, counts. PARSE_DEBUG shows splitter choice.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts');
const FILES = ['انگلیسی_8_مستمر_یک.docx.txt', 'انگلیسی_9_مستمر_یک.docx.txt'];

for (const f of FILES) {
  const text = fs.readFileSync(path.join(TEXT_DIR, f), 'utf8');
  console.log(`\n########## ${f}`);
  const doc: any = parseExamRawText(text, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as any);
  for (const s of doc.sections) {
    const types = new Map<string, number>();
    for (const q of s.questions) types.set(q.type, (types.get(q.type) ?? 0) + 1);
    const tstr = [...types.entries()].map(([k, v]) => `${k}:${v}`).join(' ') || '-';
    console.log(`  sec ${s.rowId} cat=${s.majorCategory} mark=${(s as any).totalMarks ?? '-'} nq=${s.questions.length} [${tstr}]`);
    console.log(`     title=${JSON.stringify((s.title ?? '').slice(0, 60))}`);
    for (const q of s.questions.slice(0, 3)) console.log(`       q${q.number}: ${JSON.stringify((q.stem ?? '').slice(0, 60))}`);
  }
}
