/** r4_ladder — dump splitRadifNumberedSections output for the docx regression files. */
import fs from 'node:fs';
import path from 'node:path';
import { splitRadifNumberedSections } from '../src/utils/parserEngine';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

for (const f of process.argv.slice(2).length ? process.argv.slice(2) : ['انگلیسی 8 مستمر یک.docx', 'انگلیسی 9 مستمر یک.docx']) {
  const stem = f.replace(/\.docx$/i, '').replace(/\s+/g, '_');
  for (const ext of ['.docx.txt', '.pdf.txt']) {
    const p = path.join(WS_ROOT, 'scratch/texts', stem + ext);
    if (!fs.existsSync(p)) continue;
    const text = fs.readFileSync(p, 'utf8');
    const blocks = splitRadifNumberedSections(text) as any[] | null;
    console.log(`\n===== ${f}${ext} -> ${blocks ? blocks.length + ' blocks' : 'null'}`);
    if (!blocks) continue;
    for (const b of blocks) {
      const nq = (b.text.match(/^\s*\d{1,2}\s*[..)]/gm) || []).length;
      console.log(`  row=${b.rowId} cat=${b.category} mark=${b.mark} markRows≈${nq} hdr=${JSON.stringify((b.headerLine || '').slice(0, 50))}`);
    }
  }
}
