/** r4_marks — all mark/markTotal/totalMarks issues across the qu2 corpus, with section evidence. */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch/gt-qu2');
const TEXT_DIR = path.join(WS_ROOT, 'scratch/texts-qu2');
const re = /(?: (\d+|[A-Z]) (?:markTotal|mark:))|totalMarks|(?:mark:)/;

for (const f of fs.readdirSync(GT_DIR).filter((x) => x.endsWith('.json')).sort()) {
  const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
  const stem = gt.file.replace(/\.pdf$/i, '');
  const textPath = path.join(TEXT_DIR, stem + '.pdf.txt');
  if (!fs.existsSync(textPath)) continue;
  const text = fs.readFileSync(textPath, 'utf8');
  const doc: any = parseExamRawText(text, gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  const g = gradeParse(doc, gt);
  const markIssues = g.issues.filter((i: string) => /mark/i.test(i));
  if (!markIssues.length) continue;
  console.log(`\n### ${gt.file} (${markIssues.length} mark issues)`);
  for (const iss of markIssues.slice(0, 10)) console.log('   -', iss);
  // section mark evidence for the first 2 offending sections
  const secIds = markIssues.slice(0, 3).map((i: string) => (/^\s*(\S+)/.exec(i)?.[1] ?? ''));
  for (const s of doc.sections ?? []) {
    if (!secIds.includes(String(s.rowId))) continue;
    console.log(`   [sec ${s.rowId}] mark=${s.mark} markTotal=${s.markTotal} title=${JSON.stringify(String(s.title ?? '').slice(0, 40))} bodyNums=${(String(s.text).match(/^\s*\d{1,2}(?:[.,]\d{1,2})?\s*$/gm) ?? []).map((x: string) => x.trim()).slice(0, 6).join(',')}`);
  }
}
