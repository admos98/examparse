/**
 * r4_pq89_probe — dump pq89 sec 18 (q63-67) parse: instruction, stems, types,
 * and the raw text lines of the block that produced it.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const APP_TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
const text = fs.readFileSync(path.join(APP_TEXT_DIR, '13991009pq89w65173.pdf.txt'), 'utf8');
const doc: any = parseExamRawText(text, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as any);
for (const s of doc.sections) {
  const q = s.questions ?? [];
  const has63 = q.some((qq: any) => Number(qq.number) >= 62);
  if (!has63) continue;
  console.log(`sec ${s.rowId} cat=${s.majorCategory} nq=${q.length}`);
  console.log(`  title=${JSON.stringify(s.title ?? '')}`);
  console.log(`  fa=${JSON.stringify(String((s as any).persianInstruction ?? '').slice(0, 200))}`);
  console.log(`  en=${JSON.stringify(String((s as any).englishInstruction ?? '').slice(0, 200))}`);
  for (const qq of q) {
    console.log(`  q${qq.number} [${qq.type}] stem=${JSON.stringify((qq.stem ?? '').slice(0, 90))}`);
    console.log(`     ctx=${JSON.stringify(String(qq.parentContextText ?? '').slice(0, 90))}`);
  }
}
// also dump the raw tail of the document
const lines = text.split(/\r?\n/);
console.log(`\n--- raw tail (last 30 lines) ---`);
for (let i = Math.max(0, lines.length - 30); i < lines.length; i++) {
  console.log(`  ${i}: ${JSON.stringify(lines[i].slice(0, 110))}`);
}
