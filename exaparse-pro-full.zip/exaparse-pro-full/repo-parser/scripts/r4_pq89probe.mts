/** r4_pq89probe — why does the phrase-drop gate not fire on pq89 sec18? */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const stem = '13991009pq89w65173';
const text = fs.readFileSync(path.join(WS_ROOT, 'scratch/texts-qu2', stem + '.pdf.txt'), 'utf8');
const doc: any = parseExamRawText(text, stem + '.pdf', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
for (const s of doc.sections ?? []) {
  if (String(s.rowId) !== '18') continue;
  const instrText = `${s.title || ''} ${s.persianInstruction || ''} ${s.englishInstruction || ''}`;
  console.log('title=', JSON.stringify(s.title));
  console.log('faInstr=', JSON.stringify(s.persianInstruction));
  console.log('enInstr=', JSON.stringify(s.englishInstruction));
  console.log('wordBank=', JSON.stringify(s.wordBank));
  console.log('hasWordBank=', s.hasWordBank);
  console.log('phrase-drop regex hits phrases/عبارات?', /phrases?|عبارات/i.test(instrText));
  console.log('bank all multi-word?', (s.wordBank ?? []).every((w: string) => w.trim().split(/\s+/).length >= 2));
  for (const q of s.questions ?? []) {
    console.log(`q${q.displayNumber ?? q.number} type=${q.type} ctx=${JSON.stringify((q.parentContextText ?? '').slice(0, 60))}`);
  }
}
