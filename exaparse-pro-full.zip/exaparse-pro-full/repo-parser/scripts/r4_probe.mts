/**
 * r4_probe — WHY did listening-contract sections get Vocabulary?
 * Runs the shipped default parse on selected files, prints per-section
 * category + qtypes, and replays detectInitialCategory's exact pass order
 * (copied verbatim) on the section's reconstructed header/body to expose
 * which pass produced the losing category.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText, splitRadifNumberedSections } from '../src/utils/parserEngine';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

const FILES = process.argv.slice(2).length ? process.argv.slice(2) : ['14040316pkc61q4341'];

// Verbatim copy of the detection regexes (parserEngine.ts detectInitialCategory).
const R3_SKILL_LABEL_LINE = /^(?:Listening|Speaking|Reading|Writing|Vocabulary|Grammar|Language Function|Pronunciation)\s*$/i;
function r3HitAny(t: string, res: RegExp[]) { return res.some((r) => r.test(t)); }

function detectInitialCategoryCopy(headerLine: string, blockText: string) {
  const headerOnly = headerLine.toLowerCase();
  let body = blockText.slice(0, 600);
  for (let i = 0; i < 2; i++) {
    const trimmed = body.replace(/\s+$/, '');
    const nl = trimmed.lastIndexOf('\n');
    const lastLine = trimmed.slice(nl + 1).trim();
    if (lastLine && R3_SKILL_LABEL_LINE.test(lastLine)) body = trimmed.slice(0, nl + 1);
    else break;
  }
  const combined = `${headerLine}\n${body}`.toLowerCase();
  const sqHeader = headerOnly.replace(/\s+/g, '');
  const sqCombined = combined.replace(/\s+/g, '');
  const reListening = /listening|audio|listen\s+to|شنیداری|گوش\s*دهید|فایل\s*صوتی/i;
  const reReading = /reading|passage|comprehension|cloze|درک\s*مطلب|متن\s*زیر\s*را\s*بخوانید|ریدینگ|کلوز/i;
  const reVocab = /choose\s+the\s+correct\s+answer|vocabulary|words?\s+in\s+the\s+box|using\s+the\s+words|words?\s+given|given\s+words?|fill\s+in\s+the\s+blanks?\s+with\s+(?:the\s+)?words?|spelling|واژگان|واژه|لغت|کلمات|کلمه|کادر|جعبه|املا|گزینه/i;
  const reGrammar = /fill\s+in\s+the\s+blanks|grammar|grammatical|parentheses|tenses?|preposition|دستور\s*زبان|دستور|گرامر|قواعد|شکل\s*صحیح/i;
  const reWriting = /writing|unscramble|reorder|punctuation|combine|make\s+a\s+sentence|نگارش|نوشتن|مرتب\s*کنید/i;
  const listenHit =
    reListening.test(headerOnly) || reListening.test(combined) || reListening.test(sqHeader) || reListening.test(sqCombined);
  const readingHit =
    reReading.test(headerOnly) || reReading.test(combined) || reReading.test(sqHeader) || reReading.test(sqCombined);
  console.log(`    [probe] listenHit=${listenHit} readingHit=${readingHit}`);
  console.log(`    [probe] body(0,120)=${JSON.stringify(body.slice(0, 120))}`);
  for (const [re, cat] of [[reListening, 'Listening'], [reReading, 'Reading'], [reVocab, 'Vocabulary'], [reGrammar, 'Grammar'], [reWriting, 'Writing']] as const) {
    if (re.test(headerOnly) || re.test(sqHeader)) return `pass1-header -> ${cat}`;
  }
  for (const [re, cat] of [[reListening, 'Listening'], [reReading, 'Reading'], [reVocab, 'Vocabulary'], [reGrammar, 'Grammar'], [reWriting, 'Writing']] as const) {
    if (re.test(combined)) return `pass2-combined -> ${cat}`;
  }
  for (const [re, cat] of [[reListening, 'Listening'], [reReading, 'Reading'], [reVocab, 'Vocabulary'], [reGrammar, 'Grammar'], [reWriting, 'Writing']] as const) {
    if (re.test(sqCombined)) return `pass3-squashed -> ${cat}`;
  }
  return '-> General';
}

function main() {
  for (const stem of FILES) {
    const textPath = path.join(APP_TEXT_DIR, stem + '.txt');
    if (!fs.existsSync(textPath)) { console.log(`(no text for ${stem})`); continue; }
    const text = fs.readFileSync(textPath, 'utf8');
    console.log(`\n########## ${stem} ##########`);
    const doc = parseExamRawText(text, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as any);
    for (const s of doc.sections) {
      const types = new Map<string, number>();
      for (const q of s.questions) types.set(q.type, (types.get(q.type) ?? 0) + 1);
      const tstr = [...types.entries()].map(([k, v]) => `${k}:${v}`).join(' ') || '-';
      const instr = [s.title?.replace(/^Section [^:]*:?\s*/, ''), (s as any).persianInstruction ?? '']
        .filter(Boolean).join(' | ').slice(0, 90);
      console.log(`  sec ${s.rowId} cat=${(s as any).majorCategory} nq=${s.questions.length} [${tstr}]`);
      console.log(`     instr: ${instr}`);
    }
    // Replay: reconstruct the sec-3-ish block from the radif splitter when present.
    const radifBlocks = splitRadifNumberedSections(text);
    if (radifBlocks) {
      for (const b of radifBlocks.slice(0, 20)) {
        const listen = /فایل صوتی|گوش|شنید|listening|audio/i.test(b.text);
        console.log(`  [radif block ${b.rowId}] listen=${listen} cat=${b.category ?? '-'} label=${(b as any).labelCategory ?? '-'} headerLine=${JSON.stringify((b.headerLine ?? '').slice(0, 70))}`);
        if (listen) console.log('    detection replay:', detectInitialCategoryCopy(b.headerLine ?? '', b.text));
      }
    }
  }
}

main();
