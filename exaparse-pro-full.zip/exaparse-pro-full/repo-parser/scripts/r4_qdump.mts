/**
 * r4_qdump — evidence dump for the top qtype confusions post-R3.
 * Uses gradeParse issue strings ("q15 type: got X want Y") for authoritative
 * alignment, then looks up the parsed question by number for stem evidence.
 * Grouped by (got -> want) pair, sorted by pair mass.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { runLayoutBrain } from '../src/utils/layoutBrain';
import { bridgeBrainResult } from '../src/utils/brainBridge';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2');
const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

const ONLY = process.argv[2]; // optional filter: e.g. "fill_blank->short_answer"
const MAX_PER_PAIR = Number(process.argv[3] ?? 30);

function squash(s: string) { return s.replace(/\s+/g, ' ').trim(); }
function qtypeRe() { return / q(\d+) type: got (\S+) want (\S+)/; }

function main() {
  const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  type Row = { file: string; pair: string; qnum: string; cat: string; instr: string; stem: string; text: string };
  const rows: Row[] = [];

  for (const f of files) {
    const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
    const stem = gt.file.replace(/\.pdf$/i, '');
    const textPath = path.join(APP_TEXT_DIR, stem + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const text = fs.readFileSync(textPath, 'utf8');
    const opts = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const;

    let blocks: Parameters<typeof parseExamRawText>[3] | undefined;
    const brainPath = path.join(BRAIN_DIR, stem + '.json');
    if (fs.existsSync(brainPath)) {
      const brainDoc = JSON.parse(fs.readFileSync(brainPath, 'utf8'));
      const res = runLayoutBrain(brainDoc);
      const bridged = bridgeBrainResult(res);
      if (bridged) blocks = bridged.blocks;
    }
    let doc: any;
    try { doc = parseExamRawText(text, gt.file, opts, blocks); } catch { continue; }
    const g = gradeParse(doc, gt);

    for (const iss of g.issues) {
      const m = qtypeRe().exec(iss);
      if (!m) continue;
      const [, qnum, got, want] = m;
      const pair = `${got}->${want}`;
      // find the question across sections by number/displayNumber
      let q: any; let sec: any;
      for (const s of doc.sections ?? []) {
        const hit = (s.questions ?? []).find((qq: any) => String(qq.displayNumber ?? qq.number) === qnum);
        if (hit) { q = hit; sec = s; break; }
      }
      rows.push({
        file: gt.file.slice(0, 20), pair, qnum,
        cat: String(sec?.majorCategory ?? '-'),
        instr: squash(String(sec?.persianInstruction ?? sec?.title ?? '')).slice(0, 90),
        stem: squash(String(q?.stem ?? '(question not found)')).slice(0, 90),
        text: '',
      });
    }
  }

  const byPair = new Map<string, Row[]>();
  for (const r of rows) {
    if (ONLY && r.pair !== ONLY) continue;
    if (!byPair.has(r.pair)) byPair.set(r.pair, []);
    byPair.get(r.pair)!.push(r);
  }
  const sorted = [...byPair.entries()].sort((a, b) => b[1].length - a[1].length);
  for (const [pair, rs] of sorted.slice(0, 14)) {
    console.log(`\n##### ${pair}  (${rs.length}) #####`);
    for (const r of rs.slice(0, MAX_PER_PAIR)) {
      console.log(`  ${r.file} q${r.qnum} | ${r.cat} | "${r.instr}"`);
      console.log(`      "${r.stem}"`);
    }
  }
}

main();
