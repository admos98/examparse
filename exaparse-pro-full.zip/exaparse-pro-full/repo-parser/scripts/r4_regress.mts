/**
 * r4_regress — dissect the R4-introduced golden/pinned regressions:
 *   1. p43266n364  sec7 q1-6  got cloze_item want multiple_choice
 *   2. pq89w65173  sec18 q63-67 got word_bank_fill want short_answer/essay
 *   3. 11th first.pdf q60-63 got cloze_item want multiple_choice
 * Dumps section category/instr/marks, question types + stems, and the
 * parentContext passage the printedCloze branch saw.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const TARGETS = [
  { file: '14050320p43266n364.pdf', textDir: 'scratch/texts-qu2', secs: ['7'], qnums: ['1', '2', '3', '4', '5', '6'] },
  { file: '13991009pq89w65173.pdf', textDir: 'scratch/texts-qu2', secs: ['18'], qnums: ['63', '64', '65', '66', '67'] },
  { file: '11th first.pdf', textDir: 'scratch/texts', secs: [], qnums: ['60', '61', '62', '63'] },
];

const squash = (s: unknown) => String(s ?? '').replace(/\s+/g, ' ').trim();

for (const t of TARGETS) {
  const stem = t.file.replace(/\.pdf$/i, '').replace(/\s+/g, '_');
  const textPath = path.join(WS_ROOT, t.textDir, stem + '.pdf.txt');
  if (!fs.existsSync(textPath)) { console.log(`!! no text for ${t.file}`); continue; }
  const text = fs.readFileSync(textPath, 'utf8');
  const doc: any = parseExamRawText(text, t.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  console.log(`\n============ ${t.file} ============`);
  for (const s of doc.sections ?? []) {
    const id = String(s.rowId ?? s.id ?? '?');
    if (t.secs.length && !t.secs.includes(id)) continue;
    console.log(
      `sec[${id}] cat=${s.majorCategory ?? s.category} mark=${s.mark} markTotal=${s.markTotal ?? s.totalMark} nq=${(s.questions ?? []).length} title=${JSON.stringify(squash(s.title).slice(0, 60))}`,
    );
    console.log(`   faInstr=${JSON.stringify(squash(s.persianInstruction).slice(0, 110))}`);
    console.log(`   enInstr=${JSON.stringify(squash(s.englishInstruction).slice(0, 110))}`);
    if (s.passageText) console.log(`   passage[${squash(s.passageText).length}]=${JSON.stringify(squash(s.passageText).slice(0, 220))}`);
    for (const q of s.questions ?? []) {
      const n = String(q.displayNumber ?? q.number);
      if (t.qnums.length && !t.qnums.includes(n)) continue;
      console.log(`   q${n} type=${q.type} stem=${JSON.stringify(squash(q.stem).slice(0, 130))}`);
      if (q.parentContextText && t.qnums.includes(n))
        console.log(`      ctx(${squash(q.parentContextText).length})=${JSON.stringify(squash(q.parentContextText).slice(0, 240))}`);
    }
  }
}
