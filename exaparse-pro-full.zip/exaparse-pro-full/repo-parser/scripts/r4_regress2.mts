/**
 * r4_regress2 — contrast the printedCloze GAIN files (GT cloze_item) vs the
 * LOSS files (GT multiple_choice) to find the discriminating evidence.
 * Prints: section question numbers, passage dot-hugged numbers, whether the
 * question rows carry option markers, and the section instruction.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const CASES = [
  // gains (GT cloze_item)
  { file: '14020406p2657j6465.pdf', dir: 'scratch/texts-qu2', want: 'cloze_item' },
  { file: '14040215pu557l5203.pdf', dir: 'scratch/texts-qu2', want: 'cloze_item' },
  { file: '14041010p265374941.pdf', dir: 'scratch/texts-qu2', want: 'cloze_item' },
  // losses (GT multiple_choice)
  { file: '14050320p43266n364.pdf', dir: 'scratch/texts-qu2', want: 'multiple_choice' },
  { file: '11th first.pdf', dir: 'scratch/texts', want: 'multiple_choice' },
];

const squash = (s: unknown) => String(s ?? '').replace(/\s+/g, ' ').trim();

for (const t of CASES) {
  const stem = t.file.replace(/\.pdf$/i, '').replace(/\s+/g, '_');
  const textPath = path.join(WS_ROOT, t.dir, stem + '.pdf.txt');
  if (!fs.existsSync(textPath)) { console.log(`!! no text ${t.file}`); continue; }
  const text = fs.readFileSync(textPath, 'utf8');
  const doc: any = parseExamRawText(text, t.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  console.log(`\n===== ${t.file} (GT ${t.want}) =====`);
  for (const s of doc.sections ?? []) {
    for (const q of s.questions ?? []) {
      const n = String(q.displayNumber ?? q.number);
      if (q.type !== 'cloze_item' && t.want !== 'cloze_item') continue;
      // for loss files just find questions whose GT mismatched — print first 8 of each section w/ parentContext
      const ctx = squash(q.parentContextText ?? '');
      const passageNums = [...ctx.matchAll(/(?:\.{2,}|…+)\s*(\d{1,3})\s*(?:\.{2,}|…+)/g)].map((m) => m[1]);
      const hasOpts = /\b[a-d]\s*[).-]/i.test(squash(q.stem));
      console.log(
        `  sec=${s.rowId} q${n} type=${q.type} want=${t.want} stem=${JSON.stringify(squash(q.stem).slice(0, 60))} optsInStem=${hasOpts} passageNums=[${passageNums.join(',')}] nq=${(s.questions ?? []).length}`,
      );
    }
  }
}
