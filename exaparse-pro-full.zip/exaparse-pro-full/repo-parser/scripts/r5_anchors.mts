/**
 * r5_anchors.mts — probe: verify the bare-letter anchor + instruction-group
 * model against the two cascade files before implementing the oracle.
 */
import fs from 'node:fs';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const FA_ORDER = ['الف','ب','پ','ت','ث','ج','چ','ح','خ','د','ذ','ر','ز','ژ','س','ش','ص','ض','ط','ظ','ع','غ','ف','ق','ک','گ','ل','م','ن','و','ه','ی'];

const looksInstr = (raw: string): boolean => {
  const t = raw.normalize('NFKC').replace(/[\u200E\u200F\u202A-\u202E\u2066-\u2069]/g, '').trim();
  if (!t) return false;
  if (/^[\u0600-\u06FF]/.test(t)) {
    const faChars = (t.match(/[\u0600-\u06FF]/g) ?? []).length;
    return faChars >= 6 && !/^\s*\d{1,3}\s*[-.).]/.test(t);
  }
  return /^(Complete|Choose|Fill|Match|Read|Write|Circle|Put|Unscramble|Answer|Listen|Select|Find|Change|Specify|Make|Spell|Use)\b/i.test(t);
};

const hasItems = (s: string): boolean =>
  /^\s*\.?\d{1,3}\s*[.)\-]/m.test(s) ||
  /\(\s*\d{1,2}\s*\)/.test(s) ||
  /^\s*[a-z]\s*[.)]\s*\S/m.test(s) ||
  /\s\d{1,2}\s*[\).]/.test(s) ||
  /\d{1,3}\s*\.{2,}|\.{2,}\s*\d{1,3}/.test(s);

for (const f of ['14050319p65o69r989', '14041010p265374941']) {
  const lines = fs.readFileSync(`${WS_ROOT}/scratch/texts-qu2/${f}.pdf.txt`, 'utf8').split(/\r?\n/);
  console.log(`\n=== ${f} (${lines.length} lines)`);
  // bare anchors
  const anchors: { i: number; letter: string; ord: number }[] = [];
  lines.forEach((l, i) => {
    const t = l.trim().normalize('NFKC');
    if (FA_ORDER.includes(t)) anchors.push({ i, letter: t, ord: FA_ORDER.indexOf(t) });
    else if (/^[A-Z]$/.test(t)) anchors.push({ i, letter: t, ord: 100 + t.charCodeAt(0) });
  });
  // monotonic check
  const mono = anchors.every((a, k) => k === 0 || a.ord > anchors[k - 1].ord);
  console.log('anchors:', anchors.map((a) => `${a.letter}@${a.i}`).join(' '), '| monotonic:', mono);
  // instruction starts + fused
  const starts: number[] = [];
  lines.forEach((l, i) => {
    const t = l.trim();
    if (looksInstr(t)) starts.push(i);
    else {
      const m = t.match(/^(\d{1,2})\s+(\S.*)$/);
      if (m && looksInstr(m[2])) starts.push(i);
    }
  });
  // spans + fold item-less forward, then drop pre-first-anchor prose
  interface Span { start: number; end: number }
  const spans: Span[] = starts.map((s, k) => ({ start: s, end: (k + 1 < starts.length ? starts[k + 1] : lines.length) - 1 }));
  const kept: (Span & { fold?: boolean })[] = [];
  for (const sp of spans) {
    const text = lines.slice(sp.start, sp.end + 1).join('\n');
    if (hasItems(text)) kept.push({ ...sp });
    else kept.push({ ...sp, fold: true });
  }
  // fold item-less spans forward: an item-less span is a multi-line
  // instruction continuation — merge it into the next item-bearing span.
  const groups: Span[] = [];
  for (let k = 0; k < kept.length; k++) {
    if (kept[k].fold) continue;
    let start = kept[k].start;
    let p = k - 1;
    while (p >= 0 && kept[p].fold && groups.length === 0) { start = kept[p].start; p--; }
    groups.push({ start, end: kept[k].end });
  }
  const firstAnchor = anchors.length ? anchors[0].i : -1;
  const exam = groups.filter((g) => g.end >= firstAnchor);
  console.log('exam groups:', exam.length, '→', exam.map((g) => `${g.start}-${g.end}`).join(' '));
  // marks: backward standalone-number scan in [prev_anchor .. instr)
  const standalone = (s: string) => /^\.?\d{1,2}(?:[.,]\d{1,2})?$/.test(s.trim());
  exam.forEach((g, k) => {
    const zoneEnd = g.start;
    const zoneStart = k === 0 ? 0 : (anchors.find((a) => a.i < g.start)?.i ?? 0);
    let mark: string | null = null;
    for (let z = zoneEnd - 1; z >= zoneStart; z--) {
      const t = lines[z].trim();
      if (t && !anchors.some((a) => a.i === z) && standalone(t)) { mark = t; break; }
    }
    // fused fallback
    if (mark === null) {
      const m = lines[g.start].trim().match(/^(\d{1,2})\s+\S/);
      if (m) mark = m[1] + ' (fused)';
    }
    console.log(`   group ${g.start}-${g.end} mark=${mark}`);
  });
}
