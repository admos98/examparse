/**
 * r5_dissect.mts — Wave R5 probe: dump parser output structure for the
 * negative-score files vs GT, to find the COMMON root cause (if any).
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const TEXT_DIR = WS_ROOT + '/scratch/texts-qu2';
const GT_DIR = WS_ROOT + '/scratch/gt-qu2';

const FILES = [
  '14040304pt7kkv4576.pdf',
  '14050319p65o69r989.pdf',
  '14050401pkhn2yd527.pdf',
  '14041010p265374941.pdf',
  '14031114p93s775186.pdf',
  '14050319pw1387r928.pdf',
  '14040131paq214l942.pdf',
];

for (const f of FILES) {
  const textPath = path.join(TEXT_DIR, f + '.txt');
  const gtPath = path.join(GT_DIR, f.replace(/\.pdf$/, '') + '-pdf.json');
  if (!fs.existsSync(textPath) || !fs.existsSync(gtPath)) { console.log(`SKIP ${f}`); continue; }
  const text = fs.readFileSync(textPath, 'utf8');
  const gt = JSON.parse(fs.readFileSync(gtPath, 'utf8'));
  const parsed = parseExamRawText(text, f, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });

  console.log(`\n================ ${f} ================`);
  // GT summary
  const gtSecs = (gt.sections ?? []).map((s: any) => ({
    id: s.id,
    groups: (s.qs ?? []).map((g: any) => `${g.t}[${(g.n ?? []).join(',')}]`),
  }));
  console.log('GT:');
  for (const s of gtSecs) console.log(`   ${s.id}: ${s.groups.join(' | ')}`);
  // Parsed summary
  const pSecs = (parsed as any).sections ?? [];
  console.log(`PARSED (${pSecs.length} sections):`);
  for (const s of pSecs) {
    const qs = (s.questions ?? []).map((q: any) =>
      `${q.type ?? '?'}#${Array.isArray(q.number) ? q.number.join('+') : q.number}`);
    console.log(`   [${s.id ?? s.title ?? '?'}]: ${qs.join(' | ')}`);
  }
}
