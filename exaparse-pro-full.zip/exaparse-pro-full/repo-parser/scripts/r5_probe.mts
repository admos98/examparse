/**
 * r5_probe — Wave R5 reconnaissance for the section-split catastrophe trio.
 * Dumps per-section parse shape (rowId, count, markTotal, qnum chains,
 * qtype histogram) for the trio + declared-count phrase scan of raw text.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

const FILES = process.argv.slice(2).length
  ? process.argv.slice(2)
  : ['14020406p4t7882699', '14050319p65o69r989', '14050319pw1387r928'];

const DECLARED_COUNT_RES: Array<[string, RegExp]> = [
  ['fa_total_label', /تعداد\s*(?:کل\s*)?(?:سوال(?:ات)?|سؤال(?:ات)?|پرسش(?:ها)?)[^0-9]{0,30}?(\d{1,3})/],
  ['fa_in_scope', /شامل\s*(\d{1,3})\s*(?:سوال(?:ات)?|سؤال(?:ات)?|پرسش(?:ها)?)/],
  ['fa_answer_all', /(?:به|همه(?:ی|\s+)?|تمام)\s*(\d{1,3})\s*(?:سوال(?:ات)?|سؤال(?:ات)?|پرسش(?:ها)?)\s*(?:زیر)?\s*(?:پاسخ|جواب)/],
];

for (const stem of FILES) {
  const textPath = path.join(APP_TEXT_DIR, stem + '.txt');
  if (!fs.existsSync(textPath)) { console.log(`(no text for ${stem})`); continue; }
  const text = fs.readFileSync(textPath, 'utf8');
  console.log(`\n########## ${stem} ##########`);

  // Declared-count phrases in the raw text
  for (const [pid, re] of DECLARED_COUNT_RES) {
    const m = text.match(re);
    if (m) console.log(`  [declared] ${pid} = ${m[1]}  ctx=${JSON.stringify(m[0].slice(0, 70))}`);
  }

  const doc = parseExamRawText(text, stem + '.pdf', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as any);
  let qTotal = 0;
  for (const s of doc.sections) {
    const qnums = s.questions.map((q) => q.number);
    const marksSum = s.questions.reduce((a, q) => a + (q.mark ?? 0), 0);
    qTotal += s.questions.length;
    const types = new Map<string, number>();
    for (const q of s.questions) types.set(q.type, (types.get(q.type) ?? 0) + 1);
    const tstr = [...types.entries()].map(([k, v]) => `${k}:${v}`).join(' ') || '-';
    console.log(`  sec ${s.rowId} nq=${s.questions.length} markTotal=${s.markTotal} sumMarks=${marksSum.toFixed(1)} qnums=[${qnums.slice(0, 12).join(',')}${qnums.length > 12 ? '..' + qnums[qnums.length - 1] : ''}]`);
    console.log(`     types: ${tstr}`);
    const bare = s.questions.filter((q) => !q.stem || q.stem.replace(/[.\s\u200c]+/g, '') === '').length;
    if (bare > 0) console.log(`     BARE stems: ${bare}/${s.questions.length}`);
  }
  console.log(`  TOTAL questions=${qTotal} doc.totalMarks=${doc.totalMarks}`);
}
