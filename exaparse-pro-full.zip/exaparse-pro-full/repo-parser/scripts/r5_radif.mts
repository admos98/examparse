/**
 * r5_radif — dump splitRadifNumberedSections blocks for the radif trio file:
 * rowId, mark, question-number seeds seen, and head of each block text.
 */
import fs from 'node:fs';
import path from 'node:path';
import { splitRadifNumberedSections } from '../src/utils/parserEngine';
import { canonicalize } from '../src/utils/textCanonical';
import { normalizeOcrText } from '../src/utils/ocrPreprocessor';
import { PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');
const stem = process.argv[2] ?? '14050319p65o69r989';
const text = fs.readFileSync(path.join(APP_TEXT_DIR, stem + '.txt'), 'utf8');
const canon = normalizeOcrText(canonicalize(text).text);
const blocks = splitRadifNumberedSections(canon);
if (!blocks) { console.log('(radif declined)'); process.exit(0); }
for (const b of blocks) {
  const seeds = [...b.text.matchAll(/(?:^|[\s(])(\d{1,3})\s*[.)\-]\s/gm)].map((m) => m[1]).slice(0, 14);
  console.log(`block ${b.rowId} mark=${(b as any).mark} startIndex=${b.startIndex}`);
  console.log('  nums:', seeds.join(','));
  console.log('  head:', JSON.stringify(b.text.slice(0, 110)));
  console.log('  tail:', JSON.stringify(b.text.slice(-70)));
}
