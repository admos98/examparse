/**
 * r5_scan.mts — which corpus files have bare-letter anchor sequences?
 * Tells us exactly where the R5 oracle may fire.
 */
import fs from 'node:fs';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';
import path from 'node:path';

const FA = ['الف','ب','پ','ت','ث','ج','چ','ح','خ','د','ذ','ر','ز','ژ','س','ش','ص','ض','ط','ظ','ع','غ','ف','ق','ک','گ','ل','م','ن','و','ه','ی'];
const DIRS = [WS_ROOT + '/scratch/texts-qu2', WS_ROOT + '/scratch/texts', WS_ROOT + '/scratch/texts-mocks'];

for (const DIR of DIRS) for (const f of fs.readdirSync(DIR).filter((x) => x.endsWith('.txt')).sort()) {
  const lines = fs.readFileSync(path.join(DIR, f), 'utf8').split(/\r?\n/);
  const anchors: { i: number; t: string; ord: number; fa: boolean }[] = [];
  lines.forEach((l, i) => {
    const t = l.trim().normalize('NFKC');
    const fa = FA.indexOf(t);
    if (fa >= 0) anchors.push({ i, t, ord: fa, fa: true });
    else if (/^[A-Z]$/.test(t)) anchors.push({ i, t, ord: t.charCodeAt(0), fa: false });
  });
  if (anchors.length < 4) continue;
  // longest strictly-increasing-by-1 run per script
  let best: typeof anchors = [];
  let cur: typeof anchors = [];
  for (const a of anchors) {
    if (cur.length === 0 || (a.fa === cur[cur.length - 1].fa && a.ord === cur[cur.length - 1].ord + 1)) cur.push(a);
    else cur = [a];
    if (cur.length > best.length) best = cur;
  }
  if (best.length >= 4) {
    console.log(`${f}: run=${best.length} [${best.map((a) => `${a.t}@${a.i}`).join(' ')}]`);
  }
}
