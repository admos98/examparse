/**
 * r6_grade_dump — run the REAL grader (gradeParse) on selected qu2 files and
 * dump every issue verbatim + doc section shapes, to expose what the probe's
 * simplified dump hides.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-qu2');
const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

const FILES = process.argv.slice(2).length
  ? process.argv.slice(2)
  : ['14040304pt7kkv4576'];

for (const stem of FILES) {
  const gtPath = path.join(GT_DIR, stem + '-pdf.json');
  const textPath = path.join(APP_TEXT_DIR, stem + '.txt');
  if (!fs.existsSync(gtPath) || !fs.existsSync(textPath)) {
    console.log(`(skip ${stem})`);
    continue;
  }
  const gt = JSON.parse(fs.readFileSync(gtPath, 'utf8'));
  const text = fs.readFileSync(textPath, 'utf8');
  const doc = parseExamRawText(text, stem + '.pdf', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as any);
  const { score, issues, total } = gradeParse(doc, gt);
  console.log(`\n########## ${stem}  score=${score} total=${total} ##########`);
  console.log('PARSE sections:');
  for (const s of doc.sections) {
    console.log(`  [${s.rowId}] cat=${s.majorCategory} nq=${s.questions.length} markTotal=${s.markTotal}`);
  }
  console.log(`doc.header: ${JSON.stringify(doc.header).slice(0, 220)}`);
  console.log('ISSUES:');
  for (const i of issues) console.log(`  - ${i}`);
}
