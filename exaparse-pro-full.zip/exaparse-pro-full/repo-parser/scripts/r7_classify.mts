/**
 * r7_classify — classify a line range of a qu2 text and print the resulting
 * question blocks, to expose exactly how the segmenter derived numbers.
 */
import fs from 'node:fs';
import path from 'node:path';
import { classifyLines, segmentQuestionBlocks } from '../src/utils/parserRules';
import { PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');
const stem = process.argv[2] || '14040304pt7kkv4576';
const from = parseInt(process.argv[3] || '12', 10); // 1-based inclusive
const to = parseInt(process.argv[4] || '42', 10);   // 1-based inclusive

const text = fs.readFileSync(path.join(APP_TEXT_DIR, stem + '.txt'), 'utf8');
const lines = text.split(/\r?\n/).slice(from - 1, to);
const cls = classifyLines(lines);
console.log('LINES:');
for (const c of cls) {
  console.log(`  ${String(c.lineIndex + from).padStart(3)} ${c.kind.padEnd(16)} ${c.ruleId.padEnd(8)} ${(c.confidence).toFixed(2)} :: ${c.text.trim().slice(0, 70)}`);
}
console.log('BLOCKS:');
for (const b of segmentQuestionBlocks(cls)) {
  console.log(`  #${b.number} [${b.lineStart + from}..${b.lineEnd + from}] :: ${b.text.replace(/\s+/g, ' ').slice(0, 80)}`);
}
