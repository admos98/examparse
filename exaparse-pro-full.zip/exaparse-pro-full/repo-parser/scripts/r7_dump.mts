/**
 * r7_dump — per-question detail dump (number, type, stem snippet, option count)
 * for selected qu2 files, to expose row-level shapes the grade dump hides.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

const FILES = process.argv.slice(2).length
  ? process.argv.slice(2)
  : ['14040304pt7kkv4576'];

for (const stem of FILES) {
  const textPath = path.join(APP_TEXT_DIR, stem + '.txt');
  if (!fs.existsSync(textPath)) {
    console.log(`(skip ${stem})`);
    continue;
  }
  const text = fs.readFileSync(textPath, 'utf8');
  const doc = parseExamRawText(text, stem + '.pdf', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as any);
  console.log(`\n########## ${stem} ##########`);
  console.log(`header: ${JSON.stringify(doc.header)}`);
  for (const s of doc.sections) {
    console.log(`\n== [${s.rowId}] cat=${s.majorCategory} nq=${s.questions.length} markTotal=${s.markTotal}`);
    for (const q of s.questions) {
      const stemSnip = ((q as any).stem || '').replace(/\s+/g, ' ').slice(0, 90);
      const opts = q.options ? q.options.length : 0;
      const keys = (q as any).answerKeys && (q as any).answerKeys.length ? ` keys=${JSON.stringify((q as any).answerKeys).slice(0, 40)}` : '';
      console.log(`  q${q.number} [${q.type}] opts=${opts}${keys} :: ${stemSnip}`);
    }
  }
}
