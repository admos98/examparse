/**
 * ref_probe — enumerate concrete qtype/category (got, want) pairs corpus-wide,
 * plus the instruction text near each mismatched question, so we can map
 * reference-implementation learnings onto our failure surface.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const APP_TEXT_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts');

function main() {
  const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  const qtypePairs = new Map<string, number>();
  const catPairs = new Map<string, number>();
  const qtypeFiles = new Map<string, string[]>();
  const perFileIssues: Record<string, string[]> = {};

  for (const f of files) {
    const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
    const stem = gt.file.replace(/\.pdf$/i, '');
    const textPath = path.join(APP_TEXT_DIR, stem + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const text = fs.readFileSync(textPath, 'utf8');
    const opts = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as const;
    const result = parseExamRawText(text, f, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true } as any);
    const grade = gradeParse(result, gt);
    if (!grade.issues.length) continue;
    perFileIssues[gt.file] = grade.issues;
    for (const issue of grade.issues) {
      const qm = issue.match(/ (q\d+) type: got ([^ ]+) want ([^ ]+)/);
      if (qm) {
        const key = `${qm[2]} -> ${qm[3]}`;
        qtypePairs.set(key, (qtypePairs.get(key) ?? 0) + 1);
        if (!qtypeFiles.has(key)) qtypeFiles.set(key, []);
        qtypeFiles.get(key)!.push(`${gt.file}:${qm[1]}`);
      }
      const cm = issue.match(/ category: got ([^ ]+) want ([^ ]+)/);
      if (cm) {
        const key = `${cm[1]} -> ${cm[2]}`;
        catPairs.set(key, (catPairs.get(key) ?? 0) + 1);
      }
    }
  }

  const top = (m: Map<string, number>, label: string) => {
    console.log(`\n=== ${label} (top 30) ===`);
    [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 30).forEach(([k, v]) => console.log(`${String(v).padStart(4)}  ${k}`));
  };
  top(qtypePairs, 'QTYPE got->want');
  top(catPairs, 'CATEGORY got->want');
  console.log('\n=== QTYPE sample files per top pair ===');
  [...qtypePairs.entries()].sort((a, b) => b[1] - a[1]).slice(0, 12).forEach(([k, v]) => {
    console.log(`${v}  ${k}: ${(qtypeFiles.get(k) ?? []).slice(0, 6).join(' ')}`);
  });
}
main();
