/**
 * ref_probe2 — print our parsed types for the top-confusion questions.
 */
import { parseExamRawText } from '../src/utils/parserEngine';
import fs from 'node:fs';

const CASES: Array<{ file: string; nums: (number | string)[] }> = [
  { file: '14020228p53x7md884', nums: [15, 16, 17, 18, 45, 46] },
  { file: '13991009pq89w65173', nums: [63, 64, 65, 66] },
  { file: '14020228p91294y667', nums: [19, 55] },
  { file: '13991010p3iy8yh87', nums: [39] },
  { file: '14040203p28932i821', nums: [41] },
  { file: '14031006pg3866x690', nums: [60] },
];

for (const c of CASES) {
  const text = fs.readFileSync(`scratch/brain-app-qu2/texts/${c.file}.txt`, 'utf8');
  const result = parseExamRawText(text, c.file + '.pdf', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  console.log(`--- ${c.file} ---`);
  for (const s of result.sections) {
    for (const q of s.questions) {
      if (c.nums.includes(q.number)) {
        console.log(`  q${q.number} [${s.rowId}] type=${q.type} sec=${s.majorCategory} mark=${s.markTotal} stem=${JSON.stringify((q.stem || '').slice(0, 70))}`);
      }
    }
  }
}
