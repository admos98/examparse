/**
 * ref_probe3 — dump captured section instructions for the failing sections.
 */
import { parseExamRawText } from '../src/utils/parserEngine';
import fs from 'node:fs';

for (const file of ['14020228p53x7md884', '13991009pq89w65173', '14031006pg3866x690', '14020228p91294y667']) {
  const text = fs.readFileSync(`scratch/brain-app-qu2/texts/${file}.txt`, 'utf8');
  const r = parseExamRawText(text, file + '.pdf', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  console.log(`\n===== ${file} =====`);
  for (const s of r.sections) {
    const types = [...new Set(s.questions.map((q) => q.type))].join(',');
    console.log(`  [${s.rowId}] cat=${s.majorCategory} mark=${s.markTotal} n=${s.questions.length} types=${types}`);
    const instr = (s as any).persianInstruction || (s as any).instruction || '';
    if (instr) console.log(`      faInstr: ${String(instr).slice(0, 90).replace(/\n/g, ' | ')}`);
    const en = (s as any).englishInstruction || '';
    if (en) console.log(`      enInstr: ${String(en).slice(0, 90).replace(/\n/g, ' | ')}`);
    const first = s.questions[0];
    if (first) console.log(`      q1 stem: ${JSON.stringify((first.stem || '').slice(0, 60))}`);
  }
}
