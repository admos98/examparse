/**
 * ref_probe4 — for each qtype-mismatch, classify whether the owning section's
 * captured instruction is furniture/empty (contract lost) vs real.
 */
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import fs from 'node:fs';
import path from 'node:path';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const FURNITURE = /باسمه تعالی|سواالت آزمون|ساعت شروع|مدت امتحان|اداره|دانش آموزان|نام و نام|جمع نمره|www|مرکز سنجش|ردیف/;

function main() {
  const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  let realInstr = 0, lostInstr = 0;
  const lostSamples: string[] = [];
  const typePairsLost = new Map<string, number>();

  for (const f of files) {
    const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
    const stem = gt.file.replace(/\.pdf$/i, '');
    const textPath = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts', stem + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const text = fs.readFileSync(textPath, 'utf8');
    const result = parseExamRawText(text, gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
    const grade = gradeParse(result, gt);
    for (const issue of grade.issues) {
      const qm = issue.match(/ (q\d+) type: got ([^ ]+) want ([^ ]+)/);
      if (!qm) continue;
      // find the section owning this question number
      const qnum = parseInt(qm[1].slice(1), 10);
      const sec = result.sections.find((s) => s.questions.some((q) => Number(q.number) === qnum));
      const instr = `${(sec as any)?.persianInstruction || ''} ${(sec as any)?.englishInstruction || ''}`;
      const isFurniture = !instr.trim() || (instr.trim().length > 0 && FURNITURE.test(instr) && instr.replace(FURNITURE, '').trim().length < 12);
      if (isFurniture) {
        lostInstr++;
        const key = `${qm[2]} -> ${qm[3]}`;
        typePairsLost.set(key, (typePairsLost.get(key) ?? 0) + 1);
        if (lostSamples.length < 12) lostSamples.push(`${gt.file} ${qm[1]} ${key} instr="${instr.trim().slice(0, 50)}"`);
      } else realInstr++;
    }
  }
  console.log(`qtype mismatches: realInstr=${realInstr} lostInstr=${lostInstr}`);
  console.log('\n=== lost-instruction pair breakdown (top 15) ===');
  [...typePairsLost.entries()].sort((a, b) => b[1] - a[1]).slice(0, 15).forEach(([k, v]) => console.log(`${v}  ${k}`));
  console.log('\n=== lost samples ===');
  lostSamples.forEach((s) => console.log(' ', s));
}
main();
