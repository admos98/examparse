/**
 * ref_probe5 — full stems for specific mismatching questions.
 */
import { parseExamRawText } from '../src/utils/parserEngine';
import fs from 'node:fs';

const CASES: Array<[string, (number | string)[]]> = [
  ['13991010p3iy8yh87', [39, 40]],
  ['14040203p28932i821', [41]],
  ['14020228p91294y667', [55, 29, 30]],
  ['14031006pg3866x690', [60]],
  ['14040215pu557l5203', [5, 6, 7]],
  ['14050319p65o69r989', [16]],
];

for (const [file, nums] of CASES) {
  const text = fs.readFileSync(`scratch/brain-app-qu2/texts/${file}.txt`, 'utf8');
  const r = parseExamRawText(text, file + '.pdf', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  for (const s of r.sections) {
    for (const q of s.questions) {
      if ((nums as unknown[]).includes(q.number)) {
        console.log(`${file} q${q.number} type=${q.type} secMark=${s.markTotal}`);
        console.log(`   stem: ${JSON.stringify(q.stem)}`);
      }
    }
  }
}
