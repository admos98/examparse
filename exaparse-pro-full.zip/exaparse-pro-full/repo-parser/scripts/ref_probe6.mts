/**
 * ref_probe6 — full context for short_answer->fill_blank and word_bank_fill->short_answer pairs.
 */
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import fs from 'node:fs';
import path from 'node:path';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const PAIRS = new Set(['short_answer -> fill_blank', 'word_bank_fill -> short_answer', 'fill_blank -> short_answer']);

function main() {
  const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  for (const f of files) {
    const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
    const stem0 = gt.file.replace(/\.pdf$/i, '');
    const textPath = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2', 'texts', stem0 + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const text = fs.readFileSync(textPath, 'utf8');
    const result = parseExamRawText(text, stem0 + ".pdf", { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
    const grade = gradeParse(result, gt);
    for (const issue of grade.issues) {
      const qm = issue.match(/ (q\d+) type: got ([^ ]+) want ([^ ]+)/);
      if (!qm) continue;
      const key = `${qm[2]} -> ${qm[3]}`;
      if (!PAIRS.has(key)) continue;
      const qnum = parseInt(qm[1].slice(1), 10);
      const sec = result.sections.find((s) => s.questions.some((q) => Number(q.number) === qnum));
      const q = sec?.questions.find((qq) => qq.number === qnum);
      const instr = `${(sec as any)?.persianInstruction || ''} ${(sec as any)?.englishInstruction || ''}`.trim();
      console.log(`${gt.file.slice(0, 16)} ${qm[1]} ${key}`);
      console.log(`   instr: ${JSON.stringify(instr.slice(0, 80))}`);
      console.log(`   stem: ${JSON.stringify((q?.stem || '').slice(0, 100))}`);
    }
  }
}
main();
