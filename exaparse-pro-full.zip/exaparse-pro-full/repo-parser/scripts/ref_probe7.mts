/**
 * ref_probe7 — dump rawSec.text for sections with failing matching/slash rules.
 */
import { parseExamRawText } from '../src/utils/parserEngine';
import fs from 'node:fs';

// access the internal section text — parse via the engine's debug env
process.env.PARSE_DEBUG = '';

for (const file of ['14020228p53x7md884', '14010501p8yp4c9983']) {
  const text = fs.readFileSync(`scratch/brain-app-qu2/texts/${file}.txt`, 'utf8');
  const r = parseExamRawText(text, file + '.pdf', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  console.log(`\n===== ${file} =====`);
  for (const s of r.sections) {
    if (!s.questions.length) continue;
    const types = [...new Set(s.questions.map((q) => q.type))].join(',');
    const bare = s.questions.filter((q) => !q.stem || q.stem.replace(/[\s.()0-9]+/g, '').length <= 2).length;
    console.log(`  [${s.rowId}] mark=${s.markTotal} n=${s.questions.length} bare=${bare} types=${types}`);
    const instr = `${(s as any).persianInstruction || ''}`;
    console.log(`      instr: ${JSON.stringify(instr.slice(0, 70))}`);
  }
}
