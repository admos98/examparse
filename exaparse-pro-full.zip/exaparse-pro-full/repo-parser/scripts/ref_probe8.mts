/**
 * ref_probe8 — full dissection of the catastrophic qnum trio.
 */
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse } from '../src/utils/goldenGrade';
import fs from 'node:fs';
import path from 'node:path';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');

for (const file of ['14020406p4t7882699', '14050319pw1387r928', '14050401pkhn2yd527']) {
  const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, file + '-pdf.json'), 'utf8'));
  const text = fs.readFileSync(`scratch/brain-app-qu2/texts/${file}.txt`, 'utf8');
  const r = parseExamRawText(text, gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  const g = gradeParse(r, gt);
  console.log(`\n===== ${file} score=${g.score} =====`);
  console.log('GT sections:', gt.sections.map((s: any) => `${s.id}(${s.cat},${s.mark})q[${(s.qs || []).map((q: any) => (Array.isArray(q.n) ? q.n.join('-') : q.n) + ':' + q.t.slice(0, 4)).join(' ')}]`).join(' | '));
  console.log('GOT sections:', r.sections.map((s) => `${s.rowId}(${s.majorCategory},${s.markTotal})[${s.questions.map((q) => q.number).join(',')}]`).join(' | '));
  console.log('Issues:');
  g.issues.slice(0, 14).forEach((i) => console.log('  ', i.slice(0, 110)));
}
