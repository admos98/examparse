/**
 * specialist_labels — shared labeling for the SPECIALIST model waves (W1/W2).
 *
 * Produces WEAK labels for every line of the app-domain corpus by re-running
 * the deterministic perception (distillation target, same recipe that trained
 * the tinyBrain arbiter) and adds:
 *   - synthetic anchor templates (tail classes + corrupted-text robustness)
 *   - an OCR/mangle corruption engine (the codec's real new capability: it
 *     must classify lines whose text a regex CANNOT match reliably —
 *     garbled CMaps, OCR-confused digits like "V0cabulary", "8 Grammar")
 *   - file-grouped folds (no leakage across files)
 *
 * Label taxonomy (closed domain alphabet — the "semantic codec" classes):
 *   ROLES (14): header_subject, header_generic, row_opener, row_opener_numeric,
 *               mark_token, option_line, instruction, content, furniture,
 *               page_number, key_row, key_boundary, total_line, dialogue_line
 *   SUBJECTS (9): none, vocabulary, grammar, listening, speaking, reading,
 *                 writing, pronunciation, general
 *   EVENTS (6): continue, section_start, row_start, key_start, total, noise
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  BrainDoc,
  BrainLine,
  perceive,
  toLatinDigits,
  reverseStr,
  matchSubject,
} from '../src/utils/layoutBrain';
import { PKG_ROOT } from '../scripts-batch/wsPaths.mts';

export const ROLES = [
  'header_subject', 'header_generic', 'row_opener', 'row_opener_numeric',
  'mark_token', 'option_line', 'instruction', 'content', 'furniture',
  'page_number', 'key_row', 'key_boundary', 'total_line', 'dialogue_line',
] as const;
export type Role = (typeof ROLES)[number];

export const SUBJECTS = [
  'none', 'vocabulary', 'grammar', 'listening', 'speaking',
  'reading', 'writing', 'pronunciation', 'general',
] as const;
export type Subject = (typeof SUBJECTS)[number];

export const EVENTS = [
  'continue', 'section_start', 'row_start', 'key_start', 'total', 'noise',
] as const;
export type Event = (typeof EVENTS)[number];

export const NUM_FEATS = 11;

const here = path.dirname(fileURLToPath(import.meta.url));
const CORPUS_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2');

// ------------------------------------------------------------- text folding

/** Aggressive fold for the codec: case, Arabic->Persian, digits, zero-widths. */
export function foldForCodec(s: string): string {
  return toLatinDigits(
    s
      .replace(/\u064A/g, '\u06CC') // Arabic yeh -> Persian yeh
      .replace(/\u0643/g, '\u06A9') // Arabic kaf -> Persian keheh
      .replace(/[\u200c\u200f\u200e\uFEFF]/g, '')
      .toLowerCase(),
  )
    .replace(/\s+/g, ' ')
    .trim();
}

/** layoutBrain subjects are capitalized; 'Language Function' folds to general. */
export function mapSubject(s: string | undefined): Subject | undefined {
  if (!s) return undefined;
  const t = s.toLowerCase();
  if (t === 'language function') return 'general';
  return (SUBJECTS as readonly string[]).includes(t) ? (t as Subject) : undefined;
}

// ------------------------------------------------------ weak label patterns

const DIALOGUE_RE = /^[a-b\u0627]\s*[:\u061B.]\s+\S/;
const INSTR_EN =
  /^(match|fill|choose|put|read|complete|write|define|listen|circle|underline|cross|look|answer|use|make|turn)\b/i;
// Persian instruction verbs — tested against BOTH storage orders (Persian
// may be stored visually reversed by the extractor).
const INSTR_FA =
  /^(مطابقت|وصل|در\s*جای\s*خالی|انتخاب|بخوانید|متن\s*زیر|بنویسید|کامل|گوش|مرتب|تعریف|پاسخ\s*دهید)/;
const KEY_PAT =
  /answer\s*key|key\s*answers|answer\s*sheet|پاسخنامه|پاسخ\s*نامه|کلید\s*سوالات|پاسخ\s*های\s*صحیح/;
const TOTAL_PAT =
  /total\s*[:=]|grand\s*total|جمع\s*بارم|جمع\s*نمرات|جمع\s*کل|بارم\s*کل|نمره\s*کل/;

/** Persian can be stored reversed — always test both orders. */
function bothOrders(folded: string): string[] {
  return [folded, foldForCodec(reverseStr(folded))];
}

export function isTotalLine(folded: string): boolean {
  return bothOrders(folded).some((t) => TOTAL_PAT.test(t) && /\d/.test(t));
}
export function isKeyMarker(folded: string): boolean {
  return bothOrders(folded).some((t) => KEY_PAT.test(t));
}
export function isDialogue(folded: string): boolean {
  return DIALOGUE_RE.test(folded);
}
/**
 * Key-row SHAPE: short, digit/letter-option dominated ("1. b 2. c", "12) T").
 * The key TAIL of some corpus files contains bare numbers and even full
 * instruction sentences — those are NOT key rows and the codec is MORE right
 * calling them content. Shape guards the distillation target.
 */
export function isKeyRowShape(folded: string): boolean {
  if (!folded || folded.length > 60 || !/\d/.test(folded)) return false;
  const rest = folded.replace(/[\d\s.,():\]\[-]+/g, '');
  return rest.length <= 8;
}
export function isInstruction(text: string): boolean {
  const t = text.trim();
  if (t.split(/\s+/).length < 2) return false;
  return INSTR_EN.test(t) || INSTR_FA.test(t);
}

// ----------------------------------------------------------- numeric feats

export interface LineFeats {
  sizeRatio: number;
  bold: number;
  xLeft: number; // x0 / pageWidth
  yTop: number; // y0 / pageHeight
  lenChars: number; // /60 capped
  words: number; // /12 capped
  hasDigit: number;
  hasPersian: number;
  veryShort: number; // <=3 chars
  endColon: number; // ends with : or ;
  startsLetterDot: number; // "A." / "A)" / "a -"
  sizeBucket: number; // 0..4 (structure token component)
}

export function featsOf(l: BrainLine, pageW: number, pageH: number, bodySize: number): LineFeats {
  const t = l.text.trim();
  const ratio = l.size / (bodySize || l.size || 12);
  const bucket = ratio < 1.05 ? 0 : ratio < 1.15 ? 1 : ratio < 1.35 ? 2 : ratio < 1.8 ? 3 : 4;
  const words = t.split(/\s+/).filter(Boolean).length;
  return {
    sizeRatio: Math.min(ratio, 3) / 3,
    bold: l.bold ? 1 : 0,
    xLeft: pageW ? Math.min(Math.max(l.bbox[0] / pageW, 0), 1) : 0,
    yTop: pageH ? Math.min(Math.max(l.bbox[1] / pageH, 0), 1) : 0,
    lenChars: Math.min(t.length, 60) / 60,
    words: Math.min(words, 12) / 12,
    hasDigit: /\d/.test(t) ? 1 : 0,
    hasPersian: /[\u0600-\u06FF]/.test(t) ? 1 : 0,
    veryShort: t.length <= 3 ? 1 : 0,
    endColon: /[:\u061B]$/.test(t) ? 1 : 0,
    startsLetterDot: /^[A-Za-z\u0627\u0628\u067E][.)\]-]\s/.test(t) ? 1 : 0,
    sizeBucket: bucket,
  };
}

export function featsVec(f: LineFeats): number[] {
  return [
    f.sizeRatio, f.bold, f.xLeft, f.yTop, f.lenChars, f.words,
    f.hasDigit, f.hasPersian, f.veryShort, f.endColon, f.startsLetterDot,
  ];
}

// ------------------------------------------------------------- corpus load

export interface LabeledLine {
  file: string;
  text: string;
  folded: string;
  size: number;
  bold: boolean;
  bbox: number[];
  page: number;
  bodySize: number;
  role: Role;
  subject: Subject;
  event: Event;
  feats: LineFeats;
  synthetic?: boolean;
}

export interface LabeledDoc {
  file: string;
  lines: LabeledLine[];
}

function labelDoc(doc: BrainDoc): LabeledDoc {
  const P = perceive(JSON.parse(JSON.stringify(doc)) as BrainDoc);
  const out: LabeledLine[] = [];

  // object-identity sets from THIS perceive pass
  const headerSet = new Set(P.headers);
  const letterSet = new Set(P.letterOpeners.map((o) => o.line));
  const markSet = new Set(P.markTokens.map((o) => o.line));
  const numOpener = new Map<BrainLine, { num: number; subject: string }>();
  for (const o of P.numberOpeners) numOpener.set(o.line, { num: o.num, subject: o.subject });
  const optionSet = P.optionLines;

  // key tail: CONSERVATIVE — answer keys are the LAST section of an exam.
  const flat: { line: BrainLine; pageW: number; pageH: number }[] = [];
  for (const p of P.pages) for (const l of p.lines) flat.push({ line: l, pageW: p.width, pageH: p.height });
  // A marker line only counts if it sits in the final 60% of the document
  // (early "key"-looking lines on garbled/OCR files are furniture — e.g.
  // pkc61q4341 had a page-0 match that once poisoned 343/375 lines as
  // key_row). The tail starts AT the last valid marker line.
  const keyStartIdx = (() => {
    let lastMarker = -1;
    flat.forEach(({ line }, i) => {
      if (isKeyMarker(foldForCodec(line.text)) && line.text.trim().length <= 60) lastMarker = i;
    });
    if (lastMarker < 0 || lastMarker < 0.4 * flat.length) return -1;
    return lastMarker;
  })();

  let currentSubject: Subject = 'none';
  flat.forEach(({ line, pageW, pageH }, i) => {
    const f = featsOf(line, pageW, pageH, P.bodySize);
    const folded = foldForCodec(line.text);
    let role: Role = 'content';
    let subject: Subject = currentSubject;
    let event: Event = 'continue';

    if (i === keyStartIdx || (keyStartIdx >= 0 && i > keyStartIdx && isKeyMarker(folded))) {
      role = 'key_boundary';
      event = 'key_start';
      currentSubject = 'none';
    } else if (keyStartIdx >= 0 && i > keyStartIdx) {
      // shape-guarded: bare numbers / sentences inside the tail are content
      role = isKeyRowShape(folded) ? 'key_row' : 'content';
      currentSubject = 'none';
    } else if (P.pageNumbers.some((o) => o.line === line)) {
      role = 'page_number';
      event = 'noise';
    } else if (headerSet.has(line)) {
      const m = mapSubject(matchSubject(line.text));
      if (m) {
        role = 'header_subject';
        subject = m;
        currentSubject = subject;
      } else {
        role = 'header_generic';
        subject = 'none';
      }
      event = 'section_start';
    } else if (numOpener.has(line)) {
      role = 'row_opener_numeric';
      subject = mapSubject(numOpener.get(line)!.subject) ?? 'none';
      currentSubject = subject;
      event = 'row_start';
    } else if (letterSet.has(line)) {
      role = 'row_opener';
      event = 'row_start';
    } else if (markSet.has(line)) {
      role = 'mark_token';
    } else if (optionSet.has(line)) {
      role = 'option_line';
    } else if (isTotalLine(folded)) {
      role = 'total_line';
      event = 'total';
    } else if (isDialogue(folded)) {
      role = 'dialogue_line';
    } else if (isInstruction(line.text)) {
      role = 'instruction';
    }

    out.push({
      file: doc.file, text: line.text, folded, size: line.size, bold: !!line.bold,
      bbox: line.bbox, page: line.page, bodySize: P.bodySize, role, subject, event, feats: f,
    });
  });

  return { file: doc.file, lines: out };
}

export function loadCorpus(): LabeledDoc[] {
  const files = fs.readdirSync(CORPUS_DIR).filter((f) => f.endsWith('.json')).sort();
  const docs: LabeledDoc[] = [];
  for (const f of files) {
    try {
      const doc = JSON.parse(fs.readFileSync(path.join(CORPUS_DIR, f), 'utf8')) as BrainDoc;
      const labeled = labelDoc(doc);
      if (labeled.lines.length) docs.push(labeled);
    } catch {
      /* skip unreadable sidecar */
    }
  }
  return docs;
}

// ------------------------------------------------- corruption (OCR robustness)

const MANGLE_LATIN: Record<string, string> = { o: '0', l: '1', i: '1', e: '3', s: '5', b: '6', g: '9', c: '(' };
const MANGLE_FA: Record<string, string> = { '\u06CC': '\u064A', '\u06A9': '\u0643' };

/** Deterministic-ish corruption with a seed so evals are reproducible. */
export function corruptText(s: string, seed: number, strength = 0.18): string {
  let st = seed * 2654435761 % 2147483647;
  const rnd = () => (st = (st * 48271) % 2147483647) / 2147483647;
  const chars = [...s];
  const out = chars.map((ch) => {
    const lo = ch.toLowerCase();
    if (MANGLE_LATIN[lo] && rnd() < strength) return MANGLE_LATIN[lo];
    if (MANGLE_FA[ch] && rnd() < strength) return MANGLE_FA[ch];
    if (rnd() < strength * 0.35) return ''; // deletion
    if (rnd() < strength * 0.25) return ch + ch; // duplication
    return ch;
  });
  return out.join('');
}

// ------------------------------------------------------- synthetic anchors

interface Tpl { role: Role; subject: Subject; text: string; size: number; bold: boolean }
const TEMPLATES: Tpl[] = [
  { role: 'header_subject', subject: 'vocabulary', text: 'Vocabulary', size: 16, bold: true },
  { role: 'header_subject', subject: 'vocabulary', text: 'Vocabulary', size: 13.5, bold: true },
  { role: 'header_subject', subject: 'grammar', text: 'Grammar', size: 16, bold: true },
  { role: 'header_subject', subject: 'grammar', text: 'Grammar', size: 13.5, bold: true },
  { role: 'header_subject', subject: 'listening', text: 'Listening', size: 15, bold: true },
  { role: 'header_subject', subject: 'reading', text: 'Reading', size: 15, bold: true },
  { role: 'header_subject', subject: 'writing', text: 'Writing', size: 15, bold: true },
  { role: 'header_subject', subject: 'speaking', text: 'Speaking', size: 15, bold: true },
  { role: 'header_subject', subject: 'pronunciation', text: 'Pronunciation', size: 15, bold: true },
  { role: 'header_subject', subject: 'vocabulary', text: 'Vocabulary', size: 14, bold: true },
  { role: 'header_subject', subject: 'grammar', text: 'Grammar', size: 14, bold: true },
  { role: 'header_subject', subject: 'reading', text: 'Reading', size: 14, bold: true },
  { role: 'header_generic', subject: 'none', text: 'Part One', size: 15, bold: true },
  { role: 'header_generic', subject: 'none', text: 'Section B', size: 14, bold: true },
  { role: 'row_opener', subject: 'none', text: 'A', size: 12, bold: true },
  { role: 'row_opener', subject: 'none', text: 'B', size: 12, bold: true },
  { role: 'row_opener', subject: 'none', text: 'A) Put the words in the right order', size: 12, bold: false },
  { role: 'row_opener_numeric', subject: 'grammar', text: '8 Grammar', size: 12, bold: true },
  { role: 'row_opener_numeric', subject: 'vocabulary', text: '3 Vocabulary', size: 12, bold: true },
  { role: 'row_opener_numeric', subject: 'reading', text: '12 Reading Comprehension', size: 12, bold: true },
  { role: 'mark_token', subject: 'none', text: '2', size: 12, bold: true },
  { role: 'mark_token', subject: 'none', text: '1.5', size: 12, bold: true },
  { role: 'option_line', subject: 'none', text: '1) goes 2) went 3) gone', size: 11.5, bold: false },
  { role: 'option_line', subject: 'none', text: 'a) book b) pen c) bag', size: 11.5, bold: false },
  { role: 'instruction', subject: 'none', text: 'Fill in the blanks with the correct words', size: 11.5, bold: false },
  { role: 'instruction', subject: 'none', text: 'Match the definitions with the words', size: 11.5, bold: false },
  { role: 'instruction', subject: 'none', text: 'Choose the correct answer', size: 11.5, bold: false },
  { role: 'instruction', subject: 'none', text: 'Put the words in the correct order', size: 11.5, bold: false },
  { role: 'instruction', subject: 'none', text: 'Complete the sentences with your own words', size: 11.5, bold: false },
  { role: 'content', subject: 'none', text: 'He was listening to the music when I called him', size: 11.5, bold: false },
  { role: 'content', subject: 'none', text: 'My father works in a big hospital near the city center', size: 11.5, bold: false },
  { role: 'furniture', subject: 'none', text: 'assessment center | qu2 exam bank', size: 8, bold: false },
  { role: 'furniture', subject: 'none', text: 'for more exams visit our site', size: 8, bold: false },
  { role: 'page_number', subject: 'none', text: '3', size: 11, bold: false },
  { role: 'page_number', subject: 'none', text: '17', size: 11, bold: false },
  { role: 'key_row', subject: 'none', text: '1. b 2. c 3. a 4. d', size: 11, bold: false },
  { role: 'key_row', subject: 'none', text: '5) T 6) F 7) T', size: 11, bold: false },
  { role: 'key_boundary', subject: 'none', text: 'THE ANSWER KEY', size: 12, bold: true },
  { role: 'key_boundary', subject: 'none', text: 'answer key', size: 12, bold: false },
  { role: 'total_line', subject: 'none', text: 'total : 40', size: 12, bold: true },
  { role: 'dialogue_line', subject: 'none', text: 'A: Good morning. How can I help you?', size: 11.5, bold: false },
  { role: 'dialogue_line', subject: 'none', text: 'B: I am looking for the science museum.', size: 11.5, bold: false },
  // --- tail boosters: the real corpus has 5-93 lines per tail class ---
  { role: 'header_subject', subject: 'vocabulary', text: 'Vocabulary (14)', size: 14, bold: true },
  { role: 'header_subject', subject: 'grammar', text: 'Grammar & Language Function', size: 14, bold: true },
  { role: 'header_subject', subject: 'listening', text: 'Listening Comprehension', size: 14, bold: true },
  { role: 'header_subject', subject: 'vocabulary', text: 'Vocabulary', size: 12.5, bold: true },
  { role: 'header_subject', subject: 'reading', text: 'Reading Comprehension', size: 13, bold: true },
  { role: 'header_subject', subject: 'writing', text: 'Writing', size: 13, bold: true },
  { role: 'header_generic', subject: 'none', text: 'Part Two: Language Functions', size: 13, bold: true },
  { role: 'header_generic', subject: 'none', text: 'I. Reading and Vocabulary', size: 14, bold: true },
  { role: 'header_generic', subject: 'none', text: 'Part 1', size: 13, bold: true },
  { role: 'header_generic', subject: 'none', text: 'B. Reading', size: 13, bold: true },
  { role: 'instruction', subject: 'none', text: 'Put the words in the right order', size: 11.5, bold: false },
  { role: 'instruction', subject: 'none', text: 'Fill in the blanks with your own words', size: 11.5, bold: false },
  { role: 'instruction', subject: 'none', text: 'Read the passage and answer the questions', size: 11.5, bold: false },
  { role: 'instruction', subject: 'none', text: 'Look at the pictures and describe them', size: 11.5, bold: false },
  { role: 'instruction', subject: 'none', text: 'Circle the correct option', size: 11.5, bold: false },
  { role: 'instruction', subject: 'none', text: 'Write a short paragraph about your best friend', size: 11.5, bold: false },
  { role: 'option_line', subject: 'none', text: '1) slowly 2) slow 3) slower', size: 11.5, bold: false },
  { role: 'option_line', subject: 'none', text: '1. a) watched b) watches c) watching', size: 11.5, bold: false },
  { role: 'option_line', subject: 'none', text: '(a) go (b) goes (c) going', size: 11.5, bold: false },
  { role: 'option_line', subject: 'none', text: '1) does he 2) does she 3) do they', size: 11.5, bold: false },
  { role: 'key_row', subject: 'none', text: '1. c 2. a 3. d 4. b 5. c', size: 11, bold: false },
  { role: 'key_row', subject: 'none', text: '6. T 7. F 8. T 9. F', size: 11, bold: false },
  { role: 'key_row', subject: 'none', text: '10) listens 11) went 12) has lived', size: 11, bold: false },
  { role: 'key_row', subject: 'none', text: '13. b  14. c  15. a', size: 11, bold: false },
  { role: 'key_boundary', subject: 'none', text: 'ANSWER KEY 1', size: 12, bold: true },
  { role: 'key_boundary', subject: 'none', text: 'Answer Key', size: 12, bold: false },
  { role: 'key_boundary', subject: 'none', text: 'KEY TO THE QUESTIONS', size: 12, bold: true },
  { role: 'total_line', subject: 'none', text: 'total : 20', size: 12, bold: true },
  { role: 'total_line', subject: 'none', text: 'total : 40', size: 11.5, bold: false },
  { role: 'total_line', subject: 'none', text: 'grand total : 60', size: 12, bold: true },
  { role: 'row_opener_numeric', subject: 'grammar', text: '10 Grammar', size: 12, bold: true },
  { role: 'row_opener_numeric', subject: 'reading', text: '5 Reading', size: 12, bold: true },
  { role: 'row_opener_numeric', subject: 'vocabulary', text: '1 Vocabulary', size: 12, bold: true },
  { role: 'row_opener', subject: 'none', text: 'C', size: 12, bold: true },
  { role: 'row_opener', subject: 'none', text: 'D) Match the words with the definitions', size: 12, bold: false },
  // reversed-storage Persian subject headers (glyph-reversed sidecars)
  { role: 'header_subject', subject: 'vocabulary', text: 'ژاژوا', size: 15, bold: true },
  { role: 'header_subject', subject: 'grammar', text: 'روتسد', size: 15, bold: true },
  { role: 'header_subject', subject: 'reading', text: 'لبتم کرد', size: 15, bold: true },
  { role: 'header_subject', subject: 'writing', text: 'یراتشون', size: 15, bold: true },
];

export function synthAnchors(corruptPer: number = 2): LabeledLine[] {
  const out: LabeledLine[] = [];
  let seed = 7;
  for (const t of TEMPLATES) {
    const mk = (text: string): LabeledLine => {
      const folded = foldForCodec(text);
      const fake: BrainLine = { text, size: t.size, bold: t.bold, bbox: [40, 300, 400, 312], page: 0 };
      return {
        file: 'SYNTH', text, folded, size: t.size, bold: t.bold, bbox: fake.bbox, page: 0,
        bodySize: 11.5,
        role: t.role, subject: t.subject,
        event: t.role === 'header_subject' || t.role === 'header_generic' ? 'section_start'
          : t.role.startsWith('row_opener') ? 'row_start'
          : t.role === 'key_boundary' ? 'key_start'
          : t.role === 'total_line' ? 'total'
          : t.role === 'page_number' || t.role === 'furniture' ? 'noise'
          : 'continue',
        feats: featsOf(fake, 612, 792, 11.5),
        synthetic: true,
      };
    };
    out.push(mk(t.text));
    for (let v = 1; v <= corruptPer; v++) {
      seed += 13;
      // graded + seed-varied corruption so inference-time mangles (0.15-0.31)
      // sit INSIDE a wide training distribution
      out.push(mk(corruptText(t.text, seed, 0.08 + v * 0.045)));
    }
  }
  return out;
}

// ------------------------------------------------------------------- folds

export function fileGroupedFolds(files: string[], k: number): Map<string, number> {
  const fold = new Map<string, number>();
  [...files].sort().forEach((f, i) => fold.set(f, i % k));
  return fold;
}
