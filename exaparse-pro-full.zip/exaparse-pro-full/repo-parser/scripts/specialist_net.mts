/**
 * specialist_net — W2: a TINY causal transformer over codec-symbol sequences
 * (trainer-side implementation: forward + backward + Adam + grad-check).
 *
 * The "LLM-ization" of the brain at 1/1000th the size: a decoder-only
 * transformer over the closed domain alphabet (role x subject x sizeBucket x
 * bold tokens) predicting per-line STRUCTURAL EVENTS (section_start /
 * row_start / key_start / total / noise / continue). Because the alphabet is
 * closed and domain-shaped, ~100k parameters deliver the LLM behaviors that
 * matter here: in-context adaptation (conditions on the document so far —
 * "sections numbered 1..18", "letters restart per part") and sequence
 * generation with calibrated per-event probabilities.
 *
 * Spec: d_model 48, 2 layers, 4 heads (head_dim 12), FFN 96, learned pos
 * ctx 64, post-LN, vocab = 14*9*5*2 combos + BOS + PAD. Float64 training;
 * int8-quantized export (see specstruct_train.mts).
 */
export const D_MODEL = 48;
export const N_LAYERS = 2;
export const N_HEADS = 4;
export const HEAD_DIM = D_MODEL / N_HEADS; // 12
export const FFN = 96;
export const CTX = 64;
export const COMBOS = 14 * 9 * 5 * 2; // 1260
export const BOS = COMBOS; // 1260
export const PAD = COMBOS + 1; // 1261
export const VOCAB = COMBOS + 2; // 1262
export const EVENTS = ['continue', 'section_start', 'row_start', 'key_start', 'total', 'noise'] as const;
export const N_EVENTS = EVENTS.length;

// codec alphabet dims (must match specialist_labels ROLES/SUBJECTS counts)
export const ALPHABET = { roles: 14, subjects: 9, sizeBuckets: 5, bold: 2 };

/** token composition — MUST mirror src/utils/specialistStructure.ts */
export function encodeToken(roleIdx: number, subjIdx: number, sizeBucket: number, bold: boolean): number {
  return ((roleIdx * ALPHABET.subjects + subjIdx) * ALPHABET.sizeBuckets + sizeBucket) * ALPHABET.bold + (bold ? 1 : 0);
}


export interface LN { g: Float64Array; b: Float64Array }
export interface LayerP {
  Wq: Float64Array; bq: Float64Array;
  Wk: Float64Array; bk: Float64Array;
  Wv: Float64Array; bv: Float64Array;
  Wo: Float64Array; bo: Float64Array;
  W1: Float64Array; b1: Float64Array;
  W2: Float64Array; b2: Float64Array;
  ln1: LN; ln2: LN;
}
export interface Params {
  E: Float64Array; P: Float64Array; lnIn: LN;
  layers: LayerP[];
  Wh: Float64Array; bh: Float64Array;
}

interface Rng { (): number }

export function initParams(seed: number): Params {
  let st = seed * 48271 % 2147483647;
  const rnd: Rng = () => (st = (st * 48271) % 2147483647) / 2147483647;
  const mat = (r: number, c: number): Float64Array => {
    const a = new Float64Array(r * c);
    const s = 1 / Math.sqrt(c);
    for (let i = 0; i < a.length; i++) a[i] = (rnd() * 2 - 1) * s;
    return a;
  };
  const zeros = (n: number) => new Float64Array(n);
  const ones = (n: number) => new Float64Array(n).fill(1);
  const p: Params = {
    E: mat(VOCAB, D_MODEL), P: mat(CTX, D_MODEL),
    lnIn: { g: ones(D_MODEL), b: zeros(D_MODEL) },
    layers: [], Wh: mat(D_MODEL, N_EVENTS), bh: zeros(N_EVENTS),
  };
  for (let l = 0; l < N_LAYERS; l++) {
    p.layers.push({
      Wq: mat(D_MODEL, D_MODEL), bq: zeros(D_MODEL),
      Wk: mat(D_MODEL, D_MODEL), bk: zeros(D_MODEL),
      Wv: mat(D_MODEL, D_MODEL), bv: zeros(D_MODEL),
      Wo: mat(D_MODEL, D_MODEL), bo: zeros(D_MODEL),
      W1: mat(D_MODEL, FFN), b1: zeros(FFN),
      W2: mat(FFN, D_MODEL), b2: zeros(D_MODEL),
      ln1: { g: ones(D_MODEL), b: zeros(D_MODEL) },
      ln2: { g: ones(D_MODEL), b: zeros(D_MODEL) },
    });
  }
  return p;
}

export interface LayerCache {
  q: Float64Array; k: Float64Array; v: Float64Array;
  att: Float64Array; // N_HEADS * T * T
  attnOut: Float64Array;
  s1: Float64Array; xhat1: Float64Array; std1: Float64Array; y1: Float64Array;
  ffnH: Float64Array;
  s2: Float64Array; xhat2: Float64Array; std2: Float64Array; y2: Float64Array;
}
export interface ForwardCache {
  T: number; tokens: number[];
  x0: Float64Array; lnInHat: Float64Array; xhat0: Float64Array; std0: Float64Array;
  layers: LayerCache[];
  logits: Float64Array;
}

function lnForward(s: Float64Array, T: number, g: Float64Array, b: Float64Array,
  out: Float64Array, xhat: Float64Array, std: Float64Array) {
  for (let i = 0; i < T; i++) {
    const off = i * D_MODEL;
    let mu = 0;
    for (let d = 0; d < D_MODEL; d++) mu += s[off + d];
    mu /= D_MODEL;
    let varr = 0;
    for (let d = 0; d < D_MODEL; d++) { const dv = s[off + d] - mu; varr += dv * dv; }
    varr /= D_MODEL;
    const sd = Math.sqrt(varr + 1e-5);
    std[i] = sd;
    for (let d = 0; d < D_MODEL; d++) {
      const xh = (s[off + d] - mu) / sd;
      xhat[off + d] = xh;
      out[off + d] = xh * g[d] + b[d];
    }
  }
}

export function forward(p: Params, tokens: number[], cache: ForwardCache): Float64Array {
  const T = tokens.length;
  cache.T = T; cache.tokens = tokens.slice();
  cache.x0 = new Float64Array(T * D_MODEL);
  cache.lnInHat = new Float64Array(T * D_MODEL);
  cache.xhat0 = new Float64Array(T * D_MODEL);
  cache.std0 = new Float64Array(T);
  cache.layers = [];
  for (let i = 0; i < T; i++) {
    const tok = tokens[i];
    if (tok === PAD) continue;
    for (let d = 0; d < D_MODEL; d++) cache.x0[i * D_MODEL + d] = p.E[tok * D_MODEL + d] + p.P[i * D_MODEL + d];
  }
  lnForward(cache.x0, T, p.lnIn.g, p.lnIn.b, cache.lnInHat, cache.xhat0, cache.std0);

  let cur = cache.lnInHat;
  for (let l = 0; l < N_LAYERS; l++) {
    const L = p.layers[l];
    const q = new Float64Array(T * D_MODEL), k = new Float64Array(T * D_MODEL), v = new Float64Array(T * D_MODEL);
    for (let i = 0; i < T; i++) {
      if (tokens[i] === PAD) continue;
      for (let d = 0; d < D_MODEL; d++) {
        let sq = L.bq[d], sk = L.bk[d], sv = L.bv[d];
        for (let e = 0; e < D_MODEL; e++) {
          const xv = cur[i * D_MODEL + e];
          sq += xv * L.Wq[e * D_MODEL + d];
          sk += xv * L.Wk[e * D_MODEL + d];
          sv += xv * L.Wv[e * D_MODEL + d];
        }
        q[i * D_MODEL + d] = sq; k[i * D_MODEL + d] = sk; v[i * D_MODEL + d] = sv;
      }
    }
    const att = new Float64Array(N_HEADS * T * T);
    const attnOut = new Float64Array(T * D_MODEL);
    const scale = 1 / Math.sqrt(HEAD_DIM);
    for (let h = 0; h < N_HEADS; h++) {
      const hoff = h * HEAD_DIM, aoff = h * T * T;
      for (let i = 0; i < T; i++) {
        if (tokens[i] === PAD) continue;
        let max = -Infinity;
        const row = new Float64Array(i + 1);
        for (let j = 0; j <= i; j++) {
          if (tokens[j] === PAD) { att[aoff + i * T + j] = 0; continue; }
          let s = 0;
          for (let d = 0; d < HEAD_DIM; d++) s += q[i * D_MODEL + hoff + d] * k[j * D_MODEL + hoff + d];
          row[j] = s * scale;
          if (row[j] > max) max = row[j];
        }
        let sum = 0;
        for (let j = 0; j <= i; j++) {
          if (tokens[j] === PAD) continue;
          row[j] = Math.exp(row[j] - max);
          sum += row[j];
        }
        for (let j = 0; j <= i; j++) {
          if (tokens[j] === PAD) continue;
          att[aoff + i * T + j] = row[j] / sum;
        }
        for (let d = 0; d < HEAD_DIM; d++) {
          let acc = 0;
          for (let j = 0; j <= i; j++) acc += att[aoff + i * T + j] * v[j * D_MODEL + hoff + d];
          attnOut[i * D_MODEL + hoff + d] = acc;
        }
      }
    }
    const proj = new Float64Array(T * D_MODEL);
    for (let i = 0; i < T; i++) {
      if (tokens[i] === PAD) continue;
      for (let d = 0; d < D_MODEL; d++) {
        let acc = L.bo[d];
        for (let e = 0; e < D_MODEL; e++) acc += attnOut[i * D_MODEL + e] * L.Wo[e * D_MODEL + d];
        proj[i * D_MODEL + d] = acc;
      }
    }
    const s1 = new Float64Array(T * D_MODEL), y1 = new Float64Array(T * D_MODEL);
    const xhat1 = new Float64Array(T * D_MODEL), std1 = new Float64Array(T);
    for (let i = 0; i < T * D_MODEL; i++) s1[i] = cur[i] + proj[i];
    lnForward(s1, T, L.ln1.g, L.ln1.b, y1, xhat1, std1);
    const ffnH = new Float64Array(T * FFN);
    for (let i = 0; i < T; i++) {
      if (tokens[i] === PAD) continue;
      for (let f = 0; f < FFN; f++) {
        let acc = L.b1[f];
        for (let d = 0; d < D_MODEL; d++) acc += y1[i * D_MODEL + d] * L.W1[d * FFN + f];
        ffnH[i * FFN + f] = acc > 0 ? acc : 0;
      }
    }
    const ffnOut = new Float64Array(T * D_MODEL);
    for (let i = 0; i < T; i++) {
      if (tokens[i] === PAD) continue;
      for (let d = 0; d < D_MODEL; d++) {
        let acc = L.b2[d];
        for (let f = 0; f < FFN; f++) acc += ffnH[i * FFN + f] * L.W2[f * D_MODEL + d];
        ffnOut[i * D_MODEL + d] = acc;
      }
    }
    const s2 = new Float64Array(T * D_MODEL), y2 = new Float64Array(T * D_MODEL);
    const xhat2 = new Float64Array(T * D_MODEL), std2 = new Float64Array(T);
    for (let i = 0; i < T * D_MODEL; i++) s2[i] = y1[i] + ffnOut[i];
    lnForward(s2, T, L.ln2.g, L.ln2.b, y2, xhat2, std2);
    cache.layers.push({ q, k, v, att, attnOut, s1, xhat1, std1, y1, ffnH, s2, xhat2, std2, y2 });
    cur = y2;
  }
  const logits = new Float64Array(T * N_EVENTS);
  for (let i = 0; i < T; i++) {
    if (tokens[i] === PAD) continue;
    for (let e = 0; e < N_EVENTS; e++) {
      let acc = p.bh[e];
      for (let d = 0; d < D_MODEL; d++) acc += cur[i * D_MODEL + d] * p.Wh[d * N_EVENTS + e];
      logits[i * N_EVENTS + e] = acc;
    }
  }
  cache.logits = logits;
  return logits;
}

export interface GradSet {
  E: Float64Array; P: Float64Array; lnIn: LN;
  layers: LayerP[];
  Wh: Float64Array; bh: Float64Array;
}

export function zeroGrads(p: Params): GradSet {
  const zeros = (n: number) => new Float64Array(n);
  return {
    E: zeros(p.E.length), P: zeros(p.P.length),
    lnIn: { g: zeros(D_MODEL), b: zeros(D_MODEL) },
    layers: p.layers.map(() => ({
      Wq: zeros(D_MODEL * D_MODEL), bq: zeros(D_MODEL),
      Wk: zeros(D_MODEL * D_MODEL), bk: zeros(D_MODEL),
      Wv: zeros(D_MODEL * D_MODEL), bv: zeros(D_MODEL),
      Wo: zeros(D_MODEL * D_MODEL), bo: zeros(D_MODEL),
      W1: zeros(D_MODEL * FFN), b1: zeros(FFN),
      W2: zeros(FFN * D_MODEL), b2: zeros(D_MODEL),
      ln1: { g: zeros(D_MODEL), b: zeros(D_MODEL) },
      ln2: { g: zeros(D_MODEL), b: zeros(D_MODEL) },
    })),
    Wh: zeros(p.Wh.length), bh: zeros(p.bh.length),
  };
}

/** backward of mean CE over valid (non-PAD) positions */
export function backward(p: Params, cache: ForwardCache, labels: number[], g: GradSet): number {
  const T = cache.T;
  const tokens = cache.tokens;
  let nValid = 0;
  for (let i = 0; i < T; i++) if (tokens[i] !== PAD) nValid++;
  if (!nValid) return 0;
  const dlogits = new Float64Array(T * N_EVENTS);
  let loss = 0;
  for (let i = 0; i < T; i++) {
    if (tokens[i] === PAD) continue;
    const off = i * N_EVENTS;
    let max = -Infinity;
    for (let e = 0; e < N_EVENTS; e++) if (cache.logits[off + e] > max) max = cache.logits[off + e];
    let sum = 0;
    const pr = new Float64Array(N_EVENTS);
    for (let e = 0; e < N_EVENTS; e++) { pr[e] = Math.exp(cache.logits[off + e] - max); sum += pr[e]; }
    for (let e = 0; e < N_EVENTS; e++) pr[e] /= sum;
    loss += -Math.log(Math.max(pr[labels[i]], 1e-12));
    for (let e = 0; e < N_EVENTS; e++) dlogits[off + e] = (pr[e] - (e === labels[i] ? 1 : 0)) / nValid;
  }
  loss /= nValid;

  // ---- head ----
  const lastY = cache.layers[N_LAYERS - 1].y2;
  let dCur = new Float64Array(T * D_MODEL);
  for (let i = 0; i < T; i++) {
    if (tokens[i] === PAD) continue;
    for (let e = 0; e < N_EVENTS; e++) {
      const dl = dlogits[i * N_EVENTS + e];
      g.bh[e] += dl;
      for (let d = 0; d < D_MODEL; d++) {
        g.Wh[d * N_EVENTS + e] += dl * lastY[i * D_MODEL + d];
        dCur[i * D_MODEL + d] += dl * p.Wh[d * N_EVENTS + e];
      }
    }
  }

  // ---- layers, top-down ----
  for (let l = N_LAYERS - 1; l >= 0; l--) {
    const L = p.layers[l];
    const C = cache.layers[l];
    const GL = g.layers[l];
    // ln2: y2 = LN(s2), dy2 = dCur -> ds2, gln2
    const ds2 = lnBackward(dCur, L.ln2, GL.ln2, C.xhat2, C.std2, T);
    const dffnOut = ds2;
    const dy1 = new Float64Array(T * D_MODEL);
    for (let i = 0; i < T * D_MODEL; i++) dy1[i] = ds2[i];
    // ffn
    for (let i = 0; i < T; i++) {
      if (tokens[i] === PAD) continue;
      for (let d = 0; d < D_MODEL; d++) {
        const doo = dffnOut[i * D_MODEL + d];
        if (doo === 0) continue;
        GL.b2[d] += doo;
        for (let f = 0; f < FFN; f++) GL.W2[f * D_MODEL + d] += doo * C.ffnH[i * FFN + f];
      }
    }
    for (let i = 0; i < T; i++) {
      if (tokens[i] === PAD) continue;
      for (let f = 0; f < FFN; f++) {
        if (C.ffnH[i * FFN + f] <= 0) continue;
        let acc = 0;
        for (let d = 0; d < D_MODEL; d++) acc += dffnOut[i * D_MODEL + d] * L.W2[f * D_MODEL + d];
        if (acc === 0) continue;
        GL.b1[f] += acc;
        for (let d = 0; d < D_MODEL; d++) {
          GL.W1[d * FFN + f] += acc * C.y1[i * D_MODEL + d];
          dy1[i * D_MODEL + d] += acc * L.W1[d * FFN + f];
        }
      }
    }
    // ln1
    const ds1 = lnBackward(dy1, L.ln1, GL.ln1, C.xhat1, C.std1, T);
    const dproj = ds1;
    const dattnOut = new Float64Array(T * D_MODEL);
    for (let i = 0; i < T; i++) {
      if (tokens[i] === PAD) continue;
      for (let d = 0; d < D_MODEL; d++) {
        const doo = dproj[i * D_MODEL + d];
        if (doo === 0) continue;
        GL.bo[d] += doo;
        for (let e = 0; e < D_MODEL; e++) {
          GL.Wo[e * D_MODEL + d] += doo * C.attnOut[i * D_MODEL + e];
          dattnOut[i * D_MODEL + e] += doo * L.Wo[e * D_MODEL + d];
        }
      }
    }
    // attention backward
    const dq = new Float64Array(T * D_MODEL), dk = new Float64Array(T * D_MODEL), dv = new Float64Array(T * D_MODEL);
    const scale = 1 / Math.sqrt(HEAD_DIM);
    for (let h = 0; h < N_HEADS; h++) {
      const hoff = h * HEAD_DIM, aoff = h * T * T;
      for (let i = 0; i < T; i++) {
        if (tokens[i] === PAD) continue;
        const dArow = new Float64Array(i + 1);
        let dot = 0;
        for (let j = 0; j <= i; j++) {
          if (tokens[j] === PAD) continue;
          let dA = 0;
          for (let d = 0; d < HEAD_DIM; d++) dA += dattnOut[i * D_MODEL + hoff + d] * C.v[j * D_MODEL + hoff + d];
          dArow[j] = dA;
          dot += dA * C.att[aoff + i * T + j];
        }
        for (let j = 0; j <= i; j++) {
          if (tokens[j] === PAD) continue;
          const a = C.att[aoff + i * T + j];
          const dS = a * (dArow[j] - dot);
          if (dS === 0) continue;
          for (let d = 0; d < HEAD_DIM; d++) {
            dq[i * D_MODEL + hoff + d] += dS * scale * C.k[j * D_MODEL + hoff + d];
            dk[j * D_MODEL + hoff + d] += dS * scale * C.q[i * D_MODEL + hoff + d];
            dv[j * D_MODEL + hoff + d] += a * dattnOut[i * D_MODEL + hoff + d];
          }
        }
      }
    }
    // qkv projections back to the layer input
    const dIn = new Float64Array(T * D_MODEL);
    for (let i = 0; i < T; i++) {
      if (tokens[i] === PAD) continue;
      for (let d = 0; d < D_MODEL; d++) {
        const gq = dq[i * D_MODEL + d], gk = dk[i * D_MODEL + d], gv = dv[i * D_MODEL + d];
        if (gq === 0 && gk === 0 && gv === 0) continue;
        GL.bq[d] += gq; GL.bk[d] += gk; GL.bv[d] += gv;
        for (let e = 0; e < D_MODEL; e++) {
          const src = l === 0 ? cache.lnInHat[i * D_MODEL + e] : cache.layers[l - 1].y2[i * D_MODEL + e];
          GL.Wq[e * D_MODEL + d] += gq * src;
          GL.Wk[e * D_MODEL + d] += gk * src;
          GL.Wv[e * D_MODEL + d] += gv * src;
          dIn[i * D_MODEL + e] += gq * L.Wq[e * D_MODEL + d]
            + gk * L.Wk[e * D_MODEL + d]
            + gv * L.Wv[e * D_MODEL + d];
        }
      }
    }
    // RESIDUAL: s1 = cur + proj, so ds1 also flows straight into the input
    for (let i = 0; i < T * D_MODEL; i++) dIn[i] += ds1[i];
    if (l === 0) {
      const ds0 = lnBackward(dIn, p.lnIn, g.lnIn, cache.xhat0, cache.std0, T);
      for (let i = 0; i < T; i++) {
        const tok = tokens[i];
        if (tok === PAD) continue;
        for (let d = 0; d < D_MODEL; d++) {
          g.E[tok * D_MODEL + d] += ds0[i * D_MODEL + d];
          g.P[i * D_MODEL + d] += ds0[i * D_MODEL + d];
        }
      }
    } else {
      dCur = dIn;
    }
  }
  return loss;
}

/** y = xhat*g + b; accumulates dg and db; returns ds */
function lnBackward(dy: Float64Array, ln: LN, gln: LN, xhat: Float64Array, std: Float64Array, T: number): Float64Array {
  const ds = new Float64Array(T * D_MODEL);
  for (let i = 0; i < T; i++) {
    const off = i * D_MODEL;
    let m1 = 0, m2 = 0;
    for (let d = 0; d < D_MODEL; d++) {
      const t = ln.g[d] * dy[off + d];
      m1 += t; m2 += t * xhat[off + d];
      gln.b[d] += dy[off + d];
    }
    m1 /= D_MODEL; m2 /= D_MODEL;
    for (let d = 0; d < D_MODEL; d++) {
      ds[off + d] = (ln.g[d] * dy[off + d] - m1 - xhat[off + d] * m2) / std[i];
      gln.g[d] += dy[off + d] * xhat[off + d];
    }
  }
  return ds;
}

// ------------------------------------------------------------------- Adam

export interface AdamState { m: GradSet; v: GradSet; t: number }

export function initAdam(p: Params): AdamState {
  return { m: zeroGrads(p), v: zeroGrads(p), t: 0 };
}

const LR = 1e-3;
const B1 = 0.9, B2 = 0.999, EPS = 1e-8;

export function adamStep(p: Params, g: GradSet, a: AdamState, lr: number = LR): number {
  a.t++;
  const bc1 = 1 - Math.pow(B1, a.t), bc2 = 1 - Math.pow(B2, a.t);
  let normSq = 0;
  const upd = (arr: Float64Array, gr: Float64Array, m: Float64Array, v: Float64Array) => {
    for (let i = 0; i < arr.length; i++) {
      const gi = gr[i];
      normSq += gi * gi;
      m[i] = B1 * m[i] + (1 - B1) * gi;
      v[i] = B2 * v[i] + (1 - B2) * gi * gi;
      const d = (lr * (m[i] / bc1)) / (Math.sqrt(v[i] / bc2) + EPS);
      arr[i] -= d;
    }
  };
  const lnUpd = (ln: LN, gl: LN, m: LN, v: LN) => { upd(ln.g, gl.g, m.g, v.g); upd(ln.b, gl.b, m.b, v.b); };
  const layerUpd = (pl: LayerP, gl: LayerP, ml: LayerP, vl: LayerP) => {
    upd(pl.Wq, gl.Wq, ml.Wq, vl.Wq); upd(pl.bq, gl.bq, ml.bq, vl.bq);
    upd(pl.Wk, gl.Wk, ml.Wk, vl.Wk); upd(pl.bk, gl.bk, ml.bk, vl.bk);
    upd(pl.Wv, gl.Wv, ml.Wv, vl.Wv); upd(pl.bv, gl.bv, ml.bv, vl.bv);
    upd(pl.Wo, gl.Wo, ml.Wo, vl.Wo); upd(pl.bo, gl.bo, ml.bo, vl.bo);
    upd(pl.W1, gl.W1, ml.W1, vl.W1); upd(pl.b1, gl.b1, ml.b1, vl.b1);
    upd(pl.W2, gl.W2, ml.W2, vl.W2); upd(pl.b2, gl.b2, ml.b2, vl.b2);
    lnUpd(pl.ln1, gl.ln1, ml.ln1, vl.ln1); lnUpd(pl.ln2, gl.ln2, ml.ln2, vl.ln2);
  };
  upd(p.E, g.E, a.m.E, a.v.E);
  upd(p.P, g.P, a.m.P, a.v.P);
  lnUpd(p.lnIn, g.lnIn, a.m.lnIn, a.v.lnIn);
  for (let l = 0; l < N_LAYERS; l++) layerUpd(p.layers[l], g.layers[l], a.m.layers[l], a.v.layers[l]);
  upd(p.Wh, g.Wh, a.m.Wh, a.v.Wh);
  upd(p.bh, g.bh, a.m.bh, a.v.bh);
  return Math.sqrt(normSq);
}

/** clip grads in place to maxNorm; returns the pre-clip norm */
export function clipGrads(g: GradSet, maxNorm: number): number {
  let normSq = 0;
  const acc = (arr: Float64Array) => { for (let i = 0; i < arr.length; i++) normSq += arr[i] * arr[i]; };
  const each = (l: LayerP, fn: (a: Float64Array) => void) => {
    fn(l.Wq); fn(l.bq); fn(l.Wk); fn(l.bk); fn(l.Wv); fn(l.bv);
    fn(l.Wo); fn(l.bo); fn(l.W1); fn(l.b1); fn(l.W2); fn(l.b2);
    fn(l.ln1.g); fn(l.ln1.b); fn(l.ln2.g); fn(l.ln2.b);
  };
  acc(g.E); acc(g.P); acc(g.lnIn.g); acc(g.lnIn.b);
  for (const l of g.layers) each(l, acc);
  acc(g.Wh); acc(g.bh);
  const norm = Math.sqrt(normSq);
  if (norm <= maxNorm) return norm;
  const sc = maxNorm / norm;
  const scf = (arr: Float64Array) => { for (let i = 0; i < arr.length; i++) arr[i] *= sc; };
  scf(g.E); scf(g.P); scf(g.lnIn.g); scf(g.lnIn.b);
  for (const l of g.layers) each(l, scf);
  scf(g.Wh); scf(g.bh);
  return norm;
}
