/**
 * specialist_stress — regression net for the W1/W2 SPECIALIST models.
 *
 * Pins (all fail-safe-first, mirroring the S26 pattern):
 *   W1 codec:  corrupt/truncated weights disable cleanly; OCR-mangled text
 *              ("V0cabulary", confused digits, reversed Persian) still
 *              classifies; the runtime feature mirror matches the labeler;
 *   W2 struct: corrupt weights disable cleanly; the runtime forward
 *              reproduces the trainer's quantized canonical reference;
 *              a doc-like token sequence yields the expected event shape.
 *
 * Run: npx tsx scripts/specialist_stress.ts   (exit 1 on any failure)
 */
import {
  codecValidate, codecClassify, computeFeats, codecReady,
} from '../src/utils/specialistCodec';
import { CODEC_WEIGHTS } from '../src/utils/specialistCodecWeights';
import {
  structureValidate, structureEvents, structureReady, STRUCT_EVENTS,
} from '../src/utils/specialistStructure';
import { STRUCT_WEIGHTS } from '../src/utils/specialistStructureWeights';
import { featsOf, synthAnchors } from '../scripts/specialist_labels.mts';

let failures = 0;
const ok = (cond: boolean, label: string, detail = '') => {
  console.log(`  ${cond ? 'ok' : 'ok'}  ${cond ? '' : 'FAIL  '}${label}${detail ? ' — ' + detail : ''}`);
  if (!cond) failures++;
};
const okc = (cond: boolean, label: string, detail = '') => {
  console.log(`  ${cond ? 'ok' : 'FAIL'}  ${label}${detail ? ' — ' + detail : ''}`);
  if (!cond) failures++;
};

function main() {
  console.log('== specialist stress (W1 codec + W2 structure) ==');

  // ---------------- W1: codec ----------------
  console.log('S28: codec fail-safe + malformed weights');
  okc(codecValidate(null) === null, 'S28 validate(null) -> null');
  okc(codecValidate({ ...CODEC_WEIGHTS, roleW: ['x' as unknown as string] }) === null, 'S28 truncated row -> null');
  okc(codecValidate({ ...CODEC_WEIGHTS, buckets: -1 }) === null, 'S28 negative buckets -> null');
  okc(codecValidate({ ...CODEC_WEIGHTS, roleWScale: 42 as unknown as number[] }) === null, 'S28 corrupt scales -> null');
  okc(codecReady() !== null, 'S28 shipped weights load');

  console.log('S29: codec reads mangled text the regexes cannot');
  const feats = { size: 16, bold: true, bbox: [40, 300, 400, 312] as number[], pageW: 612, pageH: 792, bodySize: 11.5 };
  const c1 = codecClassify('V0cabulary', feats);
  okc(c1?.role === 'header_subject', 'S29 "V0cabulary" -> header_subject', `${c1?.role} p=${c1?.roleP?.toFixed(2)}`);
  const c2 = codecClassify('V0cabu1ary', feats);
  okc(c2?.role === 'header_subject', 'S29 "V0cabu1ary" -> header_subject', `${c2?.role}`);
  const c3 = codecClassify('8 Grammar', { size: 12, bold: true, bbox: feats.bbox, pageW: 612, pageH: 792, bodySize: 11.5 });
  okc(c3?.role === 'row_opener_numeric', 'S29 "8 Grammar" -> row_opener_numeric', `${c3?.role}`);
  const c4 = codecClassify('8 Graminar', { size: 12, bold: true, bbox: feats.bbox, pageW: 612, pageH: 792, bodySize: 11.5 });
  okc(c4?.role === 'row_opener_numeric' || c4?.role === 'header_subject', 'S29 mangled radif opener stays opener-class', `${c4?.role}`);
  const c5 = codecClassify('totol : 40', { size: 12, bold: true, bbox: feats.bbox, pageW: 612, pageH: 792, bodySize: 11.5 });
  okc(c5?.role === 'total_line', 'S29 "totol : 40" -> total_line', `${c5?.role}`);
  const c6 = codecClassify('A: Good m0rning. H0w can I help y0u?', { size: 11.5, bold: false, bbox: feats.bbox, pageW: 612, pageH: 792, bodySize: 11.5 });
  okc(c6?.role === 'dialogue_line', 'S29 mangled dialogue -> dialogue_line', `${c6?.role}`);

  console.log('S30: runtime/labeler feature mirror identical');
  const anchor = synthAnchors(0)[0];
  const a = computeFeats(anchor.text, anchor.size, anchor.bold, anchor.bbox, 612, 792, 11.5);
  const b = featsOf({ text: anchor.text, size: anchor.size, bold: anchor.bold, bbox: anchor.bbox, page: 0 }, 612, 792, 11.5);
  const bv = [b.sizeRatio, b.bold, b.xLeft, b.yTop, b.lenChars, b.words, b.hasDigit, b.hasPersian, b.veryShort, b.endColon, b.startsLetterDot];
  okc(a.length === 11 && a.every((v, i) => Math.abs(v - bv[i]) < 1e-9), 'S30 feature vectors identical');

  // ---------------- W2: structure ----------------
  console.log('S31: structure fail-safe + malformed weights');
  okc(structureValidate(null) === null, 'S31 validate(null) -> null');
  okc(structureValidate({ ...STRUCT_WEIGHTS, layers: [] }) === null, 'S31 missing layers -> null');
  okc(structureValidate({ ...STRUCT_WEIGHTS, E: { data: '!!!', scale: 1 } }) === null, 'S31 corrupt embedding -> null');
  okc(structureReady() !== null, 'S31 shipped weights load');

  console.log('S32: runtime forward reproduces the quantized reference');
  {
    const res = structureEvents(STRUCT_WEIGHTS.canonTokens);
    let maxDiff = 0;
    STRUCT_WEIGHTS.canonProbs.forEach((ref, i) => {
      const got = res?.probs[i];
      if (!got) { maxDiff = 1; return; }
      for (let e = 0; e < STRUCT_EVENTS.length; e++) maxDiff = Math.max(maxDiff, Math.abs((got[e] ?? 0) - ref[e]));
    });
    okc(maxDiff <= 1e-3, 'S32 canonical drift <= 1e-3', `max ${maxDiff.toExponential(2)}`);
  }

  console.log('S33: doc-like sequence yields the expected event shape');
  {
    // header, instruction, content, row opener, content, content, key boundary, key row
    const m = structureReady()!;
    const roleIdx = (n: string) => (CODEC_WEIGHTS.roles as readonly string[]).indexOf(n);
    const subjIdx = (n: string) => (CODEC_WEIGHTS.subjects as readonly string[]).indexOf(n);
    const tok = (r: string, s: string, b: number, bold: boolean) =>
      ((Math.max(roleIdx(r), 0) * 9 + Math.max(subjIdx(s), 0)) * 5 + b) * 2 + (bold ? 1 : 0);
    void m;
    const toks = [
      tok('header_subject', 'grammar', 3, true),
      tok('instruction', 'none', 0, false),
      tok('content', 'none', 0, false),
      tok('row_opener', 'none', 0, true),
      tok('content', 'none', 0, false),
      tok('content', 'none', 0, false),
      tok('key_boundary', 'none', 1, true),
      tok('key_row', 'none', 0, false),
    ];
    const res = structureEvents(toks)!;
    okc(res.events[0]?.event === 1, 'S33 header -> section_start', `got ${STRUCT_EVENTS[res.events[0].event]}`);
    okc(res.events[3]?.event === 2 || res.events[6]?.event === 3, 'S33 opener/key recognized',
      `row@3=${STRUCT_EVENTS[res.events[3].event]} key@6=${STRUCT_EVENTS[res.events[6].event]}`);
    const contentContinue = res.events[4]?.event === 0 || res.events[5]?.event === 0;
    okc(contentContinue, 'S33 content lines continue', `@4=${STRUCT_EVENTS[res.events[4].event]} @5=${STRUCT_EVENTS[res.events[5].event]}`);
  }

  console.log(failures === 0 ? '\n== specialist_stress: ALL GREEN ==' : `\n== specialist_stress: ${failures} FAILURE(S) ==`);
  process.exit(failures === 0 ? 0 : 1);
}

main();
