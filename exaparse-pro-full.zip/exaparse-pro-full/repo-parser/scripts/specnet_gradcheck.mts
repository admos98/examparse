/**
 * specnet_gradcheck — per-tensor-group gradient probe for the W2 net.
 * Finite-differences one parameter per group and reports the relative error,
 * so a broken backward path is pinpointed to the exact weight matrix.
 * Run: npx tsx scripts/specnet_gradcheck.mts
 */
import {
  initParams, forward, backward, zeroGrads, ForwardCache, Params, BOS, PAD, N_EVENTS, encodeToken,
} from './specialist_net.mts';
import { ROLES, SUBJECTS } from './specialist_labels.mts';

const tok = (r: string, s: string, b: number, bold: boolean) =>
  encodeToken(Math.max(ROLES.indexOf(r as any), 0), Math.max(SUBJECTS.indexOf(s as any), 0), b, bold);

const tokens = [
  BOS,
  tok('header_subject', 'grammar', 3, true),
  tok('instruction', 'none', 0, false),
  tok('content', 'none', 0, false),
  tok('row_opener', 'none', 0, true),
  tok('content', 'none', 0, false),
  tok('mark_token', 'none', 0, true),
  tok('total_line', 'none', 1, true),
];
const events = [0, 1, 3, 0, 2, 0, 0, 4];

const lossOf = (p: Params): number => {
  const c: ForwardCache = { T: 0, tokens: [], x0: new Float64Array(0), lnInHat: new Float64Array(0), xhat0: new Float64Array(0), std0: new Float64Array(0), layers: [], logits: new Float64Array(0) };
  forward(p, tokens, c);
  let n = 0, s = 0;
  for (let i = 0; i < tokens.length; i++) {
    if (tokens[i] === PAD) continue;
    n++;
    const off = i * N_EVENTS;
    let max = -Infinity;
    for (let e = 0; e < N_EVENTS; e++) if (c.logits[off + e] > max) max = c.logits[off + e];
    let sum = 0;
    const pr = new Float64Array(N_EVENTS);
    for (let e = 0; e < N_EVENTS; e++) { pr[e] = Math.exp(c.logits[off + e] - max); sum += pr[e]; }
    for (let e = 0; e < N_EVENTS; e++) pr[e] /= sum;
    s += -Math.log(Math.max(pr[events[i]], 1e-12));
  }
  return s / n;
};

const p = initParams(1234);
const cache: ForwardCache = { T: 0, tokens: [], x0: new Float64Array(0), lnInHat: new Float64Array(0), xhat0: new Float64Array(0), std0: new Float64Array(0), layers: [], logits: new Float64Array(0) };
forward(p, tokens, cache);
const g = zeroGrads(p);
const loss = backward(p, cache, events, g);
console.log('analytic loss:', loss.toFixed(6));

const groups: [string, Float64Array, Float64Array][] = [
  ['E', p.E, g.E], ['P', p.P, g.P], ['lnIn.g', p.lnIn.g, g.lnIn.g], ['lnIn.b', p.lnIn.b, g.lnIn.b],
  ['Wh', p.Wh, g.Wh], ['bh', p.bh, g.bh],
];
for (let l = 0; l < p.layers.length; l++) {
  const L = p.layers[l], G = g.layers[l];
  groups.push(
    [`L${l}.Wq`, L.Wq, G.Wq], [`L${l}.bq`, L.bq, G.bq],
    [`L${l}.Wk`, L.Wk, G.Wk], [`L${l}.Wv`, L.Wv, G.Wv],
    [`L${l}.Wo`, L.Wo, G.Wo], [`L${l}.bo`, L.bo, G.bo],
    [`L${l}.W1`, L.W1, G.W1], [`L${l}.b1`, L.b1, G.b1],
    [`L${l}.W2`, L.W2, G.W2], [`L${l}.b2`, L.b2, G.b2],
    [`L${l}.ln1g`, L.ln1.g, G.ln1.g], [`L${l}.ln1b`, L.ln1.b, G.ln1.b],
    [`L${l}.ln2g`, L.ln2.g, G.ln2.g], [`L${l}.ln2b`, L.ln2.b, G.ln2.b],
  );
}

const eps = 1e-5;

/** bisect modes: zero parameter blocks so only one pathway is live */
function configure(mode: string) {
  const zero = (a: Float64Array) => a.fill(0);
  for (const L of p.layers) {
    if (mode === 'headonly' || mode === 'ffn-only') {
      zero(L.Wq); zero(L.Wk); zero(L.Wv); zero(L.Wo); zero(L.bq); zero(L.bk); zero(L.bv); zero(L.bo);
    }
    if (mode === 'headonly' || mode === 'attn-only') {
      zero(L.W1); zero(L.W2); zero(L.b1); zero(L.b2);
    }
    L.ln1.g.fill(1); L.ln1.b.fill(0); L.ln2.g.fill(1); L.ln2.b.fill(0);
  }
  p.lnIn.g.fill(1); p.lnIn.b.fill(0);
  if (mode !== 'full') {
    // re-init grads + re-run backward for this configuration
    const c2: ForwardCache = { T: 0, tokens: [], x0: new Float64Array(0), lnInHat: new Float64Array(0), xhat0: new Float64Array(0), std0: new Float64Array(0), layers: [], logits: new Float64Array(0) };
    forward(p, tokens, c2);
    const g2 = zeroGrads(p);
    backward(p, c2, events, g2);
    // swap the group grads for the fresh ones
    for (const [, , gArr] of groups) gArr.fill(0);
    const copy = (src: Float64Array, dst: Float64Array) => dst.set(src);
    copy(g2.E, g.E); copy(g2.P, g.P); copy(g2.lnIn.g, g.lnIn.g); copy(g2.lnIn.b, g.lnIn.b);
    copy(g2.Wh, g.Wh); copy(g2.bh, g.bh);
    for (let l = 0; l < p.layers.length; l++) {
      const G2 = g2.layers[l], G1 = g.layers[l];
      copy(G2.Wq, G1.Wq); copy(G2.bq, G1.bq); copy(G2.Wk, G1.Wk); copy(G2.bk, G1.bk);
      copy(G2.Wv, G1.Wv); copy(G2.bv, G1.bv); copy(G2.Wo, G1.Wo); copy(G2.bo, G1.bo);
      copy(G2.W1, G1.W1); copy(G2.b1, G1.b1); copy(G2.W2, G1.W2); copy(G2.b2, G1.b2);
      copy(G2.ln1.g, G1.ln1.g); copy(G2.ln1.b, G1.ln1.b);
      copy(G2.ln2.g, G1.ln2.g); copy(G2.ln2.b, G1.ln2.b);
    }
  }
}

for (const mode of ['headonly', 'attn-only', 'ffn-only', 'full']) {
  configure(mode);
  console.log(`--- mode: ${mode} ---`);
  let bad = 0;
  for (const [name, arr, gArr] of groups) {
    let idx = 0, best = 0;
    for (let i = 0; i < arr.length; i++) if (Math.abs(gArr[i]) > best) { best = Math.abs(gArr[i]); idx = i; }
    if (best === 0) continue;
    const orig = arr[idx];
    arr[idx] = orig + eps;
    const l1 = lossOf(p);
    arr[idx] = orig - eps;
    const l2 = lossOf(p);
    arr[idx] = orig;
    const num = (l1 - l2) / (2 * eps);
    const ana = gArr[idx];
    const rel = Math.abs(num - ana) / Math.max(Math.abs(num), Math.abs(ana), 1e-8);
    if (rel > 3e-2) { bad++; console.log(`  ${name.padEnd(10)} num=${num.toExponential(3)} ana=${ana.toExponential(3)} rel=${rel.toExponential(2)}  <-- BAD`); }
  }
  if (bad === 0) console.log('  all probed groups OK');
}

