/**
 * specodec_eval — fresh-process validation for the W1 semantic codec.
 *
 * Measures:
 *  1. corpus fidelity — final shipped model vs the weak labels (the CV
 *     generalization number lives in the trainer report; this is the
 *     deployed-model check)
 *  2. MANGLED-TEXT stability — the codec's real new capability: corrupted
 *     OCR-style text ("V0cabulary", reversed glyphs, confused digits) must
 *     still classify to the same role
 *  3. pinned probes — specific lines that MUST classify correctly
 *  4. fail-safe — corrupt weights must validate to null, never throw
 *
 * Run: npx tsx scripts/specodec_eval.mts   (exit 1 on any failure)
 */
import {
  codecClassify, codecReady, codecValidate, computeFeats, CODEC_ROLES,
} from '../src/utils/specialistCodec';
import { CODEC_WEIGHTS } from '../src/utils/specialistCodecWeights';
import { loadCorpus, synthAnchors, corruptText, featsOf } from './specialist_labels.mts';

let failures = 0;
const ok = (cond: boolean, label: string, detail = '') => {
  console.log(`  ${cond ? 'ok' : 'FAIL'}  ${label}${detail ? ' — ' + detail : ''}`);
  if (!cond) failures++;
};

function main() {
  console.log('== W1 semantic codec: fresh-process eval ==');
  const m = codecReady();
  ok(!!m, 'weights validate and load', m ? `${m.roles.length} roles x ${m.subjects.length} subjects` : 'null');

  const docs = (() => {
    try { return loadCorpus(); } catch { return []; }
  })();
  if (!docs.length) {
    console.error('  (no corpus sidecars — see REGEN.md step A1: npx tsx scripts/brain_app_extract.mts <pdfDir>)');
    process.exit(2);
  }
  const real = docs.flatMap((d) => d.lines);
  let agree = 0;
  const perRole = new Map<string, { n: number; agree: number }>();
  for (const l of real) {
    const r = codecClassify(l.text, {
      size: l.size, bold: l.bold, bbox: l.bbox,
      pageW: 612, pageH: 792, bodySize: l.bodySize,
    });
    const role = r?.role ?? 'DISABLED';
    if (role === l.role) agree++;
    const e = perRole.get(l.role) ?? { n: 0, agree: 0 };
    e.n++;
    if (role === l.role) e.agree++;
    perRole.set(l.role, e);
  }
  const fidelity = real.length ? agree / real.length : 0;
  console.log(`  corpus fidelity (deployed model vs weak labels): ${(fidelity * 100).toFixed(2)}% over ${real.length} lines`);
  ok(fidelity >= 0.85, 'fidelity >= 85%', `got ${(fidelity * 100).toFixed(1)}%`);

  // ---- 2. mangled-text stability (the REAL new capability) ----
  const synth = synthAnchors(4);
  const probeRoles = new Set(['header_subject', 'instruction', 'total_line', 'key_row', 'key_boundary', 'row_opener_numeric', 'option_line']);
  let mN = 0, mOk = 0;
  let seed = 31;
  for (const l of [...synth, ...real]) {
    if (!probeRoles.has(l.role)) continue;
    for (let v = 0; v < 3; v++) {
      seed = (seed * 48271) % 2147483647;
      const corrupted = corruptText(l.text, seed % 1000, 0.15 + v * 0.08);
      const r = codecClassify(corrupted, {
        size: l.size, bold: l.bold, bbox: l.bbox, pageW: 612, pageH: 792, bodySize: l.bodySize,
      });
      mN++;
      if (r?.role === l.role) mOk++;
    }
  }
  const stability = mN ? mOk / mN : 0;
  console.log(`  mangled-text role stability: ${(stability * 100).toFixed(1)}% over ${mN} corrupted probes`);
  ok(stability >= 0.75, 'mangled stability >= 75%', `got ${(stability * 100).toFixed(1)}%`);

  // ---- 3. pinned probes ----
  const pin = (text: string, size: number, bold: boolean, want: string) => {
    const r = codecClassify(text, { size, bold, bbox: [40, 300, 400, 312], pageW: 612, pageH: 792, bodySize: 11.5 });
    ok(r?.role === want, `pin "${text.slice(0, 36)}" -> ${want}`, `got ${r?.role ?? 'null'} (p=${r?.roleP.toFixed(2)})`);
  };
  pin('Vocabulary', 16, true, 'header_subject');
  pin('V0cabulary', 16, true, 'header_subject');       // OCR-mangled header
  pin('Grammar', 15, true, 'header_subject');
  pin('8 Grammar', 12, true, 'row_opener_numeric');    // radif opener w/ clean text
  pin('Fill in the blanks with the correct words', 11.5, false, 'instruction');
  pin('total : 40', 12, true, 'total_line');
  pin('THE ANSWER KEY', 12, true, 'key_boundary');
  pin('A: Good morning. How can I help you?', 11.5, false, 'dialogue_line');
  pin('for more exams visit our site', 8, false, 'furniture');
  pin('2', 12, true, 'mark_token');
  pin('He was listening to the music when I called him', 11.5, false, 'content');

  // ---- 4. fail-safe: corrupt blobs validate to null, never throw ----
  ok(codecValidate(null) === null, 'validate(null) -> null');
  ok(codecValidate({ version: 2 }) === null, 'validate(wrong version) -> null');
  ok(codecValidate({ ...CODEC_WEIGHTS, roleW: ['!!!truncated'] }) === null,
    'validate(truncated row) -> null');
  ok(Array.isArray(CODEC_ROLES) && CODEC_ROLES.length === 14, 'role alphabet exported');

  // feature-mirror drift guard: runtime computeFeats vs labeler featsOf
  const l0 = synth[0];
  const a = computeFeats(l0.text, l0.size, l0.bold, l0.bbox, 612, 792, 11.5);
  const b = featsOf({ text: l0.text, size: l0.size, bold: l0.bold, bbox: l0.bbox, page: 0 }, 612, 792, 11.5);
  const bv = [
    b.sizeRatio, b.bold, b.xLeft, b.yTop, b.lenChars, b.words,
    b.hasDigit, b.hasPersian, b.veryShort, b.endColon, b.startsLetterDot,
  ];
  ok(a.every((v, i) => Math.abs(v - bv[i]) < 1e-9), 'runtime/labeler feature mirror identical');

  console.log(failures === 0 ? '\n== specodec_eval: ALL GREEN ==' : `\n== specodec_eval: ${failures} FAILURE(S) ==`);
  process.exit(failures === 0 ? 0 : 1);
}

main();
