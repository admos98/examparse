/**
 * specodec_train — W1: train the SEMANTIC CODEC.
 *
 * A per-line classifier over hashed char n-grams + geometric features with
 * two softmax heads (ROLE, SUBJECT), distilled from the deterministic
 * perception (weak labels) + synthetic anchors (tail classes + corrupted
 * text). Pure TS, no deps. This is the codec that turns open text into the
 * closed ~14x9 domain alphabet the structure transformer (W2) consumes.
 *
 * Honesty note: corpus "accuracy" here is DISTILLATION FIDELITY vs the weak
 * labeler. The real new capability — robustness on text a regex cannot
 * match — is measured by the mangled probes (CV + eval script).
 *
 * Run: npx tsx scripts/specodec_train.mts
 * Writes: src/utils/specialistCodecWeights.ts + scratch/specialist/codec-train-report.json
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  ROLES, SUBJECTS, loadCorpus, synthAnchors, featsVec, fileGroupedFolds,
  LabeledLine,
} from './specialist_labels.mts';

const here = path.dirname(fileURLToPath(import.meta.url));
const OUT_WEIGHTS = path.join(here, '..', 'src', 'utils', 'specialistCodecWeights.ts');
const OUT_REPORT = path.join(here, '..', 'scratch', 'specialist', 'codec-train-report.json');

// ---------------------------------------------------------------- features

export const BUCKETS = 2048;

function fnv1a(s: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

/** char 1-3 grams + whole words, hashed into BUCKETS (fastText-style). */
export function ngramBuckets(folded: string): Map<number, number> {
  const t = `^ ${folded} $`;
  const counts = new Map<number, number>();
  const bump = (h: number) => {
    const b = h % BUCKETS;
    counts.set(b, Math.min((counts.get(b) ?? 0) + 1, 3));
  };
  for (let n = 1; n <= 3; n++) {
    for (let i = 0; i + n <= t.length; i++) bump(fnv1a(t.slice(i, i + n)));
  }
  for (const w of folded.split(' ').filter(Boolean)) if (w.length <= 18) bump(fnv1a('w:' + w));
  return counts;
}

// ------------------------------------------------------------------ labels

const ROLE_W: Record<string, number> = {
  content: 1, key_row: 2, dialogue_line: 2, mark_token: 1.5,
  row_opener: 2, row_opener_numeric: 3, header_subject: 3, header_generic: 2,
  instruction: 3, option_line: 5, total_line: 6, key_boundary: 4,
  furniture: 6, page_number: 3,
};
const SUBJ_W: Record<string, number> = {
  none: 0.35, vocabulary: 4, grammar: 4, listening: 4, speaking: 4,
  reading: 4, writing: 4, pronunciation: 5, general: 3,
};

interface Sample {
  buckets: Map<number, number>;
  feats: number[];
  y: number; // class index
  w: number;
  head: 'role' | 'subject';
}

const R = ROLES.length, S = SUBJECTS.length;

function trainHead(samples: Sample[], classes: number, epochs: number, seed: number):
  { W: Float64Array; numW: Float64Array; b: Float64Array } {
  const W = new Float64Array(classes * BUCKETS);
  const numW = new Float64Array(classes * 11);
  const b = new Float64Array(classes);
  const NF = 11;
  let st = seed * 48271 % 2147483647;
  const rnd = () => (st = (st * 48271) % 2147483647) / 2147483647;
  const lr0 = 0.5;
  for (let ep = 0; ep < epochs; ep++) {
    const order = samples.map((_, i) => i);
    for (let i = order.length - 1; i > 0; i--) {
      const j = Math.floor(rnd() * (i + 1));
      [order[i], order[j]] = [order[j], order[i]];
    }
    const lr = lr0 / (1 + ep * 0.35);
    for (const idx of order) {
      const s = samples[idx];
      const z = new Float64Array(classes);
      for (let c = 0; c < classes; c++) {
        let acc = b[c];
        const off = c * BUCKETS;
        for (const [bk, v] of s.buckets) acc += W[off + bk] * v;
        for (let f = 0; f < NF; f++) acc += numW[c * NF + f] * s.feats[f];
        z[c] = acc;
      }
      let max = -Infinity;
      for (let c = 0; c < classes; c++) if (z[c] > max) max = z[c];
      let sum = 0;
      const p = new Float64Array(classes);
      for (let c = 0; c < classes; c++) { p[c] = Math.exp(z[c] - max); sum += p[c]; }
      for (let c = 0; c < classes; c++) p[c] /= sum;
      for (let c = 0; c < classes; c++) {
        const g = s.w * (p[c] - (c === s.y ? 1 : 0));
        if (g === 0) continue;
        const off = c * BUCKETS;
        for (const [bk, v] of s.buckets) W[off + bk] -= lr * (g * v + 1e-6 * W[off + bk]);
        for (let f = 0; f < NF; f++) numW[c * NF + f] -= lr * (g * s.feats[f] + 1e-5 * numW[c * NF + f]);
        b[c] -= lr * g;
      }
    }
  }
  return { W, numW, b };
}

function evalHead(samples: Sample[], m: { W: Float64Array; numW: Float64Array; b: Float64Array }, classes: number): number {
  const NF = 11;
  let ok = 0;
  for (const s of samples) {
    let best = -Infinity, bi = 0;
    for (let c = 0; c < classes; c++) {
      let acc = m.b[c];
      const off = c * BUCKETS;
      for (const [bk, v] of s.buckets) acc += m.W[off + bk] * v;
      for (let f = 0; f < NF; f++) acc += m.numW[c * NF + f] * s.feats[f];
      if (acc > best) { best = acc; bi = c; }
    }
    if (bi === s.y) ok++;
  }
  return samples.length ? ok / samples.length : 0;
}

function mkSamples(lines: LabeledLine[], head: 'role' | 'subject'): Sample[] {
  const list: readonly string[] = head === 'role' ? ROLES : SUBJECTS;
  return lines.map((l) => ({
    buckets: ngramBuckets(l.folded),
    feats: featsVec(l.feats),
    y: list.indexOf(head === 'role' ? l.role : l.subject),
    w: head === 'role' ? (ROLE_W[l.role] ?? 1) * (l.synthetic ? 4 : 1)
                       : (SUBJ_W[l.subject] ?? 1) * (l.synthetic ? 4 : 1),
    head,
  })).filter((s) => s.y >= 0);
}

// ------------------------------------------------------------------- quant

function quantBase64(arr: Float64Array, count: number): { b64: string; scale: number } {
  let maxAbs = 0;
  for (let i = 0; i < count; i++) maxAbs = Math.max(maxAbs, Math.abs(arr[i]));
  const scale = maxAbs / 127 || 1;
  const q = new Int8Array(count);
  for (let i = 0; i < count; i++) q[i] = Math.max(-127, Math.min(127, Math.round(arr[i] / scale)));
  return { b64: Buffer.from(q.buffer, 0, count).toString('base64'), scale };
}

function f32Base64(arr: number[]): string {
  const a = new Float32Array(arr);
  return Buffer.from(a.buffer).toString('base64');
}

// -------------------------------------------------------------------- main

function main() {
  const t0 = Date.now();
  const docs = loadCorpus();
  const real: LabeledLine[] = docs.flatMap((d) => d.lines);
  const synth = synthAnchors(9);
  const files = docs.map((d) => d.file);
  console.log(`corpus: ${docs.length} files, ${real.length} lines + ${synth.length} synthetic anchors`);

  // ---- CV (file-grouped; synthetics always train-side) ----
  const K = 5;
  const folds = fileGroupedFolds(files, K);
  const perRole = new Map<string, { tp: number; fp: number; fn: number }>();
  let cvOk = 0, cvN = 0;
  for (let k = 0; k < K; k++) {
    const trainReal = real.filter((l) => folds.get(l.file) !== k);
    const testReal = real.filter((l) => folds.get(l.file) === k);
    const rm = trainHead([...mkSamples([...trainReal, ...synth], 'role')], R, 14, 101 + k);
    for (const l of testReal) {
      const y = ROLES.indexOf(l.role);
      const pred = argmaxHead(rm, ngramBuckets(l.folded), featsVec(l.feats), R);
      cvN++;
      if (pred === y) cvOk++;
      for (let c = 0; c < R; c++) {
        const e = perRole.get(ROLES[c]) ?? { tp: 0, fp: 0, fn: 0 };
        if (pred === c && y === c) e.tp++;
        else if (pred === c) e.fp++;
        else if (y === c) e.fn++;
        perRole.set(ROLES[c], e);
      }
    }
  }
  const cvAccuracy = cvN ? cvOk / cvN : 0;
  const perRoleF1: Record<string, number> = {};
  for (const [role, e] of perRole) {
    const p = e.tp + e.fp ? e.tp / (e.tp + e.fp) : 0;
    const r = e.tp + e.fn ? e.tp / (e.tp + e.fn) : 0;
    perRoleF1[role] = p + r ? (2 * p * r) / (p + r) : 0;
  }
  console.log(`CV role accuracy (file-grouped ${K}-fold): ${(cvAccuracy * 100).toFixed(2)}%`);
  console.log('per-role F1:', Object.entries(perRoleF1).map(([k, v]) => `${k}=${v.toFixed(2)}`).join(' '));

  // ---- final models (all data) ----
  const roleModel = trainHead([...mkSamples([...real, ...synth], 'role')], R, 20, 4242);
  const subjModel = trainHead(mkSamples([...real, ...synth], 'subject'), S, 16, 8484);

  // ---- quantize + emit weights TS ----
  const NF = 11;
  const roleRows = [], roleScales = [], roleNumFlat: number[] = [], roleB: number[] = [];
  for (let c = 0; c < R; c++) {
    const row = roleModel.W.subarray(c * BUCKETS, (c + 1) * BUCKETS);
    const q = quantBase64(row as Float64Array, BUCKETS);
    roleRows.push(q.b64); roleScales.push(q.scale);
    for (let f = 0; f < NF; f++) roleNumFlat.push(roleModel.numW[c * NF + f]);
    roleB.push(roleModel.b[c]);
  }
  const subjRows = [], subjScales = [], subjNumFlat: number[] = [], subjB: number[] = [];
  for (let c = 0; c < S; c++) {
    const row = subjModel.W.subarray(c * BUCKETS, (c + 1) * BUCKETS);
    const q = quantBase64(row as Float64Array, BUCKETS);
    subjRows.push(q.b64); subjScales.push(q.scale);
    for (let f = 0; f < NF; f++) subjNumFlat.push(subjModel.numW[c * NF + f]);
    subjB.push(subjModel.b[c]);
  }

  const ts = `/**
 * specialistCodecWeights — GENERATED by scripts/specodec_train.mts. DO NOT EDIT.
 *
 * W1 SEMANTIC CODEC: two int8-quantized softmax heads (ROLE, SUBJECT) over
 * hashed char n-grams (FNV-1a, ${BUCKETS} buckets; 1-3 grams + whole words)
 * + ${NF} geometric features. Distilled from the deterministic perception
 * over the app-domain corpus + synthetic anchors (tail classes, corrupted
 * OCR-style text). Inference: src/utils/specialistCodec.ts (fail-safe).
 */
export const CODEC_WEIGHTS = {
  version: 1,
  buckets: ${BUCKETS},
  numFeats: ${NF},
  roles: ${JSON.stringify(ROLES)},
  subjects: ${JSON.stringify(SUBJECTS)},
  roleW: ${JSON.stringify(roleRows)},
  roleWScale: ${JSON.stringify(roleScales.map((s) => +s.toFixed(8)))},
  roleNumW: ${JSON.stringify(f32Base64(roleNumFlat))},
  roleB: ${JSON.stringify(roleB.map((v) => +v.toFixed(5)))},
  subjW: ${JSON.stringify(subjRows)},
  subjWScale: ${JSON.stringify(subjScales.map((s) => +s.toFixed(8)))},
  subjNumW: ${JSON.stringify(f32Base64(subjNumFlat))},
  subjB: ${JSON.stringify(subjB.map((v) => +v.toFixed(5)))},
  metrics: {
    cvAccuracy: ${cvAccuracy.toFixed(4)},
    perRoleF1: ${JSON.stringify(Object.fromEntries(Object.entries(perRoleF1).map(([k, v]) => [k, +v.toFixed(3)])))},
    files: ${docs.length},
    lines: ${real.length},
    anchors: ${synth.length},
    trainedMs: ${Date.now() - t0},
  },
} as const;
`;
  fs.writeFileSync(OUT_WEIGHTS, ts);

  const report = {
    what: 'W1 semantic codec — distilled per-line classifier (role+subject heads)',
    cvAccuracy, perRoleF1, files: docs.length, lines: real.length,
    anchors: synth.length, quantization: 'int8 per class row',
    weights: 'src/utils/specialistCodecWeights.ts',
    trainedAt: new Date().toISOString(),
    honestyNote: 'corpus metrics measure distillation fidelity vs the deterministic weak labeler; mangled-text robustness is measured by the eval probes',
  };
  fs.mkdirSync(path.dirname(OUT_REPORT), { recursive: true });
  fs.writeFileSync(OUT_REPORT, JSON.stringify(report, null, 2));
  console.log(`weights -> ${OUT_WEIGHTS} (${(fs.statSync(OUT_WEIGHTS).size / 1024).toFixed(0)} KB)`);
  console.log(`report  -> ${OUT_REPORT}`);
}

function argmaxHead(m: { W: Float64Array; numW: Float64Array; b: Float64Array }, buckets: Map<number, number>, feats: number[], classes: number): number {
  const NF = 11;
  let best = -Infinity, bi = 0;
  for (let c = 0; c < classes; c++) {
    let acc = m.b[c];
    const off = c * BUCKETS;
    for (const [bk, v] of buckets) acc += m.W[off + bk] * v;
    for (let f = 0; f < NF; f++) acc += m.numW[c * NF + f] * feats[f];
    if (acc > best) { best = acc; bi = c; }
  }
  return bi;
}

main();
