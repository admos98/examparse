/**
 * specstruct_eval — fresh-process validation for the W2 structure transformer.
 *
 * Measures:
 *  1. reference drift — the runtime forward must reproduce the trainer's
 *     canonical reference (computed FROM the quantized weights) within 1e-3
 *  2. corpus event accuracy vs the SAME weak event labels the trainer used
 *     (codec-PREDICTED tokens — the same realistic pipeline conditions)
 *  3. per-event F1 for section_start / row_start (the boundary signals)
 *  4. mangled-text stability — corrupted docs must yield stable boundaries
 *  5. fail-safe — corrupt weights validate to null, never throw
 *
 * Run: npx tsx scripts/specstruct_eval.mts   (exit 1 on any failure)
 */
import {
  structureReady, structureValidate, structureEvents, encodeToken, STRUCT_EVENTS,
} from '../src/utils/specialistStructure';
import { STRUCT_WEIGHTS } from '../src/utils/specialistStructureWeights';
import { codecClassify } from '../src/utils/specialistCodec';
import { ROLES, SUBJECTS, EVENTS, loadCorpus, corruptText } from './specialist_labels.mts';

let failures = 0;
const ok = (cond: boolean, label: string, detail = '') => {
  console.log(`  ${cond ? 'ok' : 'FAIL'}  ${label}${detail ? ' — ' + detail : ''}`);
  if (!cond) failures++;
};

function main() {
  console.log('== W2 structure transformer: fresh-process eval ==');
  const m = structureReady();
  ok(!!m, 'weights validate and load', m ? `d=${m.D}, L=${m.L}, ctx=${m.CTX}, ${STRUCT_EVENTS.length} events` : 'null');

  // ---- 1. reference drift (runtime forward vs trainer's quantized reference)
  {
    const probs = structureEvents(STRUCT_WEIGHTS.canonTokens);
    let maxDiff = 0;
    STRUCT_WEIGHTS.canonProbs.forEach((ref, i) => {
      const got = probs?.probs[i];
      if (!got) { maxDiff = 1; return; }
      for (let e = 0; e < STRUCT_EVENTS.length; e++) {
        const d = Math.abs((got[e] ?? 0) - ref[e]);
        if (d > maxDiff) maxDiff = d;
      }
    });
    ok(maxDiff <= 1e-3, 'canonical reference drift <= 1e-3', `max diff ${maxDiff.toExponential(2)}`);
  }

  // ---- 2+3. corpus event metrics (training-consistent weak labels) ----
  const docs = (() => {
    try { return loadCorpus(); } catch { return []; }
  })();
  if (!docs.length) {
    console.error('  (no corpus sidecars — see REGEN.md step A1: npx tsx scripts/brain_app_extract.mts <pdfDir>)');
    process.exit(2);
  }
  let evOk = 0, evN = 0;
  const perEvent: Record<string, { tp: number; fp: number; fn: number }> = {};
  // mangled stability state
  let mangleStable = 0, mangleN = 0;
  let seed = 77;
  let fileIdx = 0;
  for (const d of docs) {
    fileIdx++;
    if (!d.lines.length) continue;
    // encode via the predicted codec (identical to training conditions)
    const tokens = d.lines.map((l) => {
      const r = codecClassify(l.text, {
        size: l.size, bold: l.bold, bbox: l.bbox, pageW: 612, pageH: 792, bodySize: l.bodySize,
      });
      const roleIdx = r ? ROLES.indexOf(r.role as (typeof ROLES)[number]) : ROLES.indexOf('content');
      const subjIdx = r ? SUBJECTS.indexOf(r.subject as (typeof SUBJECTS)[number]) : 0;
      return encodeToken(Math.max(roleIdx, 0), Math.max(subjIdx, 0), l.feats.sizeBucket, l.bold);
    });
    const weak = d.lines.map((l) => EVENTS.indexOf(l.event));
    const res = structureEvents(tokens);
    if (!res) { ok(false, 'structureEvents returned null (model disabled?)'); break; }

    for (let i = 0; i < d.lines.length; i++) {
      const pred = res.events[i]?.event ?? 0;
      const y = weak[i];
      evN++;
      if (pred === y) evOk++;
      const key = STRUCT_EVENTS[pred], yy = STRUCT_EVENTS[y];
      perEvent[yy] = perEvent[yy] ?? { tp: 0, fp: 0, fn: 0 };
      perEvent[key] = perEvent[key] ?? { tp: 0, fp: 0, fn: 0 };
      if (pred === y) perEvent[yy].tp++;
      else { perEvent[key].fp++; perEvent[yy].fn++; }
    }

    // mangled stability on section_start positions — sample half the files
    if (fileIdx % 2 === 0) {
      seed = (seed * 48271) % 2147483647;
      const ctokens = d.lines.map((l, i) => {
        const r = codecClassify(corruptText(l.text, (seed + i) % 1000, 0.15), {
          size: l.size, bold: l.bold, bbox: l.bbox, pageW: 612, pageH: 792, bodySize: l.bodySize,
        });
        const roleIdx = r ? ROLES.indexOf(r.role as (typeof ROLES)[number]) : ROLES.indexOf('content');
        const subjIdx = r ? SUBJECTS.indexOf(r.subject as (typeof SUBJECTS)[number]) : 0;
        return encodeToken(Math.max(roleIdx, 0), Math.max(subjIdx, 0), l.feats.sizeBucket, l.bold);
      });
      const cres = structureEvents(ctokens);
      if (cres) {
        const clean = new Set(res.events.map((e, i) => (e.event === 1 ? i : -1)).filter((i) => i >= 0));
        const dirty = new Set(cres.events.map((e, i) => (e.event === 1 ? i : -1)).filter((i) => i >= 0));
        for (const i of clean) if (dirty.has(i)) mangleStable++;
        for (const i of dirty) if (clean.has(i)) mangleStable++;
        mangleN += clean.size + dirty.size;
      }
    }
  }

  const evAcc = evN ? evOk / evN : 0;
  console.log(`  corpus event accuracy (codec-predicted tokens): ${(evAcc * 100).toFixed(2)}% over ${evN} lines`);
  ok(evAcc >= 0.8, 'event accuracy >= 80%', `got ${(evAcc * 100).toFixed(1)}%`);
  for (const name of ['section_start', 'row_start']) {
    const e = perEvent[name] ?? { tp: 0, fp: 0, fn: 0 };
    const f1 = e.tp + e.fp && e.tp + e.fn ? (2 * e.tp) / (2 * e.tp + e.fp + e.fn) : 0;
    ok(f1 >= 0.55, `${name} F1 >= 0.55`, `got ${f1.toFixed(3)} (tp ${e.tp} fp ${e.fp} fn ${e.fn})`);
  }
  const mStab = mangleN ? mangleStable / mangleN : 0;
  console.log(`  mangled boundary stability: ${(mStab * 100).toFixed(1)}% over ${mangleN} boundary slots`);
  ok(mStab >= 0.6, 'mangled boundary stability >= 60%', `got ${(mStab * 100).toFixed(1)}%`);

  // ---- 5. fail-safe ----
  ok(structureValidate(null) === null, 'validate(null) -> null');
  ok(structureValidate({ version: 9 }) === null, 'validate(wrong version) -> null');
  ok(structureValidate({ ...STRUCT_WEIGHTS, layers: [] }) === null, 'validate(missing layers) -> null');
  ok(Array.isArray(STRUCT_EVENTS) && STRUCT_EVENTS.length === 6, 'event alphabet exported');

  console.log(failures === 0 ? '\n== specstruct_eval: ALL GREEN ==' : `\n== specstruct_eval: ${failures} FAILURE(S) ==`);
  process.exit(failures === 0 ? 0 : 1);
}

main();
