/**
 * specstruct_train — W2: train the tiny STRUCTURE TRANSFORMER.
 *
 * Sequences = codec-encoded lines (PREDICTED codec tokens — the model trains
 * under realistic pipeline conditions, codec errors included). Labels = the
 * weak structural events. Phase A trains on 80% of files and reports held-out
 * metrics; phase B continues on 100% for the shipped model. Weights are
 * int8-quantized per tensor; a canonical-sequence reference (computed FROM
 * the quantized weights) ships inside the weights blob so the runtime
 * forward math can be drift-checked exactly.
 *
 * Run: npx tsx scripts/specstruct_train.mts
 * Writes: src/utils/specialistStructureWeights.ts + scratch/specialist/struct-train-report.json
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { codecClassify } from '../src/utils/specialistCodec';
import {
  ROLES, SUBJECTS, loadCorpus, synthAnchors, LabeledLine,
} from './specialist_labels.mts';
import {
  initParams, forward, backward, zeroGrads, initAdam, adamStep, clipGrads,
  Params, GradSet, ForwardCache, D_MODEL, N_LAYERS, N_HEADS, FFN, CTX,
  COMBOS, BOS, PAD, VOCAB, EVENTS, N_EVENTS, encodeToken,
} from './specialist_net.mts';

const here = path.dirname(fileURLToPath(import.meta.url));
const OUT_WEIGHTS = path.join(here, '..', 'src', 'utils', 'specialistStructureWeights.ts');
const OUT_REPORT = path.join(here, '..', 'scratch', 'specialist', 'struct-train-report.json');

// token composition lives in specialist_net.mts (side-effect free module)

interface Seq { tokens: number[]; events: number[]; file: string }

function windowize(tokens: number[], events: number[], file: string): Seq[] {
  const out: Seq[] = [];
  if (!tokens.length) return out;
  for (let start = 0; start < tokens.length; start += 32) {
    const slice = tokens.slice(start, start + CTX - 1);
    const evs = events.slice(start, start + CTX - 1);
    const seq: Seq = {
      tokens: [BOS, ...slice, ...new Array(CTX - 1 - slice.length).fill(PAD)],
      events: [0, ...evs, ...new Array(CTX - 1 - evs.length).fill(0)],
      file,
    };
    out.push(seq);
    if (start + CTX - 1 >= tokens.length) break;
  }
  return out;
}

function encodeCorpusLines(lines: LabeledLine[]): { tokens: number[]; events: number[] } {
  const tokens: number[] = [];
  const events: number[] = [];
  for (const l of lines) {
    const r = codecClassify(l.text, {
      size: l.size, bold: l.bold, bbox: l.bbox, pageW: 612, pageH: 792, bodySize: l.bodySize,
    });
    const roleIdx = r ? ROLES.indexOf(r.role as (typeof ROLES)[number]) : ROLES.indexOf('content');
    const subjIdx = r ? SUBJECTS.indexOf(r.subject as (typeof SUBJECTS)[number]) : 0;
    tokens.push(encodeToken(Math.max(roleIdx, 0), Math.max(subjIdx, 0), l.feats.sizeBucket, l.bold));
    events.push(EVENTS.indexOf(l.event));
  }
  return { tokens, events };
}

/** doc-like synthetic sequences built from the labeled templates */
function synthSequences(): Seq[] {
  const anchors = synthAnchors(0); // clean templates only
  const byRole = new Map<string, LabeledLine[]>();
  for (const a of anchors) {
    const list = byRole.get(a.role) ?? [];
    list.push(a);
    byRole.set(a.role, list);
  }
  const pick = (role: string, i: number) => {
    const list = byRole.get(role) ?? [];
    return list[i % Math.max(list.length, 1)];
  };
  const docs: LabeledLine[][] = [];
  for (let d = 0; d < 24; d++) {
    const doc: LabeledLine[] = [];
    doc.push(pick('header_subject', d));
    doc.push(pick('instruction', d));
    for (let k = 0; k < 4; k++) doc.push(pick('content', d * 4 + k));
    doc.push(pick('row_opener', d));
    for (let k = 0; k < 3; k++) doc.push(pick('content', 20 + d * 3 + k));
    doc.push(pick('mark_token', d));
    doc.push(pick('option_line', d));
    if (d % 3 === 0) doc.push(pick('page_number', d));
    if (d % 4 === 0) doc.push(pick('furniture', d));
    doc.push(pick('total_line', d));
    doc.push(pick('key_boundary', d));
    for (let k = 0; k < 3; k++) doc.push(pick('key_row', d * 3 + k));
    docs.push(doc);
  }
  return docs.flatMap((doc, di) => {
    const tokens = doc.map((l) => encodeToken(ROLES.indexOf(l.role), SUBJECTS.indexOf(l.subject), l.feats.sizeBucket, l.bold));
    const events = doc.map((l) => EVENTS.indexOf(l.event));
    return windowize(tokens, events, `SYNTH-${di}`).map((w) => ({ ...w, file: 'SYNTH' }));
  });
}

// ------------------------------------------------------------- quantization

interface QTensor { data: string; scale: number }
function quantF64(arr: Float64Array): QTensor {
  let maxAbs = 0;
  for (let i = 0; i < arr.length; i++) maxAbs = Math.max(maxAbs, Math.abs(arr[i]));
  const scale = maxAbs / 127 || 1;
  const q = new Int8Array(arr.length);
  for (let i = 0; i < arr.length; i++) q[i] = Math.max(-127, Math.min(127, Math.round(arr[i] / scale)));
  return { data: Buffer.from(q.buffer, 0, arr.length).toString('base64'), scale: +scale.toFixed(10) };
}
function f32(arr: Float64Array | number[]): string {
  const a = arr instanceof Float64Array ? Float32Array.from(arr) : new Float32Array(arr);
  return Buffer.from(a.buffer).toString('base64');
}

// ------------------------------------------------------------------- main
// Two-phase for foreground runs within command timeouts:
//   npx tsx scripts/specstruct_train.mts --phase A   (grad-check + 80% train + val + checkpoint)
//   npx tsx scripts/specstruct_train.mts --phase B   (continue on 100% + quantize + emit)
function main() {
  const phase = (process.argv.find((a) => a.startsWith('--phase'))?.split('=')[1] ?? process.argv[process.argv.indexOf('--phase') + 1]) || 'A';
  const CHECKPOINT = path.join(here, '..', 'scratch', 'specialist', 'struct-checkpoint.json');
  const t0 = Date.now();
  console.log(`== specstruct_train (phase ${phase}) ==`);

  // ---- data ----
  const docs = loadCorpus();
  const files = docs.map((d) => d.file);
  const valFiles = new Set(files.filter((_, i) => i % 5 === 1)); // 20% held-out
  const seqs: Seq[] = [];
  const seqsVal: Seq[] = [];
  for (const d of docs) {
    const { tokens, events } = encodeCorpusLines(d.lines);
    const windows = windowize(tokens, events, d.file);
    if (valFiles.has(d.file)) seqsVal.push(...windows);
    else seqs.push(...windows);
  }
  const synth = synthSequences();
  seqs.push(...synth);
  console.log(`windows: train ${seqs.length} (incl ${synth.length} synth), val ${seqsVal.length}, ctx ${CTX}`);

  // ---- grad check ----
  const p = initParams(1234);
  const lossOf = (c: ForwardCache, toks: number[], evs: number[]): number => {
    let n = 0, s = 0;
    for (let i = 0; i < toks.length; i++) {
      if (toks[i] === PAD) continue;
      n++;
      const off = i * N_EVENTS;
      let max = -Infinity;
      for (let e = 0; e < N_EVENTS; e++) if (c.logits[off + e] > max) max = c.logits[off + e];
      let sum = 0;
      const pr = new Float64Array(N_EVENTS);
      for (let e = 0; e < N_EVENTS; e++) { pr[e] = Math.exp(c.logits[off + e] - max); sum += pr[e]; }
      for (let e = 0; e < N_EVENTS; e++) pr[e] /= sum;
      s += -Math.log(Math.max(pr[evs[i]], 1e-12));
    }
    return s / n;
  };
  {
    const tiny = seqs[0];
    const cache: ForwardCache = { T: 0, tokens: [], x0: new Float64Array(0), lnInHat: new Float64Array(0), xhat0: new Float64Array(0), std0: new Float64Array(0), layers: [], logits: new Float64Array(0) };
    forward(p, tiny.tokens, cache);
    const g: GradSet = zeroGrads(p);
    backward(p, cache, tiny.events, g);
    // finite diff on 12 random positions
    let st = 99;
    const rnd = () => (st = (st * 48271) % 2147483647) / 2147483647;
    const tensors: [Float64Array, Float64Array][] = [
      [p.E, g.E], [p.P, g.P], [p.Wh, g.Wh],
      [p.layers[0].Wq, g.layers[0].Wq], [p.layers[1].W2, g.layers[1].W2],
      [p.lnIn.g, g.lnIn.g],
    ];
    let maxRel = 0;
    // probe the LARGEST-|analytic-grad| parameter per tensor group (random
    // indices sit on tiny gradients where finite-diff relative error is noise)
    for (const [tArr, gArr] of tensors) {
      let idx = 0, best = 0;
      for (let i = 0; i < gArr.length; i++) if (Math.abs(gArr[i]) > best) { best = Math.abs(gArr[i]); idx = i; }
      const eps = 1e-5;
      const orig = tArr[idx];
      const c1: ForwardCache = { T: 0, tokens: [], x0: new Float64Array(0), lnInHat: new Float64Array(0), xhat0: new Float64Array(0), std0: new Float64Array(0), layers: [], logits: new Float64Array(0) };
      const c2: ForwardCache = { T: 0, tokens: [], x0: new Float64Array(0), lnInHat: new Float64Array(0), xhat0: new Float64Array(0), std0: new Float64Array(0), layers: [], logits: new Float64Array(0) };
      tArr[idx] = orig + eps;
      forward(p, tiny.tokens, c1);
      const l1 = lossOf(c1, tiny.tokens, tiny.events);
      tArr[idx] = orig - eps;
      forward(p, tiny.tokens, c2);
      const l2 = lossOf(c2, tiny.tokens, tiny.events);
      tArr[idx] = orig;
      const num = (l1 - l2) / (2 * eps);
      const ana = gArr[idx];
      const rel = Math.abs(num - ana) / Math.max(Math.abs(num), Math.abs(ana), 1e-8);
      maxRel = Math.max(maxRel, rel);
    }
    console.log(`grad-check max rel err: ${maxRel.toExponential(2)}`);
    if (maxRel > 3e-2) {
      console.error('FATAL: gradient check failed — backward math is wrong');
      process.exit(2);
    }
  }

  // ---- phase A: 80% train / 20% val ----
  let params: Params;
  const adamState = { ref: null as null | ReturnType<typeof initAdam> };
  if (phase.toUpperCase().startsWith('A')) {
    params = initParams(4242);
    const adam = initAdam(params);
    adamState.ref = adam;
    const EPOCHS_A = 16;
    for (let ep = 0; ep < EPOCHS_A; ep++) {
    let order = seqs.map((_, i) => i);
    for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
    let epLoss = 0, steps = 0;
    for (let b = 0; b < order.length; b += 4) {
      const batch = order.slice(b, b + 4);
      const g = zeroGrads(params);
      let loss = 0;
      for (const idx of batch) {
        const cache: ForwardCache = { T: 0, tokens: [], x0: new Float64Array(0), lnInHat: new Float64Array(0), xhat0: new Float64Array(0), std0: new Float64Array(0), layers: [], logits: new Float64Array(0) };
        forward(params, seqs[idx].tokens, cache);
        loss += backward(params, cache, seqs[idx].events, g);
      }
      clipGrads(g, 5);
      adamStep(params, g, adam, 8e-4 * (1 / (1 + ep * 0.15)));
      epLoss += loss / batch.length;
      steps++;
      if (ep % 4 === 0 || ep === EPOCHS_A - 1) {
        const val = evaluate(params, seqsVal);
        console.log(`ep ${ep}: loss ${(epLoss / steps).toFixed(4)} | val acc ${(val.acc * 100).toFixed(1)}% secF1 ${val.secF1.toFixed(2)} rowF1 ${val.rowF1.toFixed(2)} (${Date.now() - t0}ms)`);
      }
    }
    }
    const valFinal = evaluate(params, seqsVal);
    console.log(`PHASE A held-out: acc ${(valFinal.acc * 100).toFixed(2)}% | section_start F1 ${valFinal.secF1.toFixed(3)} | row_start F1 ${valFinal.rowF1.toFixed(3)}`);
    if (valFinal.acc < 0.5) console.warn('WARNING: held-out event accuracy < 0.5 — inspect before shipping');
    // checkpoint params + adam for phase B
    const ser = (a: Float64Array) => Buffer.from(Float64Array.from(a).buffer).toString('base64');
    fs.mkdirSync(path.dirname(CHECKPOINT), { recursive: true });
    fs.writeFileSync(CHECKPOINT, JSON.stringify({
      phaseA: valFinal,
      E: ser(params.E), P: ser(params.P),
      lnInG: ser(params.lnIn.g), lnInB: ser(params.lnIn.b),
      layers: params.layers.map((L) => ({
        Wq: ser(L.Wq), bq: ser(L.bq), Wk: ser(L.Wk), bk: ser(L.bk),
        Wv: ser(L.Wv), bv: ser(L.bv), Wo: ser(L.Wo), bo: ser(L.bo),
        W1: ser(L.W1), b1: ser(L.b1), W2: ser(L.W2), b2: ser(L.b2),
        ln1g: ser(L.ln1.g), ln1b: ser(L.ln1.b), ln2g: ser(L.ln2.g), ln2b: ser(L.ln2.b),
      })),
      Wh: ser(params.Wh), bh: ser(params.bh),
      adamM: {
        E: ser(adam.m.E), P: ser(adam.m.P),
        lnInG: ser(adam.m.lnIn.g), lnInB: ser(adam.m.lnIn.b),
        layers: adam.m.layers.map((L) => ({
          Wq: ser(L.Wq), bq: ser(L.bq), Wk: ser(L.Wk), bk: ser(L.bk),
          Wv: ser(L.Wv), bv: ser(L.bv), Wo: ser(L.Wo), bo: ser(L.bo),
          W1: ser(L.W1), b1: ser(L.b1), W2: ser(L.W2), b2: ser(L.b2),
          ln1g: ser(L.ln1.g), ln1b: ser(L.ln1.b), ln2g: ser(L.ln2.g), ln2b: ser(L.ln2.b),
        })),
        Wh: ser(adam.m.Wh), bh: ser(adam.m.bh),
      },
      adamV: {
        E: ser(adam.v.E), P: ser(adam.v.P),
        lnInG: ser(adam.v.lnIn.g), lnInB: ser(adam.v.lnIn.b),
        layers: adam.v.layers.map((L) => ({
          Wq: ser(L.Wq), bq: ser(L.bq), Wk: ser(L.Wk), bk: ser(L.bk),
          Wv: ser(L.Wv), bv: ser(L.bv), Wo: ser(L.Wo), bo: ser(L.bo),
          W1: ser(L.W1), b1: ser(L.b1), W2: ser(L.W2), b2: ser(L.b2),
          ln1g: ser(L.ln1.g), ln1b: ser(L.ln1.b), ln2g: ser(L.ln2.g), ln2b: ser(L.ln2.b),
        })),
        Wh: ser(adam.v.Wh), bh: ser(adam.v.bh),
      },
      adamT: adam.t,
    }));
    console.log(`checkpoint -> ${CHECKPOINT}`);
    console.log('phase A complete — run --phase B next');
    return;
  }

  // ---- phase B: load checkpoint, continue on 100% ----
  {
    const ck = JSON.parse(fs.readFileSync(CHECKPOINT, 'utf8'));
    const de = (b64: string): Float64Array => {
      const buf = Buffer.from(b64, 'base64');
      return new Float64Array(buf.buffer, buf.byteOffset, buf.length / 8).slice();
    };
    params = {
      E: de(ck.E), P: de(ck.P), lnIn: { g: de(ck.lnInG), b: de(ck.lnInB) },
      layers: ck.layers.map((L: any) => ({
        Wq: de(L.Wq), bq: de(L.bq), Wk: de(L.Wk), bk: de(L.bk),
        Wv: de(L.Wv), bv: de(L.bv), Wo: de(L.Wo), bo: de(L.bo),
        W1: de(L.W1), b1: de(L.b1), W2: de(L.W2), b2: de(L.b2),
        ln1: { g: de(L.ln1g), b: de(L.ln1b) },
        ln2: { g: de(L.ln2g), b: de(L.ln2b) },
      })),
      Wh: de(ck.Wh), bh: de(ck.bh),
    };
    const mkAdamSide = (side: any) => ({
      E: de(side.E), P: de(side.P), lnIn: { g: de(side.lnInG), b: de(side.lnInB) },
      layers: side.layers.map((L: any) => ({
        Wq: de(L.Wq), bq: de(L.bq), Wk: de(L.Wk), bk: de(L.bk),
        Wv: de(L.Wv), bv: de(L.bv), Wo: de(L.Wo), bo: de(L.bo),
        W1: de(L.W1), b1: de(L.b1), W2: de(L.W2), b2: de(L.b2),
        ln1: { g: de(L.ln1g), b: de(L.ln1b) },
        ln2: { g: de(L.ln2g), b: de(L.ln2b) },
      })),
      Wh: de(side.Wh), bh: de(side.bh),
    });
    const adam = { m: mkAdamSide(ck.adamM) as GradSet, v: mkAdamSide(ck.adamV) as GradSet, t: ck.adamT };
    const valFinal = ck.phaseA as { acc: number; secF1: number; rowF1: number };
    void adamState;
    const all = [...seqs, ...seqsVal];
    const EPOCHS_B = 10;
    for (let ep = 0; ep < EPOCHS_B; ep++) {
    let order = all.map((_, i) => i);
    for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
    let epLoss = 0, steps = 0;
    for (let b = 0; b < order.length; b += 4) {
      const batch = order.slice(b, b + 4);
      const g = zeroGrads(params);
      let loss = 0;
      for (const idx of batch) {
        const cache: ForwardCache = { T: 0, tokens: [], x0: new Float64Array(0), lnInHat: new Float64Array(0), xhat0: new Float64Array(0), std0: new Float64Array(0), layers: [], logits: new Float64Array(0) };
        forward(params, all[idx].tokens, cache);
        loss += backward(params, cache, all[idx].events, g);
      }
      clipGrads(g, 5);
      adamStep(params, g, adam, 5e-4 / (1 + ep * 0.2));
      epLoss += loss / batch.length;
      steps++;
    }
    if (ep % 3 === 0 || ep === EPOCHS_B - 1) console.log(`B ep ${ep}: loss ${(epLoss / steps).toFixed(4)} (${Date.now() - t0}ms)`);
  }
  const allFinal = evaluate(params, all);
  console.log(`PHASE B full-fit: acc ${(allFinal.acc * 100).toFixed(2)}% | secF1 ${allFinal.secF1.toFixed(3)} | rowF1 ${allFinal.rowF1.toFixed(3)}`);

  // ---- quantize + reference outputs ----
  const q = {
    E: quantF64(params.E), P: quantF64(params.P),
    lnInG: f32(params.lnIn.g), lnInB: f32(params.lnIn.b),
    layers: params.layers.map((L) => ({
      Wq: quantF64(L.Wq), bq: f32(L.bq), Wk: quantF64(L.Wk), bk: f32(L.bk),
      Wv: quantF64(L.Wv), bv: f32(L.bv), Wo: quantF64(L.Wo), bo: f32(L.bo),
      W1: quantF64(L.W1), b1: f32(L.b1), W2: quantF64(L.W2), b2: f32(L.b2),
      ln1g: f32(L.ln1.g), ln1b: f32(L.ln1.b), ln2g: f32(L.ln2.g), ln2b: f32(L.ln2.b),
    })),
    Wh: quantF64(params.Wh), bh: f32(params.bh),
  };
  // canonical reference: quantized-decoded weights forward on a fixed sequence
  const qp = decodeQuant(q);
  const CANON = [BOS,
    encodeToken(ROLES.indexOf('header_subject'), SUBJECTS.indexOf('grammar'), 3, true),
    encodeToken(ROLES.indexOf('instruction'), 0, 0, false),
    encodeToken(ROLES.indexOf('content'), 0, 0, false),
    encodeToken(ROLES.indexOf('row_opener'), 0, 0, true),
    encodeToken(ROLES.indexOf('content'), 0, 0, false),
    encodeToken(ROLES.indexOf('content'), 0, 0, false),
    encodeToken(ROLES.indexOf('mark_token'), 0, 0, true),
    encodeToken(ROLES.indexOf('row_opener_numeric'), SUBJECTS.indexOf('vocabulary'), 0, true),
    encodeToken(ROLES.indexOf('total_line'), 0, 1, true),
    encodeToken(ROLES.indexOf('key_boundary'), 0, 1, true),
    encodeToken(ROLES.indexOf('key_row'), 0, 0, false),
  ];
  const cRef: ForwardCache = { T: 0, tokens: [], x0: new Float64Array(0), lnInHat: new Float64Array(0), xhat0: new Float64Array(0), std0: new Float64Array(0), layers: [], logits: new Float64Array(0) };
  forward(qp, CANON, cRef);
  const refProbs: number[][] = [];
  // align to canonTokens EXCLUDING the BOS position: refProbs[i] is the
  // distribution for canonTokens[i] (BOS sits at window position 0 only)
  for (let i = 1; i < CANON.length; i++) {
    const off = i * N_EVENTS;
    let max = -Infinity;
    for (let e = 0; e < N_EVENTS; e++) if (cRef.logits[off + e] > max) max = cRef.logits[off + e];
    let sum = 0;
    const pr = new Float64Array(N_EVENTS);
    for (let e = 0; e < N_EVENTS; e++) { pr[e] = Math.exp(cRef.logits[off + e] - max); sum += pr[e]; }
    refProbs.push(Array.from(pr, (v) => +(v / sum).toFixed(5)));
  }

  // ---- emit ----
  const ts = `/**
 * specialistStructureWeights — GENERATED by scripts/specstruct_train.mts. DO NOT EDIT.
 *
 * W2 STRUCTURE TRANSFORMER: a causal decoder (d=${D_MODEL}, ${N_LAYERS} layers,
 * ${N_HEADS} heads, FFN ${FFN}, ctx ${CTX}) over codec-symbol tokens
 * (role x subject x sizeBucket x bold = ${COMBOS} combos + BOS/PAD) predicting
 * per-line structural events. Trained on codec-encoded app-domain corpus +
 * synthetic doc sequences. Inference: src/utils/specialistStructure.ts.
 * The canonical reference comes FROM the quantized weights — the runtime
 * forward must reproduce it (drift guard, eval asserts <= 1e-3).
 */
export const STRUCT_WEIGHTS = {
  version: 1,
  dModel: ${D_MODEL}, nLayers: ${N_LAYERS}, nHeads: ${N_HEADS}, ffn: ${FFN},
  ctx: ${CTX}, combos: ${COMBOS}, bos: ${BOS}, pad: ${PAD}, vocab: ${VOCAB},
  events: ${JSON.stringify(EVENTS)},
  E: { data: '${q.E.data}', scale: ${q.E.scale} },
  P: { data: '${q.P.data}', scale: ${q.P.scale} },
  lnInG: '${q.lnInG}', lnInB: '${q.lnInB}',
  layers: ${JSON.stringify(q.layers)},
  Wh: { data: '${q.Wh.data}', scale: ${q.Wh.scale} },
  bh: '${q.bh}',
  canonTokens: ${JSON.stringify(CANON.slice(1))},
  canonProbs: ${JSON.stringify(refProbs)},
  metrics: {
    valAcc: ${valFinal.acc.toFixed(4)},
    valSecF1: ${valFinal.secF1.toFixed(4)},
    valRowF1: ${valFinal.rowF1.toFixed(4)},
    trainWindows: ${seqs.length + seqsVal.length},
    trainedMs: ${Date.now() - t0},
  },
} as const;
`;
  fs.writeFileSync(OUT_WEIGHTS, ts);
  const report = {
    what: 'W2 structure transformer over codec tokens (predicted-codec training conditions)',
    phaseA: valFinal, phaseB: allFinal,
    windows: { train: seqs.length, val: seqsVal.length },
    weights: 'src/utils/specialistStructureWeights.ts',
    trainedAt: new Date().toISOString(),
    honestyNote: 'held-out metrics are vs the weak event labels on codec-PREDICTED tokens (end-to-end realistic); canonical reference pins runtime forward math to the quantized weights',
  };
  fs.mkdirSync(path.dirname(OUT_REPORT), { recursive: true });
  fs.writeFileSync(OUT_REPORT, JSON.stringify(report, null, 2));
  console.log(`weights -> ${OUT_WEIGHTS} (${(fs.statSync(OUT_WEIGHTS).size / 1024).toFixed(0)} KB)`);
  console.log(`report  -> ${OUT_REPORT}`);
  }
}

function evaluate(params: Params, seqs: Seq[]): { acc: number; secF1: number; rowF1: number } {
  let ok = 0, n = 0;
  let secTp = 0, secFp = 0, secFn = 0, rowTp = 0, rowFp = 0, rowFn = 0;
  const cache: ForwardCache = { T: 0, tokens: [], x0: new Float64Array(0), lnInHat: new Float64Array(0), xhat0: new Float64Array(0), std0: new Float64Array(0), layers: [], logits: new Float64Array(0) };
  for (const s of seqs) {
    forward(params, s.tokens, cache);
    for (let i = 1; i < s.tokens.length; i++) {
      if (s.tokens[i] === PAD) continue;
      const off = i * N_EVENTS;
      let bi = 0, bv = -Infinity;
      for (let e = 0; e < N_EVENTS; e++) if (cache.logits[off + e] > bv) { bv = cache.logits[off + e]; bi = e; }
      const y = s.events[i];
      n++;
      if (bi === y) ok++;
      if (bi === 1 && y === 1) secTp++; else if (bi === 1) secFp++; else if (y === 1) secFn++;
      if (bi === 2 && y === 2) rowTp++; else if (bi === 2) rowFp++; else if (y === 2) rowFn++;
    }
  }
  const f1 = (tp: number, fp: number, fn: number) => (tp + fp && tp + fn) ? (2 * tp) / (2 * tp + fp + fn) : 0;
  return { acc: n ? ok / n : 0, secF1: f1(secTp, secFp, secFn), rowF1: f1(rowTp, rowFp, rowFn) };
}

/** decode a quantized weight set back into float64 Params (mirror of runtime) */
function decodeQuant(q: any): Params {
  const deq = (t: { data: string; scale: number }): Float64Array => {
    const bytes = Buffer.from(t.data, 'base64');
    const i8 = new Int8Array(bytes.buffer, bytes.byteOffset, bytes.length);
    const out = new Float64Array(i8.length);
    for (let i = 0; i < i8.length; i++) out[i] = i8[i] * t.scale;
    return out;
  };
  const f32d = (b64: string): Float64Array => {
    const buf = Buffer.from(b64, 'base64');
    // Buffer may slice from a shared pool — byteOffset MUST be respected
    return Float64Array.from(new Float32Array(buf.buffer, buf.byteOffset, buf.length / 4));
  };
  const p: Params = {
    E: deq(q.E), P: deq(q.P),
    lnIn: { g: f32d(q.lnInG), b: f32d(q.lnInB) },
    layers: q.layers.map((L: any) => ({
      Wq: deq(L.Wq), bq: f32d(L.bq), Wk: deq(L.Wk), bk: f32d(L.bk),
      Wv: deq(L.Wv), bv: f32d(L.bv), Wo: deq(L.Wo), bo: f32d(L.bo),
      W1: deq(L.W1), b1: f32d(L.b1), W2: deq(L.W2), b2: f32d(L.b2),
      ln1: { g: f32d(L.ln1g), b: f32d(L.ln1b) },
      ln2: { g: f32d(L.ln2g), b: f32d(L.ln2b) },
    })),
    Wh: deq(q.Wh), bh: f32d(q.bh),
  };
  return p;
}

main();
