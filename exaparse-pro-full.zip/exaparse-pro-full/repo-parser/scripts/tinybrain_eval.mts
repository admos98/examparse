/**
 * tinybrain_eval — post-train validation for the G6 tiny brain layer.
 * MUST run in a fresh process (the weights module is loaded once at import).
 *
 * Reports, over the whole 47-file app-domain corpus:
 *   - model verdict mix: upgrades / downgrades / mild dissents (receipt notes)
 *   - per-file drive-posture changes vs the hand brain (which files would
 *     drive before but not now, and vice versa) — the gate-relevant delta
 *   - the S27 furniture probe: a synthetic junk section the HAND scorer
 *     confirms (rule + generic header + one content line) must be VETOED by
 *     the model (p < downgradeBelow)
 *
 * Run: npx tsx scripts/tinybrain_eval.mts
 */
import fs from 'node:fs';
import path from 'node:path';
import { runLayoutBrain, BrainDoc } from '../src/utils/layoutBrain';
import { getTinyWeights, tinyBrainScore } from '../src/utils/tinyBrain';
import { PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2');

const drivePosture = (doc: BrainDoc) => {
  const res = runLayoutBrain(doc);
  const all = [...res.sections];
  const confirmed = all.filter((s) => s.confirmed && !s.demoted).length;
  const fallbacks = res.fallbacks.length;
  const allConfirmed = fallbacks === 0 && all.length > 0;
  const contentLines = res.lines.length;
  const covered = all
    .filter((s) => s.confirmed && !s.demoted)
    .reduce((n, s) => n + s.lines.length, 0);
  const coverage = contentLines ? covered / contentLines : 0;
  return { res, allConfirmed, coverage, confirmed, fallbacks };
};

function main() {
  const w = getTinyWeights();
  if (!w) {
    console.error('(tinybrain_eval: model DISABLED — no valid weights shipped. Run scripts/tinybrain_train.mts first.)');
    process.exit(1);
  }
  console.log(`weights: ${w.dataset.positives} pos / ${w.dataset.negatives} neg over ${w.dataset.files} files, CV acc ${(w.metrics.cvAccuracy * 100).toFixed(1)}%, AUC ${w.metrics.cvAuc.toFixed(3)}`);

  if (!fs.existsSync(BRAIN_DIR)) {
    console.error(`(tinybrain_eval: no corpus sidecars at ${BRAIN_DIR}.)`);
    console.error('  Rebuild them first from your PDFs — see REGEN.md step A1:');
    console.error('    npx tsx scripts/brain_app_extract.mts <pdfDir>');
    process.exit(2);
  }
  const files = fs.readdirSync(BRAIN_DIR).filter((f) => f.endsWith('.json')).sort();
  let up = 0, down = 0, mild = 0;
  let postureChanges = 0;
  for (const f of files) {
    const doc = JSON.parse(fs.readFileSync(path.join(BRAIN_DIR, f), 'utf8')) as BrainDoc;
    const hand = drivePosture({ ...doc, file: doc.file });
    const model = drivePosture(doc);
    const st = { up: 0, down: 0, mild: 0 };
    for (const s of [...model.res.sections, ...model.res.fallbacks]) {
      for (const note of s.notes) {
        if (note.includes('ml upgrade')) st.up++;
        else if (note.includes('ml downgrade')) st.down++;
        else if (note.includes('ml mild-dissent')) st.mild++;
      }
    }
    up += st.up; down += st.down; mild += st.mild;
    const handDrive = hand.allConfirmed && hand.coverage >= 0.6;
    const modelDrive = model.allConfirmed && model.coverage >= 0.6;
    if (handDrive !== modelDrive) {
      postureChanges++;
      console.log(`  DRIVE CHANGE ${f}: hand=${handDrive ? 'drive' : 'abstain'} -> model=${modelDrive ? 'drive' : 'abstain'}`);
    }
    if (st.up || st.down || st.mild) {
      console.log(`  ${f}: +${st.up} up / -${st.down} down / ~${st.mild} mild`);
    }
  }
  console.log(`\ntotals: ${up} upgrades, ${down} downgrades, ${mild} mild dissents, ${postureChanges} drive-posture changes`);

  // S27 furniture probe: the hand scorer CONFIRMS this shape (0.55 rule base
  // + 0.2 generic header = 0.75); the trained model must veto it.
  const junk = {
    index: 0,
    pageStart: 0,
    pageEnd: 0,
    boundaryKind: 'rule',
    lines: [{ text: 'some footer tail', size: 12, bold: false, bbox: [60, 700, 400, 712], page: 0 }],
    rows: [],
    evidence: { header: true, letter: false, mark: false, table: false, rules: true, ladder: 0, boxes: 0 },
    notes: [],
  } as any;
  const ctx = { bodySize: 12, pageCount: 2, contentLines: 40 };
  const sc = tinyBrainScore(junk, ctx);
  const p = sc ? sc.p : -1;
  console.log(`\nS27 furniture probe: model p=${p.toFixed(3)} (hand 0.75) -> ${p >= 0 && p < w.thresholds.downgradeBelow ? 'VETOED (downgrade tail works)' : p < 0 ? 'model disabled' : 'NOT vetoed — needs retraining/anchors'}`);
  process.exit(p >= 0 && p < w.thresholds.downgradeBelow ? 0 : 2);
}

main();
