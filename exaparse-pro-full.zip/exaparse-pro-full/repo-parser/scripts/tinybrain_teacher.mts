/**
 * tinybrain_teacher — DEV-ONLY teacher labeling for the G6 tiny brain layer.
 *
 * ⚠️  THIS FILE IS EXCLUDED FROM THE SHIPPED BUNDLE (scripts/bundle_fixed*.sh).
 * It is the "teacher network" of the teacher/student split: it optionally uses
 * a REMOTE LLM — through the SAME selectable-provider system the app itself
 * uses (gemini | openai | openrouter | vercel | ollama | custom, YOUR key,
 * ollama = fully local) — to label the AMBIGUOUS boundary candidates that the
 * distillation labels are least trustworthy on. The shipped app never calls
 * this; inference stays 100% local (28-weight logistic + Platt).
 *
 * Labels land in scratch/tinybrain/teacher-labels.json, which
 * scripts/tinybrain_train.mts merges with weight 3x (highest trust).
 *
 * Provider resolution (dev only):
 *   TEACHER_PROVIDER  gemini|openai|openrouter|vercel|ollama|custom (default gemini)
 *   TEACHER_MODEL     exact model slug (default per provider)
 *   GEMINI_API_KEY / OPENAI_API_KEY / OPENROUTER_API_KEY   — first present wins
 *   OLLAMA needs no key (local server on :11434)
 *
 * Without any key the script exits 0 with a note (nothing breaks offline).
 *
 * Run: npx tsx scripts/tinybrain_teacher.mts
 */
import fs from 'node:fs';
import path from 'node:path';
import { runLayoutBrain, BrainDoc } from '../src/utils/layoutBrain';
import { executeAIRequest } from '../src/server/aiProvider';
import type { ProviderConfig } from '../src/types/settings';
import { PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2');
const OUT_JSON = path.join(PKG_ROOT, 'scratch', 'tinybrain', 'teacher-labels.json');
const BAND_LO = 0.35; // label only where distillation is unreliable
const BAND_HI = 0.85;
const MAX_PER_FILE = 12;

const PROVIDER_DEFAULT_MODELS: Record<string, string> = {
  gemini: 'gemini-2.5-flash',
  openai: 'gpt-4o-mini',
  openrouter: 'deepseek/deepseek-chat',
  vercel: 'openai/gpt-4o-mini',
  ollama: 'llama3:latest',
  custom: 'gpt-4o-mini',
};

interface Item {
  id: string;
  file: string;
  page: number;
  textPrefix: string;
  kind: string;
  subject?: string;
  confidence: number;
  context: string[];
}

function main() {
  const provider = (process.env.TEACHER_PROVIDER || 'gemini').toLowerCase();
  const apiKey =
    process.env.GEMINI_API_KEY ||
    process.env.OPENAI_API_KEY ||
    process.env.OPENROUTER_API_KEY ||
    '';
  if (provider !== 'ollama' && !apiKey) {
    console.log(
      '(tinybrain_teacher: no provider key in env — teacher labeling skipped. ' +
        'Set GEMINI_API_KEY / OPENAI_API_KEY / OPENROUTER_API_KEY or TEACHER_PROVIDER=ollama. ' +
        'The trainer works without it; labels only sharpen the uncertain band.)'
    );
    return;
  }
  const model = process.env.TEACHER_MODEL || PROVIDER_DEFAULT_MODELS[provider] || 'gemini-2.5-flash';
  const providerConfig: ProviderConfig = {
    provider: provider as ProviderConfig['provider'],
    model,
    apiKey,
    temperature: 0,
    maxTokens: 4096,
  };

  const files = fs.readdirSync(BRAIN_DIR).filter((f) => f.endsWith('.json')).sort();
  const items: Item[] = [];
  for (const f of files) {
    const doc = JSON.parse(fs.readFileSync(path.join(BRAIN_DIR, f), 'utf8')) as BrainDoc;
    const res = runLayoutBrain(doc, { debug: true, tinyModel: false });
    const cands = (res.__debug?.candidates ?? []).filter((c) => c.confidence >= BAND_LO && c.confidence <= BAND_HI);
    for (const c of cands.slice(0, MAX_PER_FILE)) {
      // context = the candidate's own first lines + neighbors from the result lines
      const pageLines = res.lines.filter((l) => l.page === c.page);
      const startIdx = pageLines.findIndex((l) => l.text === c.firstText);
      items.push({
        id: `${f}#${c.index}`,
        file: f,
        page: c.page,
        textPrefix: (c.firstText ?? '').trim().slice(0, 40),
        kind: c.boundaryKind ?? 'unknown',
        subject: c.subject,
        confidence: Number(c.confidence.toFixed(2)),
        context: pageLines.slice(Math.max(0, startIdx - 1), Math.max(0, startIdx - 1) + 6).map((l) => l.text.slice(0, 120)),
      });
    }
  }
  if (!items.length) {
    console.log('(tinybrain_teacher: no ambiguous candidates in the labeling band — nothing to teach)');
    return;
  }
  console.log(`labeling ${items.length} ambiguous candidates via ${provider}:${model} ...`);

  const system =
    'You label exam-page boundary candidates for a document-layout parser. ' +
    'Each candidate starts a proposed SECTION on the given page; the context lines are printed document text near the candidate. ' +
    'Decide whether it truly begins a distinct exam SECTION (a titled part like Vocabulary/Grammar/Listening, a lettered row group with marks, a numbered part) ' +
    'or is NOT a section start (running question text, footer/header furniture, a page number, an answer-key fragment, an option line, an instruction). ' +
    'Reply with STRICT JSON: {"labels":[{"id":string,"verdict":"section"|"not-section","reason":string}]} — one entry per input id, no prose.';
  const user = JSON.stringify(
    items.map((it) => ({ id: it.id, kind: it.kind, subject: it.subject ?? null, handConfidence: it.confidence, context: it.context })),
    null,
    1
  );

  executeAIRequest({ systemPrompt: system, userPrompt: user, jsonMode: true, providerConfig, maxAttempts: 2 })
    .then((resp) => {
      const parsed = resp.parsedJson as { labels?: Array<{ id: string; verdict: string; reason?: string }> };
      const labels = parsed?.labels ?? [];
      const byId = new Map(labels.map((l) => [l.id, l]));
      const out: Array<{ file: string; page: number; textPrefix: string; label: number; reason: string; model: string }> = [];
      for (const it of items) {
        const v = byId.get(it.id);
        if (!v) continue;
        out.push({
          file: it.file,
          page: it.page,
          textPrefix: it.textPrefix,
          label: v.verdict === 'section' ? 1 : 0,
          reason: (v.reason ?? '').slice(0, 200),
          model,
        });
      }
      fs.mkdirSync(path.dirname(OUT_JSON), { recursive: true });
      fs.writeFileSync(OUT_JSON, JSON.stringify(out, null, 2));
      console.log(`teacher labels written: ${out.length}/${items.length} -> ${OUT_JSON}`);
      console.log('next: npx tsx scripts/tinybrain_train.mts   (teacher labels merge at weight 3x)');
    })
    .catch((err) => {
      console.error(`(tinybrain_teacher: provider call failed — ${err?.message ?? err})`);
      process.exit(1);
    });
}

main();
