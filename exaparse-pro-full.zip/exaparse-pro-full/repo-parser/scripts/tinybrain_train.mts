/**
 * tinybrain_train — DEV-ONLY trainer for the G6 tiny learned brain layer.
 *
 * What it does (fully local, zero ML dependencies — plain TS gradient descent):
 *   1. Runs the HAND brain (tinyModel:false) over every app-domain sidecar
 *      (scratch/brain-app-qu2) and labels each boundary candidate from the
 *      hand verdict: confirmed -> positive, fallback -> negative. This
 *      distills the corpus-proven hand fusion (1 better / 0 worse / 31 ties)
 *      into a smooth learned function.
 *   2. Adds SYNTHETIC ANCHOR labels (weight 2x) for the arbiter tails:
 *      furniture textures the hand scorer over-values (rule + generic header
 *      + tiny content) must score LOW; coherent structures must score HIGH.
 *      These are the cases a fixed additive rule cannot represent but a
 *      learned weight vector can.
 *   3. Merges dev-only TEACHER labels (scratch/tinybrain/teacher-labels.json,
 *      produced by tinybrain_teacher.mts through the user's own selectable
 *      provider) when present — highest weight, overrides weak labels.
 *   4. Fits logistic regression + Platt calibration with file-grouped 5-fold
 *      CV (no file leakage), then WRITES src/utils/tinyBrainWeights.ts and a
 *      provenance report (scratch/tinybrain/train-report.json).
 *   5. Re-runs the corpus with the model ON and prints the behavioral delta
 *      (upgrades / downgrades / mild dissents per file) — the iterate signal
 *      before the stress suite + gates run.
 *
 * Run: npx tsx scripts/tinybrain_train.mts
 */
import fs from 'node:fs';
import path from 'node:path';
import { runLayoutBrain, BrainDoc, BrainDebugCandidate } from '../src/utils/layoutBrain';
import {
  TINY_FEATURES,
  TINY_FEATURE_COUNT,
  extractTinyFeatures,
  TinyBrainDocCtx,
  TinyWeights,
} from '../src/utils/tinyBrain';
import { WS_ROOT, PKG_ROOT } from '../scripts-batch/wsPaths.mts';

const BRAIN_DIR = path.join(PKG_ROOT, 'scratch', 'brain-app-qu2');
const OUT_DIR = path.join(WS_ROOT, 'scratch', 'tinybrain');
const WEIGHTS_TS = path.join(PKG_ROOT, 'src', 'utils', 'tinyBrainWeights.ts');
const REPORT_JSON = path.join(OUT_DIR, 'train-report.json');
const TEACHER_JSON = path.join(OUT_DIR, 'teacher-labels.json');

/** The 6 pinned 100% files get extra weight (the ship-critical set). */
const PINNED = [
  'pq89w65173', 'pm57p5s814', 'p8214n5896', 'pc4i517871', 'p43266n364', 'p566h5f982',
];

interface Sample {
  file: string;
  page: number;
  index: number;
  x: number[];
  y: number; // label 0/1
  w: number; // sample weight
  handC: number;
  src: 'corpus' | 'anchor' | 'teacher';
  firstText: string;
}

function sigmoid(z: number): number {
  return 1 / (1 + Math.exp(-Math.max(-30, Math.min(30, z))));
}

function candidateToSample(cand: BrainDebugCandidate, file: string, weight: number): Sample | null {
  // adapt the debug candidate into the structural shape extractTinyFeatures reads
  const pseudo = {
    boundaryKind: cand.boundaryKind,
    subject: cand.subject,
    evidence: cand.evidence,
    lines: cand.lineCount > 0
      ? [{ text: cand.firstText ?? '', size: cand.firstSize ?? 12, bold: !!cand.firstBold, bbox: [0, 0, 0, 0], page: cand.page }]
      : [],
    rows: cand.rows,
    notes: cand.notes,
    pageStart: cand.page,
  } as any;
  const ctx: TinyBrainDocCtx = ctxByFile.get(file)!;
  const x = extractTinyFeatures(pseudo, ctx);
  const y = cand.confidence >= 0.7 ? 1 : 0;
  return { file, page: cand.page, index: cand.index, x, y, w: weight, handC: cand.confidence, src: 'corpus', firstText: cand.firstText ?? '' };
}

const ctxByFile = new Map<string, TinyBrainDocCtx>();

function main() {
  if (!fs.existsSync(BRAIN_DIR)) {
    console.error(`(tinybrain_train: no sidecar dir at ${BRAIN_DIR} — run scripts/brain_app_extract.mts first)`);
    process.exit(1);
  }
  fs.mkdirSync(OUT_DIR, { recursive: true });

  // ---------- 1. corpus weak labels (hand-brain distillation) --------------
  const files = fs.readdirSync(BRAIN_DIR).filter((f) => f.endsWith('.json')).sort();
  const samples: Sample[] = [];
  for (const f of files) {
    const doc = JSON.parse(fs.readFileSync(path.join(BRAIN_DIR, f), 'utf8')) as BrainDoc;
    const res = runLayoutBrain(doc, { debug: true, tinyModel: false });
    ctxByFile.set(f, { bodySize: res.stats.bodySize, pageCount: doc.pages.length, contentLines: res.lines.length });
    const weight = PINNED.some((p) => f.includes(p)) ? 1.5 : 1.0;
    for (const cand of res.__debug?.candidates ?? []) {
      const s = candidateToSample(cand, f, weight);
      if (s) samples.push(s);
    }
  }
  console.log(`corpus candidates: ${samples.length} (pos ${samples.filter((s) => s.y === 1).length} / neg ${samples.filter((s) => s.y === 0).length})`);

  // ---------- 2. synthetic anchor labels for the arbiter tails -------------
  const mkAnchor = (y: number, shape: any, note: string): Sample => {
    const ctx: TinyBrainDocCtx = { bodySize: 12, pageCount: 2, contentLines: 40 };
    const x = extractTinyFeatures({ ...shape, pageStart: shape.pageStart ?? 0 } as any, ctx);
    return { file: 'synthetic', page: 0, index: -1, x, y, w: 2.0, handC: -1, src: 'anchor', firstText: note };
  };
  const ev = (o: Partial<typeof baseEv>) => ({ ...baseEv, ...o });
  const baseEv = { header: false, letter: false, mark: false, table: false, rules: false, ladder: 0, boxes: 0 };
  const L = (n: number, size = 12, bold = false) =>
    Array.from({ length: n }, () => ({ text: 'content line', size, bold, bbox: [0, 0, 0, 0], page: 0 }));
  const anchors: Array<[number, any, string]> = [
    // NEGATIVE tails — furniture textures the hand scorer over-values:
    // hand rule+genericHeader = 0.55+0.2 = 0.75 -> CONFIRMS junk; model must refuse.
    [0, { boundaryKind: 'rule', evidence: ev({ header: true, rules: true }), lines: L(1), rows: [], notes: [] }, 'rule+generic header+1 line (footer)'],
    [0, { boundaryKind: 'rule', evidence: ev({ header: true, rules: true }), lines: L(2), rows: [], notes: [] }, 'rule+generic header+2 lines'],
    [0, { boundaryKind: 'header', evidence: ev({ header: true }), lines: L(1), rows: [], notes: [] }, 'generic header+1 line'],
    [0, { boundaryKind: 'content', evidence: ev({ table: true }), lines: L(1), rows: [], notes: [] }, 'content table+1 line'],
    [0, { boundaryKind: 'header', evidence: ev({ header: true }), lines: L(0), rows: [], notes: ['empty section'] }, 'empty header section'],
    [0, { boundaryKind: 'rule', evidence: ev({ rules: true }), lines: L(2), rows: [], notes: [] }, 'rule+2 lines, nothing else'],
    // POSITIVE anchors — coherent structures must stay high:
    [1, { boundaryKind: 'rule', evidence: ev({ rules: true, letter: true, mark: true }), lines: L(10), rows: [{ letter: 'A', mark: 2 }, { letter: 'B', mark: 1 }], notes: ['sequence ok (B)'] }, 'rule+letters+marks+content'],
    [1, { boundaryKind: 'header', subject: 'Vocabulary', evidence: ev({ header: true, table: true, mark: true }), lines: L(12), rows: [{ letter: 'A', mark: 1 }, { letter: 'B', mark: 1 }, { letter: 'C', mark: 2 }], notes: ['sequence ok (C)'] }, 'keyword header+marks table+rows'],
    [1, { boundaryKind: 'header', subject: 'Grammar', evidence: ev({ header: true }), lines: L(8), rows: [], notes: [] }, 'keyword header+8 lines'],
    [1, { boundaryKind: 'matching', evidence: ev({ table: true, rules: true }), lines: L(9), rows: [], notes: [] }, 'matching layout+content'],
    [1, { boundaryKind: 'letter', evidence: ev({ letter: true, mark: true }), lines: L(6), rows: [{ letter: 'K', mark: 2 }], notes: ['sequence ok (K)'] }, 'lettered row+mark+content'],
  ];
  for (const [y, shape, note] of anchors) samples.push(mkAnchor(y, shape, note));

  // ---------- 3. teacher labels (dev-only, optional) -----------------------
  let teacherCount = 0;
  if (fs.existsSync(TEACHER_JSON)) {
    try {
      const labels = JSON.parse(fs.readFileSync(TEACHER_JSON, 'utf8')) as Array<{ file: string; page: number; textPrefix: string; label: number }>;
      for (const t of labels) {
        const hit = samples.find(
          (s) => s.src === 'corpus' && s.file.includes(t.file) && s.page === t.page && (s.firstText || '').trimStart().startsWith(t.textPrefix)
        );
        if (hit) {
          hit.y = t.label;
          hit.w = 3.0;
          hit.src = 'teacher';
          teacherCount++;
        }
      }
      console.log(`teacher labels applied: ${teacherCount}/${labels.length}`);
    } catch (e) {
      console.warn('teacher-labels.json unreadable — skipped', e);
    }
  } else {
    console.log('teacher labels: none (run scripts/tinybrain_teacher.mts with a provider key to add)');
  }

  // ---------- 4. fit: file-grouped 5-fold CV + Platt calibration -----------
  const fileNames = [...new Set(samples.map((s) => s.file))].sort();
  const folds = 5;
  const foldOf = new Map<string, number>();
  fileNames.forEach((f, i) => foldOf.set(f, i % folds));

  const trainAt = (idx: number[], iters = 4000, lr0 = 0.5, l2 = 1e-3): { w: number[]; b: number } => {
    const w = new Array(TINY_FEATURE_COUNT).fill(0);
    let b = 0;
    let lr = lr0;
    const n = idx.length;
    for (let it = 0; it < iters; it++) {
      const gw = new Array(TINY_FEATURE_COUNT).fill(0);
      let gb = 0;
      for (const i of idx) {
        const s = samples[i];
        let z = b;
        for (let k = 0; k < TINY_FEATURE_COUNT; k++) z += w[k] * s.x[k];
        const err = sigmoid(z) - s.y;
        const sw = err * s.w;
        for (let k = 0; k < TINY_FEATURE_COUNT; k++) gw[k] += sw * s.x[k];
        gb += sw;
      }
      for (let k = 0; k < TINY_FEATURE_COUNT; k++) w[k] -= lr * (gw[k] / n + l2 * w[k]);
      b -= lr * (gb / n);
      lr *= 0.9993;
    }
    return { w, b };
  };

  const rawOf = (s: Sample, w: number[], b: number): number => {
    let z = b;
    for (let k = 0; k < TINY_FEATURE_COUNT; k++) z += w[k] * s.x[k];
    return sigmoid(z);
  };

  const foldRaw: number[] = new Array(samples.length).fill(0);
  const foldPred: number[] = new Array(samples.length).fill(0);
  const hasFold: boolean[] = new Array(samples.length).fill(false);
  let cvCorrect = 0;
  let cvCount = 0;
  for (let k = 0; k < folds; k++) {
    const train = samples.map((s, i) => ({ s, i })).filter(({ s }) => foldOf.get(s.file) !== k).map(({ i }) => i);
    const test = samples.map((s, i) => ({ s, i })).filter(({ s }) => foldOf.get(s.file) === k).map(({ i }) => i);
    if (!test.length || !train.length) continue;
    const { w, b } = trainAt(train);
    for (const i of test) {
      const raw = rawOf(samples[i], w, b);
      foldRaw[i] = raw;
      foldPred[i] = raw >= 0.7 ? 1 : 0;
      hasFold[i] = true;
      cvCorrect += foldPred[i] === samples[i].y ? 1 : 0;
      cvCount++;
    }
  }
  // Platt scaling on pooled out-of-fold raws only (never on unfilled zeros)
  const fitPlatt = (): { A: number; B: number } => {
    const idx = samples.map((_, i) => i).filter((i) => hasFold[i]);
    let A = 1, B = 0;
    const sw = idx.reduce((n, i) => n + samples[i].w, 0) || 1;
    for (let it = 0; it < 400; it++) {
      let gA = 0, gB = 0;
      for (const i of idx) {
        const p = sigmoid(A * foldRaw[i] + B);
        const err = p - samples[i].y;
        gA += err * foldRaw[i] * samples[i].w;
        gB += err * samples[i].w;
      }
      A -= (gA / sw) * 2.0;
      B -= (gB / sw) * 2.0;
      if (!Number.isFinite(A) || !Number.isFinite(B)) return { A: 1, B: 0 };
    }
    return { A, B };
  };
  const platt = fitPlatt();
  const plattIdx = samples.map((_, i) => i).filter((i) => hasFold[i]);
  const calibratedCorrect = plattIdx.reduce(
    (n, i) => n + (sigmoid(platt.A * foldRaw[i] + platt.B) >= 0.7 === (samples[i].y === 1) ? 1 : 0), 0);
  // AUC (rank statistic) on out-of-fold calibrated scores
  const calScores = plattIdx.map((i) => sigmoid(platt.A * foldRaw[i] + platt.B));
  const pos = plattIdx.filter((i) => samples[i].y === 1).length;
  const neg = plattIdx.length - pos;
  let rankSum = 0;
  const order = calScores.map((v, i) => ({ v, i })).sort((a, b) => a.v - b.v);
  order.forEach(({ i }, rank) => { if (samples[plattIdx[i]].y === 1) rankSum += rank + 1; });
  const auc = pos && neg ? (rankSum - (pos * (pos + 1)) / 2) / (pos * neg) : 1;

  // final fit on ALL samples
  const all = samples.map((_, i) => i);
  const final = trainAt(all);
  const finalCommitAcc = samples.reduce((n, s, i) => n + ((rawOf(s, final.w, final.b) >= 0.7) === (s.y === 1) ? 1 : 0), 0) / samples.length;

  console.log(`CV accuracy (raw, commit 0.7): ${(cvCorrect / Math.max(1, cvCount)).toFixed(3)} | calibrated: ${(calibratedCorrect / Math.max(1, plattIdx.length)).toFixed(3)} | AUC ${auc.toFixed(3)} | full-fit commit acc ${finalCommitAcc.toFixed(3)}`);
  console.log(`Platt: A=${platt.A.toFixed(3)} B=${platt.B.toFixed(3)}`);

  // ---------- 5. write the weights module + report --------------------------
  const weights: TinyWeights = {
    version: 1,
    trainedAt: new Date().toISOString(),
    trainer: 'scripts/tinybrain_train.mts (pure-TS logistic + Platt, file-grouped 5-fold CV)',
    dataset: {
      positives: samples.filter((s) => s.y === 1).length,
      negatives: samples.filter((s) => s.y === 0).length,
      files: fileNames.filter((f) => f !== 'synthetic').length,
      teacherLabels: teacherCount,
    },
    metrics: {
      cvAccuracy: cvCorrect / Math.max(1, cvCount),
      cvAuc: auc,
      commitThresholdAccuracy: finalCommitAcc,
    },
    features: [...TINY_FEATURES],
    w: final.w.map((x) => Math.round(x * 1e4) / 1e4),
    b: Math.round(final.b * 1e4) / 1e4,
    plattA: Math.round(platt.A * 1e4) / 1e4,
    plattB: Math.round(platt.B * 1e4) / 1e4,
    thresholds: { commit: 0.7, upgradeAbove: 0.85, downgradeBelow: 0.45 },
  };
  const ts = `/**
 * tinyBrainWeights — TRAINED ARTIFACT (generated by scripts/tinybrain_train.mts,
 * do not edit by hand — rerun the trainer).
 *
 * ${weights.dataset.positives} positives / ${weights.dataset.negatives} negatives over ${weights.dataset.files} corpus files
 * (+ ${anchors.length} synthetic tail anchors${teacherCount ? `, ${teacherCount} teacher labels` : ''}).
 * CV accuracy ${(weights.metrics.cvAccuracy * 100).toFixed(1)}%, AUC ${weights.metrics.cvAuc.toFixed(3)}.
 * A logistic model over TINY_FEATURES with Platt calibration — the learned
 * fusion layer of the layout brain (fail-safe: invalid weights = hand scorer).
 */
import type { TinyWeights } from './tinyBrain';

export const TINY_BRAIN_WEIGHTS: TinyWeights | null = ${JSON.stringify(weights, null, 2)};
`;
  fs.writeFileSync(WEIGHTS_TS, ts);

  const report = {
    ...weights,
    samples: samples.length,
    topWeights: TINY_FEATURES.map((f, i) => ({ f, w: final.w[i] }))
      .sort((a, b) => Math.abs(b.w) - Math.abs(a.w))
      .slice(0, 12),
  };
  fs.writeFileSync(REPORT_JSON, JSON.stringify(report, null, 2));
  console.log(`weights written: ${WEIGHTS_TS}`);
  console.log(`report: ${REPORT_JSON}`);
  console.log(`\nnext: npx tsx scripts/tinybrain_eval.mts   (fresh process: behavioral delta + drive posture)`);
}

main();
