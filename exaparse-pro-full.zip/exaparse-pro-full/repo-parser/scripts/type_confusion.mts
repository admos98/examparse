/**
 * type_confusion — the Q-TYPE smoking gun under a microscope.
 * Builds the (got → want) question-type confusion matrix over the whole qu2
 * GT corpus, plus the Q-NUMBER-ALIGN anatomy (shift direction) and the
 * CATEGORY confusion matrix. Measurement only.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../src/utils/parserEngine';
import { gradeParse, GoldenGT } from '../src/utils/goldenGrade';
import { WS_ROOT } from '../scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const TEXT_DIR = process.env.QU2_TEXT_DIR ?? path.join(WS_ROOT, 'scratch', 'texts-qu2');

function main() {
  const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
  const typeConf = new Map<string, number>();
  const catConf = new Map<string, number>();
  const align = new Map<string, number>();
  for (const f of files) {
    const gt: GoldenGT = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
    const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
    if (!fs.existsSync(textPath)) continue;
    const parsed = parseExamRawText(fs.readFileSync(textPath, 'utf8'), gt.file, {
      detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true,
    });
    const { issues } = gradeParse(parsed, gt);
    // map gt sections by occurrence
    const idSeen = new Map<string, number>();
    for (const gts of gt.sections) {
      const occ = idSeen.get(gts.id) ?? 0;
      idSeen.set(gts.id, occ + 1);
      const matches = parsed.sections.filter((s) => s.rowId === gts.id);
      const sec = matches[occ];
      if (!sec) continue;
      if (sec.majorCategory !== gts.cat) catConf.set(`${sec.majorCategory} -> ${gts.cat}`, (catConf.get(`${sec.majorCategory} -> ${gts.cat}`) ?? 0) + 1);
      const wantQs: { n: number; t: string }[] = [];
      for (const q of gts.qs) {
        if (q.stem !== undefined) continue;
        if (Array.isArray(q.n)) for (const n of q.n) wantQs.push({ n, t: q.t });
        else wantQs.push({ n: q.n as number, t: q.t });
      }
      const gotQs = sec.questions.map((q) => ({ n: q.number as number, t: q.type }));
      const len = Math.min(gotQs.length, wantQs.length);
      for (let i = 0; i < len; i++) {
        if (gotQs[i].t !== wantQs[i].t) {
          const k = `${gotQs[i].t} -> ${wantQs[i].t}`;
          typeConf.set(k, (typeConf.get(k) ?? 0) + 1);
        }
        if (gotQs[i].n !== wantQs[i].n) {
          const d = gotQs[i].n - wantQs[i].n;
          const k = d > 0 ? `got ahead by ${d > 3 ? '>3' : d}` : `got behind by ${-d > 3 ? '>3' : -d}`;
          align.set(k, (align.get(k) ?? 0) + 1);
        }
      }
    }
  }
  const dump = (m: Map<string, number>, title: string) => {
    console.log(`\n=== ${title} ===`);
    const arr = [...m.entries()].sort((a, b) => b[1] - a[1]);
    const sum = arr.reduce((s, [, n]) => s + n, 0);
    for (const [k, n] of arr.slice(0, 18)) console.log(`${String(n).padStart(4)} (${((n / sum) * 100).toFixed(0)}%)  ${k}`);
    console.log('total', sum);
  };
  dump(typeConf, 'Q-TYPE CONFUSION (got -> want)');
  dump(align, 'Q-NUMBER ALIGNMENT ANATOMY');
  dump(catConf, 'CATEGORY CONFUSION (got -> want)');
}
main();
