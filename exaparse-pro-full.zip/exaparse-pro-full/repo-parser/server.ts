import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { Type } from '@google/genai';
import { executeAIRequest, AIResponse } from './src/server/aiProvider.js';
import { callNativeJev, judgeViaLLM } from './src/server/judgeProvider.js';
import { mineRule, loadMinedRules, changeRuleStatus, ParseSummarySection } from './src/server/ruleMining.js';
import { MinedRuleStatus } from './src/utils/ruleMiner.js';
import { PROVIDER_DEFAULT_BASE_URLS } from './src/types/settings.js';
import { preSolveDocument, checkAnswerDistribution, PreSolveResult } from './src/utils/autoSolver.js';
import { AdjudicationCell, AdjudicationVerdict } from './src/utils/adjudicator.js';
import { AnswerChange, AIUsageReceipt, QuestionItem } from './src/types/exam.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Allow large payloads for PDF / Image base64 uploads
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Serve static assets from public folder (e.g. offline traineddata for tesseract)
app.use(express.static(path.join(__dirname, 'public')));

// ============================================================================
// AI-as-Referee helpers: deterministic pre-solve, contested-only dispatch,
// redline diff, token receipts. Every AI call pays ONLY for contested cells.
// ============================================================================

function estimateBaselineTokens(doc: any): number {
  try {
    const chars = JSON.stringify(doc, (k, v) => (k === 'sourceFile' ? undefined : v)).length;
    const questionCount = (doc?.sections || []).reduce(
      (s: number, sec: any) => s + (sec?.questions?.length || 0), 0,
    );
    // Naive pipeline: ship the WHOLE exam + receive an answer for EVERY question.
    return Math.ceil(chars / 4) + questionCount * 30;
  } catch {
    return 0;
  }
}

function buildReceipt(
  usage: AIResponse['usage'],
  baselineTokens: number,
  presolve: PreSolveResult,
  aiSolved: number,
): AIUsageReceipt {
  const totalTokens = usage?.totalTokens || 0;
  return {
    ranAt: new Date().toISOString(),
    requests: 1,
    promptTokens: usage?.promptTokens || 0,
    completionTokens: usage?.completionTokens || 0,
    totalTokens,
    baselineTokens,
    savedPct: baselineTokens > 0 ? Math.max(0, Math.round((1 - totalTokens / baselineTokens) * 1000) / 10) : 0,
    heuristicSolved: presolve.heuristicSolved,
    cacheHits: presolve.cacheHits,
    aiSolved,
  };
}

function buildExemplarBlock(exemplars: any[]): string {
  if (!Array.isArray(exemplars) || exemplars.length === 0) return '';
  const lines = exemplars
    .slice(0, 8) // few-shot signal saturates fast; 8 ≈ same accuracy at 60% fewer tokens
    .map((e, i) => {
      const stem = String(e.stem || '').slice(0, 80);
      const outcome = e.field === 'type' ? `correct type: ${e.after}` : `correct answer: ${e.after}`;
      return `${i + 1}. [${e.questionType || 'unknown'}] "${stem}" -> ${outcome}`;
    });
  return (
    'TEACHER\'S PAST CORRECTIONS on similar exams (follow the same style and conventions):\n' +
    lines.join('\n')
  );
}

function computeChanges(
  origDoc: any,
  updatedSections: any[],
  methodFor: (questionId: string, field: string) => 'ai' | 'heuristic' | 'cache',
): AnswerChange[] {
  const changes: AnswerChange[] = [];
  for (const sec of updatedSections || []) {
    const origSec = (origDoc?.sections || []).find((s: any) => s.rowId === sec.rowId);
    if (!origSec) continue;
    for (const q of sec.questions || []) {
      const origQ = (origSec.questions || []).find((oq: any) => oq.id === q.id);
      if (!origQ) continue;
      const stem = String(q.stem || '').slice(0, 140);
      if ((origQ.correctAnswer || '') !== (q.correctAnswer || '')) {
        changes.push({
          id: `chg-${q.id}-answer`,
          questionId: q.id,
          sectionRowId: sec.rowId,
          questionNumber: q.displayNumber,
          stem,
          field: 'correctAnswer',
          before: origQ.correctAnswer || '',
          after: q.correctAnswer || '',
          method: methodFor(q.id, 'correctAnswer'),
          status: 'pending',
        });
      }
      if (q.type && origQ.type && q.type !== origQ.type) {
        changes.push({
          id: `chg-${q.id}-type`,
          questionId: q.id,
          sectionRowId: sec.rowId,
          questionNumber: q.displayNumber,
          stem,
          field: 'type',
          before: origQ.type,
          after: q.type,
          method: methodFor(q.id, 'type'),
          status: 'pending',
        });
      }
    }
  }
  return changes;
}

function applyPreSolvedToSections(
  sections: any[],
  presolve: PreSolveResult,
): { sections: any[]; heuristicApplied: number; cacheApplied: number } {
  let heuristicApplied = 0;
  let cacheApplied = 0;
  const nextSections = sections.map((sec) => ({
    ...sec,
    questions: (sec.questions || []).map((q: any) => {
      const pre = presolve.solved.get(q.id);
      if (!pre) return q;
      // Never overwrite a non-empty existing answer with nothing.
      const answer = pre.answer || q.correctAnswer || '';
      if (pre.method === 'heuristic') heuristicApplied++;
      else cacheApplied++;
      return {
        ...q,
        correctAnswer: answer || q.correctAnswer || '',
        answerMeta: { method: pre.method, confidence: pre.confidence },
      };
    }),
  }));
  return { sections: nextSections, heuristicApplied, cacheApplied };
}

/** Deterministic post-AI audit: statistically implausible MCQ keys. */
function distributionAnomaly(sections: any[]): { title: string; description: string; suggestedFix: string } | null {
  const all: QuestionItem[] = (sections || []).flatMap((s: any) => s.questions || []);
  const flagged = checkAnswerDistribution(all);
  if (!flagged) return null;
  return {
    title: 'Implausible answer-key distribution detected (deterministic audit)',
    description: flagged.message,
    suggestedFix: 'Manually verify the key for this section, or re-solve with a different model.',
  };
}

// Schema for Gemini native structured output
const EXAM_PARSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    header: {
      type: Type.OBJECT,
      properties: {
        courseName: { type: Type.STRING },
        teacherName: { type: Type.STRING },
        durationMinutes: { type: Type.NUMBER },
        examDate: { type: Type.STRING },
        schoolName: { type: Type.STRING },
        district: { type: Type.STRING },
        gradeAndMajor: { type: Type.STRING },
        pageCount: { type: Type.NUMBER },
      },
      required: ['courseName', 'schoolName', 'gradeAndMajor'],
    },
    totalQuestions: { type: Type.NUMBER },
    totalMarks: { type: Type.NUMBER },
    confidenceScore: { type: Type.NUMBER },
    anomalies: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          severity: { type: Type.STRING },
          sectionRowId: { type: Type.STRING },
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          suggestedFix: { type: Type.STRING },
          isResolved: { type: Type.BOOLEAN },
        },
        required: ['id', 'severity', 'title', 'description', 'suggestedFix'],
      },
    },
    sections: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          rowId: { type: Type.STRING },
          majorCategory: { type: Type.STRING },
          title: { type: Type.STRING },
          persianInstruction: { type: Type.STRING },
          englishInstruction: { type: Type.STRING },
          markTotal: { type: Type.NUMBER },
          hasWordBank: { type: Type.BOOLEAN },
          wordBank: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
          hasPassage: { type: Type.BOOLEAN },
          passageTitle: { type: Type.STRING },
          passageText: { type: Type.STRING },
          questions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                number: { type: Type.NUMBER },
                displayNumber: { type: Type.STRING },
                sectionRowId: { type: Type.STRING },
                sectionName: { type: Type.STRING },
                type: { type: Type.STRING },
                stem: { type: Type.STRING },
                persianInstruction: { type: Type.STRING },
                mark: { type: Type.NUMBER },
                correctAnswer: { type: Type.STRING },
                parentContextType: { type: Type.STRING },
                parentContextTitle: { type: Type.STRING },
                options: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      text: { type: Type.STRING },
                    },
                    required: ['id', 'text'],
                  },
                },
              },
              required: ['id', 'number', 'displayNumber', 'sectionRowId', 'type', 'stem', 'mark'],
            },
          },
        },
        required: ['rowId', 'majorCategory', 'markTotal', 'questions'],
      },
    },
  },
  required: ['header', 'totalQuestions', 'totalMarks', 'sections'],
};

// 1. TEST CONNECTION ENDPOINT
app.post('/api/test-provider', async (req, res) => {
  try {
    const { providerConfig } = req.body;
    const testResult = await executeAIRequest({
      systemPrompt: 'You are an API diagnostic tester. Return pure JSON only with no markdown.',
      userPrompt: 'Test ping. Please reply with JSON: {"ok": true, "status": "online", "message": "ExaParse AI connection verified"}',
      providerConfig,
      // A connection ping must NOT fire the full A/B/C ladder: when the
      // gateway is down each extra attempt just burns billable tokens for an
      // identical failure. One attempt is enough to diagnose.
      maxAttempts: 1,
    });

    res.json({
      ok: true,
      model: testResult.model,
      latencyMs: testResult.latencyMs,
      sample: testResult.parsedJson,
    });
  } catch (error: any) {
    console.error('Test Provider Error:', error);
    res.status(500).json({
      ok: false,
      error: error.message || 'Connection test failed',
    });
  }
});

// 2. LIST MODELS PROXY ENDPOINT
app.all('/api/list-models', async (req, res) => {
  try {
    // SECURITY: never accept the API key from the URL query string — URLs are
    // persisted in server/access logs and proxies. Body (POST) or the
    // `x-api-key` header are the only supported transports.
    if (req.query.apiKey) {
      return res.status(400).json({
        error: 'API key must be sent in the JSON body or the x-api-key header — never in the URL query string (it leaks into logs).',
      });
    }

    const provider = (req.body?.provider || req.query.provider || 'gemini') as string;
    const baseURL = ((req.body?.baseURL || req.query.baseURL || PROVIDER_DEFAULT_BASE_URLS[provider as keyof typeof PROVIDER_DEFAULT_BASE_URLS] || '') as string).toString().trim().replace(/\/+$/, '');
    const headerKey = req.headers['x-api-key'];
    const apiKey = (req.body?.apiKey || (typeof headerKey === 'string' && headerKey ? headerKey : '') || (provider === 'gemini' ? process.env.GEMINI_API_KEY : '')) as string;

    if (provider === 'gemini') {
      return res.json({
        models: [
          'gemini-2.5-flash',
          'gemini-2.5-pro',
          'gemini-2.0-flash',
          'gemini-1.5-flash',
          'gemini-1.5-pro',
        ],
      });
    }

    if (!baseURL) {
      return res.status(400).json({ error: 'Base URL is required to list models' });
    }

    const headers: Record<string, string> = {};
    if (apiKey) headers['Authorization'] = `Bearer ${apiKey}`;
    if (provider === 'openrouter') {
      headers['HTTP-Referer'] = 'https://exaparse.app';
      headers['X-Title'] = 'ExaParse Pro';
    }

    // Models list: bounded 15s timeout — a hung gateway must not hang the
    // Settings dialog (this is a metadata fetch, not a generation call).
    const response = await fetch(`${baseURL}/models`, { headers, signal: AbortSignal.timeout(15_000) });
    if (!response.ok) {
      throw new Error(`Provider returned HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    const models = Array.isArray(data.data)
      ? data.data.map((m: any) => m.id || m.name).filter(Boolean)
      : Array.isArray(data.models)
      ? data.models.map((m: any) => m.name || m.id).filter(Boolean)
      : [];

    res.json({ models });
  } catch (error: any) {
    console.warn('List Models Error:', error.message);
    res.status(500).json({ error: error.message || 'Failed to list models' });
  }
});

// 3. ENHANCE & SOLVE EXAM ENDPOINT (Minimal Token Footprint, High Accuracy)
app.post('/api/enhance-exam', async (req, res) => {
  try {
    const { exam, providerConfig, cachedAnswers, exemplars } = req.body;

    if (!exam || !exam.sections) {
      return res.status(400).json({ error: 'Missing parsed exam document structure.' });
    }

    // ---- M2 PRODUCER MODE: short answers for EXACTLY the requested ids ----
    // The R3 last call of the complete flow: the text LLM produces JUST a short
    // answer per unresolved question (bucket B free-text + bucket C image
    // items whose vision alts are attached). No solve machinery, no heuristic
    // overlay, no document mutation — the caller (producerCritic.ts) runs the
    // Jev critic over these answers and mediates disagreements with a human.
    if (req.body.mode === 'produce_short_answers' && Array.isArray(req.body.onlyIds)) {
      const onlyIds = new Set<string>(req.body.onlyIds.map(String));
      const wanted: any[] = [];
      for (const sec of exam.sections) {
        for (const q of sec.questions || []) {
          if (!onlyIds.has(String(q.id))) continue;
          wanted.push({
            id: q.id,
            type: q.type,
            stem: q.stem,
            options: q.options,
            wordBankWords: q.wordBankWords,
            parentContextType: q.parentContextType,
            parentContextTitle: q.parentContextTitle,
            parentContextText: q.parentContextText ? String(q.parentContextText).slice(0, 2000) : undefined,
            // Vision alt/transcription: the authoritative text of the image
            // this question references (bucket C items are text-complete by
            // the time they get here).
            imageCaption: q.imageCaption,
            mark: q.mark,
          });
        }
      }

      if (wanted.length === 0) {
        return res.json({ success: true, answers: [], usage: { promptTokens: 0, completionTokens: 0, totalTokens: 0 }, warnings: ['No matching questions for the requested ids.'], model: providerConfig?.model || 'unknown' });
      }

      const producerPrompt = `You are an exam answer producer. For EVERY question below, output ONLY a short correct answer.
Rules:
- Multiple choice / inline choice: the exact option key ("a"-"d").
- Word bank fill: the exact word from the given bank words.
- True/false: "true" or "false".
- Form in parentheses / error correction: the corrected word or "mistake -> correction".
- Unscramble / combine / active-passive / letter reorder: the pristine full answer.
- Translation: the natural translation.
- Reading/dialogue/picture items: a concise, accurate answer from the attached context or image text.
OUTPUT raw JSON only: {"answers":[{"id":"<question id>","answer":"<short answer>"}]}
Minimal output. No explanations. Never refuse — give your best answer.`;

      const payload = JSON.stringify({
        sections: [{ questions: wanted }],
      });

      const warnings: string[] = [];
      let usage = { promptTokens: 0, completionTokens: 0, totalTokens: 0 };
      const answersOut: { id: string; answer: string }[] = [];
      try {
        const aiResponse = await executeAIRequest({
          systemPrompt: producerPrompt,
          userPrompt: `Produce a short answer for each of the ${wanted.length} question(s). Questions JSON:\n${payload}`,
          providerConfig,
        });
        usage = aiResponse.usage || usage;
        const parsed = aiResponse.parsedJson || {};
        const list: any[] = Array.isArray(parsed.answers) ? parsed.answers : [];
        for (const a of list) {
          if (a && a.id && onlyIds.has(String(a.id)) && a.answer !== undefined && String(a.answer).length > 0) {
            answersOut.push({ id: String(a.id), answer: String(a.answer) });
          }
        }
        if (aiResponse.truncated) warnings.push(`Producer output truncated (${aiResponse.finishReason || 'length'}) — some answers may be missing.`);
      } catch (e: any) {
        warnings.push(`Producer was unreachable (${e?.message || e}). No answers produced.`);
      }

      return res.json({
        success: true,
        answers: answersOut,
        requested: wanted.length,
        usage,
        warnings,
        model: providerConfig?.model || 'unknown',
      });
    }

    // ---- 1. AI-as-referee: solve what we can deterministically, for free ----
    const cacheMap = new Map<string, string>(
      Array.isArray(cachedAnswers)
        ? cachedAnswers.filter((c: any) => c && c.questionId && c.answer).map((c: any) => [c.questionId, String(c.answer)])
        : [],
    );
    const presolve = preSolveDocument(exam, (q) => {
      const hit = cacheMap.get(q.id);
      return hit ? { answer: hit, method: 'cache', confidence: 0.95 } : undefined;
    });

    const baselineTokens = estimateBaselineTokens(exam);

    // Everything the deterministic engine resolved never reaches the model.
    const contestedIds = new Set(presolve.contested.map((q: any) => q.id));

    // ---- 2. Full-context payload: CONTESTED questions only, but with the
    // context needed to actually solve them (full passages, matching columns,
    // instructions, word banks). The hard input budget still guards against a
    // contested-heavy sheet silently costing 6k+ input tokens per call.
    // (This is the merged payload of the former /api/solve-parsed-exam.)
    const compactExamSummary: any = {
      header: exam.header,
      sections: exam.sections
        .map((sec: any) => ({
          rowId: sec.rowId,
          majorCategory: sec.majorCategory,
          title: sec.title,
          englishInstruction: sec.englishInstruction,
          persianInstruction: sec.persianInstruction,
          hasWordBank: sec.hasWordBank,
          wordBank: sec.wordBank,
          hasPassage: sec.hasPassage,
          passageTitle: sec.passageTitle,
          passageText: sec.passageText, // full — required for solving reading items
          matchingColumns: sec.matchingColumns,
          questions: (sec.questions || [])
            .filter((q: any) => contestedIds.has(q.id))
            .map((q: any) => ({
              id: q.id,
              number: q.number,
              displayNumber: q.displayNumber,
              type: q.type,
              stem: q.stem,
              englishInstruction: q.englishInstruction,
              persianInstruction: q.persianInstruction,
              options: q.options,
              mark: q.mark,
              parentContextType: q.parentContextType,
              parentContextTitle: q.parentContextTitle,
              parentContextText: q.parentContextText,
              wordBankWords: sec.wordBank ? undefined : q.wordBankWords, // dedupe: section bank already sent
              matchingPairs: q.matchingPairs,
              matchingDistractors: q.matchingDistractors,
            })),
        }))
        .filter((sec: any) => sec.questions.length > 0),
    };

    const contestedCount = presolve.contested.length;

    // Input token budget: minified JSON + hard cap ≈ 12k tokens. Prevents a
    // contested-heavy sheet from silently costing 6k+ input tokens per call.
    const MAX_CONTESTED_PAYLOAD_CHARS = 48_000;
    let payloadJson = JSON.stringify(compactExamSummary);
    let sentContested = contestedCount;
    const countQuestions = () =>
      compactExamSummary.sections.reduce((s: number, x: any) => s + x.questions.length, 0);
    if (payloadJson.length > MAX_CONTESTED_PAYLOAD_CHARS) {
      while (
        payloadJson.length > MAX_CONTESTED_PAYLOAD_CHARS &&
        countQuestions() > 1
      ) {
        const biggest = compactExamSummary.sections.reduce((a: any, b: any) =>
          b.questions.length > a.questions.length ? b : a,
        );
        biggest.questions.pop();
      }
      compactExamSummary.sections = compactExamSummary.sections.filter(
        (s: any) => s.questions.length > 0,
      );
      sentContested = countQuestions();
      payloadJson = JSON.stringify(compactExamSummary);
    }

    const systemPrompt = `You are an expert exam answer SOLVER. The questions were already structurally parsed (stems, options, word banks extracted); the deterministic engine solved what it could, and ONLY the contested questions were sent to you.
Your job is ONLY to SOLVE each question sent to you, accurately:
1. For EVERY question sent, give the verified correctAnswer:
   - Multiple choice / inline choice: the exact option key ("a"-"d") or exact word.
   - Word bank fill: the exact word from the attached word bank.
   - Error correction: "mistake -> correction".
   - Unscramble / combine / active-passive: the pristine full sentence.
   - Reading comprehension & dialogue: a concise, accurate answer based on the passage or picture prompt.
2. Include "type" ONLY when the parsed type is wrong. Types: multiple_choice, cloze_item, word_bank_fill, fill_blank, matching, true_false, short_answer, long_answer_essay, unscramble, form_in_parentheses, combine_sentences, active_passive, error_correction, letter_reorder, inline_choice, dialogue_response, odd_one_out, phonetic_pronunciation, sentence_ordering, picture_description, translation, definition_matching, numerical_calculation.
3. Flag teacher errors/typos in the stems in the anomalies list.
OUTPUT raw JSON only: {"answers":[{"id":"...","correctAnswer":"...","type":"...only when changed"}],"anomalies":[{"title":"...","description":"...","suggestedFix":"..."}]}
Never echo stems or paragraphs. Never invent header fields. Minimal output.`;

    // Few-shot the teacher's past corrections — placed at the HEAD of the user
    // message (NOT the system prompt) so the system prompt stays a byte-stable
    // prefix and providers' implicit prompt caching discounts apply.
    const exemplarBlock = buildExemplarBlock(exemplars);
    const userPrompt = `${exemplarBlock ? exemplarBlock + '\n\n' : ''}Only ${sentContested} question(s) could not be resolved by the deterministic engine. Compact Exam AST (contested questions only):
${payloadJson}`;

    // AI is OPTIONAL: a fully deterministic solve (or an unreachable provider)
    // must never destroy the free answers already computed.
    let aiResponse: AIResponse | null = null;
    let aiError: string | null = null;
    if (contestedCount > 0) {
      try {
        aiResponse = await executeAIRequest({
          systemPrompt,
          userPrompt,
          providerConfig,
        });
      } catch (e: any) {
        aiError = e?.message || String(e);
        console.warn('enhance-exam: AI unavailable, keeping deterministic results:', aiError);
      }
    }

    const refinement = aiResponse?.parsedJson || {};
    const answersList: any[] = Array.isArray(refinement.answers) ? refinement.answers : [];

    // Non-fatal warnings surfaced to the client (e.g. output hit the token limit).
    const warnings: string[] = [];
    const knownIdsEarly = new Set<string>(
      exam.sections.flatMap((s: any) => (s.questions || []).map((q: any) => q.id)),
    );
    const unmatchedAiAnswers = answersList.filter((a: any) => !a || !a.id || !knownIdsEarly.has(a.id));
    if (aiError) {
      warnings.push(`AI was unreachable (${aiError}). Deterministic answers were kept; the ${contestedCount} contested question(s) remain unsolved.`);
    }
    if (contestedCount === 0) {
      warnings.push('Fully solved by the deterministic engine — 0 AI tokens spent.');
    }
    if (sentContested < contestedCount) {
      warnings.push(
        `Input token budget reached: sent ${sentContested} of ${contestedCount} contested questions to the AI this run. Run enhance again to process the remaining ones.`,
      );
    }
    if (unmatchedAiAnswers.length > 0) {
      warnings.push(
        `AI returned ${unmatchedAiAnswers.length} answer(s) whose question id does not match the parsed exam — they were IGNORED instead of being applied to wrong questions.`,
      );
    }
    if (aiResponse?.truncated) {
      warnings.push(
        `AI output was truncated at the model's token limit (finishReason: ${aiResponse.finishReason || 'length'}), so some answers may be missing. Increase "Max Output Tokens" in Settings or solve the exam in smaller parts.`,
      );
    }

    // Map AI answers into the original structure, THEN overlay deterministic
    // answers. MATCH BY ID ONLY (#fix-4): the previous fallback —
    // `|| String(a.number) === String(q.number)` — matched answers across ALL
    // sections, and since every section restarts numbering at 1, six AI
    // answers were smeared cyclically over all 37 questions of a real exam.
    const aiAnsweredIds = new Set<string>();
    const updatedSections = exam.sections.map((sec: any) => ({
      ...sec,
      questions: sec.questions.map((q: any) => {
        const found = answersList.find((a: any) => a.id === q.id);
        if (found && found.correctAnswer) aiAnsweredIds.add(q.id);
        return {
          ...q,
          type: found?.type || q.type,
          correctAnswer: found?.correctAnswer || q.correctAnswer || '',
          answerMeta: found?.correctAnswer ? { method: 'ai', confidence: undefined } : q.answerMeta,
        };
      }),
    }));

    // Overlay the deterministic layer (heuristic matching + semantic cache)
    const overlaid = applyPreSolvedToSections(updatedSections, presolve);

    const changes = computeChanges(exam, overlaid.sections, (qid) => {
      const pre = presolve.solved.get(qid);
      return pre ? pre.method : 'ai';
    });

    // Deterministic post-AI audit: implausible MCQ key distributions
    const distAnomaly = distributionAnomaly(overlaid.sections);
    const mergedAnomalies = refinement.anomalies?.length
      ? refinement.anomalies
      : exam.anomalies || [];
    if (distAnomaly) mergedAnomalies.push(distAnomaly);

    // HONEST STAGE FLAGS (#e2e-1): "Stage 2: AI-Solved" may only be claimed
    // when this pass actually FILLED something. The live-teacher E2E caught
    // the lie: with no provider key the AI call failed, 0 answers were
    // filled, and the document was still stamped stage2_ai_solved — the
    // detail screen then showed "Fully Solved & Verified" over 0/60 answer
    // keys. Count what the exam really carries after the merge; when the
    // pass produced nothing new, keep the previous stage flags so the UI
    // stays truthful ("Awaiting AI Solving Call").
    const countFilled = (sections: any[]): number =>
      sections.flatMap((s: any) => s.questions || []).filter((q: any) => q.correctAnswer && String(q.correctAnswer).trim()).length;
    const filledBefore = countFilled(exam.sections);
    const filledAfter = countFilled(overlaid.sections);
    const producedAnswers = filledAfter > filledBefore;

    const updatedExam = {
      ...exam,
      // Header naming was PRUNED from the AI path: the offline parser extracts
      // headers deterministically (verified at 100% on the 50-paper corpus), and
      // an AI rewrite could only invent fields, not improve them.
      header: { ...exam.header },
      sections: overlaid.sections,
      parseStage: producedAnswers ? 'stage2_ai_solved' : (exam.parseStage || 'stage1_offline_unsolved'),
      isAiSolved: producedAnswers ? true : !!exam.isAiSolved,
      ...(producedAnswers ? { solvedAt: new Date().toISOString() } : {}),
      anomalies: mergedAnomalies,
      confidenceScore: producedAnswers ? Math.max(99.0, exam.confidenceScore || 99.0) : (exam.confidenceScore || 99.0),
      aiUsage: buildReceipt(aiResponse?.usage, baselineTokens, presolve, aiAnsweredIds.size),
      review: { changes, updatedAt: new Date().toISOString() },
    };

    res.json({
      success: true,
      document: updatedExam,
      warnings,
      changes,
      contestedCount,
      heuristicSolved: presolve.heuristicSolved,
      cacheHits: presolve.cacheHits,
      aiSolved: aiAnsweredIds.size,
      usage: updatedExam.aiUsage,
    });
  } catch (error: any) {
    console.error('Enhance Exam Error:', error);
    res.status(500).json({ error: error.message || 'Failed to enhance exam' });
  }
});

// 4. (removed) /api/solve-parsed-exam — merged into /api/enhance-exam.
// The former two near-identical solve pipelines (enhance vs solve) were the
// main redundancy of the old flow: two prompts, two merge paths, two payloads
// to keep in sync. /api/enhance-exam now carries the full-context payload
// (full passages, matching columns, instructions) + the contested-only token
// budget, so there is exactly ONE solve path.

// 5. AI ADJUDICATION ENDPOINT (#14/#15) — the AI never writes content.
// Strict enum protocol: for each contested cell the model may ONLY answer
// with a provided option key or a word from the word bank. Three votes at
// varied temperature; 2/3 agreement required; the deterministic validator
// rejects anything else. Zero free-form text reaches the document.
app.post('/api/adjudicate', async (req, res) => {
  try {
    const { cells, providerConfig } = req.body as { cells: AdjudicationCell[]; providerConfig: any };

    if (!Array.isArray(cells) || cells.length === 0) {
      return res.status(400).json({ error: 'No contested cells to adjudicate.' });
    }

    const systemPrompt = `You are an exam answer ADJUDICATOR. For every question you receive you must output ONE verdict.
HARD CONSTRAINTS — violations are discarded automatically:
- If "optionKeys" is provided, your verdict MUST be exactly one of those keys (single letter).
- If "wordBankWords" is provided, your verdict MUST be one of those exact words.
- Never invent answers outside the allowed sets. No explanations. JSON only.
Output shape: { "verdicts": [ { "questionId": "...", "answer": "..." } ] }`;

    const payload = JSON.stringify(
      {
        cells: cells.slice(0, 60).map((c) => ({
          questionId: c.questionId,
          type: c.type,
          stem: c.stem,
          optionKeys: c.optionKeys,
          wordBankWords: c.wordBankWords,
          passage: c.passageSnippet,
        })),
      },
      null,
      2,
    );

    // ---- Three-vote self-consistency (#15): varied temperature, same task.
    const rounds = [
      { temperature: 0.0, nudge: 'Adjudication round 1 of 3. Be literal and conservative.' },
      { temperature: 0.4, nudge: 'Adjudication round 2 of 3. Re-read each stem carefully.' },
      { temperature: 0.8, nudge: 'Adjudication round 3 of 3. Double-check option meanings.' },
    ];

    const voteMaps: Map<string, string>[] = [];
    const usages: AIResponse['usage'][] = [];
    const warnings: string[] = [];

    for (const round of rounds) {
      try {
        const aiResponse = await executeAIRequest({
          systemPrompt,
          userPrompt: `${round.nudge}\n${payload}`,
          providerConfig: { ...providerConfig, temperature: round.temperature },
        });
        if (aiResponse.usage) usages.push(aiResponse.usage);
        if (aiResponse.truncated) {
          warnings.push(`Round hit the token limit (finishReason: ${aiResponse.finishReason || 'length'}); its votes count for answered cells only.`);
        }
        const list = Array.isArray(aiResponse.parsedJson?.verdicts) ? aiResponse.parsedJson.verdicts : [];
        const votes = new Map<string, string>();
        for (const v of list) {
          if (v && typeof v.questionId === 'string' && typeof v.answer === 'string') {
            votes.set(v.questionId, v.answer.trim());
          }
        }
        voteMaps.push(votes);
      } catch (e: any) {
        warnings.push(`Round failed (${e?.message || e}); continuing with the remaining votes.`);
      }
    }

    if (voteMaps.length === 0) {
      return res.status(502).json({ error: 'All adjudication rounds failed.', warnings });
    }

    // ---- Deterministic validation + majority merge ----
    const verdicts: AdjudicationVerdict[] = cells.map((cell) => {
      const votes = voteMaps.map((m) => m.get(cell.questionId)).filter((v): v is string => !!v);
      if (votes.length === 0) {
        return { questionId: cell.questionId, answer: '', votes: [], agreement: 'none', applied: false, reason: 'No votes returned.' };
      }

      const normalized = votes.map((v) => v.toLowerCase());
      const counts = new Map<string, number>();
      for (const v of normalized) counts.set(v, (counts.get(v) || 0) + 1);
      const [topAnswer, topCount] = [...counts.entries()].sort((a, b) => b[1] - a[1])[0];

      // Restore original casing from the first matching vote.
      const original = votes.find((v) => v.toLowerCase() === topAnswer) || topAnswer;

      // Strict enum validation (#14): the answer must exist in the allowed set.
      let valid = true;
      let reason = '';
      if (cell.optionKeys && cell.optionKeys.length > 0) {
        valid = cell.optionKeys.map((k) => k.toLowerCase()).includes(topAnswer);
        if (!valid) reason = `"${topAnswer}" is not one of the option keys (${cell.optionKeys.join(', ')}).`;
      } else if (cell.wordBankWords && cell.wordBankWords.length > 0) {
        valid = cell.wordBankWords.some((w) => w.toLowerCase() === topAnswer);
        if (!valid) reason = `"${topAnswer}" is not in the word bank.`;
      }

      const agreement: AdjudicationVerdict['agreement'] = topCount === votes.length && votes.length === 3 ? 'unanimous' : topCount >= 2 ? 'majority' : 'none';
      const applied = valid && agreement !== 'none';

      return {
        questionId: cell.questionId,
        answer: applied ? original : '',
        votes,
        agreement,
        applied,
        reason: applied ? undefined : reason || 'No 2/3 agreement between rounds — left for human review.',
      };
    });

    const usage = usages.length
      ? {
          promptTokens: usages.reduce((s, u) => s + (u?.promptTokens || 0), 0),
          completionTokens: usages.reduce((s, u) => s + (u?.completionTokens || 0), 0),
          totalTokens: usages.reduce((s, u) => s + (u?.totalTokens || 0), 0),
        }
      : undefined;

    res.json({ success: true, verdicts, rounds: voteMaps.length, usage, warnings });
  } catch (error: any) {
    console.error('Adjudicate Error:', error);
    res.status(500).json({ error: error.message || 'Adjudication failed.' });
  }
});

// 6. MIRROR POLISH ENDPOINT (optional AI assist for mirror variants)
// Rewrites vocabulary/fill stems so a DIFFERENT candidate word becomes correct.
// Deterministic mirror shuffles remain 100% token-free; this is opt-in polish.
app.post('/api/generate-mirror-polish', async (req, res) => {
  try {
    const { items, providerConfig } = req.body;

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Missing items to polish.' });
    }

    const systemPrompt = `You rewrite exam questions to create a PARALLEL exam variant.
For each item you receive a stem, its correct word, and the other candidate words.
Rewrite the stem MINIMALLY (change at most a few words) so that a DIFFERENT candidate word becomes the correct answer.
Rules:
- Keep the same language, register, and grammatical template.
- The new correct word MUST come from the provided candidates and MUST fit grammatically and semantically.
- Never change proper nouns, numbers, or names.
- Return JSON only: { "items": [ { "questionId": "...", "newStem": "...", "newAnswer": "..." } ] }`;

    const userPrompt = JSON.stringify(
      {
        items: items.slice(0, 40).map((it: any) => ({
          questionId: it.questionId,
          stem: it.stem,
          currentAnswer: it.correctAnswer,
          candidates: it.candidates,
        })),
      },
      null,
      2,
    );

    const aiResponse = await executeAIRequest({ systemPrompt, userPrompt, providerConfig });
    const polish = aiResponse.parsedJson;
    const out = Array.isArray(polish?.items) ? polish.items : [];

    res.json({
      success: true,
      items: out,
      usage: aiResponse.usage,
      warnings: aiResponse.truncated
        ? [`Polish output truncated (finishReason: ${aiResponse.finishReason || 'length'}); some stems were left unchanged.`]
        : [],
    });
  } catch (error: any) {
    console.error('Mirror Polish Error:', error);
    res.status(500).json({ error: error.message || 'Mirror polish failed.' });
  }
});

// 7. JEV JUDGE ENDPOINT (judge-ONLY protocol)
// Jev evaluates state+typed-questions and NEVER authors exam content.
// Native backend: TypeSafe "System One" API (POST {base}/systemone — verified
// for both api.typesafe.ai/v1 and openrouter.ai/api/v1, see JEV_NOTES.md).
// Fallback: the user's existing LLM provider with the same normalized result
// shape, so the feature degrades gracefully (geo-blocks / no key / outage).
app.post('/api/judge', async (req, res) => {
  try {
    // SECURITY: never accept API keys via URL query string (log-leak vector) —
    // same policy as /api/list-models.
    if (req.query.apiKey) {
      return res.status(400).json({
        error: 'API key must be sent in the JSON body — never in the URL query string (it leaks into logs).',
      });
    }

    const { mode = 'judge', state, questions, jevConfig, providerConfig } = req.body || {};

    // Payload guard (fail-safe): the judge state can legitimately carry the
    // whole parsed sheet + raw source (parse verification), but anything this
    // size can never fit a single model call — reject with a clear cause
    // instead of burning billable tokens on a guaranteed failure.
    const stateChars = typeof state === 'string' ? state.length : JSON.stringify(state ?? '').length;
    const MAX_JUDGE_STATE_CHARS = 1_500_000;
    if (stateChars > MAX_JUDGE_STATE_CHARS) {
      return res.status(413).json({
        error: `Judge state is too large (${stateChars} chars; limit ${MAX_JUDGE_STATE_CHARS}). Split the document or verify a smaller part.`,
      });
    }

    if (mode === 'test') {
      // Cheap calibration ping used by Settings → "Test Jev connection".
      const cfg = jevConfig || {};
      if (cfg.enabled) {
        // Diagnostic ping: SINGLE-SHOT wire contract (wireRetries: 0) — same
        // policy as every other test-connection call. The default 120s
        // timeout still applies via aiWire (env AI_TIMEOUT_MS overridable).
        const result = await callNativeJev({
          baseUrl: cfg.baseUrl,
          apiKey: cfg.apiKey,
          model: cfg.model || 'typesafe/jev-1.13',
          state: 'The quick brown fox says OK.',
          questions: { ping: { type: 'noul', instructions: 'Does the state contain the word OK?' } },
          wireRetries: 0,
        });
        if (result.ok) return res.json({ ok: true, backend: result.backend, model: result.model, latencyMs: result.latencyMs, warnings: result.warnings });
        // Native failed — fall through to the LLM fallback when available.
        if (providerConfig) {
          const fb = await judgeViaLLM({
            state: 'The quick brown fox says OK.',
            questions: { ping: { type: 'noul', instructions: 'Does the state contain the word OK? Reply with p.' } },
            providerConfig,
          });
          if (fb.ok) {
            return res.json({ ok: true, backend: fb.backend, model: fb.model, latencyMs: fb.latencyMs, warnings: [...result.warnings, `Native Jev unreachable (${result.error}). Verified the LLM fallback instead.`] });
          }
          return res.status(502).json({ ok: false, error: `Native Jev: ${result.error}. Fallback: ${fb.error}`, warnings: [...result.warnings, ...fb.warnings] });
        }
        return res.status(502).json({ ok: false, error: result.error || 'Jev endpoint unreachable.', warnings: result.warnings });
      }
      // Disabled → test the LLM fallback path only.
      if (providerConfig) {
        const fb = await judgeViaLLM({
          state: 'The quick brown fox says OK.',
          questions: { ping: { type: 'noul', instructions: 'Does the state contain the word OK? Reply with p.' } },
          providerConfig,
        });
        if (fb.ok) return res.json({ ok: true, backend: fb.backend, model: fb.model, latencyMs: fb.latencyMs, warnings: fb.warnings });
        return res.status(502).json({ ok: false, error: fb.error, warnings: fb.warnings });
      }
      return res.status(400).json({ ok: false, error: 'Jev is disabled and no fallback provider is configured.' });
    }

    if (!questions || typeof questions !== 'object' || Object.keys(questions).length === 0) {
      return res.status(400).json({ error: 'No judge questions supplied.' });
    }

    const cfg = jevConfig || {};
    const warnings: string[] = [];

    // ---- 1. Native Jev first (cheapest, fastest, calibrated) ----
    if (cfg.enabled && cfg.baseUrl && cfg.apiKey) {
      const native = await callNativeJev({
        baseUrl: cfg.baseUrl,
        apiKey: cfg.apiKey,
        model: cfg.model || 'typesafe/jev-1.13',
        state,
        questions,
      });
      warnings.push(...native.warnings);
      if (native.ok) {
        return res.json({
          success: true,
          backend: native.backend,
          model: native.model,
          answers: native.answers,
          usage: native.usage,
          calls: 1,
          latencyMs: native.latencyMs,
          warnings,
        });
      }
      warnings.push(`Native Jev unreachable (${native.error}). Falling back to the configured LLM judge.`);
    } else if (cfg.enabled) {
      warnings.push('Jev is enabled but the base URL or API key is missing — using the LLM fallback.');
    }

    // ---- 2. LLM fallback (same contract, works with existing providers) ----
    if (!providerConfig) {
      return res.status(502).json({
        error: 'No judge backend available: native Jev is disabled/unreachable and no fallback provider is configured.',
        warnings,
      });
    }

    const fallback = await judgeViaLLM({ state, questions, providerConfig });
    warnings.push(...fallback.warnings);
    if (!fallback.ok) {
      return res.status(502).json({ error: fallback.error || 'Fallback judge failed.', warnings });
    }

    res.json({
      success: true,
      backend: fallback.backend,
      model: fallback.model,
      answers: fallback.answers,
      usage: fallback.usage,
      calls: 1,
      latencyMs: fallback.latencyMs,
      warnings,
    });
  } catch (error: any) {
    console.error('Judge Error:', error);
    res.status(500).json({ error: error.message || 'Jev judging failed.' });
  }
});

// ============================================================================
// Vision (Idea 3) — image understanding for exam parsing. ALWAYS opt-in: this
// route only fires when the user presses a button in the UI. Provider keys
// arrive per-request in the body and are NEVER persisted server-side.
//   mode 'alts'       → ONE batched call for ALL embedded images of an exam,
//                       index-keyed JSON ({"images": {"img_1": ...}}) — never
//                       prose order.
//   mode 'transcribe' → ONE call per scanned page: verbatim transcription in
//                       reading order with inline [FIGURE near Qn: ...] markers.
// ============================================================================

const MAX_VISION_IMAGES_PER_CALL = 20;
const MAX_VISION_IMAGE_B64 = 6 * 1024 * 1024; // per-image base64 cap
const MAX_VISION_TOTAL_B64 = 40 * 1024 * 1024; // whole-payload cap (express limit is 50mb)

app.post('/api/vision-batch', async (req, res) => {
  try {
    if (req.query.apiKey) {
      return res.status(400).json({
        ok: false,
        error: 'API key must be sent in the JSON body — never in the URL query string (it leaks into logs).',
      });
    }

    const { mode = 'alts', images, instruction, providerConfig } = req.body || {};
    if (!Array.isArray(images) || images.length === 0) {
      return res.status(400).json({ ok: false, error: 'No images supplied.' });
    }
    if (images.length > MAX_VISION_IMAGES_PER_CALL) {
      return res.status(413).json({
        ok: false,
        error: `Too many images in one batch (${images.length}; limit ${MAX_VISION_IMAGES_PER_CALL}). Split the exam.`,
      });
    }

    let totalB64 = 0;
    for (const im of images) {
      const size = typeof im?.data === 'string' ? im.data.length : 0;
      totalB64 += size;
      if (size > MAX_VISION_IMAGE_B64) {
        return res.status(413).json({
          ok: false,
          error: `Image ${im?.id || '?'} is too large (${(size / 1048576).toFixed(1)} MB base64; limit ${(MAX_VISION_IMAGE_B64 / 1048576).toFixed(0)} MB).`,
        });
      }
      if (!im?.id || typeof im.id !== 'string' || typeof im?.data !== 'string') {
        return res.status(400).json({ ok: false, error: 'Every image needs a stable string id and base64 data.' });
      }
    }
    if (totalB64 > MAX_VISION_TOTAL_B64) {
      return res.status(413).json({ ok: false, error: `Batch payload too large (${(totalB64 / 1048576).toFixed(1)} MB).` });
    }
    if (!providerConfig) {
      return res.status(400).json({ ok: false, error: 'No vision provider configured. Set the vision provider in Settings first.' });
    }

    const sanitized = images.map((im: any) => ({
      id: String(im.id),
      mimeType: typeof im.mimeType === 'string' && im.mimeType.startsWith('image/') ? im.mimeType : 'image/jpeg',
      data: String(im.data),
    }));

    let result;
    if (mode === 'transcribe') {
      // Path B — ONE page per call, verbatim reading-order transcription with
      // inline figure markers. Free-form text output (no JSON mime).
      result = await executeAIRequest({
        systemPrompt:
          'You are a precise OCR transcriber for exam papers. Transcribe ALL text on the page VERBATIM in reading order, ' +
          'keeping the original language (Persian stays Persian, English stays English). Preserve question numbers, option ' +
          'letters and marks exactly as printed. Where a figure, table or picture appears, insert an inline marker on its ' +
          'own line right at its position: [FIGURE near Q<N>: <short description>] using the nearest visible question ' +
          'number (or the closest one above it). Output ONLY the transcription — no commentary, no markdown.',
        userPrompt: String(instruction || 'Transcribe this exam page verbatim with inline [FIGURE near Qn: ...] markers.'),
        images: sanitized,
        jsonMode: false,
        providerConfig,
        maxAttempts: 2,
      });
    } else {
      // Path A — ONE batched call, index-keyed structured JSON.
      result = await executeAIRequest({
        systemPrompt:
          'You describe images embedded in school exams for a parser. You receive several labeled images from ONE exam. ' +
          'For each image id: if it contains text (labels, tables, signs, sentences) transcribe that text verbatim; ' +
          'otherwise give a one-line factual description. Keep answers under 40 words, original language. ' +
          'Reply with RAW JSON only: {"images": {"<id>": {"alt": "...", "kind": "text|photo|diagram", "confidence": 0.0-1.0}}}. ' +
          'Every supplied image id MUST appear in the answer map.',
        userPrompt: String(instruction || ''),
        images: sanitized,
        jsonMode: true,
        providerConfig,
        maxAttempts: 3,
      });
    }

    res.json({
      ok: true,
      mode,
      model: result.model,
      rawText: result.rawText,
      parsed: result.parsedJson ?? null,
      truncated: result.truncated,
      finishReason: result.finishReason,
      usage: result.usage,
      latencyMs: result.latencyMs,
    });
  } catch (error: any) {
    console.error('Vision Batch Error:', error?.message || error);
    res.status(500).json({ ok: false, error: error?.message || 'Vision call failed.' });
  }
});

// ============================================================================
// Rule mining (Idea 1) — the AI proposes a rule + expected parse; the corpus
// decides. Validation, grounding, target check and the 50-exam shadow run all
// run locally at zero token cost; the AI pays for exactly ONE call.
// ============================================================================

app.get('/api/mined-rules', (_req, res) => {
  try {
    res.json({ ok: true, rules: loadMinedRules() });
  } catch (error: any) {
    res.status(500).json({ ok: false, error: error.message || 'Failed to load mined rules.' });
  }
});

app.post('/api/mine-rule', async (req, res) => {
  try {
    if (req.query.apiKey) {
      return res.status(400).json({ ok: false, error: 'API key must be sent in the JSON body — never in the URL query string (it leaks into logs).' });
    }
    const { rawText, sourceFile, parseSummary, providerConfig } = req.body || {};
    if (!rawText || typeof rawText !== 'string') {
      return res.status(400).json({ ok: false, error: 'No rawText supplied — re-parse the exam in this session first.' });
    }
    const report = await mineRule({
      rawText,
      sourceFile,
      parseSummary: Array.isArray(parseSummary) ? (parseSummary as ParseSummarySection[]) : undefined,
      providerConfig,
    });
    const httpStatus = report.ok ? 200 : 422;
    res.status(httpStatus).json(report);
  } catch (error: any) {
    console.error('Mine Rule Error:', error);
    res.status(500).json({ ok: false, error: error.message || 'Rule mining failed.' });
  }
});

app.post('/api/mined-rules/status', (req, res) => {
  try {
    const { id, status } = req.body || {};
    if (!id || typeof id !== 'string') return res.status(400).json({ ok: false, error: 'Missing rule id.' });
    const allowed: MinedRuleStatus[] = ['proposed', 'shadow', 'live', 'retired'];
    if (!allowed.includes(status)) return res.status(400).json({ ok: false, error: `status must be one of ${allowed.join(', ')}` });
    const out = changeRuleStatus(id, status as MinedRuleStatus);
    if (!out.ok) return res.status(409).json({ ok: false, error: out.error, rules: out.rules });
    res.json({ ok: true, rules: out.rules });
  } catch (error: any) {
    res.status(500).json({ ok: false, error: error.message || 'Status change failed.' });
  }
});

// Mount Vite middleware for fast frontend serving
async function startServer() {
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });

  app.use(vite.middlewares);

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ExaParse Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
