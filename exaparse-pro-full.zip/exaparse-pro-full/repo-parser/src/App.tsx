/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Sidebar, ScreenId } from './components/Sidebar';
import { DashboardScreen } from './components/DashboardScreen';
import { ParseScreen } from './components/ParseScreen';
import { BatchScreen } from './components/BatchScreen';
import { LibraryScreen } from './components/LibraryScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { ExamDetailScreen } from './components/ExamDetailScreen';
import { WizardScreen } from './components/WizardScreen';
import { ExamDocument, QuestionItem, JevJudgeReceipt, VisionReceipt } from './types/exam';
import { ProviderConfig, DEFAULT_PROVIDER_CONFIG, JevConfig, DEFAULT_JEV_CONFIG, VisionConfig, DEFAULT_VISION_CONFIG } from './types/settings';
import {
  loadExams,
  saveExams,
  saveExam,
  deleteExam as deleteExamFromDb,
  loadSettings,
  saveSettings,
  loadJevConfig,
  saveJevConfig,
  loadVisionConfig,
  saveVisionConfig,
} from './utils/storage';
import { MOTAHARI_STAGE1_OFFLINE, BUSHEHR_STAGE1_OFFLINE } from './data/offlineSampleData';
import { MOTAHARI_GRADE9_EXAM, BUSHEHR_GRADE12_EXAM } from './data/sampleExamData';
import { sanitizeExam, sanitizeExamList } from './utils/sanitizeExam';
import { fingerprintsForDocument, cacheGetMany, cachePutMany, answerFingerprint } from './utils/answerCache';
import { useSurfaceFilter } from './utils/useSurfaceFilter';
import { setSurfaceFilterSettings } from './utils/surfaceFilter';
import { resolveGrade } from './utils/curriculum';
import { attachProducedAnswer, unresolvedProducerIds } from './utils/answerFlow';
import { applyAttribution, computeAndApplyDifficulty } from './utils/attribution';
import { runProducerCritic } from './utils/producerCritic';
import { FinalReviewGrid } from './components/FinalReviewGrid';
import { findExemplarsForDocument, recordCorrection } from './utils/correctionMemory';
import { recordSolveReceipt, recordJudgeReceipt } from './utils/usageStore';
import { refreshInvariants } from './utils/invariants';
import { applyTrust } from './utils/trustEngine';
import { judgeDocument, applyJudgements } from './utils/jevJudge';
import { verifyParse, applyParseVerdicts, acceptParseVerdictByHuman } from './utils/parseVerifier';
import { ImageAltsModal } from './components/ImageAltsModal';
import { runPageTranscription, visionCapabilities } from './utils/visionFlow';
import { parseAsync } from './utils/parsePipeline';
import { migrateDocumentList } from './utils/migrations';
import { configureMinedRules } from './utils/ruleMiner';
import { pushHistory } from './utils/examHistory';
import { saveResumeState } from './utils/diagnostics';
import { collectContestedCells, applyAdjudication } from './utils/adjudicator';

export default function App() {
  // The wizard is home (#16): one dropzone. Power screens are one click away.
  const [currentScreen, setCurrentScreen] = useState<ScreenId>('wizard');
  const [parseInitialTab, setParseInitialTab] = useState<string>('upload');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [upgradeNotice, setUpgradeNotice] = useState<string | null>(null);

  // Persistent Multi-Exam Store
  const [documents, setDocuments] = useState<ExamDocument[]>([
    MOTAHARI_STAGE1_OFFLINE,
    MOTAHARI_GRADE9_EXAM,
    BUSHEHR_STAGE1_OFFLINE,
    BUSHEHR_GRADE12_EXAM,
  ]);
  const [activeDocumentId, setActiveDocumentId] = useState<string>(MOTAHARI_STAGE1_OFFLINE.id);

  // Persistent Settings
  const [providerConfig, setProviderConfig] = useState<ProviderConfig>(DEFAULT_PROVIDER_CONFIG);
  const [jevConfig, setJevConfig] = useState<JevConfig>(DEFAULT_JEV_CONFIG);
  const [visionConfig, setVisionConfig] = useState<VisionConfig>(DEFAULT_VISION_CONFIG);
  // Surface filter (D4) — pub-sub store; App only mirrors it for Settings.
  const surfaceFilter = useSurfaceFilter();
  const [isSolvingAi, setIsSolvingAi] = useState<boolean>(false);

  // Load from IndexedDB / Storage on startup
  useEffect(() => {
    async function initStorage() {
      try {
        const [savedExams, savedSettings] = await Promise.all([
          loadExams(),
          loadSettings(),
        ]);
        if (savedExams && savedExams.length > 0) {
          // Migration chain (#20): old shapes upgrade transparently, with a receipt.
          const { docs, changes, upgraded } = migrateDocumentList(savedExams);
          setDocuments(docs);
          setActiveDocumentId(docs[0]?.id || MOTAHARI_STAGE1_OFFLINE.id);
          if (upgraded > 0) {
            setUpgradeNotice(
              `${upgraded} saved exam${upgraded > 1 ? 's' : ''} upgraded to the current format — ${changes.length} improvement${changes.length > 1 ? 's' : ''}, nothing lost.`,
            );
            saveExams(docs);
          }
        }
        if (savedSettings) {
          setProviderConfig(savedSettings);
        }
        setJevConfig(loadJevConfig());
        setVisionConfig(loadVisionConfig());
      } catch (e) {
        console.warn('Storage initialization error:', e);
      }
    }
    initStorage();
  }, []);

  // Crash-safe resume bookkeeping (#19)
  useEffect(() => {
    saveResumeState({ activeDocId: activeDocumentId, screen: currentScreen });
  }, [activeDocumentId, currentScreen]);

  // Mined-rules layer (Idea 1): fetch the live rules once per session and
  // configure the parse pipeline. Fail-soft: if the API is unreachable the
  // app keeps parsing with the deterministic rules alone (empty mined layer).
  useEffect(() => {
    fetch('/api/mined-rules')
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`))))
      .then((d) => {
        if (Array.isArray(d?.rules)) configureMinedRules(d.rules);
      })
      .catch(() => {
        /* offline: deterministic-only parse is the correct fallback */
      });
  }, []);

  // Auto-dismiss the upgrade notice
  useEffect(() => {
    if (!upgradeNotice) return;
    const t = setTimeout(() => setUpgradeNotice(null), 8000);
    return () => clearTimeout(t);
  }, [upgradeNotice]);

  const activeDocument = documents.find((d) => d.id === activeDocumentId) || documents[0];

  // Navigate helper
  const handleNavigate = (screen: ScreenId, initialTab?: string) => {
    if (initialTab) {
      setParseInitialTab(initialTab);
    }
    setCurrentScreen(screen);
  };

  // Select an exam and open its Exam Detail screen
  const handleSelectExam = (examId: string) => {
    setActiveDocumentId(examId);
    setCurrentScreen('detail');
  };

  // Add parsed exam(s) to store & storage.
  // Every document is sanitized before it touches state: parse pipelines and
  // batch imports may produce partial structures that the screens assume exist.
  const handleExamParsed = (newExam: ExamDocument) => {
    const safeExam = sanitizeExam(newExam);
    setDocuments((prev) => {
      const filtered = prev.filter((d) => d.id !== safeExam.id);
      return [safeExam, ...filtered];
    });
    saveExam(safeExam);
    setActiveDocumentId(safeExam.id);
    setCurrentScreen('detail');
  };

  const handleAddBatchExams = (newExams: ExamDocument[]) => {
    const safeExams = sanitizeExamList(newExams);
    if (safeExams.length === 0) return;
    // Side effects stay OUT of the state updater — an updater must stay pure
    // (React may run it during render; saveExams inside it caused the
    // "setState during render" warning chain into HistoryScrubber).
    setDocuments((prev) => {
      const existingIds = new Set(safeExams.map((e) => e.id));
      const remaining = prev.filter((d) => !existingIds.has(d.id));
      return [...safeExams, ...remaining];
    });
    saveExams(safeExams);
  };

  const handleUpdateDocument = (updated: ExamDocument, label = 'Manual edit') => {
    const safeUpdated = sanitizeExam(updated);
    // Time travel (#13): record the PREVIOUS state as a labeled transaction.
    // pushHistory synchronously notifies HistoryScrubber's subscription — it
    // MUST run outside the setDocuments updater, or React raises
    // "Cannot update a component (HistoryScrubber) while rendering App".
    const current = documents.find((d) => d.id === safeUpdated.id);
    if (current) pushHistory(current, label);
    setDocuments((prev) => prev.map((d) => (d.id === safeUpdated.id ? safeUpdated : d)));
    saveExam(safeUpdated);
  };

  const handleDeleteDocument = (id: string) => {
    setDocuments((prev) => prev.filter((d) => d.id !== id));
    deleteExamFromDb(id);
    if (activeDocumentId === id && documents.length > 1) {
      const remaining = documents.filter((d) => d.id !== id);
      setActiveDocumentId(remaining[0]?.id || '');
    }
  };

  // Save Settings
  const handleSaveSettings = async (newConfig: ProviderConfig) => {
    setProviderConfig(newConfig);
    await saveSettings(newConfig);
  };

  // Save Jev judge settings
  const handleSaveJevConfig = async (newConfig: JevConfig) => {
    setJevConfig(newConfig);
    saveJevConfig(newConfig);
  };

  // Save vision settings (no API key here — the provider key rides per-request)
  const handleSaveVisionConfig = async (newConfig: VisionConfig) => {
    setVisionConfig(newConfig);
    saveVisionConfig(newConfig);
  };

  // Surface filter (D4): show full header fields = power-user opt-in
  const handleSaveSurfaceFilter = async (showFull: boolean) => {
    setSurfaceFilterSettings({ showFullHeaderFields: showFull });
  };

  // Solve & Enhance with AI using configured provider — AI-as-referee flow:
  // cache pre-lookup + exemplars go WITH the request; the server pre-solves
  // deterministically and only bills tokens for contested questions.
  const handleSolveWithAi = async (doc: ExamDocument) => {
    setIsSolvingAi(true);
    try {
      // 1. Semantic cache pre-lookup (free answers for repeated questions)
      const allQuestions = doc.sections.flatMap((s) => s.questions);
      const fpMap = fingerprintsForDocument(allQuestions);
      const cached = await cacheGetMany([...fpMap.values()]);
      const cachedAnswers = allQuestions
        .filter((q) => cached.get(fpMap.get(q.id)!))
        .map((q) => ({ questionId: q.id, answer: cached.get(fpMap.get(q.id)!)!.answer }));

      // 2. Correction memory: the teacher's own past fixes as few-shot exemplars
      const exemplars = await findExemplarsForDocument(
        allQuestions.map((q) => ({ stem: q.stem, type: q.type })),
      );

      const res = await fetch('/api/enhance-exam', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          exam: doc,
          providerConfig,
          cachedAnswers,
          exemplars,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const solvedDoc = sanitizeExam(data.document);
        handleUpdateDocument(refreshInvariants(solvedDoc));

        // 3. Persist new answers into the semantic cache for next time
        const newFps = solvedDoc.sections.flatMap((s) => s.questions)
          .filter((q) => q.correctAnswer && q.correctAnswer.trim())
          .map((q) => ({ fingerprint: answerFingerprint(q.type, q.stem, q.options), answer: q.correctAnswer!, type: q.type }));
        await cachePutMany(newFps);

        // 4. AI receipts → usage store (all-time + monthly intervention rate)
        if (data.usage) await recordSolveReceipt(data.usage);

        // 5. Surface the referee stats instead of hiding them
        const parts: string[] = [];
        if (data.heuristicSolved > 0) parts.push(`${data.heuristicSolved} solved by the deterministic matching engine`);
        if (data.cacheHits > 0) parts.push(`${data.cacheHits} reused from the answer cache`);
        if (data.aiSolved > 0) parts.push(`${data.aiSolved} solved by AI (${data.usage?.totalTokens ?? '?'} tokens, saved ${data.usage?.savedPct ?? 0}%)`);
        const summary = parts.length > 0 ? parts.join(' • ') : 'No answers were filled.';
        const reviewNote = Array.isArray(data.changes) && data.changes.length > 0
          ? `\n\n${data.changes.length} change(s) are awaiting your review in the exam detail screen.`
          : '';
        alert(`Solve complete — ${summary}.${reviewNote}${Array.isArray(data.warnings) && data.warnings.length ? '\n\n⚠ ' + data.warnings.join('\n') : ''}`);
      } else {
        const errData = await res.json().catch(() => ({}));
        alert(`AI Enhancement & Solve failed: ${errData.error || res.statusText}`);
      }
    } catch (e: any) {
      alert(`Network error during solve: ${e.message}`);
    } finally {
      setIsSolvingAi(false);
    }
  };

  // ---- Jev judge (judge-ONLY): evaluate solved questions, cascade escalations ----
  const [isJudging, setIsJudging] = useState<boolean>(false);
  const handleJevJudge = async (doc: ExamDocument, forceRejudgeIds?: Set<string>) => {
    setIsJudging(true);
    try {
      const result = await judgeDocument(doc, jevConfig, providerConfig, { forceRejudgeIds });

      if (!result.ok && result.error) {
        // Graceful: judging is optional — never break the pipeline.
        alert(`Jev judging unavailable: ${result.error}`);
        return;
      }

      // 1. Stamp verdicts (immutable) + receipt, then refresh trust levels.
      let next = applyJudgements(doc, result.judgements);
      const receipt: JevJudgeReceipt = {
        ranAt: new Date().toISOString(),
        backend: result.stats.backend === 'jev' ? 'jev' : 'llm-fallback',
        model: result.stats.model,
        judged: result.stats.judged,
        cacheHits: result.stats.cacheHits,
        skipped: result.stats.skipped,
        calls: result.stats.calls,
        escalated: result.escalations.length,
        promptTokens: result.stats.promptTokens,
        completionTokens: result.stats.completionTokens,
        totalTokens: result.stats.totalTokens,
        threshold: jevConfig.threshold,
        warnings: result.warnings.slice(0, 10),
      };
      next = { ...next, jevReceipt: receipt };
      next = applyTrust(next);
      handleUpdateDocument(next, `Jev judged ${result.stats.judged + result.stats.cacheHits} question(s)`);

      // 2. Efficiency receipt → usage store ("Judged 63 questions in 3 Jev calls").
      await recordJudgeReceipt({
        judged: result.stats.judged,
        cacheHits: result.stats.cacheHits,
        calls: result.stats.calls,
        totalTokens: result.stats.totalTokens,
        escalated: result.escalations.length,
      });

      // 3. Confidence cascade: ONLY mid-band questions go to the 3-vote adjudicator.
      let escalApplied = 0;
      if (result.escalations.length > 0 && jevConfig.autoEscalate && providerConfig) {
        try {
          const res = await fetch('/api/adjudicate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cells: result.escalations, providerConfig }),
          });
          if (res.ok) {
            const data = await res.json();
            const verdicts = Array.isArray(data.verdicts) ? data.verdicts : [];
            const applied = applyAdjudication(next, verdicts);
            escalApplied = applied.changes.length;
            if (escalApplied > 0) {
              handleUpdateDocument(
                {
                  ...applied.doc,
                  review: {
                    changes: [...(next.review?.changes || []), ...applied.changes],
                    updatedAt: new Date().toISOString(),
                  },
                },
                `Jev escalation (${escalApplied} adjudicated)`,
              );
            }
          }
        } catch {
          // Escalation is best-effort; the verdicts stay on the questions either way.
        }
      }

      const parts = [
        `Judged ${result.stats.judged + result.stats.cacheHits} questions in ${result.stats.calls} judge call${result.stats.calls === 1 ? '' : 's'}`,
        result.stats.cacheHits > 0 ? `${result.stats.cacheHits} served from the local cache (0 tokens)` : null,
        `${result.stats.correct} confirmed correct • ${result.stats.incorrect} flagged likely-wrong • ${result.stats.uncertain} uncertain`,
        escalApplied > 0 ? `${escalApplied} escalated verdict(s) applied as pending redlines` : result.escalations.length > 0 ? `${result.escalations.length} uncertain question(s) left for your review` : null,
        `${result.stats.totalTokens} judge tokens`,
      ].filter(Boolean);
      alert(
        `Jev judging complete:

• ${parts.join('\n• ')}

Jev never wrote an answer — every flagged question is reviewable in the question list.` +
          (result.warnings.length ? `\n
⚠ ${result.warnings.slice(0, 4).join('\n')}` : ''),
      );
    } catch (e: any) {
      alert(`Jev judging failed gracefully: ${e?.message || e}`);
    } finally {
      setIsJudging(false);
    }
  };

  // ---- Parse verification (consensus gate): the WHOLE parsed sheet + the raw
  // source ride to Jev in ONE call; every question gets true/false verdicts on
  // type / separation / metadata. parser-true ∧ JEV-true → accepted; any
  // disagreement → flagged into the Exam Doctor validation queue.
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const handleVerifyParse = async (doc: ExamDocument, forceIds?: Set<string>) => {
    setIsVerifying(true);
    try {
      const result = await verifyParse(doc, jevConfig, providerConfig, { forceIds });

      if (!result.ok) {
        // Fail-safe: verification is optional — never break the offline parse.
        alert(`Parse verification unavailable: ${result.error || 'no verdicts were produced.'}`);
        return;
      }

      let next = applyParseVerdicts(doc, result.verdicts, result.receipt);
      next = applyTrust(next);
      handleUpdateDocument(next, `Jev verified parse (${result.receipt?.questionsChecked || 0} question(s))`);

      const r = result.receipt;
      const parts: (string | null)[] = r
        ? [
            `${r.questionsChecked} question(s) checked in ${r.calls} judge call${r.calls === 1 ? '' : 's'}`,
            r.cacheHits > 0 ? `${r.cacheHits} served from the local cache (0 tokens)` : null,
            `${r.accepted} accepted — parser and Jev agree`,
            `${r.flagged} flagged for validation`,
            r.unverified > 0 ? `${r.unverified} unverified (no verdict returned)` : null,
            `${r.totalTokens} tokens`,
          ]
        : [];
      alert(
        `Parse verification complete:\n\n• ${parts.filter(Boolean).join('\n• ')}\n\n` +
          (r && r.flagged > 0
            ? `${r.flagged} flagged question(s) are waiting in the Exam Doctor tab (parse verification queue). Nothing was changed automatically.`
            : 'Every checked question passed the consensus gate.') +
          (result.warnings.length ? `\n\n⚠ ${result.warnings.slice(0, 4).join('\n')}` : ''),
      );
    } catch (e: any) {
      alert(`Parse verification failed gracefully: ${e?.message || e}`);
    } finally {
      setIsVerifying(false);
    }
  };

  // Human validation-queue decision: accept the parse of one flagged question.
  const handleAcceptParseVerdict = (doc: ExamDocument, questionId: string) => {
    const next = applyTrust(acceptParseVerdictByHuman(doc, questionId));
    handleUpdateDocument(next, `Parse accepted by human review (${questionId})`);
  };

  // ---- M4 staged answer flow (the agreed complete flow, orchestrated):
  // R1 whole-sheet verify + answer + attribute -> R3 producer-critic for the
  // unresolved -> everything lands in the Final Review grid as DRAFTS with
  // provenance. NOTHING commits silently; auto-accept stays calibration-gated.
  const [isAnswering, setIsAnswering] = useState<boolean>(false);
  const [finalReviewOpen, setFinalReviewOpen] = useState<boolean>(false);
  const handleRunAnswerFlow = async (doc: ExamDocument) => {
    setIsAnswering(true);
    try {
      // Grade resolution: ambiguous/unknown -> attribution axes silently skip
      // (never guess a grade — the Final Review shows the resolver state).
      const resolution = resolveGrade(doc.header);
      const attribution = resolution.status === 'resolved' && resolution.key ? { gradeKey: resolution.key } : undefined;

      // Answer key PRINTED ON THE SHEET: the parse already separated the key
      // into metadata and applied its answers with official provenance (see
      // utils/answerKey.ts). AI answer production is SKIPPED entirely — Jev
      // still verifies question separation + metadata, the key mapping was
      // validated at parse time (warnings land in Final Review), and metrics
      // run as usual. Uncovered questions (no key entry) still route to R3.
      const keyOnFile = !!doc.answerKeyOnFile?.detected && doc.answerKeyOnFile.applied > 0;

      // ---- R1: verify + answer (a:) + attribute (l1/l2/b/c) in ONE call ----
      const r1 = await verifyParse(doc, jevConfig, providerConfig, { attribution, skipAnswerAxis: keyOnFile });
      if (!r1.ok && r1.verdicts.size === 0) {
        alert(`Answer flow could not start: ${r1.error || 'no backend available.'}`);
        return;
      }
      let next = applyParseVerdicts(doc, r1.verdicts, r1.receipt);
      next = applyTrust(next);
      if (!keyOnFile) {
        for (const [qid, pick] of r1.answers) {
          next = attachProducedAnswer(next, qid, {
            value: pick.value,
            source: 'r1',
            provenance: 'ai-draft',
            jevVerified: false,
            producedAt: new Date().toISOString(),
            model: r1.receipt?.model || 'unknown',
          });
        }
      }
      for (const [qid, attr] of r1.attributions) {
        next = applyAttribution(next, qid, attr);
        next = computeAndApplyDifficulty(next, qid);
      }

      // ---- R3: producer-critic for EVERYTHING still unresolved ----
      const r3Ids = unresolvedProducerIds(next);
      if (r3Ids.length > 0) {
        const r3 = await runProducerCritic(next, r3Ids, jevConfig, providerConfig);
        if (r3.ok) {
          for (const [qid, ans] of r3.answers) next = attachProducedAnswer(next, qid, ans);
          for (const [qid, pair] of r3.mediations) {
            const target = next.sections.flatMap((s) => s.questions).find((q) => q.id === qid);
            if (target) {
              next = {
                ...next,
                sections: next.sections.map((s) => ({
                  ...s,
                  questions: s.questions.map((q) => (q.id === qid ? { ...q, answerMediation: { aiAnswer: pair.aiAnswer, jevAnswer: pair.jevAnswer, status: 'pending' as const } } : q)),
                })),
              };
            }
          }
          next = { ...next, answerFlowReceipt: r3.receipt };
        } else {
          alert(`Producer-critic step failed (fail-safe): ${r3.error}. R1 drafts are kept.`);
        }
      }

      handleUpdateDocument(
        sanitizeExam(next),
        keyOnFile
          ? `Answer flow run — printed key applied (${doc.answerKeyOnFile!.applied} official answers, AI production skipped)`
          : 'Answer flow run — drafts in Final Review (nothing auto-committed)',
      );
      setFinalReviewOpen(true);
    } catch (e: any) {
      alert(`Answer flow failed gracefully: ${e?.message || e}`);
    } finally {
      setIsAnswering(false);
    }
  };

  // ---- Vision (Idea 3) — image understanding. EVERY call below is opt-in:
  // triggered by an explicit button; nothing runs automatically on parse.
  const [showImagesModal, setShowImagesModal] = useState<boolean>(false);

  // Commit the reviewed alts/placements from the image editor, then run the
  // TWO-PHASE Jev pass 2: ONLY the questions that were skipped in pass 1
  // ("unchecked / awaiting image alt") are sent now, forced by id. Nothing is
  // verified twice — pass-1 verdicts ride the content cache untouched.
  const handleApplyVision = async (doc: ExamDocument, _receipt: VisionReceipt | null, pendingIdsBefore: string[]) => {
    const safe = sanitizeExam(doc);
    handleUpdateDocument(applyTrust(safe), 'Vision alts applied (human-reviewed)');

    const stillPending = new Set(safe.sections.flatMap((s) => s.questions.filter((q) => q.imgPending).map((q) => q.id)));
    const pass2Ids = pendingIdsBefore.filter((id) => !stillPending.has(id));
    if (pass2Ids.length === 0) return;

    try {
      const result = await verifyParse(safe, jevConfig, providerConfig, { forceIds: new Set(pass2Ids) });
      if (!result.ok) {
        console.warn('Vision pass-2 verification unavailable:', result.error);
        return; // fail-soft: alts are already saved; the user can Verify Parse manually
      }
      let next = applyParseVerdicts(safe, result.verdicts, result.receipt);
      next = applyTrust(next);
      handleUpdateDocument(next, `Jev pass-2 verified ${pass2Ids.length} image-dependent question(s)`);
    } catch (e: any) {
      console.warn('Vision pass-2 verification failed:', e?.message || e);
    }
  };

  // Path B — scanned-page vision transcription (opt-in button), then a re-parse
  // through the OFFLINE parser. SOLVE is never triggered by this flow.
  const [isTranscribing, setIsTranscribing] = useState<boolean>(false);
  const handleVisionTranscribe = async (doc: ExamDocument) => {
    const pages = doc.header.pageCount || 1;
    const ok = window.confirm(
      `Vision re-transcription (opt-in)\n\n` +
        `Each of the ${pages} scanned page(s) goes to your vision provider as ONE transcription call ` +
        `(verbatim reading order, inline [FIGURE near Qn] markers), then the transcript is RE-PARSED by the ` +
        `offline parser — no answers are solved. Pages are cached by content hash, so re-runs are free.\n\n` +
        `The current parse stays untouched until the new one is ready. Continue?`,
    );
    if (!ok) return;
    setIsTranscribing(true);
    try {
      const res = await runPageTranscription(doc, {
        providerConfig,
        visionConfig,
        onProgress: (note) => console.log('[vision-transcribe]', note),
      });
      if (!res.ok || !res.pages) {
        alert(`Vision transcription failed gracefully: ${res.error || 'no transcripts.'}${res.warnings.length ? '\n\n⚠ ' + res.warnings.slice(0, 3).join('\n') : ''}`);
        return;
      }
      const transcript = res.pages.map((p) => p.text).join('\n\n');
      const result = await parseAsync({ rawText: transcript, filename: doc.filename }, (u) =>
        console.log('[vision-reparse]', u.status),
      );
      if (!result.ok) {
        alert(`The transcript could not be parsed automatically: ${result.error}\n\nThe original parse is unchanged — you can open the transcript from the receipt and paste it manually.`);
        return;
      }
      const cachedCount = res.pages.filter((p) => p.cached).length;
      const next = {
        ...result.doc,
        sourceFile: doc.sourceFile,
        visionReceipt: res.receipt,
        pictureOcrNotes: [
          ...(doc.pictureOcrNotes || []),
          `Vision transcription replaced the offline OCR text: ${res.pages.length} page(s) transcribed (${res.pages.length - cachedCount} call(s), ${cachedCount} cache hit(s), ${res.receipt?.totalTokens ?? 0} tokens).`,
        ].slice(0, 20),
      };
      handleExamParsed(next);
      alert(
        `Vision transcription complete:\n\n• ${res.pages.length} page(s) transcribed (${cachedCount} from cache, ${res.receipt?.totalTokens ?? 0} tokens)\n` +
          `• The transcript was re-parsed by the OFFLINE parser (no AI solving)\n` +
          `• [FIGURE] markers rode inline, so image-dependent questions are detected automatically\n` +
          (res.warnings.length ? `\n⚠ ${res.warnings.slice(0, 3).join('\n')}` : ''),
      );
    } catch (e: any) {
      alert(`Vision transcription failed gracefully: ${e?.message || e}`);
    } finally {
      setIsTranscribing(false);
    }
  };

  // ---- Redline review decisions (#5): every decision teaches the memory ----
  const applyReviewDecision = (updated: ExamDocument, label = 'Review decision') => {
    handleUpdateDocument(refreshInvariants(updated), label);
  };

  const handleDecideChange = async (doc: ExamDocument, changeId: string, decision: 'approved' | 'rejected') => {
    const change = doc.review?.changes.find((c) => c.id === changeId);
    if (!change) return;

    let next: ExamDocument;
    if (decision === 'rejected') {
      // Revert the field to its pre-solve value
      next = {
        ...doc,
        sections: doc.sections.map((sec) => ({
          ...sec,
          questions: sec.questions.map((q) => {
            if (q.id !== change.questionId) return q;
            if (change.field === 'correctAnswer') {
              return { ...q, correctAnswer: change.before, answerMeta: undefined };
            }
            return { ...q, type: change.before as QuestionItem['type'] };
          }),
        })),
      };
    } else {
      next = doc;
    }

    next = {
      ...next,
      review: {
        changes: next.review?.changes.map((c) =>
          c.id === changeId ? { ...c, status: decision, decidedAt: new Date().toISOString() } : c,
        ) || [],
        updatedAt: new Date().toISOString(),
      },
    };
    applyReviewDecision(next);

    // Teach the correction memory (approved = AI was right, rejected = teacher fixed it)
    const question = doc.sections.flatMap((s) => s.questions).find((q) => q.id === change.questionId);
    await recordCorrection({
      questionType: question?.type || 'unknown',
      stem: change.stem || question?.stem || '',
      before: change.before,
      after: decision === 'rejected' ? change.before : change.after,
      field: change.field,
      examId: doc.id,
      // D4: school identity is not correction-memory data by default.
      schoolName: surfaceFilter.showFullHeaderFields ? doc.header?.schoolName : undefined,
    });
  };

  // ---- AI Adjudicator (#14/#15): strict-enum, 3-vote, contested cells only ----
  const [isAdjudicating, setIsAdjudicating] = useState<boolean>(false);
  const handleAdjudicate = async (doc: ExamDocument) => {
    const cells = collectContestedCells(doc);
    if (cells.length === 0) {
      alert('No resolvable contested cells right now. Every MCQ/word-bank question already has an answer or is verified.');
      return;
    }
    setIsAdjudicating(true);
    try {
      const res = await fetch('/api/adjudicate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cells, providerConfig }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        alert(`Adjudication failed: ${err.error || res.statusText}`);
        return;
      }
      const data = await res.json();
      const verdicts = Array.isArray(data.verdicts) ? data.verdicts : [];
      const applied = applyAdjudication(doc, verdicts);
      const appliedCount = applied.changes.length;
      const rejected = verdicts.filter((v: any) => !v.applied).length;

      applyReviewDecision(
        {
          ...applied.doc,
          review: {
            changes: [...(doc.review?.changes || []), ...applied.changes],
            updatedAt: new Date().toISOString(),
          },
        },
        `AI adjudication (${appliedCount} verdicts)`,
      );

      const votes = verdicts.filter((v: any) => v.agreement === 'unanimous').length;
      alert(
        `Adjudication complete (3-vote protocol):\n\n` +
          `• ${appliedCount} verdict(s) applied and awaiting your review\n` +
          `• ${votes} unanimous (3/3)\n` +
          `• ${rejected} discarded — outside the allowed option keys / word bank, or no 2/3 agreement.\n\n` +
          `The AI never wrote content: every verdict was validated against the question's own option keys or word bank.`,
      );
    } catch (e: any) {
      alert(`Network error during adjudication: ${e.message}`);
    } finally {
      setIsAdjudicating(false);
    }
  };

  const handleDecideAll = async (doc: ExamDocument, decision: 'approved' | 'rejected') => {
    const pending = doc.review?.changes.filter((c) => c.status === 'pending') || [];
    let next = doc;
    for (const change of pending) {
      await handleDecideChange(next, change.id, decision);
      // handleDecideChange already updated state via applyReviewDecision; rebuild locally
      next = {
        ...next,
        review: {
          changes: (next.review?.changes || []).map((c) =>
            c.id === change.id ? { ...c, status: decision } : c,
        ),
        updatedAt: new Date().toISOString(),
        },
      };
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500 selection:text-white overflow-hidden">
      {/* Persistent Collapsible Sidebar */}
      <Sidebar
        currentScreen={currentScreen}
        onNavigate={(screen) => handleNavigate(screen)}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        providerConfig={providerConfig}
        totalExams={documents.length}
      />

      {/* Main Screen Body */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Upgrade notice (#20): upgrades are visible proof, not silent rewrites */}
        {upgradeNotice && (
          <div className="flex items-center justify-between gap-3 px-4 py-2.5 bg-emerald-950/40 border-b border-emerald-800/50">
            <span className="text-xs text-emerald-300">✓ {upgradeNotice}</span>
            <button onClick={() => setUpgradeNotice(null)} className="text-emerald-400/70 hover:text-emerald-300 text-xs">
              Dismiss
            </button>
          </div>
        )}

        <main className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 py-6">
          {currentScreen === 'wizard' && (
            <WizardScreen
              onExamParsed={handleExamParsed}
              onOpenLibrary={() => setCurrentScreen('library')}
              onOpenAdvanced={() => {
                setParseInitialTab('upload');
                setCurrentScreen('parse');
              }}
              hasExams={documents.length > 0}
            />
          )}

          {currentScreen === 'dashboard' && (
            <DashboardScreen
              exams={documents}
              providerConfig={providerConfig}
              onNavigate={handleNavigate}
              onSelectExam={handleSelectExam}
            />
          )}

          {currentScreen === 'parse' && (
            <ParseScreen
              initialTab={parseInitialTab}
              providerConfig={providerConfig}
              onExamParsed={handleExamParsed}
            />
          )}

          {currentScreen === 'batch' && (
            <BatchScreen
              providerConfig={providerConfig}
              onAddExamsToLibrary={handleAddBatchExams}
              onOpenExamDetail={handleSelectExam}
            />
          )}

          {currentScreen === 'library' && (
            <LibraryScreen
              exams={documents}
              providerConfig={providerConfig}
              onSelectExam={handleSelectExam}
              onUpdateExam={handleUpdateDocument}
              onDeleteExam={handleDeleteDocument}
              onImportExams={handleAddBatchExams}
              onSolveExam={handleSolveWithAi}
            />
          )}

          {currentScreen === 'settings' && (
            <SettingsScreen
              config={providerConfig}
              onSaveConfig={handleSaveSettings}
              jevConfig={jevConfig}
              onSaveJevConfig={handleSaveJevConfig}
              visionConfig={visionConfig}
              onSaveVisionConfig={handleSaveVisionConfig}
              showFullHeaderFields={surfaceFilter.showFullHeaderFields}
              onSaveShowFullHeaderFields={handleSaveSurfaceFilter}
            />
          )}

          {currentScreen === 'detail' && activeDocument && (
            <ExamDetailScreen
              document={activeDocument}
              allDocuments={documents}
              onBackToLibrary={() => setCurrentScreen('library')}
              onUpdateDocument={(updated, label) => handleUpdateDocument(updated, label)}
              onSolveWithAi={handleSolveWithAi}
              isSolvingAi={isSolvingAi}
              onDecideChange={(changeId, decision) => handleDecideChange(activeDocument, changeId, decision)}
              onDecideAll={(decision) => handleDecideAll(activeDocument, decision)}
              onAdjudicate={handleAdjudicate}
              isAdjudicating={isAdjudicating}
              onJevJudge={handleJevJudge}
              isJudging={isJudging}
              onVerifyParse={handleVerifyParse}
              isVerifying={isVerifying}
              onAcceptParseVerdict={(questionId) => handleAcceptParseVerdict(activeDocument, questionId)}
              jevEnabled={jevConfig.enabled}
              providerConfig={providerConfig}
              onAddExamToLibrary={handleExamParsed}
              onOpenImages={() => setShowImagesModal(true)}
              onVisionTranscribe={() => handleVisionTranscribe(activeDocument)}
              isTranscribing={isTranscribing}
              visionCaps={visionCapabilities(activeDocument)}
              onRunAnswerFlow={handleRunAnswerFlow}
              isAnswering={isAnswering}
              onOpenFinalReview={() => setFinalReviewOpen(true)}
            />
          )}

          {finalReviewOpen && activeDocument && (
            <FinalReviewGrid
              document={activeDocument}
              calibration={null}
              onUpdateDocument={(updated, label) => handleUpdateDocument(updated, label)}
              onClose={() => setFinalReviewOpen(false)}
            />
          )}
        </main>
      </div>

      {/* Vision image review editor (Idea 3) — mounted at app level so it can
          overlay any screen while the active document stays in place. */}
      {showImagesModal && activeDocument && (
        <ImageAltsModal
          document={activeDocument}
          providerConfig={providerConfig}
          visionConfig={visionConfig}
          onClose={() => setShowImagesModal(false)}
          onApply={(doc, receipt, pendingIds) => {
            setShowImagesModal(false);
            handleApplyVision(doc, receipt, pendingIds);
          }}
        />
      )}
    </div>
  );
}
