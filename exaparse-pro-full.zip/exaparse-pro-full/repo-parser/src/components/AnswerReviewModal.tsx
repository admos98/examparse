import React, { useState } from 'react';
import { X, Check, XCircle, GitCompareArrows, Cpu, Wrench, Database, Info } from 'lucide-react';
import { AnswerChange, ExamDocument } from '../types/exam';

/**
 * Redline review (#5) — "AI proposes, you dispose."
 *
 * Every AI/heuristic edit surfaces as a pending change with before → after.
 * Approving keeps it AND teaches the correction memory; rejecting reverts the
 * field and teaches the memory what this teacher prefers instead.
 */

interface AnswerReviewModalProps {
  document: ExamDocument;
  onDecide: (change: AnswerChange, decision: 'approved' | 'rejected') => void;
  onDecideAll: (decision: 'approved' | 'rejected') => void;
  onClose: () => void;
}

const METHOD_BADGE: Record<AnswerChange['method'], { icon: React.ComponentType<{ className?: string }>; label: string; cls: string }> = {
  ai: { icon: Cpu, label: 'AI', cls: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30' },
  heuristic: { icon: Wrench, label: 'Deterministic', cls: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' },
  cache: { icon: Database, label: 'Cache', cls: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
};

export const AnswerReviewModal: React.FC<AnswerReviewModalProps> = ({ document, onDecide, onDecideAll, onClose }) => {
  const changes = document.review?.changes || [];
  const pending = changes.filter((c) => c.status === 'pending');
  const [filter, setFilter] = useState<'pending' | 'all'>('pending');
  const shown = filter === 'pending' ? pending : changes;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-3xl max-h-[85vh] flex flex-col rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
              <GitCompareArrows className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Review AI Changes</h2>
              <p className="text-xs text-slate-400">
                {pending.length > 0
                  ? `${pending.length} change${pending.length > 1 ? 's' : ''} awaiting your decision — every decision teaches the correction memory.`
                  : 'No pending changes. All decisions recorded.'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Bulk actions */}
        {pending.length > 0 && (
          <div className="flex items-center gap-2 px-5 py-3 border-b border-slate-800 bg-slate-950/50">
            <button
              onClick={() => onDecideAll('approved')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition"
            >
              <Check className="w-3.5 h-3.5" /> Approve all ({pending.length})
            </button>
            <button
              onClick={() => onDecideAll('rejected')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold transition"
            >
              <XCircle className="w-3.5 h-3.5" /> Reject all
            </button>
            <div className="ml-auto">
              <button
                onClick={() => setFilter(filter === 'pending' ? 'all' : 'pending')}
                className="text-[11px] font-semibold text-indigo-400 hover:text-indigo-300 transition"
              >
                {filter === 'pending' ? 'Show decided too' : 'Show pending only'}
              </button>
            </div>
          </div>
        )}

        {/* Change list */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3">
          {shown.length === 0 && (
            <div className="text-center py-10 space-y-2">
              <Info className="w-8 h-8 text-slate-600 mx-auto" />
              <p className="text-xs text-slate-500">Nothing to review here.</p>
            </div>
          )}
          {shown.map((change) => {
            const badge = METHOD_BADGE[change.method] || METHOD_BADGE.ai;
            const BadgeIcon = badge.icon;
            const decided = change.status !== 'pending';
            return (
              <div
                key={change.id}
                className={`p-4 rounded-xl border transition-all ${
                  change.status === 'approved'
                    ? 'bg-emerald-950/20 border-emerald-800/50'
                    : change.status === 'rejected'
                    ? 'bg-slate-950/60 border-slate-800 opacity-70'
                    : 'bg-slate-950 border-slate-700'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 justify-between pb-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${badge.cls}`}>
                      <BadgeIcon className="w-3 h-3" /> {badge.label}
                    </span>
                    <span className="text-xs font-semibold text-slate-200">
                      Q{change.questionNumber} • Section {change.sectionRowId}
                    </span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                      {change.field === 'correctAnswer' ? 'answer' : 'question type'}
                    </span>
                    {decided && (
                      <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${change.status === 'approved' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-700 text-slate-400'}`}>
                        {change.status}
                      </span>
                    )}
                  </div>
                  {!decided && (
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => onDecide(change, 'approved')}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600/90 hover:bg-emerald-500 text-white text-[11px] font-bold transition"
                      >
                        <Check className="w-3 h-3" /> Keep
                      </button>
                      <button
                        onClick={() => onDecide(change, 'rejected')}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-[11px] font-semibold transition"
                      >
                        <XCircle className="w-3 h-3" /> Revert
                      </button>
                    </div>
                  )}
                </div>

                {change.stem && (
                  <p className="text-[11px] text-slate-400 truncate pb-2">{change.stem}</p>
                )}

                <div className="flex items-center gap-2 font-mono text-xs">
                  <span className={`px-2 py-1 rounded-lg border ${change.status === 'rejected' ? 'bg-slate-900 border-slate-800 text-slate-500' : 'bg-red-950/30 border-red-900/50 text-red-300 line-through decoration-red-500/50'}`}>
                    {change.before || '(empty)'}
                  </span>
                  <span className="text-slate-600">→</span>
                  <span className={`px-2 py-1 rounded-lg border ${change.status === 'rejected' ? 'bg-slate-900 border-slate-800 text-slate-500 line-through' : 'bg-emerald-950/30 border-emerald-900/50 text-emerald-300 font-bold'}`}>
                    {change.after || '(empty)'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
