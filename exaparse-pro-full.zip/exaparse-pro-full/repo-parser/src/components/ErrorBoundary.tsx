import React from 'react';

interface ErrorBoundaryState {
  error: Error | null;
}

/**
 * Last-resort crash guard. Previously a single malformed exam (e.g. an old or
 * foreign JSON import without `header`) threw during render and white-screened
 * the entire app with no recovery path. With this boundary the user gets a
 * readable error screen and can reload — or wipe the corrupt persisted data
 * that is often the root cause — without losing the rest of the UI.
 */
export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, ErrorBoundaryState> {
  state: ErrorBoundaryState = { error: null };

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('ExaParse crashed inside ErrorBoundary:', error, info.componentStack);
  }

  handleReload = () => {
    window.location.reload();
  };

  handleClearStorageAndReload = () => {
    try {
      localStorage.removeItem('exaparse_exams');
      localStorage.removeItem('exaparse_provider_config');
      if (typeof indexedDB !== 'undefined') {
        const req = indexedDB.deleteDatabase('ExaParseStorage');
        req.onsuccess = req.onerror = req.onblocked = () => window.location.reload();
        return;
      }
    } catch (e) {
      console.warn('Could not clear storage', e);
    }
    window.location.reload();
  };

  render() {
    if (this.state.error) {
      return (
        <div className="min-h-screen bg-slate-950 text-slate-200 flex items-center justify-center p-6">
          <div className="max-w-lg w-full p-8 rounded-2xl bg-slate-900 border border-red-500/30 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center text-xl font-bold">
                !
              </div>
              <h1 className="text-lg font-bold text-white">Something went wrong</h1>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              The app hit an unexpected error while rendering — most likely a malformed exam document
              (e.g. an old or hand-edited JSON import). Your parsed data is still on disk; reloading
              usually fixes this.
            </p>
            <pre className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-[11px] text-red-300 whitespace-pre-wrap break-words max-h-40 overflow-y-auto font-code">
              {this.state.error.message || String(this.state.error)}
            </pre>
            <div className="flex flex-col sm:flex-row gap-2 pt-1">
              <button
                onClick={this.handleReload}
                className="flex-1 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition"
              >
                Reload App
              </button>
              <button
                onClick={this.handleClearStorageAndReload}
                className="flex-1 px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold transition"
                title="Removes locally saved exams & settings, then reloads"
              >
                Clear Saved Data &amp; Reload
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
