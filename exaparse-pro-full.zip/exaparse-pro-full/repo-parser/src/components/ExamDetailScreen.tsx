import React, { useState } from 'react';
import {
  ArrowLeft,
  Sparkles,
  Download,
  RotateCcw,
  CheckCircle2,
  Clock,
  BookOpen,
  GitCompareArrows,
  Copy,
  ShieldCheck,
  Zap,
  Loader2,
  Scale,
  BadgeCheck,
  ScanSearch,
  ImageIcon,
  ScanText,
} from 'lucide-react';
import { ExamDocument, QuestionItem } from '../types/exam';
import { TabsNav } from './TabsNav';
import { PipelineStageBanner } from './PipelineStageBanner';
import { QuestionBankView } from './QuestionBankView';
import { DocumentViewer } from './DocumentViewer';
import { ContextGraphView } from './ContextGraphView';
import { ExamDoctor } from './ExamDoctor';
import { XRayViewer } from './XRayViewer';
import { ArchitectureGuide } from './ArchitectureGuide';
import { QuestionDetailModal } from './QuestionDetailModal';
import { PassageModal } from './PassageModal';
import { ExportModal } from './ExportModal';
import { AnswerReviewModal } from './AnswerReviewModal';
import { MirrorModal } from './MirrorModal';
import { TrustSummaryBadge } from './TrustChips';
import { HistoryScrubber } from './HistoryScrubber';
import { exportTrustPack } from '../utils/exporter';
import { surfaceHeader } from '../utils/surfaceFilter';
import { runConsensusCheck } from '../utils/consensus';
import { refreshInvariants } from '../utils/invariants';
import { computeTrust, applyTrust } from '../utils/trustEngine';
import { ProviderConfig } from '../types/settings';
import { getParseSource } from '../utils/miningSession';
import { createOfflineUnsolvedDocument } from '../data/offlineSampleData';

interface ExamDetailScreenProps {
  document: ExamDocument;
  allDocuments: ExamDocument[];
  onBackToLibrary: () => void;
  onUpdateDocument: (updated: ExamDocument, label?: string) => void;
  onSolveWithAi: (doc: ExamDocument) => Promise<void>;
  isSolvingAi: boolean;
  onDecideChange: (changeId: string, decision: 'approved' | 'rejected') => void;
  onDecideAll: (decision: 'approved' | 'rejected') => void;
  /** AI Adjudicator (#14/#15): 3-vote strict-enum on contested cells. */
  onAdjudicate: (doc: ExamDocument) => Promise<void>;
  isAdjudicating: boolean;
  /** Jev judge (judge-ONLY): calibrated second opinion, cascade escalations. */
  onJevJudge: (doc: ExamDocument, forceRejudgeIds?: Set<string>) => Promise<void>;
  isJudging: boolean;
  /** Parse verification (consensus gate): whole sheet + raw source, ONE call. */
  onVerifyParse: (doc: ExamDocument, forceIds?: Set<string>) => Promise<void>;
  isVerifying: boolean;
  /** Human validation-queue decision on one flagged question. */
  onAcceptParseVerdict: (questionId: string) => void;
  jevEnabled: boolean;
  providerConfig: ProviderConfig;
  onAddExamToLibrary: (exam: ExamDocument) => void;
  /** Vision (Idea 3): open the image alts review editor. */
  onOpenImages?: () => void;
  /** Vision (Idea 3): scanned-page transcription (opt-in, per-page calls). */
  onVisionTranscribe?: () => void;
  isTranscribing?: boolean;
  /** Which vision flows make sense for this source file. */
  visionCaps?: { alts: boolean; transcribe: boolean };
  /** M4 staged answer flow: R1 + R3 with drafts (never auto-committed). */
  onRunAnswerFlow?: (doc: ExamDocument) => Promise<void>;
  isAnswering?: boolean;
  /** M4 open the Final Review grid (everything lands here — decision D1). */
  onOpenFinalReview?: () => void;
}

export const ExamDetailScreen: React.FC<ExamDetailScreenProps> = ({
  document,
  allDocuments,
  onBackToLibrary,
  onUpdateDocument,
  onSolveWithAi,
  isSolvingAi,
  onDecideChange,
  onDecideAll,
  onAdjudicate,
  isAdjudicating,
  onJevJudge,
  isJudging,
  onVerifyParse,
  isVerifying,
  onAcceptParseVerdict,
  jevEnabled,
  providerConfig,
  onAddExamToLibrary,
  onOpenImages,
  onVisionTranscribe,
  isTranscribing,
  visionCaps,
  onRunAnswerFlow,
  isAnswering,
  onOpenFinalReview,
}) => {
  const [activeTab, setActiveTab] = useState<string>('questions');
  const [showExportModal, setShowExportModal] = useState<boolean>(false);
  const [showReviewModal, setShowReviewModal] = useState<boolean>(false);
  const [showMirrorModal, setShowMirrorModal] = useState<boolean>(false);
  const [consensusBusy, setConsensusBusy] = useState<boolean>(false);
  const [editingQuestion, setEditingQuestion] = useState<QuestionItem | null>(null);
  const [viewingPassage, setViewingPassage] = useState<{ title: string; text: string } | null>(null);

  const isSolved = document.isAiSolved || document.parseStage === 'stage2_ai_solved';
  const pendingReviewCount = document.review?.changes.filter((c) => c.status === 'pending').length || 0;
  const openInvariantCount = document.invariants?.violations.filter((v) => !v.isFixed).length || 0;
  const unresolvedCount = document.anomalies.filter((a) => !a.isResolved).length + openInvariantCount;

  // Trust summary (#9): live when chips are stale (e.g. after edits).
  const liveTrust = computeTrust(document);
  const contestedCount = liveTrust.summary.contested;
  // Jev affordance: how many solved questions the judge can evaluate.
  const judgableCount = (() => {
    let n = 0;
    for (const sec of document.sections) {
      for (const q of sec.questions) {
        if (q.stem && q.stem.trim() && q.correctAnswer && q.correctAnswer.trim()) n++;
      }
    }
    return n;
  })();
  const judgedCount = (() => {
    let n = 0;
    for (const sec of document.sections) for (const q of sec.questions) if (q.jev) n++;
    return n;
  })();
  // Parse-verification counts (consensus gate over the parse itself).
  const parseFlaggedCount = (() => {
    let n = 0;
    for (const sec of document.sections)
      for (const q of sec.questions) if (q.parseVerdict?.verdict === 'flagged' && !q.parseVerdict.humanReviewed) n++;
    return n;
  })();
  const parseAcceptedCount = (() => {
    let n = 0;
    for (const sec of document.sections) for (const q of sec.questions) if (q.parseVerdict?.verdict === 'accepted') n++;
    return n;
  })();
  // Vision (Idea 3): images awaiting review + questions still pending an alt.
  const imagesReviewCount = (document.images || []).filter(
    (i) => i.placementStatus === 'review' || i.placementStatus === 'unplaced' || (!i.alt && !i.reviewed),
  ).length;
  const imgPendingCount = (() => {
    let n = 0;
    for (const sec of document.sections) for (const q of sec.questions) if (q.imgPending) n++;
    return n;
  })();

  // Handle anomaly resolution
  const handleResolveAnomaly = (anomalyId: string) => {
    const updatedAnomalies = document.anomalies.map((a) =>
      a.id === anomalyId ? { ...a, isResolved: true } : a,
    );
    const remainingUnresolved = updatedAnomalies.filter((a) => !a.isResolved).length;
    const newScore = remainingUnresolved === 0 ? 100 : Math.min(100, document.confidenceScore + 0.8);

    const next = applyTrust(
      {
        ...document,
        anomalies: updatedAnomalies,
        confidenceScore: Math.round(newScore * 10) / 10,
      },
      computeTrust({ ...document, anomalies: updatedAnomalies }),
    );
    onUpdateDocument(next, 'Resolve finding');
  };

  // Handle question edit
  const handleSaveQuestion = (updated: QuestionItem) => {
    const nextSections = document.sections.map((sec) => {
      if (sec.rowId !== updated.sectionRowId) return sec;
      return {
        ...sec,
        questions: sec.questions.map((q) => (q.id === updated.id ? updated : q)),
      };
    });
    const next = applyTrust({ ...document, sections: nextSections }, computeTrust({ ...document, sections: nextSections }));
    onUpdateDocument(next, `Edit question ${updated.displayNumber}`);
  };

  // Revert to Stage 1 raw
  const handleRevertToOfflineRaw = () => {
    const raw = createOfflineUnsolvedDocument(document);
    onUpdateDocument({
      ...raw,
      id: document.id,
    });
  };

  // Dual-extraction consensus (#3): two independent offline paths, diffed
  const handleConsensusCheck = async () => {
    if (!document.sourceFile || consensusBusy) return;
    setConsensusBusy(true);
    try {
      const { report, message } = await runConsensusCheck(document.sourceFile);
      if (report) {
        onUpdateDocument({ ...document, consensus: report });
        alert(
          `Consensus check complete (${report.method}).\n\n` +
            `Agreement: ${report.agreementRate}% across ${report.checks.length} comparisons.\n` +
            (report.disagreements > 0
              ? `${report.disagreements} disagreement(s) — see the Exam Doctor tab.`
              : 'Both extraction paths fully agree.'),
        );
      } else {
        alert(message || 'Consensus check did not produce a report for this file type.');
      }
    } catch (e: any) {
      alert(`Consensus check failed: ${e?.message || e}`);
    } finally {
      setConsensusBusy(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToLibrary}
            className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700 transition"
            title="Back to Exam Library"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h1 className="text-base sm:text-lg font-extrabold text-white">
                {document.header.examName || document.header.courseName}
              </h1>
              <TrustSummaryBadge
                verified={liveTrust.summary.verified}
                single={liveTrust.summary.single}
                contested={liveTrust.summary.contested}
                total={liveTrust.summary.total}
              />
              {document.header.examName && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  <Sparkles className="w-2.5 h-2.5 text-indigo-400" /> AI Exam Title
                </span>
              )}
              {isSolved ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  <CheckCircle2 className="w-3 h-3" /> Stage 2: AI-Solved
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  <Clock className="w-3 h-3" /> Stage 1: Offline Raw (Unsolved)
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-400 mt-1 flex-wrap">
              {/* D4: school identity hidden unless the power-user toggle is on */}
              {surfaceHeader(document.header).schoolName && (
                <span className="font-semibold text-slate-300">{surfaceHeader(document.header).schoolName}</span>
              )}
              {surfaceHeader(document.header).schoolName && <span>•</span>}
              <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[11px] font-medium border border-slate-700">
                {document.header.grade || document.header.gradeAndMajor}
              </span>
              {document.header.term && (
                <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[11px] font-medium border border-slate-700">
                  نوبت: {document.header.term}
                </span>
              )}
              <span>•</span>
              <span className="font-mono text-slate-500">{document.filename}</span>
            </div>
          </div>
        </div>

        {/* Header Action Buttons */}
        <div className="flex items-center gap-2 self-end sm:self-center flex-wrap justify-end">
          <HistoryScrubber document={document} onApply={(doc, label) => onUpdateDocument(doc, label)} />

          {document.totalQuestions > 0 && (
            <button
              onClick={() => onRunAnswerFlow?.(document)}
              disabled={isAnswering}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl disabled:opacity-50 text-xs font-semibold border transition bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border-indigo-500/30"
              title="The complete flow: R1 verify + answer + lesson/difficulty attribution in ONE judge call, then R3 producer-critic for the rest. Everything lands in the Final Review grid as DRAFTS with provenance — nothing commits silently."
            >
              {isAnswering ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ScanSearch className="w-3.5 h-3.5" />}
              <span>{isAnswering ? 'Answering...' : 'Verify & Answer'}</span>
            </button>
          )}

          {(document.answerFlowReceipt || document.sections.some((s) => s.questions.some((q) => q.answer || q.answerMediation))) && (
            <button
              onClick={() => onOpenFinalReview?.()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition bg-fuchsia-600/20 hover:bg-fuchsia-600/30 text-fuchsia-300 border-fuchsia-500/30"
              title="Final review: answer drafts with provenance, lesson attribution, difficulty and mediation pairs. The single surface where everything lands (human = authoritative)."
            >
              <span>Final Review</span>
            </button>
          )}

          {document.totalQuestions > 0 && (
            <button
              onClick={() => onVerifyParse(document)}
              disabled={isVerifying}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl disabled:opacity-50 text-xs font-semibold border transition ${
                parseFlaggedCount > 0
                  ? 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border-amber-500/40'
                  : 'bg-teal-600/20 hover:bg-teal-600/30 text-teal-300 border-teal-500/30'
              }`}
              title="Parse verification (consensus gate): the whole parsed sheet + the raw source text go to Jev in ONE call. Every question is answered true/false on type, separation and metadata (word banks judged as the whole bank). parser+Jev agreement = accepted; any disagreement = flagged into the Exam Doctor validation queue. Cached by content — re-runs are near-free."
            >
              {isVerifying ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ScanSearch className="w-3.5 h-3.5" />}
              <span>{isVerifying ? 'Verifying...' : 'Verify Parse'}</span>
              {!isVerifying && parseAcceptedCount > 0 && (
                <span className="text-[9px] font-mono opacity-70">{parseAcceptedCount}✓</span>
              )}
              {parseFlaggedCount > 0 && !isVerifying && (
                <span className="text-[9px] font-mono font-bold">{parseFlaggedCount}⚠</span>
              )}
            </button>
          )}

          {judgableCount > 0 && (
            <button
              onClick={() => onJevJudge(document)}
              disabled={isJudging}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 disabled:opacity-50 text-cyan-300 text-xs font-semibold border border-cyan-500/30 transition"
              title="Jev judge (judge-only): a calibrated decision model re-checks every solved answer with typed questions — P(correct), category, well-formedness. It never writes answers; uncertain ones escalate to the 3-vote adjudicator. Cached by content, so re-runs are near-free."
            >
              {isJudging ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <BadgeCheck className="w-3.5 h-3.5" />}
              <span>{isJudging ? 'Judging...' : jevEnabled ? `Jev Judge ${judgableCount}` : `Judge ${judgableCount} (fallback)`}</span>
              {judgedCount > 0 && !isJudging && <span className="text-[9px] font-mono opacity-70">{judgedCount}✓</span>}
            </button>
          )}

          {visionCaps?.alts && (
            <button
              onClick={() => onOpenImages?.()}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition ${
                imagesReviewCount + imgPendingCount > 0
                  ? 'bg-fuchsia-600/25 hover:bg-fuchsia-600/35 text-fuchsia-200 border-fuchsia-500/40 animate-pulse'
                  : 'bg-fuchsia-600/15 hover:bg-fuchsia-600/25 text-fuchsia-300 border-fuchsia-500/30'
              }`}
              title="Vision image understanding (opt-in): ONE batched call transcribes text inside embedded images or describes them; alts are placed by POSITION and are always editable here. Low-confidence placements wait for your review. Cached by content hash — re-runs are free."
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Image alts</span>
              {imagesReviewCount + imgPendingCount > 0 && (
                <span className="text-[9px] font-mono font-bold">{imagesReviewCount + imgPendingCount}⚠</span>
              )}
            </button>
          )}

          {visionCaps?.transcribe && (
            <button
              onClick={() => onVisionTranscribe?.()}
              disabled={isTranscribing}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-violet-600/20 hover:bg-violet-600/30 disabled:opacity-50 text-violet-300 text-xs font-semibold border border-violet-500/30 transition"
              title="Vision re-transcription (opt-in, Persian-grade): each scanned page is transcribed verbatim in reading order with inline [FIGURE near Qn] markers, then re-parsed by the OFFLINE parser. One call per page, cached by content hash. Tesseract stays the offline English fallback."
            >
              {isTranscribing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ScanText className="w-3.5 h-3.5" />}
              <span>{isTranscribing ? 'Transcribing...' : 'Vision re-transcribe'}</span>
            </button>
          )}

          {contestedCount > 0 && (
            <button
              onClick={() => onAdjudicate(document)}
              disabled={isAdjudicating}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600/20 hover:bg-sky-600/30 disabled:opacity-50 text-sky-300 text-xs font-semibold border border-sky-500/30 transition"
              title="AI Adjudicator: 3 independent votes on contested cells, strictly limited to each question's own option keys / word bank. Every applied verdict needs your approval."
            >
              {isAdjudicating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Scale className="w-3.5 h-3.5" />}
              <span>{isAdjudicating ? 'Adjudicating...' : `Adjudicate ${contestedCount}`}</span>
            </button>
          )}

          {pendingReviewCount > 0 && (
            <button
              onClick={() => setShowReviewModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-bold border border-amber-500/40 transition animate-pulse"
            >
              <GitCompareArrows className="w-3.5 h-3.5" />
              Review {pendingReviewCount} change{pendingReviewCount > 1 ? 's' : ''}
            </button>
          )}

          <button
            onClick={() => setShowMirrorModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 text-xs font-semibold border border-purple-500/30 transition"
            title="Create a parallel exam variant (mirror)"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>Mirror</span>
          </button>

          {document.sourceFile && (
            <button
              onClick={handleConsensusCheck}
              disabled={consensusBusy}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 disabled:opacity-50 text-slate-300 text-xs font-semibold border border-slate-700 transition"
              title="Run two independent offline extractions and diff them (0 tokens)"
            >
              {consensusBusy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
              <span>{consensusBusy ? 'Checking...' : 'Consensus'}</span>
            </button>
          )}

          <button
            onClick={() => exportTrustPack(document)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 text-xs font-semibold border border-emerald-500/30 transition"
            title="ZIP: exam JSON + Excel + self-contained verification report"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Trust Pack</span>
          </button>

          {!isSolved ? (
            <button
              disabled={isSolvingAi}
              onClick={() => onSolveWithAi(document)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 transition"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isSolvingAi ? 'Solving with AI...' : 'Solve with AI'}</span>
            </button>
          ) : (
            <button
              onClick={handleRevertToOfflineRaw}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-semibold border border-slate-700 transition"
              title="Strip answers to inspect Stage 1 offline AST"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Revert to Raw</span>
            </button>
          )}

          <button
            onClick={() => setShowExportModal(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold border border-slate-700 transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* Tabs Navigation */}
      <TabsNav
        activeTab={activeTab}
        onTabChange={setActiveTab}
        anomaliesCount={unresolvedCount}
        totalQuestions={document.totalQuestions}
        hasSourceFile={!!document.sourceFile}
      />

      {/* Stage 1 vs Stage 2 Pipeline Banner */}
      <PipelineStageBanner
        document={document}
        onSolveWithAi={() => onSolveWithAi(document)}
        onResetToOffline={handleRevertToOfflineRaw}
        isSolving={isSolvingAi}
      />

      {/* Main Tab Content */}
      <div className="space-y-6">
        {activeTab === 'questions' && (
          <QuestionBankView
            document={document}
            onEditQuestion={(q) => setEditingQuestion(q)}
            onSelectPassage={(title, text) => setViewingPassage({ title, text })}
          />
        )}

        {activeTab === 'document' && (
          <DocumentViewer
            document={document}
            onSelectQuestion={(q) => setEditingQuestion(q)}
          />
        )}

        {activeTab === 'context' && (
          <ContextGraphView
            document={document}
            onSelectQuestion={(q) => setEditingQuestion(q)}
          />
        )}

        {activeTab === 'anomalies' && (
          <ExamDoctor
            document={document}
            onResolveAnomaly={handleResolveAnomaly}
            onUpdateDocument={onUpdateDocument}
            onSelectTab={setActiveTab}
            onRejudge={(questionId) => onJevJudge(document, new Set([questionId]))}
            onAcceptParseVerdict={onAcceptParseVerdict}
            onRecheckVerdict={(questionId) => onVerifyParse(document, new Set([questionId]))}
            isVerifying={isVerifying}
            mining={{ providerConfig, rawText: getParseSource(document.id) }}
            onOpenImages={onOpenImages}
          />
        )}

        {activeTab === 'xray' && (
          <XRayViewer document={document} onSelectQuestion={(q) => setEditingQuestion(q)} />
        )}

        {activeTab === 'architecture' && <ArchitectureGuide />}
      </div>

      {/* Modals */}
      {showExportModal && (
        <ExportModal
          document={document}
          documents={allDocuments}
          onClose={() => setShowExportModal(false)}
        />
      )}

      {showReviewModal && (
        <AnswerReviewModal
          document={document}
          onDecide={(change, decision) => onDecideChange(change.id, decision)}
          onDecideAll={onDecideAll}
          onClose={() => setShowReviewModal(false)}
        />
      )}

      {showMirrorModal && (
        <MirrorModal
          document={document}
          providerConfig={providerConfig}
          onClose={() => setShowMirrorModal(false)}
          onCreate={(mirror) => {
            setShowMirrorModal(false);
            onAddExamToLibrary(refreshInvariants(mirror));
          }}
        />
      )}

      {editingQuestion && (
        <QuestionDetailModal
          question={editingQuestion}
          document={document}
          onSave={handleSaveQuestion}
          onClose={() => setEditingQuestion(null)}
        />
      )}

      {viewingPassage && (
        <PassageModal
          title={viewingPassage.title}
          text={viewingPassage.text}
          onClose={() => setViewingPassage(null)}
        />
      )}
    </div>
  );
};
