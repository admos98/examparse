import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Wrench,
  Check,
  Sparkles,
  Info,
  ShieldCheck,
  Stethoscope,
  Printer,
  Zap,
  ScanSearch,
  UserCheck,
  RefreshCw,
  Bot,
  GitBranch,
  ImageIcon,
} from 'lucide-react';
import { ExamDocument, InvariantViolation } from '../types/exam';
import { applyInvariantFix, refreshInvariants } from '../utils/invariants';
import { computeTrust, UnifiedFinding } from '../utils/trustEngine';
import { flaggedQuestions } from '../utils/parseVerifier';
import { surfaceHeader } from '../utils/surfaceFilter';
import { MinedRule, MinedRuleStatus } from '../utils/ruleMiner';

/**
 * Exam Doctor (#15) — triage inbox for everything deterministic checks know:
 * invariant violations with one-click fixes + the original teacher-drafting
 * anomalies + a printable QA report. "The exam doctor" replaces the old
 * anomaly list with actionable, provable triage.
 */

interface ExamDoctorProps {
  document: ExamDocument;
  onResolveAnomaly: (anomalyId: string) => void;
  onUpdateDocument: (updated: ExamDocument) => void;
  onSelectTab: (tab: string) => void;
  /** Jev fix action: force a re-judge of one question (bypasses the cache). */
  onRejudge?: (questionId: string) => void;
  /** Parse-verification queue: human accepts the parse of a flagged question. */
  onAcceptParseVerdict?: (questionId: string) => void;
  /** Parse-verification queue: force an AI re-check of one question (bypasses cache). */
  onRecheckVerdict?: (questionId: string) => void;
  isVerifying?: boolean;
  /** Rule-mining support (Idea 1): provider + this session's raw source text. */
  mining?: { providerConfig?: any; rawText?: string };
  /** Vision (Idea 3): open the image alts review editor. */
  onOpenImages?: () => void;
}

const SEVERITY_ORDER: Record<string, number> = { error: 0, warning: 1, info: 2 };

export const ExamDoctor: React.FC<ExamDoctorProps> = ({
  document,
  onResolveAnomaly,
  onUpdateDocument,
  onSelectTab,
  onRejudge,
  onAcceptParseVerdict,
  onRecheckVerdict,
  isVerifying,
  mining,
  onOpenImages,
}) => {
  const violations = useMemo(
    () => [...(document.invariants?.violations || [])].sort((a, b) => (SEVERITY_ORDER[a.severity] ?? 3) - (SEVERITY_ORDER[b.severity] ?? 3)),
    [document.invariants],
  );
  const openViolations = violations.filter((v) => !v.isFixed);
  const anomalies = document.anomalies || [];
  const unresolvedAnomalies = anomalies.filter((a) => !a.isResolved);
  const consensus = document.consensus;

  const handleAutoFix = (v: InvariantViolation) => {
    const fixed = applyInvariantFix(document, v.id);
    onUpdateDocument(refreshInvariants(fixed));
  };

  const handlePrintReport = () => {
    const inv = document.invariants;
    const rows = (openViolations.length > 0 ? openViolations : violations)
      .map(
        (v) => `<tr>
          <td style="padding:6px 10px;border-bottom:1px solid #e2e8f0;font-weight:${v.severity === 'error' ? 700 : 400};color:${v.severity === 'error' ? '#b91c1c' : v.severity === 'warning' ? '#b45309' : '#475569'}">${v.severity}</td>
          <td style="padding:6px 10px;border-bottom:1px solid #e2e8f0">${v.rule}</td>
          <td style="padding:6px 10px;border-bottom:1px solid #e2e8f0">${escapeHtml(v.message)}</td>
          <td style="padding:6px 10px;border-bottom:1px solid #e2e8f0">${escapeHtml(v.suggestedFix || '—')}</td>
        </tr>`,
      )
      .join('');

    const anomalyRows = anomalies
      .map(
        (a) => `<tr>
          <td style="padding:6px 10px;border-bottom:1px solid #e2e8f0;color:${a.severity === 'error' ? '#b91c1c' : '#b45309'}">${escapeHtml(a.severity)}${a.isResolved ? ' ✓' : ''}</td>
          <td style="padding:6px 10px;border-bottom:1px solid #e2e8f0">${escapeHtml(a.title)}</td>
          <td style="padding:6px 10px;border-bottom:1px solid #e2e8f0">${escapeHtml(a.description)}</td>
        </tr>`,
      )
      .join('');

    const html = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>QA Report — ${escapeHtml(document.header.courseName)}</title>
<style>
  body { font-family: system-ui, -apple-system, 'Segoe UI', sans-serif; color:#0f172a; margin: 40px; }
  h1 { font-size: 20px; margin-bottom: 2px; }
  h2 { font-size: 14px; margin-top: 28px; border-bottom: 2px solid #0f172a; padding-bottom: 4px; }
  .meta { color:#475569; font-size: 12px; }
  .badge { display:inline-block; padding:2px 10px; border-radius: 999px; border:1px solid #cbd5e1; font-size:11px; margin-right:6px; }
  table { border-collapse: collapse; width: 100%; font-size: 12px; }
  th { text-align: left; padding: 6px 10px; background: #f1f5f9; border-bottom: 2px solid #cbd5e1; }
  .footer { margin-top: 32px; font-size: 10px; color: #94a3b8; }
  @media print { body { margin: 16px; } }
</style></head>
<body>
  <h1>ExaParse Pro — Quality Assurance Report</h1>
  <div class="meta">
    ${escapeHtml(document.header.examName || document.header.courseName)} •
    ${escapeHtml(surfaceHeader(document.header).schoolName)} •
    ${escapeHtml(document.filename)}<br/>
    Generated ${new Date().toLocaleString()}
  </div>

  <p>
    <span class="badge">Parser confidence: <b>${document.confidenceScore}%</b></span>
    ${inv ? `<span class="badge">Invariants: <b>${inv.passed}/${inv.total}</b> passed</span>` : ''}
    ${document.provenanceCoverage !== undefined ? `<span class="badge">Provenance: <b>${document.provenanceCoverage}%</b> of questions traced</span>` : ''}
    ${consensus ? `<span class="badge">Dual-extraction consensus: <b>${consensus.agreementRate}%</b> (${consensus.disagreements} disagreements)</span>` : ''}
    ${document.aiUsage ? `<span class="badge">AI tokens: <b>${document.aiUsage.totalTokens}</b> (baseline ${document.aiUsage.baselineTokens} — saved ${document.aiUsage.savedPct}%)</span>` : ''}
    <span class="badge">Stage: <b>${document.isAiSolved ? `AI-solved (${document.aiUsage?.aiSolved ?? 0}/${document.totalQuestions} answers by AI)` : 'offline raw'}</b></span>
  </p>

  <h2>Structural Invariants (deterministic — no AI involved)</h2>
  ${
    rows
      ? `<table><thead><tr><th>Severity</th><th>Rule</th><th>Detail</th><th>Suggested fix</th></tr></thead><tbody>${rows}</tbody></table>`
      : `<p class="meta" style="color:#059669;font-weight:600">All invariant checks passed. The document obeys the physics of exams.</p>`
  }

  <h2>Teacher-Drafting Anomalies</h2>
  ${
    anomalyRows
      ? `<table><thead><tr><th>Severity</th><th>Title</th><th>Description</th></tr></thead><tbody>${anomalyRows}</tbody></table>`
      : `<p class="meta">No anomalies recorded.</p>`
  }

  <div class="footer">
    Generated offline by the ExaParse deterministic engine. Invariant checks are proofs, not heuristics:
    sequential numbering, mark arithmetic, MCQ option integrity, matching balance and answer validity are
    verified without any AI involvement. AI (if used) only adjudicated contested cells — see the token receipt.
  </div>
</body></html>`;

    const win = window.open('', '_blank');
    if (win) {
      win.document.write(html);
      win.document.close();
      win.focus();
      setTimeout(() => win.print(), 350);
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Stethoscope className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-bold text-white">Exam Doctor</h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
              provable QA, not guesswork
            </span>
          </div>
          <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
            Deterministic invariant checks are <b className="text-slate-300">proofs</b>: numbering, mark arithmetic, MCQ option integrity,
            matching balance and answer validity — verified with zero AI. Fix violations below before trusting the exports.
          </p>
        </div>

        <div className="flex items-center gap-4 bg-slate-950 p-3 rounded-xl border border-slate-800">
          <div className="text-right">
            <div className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Invariants</div>
            <div className={`text-2xl font-bold font-code ${openViolations.length > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
              {document.invariants ? `${document.invariants.passed}/${document.invariants.total}` : '—'}
            </div>
          </div>
          <div className="h-10 w-px bg-slate-800" />
          <div className="text-left">
            <div className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">Open Flags</div>
            <div className={`text-2xl font-bold font-code ${openViolations.length + unresolvedAnomalies.length > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
              {openViolations.length + unresolvedAnomalies.length}
            </div>
          </div>
        </div>
      </div>

      {/* Actions row */}
      <div className="flex items-center gap-2 flex-wrap">
        <button
          onClick={handlePrintReport}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-semibold transition"
        >
          <Printer className="w-3.5 h-3.5" /> Print QA Report
        </button>
        {document.provenanceCoverage !== undefined && (
          <span className="inline-flex items-center gap-1.5 text-[11px] text-slate-400 px-2 py-1 rounded-lg bg-slate-950 border border-slate-800">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" /> {document.provenanceCoverage}% evidence coverage
          </span>
        )}
        {consensus && (
          <span className={`inline-flex items-center gap-1.5 text-[11px] px-2 py-1 rounded-lg border ${consensus.agreementRate >= 95 ? 'bg-emerald-950/30 border-emerald-800/50 text-emerald-300' : 'bg-amber-950/30 border-amber-800/50 text-amber-300'}`}>
            <Zap className="w-3.5 h-3.5" /> Consensus {consensus.agreementRate}% ({consensus.disagreements} disagreements)
          </span>
        )}
      </div>

      {/* Parse-verification summary chip */}
      {document.parseVerifyReceipt && (
        <div className="flex items-center gap-2 flex-wrap text-[11px]">
          <span
            className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-lg border ${
              document.parseVerifyReceipt.flagged > 0
                ? 'bg-amber-950/30 border-amber-800/50 text-amber-300'
                : 'bg-emerald-950/30 border-emerald-800/50 text-emerald-300'
            }`}
          >
            <ScanSearch className="w-3.5 h-3.5" />
            Parse verified: {document.parseVerifyReceipt.accepted} accepted • {document.parseVerifyReceipt.flagged} flagged •{' '}
            {document.parseVerifyReceipt.totalTokens.toLocaleString()} tokens ({document.parseVerifyReceipt.backend})
          </span>
        </div>
      )}

      {/* Parse-verification validation queue (consensus gate disagreements) */}
      {(() => {
        const queue = flaggedQuestions(document);
        if (queue.length === 0) return null;
        return (
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Parse verification queue — {queue.length} question{queue.length > 1 ? 's' : ''} need{queue.length > 1 ? '' : 's'} validation
            </h3>
            <p className="text-[11px] text-slate-500 -mt-1">
              The parser said this parse is fine, but Jev disagreed (or was unsure) on at least one axis.
              Per the consensus rule, any disagreement requires you or the AI to check. Nothing was changed automatically.
            </p>
            {queue.map(({ q, sectionRowId }) => {
              const v = q.parseVerdict!;
              const axes = [
                !v.typeOk ? 'type' : null,
                !v.separationOk ? 'separation' : null,
                !v.metadataOk ? 'metadata' : null,
              ].filter(Boolean);
              return (
                <div key={q.id} className="p-4 rounded-xl border bg-amber-950/20 border-amber-500/40 space-y-2.5">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                    <div className="min-w-0 space-y-1">
                      <p className="text-xs font-semibold text-slate-100">
                        Question {q.displayNumber} (Section {sectionRowId}) — flagged: {axes.join(', ')}
                      </p>
                      <p className="text-[11px] text-slate-400 truncate">{q.stem || '(empty stem)'}</p>
                      {v.note && <p className="text-[11px] text-amber-300/80">Judge note: {v.note}</p>}
                    </div>
                    <span className="ml-auto text-[9px] font-mono uppercase tracking-wider text-slate-500 shrink-0">
                      {v.backend}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap pl-6">
                    {onRecheckVerdict && (
                      <button
                        onClick={() => onRecheckVerdict(q.id)}
                        disabled={isVerifying}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-[11px] font-bold shadow-sm transition active:scale-95"
                      >
                        <RefreshCw className={`w-3 h-3 ${isVerifying ? 'animate-spin' : ''}`} /> Re-check with AI
                      </button>
                    )}
                    {onAcceptParseVerdict && (
                      <button
                        onClick={() => onAcceptParseVerdict(q.id)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold shadow-sm transition active:scale-95"
                      >
                        <UserCheck className="w-3 h-3" /> Accept as-is
                      </button>
                    )}
                    <button
                      onClick={() => onSelectTab('questions')}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold transition"
                    >
                      Open question
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        );
      })()}

      {/* Vision images review (Idea 3): low-confidence placements + pending alts.
          The review editor is authoritative — nothing auto-placed is final. */}
      {(() => {
        const imgs = document.images || [];
        const needsReview = imgs.filter(
          (i) => i.placementStatus === 'review' || i.placementStatus === 'unplaced' || (!i.alt && !i.reviewed),
        );
        const pending = document.sections.flatMap((s) => s.questions).filter((q) => q.imgPending);
        if (needsReview.length === 0 && pending.length === 0) return null;
        return (
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Images &amp; alts — {needsReview.length} image{needsReview.length === 1 ? '' : 's'} / {pending.length} question{pending.length === 1 ? '' : 's'} awaiting you
            </h3>
            <p className="text-[11px] text-slate-500 -mt-1">
              Vision-generated alts are helpers, not verdicts: low-confidence placements are queued here instead of being
              committed. Questions that depend on an image without an alt were SKIPPED by the Jev check ("unchecked,
              awaiting image alt") and re-verify automatically once you save an alt.
            </p>
            {needsReview.slice(0, 4).map((img) => {
              const owner = img.questionId
                ? document.sections.flatMap((s) => s.questions).find((q) => q.id === img.questionId)
                : undefined;
              return (
                <div key={img.id} className="p-3 rounded-xl border bg-fuchsia-950/20 border-fuchsia-500/30 space-y-1">
                  <div className="flex items-center gap-2">
                    <ImageIcon className="w-3.5 h-3.5 text-fuchsia-300 shrink-0" />
                    <p className="text-xs font-semibold text-slate-100">
                      {img.id}
                      {img.page ? ` (page ${img.page})` : ''}
                      {img.placementStatus === 'review' && owner
                        ? ` — suggested Q${owner.displayNumber} (${Math.round((img.placementConfidence || 0) * 100)}% confidence)`
                        : img.placementStatus === 'unplaced'
                        ? ' — no confident placement'
                        : ''}
                    </p>
                  </div>
                  {img.alt && <p className="text-[11px] text-slate-400 truncate">Alt: {img.alt}</p>}
                  {!img.alt && img.error && <p className="text-[11px] text-rose-300">{img.error}</p>}
                </div>
              );
            })}
            {needsReview.length > 4 && (
              <p className="text-[11px] text-slate-500">…and {needsReview.length - 4} more in the image editor.</p>
            )}
            {onOpenImages && (
              <button
                onClick={onOpenImages}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-fuchsia-600 hover:bg-fuchsia-500 text-white text-[11px] font-bold shadow-sm transition active:scale-95"
              >
                <ImageIcon className="w-3 h-3" /> Review images &amp; alts
              </button>
            )}
          </div>
        );
      })()}

      {/* Mined rules (Idea 1): AI proposes, the corpus decides, human can retire */}
      <MinedRulesPanel
        document={document}
        mining={mining}
        onSelectTab={onSelectTab}
      />

      {/* Unified findings (#11/#12): every source merged, human sentences, fix cards */}
      {(() => {
        const trust = computeTrust(document);
        const findings = trust.findings.filter((f) => f.severity !== 'info').slice(0, 12);
        if (findings.length === 0) return null;
        return (
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Needs your eyes — {findings.length} finding{findings.length > 1 ? 's' : ''} (usually takes seconds)
            </h3>
            {findings.map((f: UnifiedFinding) => (
              <div
                key={f.id}
                className={`p-4 rounded-xl border space-y-2.5 ${
                  f.severity === 'error'
                    ? 'bg-rose-950/20 border-rose-500/40'
                    : 'bg-amber-950/20 border-amber-500/40'
                }`}
              >
                <div className="flex items-start gap-2">
                  {f.severity === 'error' ? (
                    <XCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                  )}
                  <div className="space-y-1 min-w-0">
                    <p className="text-xs font-semibold text-slate-100 leading-relaxed">{f.message}</p>
                    {f.detail && <p className="text-[11px] text-slate-400 leading-relaxed">{f.detail}</p>}
                  </div>
                  <span className="ml-auto text-[9px] font-mono uppercase tracking-wider text-slate-500 shrink-0">
                    {f.source}
                  </span>
                </div>
                {f.actions.length > 0 && (
                  <div className="flex items-center gap-2 flex-wrap pl-6">
                    {f.actions.map((a) => (
                      <button
                        key={a.label}
                        onClick={() => {
                          if (a.kind === 'auto_fix') {
                            const violation = (document.invariants?.violations || []).find((v) => v.id === a.ref);
                            if (violation) handleAutoFix(violation);
                          } else if (a.kind === 'resolve_anomaly') {
                            onResolveAnomaly(a.ref);
                          } else if (a.kind === 'open_question') {
                            onSelectTab('questions');
                          } else if (a.kind === 'rejudge') {
                            if (onRejudge) onRejudge(a.ref);
                            else onSelectTab('questions');
                          } else if (a.kind === 'adjudicate') {
                            onSelectTab('xray');
                          }
                        }}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold shadow-sm transition active:scale-95"
                      >
                        <Wrench className="w-3 h-3" /> {a.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        );
      })()}

      {/* Invariant violations */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Structural Invariant Violations</h3>
        {violations.length === 0 && (
          <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-800/40 flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <div>
              <p className="text-xs font-bold text-emerald-300">All structural checks passed</p>
              <p className="text-[11px] text-slate-400">
                Run a solve or re-parse after edits to refresh the report.
              </p>
            </div>
          </div>
        )}
        {violations.map((v) => {
          const canAutoFix = !!v.autoFix && !v.isFixed;
          return (
            <div
              key={v.id}
              className={`border rounded-xl p-4 transition-all ${
                v.isFixed
                  ? 'bg-slate-900/40 border-slate-800 opacity-70'
                  : v.severity === 'error'
                  ? 'bg-red-950/20 border-red-500/40'
                  : 'bg-amber-950/20 border-amber-500/40'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-800/80">
                <div className="flex items-center gap-2 flex-wrap">
                  {v.isFixed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  ) : v.severity === 'error' ? (
                    <XCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
                  )}
                  <span className="font-bold text-sm text-slate-100">{v.rule.replaceAll('_', ' ')}</span>
                  {v.sectionRowId && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-slate-800 text-slate-300">
                      Row {v.sectionRowId}{v.questionId ? ' • Q' : ''}
                    </span>
                  )}
                  <span className={`px-2 py-0.5 text-[10px] font-semibold uppercase rounded ${
                    v.severity === 'error' ? 'bg-red-500/20 text-red-300' : v.severity === 'warning' ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-700 text-slate-300'
                  }`}>
                    {v.severity}
                  </span>
                </div>
                {canAutoFix && (
                  <button
                    onClick={() => handleAutoFix(v)}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-sm transition active:scale-95"
                  >
                    <Wrench className="w-3.5 h-3.5" /> One-Click Fix
                  </button>
                )}
                {v.isFixed && (
                  <span className="inline-flex items-center gap-1 text-xs text-emerald-400 font-semibold bg-emerald-950/50 px-2 py-1 rounded border border-emerald-800/50">
                    <Check className="w-3.5 h-3.5" /> Fixed
                  </span>
                )}
              </div>
              <div className="mt-3 space-y-2 text-xs">
                <p className="text-slate-300 leading-relaxed">{v.message}</p>
                {v.suggestedFix && (
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-start gap-2">
                    <Sparkles className="w-4 h-4 text-indigo-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-indigo-300">Engine Recommendation: </span>
                      <span className="text-slate-300">{v.suggestedFix}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Teacher anomalies (existing flow) */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Teacher-Drafting Anomalies</h3>
        {anomalies.length === 0 && (
          <p className="text-xs text-slate-500 p-3">No anomalies recorded for this document.</p>
        )}
        {anomalies.map((anom) => {
          const isResolved = anom.isResolved;
          return (
            <div
              key={anom.id}
              className={`border rounded-xl p-4 transition-all ${
                isResolved
                  ? 'bg-slate-900/40 border-slate-800 opacity-80'
                  : anom.severity === 'error'
                  ? 'bg-red-950/20 border-red-500/40'
                  : 'bg-amber-950/20 border-amber-500/40'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-800/80">
                <div className="flex items-center gap-2">
                  {isResolved ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  ) : anom.severity === 'error' ? (
                    <XCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
                  )}
                  <span className="font-bold text-sm text-slate-100">{anom.title}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-slate-800 text-slate-300">
                    Row {anom.sectionRowId} {anom.questionNumber ? `• Q${anom.questionNumber}` : ''}
                  </span>
                </div>
                <div>
                  {isResolved ? (
                    <span className="inline-flex items-center gap-1 text-xs text-emerald-400 font-semibold bg-emerald-950/50 px-2 py-1 rounded border border-emerald-800/50">
                      <Check className="w-3.5 h-3.5" /> Resolved & Normalized
                    </span>
                  ) : (
                    <button
                      onClick={() => onResolveAnomaly(anom.id)}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-sm transition active:scale-95"
                    >
                      <Wrench className="w-3.5 h-3.5" />
                      <span>Apply Suggested Fix</span>
                    </button>
                  )}
                </div>
              </div>
              <div className="mt-3 space-y-2 text-xs">
                <p className="text-slate-300 leading-relaxed">{anom.description}</p>
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-start gap-2">
                  <Info className="w-4 h-4 text-indigo-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-indigo-300">Engine Recommendation: </span>
                    <span className="text-slate-300">{anom.suggestedFix}</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

function escapeHtml(s: string): string {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ---------------------------------------------------------------------------
// Mined rules panel (Idea 1)
// The contract, in UI form: AI proposes (one call) -> validation + grounding +
// target check + corpus shadow run decide -> live rules apply everywhere until
// a human retires them. The panel NEVER offers a path around the gate: there
// is no "force live" button, and retiring is always one click.
// ---------------------------------------------------------------------------

const STATUS_STYLE: Record<MinedRuleStatus, string> = {
  proposed: 'bg-slate-800 text-slate-300 border-slate-600',
  shadow: 'bg-amber-950/40 text-amber-300 border-amber-700/50',
  live: 'bg-emerald-950/40 text-emerald-300 border-emerald-700/50',
  retired: 'bg-slate-950 text-slate-500 border-slate-800',
};

const MinedRulesPanel: React.FC<{
  document: ExamDocument;
  mining?: { providerConfig?: any; rawText?: string };
  onSelectTab: (tab: string) => void;
}> = ({ document, mining, onSelectTab }) => {
  const [rules, setRules] = useState<MinedRule[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);

  useEffect(() => {
    let alive = true;
    fetch('/api/mined-rules')
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`))))
      .then((d) => {
        if (alive) setRules(Array.isArray(d?.rules) ? d.rules : []);
      })
      .catch(() => {
        if (alive) setRules([]); // offline parse still works; mining just unavailable
      });
    return () => {
      alive = false;
    };
  }, []);

  const mine = async () => {
    if (!mining?.rawText || busy) return;
    setBusy(true);
    setMessage(null);
    try {
      const res = await fetch('/api/mine-rule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rawText: mining.rawText,
          sourceFile: document.filename,
          providerConfig: mining.providerConfig,
        }),
      });
      const data = await res.json();
      if (data?.ok) {
        setRules((prev) => prev); // refetch below for consistency
        const refreshed = await fetch('/api/mined-rules').then((r) => r.json());
        setRules(Array.isArray(refreshed?.rules) ? refreshed.rules : []);
        setMessage({
          kind: 'ok',
          text: `Rule accepted (${data.status}) — target fixed, corpus shadow clean (${data.shadow?.corpusFiles ?? 0} exams graded).`,
        });
      } else {
        setMessage({ kind: 'err', text: `${data?.error || 'Mining rejected.'}${data?.errors?.length ? ` (${data.errors.slice(0, 2).join('; ')})` : ''}` });
      }
    } catch (e: any) {
      setMessage({ kind: 'err', text: e?.message || 'Mining request failed.' });
    } finally {
      setBusy(false);
    }
  };

  const changeStatus = async (id: string, status: MinedRuleStatus) => {
    setBusy(true);
    setMessage(null);
    try {
      const res = await fetch('/api/mined-rules/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status }),
      });
      const data = await res.json();
      if (data?.ok) {
        setRules(Array.isArray(data.rules) ? data.rules : []);
        if (status === 'retired') setMessage({ kind: 'ok', text: `Rule ${id} retired — it no longer applies to any parse.` });
      } else {
        setMessage({ kind: 'err', text: data?.error || 'Status change failed.' });
      }
    } catch (e: any) {
      setMessage({ kind: 'err', text: e?.message || 'Status change failed.' });
    } finally {
      setBusy(false);
    }
  };

  const liveCount = (rules || []).filter((r) => r.status === 'live').length;
  const canMine = !!mining?.rawText;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
          <GitBranch className="w-3.5 h-3.5 text-indigo-400" /> Mined rules
          {liveCount > 0 && (
            <span className="px-2 py-0.5 rounded-full bg-emerald-950/40 border border-emerald-700/50 text-emerald-300 text-[10px] font-bold normal-case">
              {liveCount} live
            </span>
          )}
        </h3>
        <button
          onClick={mine}
          disabled={!canMine || busy}
          title={canMine ? 'One AI call: propose a rule + expected parse; the corpus gate decides.' : 'Re-parse this exam in this session to enable mining (the raw source is required).'}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed text-white text-[11px] font-bold shadow-sm transition active:scale-95"
        >
          <Bot className={`w-3.5 h-3.5 ${busy ? 'animate-pulse' : ''}`} /> Mine a rule for this exam
        </button>
      </div>
      <p className="text-[11px] text-slate-500 -mt-1">
        The model proposes one corrective rule and the expected parse. It is validated, anchored to the raw document,
        target-checked, then shadow-run over the whole golden corpus — anything less than perfect is rejected automatically.
      </p>

      {message && (
        <div className={`p-3 rounded-lg text-[11px] border ${message.kind === 'ok' ? 'bg-emerald-950/30 border-emerald-800/50 text-emerald-300' : 'bg-rose-950/30 border-rose-800/50 text-rose-300'}`}>
          {message.text}
        </div>
      )}

      {rules === null && <p className="text-[11px] text-slate-500">Loading mined rules…</p>}

      {rules !== null && rules.length === 0 && (
        <p className="text-[11px] text-slate-500 p-3">No mined rules yet. The parser runs on its deterministic rules alone.</p>
      )}

      {(rules || []).map((rule) => (
        <div key={rule.id} className="p-4 rounded-xl border bg-slate-900/50 border-slate-800 space-y-2">
          <div className="flex items-start gap-2 flex-wrap">
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${STATUS_STYLE[rule.status]}`}>
              {rule.status}
            </span>
            <span className="text-[10px] font-mono text-slate-500">{rule.id}</span>
            <span className="text-[10px] text-slate-500 ml-auto">
              {rule.provenance.model ? `${rule.provenance.model} • ` : ''}
              {rule.provenance.sourceFile ? escapeHtml(rule.provenance.sourceFile) : 'manual'}
            </span>
          </div>
          <p className="text-[11px] text-slate-300 font-mono leading-relaxed">
            when {describeCondition(rule)} <span className="text-indigo-400">→</span> {describeAction(rule)}
          </p>
          {rule.rationale && <p className="text-[11px] text-slate-400 italic">{escapeHtml(rule.rationale)}</p>}
          <div className="flex items-center gap-2 flex-wrap pt-1">
            {rule.status === 'shadow' && (
              <button
                onClick={() => changeStatus(rule.id, 'live')}
                disabled={busy}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-[10px] font-bold transition"
              >
                <Check className="w-3 h-3" /> Promote to live
              </button>
            )}
            {(rule.status === 'live' || rule.status === 'shadow' || rule.status === 'proposed') && (
              <button
                onClick={() => changeStatus(rule.id, 'retired')}
                disabled={busy || rule.status === 'proposed'}
                title={rule.status === 'proposed' ? 'Proposed rules are not applied yet — they expire on their own.' : 'Retire this rule everywhere (kill switch).'}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 text-[10px] font-bold transition"
              >
                <XCircle className="w-3 h-3" /> Retire
              </button>
            )}
            <button
              onClick={() => onSelectTab('questions')}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-semibold transition"
            >
              See affected questions
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

function describeCondition(rule: MinedRule): string {
  const c = rule.condition;
  const parts: string[] = [];
  if (c.sectionRowId) parts.push(`section ${c.sectionRowId}`);
  if (c.suggestsTypeFromTemplate) parts.push(`template≈${c.suggestsTypeFromTemplate}`);
  if (c.instructionRegex) parts.push(`instruction /${c.instructionRegex.slice(0, 40)}/`);
  if (c.stemRegex) parts.push(`stem /${c.stemRegex.slice(0, 40)}/`);
  if (c.questionNumbers) parts.push(`q ${c.questionNumbers.join(',')}`);
  return parts.length > 0 ? parts.join(' + ') : '(unscoped)';
}

function describeAction(rule: MinedRule): string {
  const a = rule.action;
  const parts: string[] = [];
  if (a.setType) parts.push(`type = ${a.setType}`);
  if (a.setCategory) parts.push(`category = ${a.setCategory}`);
  if (a.setMark !== undefined) parts.push(`mark = ${a.setMark}`);
  return parts.join(', ');
}
