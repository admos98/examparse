import React from 'react';
import { Receipt, Scale } from 'lucide-react';
import { ExamDocument, QuestionItem } from '../types/exam';

/**
 * "Explain This Question" receipt (#10): the exact source lines that produced
 * the question, the rules that fired, and the alternatives the parser
 * considered and rejected. Show-your-work is the strongest trust primitive.
 */

interface ExplainReceiptProps {
  question: QuestionItem;
  document: ExamDocument;
}

const RULE_COLORS: Record<string, string> = {
  R20: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30',
  R30: 'bg-sky-500/15 text-sky-300 border-sky-500/30',
  R10: 'bg-purple-500/15 text-purple-300 border-purple-500/30',
  R12: 'bg-purple-500/15 text-purple-300 border-purple-500/30',
  R14: 'bg-purple-500/15 text-purple-300 border-purple-500/30',
  R40: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
  R50: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
  R60: 'bg-slate-500/15 text-slate-300 border-slate-500/30',
};

export const ExplainReceipt: React.FC<ExplainReceiptProps> = ({ question, document }) => {
  const receipt = question.receipt;
  const traceLines = document.parseTrace?.lines;

  if (!receipt && !document.parseTrace) {
    return (
      <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700 text-[11px] text-slate-400">
        No parse receipt available for this question — it was likely created before the receipt system, edited by hand,
        or produced by the AI layer. Every question parsed from a file from now on carries a full receipt.
      </div>
    );
  }

  const sourceLines =
    receipt && traceLines ? traceLines.slice(receipt.lineStart, receipt.lineEnd + 1).filter((l) => l.trim()) : [];

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 text-[11px] font-bold text-slate-300">
        <Receipt className="w-3.5 h-3.5 text-indigo-400" />
        Parse receipt — show your work
      </div>

      {/* Rule chain */}
      {receipt && (
        <div className="flex flex-wrap items-center gap-1.5">
          {receipt.ruleChain.map((r) => {
            const [id, ...nameParts] = r.split(':');
            const name = nameParts.join(':') || id;
            return (
              <span key={r} className={`px-2 py-0.5 rounded-md border text-[10px] font-semibold ${RULE_COLORS[id] || 'bg-slate-500/15 text-slate-300 border-slate-500/30'}`}>
                {id} · {name}
              </span>
            );
          })}
          <span
            className={`px-2 py-0.5 rounded-md border text-[10px] font-bold ${
              receipt.ruleConfidence >= 85
                ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                : receipt.ruleConfidence >= 60
                  ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                  : 'bg-rose-500/15 text-rose-300 border-rose-500/30'
            }`}
          >
            {receipt.ruleConfidence}% rule confidence
          </span>
        </div>
      )}

      {/* Source lines */}
      {sourceLines.length > 0 && (
        <div className="rounded-xl bg-slate-950 border border-slate-800 overflow-hidden">
          <div className="px-3 py-1.5 text-[10px] font-bold text-slate-500 border-b border-slate-800">
            Source lines {receipt ? `#${receipt.lineStart + 1}–${receipt.lineEnd + 1}` : ''} (as the engine saw them)
          </div>
          <div className="divide-y divide-slate-800/60">
            {sourceLines.map((line, i) => (
              <div key={i} className="flex items-start gap-2 px-3 py-1.5">
                <span className="text-[10px] font-mono text-slate-600 w-10 shrink-0 text-right">
                  {(receipt?.lineStart || 0) + i + 1}
                </span>
                <span className="text-[11px] font-mono text-slate-300 whitespace-pre-wrap break-all" dir="auto">
                  {line}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Alternatives considered */}
      {receipt?.alternates && receipt.alternates.length > 0 && (
        <div className="space-y-1.5">
          <div className="text-[10px] font-bold text-slate-500">ALTERNATIVES CONSIDERED AND REJECTED</div>
          {receipt.alternates.map((a, i) => (
            <div key={i} className="flex items-start gap-2 text-[11px] text-slate-400">
              <span className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-[9px] font-mono text-slate-400 shrink-0">
                {a.ruleId}
              </span>
              <span>
                Could this be <b className="text-slate-300">{a.kind}</b>? {a.reason}.
              </span>
            </div>
          ))}
        </div>
      )}

      {!receipt && document.parseTrace && (
        <div className="text-[11px] text-slate-500">
          This question came from the legacy fallback scanner (no per-block receipt), or from a solve/AI step.
          {document.parseTrace.fallbackUsed ? ' The trace shows the rule table found no blocks for this section.' : ''}
        </div>
      )}

      {/* Jev judge verdict (judge-only protocol): calibrated second opinion */}
      {question.jev && (
        <div className="rounded-xl border border-slate-800 bg-slate-950 p-3 space-y-2">
          <div className="flex items-center gap-2 text-[11px] font-bold text-slate-300">
            <Scale className="w-3.5 h-3.5 text-cyan-400" />
            Jev judge verdict
            <span
              className={`px-2 py-0.5 rounded-md border text-[10px] font-bold ${
                question.jev.verdict === 'correct'
                  ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                  : question.jev.verdict === 'incorrect'
                    ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                    : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
              }`}
            >
              {question.jev.verdict}
            </span>
            {question.jev.cached && (
              <span className="px-2 py-0.5 rounded-md border text-[10px] font-semibold bg-slate-800 text-slate-400 border-slate-700">
                cached — 0 tokens
              </span>
            )}
          </div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-[11px] text-slate-400">
            <span>
              P(correct): <b className="text-slate-200 font-mono">{question.jev.pCorrect !== undefined ? question.jev.pCorrect.toFixed(3) : '—'}</b>
            </span>
            <span>
              Category: <b className="text-slate-200">{question.jev.category || '—'}</b>
            </span>
            <span>
              Skill area: <b className="text-slate-200">{question.jev.skillArea || '—'}</b>
            </span>
            <span>
              Well-formedness: <b className="text-slate-200 font-mono">{question.jev.quality !== undefined ? question.jev.quality.toFixed(2) : '—'}</b> / 3
            </span>
            <span>
              Judge model: <b className="text-slate-200 font-mono">{question.jev.model}</b>
            </span>
            <span>
              Backend: <b className="text-slate-200">{question.jev.backend === 'jev' ? 'TypeSafe Jev (native)' : 'LLM fallback'}</b>
            </span>
          </div>
          <p className="text-[10px] text-slate-500">
            Jev is a decision model: it evaluates typed questions and returns probabilities — it never writes or edits answers.
            {question.jev.judgedAt ? ` Judged ${new Date(question.jev.judgedAt).toLocaleString()}.` : ''}
          </p>
        </div>
      )}
    </div>
  );
};
