import React, { useMemo, useState } from 'react';
import { Table2, Download, X } from 'lucide-react';
import { ExamDocument } from '../types/exam';
import { buildPreviewGrid, exportToExcel } from '../utils/exporter';

/**
 * Export Preview (#18) — WYSIWYS: this table renders the exact row objects
 * that buildQuestionRows feeds into the .xlsx. No surprises between what the
 * user sees here and what lands in Excel.
 */

interface ExportPreviewModalProps {
  document: ExamDocument;
  onClose: () => void;
}

export const ExportPreviewModal: React.FC<ExportPreviewModalProps> = ({ document, onClose }) => {
  const { headers, rows } = useMemo(() => buildPreviewGrid(document), [document]);
  const [visible, setVisible] = useState(15);
  const stemIdx = headers.indexOf('Question Stem');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4" onClick={onClose}>
      <div
        className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-6xl max-h-[85vh] flex flex-col shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Table2 className="w-4 h-4 text-emerald-400" />
            <div>
              <h3 className="text-sm font-bold text-white">Excel export preview</h3>
              <p className="text-[11px] text-slate-400">
                Exactly what the .xlsx will contain — {rows.length} question rows × {headers.length} columns.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => exportToExcel(document)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition"
            >
              <Download className="w-3.5 h-3.5" /> Download .xlsx
            </button>
            <button onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Grid */}
        <div className="flex-1 overflow-auto">
          {rows.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500">This document has no questions to export.</div>
          ) : (
            <table className="w-full text-[11px] border-collapse">
              <thead className="sticky top-0 z-10">
                <tr className="bg-slate-950">
                  {headers.map((h) => (
                    <th
                      key={h}
                      className="text-left px-3 py-2 font-bold text-slate-300 border-b border-slate-700 whitespace-nowrap"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.slice(0, visible).map((row, i) => (
                  <tr key={i} className={i % 2 ? 'bg-slate-900/60' : 'bg-slate-900'}>
                    {row.map((cell, j) => (
                      <td
                        key={j}
                        className={`px-3 py-1.5 border-b border-slate-800/70 align-top max-w-[280px] truncate ${
                          j === stemIdx ? 'text-slate-200' : 'text-slate-300'
                        }`}
                        title={String(cell)}
                      >
                        {String(cell) || <span className="text-slate-600">—</span>}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Footer */}
        {rows.length > visible && (
          <div className="px-5 py-3 border-t border-slate-800 flex items-center justify-between">
            <span className="text-[11px] text-slate-500">
              Showing {visible} of {rows.length} rows — the download always includes everything.
            </span>
            <button
              onClick={() => setVisible((v) => v + 30)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold border border-slate-700 transition"
            >
              Show 30 more
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
