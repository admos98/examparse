import React, { useMemo, useState } from 'react';
import { CheckCheck, X, ShieldCheck, Scale, AlertTriangle } from 'lucide-react';
import { ExamDocument, QuestionItem } from '../types/exam';
import { acceptDraftAnswer, applyMediationDecision } from '../utils/answerFlow';
import { bulkAcceptAllowed } from '../utils/calibration';
import { CalibrationReport } from '../types/exam';

/**
 * M4 — the Final Review grid: the single surface where EVERYTHING lands
 * (decision D1). Rows carry the answer draft with its provenance badge, the
 * lesson attribution, the difficulty chips, and the mediation status. The
 * human edits inline and always wins; BULK accept is the ONLY path the
 * calibration gate restricts (verifyCalibration + bulkAcceptAllowed rules).
 */

interface FinalReviewGridProps {
  document: ExamDocument;
  calibration?: CalibrationReport | null;
  onUpdateDocument: (updated: ExamDocument, label: string) => void;
  onClose: () => void;
}

const PROVENANCE_BADGE: Record<string, { label: string; className: string }> = {
  'jev-verified-draft': { label: 'Jev-verified draft', className: 'bg-emerald-900/60 text-emerald-300 border-emerald-700' },
  'ai-draft': { label: 'AI draft', className: 'bg-amber-900/60 text-amber-300 border-amber-700' },
};

export const FinalReviewGrid: React.FC<FinalReviewGridProps> = ({ document, calibration, onUpdateDocument, onClose }) => {
  const [dismissed, setDismissed] = useState(false);
  const [bulkSummary, setBulkSummary] = useState<string | null>(null);

  const rows = useMemo(() => {
    const out: { q: QuestionItem; sectionRowId: string }[] = [];
    for (const sec of document.sections) {
      for (const q of sec.questions) {
        if (q.answer || q.answerMediation) out.push({ q, sectionRowId: sec.rowId });
      }
    }
    return out;
  }, [document]);

  if (dismissed) return null;

  const mediationsPending = rows.filter((r) => r.q.answerMediation?.status === 'pending').length;
  const drafts = rows.filter((r) => r.q.answer && !r.q.correctAnswer).length;
  const bulkEligible = rows.filter((r) => bulkAcceptAllowed(r.q, calibration)).length;

  const handleBulkAccept = () => {
    let accepted = 0;
    let refused = 0;
    let next = document;
    for (const { q } of rows) {
      if (!q.answer || q.correctAnswer) continue;
      if (bulkAcceptAllowed(q, calibration)) {
        next = acceptDraftAnswer(next, q.id);
        accepted++;
      } else {
        refused++;
      }
    }
    if (accepted > 0) onUpdateDocument(next, `Bulk-accepted ${accepted} calibrated draft answer(s)`);
    setBulkSummary(`Accepted ${accepted} — refused ${refused} (below measured calibration / flagged / free-text / application-level). Human decision required for those.`);
  };

  const handleMediation = (questionId: string, decision: 'ai' | 'jev' | 'human', humanValue?: string) => {
    const next = applyMediationDecision(document, questionId, decision, humanValue);
    onUpdateDocument(next, `Mediation resolved (${decision})`);
  };

  const handleEditDraft = (questionId: string, value: string) => {
    // A human edit IS the accept: write the human value directly.
    const next = applyMediationDecision(document, questionId, 'human', value);
    onUpdateDocument(next, 'Human answer entered');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-6xl max-h-[92vh] flex flex-col shadow-2xl">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-white">Final Review — answers, lessons &amp; difficulty</h2>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="px-4 py-2 border-b border-slate-800 flex flex-wrap items-center gap-2 text-xs">
          <span className="text-slate-400">{rows.length} drafted / mediated row(s)</span>
          <span className="text-slate-600">•</span>
          <span className="text-amber-300">{drafts} draft(s) awaiting accept</span>
          <span className="text-slate-600">•</span>
          <span className="text-fuchsia-300">{mediationsPending} mediation(s) pending</span>
          <span className="flex-1" />
          <button
            onClick={handleBulkAccept}
            disabled={bulkEligible === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 disabled:bg-slate-800 disabled:text-slate-500 text-white font-semibold transition"
          >
            <CheckCheck className="w-3.5 h-3.5" /> Bulk accept ({bulkEligible} eligible)
          </button>
        </div>

        {bulkSummary && (
          <div className="mx-4 mt-2 flex items-start gap-2 text-xs bg-slate-800/70 border border-slate-700 rounded-lg p-3 text-slate-300">
            <Scale className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
            <span>{bulkSummary}</span>
          </div>
        )}

        <div className="overflow-auto flex-1 p-4">
          {rows.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-10">
              Nothing to review yet — run the answer flow (Verify &amp; Answer) first.
            </p>
          ) : (
            <table className="w-full text-xs">
              <thead>
                <tr className="text-left text-slate-400 border-b border-slate-800">
                  <th className="py-2 pr-2">#</th>
                  <th className="py-2 pr-2">Stem</th>
                  <th className="py-2 pr-2">Draft answer</th>
                  <th className="py-2 pr-2">Lesson</th>
                  <th className="py-2 pr-2">Difficulty</th>
                  <th className="py-2 pr-2">Actions</th>
                </tr>
              </thead>
              <tbody>
                {rows.map(({ q, sectionRowId }) => {
                  const badge = q.answer ? PROVENANCE_BADGE[q.answer.provenance] : undefined;
                  const mediation = q.answerMediation;
                  const span = [q.attribution?.lesson1, q.attribution?.lesson2].filter(Boolean).join(' + ') || '—';
                  return (
                    <tr key={q.id} className="border-b border-slate-800/60 align-top">
                      <td className="py-2.5 pr-2 text-slate-400 font-mono">
                        {sectionRowId}/{q.displayNumber}
                      </td>
                      <td className="py-2.5 pr-2 text-slate-300 max-w-[240px]">
                        <span className="line-clamp-2">{q.stem}</span>
                        {q.attribution?.supportFlag && (
                          <span className="inline-flex items-center gap-1 mt-1 text-[10px] text-orange-300 border border-orange-800 rounded px-1.5 py-0.5">
                            <AlertTriangle className="w-3 h-3" /> no lesson support
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 pr-2">
                        {q.answer ? (
                          <div className="space-y-1">
                            <span className={`inline-block border rounded px-1.5 py-0.5 text-[10px] font-semibold ${badge?.className}`}>{badge?.label}</span>
                            <div className="text-slate-200 font-mono">{q.answer.value}</div>
                          </div>
                        ) : (
                          <span className="text-slate-500">—</span>
                        )}
                        {mediation && (
                          <div className="mt-1.5 rounded-lg border border-fuchsia-900/60 bg-fuchsia-950/40 p-2 space-y-1">
                            <div className="text-[10px] font-bold text-fuchsia-300 uppercase tracking-wide">Mediation — pick one</div>
                            <div className="text-slate-300">AI says: <span className="font-mono">{mediation.aiAnswer}</span></div>
                            {mediation.jevAnswer && <div className="text-slate-300">Jev says: <span className="font-mono">{mediation.jevAnswer}</span></div>}
                            {mediation.status === 'pending' ? (
                              <div className="flex flex-wrap gap-1.5 pt-1">
                                {mediation.aiAnswer && (
                                  <button onClick={() => handleMediation(q.id, 'ai')} className="px-2 py-1 rounded bg-amber-800 hover:bg-amber-700 text-white text-[10px] font-semibold">Keep AI</button>
                                )}
                                {mediation.jevAnswer && (
                                  <button onClick={() => handleMediation(q.id, 'jev')} className="px-2 py-1 rounded bg-emerald-800 hover:bg-emerald-700 text-white text-[10px] font-semibold">Keep Jev</button>
                                )}
                                <HumanValueInput onSubmit={(v) => handleMediation(q.id, 'human', v)} />
                              </div>
                            ) : (
                              <span className="text-[10px] text-slate-500">resolved: {mediation.status}</span>
                            )}
                          </div>
                        )}
                      </td>
                      <td className="py-2.5 pr-2 text-slate-400">
                        <span className="block font-mono text-[10px]">{span}</span>
                        <span className="block text-[10px]">{q.attribution?.inBook || ''}</span>
                        <span className="block text-[10px]">{q.attribution?.cognitive || ''}</span>
                      </td>
                      <td className="py-2.5 pr-2">
                        {q.difficulty ? (
                          <span
                            className={`inline-block rounded px-2 py-0.5 text-[10px] font-bold border ${
                              q.difficulty.band === 'hard'
                                ? 'bg-red-950/60 text-red-300 border-red-800'
                                : q.difficulty.band === 'medium'
                                  ? 'bg-amber-950/60 text-amber-300 border-amber-800'
                                  : 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
                            }`}
                          >
                            {q.difficulty.score} · {q.difficulty.band}
                          </span>
                        ) : (
                          <span className="text-slate-500">—</span>
                        )}
                      </td>
                      <td className="py-2.5 pr-2">
                        {q.answer && !q.correctAnswer && !mediation?.status.startsWith('pending') && (
                          <button onClick={() => handleEditDraft(q.id, q.answer!.value)} className="px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 text-white text-[10px] font-semibold">
                            Accept draft
                          </button>
                        )}
                        {q.correctAnswer && <span className="text-[10px] text-emerald-400">answered ({q.answerMeta?.method || '?'})</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};

const HumanValueInput: React.FC<{ onSubmit: (value: string) => void }> = ({ onSubmit }) => {
  const [value, setValue] = useState('');
  return (
    <span className="flex items-center gap-1">
      <input
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="own answer"
        className="w-24 bg-slate-950 border border-slate-700 rounded px-1.5 py-1 text-[10px] text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
      />
      <button
        onClick={() => {
          if (value.trim()) onSubmit(value.trim());
        }}
        className="px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 text-white text-[10px] font-semibold"
      >
        Use mine
      </button>
    </span>
  );
};
