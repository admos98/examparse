import React, { useEffect, useState } from 'react';
import { Undo2, Redo2, History, X } from 'lucide-react';
import { ExamDocument } from '../types/exam';
import { canUndo, canRedo, undo, redo, listHistory, jumpTo, subscribeHistory } from '../utils/examHistory';

/**
 * Time Travel UI (#13): global undo/redo + a scrubber listing every labeled
 * transaction. Ctrl+Z / Ctrl+Shift+Z are handled here (mounted on the detail
 * screen) so keyboard users get the same fearlessness as mouse users.
 */

interface HistoryScrubberProps {
  document: ExamDocument;
  onApply: (doc: ExamDocument, label: string) => void;
}

export const HistoryScrubber: React.FC<HistoryScrubberProps> = ({ document, onApply }) => {
  const [, setTick] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => subscribeHistory(() => setTick((t) => t + 1)), []);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) {
          const next = redo(document);
          if (next) onApply(next, 'Redo');
        } else {
          const prev = undo(document);
          if (prev) onApply(prev, 'Undo');
        }
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [document, onApply]);

  const entries = listHistory(document.id);

  return (
    <div className="relative flex items-center gap-1">
      <button
        onClick={() => {
          const prev = undo(document);
          if (prev) onApply(prev, 'Undo');
        }}
        disabled={!canUndo(document.id)}
        className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 disabled:opacity-40 hover:text-white transition"
        title="Undo (Ctrl+Z)"
      >
        <Undo2 className="w-3.5 h-3.5" />
      </button>
      <button
        onClick={() => {
          const next = redo(document);
          if (next) onApply(next, 'Redo');
        }}
        disabled={!canRedo(document.id)}
        className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 disabled:opacity-40 hover:text-white transition"
        title="Redo (Ctrl+Shift+Z)"
      >
        <Redo2 className="w-3.5 h-3.5" />
      </button>
      <button
        onClick={() => setOpen(!open)}
        disabled={entries.length === 0}
        className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 disabled:opacity-40 hover:text-white transition"
        title="History scrubber"
      >
        <History className="w-3.5 h-3.5" />
      </button>

      {open && entries.length > 0 && (
        <div className="absolute right-0 top-10 z-40 w-72 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-3 py-2 border-b border-slate-800">
            <span className="text-[11px] font-bold text-slate-300">Time travel</span>
            <button onClick={() => setOpen(false)} className="text-slate-500 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="max-h-64 overflow-y-auto">
            {[...entries].reverse().map((e, revIdx) => {
              const idx = entries.length - 1 - revIdx;
              return (
                <button
                  key={`${e.at}-${idx}`}
                  onClick={() => {
                    const target = jumpTo(document, idx);
                    if (target) onApply(target, `Jump to: ${e.label}`);
                    setOpen(false);
                  }}
                  className="w-full text-left px-3 py-2 hover:bg-slate-800/70 transition border-b border-slate-800/60 last:border-0"
                >
                  <div className="text-[11px] font-semibold text-slate-200">{e.label}</div>
                  <div className="text-[10px] text-slate-500">{new Date(e.at).toLocaleTimeString()}</div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
