import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { X, Loader2, ImageIcon, RefreshCw, Save, ScanText, AlertTriangle } from 'lucide-react';
import { ExamDocument, ExamImage, VisionReceipt } from '../types/exam';
import { ProviderConfig, VisionConfig } from '../types/settings';
import { runAltGeneration, extractImagesForDoc } from '../utils/visionFlow';
import { needsImageAlt } from '../utils/imagePending';

/**
 * Image review editor (Idea 3) — the human-in-the-loop authority over every
 * vision result. Auto-generated alts and placements are ALWAYS visible here
 * and editable; low-confidence placements arrive pre-flagged ('review') and
 * are not committed to questions until you accept them.
 *
 * Everything deterministic (extraction, cache lookup, placement evidence) is
 * free and runs on open. The provider is called ONLY when you press
 * "Generate / refresh alts" — one batched call, cached by content hash.
 */

interface ImageAltsModalProps {
  document: ExamDocument;
  providerConfig?: ProviderConfig;
  visionConfig: VisionConfig;
  onClose: () => void;
  /** Commit the edited state; App stamps history and runs the two-phase pass 2. */
  onApply: (doc: ExamDocument, receipt: VisionReceipt | null, pendingIdsBefore: string[]) => void;
}

interface QuestionRef {
  id: string;
  label: string;
}

export const ImageAltsModal: React.FC<ImageAltsModalProps> = ({
  document,
  providerConfig,
  visionConfig,
  onClose,
  onApply,
}) => {
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [progress, setProgress] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [warnings, setWarnings] = useState<string[]>([]);
  const [preview, setPreview] = useState<{ count: number; estTokens: number; error?: string }>({ count: 0, estTokens: 0 });
  const [working, setWorking] = useState<ExamImage[]>([]);
  const [receipt, setReceipt] = useState<VisionReceipt | null>(null);
  const [docDraft, setDocDraft] = useState<ExamDocument>(document);

  const questionOptions: QuestionRef[] = useMemo(
    () =>
      document.sections.flatMap((sec) =>
        sec.questions.map((q) => ({
          id: q.id,
          label: `Q${q.displayNumber}${sec.rowId ? ` · ${sec.rowId}` : ''} — ${(q.stem || '').slice(0, 60)}`,
        })),
      ),
    [document],
  );

  const pendingIdsBefore = useMemo(
    () => document.sections.flatMap((s) => s.questions.filter((q) => needsImageAlt(q)).map((q) => q.id)),
    [document],
  );

  const runPreview = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await extractImagesForDoc(document);
      if (res.error) {
        setPreview({ count: 0, estTokens: 0, error: res.error });
      } else {
        const existing = new Map((document.images || []).map((i) => [i.contentHash, i]));
        const fresh = res.images.filter((i) => !existing.has(i.contentHash));
        setPreview({ count: res.images.length, estTokens: fresh.length * 700 });
      }
      setWarnings(res.warnings);
    } catch (e: any) {
      setPreview({ count: 0, estTokens: 0, error: e?.message || 'Extraction preview failed.' });
    } finally {
      setLoading(false);
    }
  }, [document]);

  useEffect(() => {
    runPreview();
    // Seed the working list with any images already on the document.
    setWorking([...(document.images || [])]);
    if (document.images && document.images.length > 0) setDocDraft(document);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleGenerate = async () => {
    setGenerating(true);
    setError('');
    setWarnings([]);
    try {
      const res = await runAltGeneration(document, {
        providerConfig,
        visionConfig,
        onProgress: (note) => setProgress(note),
      });
      setProgress('');
      if (!res.ok || !res.doc) {
        setError(res.error || 'Vision generation failed.');
        return;
      }
      setWarnings(res.warnings);
      setReceipt(res.receipt || null);
      setDocDraft(res.doc);
      setWorking([...(res.doc.images || [])]);
    } catch (e: any) {
      setError(e?.message || 'Vision generation failed.');
    } finally {
      setGenerating(false);
      setProgress('');
    }
  };

  const patchImage = (id: string, patch: Partial<ExamImage>) => {
    setWorking((prev) => prev.map((img) => (img.id === id ? { ...img, ...patch } : img)));
  };

  const handleSave = () => {
    // Fold the edited images back into the draft and apply placements with the
    // edited state: manual picks become 'manual', untouched entries keep status.
    const withEdits: ExamDocument = {
      ...docDraft,
      images: working.map((img) => ({
        ...img,
        placementStatus: img.placementStatus === 'review' && img.questionId ? 'manual' : img.placementStatus,
        reviewed: true,
      })),
    };
    onApply(withEdits, receipt, pendingIdsBefore);
  };

  const total = working.length;
  const cachedCount = working.filter((i) => i.cached).length;
  const reviewCount = working.filter((i) => i.placementStatus === 'review').length;
  const unplacedCount = working.filter((i) => i.placementStatus === 'unplaced' || !i.alt).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4" onClick={onClose}>
      <div
        className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-3xl max-h-[88vh] flex flex-col shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5 min-w-0">
            <ImageIcon className="w-5 h-5 text-fuchsia-300 shrink-0" />
            <div className="min-w-0">
              <h2 className="text-sm font-bold text-white truncate">Images — vision alts &amp; placement</h2>
              <p className="text-[11px] text-slate-400 truncate">
                {total > 0 ? `${total} image(s) · ${cachedCount} cached · ${reviewCount} awaiting review · ${unplacedCount} without alt` : 'Opt-in: nothing runs until you press Generate.'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {loading && (
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Loader2 className="w-3.5 h-3.5 animate-spin" /> Reading the source file for embedded images...
            </div>
          )}

          {!loading && preview.error && (
            <div className="flex items-start gap-2 bg-amber-950/40 border border-amber-800/50 rounded-xl p-3 text-xs text-amber-200">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{preview.error}</span>
            </div>
          )}

          {!loading && !preview.error && (
            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 text-xs text-slate-300 space-y-2">
              <p>
                <span className="font-semibold text-white">{preview.count}</span> embedded image(s) found in this document.
              </p>
              <p className="text-slate-400">
                One batched vision call describes all of them (text inside images is transcribed; photos get a one-line
                description). Results are cached by content hash — re-runs are free. Estimated cost when nothing is
                cached: ≈{preview.estTokens.toLocaleString()} tokens.
              </p>
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={handleGenerate}
                  disabled={generating || preview.count === 0}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-fuchsia-600 hover:bg-fuchsia-500 disabled:opacity-50 text-white text-xs font-bold transition"
                >
                  {generating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ScanText className="w-3.5 h-3.5" />}
                  <span>{generating ? 'Working...' : `Generate / refresh alts${preview.count ? ` (${preview.count})` : ''}`}</span>
                </button>
                {generating && <span className="text-[11px] text-slate-400">{progress}</span>}
              </div>
            </div>
          )}

          {error && (
            <div className="flex items-start gap-2 bg-rose-950/40 border border-rose-800/50 rounded-xl p-3 text-xs text-rose-200">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {warnings.length > 0 && (
            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 text-[11px] text-slate-400 space-y-1">
              {warnings.slice(0, 6).map((w, i) => (
                <p key={i}>⚠ {w}</p>
              ))}
            </div>
          )}

          {/* Image cards */}
          {working.map((img) => (
            <div key={img.id} className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 space-y-2.5">
              <div className="flex items-start gap-3">
                {img.thumbnail ? (
                  <img src={img.thumbnail} alt={`thumbnail of ${img.id}`} className="w-20 h-20 object-cover rounded-lg border border-slate-700 bg-white" />
                ) : (
                  <div className="w-20 h-20 rounded-lg border border-slate-800 bg-slate-900 flex items-center justify-center text-slate-600">
                    <ImageIcon className="w-6 h-6" />
                  </div>
                )}
                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs font-bold text-white">{img.id}</span>
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-semibold bg-slate-800 text-slate-300 border border-slate-700">{img.kind || 'unknown'}</span>
                    {img.cached && <span className="px-1.5 py-0.5 rounded text-[9px] font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">cached · 0 tokens</span>}
                    {img.placementStatus && (
                      <span
                        className={`px-1.5 py-0.5 rounded text-[9px] font-semibold border ${
                          img.placementStatus === 'auto'
                            ? 'bg-teal-500/15 text-teal-300 border-teal-500/30'
                            : img.placementStatus === 'manual'
                            ? 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30'
                            : img.placementStatus === 'review'
                            ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                            : 'bg-slate-700/40 text-slate-400 border-slate-700'
                        }`}
                      >
                        {img.placementStatus}
                        {img.placementConfidence !== undefined ? ` ${Math.round(img.placementConfidence * 100)}%` : ''}
                      </span>
                    )}
                    {img.page && <span className="text-[9px] text-slate-500">page {img.page}</span>}
                  </div>
                  {img.error && <p className="text-[10px] text-rose-300">{img.error}</p>}
                  <textarea
                    value={img.alt || ''}
                    onChange={(e) => patchImage(img.id, { alt: e.target.value, cached: false, reviewed: false })}
                    placeholder={img.error ? 'No alt yet — generate or type one manually' : 'Alt / transcription (editable)'}
                    rows={2}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:ring-1 focus:ring-fuchsia-500/60"
                  />
                  <div className="flex items-center gap-2">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider shrink-0">Placed at</label>
                    <select
                      value={img.questionId || ''}
                      onChange={(e) =>
                        patchImage(img.id, {
                          questionId: e.target.value || undefined,
                          placementStatus: e.target.value ? 'manual' : 'unplaced',
                          reviewed: true,
                        })
                      }
                      className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-fuchsia-500/60"
                    >
                      <option value="">— unplaced (review) —</option>
                      {questionOptions.map((q) => (
                        <option key={q.id} value={q.id}>
                          {q.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {receipt && (
            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 text-[11px] text-slate-400">
              Vision receipt: {receipt.sent} sent · {receipt.cacheHits} cache hit(s) · {receipt.calls} call(s) ·{' '}
              {receipt.totalTokens} tokens · {receipt.placed} auto-placed · {receipt.needsReview} awaiting review ·{' '}
              {receipt.unplaced} unplaced.
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between gap-3 px-5 py-3.5 border-t border-slate-800">
          <p className="text-[10px] text-slate-500">
            Alts become part of each question's context for the Jev check. Pending questions re-verify automatically after you save.
          </p>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={total === 0}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 disabled:opacity-50 text-white text-xs font-bold transition"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save to exam</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
