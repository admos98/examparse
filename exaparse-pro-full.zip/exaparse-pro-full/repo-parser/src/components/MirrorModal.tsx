import React, { useMemo, useState } from 'react';
import { X, Copy, Shuffle, Sparkles, Loader2, Info } from 'lucide-react';
import { ExamDocument } from '../types/exam';
import { createMirrorExam } from '../utils/mirrorExam';
import { refreshInvariants } from '../utils/invariants';

/**
 * Mirror Variant Modal (#16) — one-click parallel exam forms.
 * Deterministic core (option shuffles, bank/column permutations with answer
 * remapping) costs 0 tokens; the optional AI polish rewrites vocab/fill stems
 * so different bank words become correct.
 */

interface MirrorModalProps {
  document: ExamDocument;
  providerConfig: { provider: string; apiKey?: string; model: string };
  onClose: () => void;
  onCreate: (mirror: ExamDocument) => void;
}

export const MirrorModal: React.FC<MirrorModalProps> = ({ document, providerConfig, onClose, onCreate }) => {
  const nextVariant = useMemo(() => {
    // B, C, D ... (skip A)
    const used = new Set<string>();
    return () => {
      const letters = 'BCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
      for (const l of letters) {
        if (!used.has(l)) {
          used.add(l);
          return l;
        }
      }
      return `V${used.size + 1}`;
    };
  }, []);

  const [variant, setVariant] = useState<string>(nextVariant());
  const [shuffleQuestions, setShuffleQuestions] = useState(false);
  const [aiPolish, setAiPolish] = useState(false);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const polishableCount = document.sections.reduce(
    (n, sec) =>
      n +
      sec.questions.filter(
        (q) =>
          (q.type === 'word_bank_fill' || q.type === 'fill_blank') &&
          (q.wordBankWords?.length || sec.wordBank?.length || 0) >= 2,
      ).length,
    0,
  );

  const handleCreate = async () => {
    setBusy(true);
    setError(null);
    setStatus('Shuffling options, word banks and matching columns deterministically...');
    try {
      const mirror = createMirrorExam(document, { variant, seed: Date.now() % 2147483647, shuffleQuestions });

      if (aiPolish && polishableCount > 0) {
        setStatus(`AI-polishing ${polishableCount} vocabulary/fill stems (minimal tokens)...`);
        const items: { questionId: string; stem: string; correctAnswer: string; candidates: string[] }[] = [];
        for (const sec of mirror.sections) {
          const bank = sec.wordBank || [];
          for (const q of sec.questions) {
            if (q.type !== 'word_bank_fill' && q.type !== 'fill_blank') continue;
            const candidates = (q.wordBankWords?.length ? q.wordBankWords : bank).filter(
              (w) => w.toLowerCase() !== (q.correctAnswer || '').toLowerCase(),
            );
            if (candidates.length === 0 || !q.correctAnswer) continue;
            items.push({ questionId: q.id, stem: q.stem, correctAnswer: q.correctAnswer, candidates });
            if (items.length >= 40) break;
          }
        }

        if (items.length > 0) {
          const res = await fetch('/api/generate-mirror-polish', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ items, providerConfig }),
          });
          if (res.ok) {
            const data = await res.json();
            const byId = new Map<string, { newStem: string; newAnswer: string }>(
              (data.items || []).map((it: any) => [it.questionId, { newStem: it.newStem, newAnswer: it.newAnswer }]),
            );
            for (const sec of mirror.sections) {
              for (const q of sec.questions) {
                const polished = byId.get(q.id);
                if (polished && polished.newStem && polished.newAnswer) {
                  q.stem = polished.newStem;
                  q.correctAnswer = polished.newAnswer;
                }
              }
            }
          } else {
            const errData = await res.json().catch(() => ({}));
            setError(`AI polish skipped: ${errData.error || res.statusText}. The deterministic mirror was created.`);
          }
        }
      }

      setStatus('Validating structural invariants...');
      const withInvariants = refreshInvariants(mirror);
      onCreate(withInvariants);
    } catch (e: any) {
      setError(e?.message || 'Failed to create mirror variant');
    } finally {
      setBusy(false);
      setStatus(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between p-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center">
              <Copy className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Create Mirror Variant</h2>
              <p className="text-xs text-slate-400">A parallel form of this exam — same blueprint, fresh key.</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Variant label */}
          <div className="flex items-center gap-3">
            <label className="text-xs font-semibold text-slate-300 w-28">Variant label:</label>
            <input
              value={variant}
              onChange={(e) => setVariant(e.target.value.slice(0, 3).toUpperCase())}
              className="w-24 bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-sm text-white font-bold text-center focus:outline-none focus:border-purple-500"
            />
          </div>

          {/* Deterministic shuffles */}
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
            <p className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
              <Shuffle className="w-3 h-3" /> Deterministic transforms — 0 tokens, answer-valid by construction
            </p>
            <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
              <span>Shuffle MCQ option order <span className="text-slate-500">(answer letters remap automatically)</span></span>
              <input type="checkbox" checked disabled className="accent-emerald-500 rounded" />
            </label>
            <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
              <span>Permute word bank & matching column B <span className="text-slate-500">(keys remap)</span></span>
              <input type="checkbox" checked disabled className="accent-emerald-500 rounded" />
            </label>
            <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
              <span>Shuffle question order within sections (renumbered)</span>
              <input
                type="checkbox"
                checked={shuffleQuestions}
                onChange={(e) => setShuffleQuestions(e.target.checked)}
                className="accent-purple-500 rounded"
              />
            </label>
          </div>

          {/* AI polish */}
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                AI stem polish for vocab/fill
                <span className="text-[10px] text-slate-500">(~{polishableCount} items, minimal tokens)</span>
              </span>
              <input
                type="checkbox"
                checked={aiPolish}
                onChange={(e) => setAiPolish(e.target.checked)}
                disabled={polishableCount === 0}
                className="accent-indigo-500 rounded"
              />
            </label>
            <p className="text-[10px] text-slate-500 leading-relaxed flex items-start gap-1">
              <Info className="w-3 h-3 mt-0.5 flex-shrink-0" />
              Rewrites stems so a different bank word becomes correct — makes the variant a genuinely different test, not just a re-shuffle. Requires a configured AI provider.
            </p>
          </div>

          {status && (
            <div className="flex items-center gap-2 text-xs text-indigo-300">
              <Loader2 className="w-3.5 h-3.5 animate-spin" /> {status}
            </div>
          )}
          {error && (
            <div className="p-2.5 rounded-lg bg-amber-950/30 border border-amber-800/50 text-[11px] text-amber-300">{error}</div>
          )}
        </div>

        <div className="flex items-center justify-end gap-2 p-5 border-t border-slate-800 bg-slate-950/50">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-300 hover:text-white transition">
            Cancel
          </button>
          <button
            onClick={handleCreate}
            disabled={busy || !variant.trim()}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-xs font-bold transition"
          >
            <Copy className="w-3.5 h-3.5" />
            {busy ? 'Creating...' : `Create Variant ${variant}`}
          </button>
        </div>
      </div>
    </div>
  );
};
