import React, { useEffect, useState } from 'react';
import {
  FileSearch,
  ScanText,
  GitBranch,
  Boxes,
  ShieldCheck,
  Check,
  Loader2,
  Sparkles,
  RotateCcw,
  ChevronDown,
} from 'lucide-react';
import { ExamDocument } from '../types/exam';

/**
 * Parse Journey (#13) — turns the offline engine from a black box into a magic
 * show: the real extraction stats replay as an animated pipeline (words →
 * lines → sections → questions → invariants). Live mode shows current phase
 * during OCR; replay mode animates the recorded journey after parsing.
 */

export interface JourneyPhase {
  key: string;
  label: string;
  detail: string;
  icon: 'extract' | 'lines' | 'sections' | 'questions' | 'invariants' | 'provenance';
  count?: number;
  done: boolean;
}

export function buildReplayJourney(doc: ExamDocument, wordCount: number, lineCount: number): JourneyPhase[] {
  const wordBankCount = doc.sections.filter((s) => s.hasWordBank).length;
  const passages = doc.sections.filter((s) => s.hasPassage).length;
  const inv = doc.invariants;
  return [
    { key: 'extract', label: 'Extracting words', detail: 'Tesseract.js / PDF.js / DOCX XML — 0 network requests', icon: 'extract', count: wordCount, done: true },
    { key: 'lines', label: 'Reconstructing lines & geometry', detail: `${lineCount} source lines with physical coordinates`, icon: 'lines', count: lineCount, done: true },
    { key: 'sections', label: 'Detecting sections', detail: `${doc.sections.length} sections • ${wordBankCount} word banks • ${passages} passages`, icon: 'sections', count: doc.sections.length, done: true },
    { key: 'questions', label: 'Building the AST', detail: `${doc.totalQuestions} questions • ${doc.totalMarks} marks`, icon: 'questions', count: doc.totalQuestions, done: true },
    {
      key: 'invariants',
      label: 'Validating structural invariants',
      detail: inv ? `${inv.passed}/${inv.total} checks passed • ${inv.violations.filter((v) => !v.isFixed).length} flags` : 'Deterministic physics-of-exams engine',
      icon: 'invariants',
      done: true,
    },
    {
      key: 'provenance',
      label: 'Linking evidence',
      detail: doc.provenanceCoverage !== undefined ? `${doc.provenanceCoverage}% of questions traced to source pixels` : 'Evidence-linked provenance',
      icon: 'provenance',
      done: true,
    },
  ];
}

interface ParseJourneyProps {
  phases: JourneyPhase[];
  /** Replay speed ms per phase; 0 = show final state immediately. */
  replayMs?: number;
  title?: string;
  defaultOpen?: boolean;
}

const ICONS: Record<JourneyPhase['icon'], React.ComponentType<{ className?: string }>> = {
  extract: FileSearch,
  lines: ScanText,
  sections: GitBranch,
  questions: Boxes,
  invariants: ShieldCheck,
  provenance: Sparkles,
};

export const ParseJourney: React.FC<ParseJourneyProps> = ({ phases, replayMs = 550, title = 'Parse Journey', defaultOpen = true }) => {
  const [visibleCount, setVisibleCount] = useState(replayMs === 0 ? phases.length : 0);
  const [open, setOpen] = useState(defaultOpen);

  useEffect(() => {
    setVisibleCount(replayMs === 0 ? phases.length : 0);
    if (replayMs === 0) return;
    let cancelled = false;
    let i = 0;
    const tick = () => {
      if (cancelled) return;
      i += 1;
      setVisibleCount(i);
      if (i < phases.length) {
        window.setTimeout(tick, replayMs);
      }
    };
    const t = window.setTimeout(tick, 250);
    return () => {
      cancelled = true;
      window.clearTimeout(t);
    };
  }, [phases, replayMs]);

  const allDone = visibleCount >= phases.length;
  const totalQuestions = phases.find((p) => p.key === 'questions')?.count || 0;

  return (
    <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <h3 className="text-sm font-bold text-white">{title}</h3>
          {allDone && totalQuestions > 0 && (
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              {totalQuestions} questions in milliseconds • 0 AI tokens
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          {allDone && replayMs > 0 && (
            <button
              onClick={() => setVisibleCount(0)}
              className="p-1.5 text-slate-500 hover:text-indigo-400 rounded-lg hover:bg-slate-800 transition"
              title="Replay"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={() => setOpen(!open)}
            className="p-1.5 text-slate-500 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${open ? '' : '-rotate-90'}`} />
          </button>
        </div>
      </div>

      {open && (
        <div className="space-y-2">
          {phases.slice(0, visibleCount).map((phase, idx) => {
            const Icon = ICONS[phase.icon];
            const isLast = idx === visibleCount - 1 && !allDone;
            return (
              <div
                key={phase.key}
                className={`flex items-center gap-3 p-2.5 rounded-xl border transition-all duration-300 ${
                  isLast
                    ? 'bg-indigo-950/30 border-indigo-500/40 animate-pulse'
                    : 'bg-slate-950/60 border-slate-800'
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                    phase.done ? 'bg-emerald-500/15 text-emerald-400' : 'bg-slate-800 text-slate-500'
                  }`}
                >
                  {phase.done ? <Check className="w-4 h-4" /> : <Loader2 className="w-4 h-4 animate-spin" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <Icon className="w-3.5 h-3.5 text-indigo-400" />
                    <span className="text-xs font-bold text-slate-100">{phase.label}</span>
                    {phase.count !== undefined && (
                      <span className="text-[10px] font-mono text-indigo-300">{phase.count.toLocaleString()}</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 truncate">{phase.detail}</p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
