import React, { useState } from 'react';
import {
  Upload,
  FileCode,
  Sparkles,
  CheckCircle,
  AlertCircle,
  ArrowRight,
  Cpu,
  Layers,
  FileText,
  Image,
  Camera,
  ScanSearch,
} from 'lucide-react';
import { parseAsync } from '../utils/parsePipeline';
import { rememberParseSource } from '../utils/miningSession';
import { extractTextFromFileDetailed } from '../utils/fileExtractor';
import { enhanceForCameraScan } from '../utils/ocrPreprocessor';
import { detectRecipe, applyRecipe, getAllRecipes, saveCustomRecipe, LayoutRecipe } from '../data/layoutRecipes';
import { ParseJourney, JourneyPhase } from './ParseJourney';
import { BUSHEHR_GRADE12_EXAM, MOTAHARI_GRADE9_EXAM } from '../data/sampleExamData';
import { ExamDocument } from '../types/exam';
import { ProviderConfig } from '../types/settings';

interface ParseScreenProps {
  initialTab?: string;
  providerConfig: ProviderConfig;
  onExamParsed: (exam: ExamDocument) => void;
}

export const ParseScreen: React.FC<ParseScreenProps> = ({
  initialTab = 'upload',
  providerConfig,
  onExamParsed,
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'paste' | 'presets'>(
    initialTab === 'paste' ? 'paste' : 'upload',
  );
  const [pastedText, setPastedText] = useState('');
  const [customFileName, setCustomFileName] = useState('custom_exam.txt');
  const [solveWithAi, setSolveWithAi] = useState(false);
  const [brainDrive, setBrainDrive] = useState(true);
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [progressPercent, setProgressPercent] = useState<number | null>(null);
  const [journey, setJourney] = useState<JourneyPhase[] | null>(null);
  const [detectedRecipe, setDetectedRecipe] = useState<{ name: string; remapped: number } | null>(null);
  const [customRecipes, setCustomRecipes] = useState<LayoutRecipe[]>([]);
  const [showRecipeImport, setShowRecipeImport] = useState(false);
  const [recipeJson, setRecipeJson] = useState('');

  React.useEffect(() => {
    getAllRecipes().then((all) => setCustomRecipes(all.filter((r) => r.custom)));
  }, []);

  const handleImportRecipe = async () => {
    try {
      const parsed = JSON.parse(recipeJson);
      if (!parsed.id || !parsed.name || !Array.isArray(parsed.matchAny)) {
        throw new Error('Recipe needs { id, name, matchAny: [regex strings], categoryHints: {} }');
      }
      await saveCustomRecipe({ ...parsed, custom: true, categoryHints: parsed.categoryHints || {} });
      setCustomRecipes(await loadAll());
      setRecipeJson('');
      setShowRecipeImport(false);
    } catch (e: any) {
      alert(`Invalid recipe: ${e.message}`);
    }
  };

  const loadAll = async (): Promise<LayoutRecipe[]> => {
    const all = await getAllRecipes();
    return all.filter((r) => r.custom);
  };

  /** Camera photo -> deskew + shadow removal -> File (snap-to-Excel flow #18) */
  const handleCameraCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setStatusMessage('Enhancing camera scan: deskew + shadow removal...');
      setLoading(true);
      const bitmap = await createImageBitmap(file);
      const canvas = document.createElement('canvas');
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      canvas.getContext('2d')?.drawImage(bitmap, 0, 0);
      const { canvas: enhanced, skewDeg, shadowRemoved } = enhanceForCameraScan(canvas);
      const blob: Blob = await new Promise((resolve) => enhanced.toBlob((b) => resolve(b || file), 'image/png'));
      const processed = new File([blob], `camera-scan-${Date.now()}.png`, { type: 'image/png' });
      setStatusMessage(`Scan enhanced${skewDeg ? ` — deskewed ${skewDeg.toFixed(1)}°` : ''}${shadowRemoved ? ' — shadows flattened' : ''}`);
      // Reuse the normal upload flow with the enhanced file
      await handleFileUploadInner(processed);
    } catch (err: any) {
      console.warn('Camera enhancement failed, falling back to raw file:', err);
      await handleFileUploadInner(file);
    }
  };

  const handleFileUploadInner = async (file: File) => {
    setLoading(true);
    setProgressPercent(null);
    setJourney(null);
    setDetectedRecipe(null);

    try {
      // Always do offline extraction first as the Foundation
      setStatusMessage(`Foundational extraction from ${file.name}...`);
      const extraction = await extractTextFromFileDetailed(file, (status, pct) => {
        setStatusMessage(status);
        setProgressPercent(pct);
      });

      if (!extraction.text || extraction.text.trim().length === 0) {
        throw new Error('No text could be extracted from this file.');
      }

      // EQS (#6): the cascade already picked the winning strategy; report it.
      if (extraction.eqs) {
        const eqs = extraction.eqs;
        setStatusMessage(
          `Extraction quality: ${eqs.score}/100 (${eqs.verdict}) via ${eqs.strategy || extraction.sourceType}`,
        );
        if (eqs.verdict === 'poor') {
          setStatusMessage(
            `Extraction quality is poor (${eqs.score}/100). ${eqs.reasons[0] || 'The scan may be hard to read.'} Parsing anyway — contested areas will be flagged.`,
          );
        }
      }

      // Layout recipes (#19): known formats map Persian section names to categories
      setStatusMessage('Matching layout recipes...');
      const recipeMatch = detectRecipe(extraction.text, await getAllRecipes());

      // Trusted pipeline (#5/#9/#17): parse (worker when large) + provenance +
      // invariants + trust chips, all in one throw-free call.
      const result = await parseAsync(
        {
          rawText: extraction.text,
          filename: file.name,
          lines: extraction.lines,
          eqs: extraction.eqs,
          pictureNotes: extraction.pictureNotes,
          brainDoc: extraction.brainDoc,
          brainMode: brainDrive ? 'drive' : 'advisory',
        },
        (u) => {
          setStatusMessage(u.status);
          setProgressPercent(u.percent);
        },
      );
      if (!result.ok) {
        throw new Error(result.error);
      }
      let exam = result.doc;

      if (recipeMatch) {
        const applied = applyRecipe(exam, recipeMatch.recipe);
        exam = applied.doc;
        setDetectedRecipe({ name: recipeMatch.recipe.name, remapped: applied.remapped });
      }

      // Remember the raw source for rule mining (Idea 1) in this session.
      rememberParseSource(exam.id, extraction.text);

      exam.sourceFile = file;

      // Record the journey for the animated replay (#13)
      setJourney([
        { key: 'extract', label: 'Extracting words', detail: `${extraction.sourceType.toUpperCase()} • 0 network requests`, icon: 'extract', count: extraction.text.split(/\s+/).length, done: true },
        { key: 'lines', label: 'Reconstructing lines & geometry', detail: `${extraction.lines.length} source lines with coordinates`, icon: 'lines', count: extraction.lines.length, done: true },
        { key: 'quality', label: 'Scoring extraction quality (EQS)', detail: extraction.eqs ? `${extraction.eqs.score}/100 (${extraction.eqs.verdict}) via ${extraction.eqs.strategy || extraction.sourceType}` : 'score unavailable', icon: 'sections', done: true },
        { key: 'layout', label: 'Reading the page layout', detail: exam.brainReport ? `Layout brain: ${exam.brainReport.confirmed}/${exam.brainReport.sections} section(s) confirmed (${exam.brainReport.mode})${exam.brainReport.printedTotal ? ` • printed total ${exam.brainReport.printedTotal}` : ''}` : extraction.brainDoc ? 'Layout brain abstained — text rules took over' : 'no geometry (text/OCR path)', icon: 'sections', done: true },
        { key: 'sections', label: 'Detecting sections', detail: recipeMatch ? `Recipe: ${recipeMatch.recipe.name}` : `Rule table${exam.parseTrace?.fallbackUsed ? ' (fallback to legacy scanner)' : ''}`, icon: 'sections', count: exam.sections.length, done: true },
        { key: 'questions', label: 'Building the AST', detail: `${exam.totalQuestions} questions • ${exam.totalMarks} marks`, icon: 'questions', count: exam.totalQuestions, done: true },
        { key: 'invariants', label: 'Validating structural invariants', detail: exam.invariants ? `${exam.invariants.passed}/${exam.invariants.total} checks passed` : 'unavailable', icon: 'invariants', done: true },
        { key: 'provenance', label: 'Linking evidence', detail: `${exam.provenanceCoverage ?? 0}% of questions traced to source pixels`, icon: 'provenance', done: true },
        { key: 'trust', label: 'Truth chips', detail: exam.trust ? `${exam.trust.verified} verified • ${exam.trust.single} single-source • ${exam.trust.contested} contested` : 'unavailable', icon: 'invariants', done: true },
      ]);

      if (solveWithAi) {
        setStatusMessage('AI solving answer keys for contested questions...');
        try {
          const res = await fetch('/api/enhance-exam', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ exam, providerConfig }),
          });
          if (res.ok) {
            const data = await res.json();
            if (data.document) {
              onExamParsed(data.document);
              return;
            }
          }
        } catch (aiErr) {
          console.warn('AI enhance failed, loading offline foundation:', aiErr);
        }
      }

      onExamParsed({
        ...exam,
        parseStage: 'stage1_offline_unsolved',
        isAiSolved: false,
      });
    } catch (err: any) {
      console.error('File parsing error:', err);
      alert(`Parsing Error: ${err.message || 'Failed to parse file'}`);
    } finally {
      setLoading(false);
      setStatusMessage('');
      setProgressPercent(null);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    handleFileUploadInner(file);
  };

  const handleParsePasted = async () => {
    if (!pastedText.trim()) return;

    setLoading(true);
    setStatusMessage('Parsing text with offline AST engine...');
    setJourney(null);

    try {
      const recipeMatch = detectRecipe(pastedText, await getAllRecipes());

      const result = await parseAsync(
        { rawText: pastedText, filename: customFileName },
        (u) => setStatusMessage(u.status),
      );
      if (!result.ok) {
        alert(`Parsing Error: ${result.error}`);
        return;
      }
      let parsed = result.doc;
      if (recipeMatch) {
        const applied = applyRecipe(parsed, recipeMatch.recipe);
        parsed = applied.doc;
        setDetectedRecipe({ name: recipeMatch.recipe.name, remapped: applied.remapped });
      }
      rememberParseSource(parsed.id, pastedText);

      if (solveWithAi) {
        setStatusMessage('AI solving answer keys for contested questions...');
        try {
          const res = await fetch('/api/enhance-exam', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ exam: parsed, providerConfig }),
          });
          if (res.ok) {
            const data = await res.json();
            if (data.document) {
              onExamParsed(data.document);
              return;
            }
          }
        } catch (aiErr) {
          console.warn('AI enhance failed, loading offline foundation:', aiErr);
        }
      }

      onExamParsed({
        ...parsed,
        parseStage: 'stage1_offline_unsolved',
        isAiSolved: false,
      });
    } finally {
      setLoading(false);
      setStatusMessage('');
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-white">Parse Single Exam</h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Ingest Word `.docx`, PDF (digital or scanned), text dumps, or images. Choose between Stage 1 Offline AST and Stage 2 AI Solving.
        </p>
      </div>

      {/* Global AI Mode Banner & Toggle */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center flex-shrink-0">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-bold text-white flex items-center gap-2">
              <span>Pipeline Mode:</span>
              <span className={solveWithAi ? 'text-indigo-400' : 'text-amber-400'}>
                {solveWithAi ? 'Stage 2 (AI-Solved Answer Key)' : 'Stage 1 (Pure Offline Deterministic AST)'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {solveWithAi
                ? `Uses configured provider (${providerConfig.provider}) to solve answer keys and teacher corrections.`
                : '100% offline, 0 network requests, 0 API cost. Extracts stems, choices, marks, word banks.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 self-end sm:self-center">
          <label className="flex items-center gap-2 cursor-pointer select-none" title="The layout brain's geometry-verified boundaries drive the section split whenever they fully confirm (coverage + marks closure verified); untick to always parse with the text splitters.">
            <span className="text-xs font-semibold text-slate-300">Layout brain drives</span>
            <input
              type="checkbox"
              checked={brainDrive}
              onChange={(e) => setBrainDrive(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-600 relative"></div>
          </label>
          <label className="flex items-center gap-2 cursor-pointer select-none">
            <span className="text-xs font-semibold text-slate-300">Solve with AI</span>
            <input
              type="checkbox"
              checked={solveWithAi}
              onChange={(e) => setSolveWithAi(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600 relative"></div>
          </label>
        </div>
      </div>

      {/* Main Tabs Container */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        {/* Tab Buttons */}
        <div className="px-6 pt-4 border-b border-slate-800 flex items-center gap-3 bg-slate-950/40">
          <button
            onClick={() => setActiveTab('upload')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs font-bold border-b-2 transition ${
              activeTab === 'upload'
                ? 'border-indigo-500 text-indigo-400 bg-slate-900'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>Upload File (.docx / .pdf / .txt / images)</span>
          </button>
          <button
            onClick={() => setActiveTab('paste')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs font-bold border-b-2 transition ${
              activeTab === 'paste'
                ? 'border-indigo-500 text-indigo-400 bg-slate-900'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>Paste Raw Text / OCR</span>
          </button>
          <button
            onClick={() => setActiveTab('presets')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs font-bold border-b-2 transition ${
              activeTab === 'presets'
                ? 'border-indigo-500 text-indigo-400 bg-slate-900'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Sample Presets</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6">
          {activeTab === 'upload' && (
            <div className="space-y-4">
              <div className="border-2 border-dashed border-slate-700 hover:border-indigo-500 rounded-2xl p-10 text-center space-y-4 transition bg-slate-950/40">
                <div className="w-14 h-14 rounded-2xl bg-indigo-600/10 text-indigo-400 flex items-center justify-center mx-auto">
                  <Upload className="w-7 h-7" />
                </div>
                <div>
                  {loading ? (
                    <div className="space-y-3">
                      <div className="text-sm font-bold text-indigo-400 animate-pulse">
                        {statusMessage || 'Processing file...'}
                      </div>
                      {typeof progressPercent === 'number' && (
                        <div className="max-w-xs mx-auto space-y-1">
                          <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-indigo-500 transition-all duration-300"
                              style={{ width: `${progressPercent}%` }}
                            />
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono">{progressPercent}%</div>
                        </div>
                      )}
                      <p className="text-xs text-slate-500">
                        Running local offline engine (Tesseract.js / PDF.js / JSZip XML)...
                      </p>
                    </div>
                  ) : (
                    <>
                      <div className="flex flex-col sm:flex-row items-center justify-center gap-2">
                        <label className="cursor-pointer inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-lg shadow-indigo-600/30 transition">
                          <Upload className="w-4 h-4" />
                          <span>Select Exam Document or Image</span>
                          <input
                            type="file"
                            accept=".txt,.docx,.pdf,.ocr,.json,.png,.jpg,.jpeg,.webp,.tiff"
                            onChange={handleFileUpload}
                            className="hidden"
                            disabled={loading}
                          />
                        </label>

                        {/* Snap-to-Excel (#18): camera capture with deskew + shadow removal */}
                        <label className="cursor-pointer inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold border border-slate-700 transition">
                          <Camera className="w-4 h-4 text-emerald-400" />
                          <span>Snap with Camera</span>
                          <input
                            type="file"
                            accept="image/*"
                            capture="environment"
                            onChange={handleCameraCapture}
                            className="hidden"
                            disabled={loading}
                          />
                        </label>
                      </div>
                      <p className="text-xs text-slate-400 mt-3 max-w-md mx-auto leading-relaxed">
                        Drag or select `.docx`, `.pdf`, `.txt`, `.ocr` or image files. Scanned PDFs and phone photos
                        are auto-enhanced (deskew + shadow removal) and recognized via 100% offline OCR.
                      </p>
                      {detectedRecipe && (
                        <div className="inline-flex items-center gap-1.5 mt-2 px-3 py-1.5 rounded-lg bg-emerald-950/30 border border-emerald-800/50 text-[11px] text-emerald-300">
                          <ScanSearch className="w-3.5 h-3.5" />
                          Layout recipe matched: <b>{detectedRecipe.name}</b>
                          {detectedRecipe.remapped > 0 ? ` • ${detectedRecipe.remapped} sections remapped` : ''}
                        </div>
                      )}
                    </>
                  )}
                </div>
              </div>

              {/* Recipe manager (#19) */}
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-bold text-slate-200">Layout Recipes</h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Known exam formats (Persian section names → AST categories) map automatically. Add your school's format as JSON.
                    </p>
                  </div>
                  <button
                    onClick={() => setShowRecipeImport(!showRecipeImport)}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 border border-slate-700 text-[11px] font-semibold text-slate-300 transition"
                  >
                    {showRecipeImport ? 'Hide' : 'Add Recipe'}
                  </button>
                </div>
                {customRecipes.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {customRecipes.map((r) => (
                      <span key={r.id} className="px-2 py-0.5 rounded-full text-[10px] bg-slate-800 text-slate-300 border border-slate-700">
                        {r.name} (custom)
                      </span>
                    ))}
                  </div>
                )}
                {showRecipeImport && (
                  <div className="mt-3 space-y-2">
                    <textarea
                      value={recipeJson}
                      onChange={(e) => setRecipeJson(e.target.value)}
                      rows={5}
                      placeholder={`{
  "id": "my-school",
  "name": "My School Format",
  "matchAny": ["نام\\s*درس[\\s\\S]{0,80}مدرسه"],
  "categoryHints": { "شنیداری": "Listening", "واژگان": "Vocabulary" }
}`}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-[11px] font-mono text-slate-200 focus:outline-none focus:border-indigo-500"
                    />
                    <button
                      onClick={handleImportRecipe}
                      disabled={!recipeJson.trim()}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-[11px] font-bold transition"
                    >
                      Save Recipe
                    </button>
                  </div>
                )}
              </div>

              {/* Parse Journey (#13) — animated replay of what the engine did */}
              {journey && !loading && <ParseJourney phases={journey} />}
            </div>
          )}

          {activeTab === 'paste' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Paste OCR or exam text with row letters (A, B, C...) or question numbers:</span>
                <input
                  type="text"
                  value={customFileName}
                  onChange={(e) => setCustomFileName(e.target.value)}
                  placeholder="Exam title or filename..."
                  className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-slate-300 text-xs w-56 font-mono"
                />
              </div>

              <textarea
                value={pastedText}
                onChange={(e) => setPastedText(e.target.value)}
                rows={12}
                placeholder={`Paste OCR or exam text here, e.g.:\n\nA Choose the correct answer 2\n1. "Why is Amin busy these days?"\na. working on a new project\nb. very tired\n\nD Fill in the blanks with the words given. 2\nfigure effectively appreciate founded compiled\n9. With an American father and a French mother, she is...`}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-4 text-xs font-code text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
              />

              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-500">
                  {pastedText.length > 0 ? `${pastedText.split('\n').length} lines • ${pastedText.length} characters` : ''}
                </span>

                <button
                  disabled={!pastedText.trim() || loading}
                  onClick={handleParsePasted}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-bold transition shadow-lg shadow-indigo-600/30"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>{solveWithAi ? 'Parse & Solve with AI' : 'Parse with Offline AST Engine'}</span>
                </button>
              </div>
            </div>
          )}

          {activeTab === 'presets' && (
            <div className="space-y-3">
              <div className="text-xs text-slate-400 font-medium">
                Load real Iranian national and high school exam papers to test offline parser performance:
              </div>

              {/* Preset 1: Motahari */}
              <div
                onClick={() => onExamParsed(MOTAHARI_GRADE9_EXAM)}
                className="p-4 rounded-xl bg-slate-950 hover:bg-slate-850 border border-emerald-500/40 hover:border-emerald-500 cursor-pointer transition space-y-2 group shadow-lg"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-emerald-300 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                    Motahari Boys High School - Grade 9 English (Prospect 3)
                  </span>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300">
                    24 Items • 10 pts
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Rows A to I. Includes MCQs with multiline choices, Bahador's New Year word bank (10 words in box for 8 blanks), teacher picture questions, dialogue completion, unscramble, spelling, and reading passage.
                </p>
                <div className="text-xs font-semibold text-emerald-400 flex items-center gap-1 pt-1">
                  Load into workbench <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>

              {/* Preset 2: Bushehr */}
              <div
                onClick={() => onExamParsed(BUSHEHR_GRADE12_EXAM)}
                className="p-4 rounded-xl bg-slate-950 hover:bg-slate-850 border border-indigo-500/40 hover:border-indigo-500 cursor-pointer transition space-y-2 group shadow-lg"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-indigo-300 flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-indigo-400" />
                    Bushehr Shariati High School - Grade 12 English (Attached Sample)
                  </span>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300">
                    67 Questions • 32 pts
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  5 pages. Contains Listening (Audio 1-3), Word Bank (10 words), Matching table, Grammar MCQ, Parentheses verb forms, Cloze Test, and 2 full Reading Passages.
                </p>
                <div className="text-xs font-semibold text-indigo-400 flex items-center gap-1 pt-1">
                  Load into workbench <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
