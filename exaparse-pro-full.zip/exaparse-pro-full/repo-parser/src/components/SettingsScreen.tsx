import React, { useState } from 'react';
import {
  Settings,
  Cpu,
  Key,
  Globe,
  Sliders,
  Sparkles,
  CheckCircle2,
  XCircle,
  Loader2,
  Eye,
  EyeOff,
  RefreshCw,
  ShieldCheck,
  AlertTriangle,
  Info,
  Scale,
} from 'lucide-react';
import {
  ProviderConfig,
  AIProvider,
  PROVIDER_DEFAULT_BASE_URLS,
  PROVIDER_DEFAULT_MODELS,
  DEFAULT_PROVIDER_CONFIG,
  JevConfig,
  DEFAULT_JEV_CONFIG,
  JEV_BASE_URLS,
  JEV_DEFAULT_MODELS,
  VisionConfig,
  DEFAULT_VISION_CONFIG,
} from '../types/settings';

interface SettingsScreenProps {
  config: ProviderConfig;
  onSaveConfig: (newConfig: ProviderConfig) => Promise<void>;
  jevConfig?: JevConfig;
  onSaveJevConfig?: (newConfig: JevConfig) => Promise<void>;
  visionConfig?: VisionConfig;
  onSaveVisionConfig?: (newConfig: VisionConfig) => Promise<void>;
  showFullHeaderFields?: boolean;
  onSaveShowFullHeaderFields?: (show: boolean) => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({ config, onSaveConfig, jevConfig, onSaveJevConfig, visionConfig, onSaveVisionConfig, showFullHeaderFields, onSaveShowFullHeaderFields }) => {
  const [provider, setProvider] = useState<AIProvider>(config.provider);
  const [baseURL, setBaseURL] = useState<string>(config.baseURL || PROVIDER_DEFAULT_BASE_URLS[config.provider] || '');
  const [apiKey, setApiKey] = useState<string>(config.apiKey || '');
  const [showKey, setShowKey] = useState<boolean>(false);
  const [model, setModel] = useState<string>(config.model || PROVIDER_DEFAULT_MODELS[config.provider]);
  const [temperature, setTemperature] = useState<number>(config.temperature ?? 0.2);
  const [maxTokens, setMaxTokens] = useState<number>(config.maxTokens ?? 8192);

  // Model Fetching state
  const [availableModels, setAvailableModels] = useState<string[]>([]);
  const [isFetchingModels, setIsFetchingModels] = useState<boolean>(false);

  // Connection Test state
  const [isTesting, setIsTesting] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<{
    ok: boolean;
    model?: string;
    latencyMs?: number;
    sample?: any;
    error?: string;
  } | null>(null);

  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);

  // ---- Jev judge state (judge-ONLY protocol) ----
  const j0 = jevConfig || DEFAULT_JEV_CONFIG;
  const [jevEnabled, setJevEnabled] = useState<boolean>(j0.enabled);
  const [jevBaseUrl, setJevBaseUrl] = useState<string>(j0.baseUrl);
  const [jevApiKey, setJevApiKey] = useState<string>(j0.apiKey);
  const [jevShowKey, setJevShowKey] = useState<boolean>(false);
  const [jevModel, setJevModel] = useState<string>(j0.model);
  const [jevThreshold, setJevThreshold] = useState<number>(j0.threshold);
  const [jevLowBand, setJevLowBand] = useState<number>(j0.lowBand);
  const [jevBatchSize, setJevBatchSize] = useState<number>(j0.batchSize);
  const [jevQuality, setJevQuality] = useState<boolean>(j0.judgeQuality);
  const [jevAutoEscalate, setJevAutoEscalate] = useState<boolean>(j0.autoEscalate);
  const [jevSaved, setJevSaved] = useState<boolean>(false);
  const [jevTesting, setJevTesting] = useState<boolean>(false);
  const [jevTestResult, setJevTestResult] = useState<{ ok: boolean; backend?: string; model?: string; latencyMs?: number; error?: string; warnings?: string[] } | null>(null);

  // ---- Vision (Idea 3) state — no API key here: vision reuses the provider key per-request ----
  const v0 = visionConfig || DEFAULT_VISION_CONFIG;
  const [visionProvider, setVisionProvider] = useState<AIProvider>(v0.provider);
  const [visionBaseURL, setVisionBaseURL] = useState<string>(v0.baseURL || '');
  const [visionModel, setVisionModel] = useState<string>(v0.model);
  const [visionMaxTokens, setVisionMaxTokens] = useState<number>(v0.maxTokens);
  const [visionTextPx, setVisionTextPx] = useState<number>(v0.textImagePx);
  const [visionPhotoPx, setVisionPhotoPx] = useState<number>(v0.photoImagePx);
  const [visionMaxImages, setVisionMaxImages] = useState<number>(v0.maxImagesPerCall);
  const [visionThreshold, setVisionThreshold] = useState<number>(v0.placementThreshold);
  const [visionSaved, setVisionSaved] = useState<boolean>(false);

  const buildVisionConfig = (): VisionConfig => ({
    ...DEFAULT_VISION_CONFIG,
    enabled: true,
    provider: visionProvider,
    baseURL: visionBaseURL,
    model: visionModel,
    maxTokens: visionMaxTokens,
    textImagePx: visionTextPx,
    photoImagePx: visionPhotoPx,
    maxImagesPerCall: visionMaxImages,
    placementThreshold: visionThreshold,
  });

  const handleSaveVision = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onSaveVisionConfig) return;
    await onSaveVisionConfig(buildVisionConfig());
    setVisionSaved(true);
    setTimeout(() => setVisionSaved(false), 3000);
  };

  const handleJevPreset = (which: 'typesafe' | 'openrouter') => {
    setJevBaseUrl(JEV_BASE_URLS[which]);
    setJevModel(JEV_DEFAULT_MODELS[which]);
    setJevTestResult(null);
  };

  const buildJevConfig = (): JevConfig => ({
    enabled: jevEnabled,
    baseUrl: jevBaseUrl.trim().replace(/\/+$/, ''),
    apiKey: jevApiKey.trim(),
    model: jevModel.trim() || JEV_DEFAULT_MODELS.openrouter,
    threshold: Math.min(0.99, Math.max(0.5, jevThreshold)),
    lowBand: Math.min(0.45, Math.max(0.01, jevLowBand)),
    batchSize: Math.min(60, Math.max(1, Math.round(jevBatchSize || 20))),
    judgeQuality: jevQuality,
    autoEscalate: jevAutoEscalate,
  });

  const handleSaveJev = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onSaveJevConfig) return;
    await onSaveJevConfig(buildJevConfig());
    setJevSaved(true);
    setTimeout(() => setJevSaved(false), 3000);
  };

  const handleTestJev = async () => {
    setJevTesting(true);
    setJevTestResult(null);
    try {
      const res = await fetch('/api/judge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'test',
          jevConfig: buildJevConfig(),
          providerConfig: { ...config, apiKey: config.apiKey },
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        setJevTestResult({ ok: true, backend: data.backend, model: data.model, latencyMs: data.latencyMs, warnings: data.warnings });
      } else {
        setJevTestResult({ ok: false, error: data.error || `HTTP ${res.status}`, warnings: data.warnings });
      }
    } catch (err: any) {
      setJevTestResult({ ok: false, error: err.message || 'Network request failed' });
    } finally {
      setJevTesting(false);
    }
  };

  // Switch provider handler: auto-fills standard baseURL and default model
  const handleProviderChange = (newProvider: AIProvider) => {
    setProvider(newProvider);
    setBaseURL(PROVIDER_DEFAULT_BASE_URLS[newProvider]);
    setModel(PROVIDER_DEFAULT_MODELS[newProvider]);
    setAvailableModels([]);
    setTestResult(null);
  };

  // Fetch models from provider
  const handleFetchModels = async () => {
    setIsFetchingModels(true);
    setTestResult(null);
    try {
      const res = await fetch('/api/list-models', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider,
          baseURL,
          apiKey,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `HTTP ${res.status}`);
      }

      const data = await res.json();
      if (Array.isArray(data.models) && data.models.length > 0) {
        setAvailableModels(data.models);
      } else {
        alert('No models returned from provider list.');
      }
    } catch (err: any) {
      alert(`Failed to fetch models: ${err.message}`);
    } finally {
      setIsFetchingModels(false);
    }
  };

  // Test connection
  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);

    const testPayload: ProviderConfig = {
      provider,
      baseURL,
      apiKey,
      model,
      temperature,
      maxTokens,
    };

    try {
      const res = await fetch('/api/test-provider', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ providerConfig: testPayload }),
      });

      const data = await res.json();
      if (res.ok && data.ok) {
        setTestResult({
          ok: true,
          model: data.model,
          latencyMs: data.latencyMs,
          sample: data.sample,
        });
      } else {
        setTestResult({
          ok: false,
          error: data.error || 'Connection test failed',
        });
      }
    } catch (err: any) {
      setTestResult({
        ok: false,
        error: err.message || 'Network request failed',
      });
    } finally {
      setIsTesting(false);
    }
  };

  // Save Settings
  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const updated: ProviderConfig = {
      provider,
      baseURL: provider === 'gemini' ? '' : baseURL,
      apiKey: apiKey.trim(),
      model: model.trim(),
      temperature,
      maxTokens,
    };

    await onSaveConfig(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleResetDefaults = () => {
    if (!window.confirm('Reset AI provider settings to defaults?')) return;
    setProvider(DEFAULT_PROVIDER_CONFIG.provider);
    setBaseURL(DEFAULT_PROVIDER_CONFIG.baseURL || '');
    setApiKey('');
    setModel(DEFAULT_PROVIDER_CONFIG.model);
    setTemperature(DEFAULT_PROVIDER_CONFIG.temperature);
    setMaxTokens(DEFAULT_PROVIDER_CONFIG.maxTokens);
    setTestResult(null);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2.5">
          <Settings className="w-6 h-6 text-indigo-400" />
          AI Provider & Engine Settings
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Configure which LLM powers Stage 2 exam solving. Run against Gemini, OpenAI, OpenRouter, local Ollama, or custom OpenAI-compatible gateways.
        </p>
      </div>

      {/* Regional Block & Bypass Callout */}
      <div className="p-4 rounded-2xl bg-indigo-950/30 border border-indigo-500/30 flex items-start gap-3 text-xs leading-relaxed text-slate-300">
        <Info className="w-5 h-5 text-indigo-400 flex-shrink-0 mt-0.5" />
        <div>
          <span className="font-bold text-indigo-300">Regional Block & VPN-Free Access Note: </span>
          Users located in regions where direct Google Gemini or OpenAI API calls are blocked (such as Iran) can configure an
          OpenAI-compatible gateway (e.g., <strong className="text-white">OpenRouter</strong>, <strong className="text-white">Vercel AI Gateway</strong>, or a local <strong className="text-white">Ollama</strong> instance on <code className="text-indigo-300 bg-slate-950 px-1 py-0.5 rounded font-mono">http://localhost:11434/v1</code>) to parse and solve exams seamlessly without needing a VPN.
          Alternatively, the <strong>Stage 1 Offline AST engine</strong> runs 100% locally with zero internet access required.
        </div>
      </div>

      {/* Main Settings Form */}
      <form onSubmit={handleSave} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6 shadow-xl">
        {/* Field 1: Provider Selection */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <Cpu className="w-4 h-4 text-indigo-400" />
            AI Provider
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {[
              { id: 'gemini' as AIProvider, label: 'Google Gemini (Native)' },
              { id: 'openai' as AIProvider, label: 'OpenAI' },
              { id: 'openrouter' as AIProvider, label: 'OpenRouter' },
              { id: 'vercel' as AIProvider, label: 'Vercel AI Gateway' },
              { id: 'ollama' as AIProvider, label: 'Ollama (Local)' },
              { id: 'custom' as AIProvider, label: 'Custom (OpenAI-compatible)' },
            ].map((p) => (
              <button
                type="button"
                key={p.id}
                onClick={() => handleProviderChange(p.id)}
                className={`p-3 rounded-xl border text-left text-xs font-semibold transition ${
                  provider === p.id
                    ? 'border-indigo-500 bg-indigo-600/20 text-indigo-300 shadow-md'
                    : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Field 2: Base URL (Hidden for Gemini Native) */}
        {provider !== 'gemini' && (
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Globe className="w-4 h-4 text-indigo-400" />
              API Base URL
            </label>
            <input
              type="text"
              value={baseURL}
              onChange={(e) => setBaseURL(e.target.value)}
              placeholder="https://api.openai.com/v1"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
            />
            <p className="text-[11px] text-slate-500">
              The root endpoint of your OpenAI-compatible API (calls will be routed to <code className="font-mono">{baseURL}/chat/completions</code>).
            </p>
          </div>
        )}

        {/* Field 3: API Key */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Key className="w-4 h-4 text-indigo-400" />
              API Key {provider === 'ollama' && <span className="text-slate-500 font-normal lowercase">(optional for local Ollama)</span>}
            </label>
            <span className="text-[11px] text-slate-500 font-mono">Stored only in your browser (IndexedDB)</span>
          </div>

          <div className="relative">
            <input
              type={showKey ? 'text' : 'password'}
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder={provider === 'gemini' ? 'AIzaSy...' : 'sk-...'}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-4 pr-10 py-2.5 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
            />
            <button
              type="button"
              onClick={() => setShowKey(!showKey)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
            >
              {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Field 4: Model Selector with "Fetch Models" */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Model Identifier
            </label>

            <button
              type="button"
              onClick={handleFetchModels}
              disabled={isFetchingModels}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-750 text-indigo-400 text-xs font-semibold transition"
            >
              {isFetchingModels ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
              <span>Fetch Models</span>
            </button>
          </div>

          <div className="space-y-2">
            <input
              type="text"
              value={model}
              onChange={(e) => setModel(e.target.value)}
              placeholder="e.g. gemini-2.5-flash, gpt-4o-mini, deepseek/deepseek-chat"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500"
            />

            {availableModels.length > 0 && (
              <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 font-semibold px-2">Select from discovered models:</span>
                <div className="max-h-36 overflow-y-auto divide-y divide-slate-850">
                  {availableModels.map((m) => (
                    <div
                      key={m}
                      onClick={() => setModel(m)}
                      className={`p-1.5 px-2 rounded-lg text-xs font-mono cursor-pointer transition ${
                        model === m ? 'bg-indigo-600 text-white' : 'text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      {m}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Sliders: Temperature & Max Tokens */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300 uppercase tracking-wider">Temperature</span>
              <span className="font-mono text-indigo-400">{temperature}</span>
            </div>
            <input
              type="range"
              min="0.0"
              max="1.0"
              step="0.05"
              value={temperature}
              onChange={(e) => setTemperature(parseFloat(e.target.value))}
              className="w-full accent-indigo-500 bg-slate-800 rounded-lg h-2"
            />
            <p className="text-[10px] text-slate-500">Lower values (0.1–0.3) provide more deterministic and accurate exam answer keys.</p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300 uppercase tracking-wider">Max Output Tokens</span>
              <span className="font-mono text-indigo-400">{maxTokens}</span>
            </div>
            <input
              type="number"
              min={1000}
              max={32768}
              step={512}
              value={maxTokens}
              onChange={(e) => setMaxTokens(parseInt(e.target.value, 10) || 8192)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-1.5 text-xs font-mono text-slate-200 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Test Connection Banner */}
        <div className="pt-2 border-t border-slate-800 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h4 className="text-xs font-bold text-white">Diagnostics & Verification</h4>
              <p className="text-[11px] text-slate-400">Send a lightweight round-trip query to verify credentials and measure latency.</p>
            </div>

            <button
              type="button"
              disabled={isTesting}
              onClick={handleTestConnection}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-indigo-300 text-xs font-semibold border border-indigo-500/30 transition disabled:opacity-50"
            >
              {isTesting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
              <span>Test Connection</span>
            </button>
          </div>

          {/* Test Result Display */}
          {testResult && (
            <div
              className={`p-3.5 rounded-xl border text-xs space-y-1.5 animate-fadeIn ${
                testResult.ok
                  ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300'
                  : 'bg-red-950/20 border-red-500/40 text-red-300'
              }`}
            >
              <div className="flex items-center gap-2 font-bold">
                {testResult.ok ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Connection Verified Successfully</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-200">
                      {testResult.latencyMs} ms
                    </span>
                  </>
                ) : (
                  <>
                    <XCircle className="w-4 h-4 text-red-400" />
                    <span>Connection Failed</span>
                  </>
                )}
              </div>

              {testResult.ok ? (
                <div className="text-[11px] text-slate-300 font-mono">
                  Model responded: <strong>{testResult.model}</strong>
                </div>
              ) : (
                <div className="text-[11px] text-red-300 leading-relaxed">
                  {testResult.error}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="text-xs text-slate-500 hover:text-slate-300 transition"
          >
            Reset to Defaults
          </button>

          <div className="flex items-center gap-3">
            {savedSuccess && (
              <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Saved!
              </span>
            )}
            <button
              type="submit"
              className="px-6 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 transition"
            >
              Save Settings
            </button>
          </div>
        </div>
      </form>

      {/* ================= JEV JUDGE (judge-only protocol) ================= */}
      <form onSubmit={handleSaveJev} className="bg-slate-900 border border-cyan-900/60 rounded-2xl p-6 space-y-6 shadow-xl">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h2 className="text-sm font-extrabold text-white flex items-center gap-2">
              <Scale className="w-4 h-4 text-cyan-400" />
              Jev Judge — calibrated second opinion
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 font-semibold">judge only — never writes answers</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Jev (TypeSafe's System One decision model) evaluates each solved question with typed questions — P(correct) as a
              calibrated probability, a category label, and a well-formedness score — and returns typed answers instead of text.
              It never parses, solves, or edits anything. High-confidence verdicts strengthen trust; uncertain ones escalate to the
              existing 3-vote adjudicator. Judgments are cached by content fingerprint in your browser — re-running is near-free.
              <span className="text-slate-500"> If no Jev endpoint is reachable (geo-blocks), the judge automatically runs on your AI provider with the same results shape.</span>
            </p>
          </div>
          <label className="flex items-center gap-2 cursor-pointer select-none shrink-0">
            <input type="checkbox" checked={jevEnabled} onChange={(e) => setJevEnabled(e.target.checked)} className="w-4 h-4 accent-cyan-500" />
            <span className="text-xs font-bold text-slate-200">Enable Jev judging</span>
          </label>
        </div>

        {/* Endpoint presets */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Jev Endpoint (verified System One API)</label>
            <div className="flex gap-2">
              <button type="button" onClick={() => handleJevPreset('openrouter')} className={`px-3 py-1.5 rounded-lg text-[11px] font-semibold border transition ${jevBaseUrl === JEV_BASE_URLS.openrouter ? 'bg-cyan-600/20 text-cyan-300 border-cyan-500/40' : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'}`}>
                OpenRouter
              </button>
              <button type="button" onClick={() => handleJevPreset('typesafe')} className={`px-3 py-1.5 rounded-lg text-[11px] font-semibold border transition ${jevBaseUrl === JEV_BASE_URLS.typesafe ? 'bg-cyan-600/20 text-cyan-300 border-cyan-500/40' : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'}`}>
                TypeSafe direct
              </button>
            </div>
            <input
              type="text"
              value={jevBaseUrl}
              onChange={(e) => setJevBaseUrl(e.target.value)}
              placeholder="https://openrouter.ai/api/v1"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500"
            />
            <p className="text-[11px] text-slate-500">
              Both endpoints expose the identical request shape (<code className="font-mono">POST /systemone</code>). OpenRouter is the usual choice in regions with blocked APIs.
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Jev API Key</label>
              <span className="text-[11px] text-slate-500 font-mono">browser-only, sent per request, never stored server-side</span>
            </div>
            <div className="relative">
              <input
                type={jevShowKey ? 'text' : 'password'}
                value={jevApiKey}
                onChange={(e) => setJevApiKey(e.target.value)}
                placeholder="sk-or-... (OpenRouter) or TypeSafe key"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-4 pr-10 py-2.5 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500"
              />
              <button type="button" onClick={() => setJevShowKey(!jevShowKey)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300">
                {jevShowKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Model</label>
            <input
              type="text"
              value={jevModel}
              onChange={(e) => setJevModel(e.target.value)}
              placeholder="typesafe/jev-1.13"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        {/* Cascade + batching */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300 uppercase tracking-wider">Accept threshold</span>
              <span className="font-mono text-cyan-400">≥ {jevThreshold.toFixed(2)}</span>
            </div>
            <input type="range" min="0.5" max="0.99" step="0.01" value={jevThreshold} onChange={(e) => setJevThreshold(parseFloat(e.target.value))} className="w-full accent-cyan-500 bg-slate-800 rounded-lg h-2" />
            <p className="text-[10px] text-slate-500">P(correct) at or above this marks the answer “correct” (act band).</p>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300 uppercase tracking-wider">Reject band</span>
              <span className="font-mono text-cyan-400">≤ {jevLowBand.toFixed(2)}</span>
            </div>
            <input type="range" min="0.01" max="0.45" step="0.01" value={jevLowBand} onChange={(e) => setJevLowBand(parseFloat(e.target.value))} className="w-full accent-cyan-500 bg-slate-800 rounded-lg h-2" />
            <p className="text-[10px] text-slate-500">At or below this the answer is flagged as likely wrong. Between the bands = uncertain → escalate.</p>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300 uppercase tracking-wider">Questions per judge call</span>
              <span className="font-mono text-cyan-400">{jevBatchSize}</span>
            </div>
            <input
              type="number"
              min={1}
              max={60}
              value={jevBatchSize}
              onChange={(e) => setJevBatchSize(parseInt(e.target.value, 10) || 20)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-1.5 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
            />
            <p className="text-[10px] text-slate-500">Jev answers many typed questions in ONE call against a shared state — batching keeps call count tiny (a 60-question exam ≈ 3 calls).</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center gap-4 flex-wrap">
          <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
            <input type="checkbox" checked={jevQuality} onChange={(e) => setJevQuality(e.target.checked)} className="w-4 h-4 accent-cyan-500" />
            Also score extraction well-formedness (feeds the Trust Engine)
          </label>
          <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
            <input type="checkbox" checked={jevAutoEscalate} onChange={(e) => setJevAutoEscalate(e.target.checked)} className="w-4 h-4 accent-cyan-500" />
            Auto-escalate uncertain questions to the 3-vote adjudicator
          </label>
        </div>

        {/* Test + save row */}
        <div className="pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleTestJev}
            disabled={jevTesting}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-cyan-300 text-xs font-semibold border border-cyan-500/30 transition disabled:opacity-50"
          >
            {jevTesting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
            <span>Test Jev connection</span>
          </button>

          <div className="flex items-center gap-3">
            {jevSaved && (
              <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Saved!
              </span>
            )}
            <button type="submit" className="px-6 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-lg shadow-cyan-900/30 transition">
              Save Jev Settings
            </button>
          </div>
        </div>

        {jevTestResult && (
          <div className={`p-3.5 rounded-xl border text-xs space-y-1.5 ${jevTestResult.ok ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300' : 'bg-red-950/20 border-red-500/40 text-red-300'}`}>
            <div className="flex items-center gap-2 font-bold">
              {jevTestResult.ok ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Judge reachable</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-200">{jevTestResult.backend}</span>
                  {jevTestResult.latencyMs !== undefined && <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-200">{jevTestResult.latencyMs} ms</span>}
                </>
              ) : (
                <>
                  <XCircle className="w-4 h-4 text-red-400" />
                  <span>Judge test failed</span>
                </>
              )}
            </div>
            {jevTestResult.ok && jevTestResult.model && <div className="text-[11px] text-slate-300 font-mono">Judge model: {jevTestResult.model}</div>}
            {!jevTestResult.ok && <div className="text-[11px] text-red-300 leading-relaxed">{jevTestResult.error}</div>}
            {Array.isArray(jevTestResult.warnings) && jevTestResult.warnings.length > 0 && (
              <div className="text-[11px] text-amber-300/90">{jevTestResult.warnings.join(' ')}</div>
            )}
          </div>
        )}
      </form>

      {/* ---- Vision (Idea 3) — image understanding settings ---- */}
      <form onSubmit={handleSaveVision} className="bg-slate-900 border border-fuchsia-900/60 rounded-2xl p-6 space-y-6 shadow-xl">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-fuchsia-400" /> Vision — image understanding
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed max-w-2xl">
              Used ONLY when you press "Image alts" or "Vision re-transcribe" on an exam — never automatically on parse.
              Transcribes text inside embedded images (labeled diagrams, tables) or describes photos, and re-transcribes
              scanned pages in reading order. Every result is cached by content hash (re-runs are free) and stays editable
              in the review editor. Vision reuses the API key you configured above — sent per-request, never stored here.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Vision provider</label>
            <select
              value={visionProvider}
              onChange={(e) => setVisionProvider(e.target.value as AIProvider)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-fuchsia-500/50"
            >
              {(Object.keys(PROVIDER_DEFAULT_BASE_URLS) as AIProvider[]).map((p) => (
                <option key={p} value={p}>{p}</option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Vision model (must be vision-capable)</label>
            <input
              type="text"
              value={visionModel}
              onChange={(e) => setVisionModel(e.target.value)}
              placeholder="gemini-2.5-flash / gpt-4o-mini"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-fuchsia-500/50"
            />
          </div>
          {visionProvider === 'custom' && (
            <div className="space-y-1.5 sm:col-span-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Vision base URL (OpenAI-compatible)</label>
              <input
                type="text"
                value={visionBaseURL}
                onChange={(e) => setVisionBaseURL(e.target.value)}
                placeholder={PROVIDER_DEFAULT_BASE_URLS.custom}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-fuchsia-500/50"
              />
            </div>
          )}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Text-image resolution (px long edge)</label>
            <input type="number" min={512} max={2048} step={64} value={visionTextPx}
              onChange={(e) => setVisionTextPx(parseInt(e.target.value, 10) || 1024)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-fuchsia-500/50" />
            <p className="text-[10px] text-slate-500">Gentle downscale for diagrams/screenshots so small labels stay legible.</p>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Photo resolution (px long edge)</label>
            <input type="number" min={256} max={1024} step={32} value={visionPhotoPx}
              onChange={(e) => setVisionPhotoPx(parseInt(e.target.value, 10) || 512)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-fuchsia-500/50" />
            <p className="text-[10px] text-slate-500">Aggressive downscale for photos — no text to preserve.</p>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Max images per call</label>
            <input type="number" min={1} max={20} value={visionMaxImages}
              onChange={(e) => setVisionMaxImages(parseInt(e.target.value, 10) || 12)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-fuchsia-500/50" />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Auto-place threshold: {(visionThreshold * 100).toFixed(0)}%</label>
            <input type="range" min="0.5" max="0.95" step="0.01" value={visionThreshold}
              onChange={(e) => setVisionThreshold(parseFloat(e.target.value))}
              className="w-full accent-fuchsia-500 bg-slate-800 rounded-lg h-2" />
            <p className="text-[10px] text-slate-500">Below this positional confidence, placements wait in the review queue instead of being applied.</p>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Max output tokens</label>
            <input type="number" min={512} max={16384} step={256} value={visionMaxTokens}
              onChange={(e) => setVisionMaxTokens(parseInt(e.target.value, 10) || 4096)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-fuchsia-500/50" />
          </div>
        </div>

        <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
          {visionSaved && (
            <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> Saved!
            </span>
          )}
          <button type="submit" className="px-6 py-2 rounded-xl bg-fuchsia-600 hover:bg-fuchsia-500 text-white text-xs font-bold shadow-lg shadow-fuchsia-900/30 transition">
            Save Vision Settings
          </button>
        </div>
      </form>

      {/* Privacy — surface filter (D4): personal header metadata never surfaces by default */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-1">
          <ShieldCheck className="w-5 h-5 text-emerald-400" />
          <h2 className="text-lg font-bold text-white">Privacy — Personal Metadata</h2>
        </div>
        <p className="text-xs text-slate-400 mb-4">
          School, teacher, exam date and district fields are extracted for parsing but
          hidden from the interface, removed from AI requests, and stripped from every
          export by default. Grade, course, duration and term are always kept.
        </p>
        <label className="flex items-start gap-3 cursor-pointer bg-slate-950/60 border border-slate-800 rounded-xl p-4">
          <input
            type="checkbox"
            checked={!!showFullHeaderFields}
            onChange={(e) => onSaveShowFullHeaderFields?.(e.target.checked)}
            className="mt-0.5 w-4 h-4 accent-emerald-500"
          />
          <span>
            <span className="text-sm font-semibold text-slate-200">Show full header fields (power users)</span>
            <span className="block text-xs text-slate-500 mt-1">
              Off = filtered everywhere (recommended). On = the raw extracted values
              reappear in the UI and exports on THIS device only.
            </span>
          </span>
        </label>
      </div>
    </div>
  );
};
