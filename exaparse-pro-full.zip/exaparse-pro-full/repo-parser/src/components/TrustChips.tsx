import React from 'react';
import { ShieldCheck, ShieldAlert, Shield } from 'lucide-react';
import { QuestionItem } from '../types/exam';

/**
 * Truth Chips (#9): one dot per question — 🟢 verified / 🟡 single-source /
 * 🔴 contested — with a plain-language legend. This is the component that
 * turns "trust me" into "look at the map".
 */

export const TRUST_META = {
  verified: {
    label: 'Verified',
    color: 'text-emerald-400',
    dot: 'bg-emerald-400',
    ring: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
    icon: ShieldCheck,
    help: 'Traced to its source pixels and it passed every structural rule. Nothing to do.',
  },
  single: {
    label: 'Single source',
    color: 'text-amber-400',
    dot: 'bg-amber-400',
    ring: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
    icon: Shield,
    help: 'Parsed from one source only (no second reading, or low OCR confidence). Glance at it once.',
  },
  contested: {
    label: 'Contested',
    color: 'text-rose-400',
    dot: 'bg-rose-400',
    ring: 'bg-rose-500/15 text-rose-300 border-rose-500/30',
    icon: ShieldAlert,
    help: 'A structural rule failed or the two extraction paths disagree. Look here first.',
  },
} as const;

export type TrustLevel = keyof typeof TRUST_META;

export const TrustDot: React.FC<{ level?: TrustLevel | string; size?: 'sm' | 'md' }> = ({ level, size = 'sm' }) => {
  const meta = TRUST_META[(level as TrustLevel) || 'single'] || TRUST_META.single;
  const dim = size === 'md' ? 'w-3 h-3' : 'w-2 h-2';
  return <span className={`inline-block rounded-full ${meta.dot} ${dim}`} title={`${meta.label}: ${meta.help}`} />;
};

export const TrustBadge: React.FC<{ level?: TrustLevel | string }> = ({ level }) => {
  const meta = TRUST_META[(level as TrustLevel) || 'single'] || TRUST_META.single;
  const Icon = meta.icon;
  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold border ${meta.ring}`}
      title={meta.help}
    >
      <Icon className="w-2.5 h-2.5" />
      {meta.label}
    </span>
  );
};

/** Document-level summary: "Verified 58/60" + mini distribution. */
export const TrustSummaryBadge: React.FC<{ verified: number; single: number; contested: number; total: number }> = ({
  verified,
  single,
  contested,
  total,
}) => {
  const pct = total > 0 ? Math.round((verified / total) * 100) : 0;
  return (
    <span
      className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-slate-800/80 text-slate-300 border border-slate-700"
      title="🟢 verified = traced to source + all structural rules pass. 🟡 single-source. 🔴 needs your eyes."
    >
      <span className="flex items-center gap-1">
        <span className="w-2 h-2 rounded-full bg-emerald-400" /> {verified}
      </span>
      {single > 0 && (
        <span className="flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-amber-400" /> {single}
        </span>
      )}
      {contested > 0 && (
        <span className="flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-rose-400" /> {contested}
        </span>
      )}
      <span className="text-slate-500">|</span>
      <span className={pct >= 90 ? 'text-emerald-300' : pct >= 70 ? 'text-amber-300' : 'text-rose-300'}>{pct}% verified</span>
    </span>
  );
};

/** Convenience: read the level off a question object. */
export function trustLevelOf(q: QuestionItem): TrustLevel {
  return (q.trustLevel as TrustLevel) || 'single';
}

/**
 * Jev trust chip: shows the calibrated judge verdict on judged questions.
 * 🟢 P ≥ threshold → "Jev ✓ 0.96" · 🔴 rejected · 🟡 unsure. Judge-ONLY —
 * this chip never appears on questions Jev didn't evaluate.
 */
export const JevChip: React.FC<{ question: QuestionItem; threshold?: number }> = ({ question, threshold = 0.9 }) => {
  const jev = question.jev;
  if (!jev) return null;
  const p = typeof jev.pCorrect === 'number' ? jev.pCorrect : undefined;
  const pct = p !== undefined ? Math.round(p * 100) : null;

  const meta =
    jev.verdict === 'correct'
      ? { ring: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30', title: `Jev judge confirmed the answer (P=${p?.toFixed(2)} ≥ ${threshold}). Category: ${jev.category || '—'}.`, label: `Jev ✓ ${pct}%` }
      : jev.verdict === 'incorrect'
        ? { ring: 'bg-rose-500/15 text-rose-300 border-rose-500/30', title: `Jev judge believes the marked answer is WRONG (P(correct)=${p?.toFixed(2)}). Re-judge or review by hand.`, label: `Jev ✗ ${pct}%` }
        : { ring: 'bg-amber-500/15 text-amber-300 border-amber-500/30', title: `Jev judge was unsure (P=${p?.toFixed(2)} — mid band). Escalated to the 3-vote adjudicator / review by hand.`, label: `Jev ? ${pct}%` };

  return (
    <span
      className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-bold border ${meta.ring}`}
      title={meta.title}
    >
      {meta.label}
      {jev.backend === 'llm-fallback' && <span className="opacity-60" title="Judged by the LLM fallback (native Jev unreachable)">⌁</span>}
      {jev.cached && <span className="opacity-60" title="Served from the local judge cache — 0 tokens">↻</span>}
    </span>
  );
};
