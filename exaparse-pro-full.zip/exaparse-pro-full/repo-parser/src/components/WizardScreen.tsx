import React, { useCallback, useRef, useState } from 'react';
import {
  Upload,
  Camera,
  FileCode,
  Sparkles,
  ScanSearch,
  ArrowRight,
  ClipboardPaste,
  ShieldCheck,
  Loader2,
} from 'lucide-react';
import { ExamDocument } from '../types/exam';
import { extractTextFromFileDetailed } from '../utils/fileExtractor';
import { parseAsync, ParseStageUpdate } from '../utils/parsePipeline';
import { rememberParseSource } from '../utils/miningSession';
import { detectRecipe, applyRecipe, getAllRecipes } from '../data/layoutRecipes';
import { enhanceForCameraScan } from '../utils/ocrPreprocessor';
import { loadResumeState, clearResumeState } from '../utils/diagnostics';
import { logBlackBox } from '../utils/diagnostics';

/**
 * One-screen Wizard (#16): the whole product on a single dropzone.
 * No tabs, no jargon, no configuration. Drop a file -> watch honest progress
 * -> land in the review view with trust chips already computed. Advanced
 * users can still reach the full ParseScreen from the sidebar.
 */

interface WizardScreenProps {
  onExamParsed: (exam: ExamDocument) => void;
  onOpenLibrary: () => void;
  onOpenAdvanced: () => void;
  hasExams: boolean;
}

type Busy =
  | { kind: 'none' }
  | { kind: 'working'; status: string; percent: number }
  | { kind: 'error'; message: string };

export const WizardScreen: React.FC<WizardScreenProps> = ({
  onExamParsed,
  onOpenLibrary,
  onOpenAdvanced,
  hasExams,
}) => {
  const [busy, setBusy] = useState<Busy>({ kind: 'none' });
  const [dragOver, setDragOver] = useState(false);
  const [pasteMode, setPasteMode] = useState(false);
  const [pastedText, setPastedText] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const resume = loadResumeState();

  const handleStage = useCallback((u: ParseStageUpdate) => {
    setBusy({ kind: 'working', status: u.status, percent: u.percent });
  }, []);

  const finishParse = useCallback(
    (doc: ExamDocument) => {
      logBlackBox({ event: 'parse_start', filename: doc.filename });
      onExamParsed(doc);
    },
    [onExamParsed],
  );

  const processFile = useCallback(
    async (file: File) => {
      setBusy({ kind: 'working', status: `Reading ${file.name}...`, percent: 4 });
      logBlackBox({ event: 'parse_start', filename: file.name });
      try {
        const extraction = await extractTextFromFileDetailed(file, (status, pct) =>
          setBusy({ kind: 'working', status, percent: Math.min(pct || 0, 50) }),
        );

        if (!extraction.text || !extraction.text.trim()) {
          setBusy({
            kind: 'error',
            message:
              'No readable text was found in this file. If it is a scan, make sure the photo is sharp, straight and well-lit — then try again.',
          });
          return;
        }

        const recipeMatch = detectRecipe(extraction.text, await getAllRecipes());
        let rawText = extraction.text;
        let doc: ExamDocument;

        const result = await parseAsync(
          { rawText, filename: file.name, lines: extraction.lines, eqs: extraction.eqs, pictureNotes: extraction.pictureNotes, brainDoc: extraction.brainDoc },
          handleStage,
        );

        if (!result.ok) {
          setBusy({
            kind: 'error',
            message: `The parser could not process this file: ${result.error}. You can paste the text manually instead — the engine will do the rest.`,
          });
          return;
        }
        doc = result.doc;

        if (recipeMatch) {
          const applied = applyRecipe(doc, recipeMatch.recipe);
          doc = applied.doc;
        }

        // Remember the raw source for rule mining (Idea 1) in this session.
        rememberParseSource(doc.id, rawText);

        doc.sourceFile = file;
        finishParse(doc);
      } catch (e: any) {
        setBusy({ kind: 'error', message: e?.message || 'Something went wrong while reading the file.' });
      }
    },
    [finishParse, handleStage],
  );

  const handleCameraCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy({ kind: 'working', status: 'Enhancing your photo (deskew + shadow removal)...', percent: 2 });
    try {
      const bitmap = await createImageBitmap(file);
      const canvas = document.createElement('canvas');
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      canvas.getContext('2d')?.drawImage(bitmap, 0, 0);
      const { canvas: enhanced } = enhanceForCameraScan(canvas);
      const blob: Blob = await new Promise((resolve) => enhanced.toBlob((b) => resolve(b || file), 'image/png'));
      await processFile(new File([blob], `camera-scan.png`, { type: 'image/png' }));
    } catch {
      await processFile(file);
    }
  };

  const handleParsePaste = async () => {
    if (!pastedText.trim()) return;
    const result = await parseAsync(
      { rawText: pastedText, filename: 'pasted_exam.txt' },
      handleStage,
    );
    if (!result.ok) {
      setBusy({ kind: 'error', message: `Could not parse the pasted text: ${result.error}` });
      return;
    }
    rememberParseSource(result.doc.id, pastedText);
    finishParse(result.doc);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Hero */}
      <div className="text-center space-y-2 pt-4">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
          Drop an exam. Get <span className="text-indigo-400">proof-read</span> structure.
        </h1>
        <p className="text-sm text-slate-400 max-w-xl mx-auto">
          Everything runs offline on your device: extraction, double-reading of scans, and the structural checks.
          The parser shows its work — you only look at the few dots that are not green.
        </p>
      </div>

      {/* Resume banner (#19) */}
      {resume && busy.kind === 'none' && (
        <div className="flex items-center justify-between gap-3 px-4 py-3 rounded-xl bg-emerald-950/30 border border-emerald-800/50">
          <div className="text-xs text-emerald-300">
            Your work was saved at <b>{new Date(resume.at).toLocaleTimeString()}</b> — nothing was lost.
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                clearResumeState();
                onOpenLibrary();
              }}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold transition"
            >
              Continue where I left off
            </button>
            <button
              onClick={() => clearResumeState()}
              className="px-2 py-1.5 rounded-lg text-emerald-400/70 hover:text-emerald-300 text-[11px] transition"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* The dropzone */}
      {!pasteMode && (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            const file = e.dataTransfer.files?.[0];
            if (file) processFile(file);
          }}
          className={`rounded-3xl border-2 border-dashed p-10 text-center transition bg-slate-900/60 ${
            dragOver ? 'border-indigo-400 bg-indigo-950/30' : 'border-slate-700 hover:border-indigo-500'
          }`}
        >
          {busy.kind === 'working' ? (
            <div className="space-y-4">
              <Loader2 className="w-8 h-8 text-indigo-400 animate-spin mx-auto" />
              <div className="text-sm font-bold text-indigo-300">{busy.status}</div>
              <div className="max-w-sm mx-auto space-y-1">
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-indigo-500 transition-all duration-300" style={{ width: `${busy.percent}%` }} />
                </div>
                <div className="text-[11px] text-slate-500 font-mono">{busy.percent}%</div>
              </div>
            </div>
          ) : (
            <div className="space-y-5">
              <div className="w-16 h-16 rounded-2xl bg-indigo-600/10 text-indigo-400 flex items-center justify-center mx-auto">
                <Upload className="w-8 h-8" />
              </div>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-2">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-bold shadow-lg shadow-indigo-600/30 transition"
                >
                  <Upload className="w-4 h-4" />
                  Choose a file
                </button>
                <button
                  onClick={() => cameraInputRef.current?.click()}
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-semibold border border-slate-700 transition"
                >
                  <Camera className="w-4 h-4 text-emerald-400" />
                  Take a photo
                </button>
                <button
                  onClick={() => setPasteMode(true)}
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-semibold border border-slate-700 transition"
                >
                  <ClipboardPaste className="w-4 h-4 text-sky-400" />
                  Paste text
                </button>
              </div>
              <p className="text-xs text-slate-500">
                PDF (digital or scanned) • Word .docx • images • plain text — or just drag it anywhere onto this box.
              </p>
              <input ref={fileInputRef} type="file" accept=".txt,.docx,.pdf,.ocr,.json,.png,.jpg,.jpeg,.webp,.tiff" className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) processFile(f);
                }} />
              <input ref={cameraInputRef} type="file" accept="image/*" capture="environment" className="hidden"
                onChange={handleCameraCapture} />
            </div>
          )}
        </div>
      )}

      {/* Paste mode */}
      {pasteMode && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-200">
              <FileCode className="w-4 h-4 text-sky-400" /> Paste exam text
            </div>
            <button onClick={() => setPasteMode(false)} className="text-xs text-slate-400 hover:text-white">
              Back
            </button>
          </div>
          <textarea
            value={pastedText}
            onChange={(e) => setPastedText(e.target.value)}
            rows={10}
            placeholder={'Paste OCR text or type the exam here. Question numbers like "1." and section letters like "A" help the parser.'}
            className="w-full bg-slate-950 border border-slate-700 rounded-xl p-4 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-indigo-500 font-mono"
          />
          <button
            disabled={!pastedText.trim() || busy.kind === 'working'}
            onClick={handleParsePaste}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-bold transition"
          >
            <Sparkles className="w-4 h-4" /> Parse this text
          </button>
        </div>
      )}

      {/* Error card */}
      {busy.kind === 'error' && (
        <div className="p-4 rounded-xl bg-rose-950/30 border border-rose-800/50 space-y-2">
          <div className="text-xs font-bold text-rose-300">That did not work</div>
          <p className="text-xs text-rose-200/80 leading-relaxed">{busy.message}</p>
          <button
            onClick={() => setBusy({ kind: 'none' })}
            className="px-3 py-1.5 rounded-lg bg-rose-900/60 hover:bg-rose-900 text-rose-200 text-[11px] font-semibold transition"
          >
            Try again
          </button>
        </div>
      )}

      {/* Trust explainer strip — sets expectations before the first parse */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {[
          { icon: ScanSearch, title: 'Double-read', text: 'Scans are read twice by different strategies; only disagreements get flagged.' },
          { icon: ShieldCheck, title: 'Checked like math', text: 'Numbering, marks and option integrity are verified as hard rules — 0 AI tokens.' },
          { icon: Sparkles, title: 'AI only as referee', text: 'When AI helps at all, it votes 3 times on contested cells and you approve every change.' },
        ].map((c) => (
          <div key={c.title} className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
            <c.icon className="w-4 h-4 text-indigo-400" />
            <div className="text-xs font-bold text-slate-200">{c.title}</div>
            <p className="text-[11px] text-slate-400 leading-relaxed">{c.text}</p>
          </div>
        ))}
      </div>

      {/* Escape hatches for power users */}
      <div className="flex items-center justify-center gap-4 text-[11px]">
        {hasExams && (
          <button onClick={onOpenLibrary} className="text-slate-400 hover:text-white inline-flex items-center gap-1 transition">
            My exams <ArrowRight className="w-3 h-3" />
          </button>
        )}
        <button onClick={onOpenAdvanced} className="text-slate-500 hover:text-slate-300 inline-flex items-center gap-1 transition">
          Advanced parsing options <ArrowRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
