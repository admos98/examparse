import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ScanSearch, ChevronLeft, ChevronRight, ImageOff, Crosshair, Loader2 } from 'lucide-react';
import { ExamDocument, QuestionItem } from '../types/exam';
import { countSourcePages, renderSourcePage } from '../utils/pageRenderer';

/**
 * X-Ray Overlay (#12) — the demo centerpiece.
 *
 * Renders the ORIGINAL uploaded page (PDF via pdf.js, or the image itself) and
 * layers the parsed AST on top of the real pixels: every question's provenance
 * bbox drawn in its section color, opacity driven by OCR confidence heat.
 * Click a box ↔ select the question. Evidence you can literally see.
 */

const SECTION_COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ec4899', '#06b6d4', '#a855f7', '#ef4444', '#84cc16'];

function sectionColor(rowId: string): string {
  let h = 0;
  for (let i = 0; i < rowId.length; i++) h = (h * 31 + rowId.charCodeAt(i)) | 0;
  return SECTION_COLORS[Math.abs(h) % SECTION_COLORS.length];
}

interface XRayViewerProps {
  document: ExamDocument;
  onSelectQuestion?: (q: QuestionItem) => void;
}

export const XRayViewer: React.FC<XRayViewerProps> = ({ document, onSelectQuestion }) => {
  const sourceFile = document.sourceFile;
  const [pageCount, setPageCount] = useState(1);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const canvasHostRef = useRef<HTMLDivElement>(null);
  const [displaySize, setDisplaySize] = useState<{ w: number; h: number } | null>(null);
  const [nativeSize, setNativeSize] = useState<{ w: number; h: number } | null>(null);

  const questionsByPage = useMemo(() => {
    const map = new Map<number, { q: QuestionItem; color: string }[]>();
    for (const sec of document.sections || []) {
      const color = sectionColor(sec.rowId);
      for (const q of sec.questions) {
        if (!q.provenance?.bbox || !q.provenance.page) continue;
        const p = q.provenance.page;
        if (!map.has(p)) map.set(p, []);
        map.get(p)!.push({ q, color });
      }
    }
    return map;
  }, [document]);

  const boxes = questionsByPage.get(page) || [];

  useEffect(() => {
    if (!sourceFile) return;
    let cancelled = false;
    (async () => {
      try {
        const n = await countSourcePages(sourceFile);
        if (!cancelled) setPageCount(n);
      } catch {
        if (!cancelled) setPageCount(1);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [sourceFile]);

  useEffect(() => {
    if (!sourceFile) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    (async () => {
      try {
        const rendered = await renderSourcePage(sourceFile, page);
        if (cancelled) return;
        setNativeSize({ w: rendered.width, h: rendered.height });
        const host = canvasHostRef.current;
        if (host) {
          host.innerHTML = '';
          rendered.canvas.style.width = '100%';
          rendered.canvas.style.height = 'auto';
          rendered.canvas.style.display = 'block';
          host.appendChild(rendered.canvas);
        }
      } catch (e: any) {
        if (!cancelled) setError(e?.message || 'Could not render the source page');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [sourceFile, page]);

  // Track rendered display size so SVG overlay scales exactly with the image
  useEffect(() => {
    const host = canvasHostRef.current;
    if (!host) return;
    const update = () => {
      const canvas = host.querySelector('canvas');
      if (canvas) {
        setDisplaySize({ w: canvas.clientWidth, h: canvas.clientHeight });
      }
    };
    update();
    const observer = new ResizeObserver(update);
    observer.observe(host);
    return () => observer.disconnect();
  }, [loading, page]);

  const handleSelect = (q: QuestionItem) => {
    setSelectedId(q.id);
    onSelectQuestion?.(q);
  };

  if (!sourceFile) {
    return (
      <div className="p-10 rounded-2xl bg-slate-900 border border-slate-800 text-center space-y-3">
        <ImageOff className="w-10 h-10 text-slate-600 mx-auto" />
        <h3 className="text-sm font-bold text-white">No original file attached</h3>
        <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
          The X-ray overlay needs the original PDF/image, which is kept automatically for documents parsed from a file.
          This document came from pasted text or an older import — parse the source file again to unlock evidence-linked viewing.
        </p>
      </div>
    );
  }

  const scale = displaySize && nativeSize ? displaySize.w / nativeSize.w : 0;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
            <ScanSearch className="w-4.5 h-4.5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white">X-Ray Overlay — Evidence Viewer</h2>
            <p className="text-[11px] text-slate-400">
              {boxes.length} of {document.totalQuestions} questions traced on this page • every box links the parsed AST to its source pixels
            </p>
          </div>
        </div>

        {/* Page nav */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setPage(Math.max(1, page - 1))}
            disabled={page <= 1 || loading}
            className="p-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-400 hover:text-white disabled:opacity-40 transition"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-xs font-mono text-slate-300 px-2">Page {page} / {pageCount}</span>
          <button
            onClick={() => setPage(Math.min(pageCount, page + 1))}
            disabled={page >= pageCount || loading}
            className="p-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-400 hover:text-white disabled:opacity-40 transition"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Canvas + overlay */}
      <div className="relative rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden">
        {loading && (
          <div className="absolute inset-0 z-20 flex items-center justify-center bg-slate-950/70">
            <Loader2 className="w-6 h-6 text-indigo-400 animate-spin" />
          </div>
        )}
        {error && (
          <div className="p-8 text-center text-xs text-red-400">{error}</div>
        )}
        <div ref={canvasHostRef} className="relative" />

        {/* SVG overlay */}
        {scale > 0 && displaySize && (
          <svg
            className="absolute inset-0 pointer-events-none"
            width={displaySize.w}
            height={displaySize.h}
            viewBox={`0 0 ${displaySize.w} ${displaySize.h}`}
          >
            {boxes.map(({ q, color }) => {
              const prov = q.provenance!;
              const bb = prov.bbox!;
              const isSel = selectedId === q.id;
              // Normalize to page fractions, then to display px
              const pw = prov.pageWidth || 1;
              const ph = prov.pageHeight || 1;
              let leftFrac = bb.x / pw;
              let topFrac: number;
              if (prov.coordSpace === 'pdf') {
                topFrac = (ph - bb.y) / ph; // PDF space: y is the TOP edge, measured from bottom
              } else {
                topFrac = bb.y / ph;
              }
              const wFrac = bb.w / pw;
              const hFrac = bb.h / ph;
              // Confidence heat: low OCR confidence = stronger warning tint
              const conf = prov.ocrConfidence;
              const heat = conf !== undefined ? Math.max(0, Math.min(1, (100 - conf) / 30)) : 0.25;
              return (
                <g key={q.id} className="pointer-events-auto cursor-pointer" onClick={() => handleSelect(q)}>
                  <rect
                    x={leftFrac * displaySize.w}
                    y={topFrac * displaySize.h}
                    width={Math.max(4, wFrac * displaySize.w)}
                    height={Math.max(3, hFrac * displaySize.h)}
                    fill={heat > 0.55 ? '#ef4444' : color}
                    fillOpacity={isSel ? 0.45 : 0.18 + heat * 0.15}
                    stroke={isSel ? '#ffffff' : color}
                    strokeWidth={isSel ? 2.5 : 1}
                    rx={3}
                  />
                  <text
                    x={leftFrac * displaySize.w + 2}
                    y={Math.max(10, topFrac * displaySize.h - 4)}
                    fontSize={11}
                    fontWeight={700}
                    fill={isSel ? '#ffffff' : color}
                    style={{ paintOrder: 'stroke', stroke: '#0f172a', strokeWidth: 3 }}
                  >
                    {q.displayNumber}
                  </text>
                </g>
              );
            })}
          </svg>
        )}
      </div>

      {/* Legend + selected question */}
      <div className="flex flex-col lg:flex-row gap-3">
        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex-1">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Section colors</p>
          <div className="flex flex-wrap gap-2">
            {(document.sections || []).map((sec) => (
              <span key={sec.rowId} className="inline-flex items-center gap-1.5 text-[11px] text-slate-300">
                <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: sectionColor(sec.rowId) }} />
                {sec.rowId} · {sec.majorCategory}
              </span>
            ))}
          </div>
          <p className="text-[10px] text-slate-500 mt-2 flex items-center gap-1">
            <Crosshair className="w-3 h-3" /> Red tint = low OCR confidence (heat map). Click a box to inspect.
          </p>
        </div>

        {selectedId && (
          <div className="p-3 rounded-xl bg-slate-900 border border-indigo-500/40 lg:max-w-sm flex-1">
            <p className="text-[10px] font-bold text-indigo-300 uppercase tracking-wider mb-1">Selected question</p>
            {(() => {
              const found = (document.sections || []).flatMap((s) => s.questions).find((q) => q.id === selectedId);
              if (!found) return null;
              return (
                <div className="space-y-1.5">
                  <p className="text-xs text-slate-200 leading-snug line-clamp-3">{found.stem}</p>
                  <p className="text-[11px] text-slate-400 font-mono">
                    Page {found.provenance?.page} • {found.provenance?.source}
                    {found.provenance?.ocrConfidence !== undefined ? ` • OCR ${found.provenance.ocrConfidence}%` : ''}
                    {found.answerMeta ? ` • ${found.answerMeta.method}` : ''}
                  </p>
                </div>
              );
            })()}
          </div>
        )}
      </div>
    </div>
  );
};
