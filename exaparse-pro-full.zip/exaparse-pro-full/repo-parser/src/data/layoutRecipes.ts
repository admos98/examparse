import { ExamDocument } from '../types/exam';

/**
 * Layout recipes (#19) — declarative knowledge about known exam formats.
 *
 * A recipe encodes how a particular family of Iranian exam papers words its
 * section headers, so the deterministic parser can map Persian section names
 * (شنیداری، واژگان، دستور، ...) to AST categories with near-100% accuracy,
 * with zero AI. Schools/publishers can add their own recipes as JSON.
 */

export type SectionCategory = 'Listening' | 'Vocabulary' | 'Grammar' | 'Writing' | 'Reading' | 'General';

export interface LayoutRecipe {
  id: string;
  name: string;
  description?: string;
  /** Patterns tested against the document head; ANY match selects the recipe. */
  matchAny: string[]; // regex sources (stored as strings so recipes are JSON-importable)
  /** Persian/English section keywords -> AST category. */
  categoryHints: Record<string, SectionCategory>;
  custom?: boolean;
}

const KH: Record<string, SectionCategory> = {
  'شنیداری': 'Listening',
  'شنيداري': 'Listening',
  'listening': 'Listening',
  'واژگان': 'Vocabulary',
  'واژگان و اصطلاحات': 'Vocabulary',
  'لغت': 'Vocabulary',
  'vocabulary': 'Vocabulary',
  'دستور': 'Grammar',
  'دستور زبان': 'Grammar',
  'گرامر': 'Grammar',
  'grammar': 'Grammar',
  'درک مطلب': 'Reading',
  'درک': 'Reading',
  'reading': 'Reading',
  'نوشتاری': 'Writing',
  'نگارش': 'Writing',
  'نوشتار': 'Writing',
  'writing': 'Writing',
};

export const BUILT_IN_RECIPES: LayoutRecipe[] = [
  {
    id: 'ir-cohesive-exam',
    name: 'آزمون هماهنگ استانی (District Cohesive Exam)',
    description: 'Standard provincial cohesive exam: نام درس / دبیرستان / اداره آموزش و پرورش header, sections الف تا ی.',
    matchAny: [
      'نام\\s*درس[\\s\\S]{0,120}دبیرستان',
      'اداره\\s*آموزش\\s*و\\s*پرورش',
      'آزمون\\s*هماهنگ',
      'نوبت\\s*(اول|دوم)',
    ],
    categoryHints: KH,
  },
  {
    id: 'ir-middle-school',
    name: 'کتاب مدرسه‌ای پایه هفتم–نهم (School Course Book Exam)',
    description: 'Lesson-based exams with شنیداری/واژگان/دستور/درک مطلب/نوشتاری sections.',
    matchAny: [
      '(شنیداری|واژگان|دستور|درک\\s*مطلب|نوشتاری)',
      'درس\\s*(اول|دوم|سوم)',
    ],
    categoryHints: KH,
  },
  {
    id: 'en-part-based',
    name: 'English Part-Based Exam (Part A/B/C)',
    description: 'International-style English exams with Part banners and instructions.',
    matchAny: [
      'Part\\s*[A-D1-5]',
      '(Choose|Fill|Match|Read)\\s+(the\\s+)?(the\\s+)?(best|correct|blank)',
    ],
    categoryHints: KH,
  },
  {
    id: 'generic-persian-letters',
    name: 'Generic Persian-Letter Sections (الف/ب/ج/د)',
    description: 'Fallback recipe for any exam using Persian letter section markers.',
    matchAny: ['(?:^|\\n)\\s*الف\\s*[\\)\\.]'],
    categoryHints: KH,
  },
];

const RECIPES_KEY = 'exaparse:custom-recipes';

export async function loadCustomRecipes(): Promise<LayoutRecipe[]> {
  try {
    const raw = localStorage.getItem(RECIPES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((r: any) => r && r.id && r.name && Array.isArray(r.matchAny));
  } catch {
    return [];
  }
}

export async function saveCustomRecipe(recipe: LayoutRecipe): Promise<void> {
  const list = await loadCustomRecipes();
  const idx = list.findIndex((r) => r.id === recipe.id);
  if (idx >= 0) list[idx] = recipe;
  else list.push(recipe);
  localStorage.setItem(RECIPES_KEY, JSON.stringify(list));
}

export async function getAllRecipes(): Promise<LayoutRecipe[]> {
  return [...BUILT_IN_RECIPES, ...(await loadCustomRecipes())];
}

/**
 * Detect which recipe (if any) matches the head of the document.
 * Returns the recipe with the most pattern hits, or null.
 */
export function detectRecipe(text: string, recipes: LayoutRecipe[]): { recipe: LayoutRecipe; hits: number } | null {
  const head = (text || '').slice(0, 600);
  let best: { recipe: LayoutRecipe; hits: number } | null = null;
  for (const recipe of recipes) {
    let hits = 0;
    for (const pattern of recipe.matchAny) {
      try {
        if (new RegExp(pattern, 'i').test(head)) hits++;
      } catch {
        // invalid user pattern — skip
      }
    }
    if (hits > 0 && (!best || hits > best.hits)) best = { recipe, hits };
  }
  return best;
}

/**
 * Apply a recipe's category hints to section titles/instructions that the
 * generic detector left as 'General' (never overrides confident categories).
 */
export function applyRecipe(doc: ExamDocument, recipe: LayoutRecipe): { doc: ExamDocument; remapped: number } {
  let remapped = 0;
  const entries = Object.entries(recipe.categoryHints).sort((a, b) => b[0].length - a[0].length);

  const sections = doc.sections.map((sec) => {
    if (sec.majorCategory !== 'General') return sec;
    const hay = `${sec.title || ''} ${sec.persianInstruction || ''} ${sec.englishInstruction || ''}`;
    for (const [keyword, category] of entries) {
      try {
        if (new RegExp(keyword, 'i').test(hay)) {
          remapped++;
          return { ...sec, majorCategory: category };
        }
      } catch {
        continue;
      }
    }
    return sec;
  });

  return { doc: { ...doc, sections }, remapped };
}
