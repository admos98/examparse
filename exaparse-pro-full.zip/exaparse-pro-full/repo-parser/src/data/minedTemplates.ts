/**
 * MINED SECTION TEMPLATES (Idea 2) — GENERATED FILE, DO NOT EDIT BY HAND.
 * Regenerate with: npx tsx scripts/mineTemplates.mts
 *
 * Mined deterministically from the 57-exam golden corpus by structural
 * fingerprint clustering. Advisory evidence ONLY — these never stamp types,
 * never enter the grading path, and never demote trust (see
 * src/utils/sectionTemplates.ts for the contract).
 */
export const MINED_TEMPLATES: import('../utils/sectionTemplates').SectionTemplate[] = [
  {
    "id": "tpl-00-vvxqq3",
    "suggestsType": "short_answer",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.13,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      4,
      8
    ],
    "weight": 0.429,
    "provenance": {
      "minedFrom": [
        "mock-01-haftom-payani.docx",
        "انگلیسی 8 مستمر دو.docx",
        "انگلیسی 8 نوبت اول.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-01-numoy4",
    "suggestsType": "short_answer",
    "suggestsCategory": "General",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.17,
      "stemsInterrogative": true,
      "stemsBlankFill": false
    },
    "countRange": [
      6,
      6
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "زبان هفتم نوبت اول.docx",
        "زبان هفتم نوبت اول.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-02-2idi8e",
    "suggestsType": "short_answer",
    "suggestsCategory": "General",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.21,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      7,
      7
    ],
    "weight": 0.556,
    "provenance": {
      "minedFrom": [
        "کلاس هشتم 1پایانی.pdf",
        "کلاس هفتم پایانی.docx",
        "کلاس هفتم پایانی.pdf",
        "کلاس هفتم پایانی1.docx",
        "کلاس هفتم پایانی1.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-03-uxlzw6",
    "suggestsType": "short_answer",
    "suggestsCategory": "General",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.25,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      2,
      8
    ],
    "weight": 0.934,
    "provenance": {
      "minedFrom": [
        "10th first.pdf",
        "11th first.pdf",
        "12th first.pdf",
        "9_2.pdf",
        "9th 1-3.docx",
        "9th 1-3.pdf",
        "mock-01-haftom-payani.docx",
        "mock-04-dahom-head.pdf",
        "انگلیسی 8 مستمر دو.docx",
        "انگلیسی 8 مستمر یک.docx",
        "انگلیسی 8 نوبت اول.docx",
        "انگلیسی 9 مستمر دو.docx",
        "انگلیسی 9 مستمر چهار.docx",
        "انگلیسی 9 مستمر یک.docx",
        "انگلیسی 9 نوبت اول.docx",
        "زبان هفتم مسترم دو.docx",
        "زبان هفتم نوبت اول.docx",
        "زبان هفتم نوبت اول.pdf",
        "کلاس هشتم 1پایانی.pdf",
        "کلاس هشتم پایانی.docx",
        "کلاس هشتم پایانی.pdf",
        "کلاس هشتم پایانی1.docx",
        "کلاس هفتم پایانی.docx",
        "کلاس هفتم پایانی.pdf",
        "کلاس هفتم پایانی1.docx",
        "کلاس هفتم پایانی1.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-04-cz084f",
    "suggestsType": "fill_blank",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.25,
      "stemsInterrogative": false,
      "stemsBlankFill": true
    },
    "countRange": [
      4,
      8
    ],
    "weight": 0.429,
    "provenance": {
      "minedFrom": [
        "12th first.pdf",
        "زبان هفتم نوبت اول.docx",
        "زبان هفتم نوبت اول.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-05-mi9a27",
    "suggestsType": "short_answer",
    "suggestsCategory": "General",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.25,
      "stemsInterrogative": true,
      "stemsBlankFill": false
    },
    "countRange": [
      2,
      4
    ],
    "weight": 0.81,
    "provenance": {
      "minedFrom": [
        "انگلیسی 9 مستمر دو.docx",
        "انگلیسی 9 مستمر چهار.docx",
        "انگلیسی 9 نوبت اول.docx",
        "زبان هفتم مسترم دو.docx",
        "کلاس هشتم 1پایانی.pdf",
        "کلاس هشتم پایانی.pdf",
        "کلاس هفتم پایانی.docx",
        "کلاس هفتم پایانی.pdf",
        "کلاس هفتم پایانی1.docx",
        "کلاس هفتم پایانی1.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-06-apxtl9",
    "suggestsType": "form_in_parentheses",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.33,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      3,
      6
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "11th first.pdf",
        "کلاس هشتم 1پایانی.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-07-v31k2g",
    "suggestsType": "matching",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.38,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      4,
      4
    ],
    "weight": 0.667,
    "provenance": {
      "minedFrom": [
        "mock-03-nohom-mostamar.pdf",
        "mock-06-nohom-ocr.pdf",
        "mock-07-alefba.docx",
        "mock-13-tarjome-tartib.docx",
        "mock-20-mixed-full.docx",
        "کلاس هشتم 1پایانی.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-08-hicmsk",
    "suggestsType": "short_answer",
    "suggestsCategory": "General",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.5,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      1,
      6
    ],
    "weight": 0.951,
    "provenance": {
      "minedFrom": [
        "10th first.pdf",
        "11th first.pdf",
        "12th first.pdf",
        "9_2.pdf",
        "9th 1-3.docx",
        "9th 1-3.pdf",
        "mock-01-haftom-payani.docx",
        "mock-02-hashthom-mostamar.docx",
        "mock-03-nohom-mostamar.pdf",
        "mock-04-dahom-head.pdf",
        "mock-05-yazdahom-numpr.docx",
        "mock-06-nohom-ocr.pdf",
        "mock-07-alefba.docx",
        "mock-09-cloze-matn.docx",
        "mock-10-motabegh-extra.docx",
        "mock-11-nemreh-dakheli.pdf",
        "mock-12-peyvaste.docx",
        "mock-14-farsi-motabegh.docx",
        "mock-16-emla-ghalte.docx",
        "mock-18-definition-number.docx",
        "mock-19-tasvir.docx",
        "mock-20-mixed-full.docx",
        "انگلیسی 8 مستمر دو.docx",
        "انگلیسی 8 مستمر یک.docx",
        "انگلیسی 8 نوبت اول.docx",
        "انگلیسی 9 مستمر دو.docx",
        "انگلیسی 9 مستمر چهار.docx",
        "انگلیسی 9 مستمر یک.docx",
        "انگلیسی 9 نوبت اول.docx",
        "زبان هفتم نوبت اول.docx",
        "زبان هفتم نوبت اول.pdf",
        "زمان آزمون.docx",
        "زمان آزمون.pdf",
        "کلاس هشتم 1پایانی.pdf",
        "کلاس هشتم مستمر.docx",
        "کلاس هشتم مستمر.pdf",
        "کلاس هشتم پایانی.docx",
        "کلاس هشتم پایانی.pdf",
        "کلاس هشتم پایانی1.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-09-js6iv5",
    "suggestsType": "short_answer",
    "suggestsCategory": "General",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.5,
      "stemsInterrogative": true,
      "stemsBlankFill": false
    },
    "countRange": [
      2,
      8
    ],
    "weight": 0.75,
    "provenance": {
      "minedFrom": [
        "9_2.pdf",
        "mock-03-nohom-mostamar.pdf",
        "mock-05-yazdahom-numpr.docx",
        "mock-06-nohom-ocr.pdf",
        "mock-08-gozine-farsi.pdf",
        "mock-09-cloze-matn.docx",
        "زمان آزمون.docx",
        "زمان آزمون.pdf",
        "کلاس هشتم 1پایانی.pdf",
        "کلاس هشتم پایانی.docx",
        "کلاس هشتم پایانی.pdf",
        "کلاس هشتم پایانی1.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0a-iyhj90",
    "suggestsType": "fill_blank",
    "suggestsCategory": "Listening",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.67,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      3,
      3
    ],
    "weight": 0.429,
    "provenance": {
      "minedFrom": [
        "mock-13-tarjome-tartib.docx",
        "mock-16-emla-ghalte.docx",
        "mock-17-gosh-deed.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0b-mp2a8f",
    "suggestsType": "short_answer",
    "suggestsCategory": "General",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.75,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      1,
      2
    ],
    "weight": 0.6,
    "provenance": {
      "minedFrom": [
        "mock-01-haftom-payani.docx",
        "mock-06-nohom-ocr.pdf",
        "mock-13-tarjome-tartib.docx",
        "mock-15-do-sotun.pdf",
        "انگلیسی 8 مستمر یک.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0c-38j542",
    "suggestsType": "unscramble",
    "suggestsCategory": "Writing",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 1,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      1,
      4
    ],
    "weight": 0.892,
    "provenance": {
      "minedFrom": [
        "10th first.pdf",
        "12th first.pdf",
        "9_2.pdf",
        "9th 1-3.docx",
        "mock-04-dahom-head.pdf",
        "mock-11-nemreh-dakheli.pdf",
        "mock-12-peyvaste.docx",
        "انگلیسی 8 نوبت اول.docx",
        "انگلیسی 9 مستمر یک.docx",
        "انگلیسی 9 نوبت اول.docx",
        "زبان هفتم نوبت اول.docx",
        "زبان هفتم نوبت اول.pdf",
        "زمان آزمون.docx",
        "زمان آزمون.pdf",
        "نهم مستمر.docx",
        "نهم مستمر.pdf",
        "کلاس هشتم 1پایانی.pdf",
        "کلاس هشتم مستمر.docx",
        "کلاس هشتم مستمر.pdf",
        "کلاس هشتم پایانی.docx",
        "کلاس هشتم پایانی.pdf",
        "کلاس هشتم پایانی1.docx",
        "کلاس هفتم پایانی.pdf",
        "کلاس هفتم پایانی1.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0d-yp2q9z",
    "suggestsType": "fill_blank",
    "suggestsCategory": "General",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 1,
      "stemsInterrogative": false,
      "stemsBlankFill": true
    },
    "countRange": [
      2,
      2
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "نهم مستمر.docx",
        "نهم مستمر.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0e-s6rwn",
    "suggestsType": "short_answer",
    "suggestsCategory": "General",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 1,
      "stemsInterrogative": true,
      "stemsBlankFill": false
    },
    "countRange": [
      2,
      3
    ],
    "weight": 0.636,
    "provenance": {
      "minedFrom": [
        "11th first.pdf",
        "mock-04-dahom-head.pdf",
        "mock-11-nemreh-dakheli.pdf",
        "زمان آزمون.docx",
        "زمان آزمون.pdf",
        "کلاس هشتم مستمر.docx",
        "کلاس هشتم مستمر.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0f-pyb5hh",
    "suggestsType": "long_answer_essay",
    "suggestsCategory": "Writing",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 1.5,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      1,
      1
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "mock-20-mixed-full.docx",
        "انگلیسی 9 نوبت اول.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0g-54gqf3",
    "suggestsType": "short_answer",
    "suggestsCategory": "General",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 2,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      1,
      2
    ],
    "weight": 0.5,
    "provenance": {
      "minedFrom": [
        "12th first.pdf",
        "انگلیسی 8 مستمر یک.docx",
        "انگلیسی 8 نوبت اول.docx",
        "کلاس هشتم 1پایانی.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0h-bchqp5",
    "suggestsType": "short_answer",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": true,
      "markPattern": "uniform",
      "uniformMark": 0.21,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      6,
      6
    ],
    "weight": 0.5,
    "provenance": {
      "minedFrom": [
        "کلاس هفتم پایانی.docx",
        "کلاس هفتم پایانی.pdf",
        "کلاس هفتم پایانی1.docx",
        "کلاس هفتم پایانی1.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0i-q378z5",
    "suggestsType": "true_false",
    "suggestsCategory": "Reading",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": true,
      "markPattern": "uniform",
      "uniformMark": 0.38,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      4,
      4
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "9th 1-3.docx",
        "9th 1-3.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0j-52symo",
    "suggestsType": "short_answer",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": true,
      "markPattern": "uniform",
      "uniformMark": 0.8,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      5,
      5
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "نهم مستمر.docx",
        "نهم مستمر.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0k-h73jkv",
    "suggestsType": "fill_blank",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": true,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.25,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      4,
      4
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "کلاس هفتم پایانی.pdf",
        "کلاس هفتم پایانی1.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0l-9hx048",
    "suggestsType": "fill_blank",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": true,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.25,
      "stemsInterrogative": false,
      "stemsBlankFill": true
    },
    "countRange": [
      4,
      4
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "کلاس هفتم پایانی.docx",
        "کلاس هفتم پایانی1.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0m-gwg2mp",
    "suggestsType": "fill_blank",
    "suggestsCategory": "Reading",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": true,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.25,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      6,
      6
    ],
    "weight": 0.692,
    "provenance": {
      "minedFrom": [
        "11th first.pdf",
        "کلاس هشتم 1پایانی.pdf",
        "کلاس هشتم پایانی.docx",
        "کلاس هشتم پایانی.pdf",
        "کلاس هشتم پایانی1.docx",
        "کلاس هفتم پایانی.docx",
        "کلاس هفتم پایانی.pdf",
        "کلاس هفتم پایانی1.docx",
        "کلاس هفتم پایانی1.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0n-3b4otl",
    "suggestsType": "error_correction",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": true,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.5,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      4,
      5
    ],
    "weight": 0.6,
    "provenance": {
      "minedFrom": [
        "10th first.pdf",
        "11th first.pdf",
        "انگلیسی 9 مستمر دو.docx",
        "انگلیسی 9 نوبت اول.docx",
        "نهم مستمر.docx",
        "نهم مستمر.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0o-q8ll3x",
    "suggestsType": "short_answer",
    "suggestsCategory": "Reading",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": true,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 1,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      1,
      5
    ],
    "weight": 0.636,
    "provenance": {
      "minedFrom": [
        "9th 1-3.docx",
        "9th 1-3.pdf",
        "نهم مستمر.docx",
        "نهم مستمر.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0p-13eli2",
    "suggestsType": "short_answer",
    "suggestsCategory": "Reading",
    "constraints": {
      "hasOptions": false,
      "hasBank": false,
      "hasPassage": true,
      "hasInlineBlanks": false,
      "uniformOptionCount": true,
      "markPattern": "mixed",
      "stemsInterrogative": true,
      "stemsBlankFill": false
    },
    "countRange": [
      5,
      5
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "انگلیسی 9 مستمر دو.docx",
        "انگلیسی 9 نوبت اول.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0q-rzn5q5",
    "suggestsType": "word_bank_fill",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": true,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.25,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      2,
      8
    ],
    "weight": 0.778,
    "provenance": {
      "minedFrom": [
        "10th first.pdf",
        "11th first.pdf",
        "12th first.pdf",
        "mock-03-nohom-mostamar.pdf",
        "mock-05-yazdahom-numpr.docx",
        "انگلیسی 8 مستمر دو.docx",
        "انگلیسی 9 مستمر دو.docx",
        "انگلیسی 9 نوبت اول.docx",
        "کلاس هفتم پایانی.docx",
        "کلاس هفتم پایانی.pdf",
        "کلاس هفتم پایانی1.docx",
        "کلاس هفتم پایانی1.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0r-1dx2rk",
    "suggestsType": "word_bank_fill",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": true,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.33,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      6,
      6
    ],
    "weight": 0.5,
    "provenance": {
      "minedFrom": [
        "کلاس هشتم 1پایانی.pdf",
        "کلاس هشتم پایانی.docx",
        "کلاس هشتم پایانی.pdf",
        "کلاس هشتم پایانی1.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0s-e6ewsp",
    "suggestsType": "word_bank_fill",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": true,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.5,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      2,
      8
    ],
    "weight": 0.778,
    "provenance": {
      "minedFrom": [
        "mock-04-dahom-head.pdf",
        "mock-05-yazdahom-numpr.docx",
        "mock-07-alefba.docx",
        "mock-08-gozine-farsi.pdf",
        "mock-11-nemreh-dakheli.pdf",
        "mock-20-mixed-full.docx",
        "انگلیسی 8 مستمر یک.docx",
        "انگلیسی 8 نوبت اول.docx",
        "زمان آزمون.docx",
        "زمان آزمون.pdf",
        "نهم مستمر.docx",
        "نهم مستمر.pdf",
        "کلاس هشتم مستمر.docx",
        "کلاس هشتم مستمر.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0t-x7dm1b",
    "suggestsType": "word_bank_fill",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": true,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 1,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      4,
      4
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "mock-11-nemreh-dakheli.pdf",
        "mock-12-peyvaste.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0u-oudqi6",
    "suggestsType": "word_bank_fill",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": true,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 2,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      1,
      1
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "9th 1-3.docx",
        "9th 1-3.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0v-tb6yam",
    "suggestsType": "word_bank_fill",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": true,
      "hasPassage": false,
      "hasInlineBlanks": true,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 1,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      1,
      1
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "کلاس هفتم پایانی.pdf",
        "کلاس هفتم پایانی1.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0w-esbgyk",
    "suggestsType": "error_correction",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": true,
      "hasPassage": true,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.25,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      4,
      4
    ],
    "weight": 0.5,
    "provenance": {
      "minedFrom": [
        "کلاس هفتم پایانی.docx",
        "کلاس هفتم پایانی.pdf",
        "کلاس هفتم پایانی1.docx",
        "کلاس هفتم پایانی1.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0x-2an64q",
    "suggestsType": "error_correction",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": false,
      "hasBank": true,
      "hasPassage": true,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.5,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      4,
      4
    ],
    "weight": 0.636,
    "provenance": {
      "minedFrom": [
        "9_2.pdf",
        "کلاس هشتم 1پایانی.pdf",
        "کلاس هشتم مستمر.docx",
        "کلاس هشتم مستمر.pdf",
        "کلاس هشتم پایانی.docx",
        "کلاس هشتم پایانی.pdf",
        "کلاس هشتم پایانی1.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0y-wd9v3k",
    "suggestsType": "short_answer",
    "suggestsCategory": "Reading",
    "constraints": {
      "hasOptions": false,
      "hasBank": true,
      "hasPassage": true,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 1,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      1,
      1
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "9th 1-3.docx",
        "9th 1-3.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-0z-8ymrln",
    "suggestsType": "multiple_choice",
    "suggestsCategory": "Listening",
    "constraints": {
      "hasOptions": true,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": false,
      "markPattern": "uniform",
      "uniformMark": 0.5,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      2,
      4
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "12th first.pdf",
        "mock-02-hashthom-mostamar.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-10-ibhufi",
    "suggestsType": "odd_one_out",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": true,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": true,
      "markPattern": "uniform",
      "uniformMark": 0.25,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      2,
      5
    ],
    "weight": 0.889,
    "provenance": {
      "minedFrom": [
        "10th first.pdf",
        "11th first.pdf",
        "12th first.pdf",
        "9th 1-3.pdf",
        "انگلیسی 8 مستمر دو.docx",
        "انگلیسی 8 نوبت اول.docx",
        "انگلیسی 9 مستمر دو.docx",
        "انگلیسی 9 نوبت اول.docx",
        "کلاس هشتم 1پایانی.pdf",
        "کلاس هشتم پایانی.docx",
        "کلاس هشتم پایانی.pdf",
        "کلاس هشتم پایانی1.docx",
        "کلاس هفتم پایانی.docx",
        "کلاس هفتم پایانی.pdf",
        "کلاس هفتم پایانی1.docx",
        "کلاس هفتم پایانی1.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-11-igxels",
    "suggestsType": "multiple_choice",
    "suggestsCategory": "Reading",
    "constraints": {
      "hasOptions": true,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": true,
      "markPattern": "uniform",
      "uniformMark": 0.38,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      2,
      2
    ],
    "weight": 0.429,
    "provenance": {
      "minedFrom": [
        "mock-01-haftom-payani.docx",
        "کلاس هفتم پایانی.pdf",
        "کلاس هفتم پایانی1.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-12-ciq68c",
    "suggestsType": "multiple_choice",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": true,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": true,
      "markPattern": "uniform",
      "uniformMark": 0.5,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      1,
      6
    ],
    "weight": 0.913,
    "provenance": {
      "minedFrom": [
        "11th first.pdf",
        "12th first.pdf",
        "9_2.pdf",
        "mock-02-hashthom-mostamar.docx",
        "mock-03-nohom-mostamar.pdf",
        "mock-04-dahom-head.pdf",
        "mock-06-nohom-ocr.pdf",
        "mock-07-alefba.docx",
        "mock-08-gozine-farsi.pdf",
        "mock-09-cloze-matn.docx",
        "mock-10-motabegh-extra.docx",
        "mock-11-nemreh-dakheli.pdf",
        "mock-17-gosh-deed.docx",
        "mock-18-definition-number.docx",
        "انگلیسی 9 مستمر دو.docx",
        "انگلیسی 9 مستمر چهار.docx",
        "انگلیسی 9 نوبت اول.docx",
        "زبان هفتم نوبت اول.docx",
        "زبان هفتم نوبت اول.pdf",
        "زمان آزمون.docx",
        "زمان آزمون.pdf",
        "کلاس هفتم پایانی.pdf",
        "کلاس هفتم پایانی1.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-13-6cddsc",
    "suggestsType": "multiple_choice",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": true,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": true,
      "markPattern": "uniform",
      "uniformMark": 0.67,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      3,
      3
    ],
    "weight": 0.429,
    "provenance": {
      "minedFrom": [
        "mock-03-nohom-mostamar.pdf",
        "mock-05-yazdahom-numpr.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-14-zb6fp3",
    "suggestsType": "multiple_choice",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": true,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": true,
      "markPattern": "uniform",
      "uniformMark": 0.75,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      2,
      3
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "mock-01-haftom-payani.docx",
        "mock-19-tasvir.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-15-gsdqti",
    "suggestsType": "odd_one_out",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": true,
      "hasBank": false,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": true,
      "markPattern": "uniform",
      "uniformMark": 1,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      1,
      5
    ],
    "weight": 0.667,
    "provenance": {
      "minedFrom": [
        "mock-04-dahom-head.pdf",
        "mock-06-nohom-ocr.pdf",
        "mock-12-peyvaste.docx",
        "mock-15-do-sotun.pdf",
        "انگلیسی 9 مستمر یک.docx",
        "کلاس هشتم مستمر.docx",
        "کلاس هشتم مستمر.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-16-ivimvd",
    "suggestsType": "true_false",
    "suggestsCategory": "Reading",
    "constraints": {
      "hasOptions": true,
      "hasBank": false,
      "hasPassage": true,
      "hasInlineBlanks": false,
      "uniformOptionCount": true,
      "markPattern": "uniform",
      "uniformMark": 0.5,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      3,
      6
    ],
    "weight": 0.556,
    "provenance": {
      "minedFrom": [
        "10th first.pdf",
        "12th first.pdf",
        "9_2.pdf",
        "mock-14-farsi-motabegh.docx",
        "mock-20-mixed-full.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-17-6aruyr",
    "suggestsType": "multiple_choice",
    "suggestsCategory": "Reading",
    "constraints": {
      "hasOptions": true,
      "hasBank": false,
      "hasPassage": true,
      "hasInlineBlanks": false,
      "uniformOptionCount": true,
      "markPattern": "uniform",
      "uniformMark": 1,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      2,
      3
    ],
    "weight": 0.333,
    "provenance": {
      "minedFrom": [
        "10th first.pdf",
        "mock-12-peyvaste.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-18-l0mnba",
    "suggestsType": "multiple_choice",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": true,
      "hasBank": true,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": true,
      "markPattern": "uniform",
      "uniformMark": 0.25,
      "stemsInterrogative": true,
      "stemsBlankFill": false
    },
    "countRange": [
      5,
      5
    ],
    "weight": 0.5,
    "provenance": {
      "minedFrom": [
        "کلاس هشتم 1پایانی.pdf",
        "کلاس هشتم پایانی.docx",
        "کلاس هشتم پایانی.pdf",
        "کلاس هشتم پایانی1.docx"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  },
  {
    "id": "tpl-19-g0q01n",
    "suggestsType": "inline_choice",
    "suggestsCategory": "Vocabulary",
    "constraints": {
      "hasOptions": true,
      "hasBank": true,
      "hasPassage": false,
      "hasInlineBlanks": false,
      "uniformOptionCount": true,
      "markPattern": "uniform",
      "uniformMark": 0.5,
      "stemsInterrogative": false,
      "stemsBlankFill": false
    },
    "countRange": [
      1,
      4
    ],
    "weight": 0.429,
    "provenance": {
      "minedFrom": [
        "mock-01-haftom-payani.docx",
        "نهم مستمر.docx",
        "نهم مستمر.pdf"
      ],
      "minedAt": "2026-09-29T17:50:25.553Z",
      "version": 1
    }
  }
];
