import { GoogleGenAI, Type } from '@google/genai';
import { ProviderConfig, PROVIDER_DEFAULT_BASE_URLS } from '../types/settings';
import { TokenUsage } from '../types/exam';
import { callChatWithRecovery } from './aiResponse';
import { computeBackoffMs, isRetryableNetworkError, isRetryableStatus, resolveTimeoutMs, sleep } from './aiWire';

export interface AIResponse {
  rawText: string;
  parsedJson: any;
  model: string;
  latencyMs: number;
  /** True when the provider stopped early because the token budget ran out. */
  truncated: boolean;
  /** Provider-native finish reason, e.g. 'STOP' | 'MAX_TOKENS' | 'length'. */
  finishReason?: string;
  /** Token usage as reported by the provider (AI receipts). */
  usage?: TokenUsage;
}

export async function executeAIRequest({
  systemPrompt,
  userPrompt,
  fileData,
  mimeType,
  images,
  jsonMode,
  providerConfig,
  geminiSchema,
  maxAttempts,
}: {
  systemPrompt: string;
  userPrompt: string;
  fileData?: string;
  mimeType?: string;
  /** Multi-image payloads (vision batching): each entry rides with a stable id label. */
  images?: { id: string; mimeType: string; data: string }[];
  /** Set false for free-form output (e.g. scanned-page transcription) — JSON
   *  mime/response_format is skipped. Default true (JSON contracts everywhere else). */
  jsonMode?: boolean;
  providerConfig?: Partial<ProviderConfig>;
  geminiSchema?: any;
  /** Wire attempts for the empty-output recovery ladder (default 3 = A/B/C).
   *  Diagnostic pings should pass 1 — a transport-level failure repeats
   *  identically and the extra attempts only burn billable tokens. */
  maxAttempts?: number;
}): Promise<AIResponse> {
  const provider = providerConfig?.provider || 'gemini';
  const model = providerConfig?.model || (provider === 'gemini' ? 'gemini-2.5-flash' : 'gpt-4o-mini');
  const temperature = providerConfig?.temperature ?? 0.2;
  const maxTokens = providerConfig?.maxTokens ?? 8192;
  // Wire hardening: configurable timeout + bounded in-place retry on
  // 429/5xx/retryable network faults. Diagnostic pings (maxAttempts: 1) keep
  // their single-shot contract — zero wire retries.
  const timeoutMs = resolveTimeoutMs(providerConfig?.timeoutMs);
  const wireRetries =
    maxAttempts === 1
      ? 0
      : Math.max(0, providerConfig?.wireRetries ?? Number(process.env.AI_WIRE_RETRIES ?? 2));
  const startTime = Date.now();

  if (provider === 'gemini') {
    const apiKey = providerConfig?.apiKey || process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('Google Gemini API Key is missing. Please set it in Settings or GEMINI_API_KEY environment variable.');
    }

    // Honor a custom Base URL so Gemini-protocol gateways (self-hosted
    // proxies, regional relays) work too. Unset = Google's official endpoint.
    // NOTE: an OpenAI-style URL here will 404 — route those gateways through
    // the "custom" provider (OpenAI-compatible branch) instead.
    const requestedBaseURL = (providerConfig?.baseURL || '').trim().replace(/\/+$/, '');
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        ...(requestedBaseURL ? { baseUrl: requestedBaseURL } : {}),
        headers: {
          'User-Agent': 'exaparse-pro',
        },
      },
    });

    const parts: any[] = [];
    if (fileData && mimeType) {
      parts.push({
        inlineData: {
          mimeType,
          data: fileData,
        },
      });
    }
    // Multi-image batching (vision): label each image so the model's index-keyed
    // JSON can never rely on prose order.
    if (images && images.length > 0) {
      for (const im of images) {
        parts.push({ text: `Image ${im.id}:` });
        parts.push({ inlineData: { mimeType: im.mimeType, data: im.data } });
      }
    }
    parts.push({ text: userPrompt });

    const wantJson = jsonMode !== false;
    const config: any = {
      systemInstruction: systemPrompt,
      ...(wantJson ? { responseMimeType: 'application/json' } : {}),
      temperature,
      maxOutputTokens: maxTokens,
    };
    if (wantJson && geminiSchema) {
      config.responseSchema = geminiSchema;
    }

    const readFinishReason = (resp: any): string | undefined => {
      const cands = Array.isArray(resp?.candidates) ? resp.candidates : [];
      return cands[0]?.finishReason ?? undefined;
    };

    /**
     * One wire call to the Gemini SDK with a fresh AbortController timeout and
     * bounded in-place retry on 429/5xx + retryable network faults. Aborts are
     * never retried (a timeout would just double the stall). Used for BOTH the
     * as-built call and the thinking-exhaustion retry below.
     */
    const generateWithWireRetry = async (callConfig: any): Promise<any> => {
      for (let attempt = 0; ; attempt++) {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), timeoutMs);
        try {
          // The SDK forwards abortSignal to its underlying fetch — a hung
          // provider now unblocks the flow instead of stalling it forever.
          return await ai.models.generateContent({
            model,
            contents: { parts },
            config: { ...callConfig, abortSignal: ctrl.signal },
          });
        } catch (err: any) {
          if (ctrl.signal.aborted) {
            throw new Error(
              `AI request timed out after ${Math.round(timeoutMs / 1000)}s (model: ${model}). ` +
                `Raise the timeout in Settings / AI_TIMEOUT_MS and retry.`,
            );
          }
          const status = Number(err?.status ?? err?.code);
          const retryAfter =
            typeof err?.headers?.get === 'function' ? err.headers.get('retry-after') : undefined;
          if (attempt < wireRetries && (isRetryableStatus(status) || isRetryableNetworkError(err))) {
            console.warn(
              `[aiProvider] gemini: HTTP ${status || 'network fault'} — retry ${attempt + 1}/${wireRetries} after backoff`,
            );
            await sleep(computeBackoffMs(retryAfter, attempt));
            continue;
          }
          throw err;
        } finally {
          clearTimeout(timer);
        }
      }
    };
    // `response.text` is a getter that can throw when the candidate has no
    // content parts (e.g. MAX_TOKENS spent entirely on reasoning) — guard it.
    const extractText = (resp: any): string => {
      try {
        return typeof resp.text === 'string' ? resp.text : '';
      } catch {
        return '';
      }
    };

    let response: any;
    try {
      response = await generateWithWireRetry(config);
    } catch (err: any) {
      throw describeGeminiHttpError(err, model, requestedBaseURL);
    }

    let finishReason: string | undefined = readFinishReason(response);
    let text = extractText(response);

    // Thinking-exhaustion recovery (Gemini path): thinking models can burn the
    // whole maxOutputTokens budget on hidden thought parts — finishReason
    // MAX_TOKENS with zero visible text. Same failure class the OpenAI-compat
    // ladder solves with C:no-think: retry ONCE with thinking disabled.
    // POLISH (fix-6): the retry is skipped when maxAttempts === 1 so a
    // diagnostic ping (maxAttempts:1) never fires two wire attempts.
    if (
      (maxAttempts === undefined || maxAttempts > 1) &&
      !text.trim() &&
      (finishReason === 'MAX_TOKENS' || finishReason === 'LENGTH')
    ) {
      console.warn(
        `[aiProvider] gemini: empty text with finishReason=${finishReason} ` +
          `— retrying once with thinkingConfig.thinkingBudget=0`,
      );
      try {
        response = await generateWithWireRetry({ ...config, thinkingConfig: { thinkingBudget: 0 } });
        finishReason = readFinishReason(response);
        text = extractText(response);
      } catch (err: any) {
        throw describeGeminiHttpError(err, model, requestedBaseURL);
      }
    }

    const anyResponse = response as any;
    const blockReason: string | undefined = anyResponse?.promptFeedback?.blockReason ?? undefined;

    if (blockReason) {
      throw new Error(`Gemini blocked the request (reason: ${blockReason}). Adjust the content or safety settings and retry.`);
    }

    if (!text.trim()) {
      throw new Error(
        `AI provider returned an EMPTY response (finishReason: ${finishReason || 'unknown'}). ` +
          `This usually means the model used the whole token budget on internal reasoning. ` +
          `Try increasing "Max Output Tokens" in Settings, disable thinking, or use a smaller exam.`,
      );
    }

    const latencyMs = Date.now() - startTime;
    const meta: any = anyResponse?.usageMetadata || {};
    return {
      rawText: text,
      parsedJson: cleanAndParseJson(text),
      model,
      latencyMs,
      truncated: finishReason === 'MAX_TOKENS' || finishReason === 'LENGTH',
      finishReason,
      usage: meta.totalTokenCount
        ? {
            promptTokens: meta.promptTokenCount || 0,
            completionTokens: meta.candidatesTokenCount || 0,
            totalTokens: meta.totalTokenCount,
          }
        : undefined,
    };
  }

  // OpenAI-Compatible Providers (OpenAI, OpenRouter, Vercel AI Gateway, Ollama, Custom)
  const defaultBase = PROVIDER_DEFAULT_BASE_URLS[provider] || 'https://api.openai.com/v1';
  let baseURL = (providerConfig?.baseURL || defaultBase).trim().replace(/\/+$/, '');
  const apiKey = providerConfig?.apiKey || '';

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (apiKey) {
    headers['Authorization'] = `Bearer ${apiKey}`;
  }

  if (provider === 'openrouter') {
    headers['HTTP-Referer'] = 'https://exaparse.app';
    headers['X-Title'] = 'ExaParse Pro';
  }

  // Build message content
  let userContent: any = userPrompt;
  if (fileData && mimeType && mimeType.startsWith('image/')) {
    userContent = [
      { type: 'text', text: userPrompt },
      {
        type: 'image_url',
        image_url: {
          url: `data:${mimeType};base64,${fileData}`,
        },
      },
    ];
  } else if (images && images.length > 0) {
    // Multi-image batching: instruction first, then id-labeled image parts in order.
    const content: any[] = [{ type: 'text', text: userPrompt }];
    for (const im of images) {
      content.push({ type: 'text', text: `--- Image ${im.id} ---` });
      content.push({ type: 'image_url', image_url: { url: `data:${im.mimeType};base64,${im.data}` } });
    }
    userContent = content;
  }

  const promptWithJsonInstructions = jsonMode === false
    ? systemPrompt
    : `${systemPrompt}\n\nIMPORTANT: Return valid, raw JSON only. Do not wrap in markdown or backticks.`;

  const payload: any = {
    model,
    messages: [
      { role: 'system', content: promptWithJsonInstructions },
      { role: 'user', content: userContent },
    ],
    temperature,
    max_tokens: maxTokens,
  };

  // Only pass response_format if not using models that reject it
  if (jsonMode !== false && !model.includes('instruct') && !model.includes('o1-')) {
    payload.response_format = { type: 'json_object' };
  }

  const url = `${baseURL}/chat/completions`;

  // Shape-robust call with empty-output recovery (see aiResponse.ts).
  // Fixes: thinking models answering in reasoning_content, array-of-parts
  // content, gateways that emit empty content under response_format, legacy
  // choices[0].text, and answers smuggled into tool_calls.
  let recovery: Awaited<ReturnType<typeof callChatWithRecovery>>;
  try {
    recovery = await callChatWithRecovery({
      endpoint: url,
      headers,
      body: payload,
      providerLabel: provider,
      maxAttempts: maxAttempts ?? 3,
      timeoutMs,
      wireRetries,
    });
  } catch (emptyErr: any) {
    // All attempts empty/failed — surface the actionable diagnosis.
    throw new Error(emptyErr?.message || `Provider ${provider} call failed.`);
  }

  const rawText = recovery.text;
  const latencyMs = Date.now() - startTime;
  const usage: TokenUsage | undefined = recovery.usage.totalTokens > 0
    ? {
        // Honest accounting: includes tokens burned on empty retry attempts.
        promptTokens: recovery.usage.promptTokens,
        completionTokens: recovery.usage.completionTokens,
        totalTokens: recovery.usage.totalTokens,
      }
    : undefined;

  return {
    rawText,
    parsedJson: cleanAndParseJson(rawText),
    model: recovery.model || model,
    latencyMs,
    truncated: recovery.finishReason === 'length' || recovery.finishReason === 'max_tokens',
    finishReason: recovery.finishReason || undefined,
    usage,
  };
}

/**
 * Wrap raw SDK/HTTP failures from the Gemini branch with an actionable message.
 * A bare 404 stack trace tells the user nothing — this names the model, the
 * endpoint, and the two most common fixes (model slug, provider kind).
 */
export function describeGeminiHttpError(err: any, model: string, baseURL: string): Error {
  const status = err?.status ?? err?.code;
  const endpoint = baseURL || 'the Google Generative Language API (generativelanguage.googleapis.com)';
  const underlying = err?.message ? String(err.message) : 'unknown error';
  let hint = '';
  if (status === 404) {
    hint =
      `HTTP 404 — model "${model}" was not found at ${endpoint}. ` +
      `Use an exact Gemini model slug in Settings (e.g. gemini-2.5-flash, gemini-2.5-pro, gemini-2.0-flash) and make sure your API key has access to it. ` +
      `Routing through a gateway? Its Base URL must speak the Gemini protocol (…/v1beta) — an OpenAI-style URL under the Gemini provider always 404s (use the "custom" provider for those).`;
  } else if (status === 401 || status === 403) {
    hint = `HTTP ${status} — the API key was rejected by ${endpoint} (invalid key, no access to "${model}", or regional restriction).`;
  } else if (status === 429) {
    hint = `HTTP 429 — rate limit / quota exhausted at ${endpoint} for "${model}".`;
  }
  if (hint) {
    const wrapped = new Error(`${hint} [provider said: ${underlying}]`);
    (wrapped as any).status = status;
    return wrapped;
  }
  return err instanceof Error ? err : new Error(underlying);
}

const MAX_JSON_CANDIDATES = 16;
const MAX_JSON_SCAN_STARTS = 32;
const MAX_JSON_SCAN_LENGTH = 1024 * 1024; // candidate-scan bound (1 MB)

interface JsonScan {
  /** Balanced top-level JSON values, in source order. */
  candidates: string[];
  /** True when the scan from the FIRST brace never balanced — the classic
   *  truncated-output shape; salvage must run before fragment candidates. */
  firstScanUnbalanced: boolean;
}

/**
 * Scan text for balanced top-level JSON values ({…} / […]), tolerating prose,
 * markdown fences, and decoration around them. The scan is string/escape
 * aware — braces inside string literals never break the depth count — and a
 * scan that never balances (truncated output, or a decoy brace inside prose)
 * is skipped in favor of the next candidate start instead of aborting.
 */
function scanJsonCandidates(text: string): JsonScan {
  const result: JsonScan = { candidates: [], firstScanUnbalanced: false };
  if (!text) return result;
  const n = Math.min(text.length, MAX_JSON_SCAN_LENGTH);
  let start = text.slice(0, n).search(/[{[]/);
  let startsTried = 0;
  while (start !== -1 && start < n && result.candidates.length < MAX_JSON_CANDIDATES && startsTried < MAX_JSON_SCAN_STARTS) {
    startsTried++;
    const stack: string[] = [];
    let inString = false;
    let escaped = false;
    let end = -1;
    for (let i = start; i < n; i++) {
      const ch = text[i];
      if (inString) {
        if (escaped) escaped = false;
        else if (ch === '\\') escaped = true;
        else if (ch === '"') inString = false;
        continue;
      }
      if (ch === '"') {
        inString = true;
      } else if (ch === '{' || ch === '[') {
        stack.push(ch === '{' ? '}' : ']');
      } else if (ch === '}' || ch === ']') {
        if (stack.length === 0) break; // stray closer: no value starts here
        stack.pop();
        if (stack.length === 0) {
          end = i;
          break;
        }
      }
    }
    if (end === -1) {
      if (startsTried === 1) result.firstScanUnbalanced = true;
      const next = text.slice(start + 1, n).search(/[{[]/);
      start = next === -1 ? n : start + 1 + next;
      continue;
    }
    result.candidates.push(text.slice(start, end + 1));
    const next = text.slice(end + 1, n).search(/[{[]/);
    start = next === -1 ? n : end + 1 + next;
  }
  return result;
}

/**
 * Extract the FIRST balanced JSON value (object or array) from arbitrary
 * model output — prose-wrapped, fenced, or decorated. Returns null when no
 * balanced value exists (truncation territory — salvageTruncatedJson owns
 * that case). This is the named backbone of the live-run crash fix: the
 * recurring "Unexpected non-whitespace character after JSON at position N"
 * crash came from handing JSON.parse a VALID value with prose glued to it
 * ({"done":true}\n\nHere is the summary…), and "Unexpected token" from
 * prose BEFORE the value. Isolate first, parse second.
 */
export function extractFirstJsonValue(text: string): string | null {
  return scanJsonCandidates(text).candidates[0] ?? null;
}

/**
 * Parse model output as JSON, surviving every shape providers actually emit:
 *   1. clean JSON (fast path, behavior unchanged)
 *   2. output CUT OFF mid-JSON by the model's token limit (huge exams
 *      dispatched to /api/enhance-exam) — repaired by closing the still-open
 *      string literals and bracket stack instead of losing the whole response
 *   3. fenced / prose-wrapped / decorated output — balanced JSON values are
 *      isolated and parsed in source order (decoy braces in prose skipped)
 * The original parse error is only rethrown when every rung fails, so the
 * "Unexpected non-whitespace character after JSON at position N" crash can
 * no longer escape this function. Recovery rungs log loudly — silent
 * recovery of malformed output is itself worth seeing in live runs.
 */
export function cleanAndParseJson(text: string): any {
  const cleaned = text.trim();
  let primaryError: unknown;
  try {
    return JSON.parse(cleaned);
  } catch (e) {
    primaryError = e;
  }

  const scan = scanJsonCandidates(cleaned);

  // Truncation outranks fragments: when the document's first brace never
  // balances, repairing the WHOLE cut-off document beats grabbing a later
  // balanced piece of it.
  if (scan.firstScanUnbalanced) {
    const firstBrace = cleaned.search(/[{[]/);
    const salvaged = salvageTruncatedJson(firstBrace >= 0 ? cleaned.slice(firstBrace) : cleaned);
    if (salvaged !== null) {
      console.warn('[aiProvider] cleanAndParseJson: salvaged truncated JSON output');
      return salvaged;
    }
  }

  for (const candidate of scan.candidates) {
    try {
      const value = JSON.parse(candidate);
      console.warn('[aiProvider] cleanAndParseJson: recovered JSON from prose-wrapped model output');
      return value;
    } catch {
      // Balanced but not valid JSON (decoy braces in prose) — try the next.
    }
  }

  // Final rung: balanced candidates all failed to parse — run the truncation
  // repair once more before giving up, so the historic salvage-only behavior
  // stays reachable for every input shape.
  if (!scan.firstScanUnbalanced) {
    const firstBrace = cleaned.search(/[{[]/);
    const salvaged = salvageTruncatedJson(firstBrace >= 0 ? cleaned.slice(firstBrace) : cleaned);
    if (salvaged !== null) {
      console.warn('[aiProvider] cleanAndParseJson: salvaged truncated JSON output');
      return salvaged;
    }
  }

  throw primaryError instanceof Error ? primaryError : new Error(String(primaryError));
}

const MAX_SALVAGE_ATTEMPTS = 64;
const MAX_SALVAGE_LENGTH = 4 * 1024 * 1024; // 4 MB safety bound

/**
 * Best-effort repair of JSON that was truncated mid-stream.
 * Returns the repaired value, or null when nothing parseable can be recovered.
 */
function salvageTruncatedJson(text: string): any {
  if (!text || text.length > MAX_SALVAGE_LENGTH) return null;
  let candidate = text;

  for (let attempt = 0; attempt < MAX_SALVAGE_ATTEMPTS; attempt++) {
    const repaired = closeOpenJson(candidate);
    if (repaired !== null) {
      try {
        return JSON.parse(repaired);
      } catch {
        // fall through and cut back further
      }
    }

    // Cut back to the previous structural character and retry — this drops
    // partial keys / values / numbers dangling at the cut point.
    const cutIndex = findLastStructuralIndex(candidate);
    if (cutIndex <= 0) return null;
    candidate = candidate.slice(0, cutIndex);
  }
  return null;
}

/** Find the last char that can legally end a value/entry we can trim to. */
function findLastStructuralIndex(text: string): number {
  for (let i = text.length - 1; i > 0; i--) {
    const ch = text[i];
    if (ch === ',' || ch === '{' || ch === '[' || ch === ':' || ch === '"') return i;
  }
  return -1;
}

/**
 * Close an unterminated JSON document: finish open string literals (handling
 * dangling backslash escapes), then append the missing `}` / `]` closers in
 * reverse order. Returns null when no top-level object/array can be detected.
 */
function closeOpenJson(text: string): string | null {
  const start = text.search(/\S/);
  if (start === -1) return null;
  if (text[start] !== '{' && text[start] !== '[') return null;

  const stack: string[] = [];
  let inString = false;
  let escaped = false;

  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (ch === '\\') {
        escaped = true;
      } else if (ch === '"') {
        inString = false;
      }
      continue;
    }
    if (ch === '"') {
      inString = true;
    } else if (ch === '{') {
      stack.push('}');
    } else if (ch === '[') {
      stack.push(']');
    } else if (ch === '}' || ch === ']') {
      stack.pop(); // tolerate mismatched input; stack may underflow on garbage
    }
  }

  let repaired = text;
  if (inString) {
    // Drop a dangling backslash so the closing quote isn't escaped itself.
    let trailingBackslashes = 0;
    for (let i = repaired.length - 1; i >= 0 && repaired[i] === '\\'; i--) {
      trailingBackslashes++;
    }
    if (trailingBackslashes % 2 === 1) {
      repaired = repaired.slice(0, -1);
    }
    repaired += '"';
  }

  // Trim trailing separators that are now illegal before the closers.
  repaired = repaired.trimEnd();
  while (repaired.endsWith(',') || repaired.endsWith(':')) {
    repaired = repaired.slice(0, -1).trimEnd();
  }

  while (stack.length > 0) {
    repaired += stack.pop();
  }
  return repaired;
}
