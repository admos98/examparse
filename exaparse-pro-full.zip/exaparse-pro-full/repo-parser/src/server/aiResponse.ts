/**
 * aiResponse.ts — hardened OpenAI-compatible response reader + empty-output recovery.
 * ---------------------------------------------------------------------------
 * Drop-in module for ExaParse (src/server/). No imports, no dependencies.
 * Requires Node 18+ (global fetch).
 *
 * WHY THIS EXISTS
 * The old extraction in aiProvider.ts read exactly one response shape:
 *     choices[0].message.content  (string only)
 * Anything else — reasoning models that put the answer in `reasoning_content`,
 * gateways that return `content` as an ARRAY of parts, legacy `choices[0].text`,
 * answers smuggled into `tool_calls[0].function.arguments` — was read as EMPTY,
 * even though the provider happily charged ~6000 input tokens for the prompt.
 * finish_reason was "stop", so the "increase Max Output Tokens" hint was wrong.
 *
 * WHAT IT DOES
 *  1. extractModelOutput(): reads every plausible shape, returns text + usage
 *     + finish reason + a raw snippet for diagnostics.
 *  2. callChatWithRecovery(): one logical call with up to 3 wire attempts:
 *       A. the request exactly as you built it
 *       B. drop response_format/json_schema + double the output cap
 *          (fixes gateways that silently emit empty content in JSON mode)
 *       C. attempt B + thinking-disable hints (Qwen/DashScope `enable_thinking`,
 *          vLLM `chat_template_kwargs`, OpenRouter `reasoning.exclude`)
 *     The order of B and C is ADAPTIVE: if attempt A shows the
 *     thinking-exhaustion signature (finish_reason=length + reasoning, no
 *     content), C is promoted ahead of B — disabling thinking is the cheap,
 *     targeted fix, while doubling the cap on a thinking model burns up to
 *     16k output tokens. Every attempt is logged; usage is summed so the UI
 *     can show WASTED tokens when the first attempt produced nothing.
 *  3. describeEmptyCause(): turns an empty/odd response into concrete advice.
 *  4. WIRE HARDENING: every wire try carries a fresh AbortController timeout,
 *     and 429/5xx + retryable network faults retry IN PLACE with bounded
 *     exponential backoff (Retry-After honored) before the ladder moves on.
 *     See aiWire.ts for the shared policy (the Gemini branch uses it too).
 */

import { computeBackoffMs, isRetryableNetworkError, isRetryableStatus, sleep } from './aiWire';

export interface TokenUsage {
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
}

export interface AttemptLog {
  label: string;
  ok: boolean;
  empty?: boolean;
  status?: number;
  finishReason?: string;
  usage?: TokenUsage;
  note?: string;
}

export interface RecoveryResult {
  text: string;
  usage: TokenUsage;       // summed across ALL attempts (burned tokens)
  usefulUsage: TokenUsage; // usage of the attempt that finally produced text
  attempts: AttemptLog[];
  finishReason?: string;
  model?: string;          // provider-reported model id, if present
}

export interface RecoveryParams {
  endpoint: string;
  headers: Record<string, string>;
  body: Record<string, unknown>;
  providerLabel: string;      // e.g. "custom" — used in error text
  timeoutMs?: number;         // default 120000
  maxAttempts?: number;       // default 3 (A/B/C above)
  fetchImpl?: typeof fetch;   // injectable for tests
  /** Extra wire tries per variant on 429/5xx/retryable network faults.
   *  default 2; forced to 0 when maxAttempts === 1 (diagnostic pings). */
  wireRetries?: number;
  /** Backoff base for tests (default 1000ms; tests pass 1). */
  backoffBaseMs?: number;
}

const EMPTY = (finish: string, extra = '') =>
  `__EMPTY__${finish ? ` (finish_reason: ${finish})` : ''}${extra}`;

/* ------------------------------------------------------------------ */
/* Shape-robust extraction                                             */
/* ------------------------------------------------------------------ */

function joinContentParts(value: unknown): string {
  // content can be: string | Array<{type,text} | string>
  if (typeof value === 'string') return value.trim();
  if (Array.isArray(value)) {
    const parts: string[] = [];
    for (const part of value) {
      if (typeof part === 'string') parts.push(part);
      else if (part && typeof part === 'object') {
        const p = part as Record<string, unknown>;
        if (typeof p.text === 'string' && p.text.trim()) parts.push(p.text);
      }
    }
    return parts.join('\n').trim();
  }
  return '';
}

function readObj(v: unknown): Record<string, unknown> | null {
  return v && typeof v === 'object' && !Array.isArray(v)
    ? (v as Record<string, unknown>)
    : null;
}

export interface Extracted {
  text: string;
  finishReason: string;
  reasoningChars: number;  // >0 means a thinking model wrote reasoning only
  rawSnippet: string;      // first 400 chars of raw body for console logs
  model?: string;          // provider-reported model id, if present
  /** Set when the body itself was unreadable (empty / non-JSON / bare SSE) —
   *  takes priority over every shape-based diagnosis. */
  cause?: string;
}

/* ------------------------------------------------------------------ */
/* SSE (server-sent events) aggregation                                */
/* ------------------------------------------------------------------ */

/**
 * Aggregates an SSE (`data: {...}` chunk stream) body into an OpenAI-shaped
 * object. Some gateways — self-hosted routers in particular — stream the
 * answer as `text/event-stream` even when the client did NOT set stream:true.
 * A naive JSON.parse of that body lands on null and a perfectly good (and
 * fully billed!) answer is silently discarded. This reads the chunks back.
 */
export function aggregateSSE(raw: string): Record<string, unknown> | null {
  let content = '';
  let reasoning = '';
  let finishReason = '';
  let model: string | undefined;
  let usage: Record<string, unknown> | undefined;

  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed.startsWith('data:')) continue;
    const payload = trimmed.slice(5).trim();
    if (!payload || payload === '[DONE]') continue;
    let chunk: any;
    try { chunk = JSON.parse(payload); } catch { continue; }
    if (!chunk || typeof chunk !== 'object') continue;
    if (typeof chunk.model === 'string' && chunk.model) model = chunk.model;
    if (chunk.usage && typeof chunk.usage === 'object') usage = chunk.usage;
    const choice = Array.isArray(chunk.choices) ? chunk.choices[0] : undefined;
    if (!choice || typeof choice !== 'object') continue;
    if (typeof choice.finish_reason === 'string' && choice.finish_reason) {
      finishReason = choice.finish_reason;
    }
    const delta = readObj(choice.delta) ?? readObj(choice.message) ?? {};
    const c = delta.content;
    if (typeof c === 'string') content += c;
    else if (Array.isArray(c)) {
      for (const part of c) {
        if (typeof part === 'string') content += part;
        else {
          const p = readObj(part);
          if (p && typeof p.text === 'string') content += p.text;
        }
      }
    }
    const r = typeof delta.reasoning_content === 'string' ? delta.reasoning_content
            : typeof delta.reasoning === 'string' ? delta.reasoning : '';
    if (r) reasoning += r;
  }

  if (!content && !reasoning && !usage) return null;
  const message: Record<string, unknown> = { content };
  if (reasoning) message.reasoning_content = reasoning;
  const out: Record<string, unknown> = {
    choices: [{ message, finish_reason: finishReason || 'stop' }],
  };
  if (model) out.model = model;
  if (usage) out.usage = usage;
  return out;
}

/** Reads every known OpenAI-compatible response shape. Never throws. */
export function extractModelOutput(data: unknown): Extracted {
  const rawSnippet = (() => {
    try { return JSON.stringify(data).slice(0, 400); } catch { return String(data).slice(0, 400); }
  })();

  const root = readObj(data);
  if (!root) {
    return { text: '', finishReason: '', reasoningChars: 0, rawSnippet };
  }
  const model = typeof root.model === 'string' ? root.model : undefined;

  let finishReason = '';
  let text = '';
  let reasoningChars = 0;

  // --- Anthropic-style gateways: {content:[{type:'text',text}]} -----------
  const topContent = joinContentParts(root.content);
  if (topContent) text = topContent;
  if (typeof root.stop_reason === 'string') finishReason = root.stop_reason;

  // --- OpenAI Responses API: {output_text: "..."} --------------------------
  if (!text && typeof root.output_text === 'string') text = root.output_text.trim();

  // --- Legacy completions: {choices:[{text}]} ------------------------------
  const choices = Array.isArray(root.choices) ? root.choices : [];

  // --- Chat completions: {choices:[{message:{content|reasoning_content}}]} -
  if (!text && choices.length > 0) {
    const first = readObj(choices[0]) ?? {};
    if (typeof first.finish_reason === 'string') finishReason = first.finish_reason;
    else if (typeof first.finishReason === 'string') finishReason = first.finishReason;

    const message = readObj(first.message) ?? readObj(first.delta) ?? {};
    const content = joinContentParts(message.content);
    if (content) text = content;

    if (!text) {
      // Answers smuggled through tool calls (some models do this unprompted)
      const toolCalls = Array.isArray(message.tool_calls) ? message.tool_calls : [];
      if (toolCalls.length > 0) {
        const fn = readObj(readObj(toolCalls[0])?.function) ?? {};
        if (typeof fn.arguments === 'string' && fn.arguments.trim()) text = fn.arguments.trim();
      }
    }
    if (!text) {
      // Thinking models: reasoning may be present while content is empty.
      const reasoning = joinContentParts(message.reasoning_content) ||
                        joinContentParts(message.reasoning);
      reasoningChars = reasoning.length;
    }

    if (!text && typeof first.text === 'string') text = first.text.trim();
  }

  return { text, finishReason, reasoningChars, rawSnippet, model };
}

/** Turns an empty/odd response into concrete, actionable advice. */
export function describeEmptyCause(e: Extracted): string {
  if (e.cause) return e.cause; // body-level failure — the most specific truth we have
  if (e.finishReason === 'length' && e.reasoningChars > 0) {
    return `a THINKING model exhausted the output cap while still reasoning (${e.reasoningChars} chars) — no answer was ever written. ` +
           'Pick a NON-thinking model variant or disable thinking; otherwise raise Max Output Tokens so thinking AND the answer both fit';
  }
  if (e.finishReason === 'length') {
    return 'output hit the token cap mid-answer — raise "Max Output Tokens" in Settings';
  }
  if (e.finishReason === 'content_filter') {
    return 'provider content filter blocked the response — try a different model';
  }
  if (e.reasoningChars > 0) {
    return `this looks like a THINKING model — it wrote ${e.reasoningChars} chars of reasoning but no final answer. ` +
           'Disable thinking on your provider (e.g. non-thinking model variant) or raise Max Output Tokens so thinking + answer both fit';
  }
  if (e.rawSnippet.includes('"choices":[]') || e.rawSnippet.includes('"choices": []')) {
    return 'provider returned zero choices (often a safety block or rate limit) — check the provider console';
  }
  return 'provider wrote nothing readable — see server console for the raw response snippet';
}

/* ------------------------------------------------------------------ */
/* One logical call with wire-level recovery                           */
/* ------------------------------------------------------------------ */

function readUsage(data: unknown): TokenUsage {
  const u = readObj(readObj(data)?.usage) ?? {};
  const n = (v: unknown): number => (typeof v === 'number' && isFinite(v) ? v : 0);
  return {
    promptTokens: n(u.prompt_tokens),
    completionTokens: n(u.completion_tokens),
    totalTokens: n(u.total_tokens) || n(u.prompt_tokens) + n(u.completion_tokens),
  };
}

const sumUsage = (a: TokenUsage, b: TokenUsage): TokenUsage => ({
  promptTokens: a.promptTokens + b.promptTokens,
  completionTokens: a.completionTokens + b.completionTokens,
  totalTokens: a.totalTokens + b.totalTokens,
});

function variantB(body: Record<string, unknown>): Record<string, unknown> {
  const b = { ...body };
  delete b.response_format;          // known silent-empty trigger on some gateways
  delete b.json_schema;
  delete b.grammar;
  const key = 'max_completion_tokens' in b ? 'max_completion_tokens'
            : 'max_tokens' in b ? 'max_tokens' : null;
  if (key) {
    const cap = Math.min(Number(b[key]) * 2 || 8192, 16384);
    b[key] = cap;
  }
  return b;
}

function variantC(body: Record<string, unknown>): Record<string, unknown> {
  return {
    ...variantB(body),
    // Thinking-disable hints. Servers that don't know a field ignore it;
    // if one rejects with 400 we simply surface attempt B's result instead.
    enable_thinking: false,                              // Qwen / DashScope-compat
    chat_template_kwargs: { enable_thinking: false },    // vLLM
    reasoning: { enabled: false, exclude: true },        // OpenRouter
  };
}

function parseErrorBody(raw: string): string {
  try {
    const j = JSON.parse(raw) as Record<string, unknown>;
    const err = readObj(j.error);
    if (err && typeof err.message === 'string') return err.message;
  } catch { /* not JSON */ }
  return raw.slice(0, 200);
}

export async function callChatWithRecovery(params: RecoveryParams): Promise<RecoveryResult> {
  const {
    endpoint, headers, body, providerLabel,
    timeoutMs = 120_000, maxAttempts = 3,
    fetchImpl = (globalThis as { fetch: typeof fetch }).fetch,
    wireRetries: wireRetriesParam = 2,
    backoffBaseMs = 1_000,
  } = params;
  // Diagnostic pings (maxAttempts === 1) keep the single-shot contract: a
  // transport-level failure repeats identically and retries only burn time.
  const wireRetries = maxAttempts === 1 ? 0 : Math.max(0, wireRetriesParam);

  const variants: Array<{ label: string; body: Record<string, unknown> }> = [];
  if (maxAttempts >= 1) variants.push({ label: 'A:as-built', body });
  if (maxAttempts >= 2) variants.push({ label: 'B:no-json-mode', body: variantB(body) });
  if (maxAttempts >= 3) variants.push({ label: 'C:no-think', body: variantC(body) });
  const attempts: AttemptLog[] = [];
  let burned: TokenUsage = { promptTokens: 0, completionTokens: 0, totalTokens: 0 };
  let useful: TokenUsage = { promptTokens: 0, completionTokens: 0, totalTokens: 0 };
  let lastCause = 'unknown';
  let lastFinish = '';
  let lastSnippet = '';
  let reasoningChars = 0;
  let reportedModel: string | undefined;
  let ladderDoomed = false; // 401/403/404: no variant can succeed — stop the ladder

  for (const variant of variants) {
    // Wire-level retry loop: the SAME variant retries on 429/5xx and retryable
    // network faults with bounded exponential backoff before the ladder moves
    // to the next variant. Every try gets a FRESH timeout budget.
    for (let wireTry = 0; ; wireTry++) {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), timeoutMs);
      let res: Response;
      try {
        res = await fetchImpl(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...headers },
          body: JSON.stringify(variant.body),
          signal: ctrl.signal,
        });
      } catch (err) {
        clearTimeout(timer);
        const msg = err instanceof Error ? err.message : String(err);
        const aborted = msg.includes('abort') || ctrl.signal.aborted;
        if (!aborted && wireTry < wireRetries && isRetryableNetworkError(err)) {
          attempts.push({ label: variant.label, ok: false, note: `retry ${wireTry + 1}/${wireRetries} (${msg.slice(0, 80)})` });
          await sleep(computeBackoffMs(null, wireTry, backoffBaseMs));
          continue;
        }
        attempts.push({ label: variant.label, ok: false, note: aborted ? 'timeout' : msg });
        lastCause = aborted ? `timed out after ${timeoutMs / 1000}s` : msg;
        break; // next variant
      }
      clearTimeout(timer);

      if (!res.ok) {
        // Retryable status + tries left: back off IN PLACE (same variant),
        // honoring the provider's Retry-After hint when present.
        if (isRetryableStatus(res.status) && wireTry < wireRetries) {
          attempts.push({ label: variant.label, ok: false, status: res.status, note: `retry ${wireTry + 1}/${wireRetries}` });
          const ra = res.headers?.get ? res.headers.get('retry-after') : null;
          await sleep(computeBackoffMs(ra, wireTry, backoffBaseMs));
          continue;
        }
        const errText = await res.text().catch(() => '');
        const errDetail = parseErrorBody(errText);
        attempts.push({
          label: variant.label, ok: false, status: res.status,
          note: errDetail,
        });
        // Record the cause BEFORE the auth-break below: a 401/403/404 ends the
        // ladder immediately, and the final error must say WHY ("Cause: HTTP
        // 404: model not found"), not the useless "Cause: unknown".
        lastCause = `HTTP ${res.status}: ${errDetail}`;
        // 401/403/404: no point retrying other variants with the same auth/path
        if (res.status === 401 || res.status === 403 || res.status === 404) ladderDoomed = true;
        break; // next variant (or stop the ladder entirely)
      }

      const rawBody = await res.text().catch(() => '');
      let data: unknown = null;
      try { data = JSON.parse(rawBody); } catch { data = null; }
      // Gateways that stream without being asked (stream:false on our side):
      // the body is an SSE chunk stream, JSON.parse lands on null, and a
      // fully-billed answer would be silently discarded. Read it back.
      const looksSSE = /^\s*data:/.test(rawBody);
      if (data === null && looksSSE) {
        const agg = aggregateSSE(rawBody);
        if (agg) data = agg;
      }
      const e = extractModelOutput(data);
      if (data === null) {
        // Show the TRUE bytes in diagnostics instead of a misleading "null".
        e.rawSnippet = rawBody.trim() ? rawBody.slice(0, 400) : '<empty body (0 bytes)>';
        e.cause = !rawBody.trim()
          ? 'provider returned HTTP 200 with an empty body (0 bytes) — response was lost at the gateway'
          : looksSSE
            ? 'provider replied with an SSE event stream that carried no usable content'
            : `body was not JSON — first bytes: ${rawBody.slice(0, 120)}`;
      }
      const usage = readUsage(data);
      burned = sumUsage(burned, usage);
      lastFinish = e.finishReason;
      lastSnippet = e.rawSnippet;

      if (e.text) {
        attempts.push({ label: variant.label, ok: true, finishReason: e.finishReason, usage });
        if (!useful.totalTokens) useful = usage;
        return { text: e.text, usage: burned, usefulUsage: useful, attempts, finishReason: e.finishReason, model: e.model };
      }

      reasoningChars = Math.max(reasoningChars, e.reasoningChars);
      if (e.model) reportedModel = e.model;
      lastCause = describeEmptyCause(e);
      attempts.push({
        label: variant.label, ok: true, empty: true,
        finishReason: e.finishReason, usage,
        note: e.reasoningChars > 0 ? `reasoning-only (${e.reasoningChars} chars)` : 'empty content',
      });
      console.warn(
        `[aiResponse] ${providerLabel} ${variant.label}: EMPTY output ` +
        `(finish_reason: ${e.finishReason || 'unknown'}, reasoning: ${e.reasoningChars} chars, ` +
        `usage: ${usage.promptTokens}in/${usage.completionTokens}out). Raw snippet: ${e.rawSnippet}`,
      );
      // Adaptive order (#fix-4): a THINKING model that burned the whole cap on
      // reasoning (finish_reason=length + reasoning, no content) will not be
      // saved by B's doubled cap alone — and thinking through 16k tokens is
      // exactly the cost problem. The cheap, targeted next attempt is the
      // thinking-off variant, so promote it ahead of B for the remaining tries.
      if (
        variant.label === 'A:as-built' &&
        e.finishReason === 'length' && e.reasoningChars > 0 &&
        variants.length >= 3 && variants[1].label !== 'C:no-think'
      ) {
        const c = variants.splice(variants.findIndex(v => v.label === 'C:no-think'), 1)[0];
        variants.splice(1, 0, c);
      }
      break; // empty output — next variant
    }
    if (ladderDoomed) break;
  }

  const attemptSummary = attempts
    .map(a => `${a.label}${a.status ? ` HTTP${a.status}` : ''}${a.empty ? ' empty' : a.ok ? '' : ' failed'}`)
    .join(' → ');

  const err = new Error(
    `Provider ${providerLabel} returned no usable output after ${attempts.length} attempts (${attemptSummary}). ` +
    `Cause: ${lastCause}. ` +
    (lastSnippet ? `Raw response started with: ${lastSnippet.slice(0, 200)} ` : '') +
    `Last finish_reason: ${lastFinish || 'unknown'}.` +
    (burned.totalTokens ? ` ${burned.totalTokens} tokens were consumed and will show as "wasted" in the usage panel.` : ''),
  );
  (err as Error & { attempts?: AttemptLog[]; burnedTokens?: number }).attempts = attempts;
  (err as Error & { attempts?: AttemptLog[]; burnedTokens?: number }).burnedTokens = burned.totalTokens;
  void reportedModel;
  throw err;
}
