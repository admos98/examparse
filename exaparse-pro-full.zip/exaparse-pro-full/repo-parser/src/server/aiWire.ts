/**
 * aiWire.ts — wire-level hardening shared by EVERY AI path (the Gemini SDK
 * branch and the OpenAI-compatible fetch branch alike): request timeouts and
 * bounded retry with exponential backoff on rate limits / transient faults.
 *
 * Failure classes handled here (the "it failed, I'm tired, make it just work"
 * friction of flaky free-gateway models):
 *
 *   HANG   — a provider that never responds used to block the whole
 *            verify/answer/vision flow with no recovery. Every wire call now
 *            carries an AbortController with a configurable timeout:
 *            providerConfig.timeoutMs > env AI_TIMEOUT_MS > 120s default.
 *
 *   429/5xx— rate limits and transient gateway errors retry IN PLACE with
 *            exponential backoff (1s base, doubling, 30s cap), honoring a
 *            provider `Retry-After` hint when present. Bounded: at most
 *            `wireRetries` extra wire tries per logical attempt, and
 *            diagnostic pings (maxAttempts: 1) keep their single-shot
 *            contract — zero wire retries.
 *
 *   400/401/403/404 are NEVER retried: auth/path/model errors repeat
 *            identically — retrying only burns quota and hides the real
 *            diagnosis.
 */

export const DEFAULT_WIRE_TIMEOUT_MS = 120_000;
export const BASE_BACKOFF_MS = 1_000;
export const MAX_BACKOFF_MS = 30_000;
/** Hard ceiling on a provider-supplied Retry-After hint (seconds). */
export const MAX_RETRY_AFTER_S = 30;

/**
 * Effective wire timeout: explicit per-call override (Settings / request)
 * wins, then the AI_TIMEOUT_MS env, then the 120s default.
 */
export function resolveTimeoutMs(explicit?: number): number {
  if (Number.isFinite(explicit) && (explicit as number) > 0) return explicit as number;
  const env = Number(process.env.AI_TIMEOUT_MS);
  if (Number.isFinite(env) && env > 0) return env;
  return DEFAULT_WIRE_TIMEOUT_MS;
}

/** Statuses worth an in-place retry: rate limit + transient server faults. */
export function isRetryableStatus(status: number | undefined | null): boolean {
  return status === 429 || status === 500 || status === 502 || status === 503 || status === 504;
}

/**
 * Network-level faults worth a retry (transport died mid-call).
 * Aborts are NEVER retried here: an abort is either the caller's timeout
 * (retrying would double the stall) or a deliberate cancellation.
 */
export function isRetryableNetworkError(err: unknown): boolean {
  const msg = err instanceof Error ? `${err.name}: ${err.message}` : String(err);
  if (/abort/i.test(msg)) return false;
  return /ECONNRESET|ECONNREFUSED|ETIMEDOUT|EPIPE|EAI_AGAIN|socket hang up|network|fetch failed|terminated|other side closed/i.test(
    msg,
  );
}

/**
 * Backoff before retry attempt n (0-based). A provider `Retry-After` hint
 * (seconds) wins — capped at MAX_RETRY_AFTER_S — else base * 2^n, capped.
 * Half-jitter spreads concurrent calls so a recovering rate limit isn't
 * hammered in lock-step.
 */
export function computeBackoffMs(
  retryAfterHeader: string | null | undefined,
  attempt: number,
  baseMs: number = BASE_BACKOFF_MS,
): number {
  const ra =
    retryAfterHeader === null || retryAfterHeader === undefined || retryAfterHeader === ''
      ? NaN
      : Number(retryAfterHeader);
  if (Number.isFinite(ra) && ra >= 0) return Math.min(ra, MAX_RETRY_AFTER_S) * 1000;
  const exp = Math.min(baseMs * 2 ** Math.max(0, attempt), MAX_BACKOFF_MS);
  return Math.max(0, Math.floor(exp * (0.5 + Math.random() * 0.5)));
}

export const sleep = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms));
