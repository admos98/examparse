import { executeAIRequest, AIResponse } from './aiProvider.js';
import {
  computeBackoffMs,
  isRetryableNetworkError,
  isRetryableStatus,
  resolveTimeoutMs,
  sleep,
} from './aiWire.js';
import { TokenUsage } from '../types/exam.js';

/**
 * Jev judge backend (judge-ONLY protocol — this module NEVER authors exam
 * content; it only evaluates state+questions and returns typed answers).
 *
 * Two backends, one normalized result shape:
 *   1. callNativeJev — the verified TypeSafe "System One" HTTP API.
 *      Endpoint: POST {baseUrl}/systemone  (Authorization: Bearer <key>)
 *      Both https://api.typesafe.ai/v1 (TypeSafe direct) and
 *      https://openrouter.ai/api/v1 (OpenRouter) expose the SAME verified
 *      request/response shape — see JEV_NOTES.md §4/§9.
 *   2. judgeViaLLM  — identical interface against the user's existing LLM
 *      provider, so the feature degrades gracefully when no Jev endpoint is
 *      reachable (geo-blocks, no key, outage). Swap-in point for the official
 *      @typesafe-ai/sdk is callNativeJev() — nothing else changes.
 *
 * Research sources: docs.typesafe.ai/api.md, openrouter.ai/docs/.../submit-
 * a-system-one-request.md, langfuse.com Jev docs, LangChain benchmark blog.
 */

export type JevTypedQuestion =
  | { type: 'noul'; instructions: string | object; criteria?: { true?: string; false?: string } }
  | { type: 'choice'; instructions: string | object; criteria: Record<string, string | null> }
  | { type: 'score'; instructions: string | object; criteria: string[] };

export type JevAnswer =
  | { type: 'noul'; p: number }
  | { type: 'choice'; choice: string; probabilities?: Record<string, number>; confidence?: number; invalid?: boolean }
  | { type: 'score'; score: number; confidence?: number; invalid?: boolean };

export interface JevCallResult {
  ok: boolean;
  backend: 'jev' | 'llm-fallback';
  model: string;
  answers: Record<string, JevAnswer>;
  usage?: TokenUsage;
  latencyMs: number;
  warnings: string[];
  error?: string;
}

/** OpenRouter's "overloaded" status rides the same retry policy as 5xx. */
const JEV_OVERLOADED_STATUS = 529;
/** Extra wire attempts after the first (default: 3 attempts total, bounded). */
const DEFAULT_NATIVE_WIRE_RETRIES = 2;

/** Native Jev retryable statuses: the shared 429/5xx set + 529 overloaded. */
export function isNativeRetryableStatus(status: number): boolean {
  return isRetryableStatus(status) || status === JEV_OVERLOADED_STATUS;
}

function clamp01(n: unknown): number {
  const v = typeof n === 'number' ? n : parseFloat(String(n));
  if (!Number.isFinite(v)) return -1;
  return Math.max(0, Math.min(1, v));
}

/**
 * Native TypeSafe /v1/systemone call. Throws only on fatal config errors;
 * network/HTTP failures surface as {ok:false, error} after retries.
 *
 * WIRE-HARDENED (same policy as every AI path via aiWire.ts):
 *   - Each attempt carries an AbortController with a configurable timeout
 *     (timeoutMs arg > env AI_TIMEOUT_MS > 120s default). A hung endpoint
 *     aborts with an exact "timed out after Ns" diagnosis instead of
 *     stalling the judge flow forever. Timeouts are NEVER retried.
 *   - 429/5xx/529 retry IN PLACE with bounded exponential backoff (1s base,
 *     30s cap) honoring a Retry-After hint; retryable transport faults
 *     (ECONNRESET & co) retry too; 400/401/403/404 never do.
 *
 * SWAP-IN POINT: replace this function's body with `@typesafe-ai/sdk`
 * (`new TypeSafeClient().systemOne({state, questions})`) when desired —
 * the normalized JevCallResult contract stays identical.
 */
export async function callNativeJev({
  baseUrl,
  apiKey,
  model,
  state,
  questions,
  timeoutMs,
  wireRetries,
}: {
  baseUrl: string;
  apiKey: string;
  model: string;
  state: unknown;
  questions: Record<string, JevTypedQuestion>;
  /** Per-call wire timeout override (else env AI_TIMEOUT_MS, else 120s). */
  timeoutMs?: number;
  /** Extra wire attempts after the first (default 2 → 3 attempts total). */
  wireRetries?: number;
}): Promise<JevCallResult> {
  const started = Date.now();
  const warnings: string[] = [];
  const base = (baseUrl || '').trim().replace(/\/+$/, '');
  if (!base) {
    return { ok: false, backend: 'jev', model, answers: {}, latencyMs: 0, warnings, error: 'Jev base URL is not configured.' };
  }
  if (!apiKey) {
    return { ok: false, backend: 'jev', model, answers: {}, latencyMs: 0, warnings, error: 'Jev API key is missing.' };
  }
  const url = `${base}/systemone`;
  const timeout = resolveTimeoutMs(timeoutMs);
  const maxAttempts =
    1 + Math.max(0, Number.isFinite(wireRetries) ? Math.floor(wireRetries as number) : DEFAULT_NATIVE_WIRE_RETRIES);
  const timeoutError = `Jev request timed out after ${(timeout / 1000).toFixed(1)}s with no response (endpoint: ${url}).`;

  let lastError = '';
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ state, model, questions }),
        signal: controller.signal,
      });

      if (isNativeRetryableStatus(res.status)) {
        if (attempt < maxAttempts) {
          const waitMs = computeBackoffMs(res.headers.get('retry-after'), attempt - 1);
          warnings.push(`Jev returned HTTP ${res.status}; retrying in ${Math.round(waitMs)} ms (attempt ${attempt}).`);
          await sleep(waitMs);
          continue;
        }
        lastError = `Jev endpoint returned HTTP ${res.status} after ${attempt} attempts (rate-limited/overloaded).`;
        break;
      }

      if (!res.ok) {
        const body = await res.text().catch(() => '');
        lastError = `Jev endpoint returned HTTP ${res.status} ${res.statusText}${body ? `: ${body.slice(0, 200)}` : ''}`;
        break;
      }

      const data: any = await res.json();
      const rawAnswers = data?.answers && typeof data.answers === 'object' ? data.answers : {};
      const answers: Record<string, JevAnswer> = {};
      for (const [qid, raw] of Object.entries<any>(rawAnswers)) {
        if (!raw || typeof raw !== 'object') continue;
        if (raw.type === 'noul') {
          const p = clamp01(raw.noul);
          if (p >= 0) answers[qid] = { type: 'noul', p };
        } else if (raw.type === 'choice') {
          answers[qid] = {
            type: 'choice',
            choice: String(raw.choice ?? ''),
            probabilities: raw.probabilities && typeof raw.probabilities === 'object' ? raw.probabilities : undefined,
            confidence: typeof raw.confidence === 'number' ? raw.confidence : undefined,
          };
        } else if (raw.type === 'score') {
          const score = typeof raw.score === 'number' ? raw.score : parseFloat(String(raw.score));
          answers[qid] = {
            type: 'score',
            score: Number.isFinite(score) ? score : -1,
            confidence: typeof raw.confidence === 'number' ? raw.confidence : undefined,
          };
        }
      }

      const usage: TokenUsage | undefined = data?.usage
        ? {
            promptTokens: data.usage.input_tokens || 0,
            completionTokens: data.usage.output_tokens || 0, // Jev output is free, but keep the shape
            totalTokens: (data.usage.input_tokens || 0) + (data.usage.output_tokens || 0),
          }
        : undefined;

      return {
        ok: answers && Object.keys(answers).length > 0,
        backend: 'jev',
        model: String(data?.model || model),
        answers,
        usage,
        latencyMs: Date.now() - started,
        warnings,
      };
    } catch (e: any) {
      const msg = e?.message || String(e);
      // An abort here is ALWAYS our own timeout (no external signal exists):
      // exact diagnosis, and — like every wire path — never retried, since a
      // retry would just double the stall.
      if (controller.signal.aborted) {
        lastError = timeoutError;
        break;
      }
      lastError = msg;
      if (!isRetryableNetworkError(e) || attempt >= maxAttempts) break;
      const waitMs = computeBackoffMs(null, attempt - 1);
      warnings.push(`Jev wire fault (${msg}); retrying in ${Math.round(waitMs)} ms (attempt ${attempt}).`);
      await sleep(waitMs);
    } finally {
      clearTimeout(timer);
    }
  }

  return { ok: false, backend: 'jev', model, answers: {}, latencyMs: Date.now() - started, warnings, error: lastError || 'Jev call failed.' };
}

/**
 * LLM fallback with the SAME normalized contract. One bounded call per
 * batch; strict-enum validation discards anything outside the allowed
 * answers (a Choice verdict not in criteria is marked invalid, nouls are
 * clamped to [0,1], scores to their level range) so the deterministic
 * client-side cascade can treat both backends identically.
 */
export async function judgeViaLLM({
  state,
  questions,
  providerConfig,
}: {
  state: unknown;
  questions: Record<string, JevTypedQuestion>;
  providerConfig?: any;
}): Promise<JevCallResult> {
  const started = Date.now();
  const warnings: string[] = [];

  const systemPrompt =
    'You are a CALIBRATED EXAM JUDGE. You receive a state (exam context) and a map of typed questions.\n' +
    'You evaluate ONLY — you never invent exam content and never write answers.\n' +
    'Question types:\n' +
    '- noul: yes/no. Reply {"p": <probability 0..1 that the answer is true>}.\n' +
    '- choice: reply {"choice": "<one of the provided criteria option keys>"} — nothing outside the keys.\n' +
    '- score: reply {"score": <number between 0 and (number of levels - 1)>}.\n' +
    'Reply with RAW JSON only: { "answers": { "<questionId>": { "type": "<noul|choice|score>", ... } } }.\n' +
    'Every question id you received MUST appear in answers. No markdown, no explanations.';

  const userPrompt = JSON.stringify({ state, questions });

  let ai: AIResponse;
  try {
    ai = await executeAIRequest({
      systemPrompt,
      userPrompt,
      providerConfig: { ...providerConfig, temperature: 0 },
    });
  } catch (e: any) {
    return {
      ok: false,
      backend: 'llm-fallback',
      model: providerConfig?.model || 'unknown',
      answers: {},
      latencyMs: Date.now() - started,
      warnings,
      error: e?.message || 'LLM judge fallback failed.',
    };
  }

  const raw = ai.parsedJson?.answers && typeof ai.parsedJson.answers === 'object' ? ai.parsedJson.answers : {};
  const answers: Record<string, JevAnswer> = {};

  for (const [qid, q] of Object.entries(questions)) {
    const a = raw[qid];
    if (!a || typeof a !== 'object') {
      warnings.push(`Fallback judge returned no answer for "${qid}".`);
      continue;
    }
    if (q.type === 'noul' && a.type === 'noul') {
      const p = clamp01(a.p);
      if (p >= 0) answers[qid] = { type: 'noul', p };
    } else if (q.type === 'choice' && a.type === 'choice') {
      const choice = String(a.choice ?? '');
      const valid = Object.keys(q.criteria).some((k) => k.toLowerCase() === choice.toLowerCase());
      answers[qid] = {
        type: 'choice',
        choice: valid ? choice : '',
        probabilities: a.probabilities && typeof a.probabilities === 'object' ? a.probabilities : undefined,
        confidence: typeof a.confidence === 'number' ? a.confidence : undefined,
        invalid: !valid,
      };
      if (!valid) warnings.push(`Fallback verdict "${choice}" for "${qid}" is outside the allowed options — discarded.`);
    } else if (q.type === 'score' && a.type === 'score') {
      const max = q.criteria.length - 1;
      const score = typeof a.score === 'number' ? a.score : parseFloat(String(a.score));
      answers[qid] = {
        type: 'score',
        score: Number.isFinite(score) ? Math.max(0, Math.min(max, score)) : -1,
        confidence: typeof a.confidence === 'number' ? a.confidence : undefined,
      };
    }
  }

  return {
    ok: Object.keys(answers).length > 0,
    backend: 'llm-fallback',
    model: ai.model,
    answers,
    usage: ai.usage,
    latencyMs: Date.now() - started,
    warnings: [...warnings, ...(ai.truncated ? [`Fallback judge output was truncated (${ai.finishReason || 'length'}); some questions were left unjudged.`] : [])],
    error: Object.keys(answers).length === 0 ? 'The fallback judge returned no usable answers.' : undefined,
  };
}
