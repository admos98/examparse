import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { executeAIRequest } from './aiProvider';
import {
  MinedRule,
  MinedRuleStatus,
  MiningReport,
  runMiningPipeline,
  mergeMinedRules,
  transitionRule,
  MiningCorpusEntry,
  MAX_RULES,
} from '../utils/ruleMiner';
import { GoldenGT } from '../utils/goldenGrade';
import { SectionTemplate } from '../utils/sectionTemplates';
import { parseExamRawText } from '../utils/parserEngine';

/**
 * Rule-mining service layer (Idea 1) — the ONLY place that touches the AI,
 * the filesystem, and the golden corpus. All decision logic lives in
 * src/utils/ruleMiner.ts (pure, dependency-injected, fully testable).
 *
 * AI economics (the user-approved contract): ONE executeAIRequest call per
 * mining request. The proposal is validated, grounded, target-checked and
 * shadow-run locally — none of that costs tokens.
 */

export const MINED_RULES_PATH =
  process.env.MINED_RULES_PATH || path.join(process.cwd(), 'data', 'mined-rules.json');

// Workspace root derived from this file's own location — never an absolute
// machine path — so the shadow-run corpus resolves out-of-the-box anywhere the
// workspace or unzipped bundle is placed (layout: see scripts-batch/wsPaths.mts).
const WS_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', '..');

const MAX_RAW_TEXT_CHARS = 400_000;

// ---------------------------------------------------------------------------
// Store (data/mined-rules.json)
// ---------------------------------------------------------------------------

export function loadMinedRules(): MinedRule[] {
  try {
    if (!fs.existsSync(MINED_RULES_PATH)) return [];
    const parsed = JSON.parse(fs.readFileSync(MINED_RULES_PATH, 'utf8'));
    return Array.isArray(parsed) ? parsed.filter((r) => r && typeof r === 'object') : [];
  } catch (e: any) {
    console.warn('[ruleMining] mined-rules store unreadable:', e?.message);
    return [];
  }
}

export function saveMinedRules(rules: MinedRule[]): void {
  fs.mkdirSync(path.dirname(MINED_RULES_PATH), { recursive: true });
  fs.writeFileSync(MINED_RULES_PATH, JSON.stringify(rules, null, 2), 'utf8');
}

export function changeRuleStatus(id: string, status: MinedRuleStatus): { ok: boolean; error?: string; rules: MinedRule[] } {
  const rules = loadMinedRules();
  const res = transitionRule(rules, id, status);
  if (res.ok) saveMinedRules(res.rules);
  return res;
}

// ---------------------------------------------------------------------------
// Golden corpus loading (for the shadow run)
// ---------------------------------------------------------------------------

function loadShadowCorpus(): MiningCorpusEntry[] {
  const pairs: [string, string][] = [
    [process.env.GT_DIR || path.join(WS_ROOT, 'scratch/gt'), process.env.TEXT_DIR || path.join(WS_ROOT, 'scratch/texts')],
    [process.env.GT_MOCKS_DIR || path.join(WS_ROOT, 'scratch/gt-mocks'), process.env.TEXT_MOCKS_DIR || path.join(WS_ROOT, 'scratch/texts-mocks')],
  ];
  const corpus: MiningCorpusEntry[] = [];
  for (const [gtDir, textDir] of pairs) {
    try {
      if (!fs.existsSync(gtDir) || !fs.existsSync(textDir)) continue;
      for (const f of fs.readdirSync(gtDir).filter((x) => x.endsWith('.json')).sort()) {
        if (corpus.length >= 100) break;
        const gt = JSON.parse(fs.readFileSync(path.join(gtDir, f), 'utf8')) as GoldenGT;
        const textPath = path.join(textDir, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
        if (!fs.existsSync(textPath)) continue;
        corpus.push({ name: gt.file, text: fs.readFileSync(textPath, 'utf8'), gt });
      }
    } catch (e: any) {
      console.warn(`[ruleMining] corpus dir skipped (${gtDir}):`, e?.message);
    }
  }
  return corpus;
}

// ---------------------------------------------------------------------------
// Prompt — teaches the constrained DSL and the corpus context
// ---------------------------------------------------------------------------

export interface ParseSummarySection {
  rowId: string;
  category: string;
  markTotal: number;
  templateHints?: { templateId: string; suggestsType: string; score: number }[];
  questions: { n: number | string; type: string; stem: string }[];
}

export function buildMiningPrompt(rawText: string, parseSummary: ParseSummarySection[]): {
  systemPrompt: string;
  userPrompt: string;
} {
  const systemPrompt = `You are a PARSE-RULE MINER for a deterministic Persian/English exam parser.
You receive: the RAW text of one exam page, the parser's current (imperfect) output for it, and mined layout templates for its sections.

Propose ONE minimal corrective rule AND the corrected expected parse.

The rule MUST fit this schema exactly:
{
  "analysis": "<1-3 sentences: what the parser got wrong and why>",
  "rule": {
    "condition": {
      "sectionRowId": "<exact section id, e.g. 'ب' or 'A'>",          // optional
      "suggestsTypeFromTemplate": "<a question type the section's template suggests>", // optional
      "stemRegex": "<regexp tested against question stems>",          // optional
      "instructionRegex": "<regexp tested against the section instruction>", // optional
      "questionNumbers": [1, 2]                                       // optional explicit targets
    },
    "action": {
      "setType": "<one type from the whitelist>",   // and/or setCategory, and/or setMark
      "setCategory": "<Listening|Vocabulary|Grammar|Writing|Reading|General>",
      "setMark": <positive number>
    },
    "rationale": "<one sentence a teacher would understand>"
  },
  "expectedParse": {
    "header": { "<field>": "<value>" },     // optional, only if the header is wrong
    "totalMarks": <number>,                 // optional
    "sections": [
      { "id": "<section id>", "cat": "<category>", "mark": <section total>,
        "questions": [ { "n": <number>, "t": "<type>" } ] }
    ]
  }
}

HARD RULES:
- Scope the condition as NARROWLY as possible; a broad rule will be rejected by the corpus gate.
- The expectedParse must describe the WHOLE parsed document, exactly as the printed paper shows it (question numbers increasing, real types).
- Types whitelist: multiple_choice, cloze_item, word_bank_fill, fill_blank, matching, true_false, short_answer, long_answer_essay, unscramble, form_in_parentheses, combine_sentences, active_passive, error_correction, letter_reorder, inline_choice, dialogue_response, odd_one_out, phonetic_pronunciation, sentence_ordering, picture_description, translation, definition_matching, numerical_calculation.
- If the parse is actually correct, return rule.action = {} — no, you MUST return at least one action; instead return {"analysis":"the parse is correct","rule":{"condition":{"sectionRowId":"<first section>"},"action":{"setType":"<the type it already has>"},"rationale":"no change needed"},"expectedParse":<the parse as it is>}.
- Reply with RAW JSON only. No markdown, no commentary.`;

  const userPrompt = JSON.stringify({
    rawText: rawText.slice(0, 60_000),
    currentParse: parseSummary.map((s) => ({
      rowId: s.rowId,
      category: s.category,
      markTotal: s.markTotal,
      templateHints: s.templateHints,
      questions: s.questions.map((q) => ({ n: q.n, type: q.type, stem: (q.stem || '').slice(0, 140) })),
    })),
  });

  return { systemPrompt, userPrompt };
}

// ---------------------------------------------------------------------------
// The one-call mining service
// ---------------------------------------------------------------------------

export async function mineRule(opts: {
  rawText: string;
  sourceFile?: string;
  parseSummary?: ParseSummarySection[];
  providerConfig?: any;
  templates?: SectionTemplate[];
  promptHash?: string;
}): Promise<MiningReport & { deduped?: boolean; persisted?: boolean }> {
  const rawText = String(opts.rawText || '');
  if (!rawText.trim()) {
    return { ok: false, error: 'No raw text supplied to mine from.', warnings: [] };
  }
  if (rawText.length > MAX_RAW_TEXT_CHARS) {
    return { ok: false, error: `Raw text too large (${rawText.length} chars; limit ${MAX_RAW_TEXT_CHARS}).`, warnings: [] };
  }

  const { systemPrompt, userPrompt } = buildMiningPrompt(rawText, opts.parseSummary || []);

  // THE one billable call (JSON recovery ladder lives inside executeAIRequest).
  const ai = await executeAIRequest({
    systemPrompt,
    userPrompt,
    providerConfig: { ...opts.providerConfig, temperature: 0 },
  });
  if (!ai?.parsedJson) {
    return { ok: false, error: 'The mining model returned no parsable JSON proposal.', warnings: [] };
  }

  const corpus = loadShadowCorpus();
  const report = runMiningPipeline({
    rawText,
    sourceFile: opts.sourceFile,
    proposal: ai.parsedJson,
    corpus,
    model: ai.model,
    promptHash: opts.promptHash,
  });

  if (report.ok && report.rule) {
    try {
      const store = loadMinedRules();
      const merged = mergeMinedRules(store, report.rule);
      saveMinedRules(merged.rules);
      return { ...report, deduped: merged.deduped, persisted: true };
    } catch (e: any) {
      return { ...report, warnings: [...report.warnings, `Rule approved but NOT persisted: ${e?.message || e}`], persisted: false };
    }
  }
  return report;
}

/** Parse+summarize server-side when the client cannot summarize (thin helper). */
export function summarizeRawText(rawText: string, templates: SectionTemplate[]): ParseSummarySection[] {
  const doc = parseExamRawText(rawText, 'mining-summary', { detectAnomalies: false, normalizeNumbering: true, linkClozePassages: true });
  return doc.sections.map((s) => ({
    rowId: s.rowId,
    category: s.majorCategory,
    markTotal: s.markTotal,
    templateHints: s.templateHints?.map((h) => ({ templateId: h.templateId, suggestsType: h.suggestsType, score: h.score })),
    questions: s.questions.map((q) => ({ n: q.number, type: q.type, stem: q.stem || '' })),
  }));
}

export { MAX_RULES };
