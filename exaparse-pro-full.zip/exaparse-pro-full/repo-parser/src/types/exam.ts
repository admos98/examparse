/** Current ExamDocument schema version — bump when migrations change shapes. */
export const EXAM_SCHEMA_VERSION = 3;

export type QuestionType =
  | 'multiple_choice'
  | 'cloze_item'
  | 'word_bank_fill'
  | 'fill_blank'
  | 'matching'
  | 'true_false'
  | 'short_answer'
  | 'long_answer_essay'
  | 'unscramble'
  | 'form_in_parentheses'
  | 'combine_sentences'
  | 'active_passive'
  | 'error_correction'
  | 'letter_reorder'
  | 'inline_choice'
  | 'dialogue_response'
  | 'odd_one_out'
  | 'phonetic_pronunciation'
  | 'sentence_ordering'
  | 'picture_description'
  | 'translation'
  | 'definition_matching'
  | 'numerical_calculation';

export interface ExamOption {
  id: string; // 'a', 'b', 'c', 'd'
  text: string;
}

/** Source-image rectangle (px in rendered/OCR space, or PDF text-space pts). */
export interface BBox {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** Where a piece of parsed data physically came from in the original file. */
export interface ProvenanceRef {
  source: 'pdf_text' | 'ocr' | 'docx' | 'text';
  page?: number;
  bbox?: BBox;
  /** 'pdf' = PDF text-space (y from bottom), 'pixel' = rendered image pixels. */
  coordSpace?: 'pdf' | 'pixel';
  pageHeight?: number;
  pageWidth?: number;
  lineStart?: number;
  lineEnd?: number;
  ocrConfidence?: number;
}

export interface InvariantViolation {
  id: string;
  rule:
    | 'SEQ_NUMBER'
    | 'SECTION_MARKS'
    | 'MCQ_OPTIONS'
    | 'ANSWER_VALID'
    | 'MARK_VALUES'
    | 'EMPTY_STEM'
    | 'DUP_STEM'
    | 'MATCHING_BALANCE'
    | 'WORD_BANK';
  severity: 'error' | 'warning' | 'info';
  sectionRowId?: string;
  questionId?: string;
  message: string;
  suggestedFix?: string;
  autoFix?: 'renumber' | 'recalc_marks' | 'clear_invalid_answer' | 'snap_mark';
  isFixed?: boolean;
}

/** How the parser classified a source line (rule-table trace, #3/#10). */
export type LineKind =
  | 'header_field'
  | 'section_header'
  | 'question_start'
  | 'option_row'
  | 'instruction'
  | 'passage'
  | 'word_bank'
  | 'answer_key'
  | 'noise'
  | 'other';

/** Per-question "show your work" receipt (#10 Explain This Question). */
export interface QuestionReceipt {
  /** Inclusive source-line range (indices into parseTrace.lines). */
  lineStart: number;
  lineEnd: number;
  /** Rule ids that produced this question, in firing order. */
  ruleChain: string[];
  /** Alternative interpretations considered and rejected. */
  alternates?: { kind: string; ruleId: string; reason: string }[];
  /** 0-100 confidence contributed by the fired rules. */
  ruleConfidence: number;
}

/** Extraction Quality Score (#6): is the extracted text even parseable? */
export interface ExtractionQualityReport {
  score: number; // 0-100
  verdict: 'good' | 'fair' | 'poor';
  signals: Record<string, number>;
  reasons: string[];
  /** Which extraction strategy produced the text (cascade winner). */
  strategy?: string;
}

/** Aggregate verified/single/contested counts (#9 truth chips). */
export interface TrustSummary {
  computedAt: string;
  verified: number;
  single: number;
  contested: number;
  total: number;
  verifiedPct: number;
}

/** Rule-table parse trace (#3): the full line classification of the source. */
export interface ParseTraceSummary {
  lines: string[];
  rules: { id: string; name: string; kind: LineKind; hits: number; meanConfidence: number }[];
  /** True when the rule-table walk found nothing and the legacy regex ran. */
  fallbackUsed?: boolean;
}

/** Document-level receipt of one Jev judging pass (efficiency evidence). */
export interface JevJudgeReceipt {
  ranAt: string;
  backend: 'jev' | 'llm-fallback';
  model: string;
  /** How many questions received a fresh verdict (excludes cache hits). */
  judged: number;
  /** Served from the local IndexedDB judge cache — 0 tokens. */
  cacheHits: number;
  /** Skipped by selection (empty stem / already verified / not resolvable). */
  skipped: number;
  /** Actual HTTP/system judge calls made for this pass. */
  calls: number;
  /** Questions in the mid-band escalated to the 3-vote adjudicator. */
  escalated: number;
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  threshold: number;
  warnings?: string[];
}

export interface InvariantReport {
  ranAt: string;
  passed: number;
  total: number;
  violations: InvariantViolation[];
}

export interface ConsensusCheck {
  path: string; // e.g. 'A/q3/stem'
  a: string;
  b: string;
  agree: boolean;
  similarity: number;
}

export interface ConsensusReport {
  ranAt: string;
  method: string; // e.g. 'pdf_text_vs_ocr'
  agreementRate: number; // 0-100
  disagreements: number;
  checks: ConsensusCheck[];
}

export interface TokenUsage {
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
}

export interface AIUsageReceipt {
  ranAt: string;
  requests: number;
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  /** Estimated tokens a naive "send everything to the AI" pipeline would burn. */
  baselineTokens: number;
  savedPct: number;
  heuristicSolved: number;
  cacheHits: number;
  aiSolved: number;
}

/** One AI-proposed edit awaiting human review (redline diff). */
export interface AnswerChange {
  id: string;
  questionId: string;
  sectionRowId?: string;
  questionNumber?: number | string;
  stem?: string;
  field: 'correctAnswer' | 'type';
  before: string;
  after: string;
  method: 'ai' | 'heuristic' | 'cache';
  status: 'pending' | 'approved' | 'rejected';
  decidedAt?: string;
}

export interface ReviewState {
  changes: AnswerChange[];
  updatedAt: string;
}

export interface MatchingPair {
  leftNumber: number | string;
  leftText: string;
  rightKey?: string; // e.g. 'c'
  rightText?: string;
}

/**
 * Jev judge verdict (A: judge-only protocol). Jev never writes answers —
 * it only evaluates what the offline parser + adjudicator already produced.
 * Shape mirrors TypeSafe's typed primitives: Noul (P(true)), Choice (label),
 * Score (ordered scale). See JEV_NOTES.md for the research behind this.
 */
export interface JevJudgement {
  /** Choice answer — our QuestionType enum, as judged by Jev. */
  category?: QuestionType | string;
  /** Choice answer — skill area (Vocabulary/Grammar/Reading/Writing/Listening/General). */
  skillArea?: string;
  /** Noul answer — P(the proposed correctAnswer is correct), 0..1. */
  pCorrect?: number;
  /** Score answer — well-formedness of the extracted question, 0..levels-1. */
  quality?: number;
  qualityConfidence?: number;
  /** Confidence-cascade outcome (act / review / ignore bands). */
  verdict: 'correct' | 'incorrect' | 'uncertain';
  judgedAt: string;
  model: string;
  /** Which backend produced it: native TypeSafe API or the LLM fallback. */
  backend: 'jev' | 'llm-fallback';
  /** Content fingerprint of (stem + options + correctAnswer) at judging time. */
  fingerprint?: string;
  /** True when served from the local IndexedDB judge cache (0 tokens). */
  cached?: boolean;
  /** Raw choice distribution for the category question (when native). */
  probabilities?: Record<string, number>;
}

/**
 * Parse-verification verdict — Jev true/false adjudication of the PARSE itself
 * (NOT the answers; that is JevJudgement). The user-approved consensus flow:
 *
 *   parser-first-pass-true ("first round true")  ∧  JEV true on every axis
 *     → 'accepted'  — safe, auto-accepted, no further AI needed
 *   ANY axis false or uncertain (both disagree, or just one)
 *     → 'flagged'   — human or AI validation REQUIRED before trusting it
 *   verification unavailable / no verdict returned
 *     → 'unverified' — never blocks the offline parse, never fakes confidence
 *
 * Fail-safe invariants:
 *   • Verification NEVER mutates stems/options/answers — it only attaches evidence.
 *   • A missing verdict is treated as UNVERIFIED, never as accepted.
 *   • suggestedType is advisory only; nothing is auto-applied.
 */
export interface ParseVerdict {
  /** JEV: the parsed question TYPE is right (it really is an MCQ, not short_answer, ...). */
  typeOk: boolean;
  /** JEV: the question is correctly SEPARATED — exactly one question, no neighbor text merged in, not split in two. */
  separationOk: boolean;
  /** JEV: metadata is right — number, mark, options, word-bank membership, passage association. */
  metadataOk: boolean;
  /** Consensus-gate outcome over the three axes. */
  verdict: 'accepted' | 'flagged' | 'unverified';
  /** Short human reason — present ONLY when flagged (token-light output contract). */
  note?: string;
  /** Advisory type suggestion when typeOk is false — NEVER auto-applied to the document. */
  suggestedType?: string;
  /** True when a human accepted/overrode this verdict in the validation queue. */
  humanReviewed?: boolean;
  checkedAt: string;
  model: string;
  backend: 'jev' | 'llm-fallback';
  /** Content fingerprint of the verified parse shape at checking time. */
  fingerprint?: string;
  /** True when served from the local IndexedDB verdict cache (0 tokens). */
  cached?: boolean;
}

/** Document-level receipt of one parse-verification pass (efficiency evidence). */
export interface ParseVerifyReceipt {
  ranAt: string;
  backend: 'jev' | 'llm-fallback';
  model: string;
  /** Questions that carried a verdict (fresh or cached). */
  questionsChecked: number;
  /** Two-phase check: image-dependent questions skipped in pass 1 (awaiting image alt). */
  imgPending?: number;
  /** Served from the local verdict cache — 0 tokens. */
  cacheHits: number;
  /** Actual HTTP judge calls made for this pass (contract: 1 for a fresh sheet). */
  calls: number;
  accepted: number;
  flagged: number;
  unverified: number;
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  /** Size of the raw source text shipped as ground truth for the check. */
  sourceChars: number;
  /** M2: bucket-A items the judge answered via the `a:` Choice axis this pass. */
  answersProduced?: number;
  /** M2: bucket-A picks served from the pick cache (0 tokens). */
  answersFromCache?: number;
  warnings?: string[];
}

/** How a question's answer was obtained (legacy solve-path metadata). */
// (answerMeta on QuestionItem below)

/**
 * A produced answer draft (M2 answer flow). An answer is NEVER silently
 * committed: it lands on QuestionItem.answer as a DRAFT with provenance and
 * only reaches correctAnswer through an explicit accept (human review, or the
 * calibration-gated auto-accept policy — see IMPLEMENTATION_PLAN §6).
 *
 * Provenance chain (strongest first):
 *   official (parsed printed key) > human > jev-verified-draft > ai-draft > heuristic
 *   - 'official'          — the answer key PRINTED ON THE SHEET itself (the
 *                           exam author's own answers — not an AI product at
 *                           all; see utils/answerKey.ts).
 *   - 'ai-draft'          — produced by ONE model, unverified (R1 a: pick, or
 *                          the R3 producer before the critic ran).
 *   - 'jev-verified-draft' — produced by the R3 text LLM AND agreeing with the
 *                          independent Jev critic (model diversity). Never the
 *                          work of a single model alone.
 */
export interface ProducedAnswer {
  value: string;
  /** Which stage produced it: R1 whole-sheet Choice, the R3 last call, or the printed key. */
  source: 'r1' | 'r3' | 'key';
  provenance: 'official' | 'jev-verified-draft' | 'ai-draft';
  /** True only for cross-model-verified drafts. */
  jevVerified: boolean;
  producedAt: string;
  model?: string;
}

/**
 * Producer-critic disagreement awaiting a HUMAN decision (M2 mediation).
 * Both answers are shown side-by-side; the human picks or writes their own.
 * status 'resolved-*' records which side won; 'resolved-human' stores the
 * human's own value in `humanValue`.
 */
export interface AnswerMediation {
  aiAnswer: string;
  jevAnswer?: string;
  status: 'pending' | 'resolved-ai' | 'resolved-jev' | 'resolved-human';
  humanValue?: string;
  decidedAt?: string;
}

export interface QuestionItem {
  id: string;
  number: number | string;
  displayNumber: string;
  originalNumber?: number | string;
  sectionRowId: string; // e.g. 'A', 'B', 'D', 'P', 'Q'
  sectionName: string; // 'Listening', 'Vocabulary', 'Grammar', 'Writing', 'Reading'
  type: QuestionType;
  typeEnName?: string; // e.g. "Multiple Choice (MCQ)", "Word Bank Fill"
  typeFaName?: string; // e.g. "چهار گزینه‌ای (تستی)", "جای خالی با جعبه واژگان"
  stem: string;
  persianInstruction?: string;
  englishInstruction?: string;
  options?: ExamOption[];
  correctAnswer?: string;
  mark: number;
  // Parent links & Context
  parentContextType?: 'word_bank' | 'cloze_passage' | 'reading_passage' | 'matching_table' | 'image_prompt' | 'dialogue_context' | 'listening_audio' | 'none';
  parentContextTitle?: string;
  parentContextText?: string;
  wordBankWords?: string[]; // Candidate words from box available to this question
  /**
   * Reliable task subtype for open-answer items whose TYPE alone undersells
   * the task — e.g. 'dictation' (partial-word completion: "p—ram---ds" →
   * "pyramids") on short_answer items. Advisory metadata: never changes the
   * QuestionType contract, exported with the question for filters/Jev context.
   */
  taskType?: string;
  // Match-specific
  matchingPairs?: MatchingPair[];
  matchingDistractors?: string[];
  // Attached Images
  hasImage?: boolean;
  imageUrl?: string;
  imageFileName?: string;
  imageCaption?: string;
  // Anomaly warnings
  anomalies?: string[];
  reviewed?: boolean;
  // Physical provenance (X-ray viewer & trust reports)
  provenance?: ProvenanceRef;
  // How this question's answer was obtained
  answerMeta?: { method: 'heuristic' | 'ai' | 'cache' | 'human' | 'official'; confidence?: number };
  // "Show your work" receipt (#10): source lines + rules that built this question
  receipt?: QuestionReceipt;
  // Truth chip level (#9): computed by trustEngine
  trustLevel?: 'verified' | 'single' | 'contested';
  // Jev judge verdict (judge-only; never authors content)
  jev?: JevJudgement;
  // Jev parse-verification verdict (consensus gate over the parse itself)
  parseVerdict?: ParseVerdict;
  // M2 answer flow: the current answer DRAFT (never auto-committed — see
  // ProducedAnswer). correctAnswer only changes via explicit accept.
  answer?: ProducedAnswer;
  // M2 producer-critic disagreement awaiting human mediation.
  answerMediation?: AnswerMediation;
  // M3 lesson/difficulty attribution (AI signals, human-editable evidence).
  attribution?: LessonAttribution;
  // M3 deterministic difficulty score computed from the signals + weights.
  difficulty?: DifficultyScore;
  /**
   * Two-phase Jev check: true = this question depends on an image whose
   * alt/transcription is NOT in yet, so it was skipped by the FIRST Jev pass
   * ("unchecked / awaiting image alt"). Cleared when a vision alt is attached.
   * Tracking the flag per question is what guarantees no question is ever sent
   * to Jev twice for the same content (pass 2 covers ONLY these).
   */
  imgPending?: boolean;
}

/**
 * One image understood by the vision pipeline (Idea 3): an embedded picture
 * (docx media / PDF image XObject) or a rendered page (scanned exams).
 * The vision result is human-reviewable BY DESIGN — alt and placement are
 * editable in the review editor, and low-confidence placements are queued,
 * never silently committed.
 */
export interface ExamImage {
  /** Stable per-document id: img-1, img-2, ... (reused across re-runs by contentHash). */
  id: string;
  /** SHA-256 (hex) of the ORIGINAL image bytes / page render — the vision cache key. */
  contentHash: string;
  origin: 'docx_media' | 'pdf_embedded' | 'page';
  page?: number;
  /** Position evidence: docx = paragraph index of the drawing anchor; pdf = reading-order rank. */
  anchorIndex?: number;
  /** PDF image bounding box (PDF text-space) for position-based placement. */
  bbox?: BBox;
  /** Text immediately around the image in the source (placement + prompt context). */
  contextText?: string;
  /** Alt text / description already present in the FILE (docx wp:docPr descr) — read the document around the bytes first. */
  embeddedAlt?: string;
  /** Small data-URL thumbnail for the review UI (not exported). */
  thumbnail?: string;
  // ---- vision result ----
  /** Transcription (text-bearing images) or one-line description (photos). */
  alt?: string;
  kind?: 'text' | 'photo' | 'diagram' | 'unknown';
  /** Model-reported confidence 0..1 for the alt itself. */
  confidence?: number;
  // ---- placement ----
  questionId?: string;
  placementConfidence?: number;
  /** auto = placed with confidence; review = below threshold, queued; manual = human-decided; unplaced. */
  placementStatus?: 'auto' | 'review' | 'manual' | 'unplaced';
  // ---- provenance of THIS record ----
  /** True when the vision result came from the content-hash cache (0 tokens). */
  cached?: boolean;
  /** Human has seen/edited this image's result. */
  reviewed?: boolean;
  /** Per-image failure (fail-soft: one bad image never blocks the batch). */
  error?: string;
  model?: string;
}

/** Document-level receipt of one vision pass (Path A alts or Path B transcription). */
export interface VisionReceipt {
  ranAt: string;
  /** 'alts' = embedded-image batch; 'transcribe' = scanned-page transcription. */
  mode: 'alts' | 'transcribe';
  provider: string;
  model: string;
  /** Images/pages actually sent to the provider (cache hits excluded). */
  sent: number;
  /** Served from the content-hash vision cache — 0 tokens, no wire call. */
  cacheHits: number;
  /** Wire calls made (Path A contract: 1 batched call per exam for alts). */
  calls: number;
  placed: number;
  needsReview: number;
  unplaced: number;
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  /** Estimated tokens a naive per-image pipeline would have burned. */
  baselineTokens?: number;
  warnings?: string[];
  error?: string;
}

/** Advisory evidence from the mined template layer (Idea 2) — NEVER a stamp. */
export interface TemplateHint {
  templateId: string;
  suggestsType: string;
  suggestsCategory?: string;
  score: number;
}

export interface ExamSection {
  rowId: string; // 'A', 'B', 'C', 'D' ... 'Q'
  majorCategory: 'Listening' | 'Vocabulary' | 'Grammar' | 'Writing' | 'Reading' | 'General';
  title?: string;
  persianInstruction?: string;
  englishInstruction?: string;
  markTotal: number;
  questions: QuestionItem[];
  // Shared context in this section
  hasWordBank?: boolean;
  wordBank?: string[];
  hasPassage?: boolean;
  passageTitle?: string;
  passageText?: string;
  matchingColumns?: {
    columnA: { id: string | number; text: string }[];
    columnB: { id: string; text: string }[];
  };
  /** Mined-template evidence (advisory only — see utils/sectionTemplates.ts). */
  templateHints?: TemplateHint[];
}

export interface ExamHeader {
  courseName: string; // e.g. "زبان انگلیسی"
  teacherName?: string;
  durationMinutes: number; // 80
  examDate: string; // "03/10/17"
  schoolName: string; // "دبیرستان پسرانه شریعتی"
  district: string; // "اداره آموزش و پرورش خارگ - بوشهر"
  gradeAndMajor: string; // "مقطع و رشته: دوازدهم"
  pageCount: number; // 5
  grade?: string; // e.g., "Grade 9"
  term?: string;  // e.g., "First Term"
  examName?: string; // Inferred by AI
}

export interface ParsingAnomaly {
  id: string;
  severity: 'warning' | 'info' | 'error';
  sectionRowId: string;
  questionNumber?: number | string;
  title: string;
  description: string;
  suggestedFix: string;
  isResolved?: boolean;
}

export interface ExamDocument {
  id: string;
  filename: string;
  filesize?: string;
  parsedAt: string;
  /** Bump when a migration changes the shape; see utils/migrations.ts. */
  schemaVersion?: number;
  header: ExamHeader;
  sections: ExamSection[];
  totalQuestions: number;
  totalMarks: number;
  anomalies: ParsingAnomaly[];
  confidenceScore: number; // e.g. 98.4
  needsReview?: boolean;
  validationFlags?: string[];
  // 2-Stage Pipeline Tracking
  parseStage?: 'stage1_offline_unsolved' | 'stage2_ai_solved';
  solvedAt?: string;
  isAiSolved?: boolean;
  // === Trust architecture ===
  /** Original uploaded file (Blob) kept for the X-ray overlay & consensus. Not exported. */
  sourceFile?: Blob;
  /** % of questions that carry physical provenance. */
  provenanceCoverage?: number;
  invariants?: InvariantReport;
  consensus?: ConsensusReport;
  aiUsage?: AIUsageReceipt;
  /** AI-proposed edits awaiting/after human redline review. */
  review?: ReviewState;
  /** Mirror-variant bookkeeping */
  mirrorOf?: string;
  mirrorVariant?: string;
  // === Bulletproofing round ===
  /** Extraction Quality Score (#6) + winning strategy of the cascade. */
  extraction?: ExtractionQualityReport;
  /** Aggregated verified/single/contested truth summary (#9). */
  trust?: TrustSummary;
  /** Rule-table trace (#3): source lines + rule statistics for Explain receipts. */
  parseTrace?: ParseTraceSummary;
  /** Layout-brain verdict (#geometry): cross-checked geometry separation the
   *  parser used (or partially used) for this document. Uncertainty is part
   *  of the report — the UI surfaces it, it never hides it. */
  brainReport?: import('../utils/brainBridge').BrainReportSummary;
  /** Last Jev judging pass receipt (judge-only protocol). */
  jevReceipt?: JevJudgeReceipt;
  /** Last parse-verification pass receipt (consensus gate over the parse). */
  parseVerifyReceipt?: ParseVerifyReceipt;
  /**
   * Minimal offline OCR of the pictures embedded in the source file (docx
   * word/media/*, extracted fail-soft). NEVER part of the parse input — the
   * line-based parser would spawn phantom questions. Consumed only by the
   * Jev parse verification, which appends them to the raw source the judge
   * reads (user-approved flow: "along with offline simple OCR of the pics").
   */
  pictureOcrNotes?: string[];
  /**
   * Vision-understood images (embedded pictures + scanned-page renders),
   * cached by content hash and always human-reviewable. See ExamImage.
   */
  images?: ExamImage[];
  /** Last vision pass receipt (alts or transcription). */
  visionReceipt?: VisionReceipt;
  /** Last answer-production pass receipt (R1 a: picks + R3 producer-critic). */
  answerFlowReceipt?: AnswerFlowReceipt;
  /**
   * Answer key PRINTED ON THE SHEET (deterministic offline detection at parse
   * time — see utils/answerKey.ts). When present: the key's rows are METADATA
   * (never questions), its answers are attached with official provenance, and
   * the AI answer-production flow skips answer generation entirely (Jev still
   * verifies separation + metadata; the key mapping is validated locally).
   */
  answerKeyOnFile?: AnswerKeyReport;
}

// ---------- answer key on file (printed-key mode) ----------

/** One parsed key entry: question number -> option label as printed. */
export interface AnswerKeyEntry {
  number: number;
  /** The raw label as printed: الف/ب/پ/ت/ث/ج, a digit, or صحیح/غلط. */
  label: string;
  /** Resolved 0-based option index when the label maps to one. */
  optionIndex?: number;
  /** Resolved answer text when the entry was applied to a question. */
  optionText?: string;
}

export interface AnswerKeyWarning {
  type:
    | 'orphan-entry'        // key number with no matching question
    | 'ambiguous-number'    // number matches several questions (section restart) — never guessed
    | 'invalid-option'      // option label out of range for the question's options
    | 'unmapped-type'       // entry targets a non-MCQ/non-TF question (free-text key not supported yet)
    | 'duplicate-entry'     // the same question number keyed twice — first wins
    | 'skipped-existing'    // question already answered by human/official — not overwritten
    | 'uncovered-questions'; // summary: N answerable questions have no key entry
  message: string;
  questionNumber?: number;
}

export interface AnswerKeyReport {
  detected: true;
  source: 'on-file';
  /** Which detection signal fired (banner corroborated or pure-pattern run). */
  via: 'banner' | 'pattern';
  /** How many key rows were removed from the question list (they are metadata now). */
  removedQuestions: number;
  entries: AnswerKeyEntry[];
  applied: number;
  warnings: AnswerKeyWarning[];
  appliedAt: string;
}

/** Document-level receipt of one answer-production pass (M2). */
export interface AnswerFlowReceipt {
  ranAt: string;
  model: string;
  /** R1 Choice picks produced by the whole-sheet judge call. */
  r1Picks: number;
  /** R3 producer answers (short answers from the text LLM). */
  r3Produced: number;
  /** R3 answers the Jev critic AGREED with → jev-verified drafts. */
  r3Agreed: number;
  /** R3 disagreements queued for human mediation. */
  r3Mediated: number;
  /** Producer answers served from the local answer cache — 0 tokens. */
  cacheHits: number;
  producerCalls: number;
  criticCalls: number;
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  warnings?: string[];
}

/**
 * M3 lesson/difficulty attribution — AI SIGNALS attached as evidence (drafts,
 * human-editable, never auto-committed into anything). `supportFlag` is set by
 * the deterministic keyword cross-check when the picked lesson shows near-zero
 * keyword support in the question text — a strong wrong-attribution signal.
 */
export interface LessonAttribution {
  lesson1?: string;
  lesson2?: string;
  inBook?: 'in-book' | 'mixed' | 'out-of-book';
  cognitive?: 'recall' | 'comprehension' | 'application';
  supportFlag?: boolean;
  digestVersion?: string;
  attributedAt?: string;
  model?: string;
}

/** M3 computed difficulty — deterministic over signals + weights. */
export interface DifficultyScore {
  score: number;
  band: 'easy' | 'medium' | 'hard';
  factors: { id: string; label: string; points: number }[];
  weightsVersion: string;
  computedAt: string;
}

/** M4 §6: one measured calibration cell (kind × cognitive level). */
export interface CalibrationCategory {
  category: string;
  n: number;
  correct: number;
  accuracy: number;
  autoAcceptable: boolean;
}

/** M4 §6: the measured, version-bound calibration report. */
export interface CalibrationReport {
  ranAt: string;
  digestVersion: string;
  weightsVersion: string;
  promptVersion: string;
  threshold: number;
  minCell: number;
  categories: CalibrationCategory[];
}
