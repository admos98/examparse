export type AIProvider = 'gemini' | 'openai' | 'openrouter' | 'vercel' | 'ollama' | 'custom';

export interface ProviderConfig {
  provider: AIProvider;
  baseURL?: string;
  apiKey?: string;
  model: string;
  temperature: number;
  maxTokens: number;
  /** Wire timeout per AI call (ms). Default: env AI_TIMEOUT_MS > 120000.
   *  A hung provider aborts here instead of stalling the flow forever. */
  timeoutMs?: number;
  /** Bounded in-place retries on 429/5xx/retryable network faults
   *  (exponential backoff, Retry-After honored). Default 2; diagnostic
   *  pings (maxAttempts: 1) never retry. */
  wireRetries?: number;
}

export const DEFAULT_PROVIDER_CONFIG: ProviderConfig = {
  provider: 'gemini',
  baseURL: '',
  apiKey: '',
  model: 'gemini-2.5-flash',
  temperature: 0.2,
  maxTokens: 8192,
};

export const PROVIDER_DEFAULT_BASE_URLS: Record<AIProvider, string> = {
  gemini: '',
  openai: 'https://api.openai.com/v1',
  openrouter: 'https://openrouter.ai/api/v1',
  vercel: 'https://ai-gateway.vercel.sh/v1',
  ollama: 'http://localhost:11434/v1',
  custom: 'https://api.example.com/v1',
};

export const PROVIDER_DEFAULT_MODELS: Record<AIProvider, string> = {
  gemini: 'gemini-2.5-flash',
  openai: 'gpt-4o-mini',
  openrouter: 'deepseek/deepseek-chat',
  vercel: 'openai/gpt-4o-mini',
  ollama: 'llama3:latest',
  custom: 'gpt-4o-mini',
};

/**
 * Jev judge configuration (judge-ONLY protocol — Jev never authors answers).
 * Both default base URLs expose the identical verified System One request
 * shape (see JEV_NOTES.md §4): POST {base}/systemone with
 * {state, model, questions:{type:'noul'|'choice'|'score', instructions, criteria}}.
 */
export interface JevConfig {
  enabled: boolean;
  /** Verified native endpoints: TypeSafe direct or OpenRouter (same shape). */
  baseUrl: string;
  /** TypeSafe or OpenRouter API key — client-side only, per-request, never persisted server-side. */
  apiKey: string;
  /** 'jev-latest' | 'jev-1.13.0' (TypeSafe) or 'typesafe/jev-1.13' (OpenRouter). */
  model: string;
  /** Accept 'correct' when pCorrect >= threshold (confidence cascade: act band). */
  threshold: number;
  /** Accept 'incorrect' when pCorrect <= lowBand (default 0.2); between = uncertain → escalate. */
  lowBand: number;
  /** Questions bundled into ONE judge call (state is shared; questions run in parallel). */
  batchSize: number;
  /** Also ask the optional Score question (extracted-question well-formedness). */
  judgeQuality: boolean;
  /** Auto-escalate mid-band (uncertain) questions to the 3-vote /api/adjudicate path. */
  autoEscalate: boolean;
}

export const DEFAULT_JEV_CONFIG: JevConfig = {
  enabled: false,
  baseUrl: 'https://openrouter.ai/api/v1',
  apiKey: '',
  model: 'typesafe/jev-1.13',
  threshold: 0.9,
  lowBand: 0.2,
  batchSize: 20,
  judgeQuality: true,
  autoEscalate: true,
};

export const JEV_BASE_URLS = {
  typesafe: 'https://api.typesafe.ai/v1',
  openrouter: 'https://openrouter.ai/api/v1',
} as const;

export const JEV_DEFAULT_MODELS = {
  typesafe: 'jev-latest',
  openrouter: 'typesafe/jev-1.13',
} as const;

/**
 * Vision (image understanding) configuration — Path A (embedded pictures) and
 * Path B (scanned-page transcription). Vision calls are ALWAYS opt-in (explicit
 * button); this config only remembers HOW to call the provider when the user
 * asks for it. Keys are never stored here — the vision call reuses the same
 * client-side provider key the rest of the app sends per-request.
 */
export interface VisionConfig {
  /** Remember the user's opt-in choice for the "run again" affordance. Calls themselves stay manual. */
  enabled: boolean;
  provider: AIProvider;
  baseURL?: string;
  /** Vision-capable model (Gemini native / OpenAI-compatible — user-configurable in Settings). */
  model: string;
  maxTokens: number;
  /** Downscale target (long edge px) for text-bearing images (labeled diagrams, screenshots). */
  textImagePx: number;
  /** Downscale target for pure photos (aggressive — no text to keep legible). */
  photoImagePx: number;
  /** JPEG quality (0..1) for the payload. */
  jpegQuality: number;
  /** Max images per batched exam call (payload + answer-map safety). */
  maxImagesPerCall: number;
  /** Total base64 payload cap per call, bytes (soft — oversized batches split). */
  maxPayloadBytes: number;
  /** Positional confidence at/above this → auto-place; below → review queue only. */
  placementThreshold: number;
  /** Render scale for scanned-page transcription. */
  pageRenderScale: number;
}

export const DEFAULT_VISION_CONFIG: VisionConfig = {
  enabled: false,
  provider: 'gemini',
  baseURL: '',
  model: 'gemini-2.5-flash',
  maxTokens: 4096,
  textImagePx: 1024,
  photoImagePx: 512,
  jpegQuality: 0.7,
  maxImagesPerCall: 12,
  maxPayloadBytes: 8 * 1024 * 1024,
  placementThreshold: 0.7,
  pageRenderScale: 2.0,
};
