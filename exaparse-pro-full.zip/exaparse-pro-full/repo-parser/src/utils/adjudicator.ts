import { ExamDocument, QuestionItem, AnswerChange } from '../types/exam';

/**
 * AI Adjudicator (#14/#15) — the AI never writes exam content.
 *
 * The client collects CONTESTED cells (per trustEngine), the server asks the
 * model THREE times (varied temperature) with a strict enum protocol, and a
 * deterministic applier merges only VERDICTS THAT ARE VALID for the question
 * shape (option key ∈ options, word ∈ word bank). Invalid or non-unanimous
 * verdicts never touch the document — they stay contested for a human.
 */

export interface AdjudicationCell {
  questionId: string;
  sectionRowId: string;
  number: number | string;
  type: QuestionItem['type'];
  stem: string;
  optionKeys?: string[];
  wordBankWords?: string[];
  passageSnippet?: string;
}

export interface AdjudicationVerdict {
  questionId: string;
  answer: string;
  votes: string[];
  agreement: 'unanimous' | 'majority' | 'none';
  applied: boolean;
  reason?: string;
}

/** Collect the questions worth adjudicating: contested trust level, no answer yet, resolvable shape. */
export function collectContestedCells(doc: ExamDocument): AdjudicationCell[] {
  const cells: AdjudicationCell[] = [];
  for (const sec of doc.sections) {
    for (const q of sec.questions) {
      const resolvable =
        (q.type === 'multiple_choice' || q.type === 'cloze_item' || q.type === 'inline_choice') && q.options && q.options.length >= 2
          ? true
          : q.type === 'word_bank_fill' && (q.wordBankWords?.length || sec.wordBank?.length)
            ? true
            : false;
      if (!resolvable) continue;
      const alreadyAnswered = !!(q.correctAnswer && q.correctAnswer.trim());
      const contested = q.trustLevel === 'contested' || q.trustLevel === 'single';
      if (alreadyAnswered || !contested) continue;
      cells.push({
        questionId: q.id,
        sectionRowId: sec.rowId,
        number: q.displayNumber,
        type: q.type,
        stem: q.stem,
        optionKeys: q.options?.map((o) => o.id),
        wordBankWords: q.wordBankWords || sec.wordBank,
        passageSnippet: q.parentContextText?.slice(0, 300),
      });
    }
  }
  return cells;
}

/**
 * Deterministic applier: ONLY valid verdicts are applied, and every applied
 * verdict becomes a redline AnswerChange (pending review) — the AI proposes,
 * the human disposes (#14).
 */
export function applyAdjudication(
  doc: ExamDocument,
  verdicts: AdjudicationVerdict[],
): { doc: ExamDocument; changes: AnswerChange[] } {
  const byId = new Map(verdicts.map((v) => [v.questionId, v]));
  const changes: AnswerChange[] = [];

  const sections = doc.sections.map((sec) => ({
    ...sec,
    questions: sec.questions.map((q): QuestionItem => {
      const v = byId.get(q.id);
      if (!v || !v.applied) return q;
      changes.push({
        id: `chg-${q.id}-adjudicate`,
        questionId: q.id,
        sectionRowId: sec.rowId,
        questionNumber: q.displayNumber,
        stem: q.stem.slice(0, 140),
        field: 'correctAnswer',
        before: q.correctAnswer || '',
        after: v.answer,
        method: 'ai',
        status: 'pending',
      });
      return {
        ...q,
        correctAnswer: v.answer,
        answerMeta: { method: 'ai', confidence: v.agreement === 'unanimous' ? 0.99 : 0.8 },
      };
    }),
  }));

  return { doc: { ...doc, sections }, changes };
}
