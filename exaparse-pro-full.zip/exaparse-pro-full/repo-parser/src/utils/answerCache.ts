import { ExamOption, QuestionItem } from '../types/exam';
import { kvCount, kvGet, kvGetMany, kvSet } from './localStore';

/**
 * Semantic answer cache — exams (especially in the same school/district) repeat
 * heavily year over year. A solved question is fingerprinted by its normalized
 * stem + choices, so the next occurrence is answered instantly, for free.
 * 100% local (IndexedDB), privacy-safe.
 */

const PREFIX = 'ac:';

export function normalizeForFingerprint(text: string): string {
  return (text || '')
    .toLowerCase()
    // unify Persian/Arabic ye & kaf variants
    .replace(/\u064A/g, '\u06CC')
    .replace(/\u0643/g, '\u06A9')
    // strip diacritics
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function answerFingerprint(type: string, stem: string, options?: ExamOption[]): string {
  const parts = [type, normalizeForFingerprint(stem)];
  if (options && options.length > 0) {
    parts.push(options.map((o) => normalizeForFingerprint(o.text)).join('|'));
  }
  // Cheap non-crypto hash (djb2) — collisions handled by storing the key too.
  const raw = parts.join('::');
  let h = 5381;
  for (let i = 0; i < raw.length; i++) {
    h = ((h << 5) + h + raw.charCodeAt(i)) | 0;
  }
  return `${PREFIX}${type}:${(h >>> 0).toString(36)}`;
}

export interface CachedAnswer {
  answer: string;
  type?: string;
  ts: number;
}

export async function cacheGet(fingerprint: string): Promise<CachedAnswer | undefined> {
  return kvGet<CachedAnswer>(fingerprint);
}

export async function cacheGetMany(fingerprints: string[]): Promise<Map<string, CachedAnswer>> {
  return kvGetMany<CachedAnswer>(fingerprints);
}

export async function cachePut(fingerprint: string, answer: string, type?: string): Promise<void> {
  if (!answer || !answer.trim()) return;
  await kvSet(fingerprint, { answer: answer.trim(), type, ts: Date.now() } satisfies CachedAnswer);
}

export async function cachePutMany(entries: { fingerprint: string; answer: string; type?: string }[]): Promise<void> {
  await Promise.all(entries.map((e) => cachePut(e.fingerprint, e.answer, e.type)));
}

/** Fingerprint every question of a document (client-side pre-lookup helper). */
export function fingerprintsForDocument(questions: QuestionItem[]): Map<string, string> {
  const map = new Map<string, string>(); // questionId -> fingerprint
  for (const q of questions) {
    map.set(q.id, answerFingerprint(q.type, q.stem, q.options));
  }
  return map;
}

export async function cacheSize(): Promise<number> {
  const all = await kvCount();
  return all; // approx (KV shared with other features)
}
