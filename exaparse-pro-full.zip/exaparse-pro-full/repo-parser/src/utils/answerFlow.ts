import { AnswerMediation, ExamDocument, ProducedAnswer, QuestionItem } from '../types/exam';

/**
 * M2 answer flow — deterministic bucket routing + immutable answer application.
 *
 * Three-bucket routing (the agreed complete flow):
 *   A = text-complete with an extractable candidate set (MCQ options, word-bank
 *       words, true/false)  -> R1 answers it via the `a:` Choice axis.
 *   B = text-complete free-text short answer (form-in-parentheses, unscramble,
 *       translation, ...)   -> R1 verifies axes only; R3 producer-critic answers.
 *   C = image-dependent without vision alt yet (imgPending / no caption)
 *                           -> skipped in R1; R3 answers AFTER the image pass.
 * Essays (long_answer_essay) are NEVER machine-answered — they are excluded
 * from production entirely and stay human-only.
 *
 * Nothing here mutates a document. Drafts attach to QuestionItem.answer with
 * provenance; correctAnswer only moves via the explicit accept functions.
 */

export type AnswerBucket = 'A' | 'B' | 'C';

const OPTION_KEY_ORDER = ['a', 'b', 'c', 'd', 'e', 'f'];

/** True when this question's answer must never be machine-produced. */
export function isHumanOnly(q: QuestionItem): boolean {
  return q.type === 'long_answer_essay';
}

/**
 * Deterministic bucket classification. Pure — no heuristics beyond the
 * structural facts already extracted by the parser.
 */
export function classifyBucket(q: QuestionItem): AnswerBucket {
  // C first: an image-dependent question without its authoritative text
  // (vision alt/transcription) is not text-complete yet.
  if (q.imgPending) return 'C';
  if (q.hasImage && !q.imageCaption) return 'C';
  // Essays are excluded from machine answering (see isHumanOnly) but they are
  // structurally bucket B — the caller filters them out explicitly.
  if (hasSelectableCandidates(q)) return 'A';
  return 'B';
}

/** Does the question carry its own candidate set the judge can pick from? */
export function hasSelectableCandidates(q: QuestionItem): boolean {
  if (q.options && q.options.length > 0) return true;
  if (q.type === 'true_false') return true;
  if (q.wordBankWords && q.wordBankWords.length > 0) return true;
  return false;
}

/**
 * The Choice criteria for the `a:` answer axis: label -> candidate text.
 *   MCQ / inline choice: the item's own option keys ('a'..'d').
 *   True/false: the fixed pair { true, false }.
 *   Word-bank fill: the SCOPED words for this item, indexed '1'..'n'
 *   (a section-level bank must never widen the candidate set).
 * Returns null for bucket-B items (no candidate set exists).
 */
export function bucketACandidates(q: QuestionItem): Record<string, string> | null {
  if (q.options && q.options.length > 0) {
    const out: Record<string, string> = {};
    for (const o of q.options) {
      const key = OPTION_KEY_ORDER.includes(o.id) ? o.id : o.id.toLowerCase();
      out[key] = o.text;
    }
    return out;
  }
  if (q.type === 'true_false') {
    return { true: 'True — the statement is correct.', false: 'False — the statement is incorrect.' };
  }
  if (q.wordBankWords && q.wordBankWords.length > 0) {
    const out: Record<string, string> = {};
    q.wordBankWords.forEach((w, i) => {
      out[String(i + 1)] = w;
    });
    return out;
  }
  return null;
}

/** All questions the R1 pass should attempt (bucket A, essays excluded). */
export function bucketAIds(doc: ExamDocument): string[] {
  const out: string[] = [];
  for (const sec of doc.sections) {
    for (const q of sec.questions) {
      if (isHumanOnly(q)) continue;
      if (classifyBucket(q) === 'A') out.push(q.id);
    }
  }
  return out;
}

/**
 * Questions the R3 producer-critic should attempt: bucket B free-text items +
 * bucket C items that HAVE their image alt now + any bucket-A straggler that
 * R1 left unanswered. Essays excluded. Every id is deduped.
 */
export function unresolvedProducerIds(doc: ExamDocument): string[] {
  const out: string[] = [];
  const seen = new Set<string>();
  for (const sec of doc.sections) {
    for (const q of sec.questions) {
      if (isHumanOnly(q)) continue;
      if (q.correctAnswer) continue; // already answered (official/human/accepted)
      const bucket = classifyBucket(q);
      if (bucket === 'C' && !q.imageCaption) continue; // still awaiting vision
      if (seen.has(q.id)) continue;
      seen.add(q.id);
      out.push(q.id);
    }
  }
  return out;
}

// ---------- immutable application ----------

/**
 * Attach a produced answer DRAFT to one question. Returns a NEW document.
 * NEVER touches correctAnswer — that is the explicit accept's job.
 * An existing draft is overwritten only by an equal-or-stronger provenance
 * (ai-draft < jev-verified-draft), so a late weaker result can't degrade one.
 */
const PROVENANCE_RANK: Record<ProducedAnswer['provenance'], number> = {
  'official': 3,
  'ai-draft': 1,
  'jev-verified-draft': 2,
};

export function attachProducedAnswer(doc: ExamDocument, questionId: string, answer: ProducedAnswer): ExamDocument {
  return {
    ...doc,
    sections: doc.sections.map((sec) => ({
      ...sec,
      questions: sec.questions.map((q) => {
        if (q.id !== questionId) return q;
        const prev = q.answer;
        if (prev && PROVENANCE_RANK[prev.provenance] > PROVENANCE_RANK[answer.provenance]) return q;
        return { ...q, answer };
      }),
    })),
  };
}

/**
 * Explicit accept (human decision in the review grid, or the calibration-
 * gated auto-accept): promote the draft into correctAnswer with provenance.
 * Guardrails: never overwrites a HUMAN-entered correctAnswer, and an empty
 * draft value is a no-op.
 */
export function acceptDraftAnswer(doc: ExamDocument, questionId: string): ExamDocument {
  return {
    ...doc,
    sections: doc.sections.map((sec) => ({
      ...sec,
      questions: sec.questions.map((q) => {
        if (q.id !== questionId) return q;
        const draft = q.answer;
        if (!draft || !draft.value) return q;
        if (q.answerMeta?.method === 'human') return q; // human already won
        return {
          ...q,
          correctAnswer: draft.value,
          answerMeta: { method: 'ai', confidence: undefined },
        };
      }),
    })),
  };
}

/** Record the human's mediation decision for one question. Immutable. */
export function resolveMediation(
  doc: ExamDocument,
  questionId: string,
  decision: 'ai' | 'jev' | 'human',
  humanValue?: string,
): ExamDocument {
  const status: AnswerMediation['status'] =
    decision === 'ai' ? 'resolved-ai' : decision === 'jev' ? 'resolved-jev' : 'resolved-human';
  return {
    ...doc,
    sections: doc.sections.map((sec) => ({
      ...sec,
      questions: sec.questions.map((q) => {
        if (q.id !== questionId) return q;
        const m = q.answerMediation;
        if (!m) return q;
        const next: AnswerMediation = { ...m, status, decidedAt: new Date().toISOString() };
        if (decision === 'human') next.humanValue = humanValue ?? '';
        return { ...q, answerMediation: next };
      }),
    })),
  };
}

/**
 * Apply a mediation decision end-to-end: resolve the pair AND (for ai/jev/
 * human values) write the winning value into correctAnswer as a HUMAN decision.
 */
export function applyMediationDecision(
  doc: ExamDocument,
  questionId: string,
  decision: 'ai' | 'jev' | 'human',
  humanValue?: string,
): ExamDocument {
  const target = doc.sections.flatMap((s) => s.questions).find((q) => q.id === questionId);
  if (!target) return doc;
  const winner =
    decision === 'ai'
      ? target.answerMediation?.aiAnswer
      : decision === 'jev'
        ? target.answerMediation?.jevAnswer
        : humanValue ?? '';
  const resolved = resolveMediation(doc, questionId, decision, humanValue);
  if (!winner) return resolved;
  return {
    ...resolved,
    sections: resolved.sections.map((sec) => ({
      ...sec,
      questions: sec.questions.map((q) => {
        if (q.id !== questionId) return q;
        if (q.answerMeta?.method === 'human') return q;
        return { ...q, correctAnswer: winner, answerMeta: { method: 'human', confidence: undefined } };
      }),
    })),
  };
}
