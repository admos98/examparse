import {
  AnswerKeyEntry,
  AnswerKeyReport,
  AnswerKeyWarning,
  ExamDocument,
  QuestionItem,
} from '../types/exam';

/**
 * answerKey.ts — answer key PRINTED ON THE SHEET (offline, deterministic).
 *
 * Many exam papers carry their own key (پاسخنامه / کلید) as a table of
 * number→option pairs. Left alone, the parser shreds those rows into phantom
 * questions ("1. ب" becomes a junk short_answer item) and the app then asks
 * AI models to re-derive answers that were printed on the paper all along.
 * This module runs INSIDE the parse pipeline and:
 *
 *   1. DETECT — the key region is the trailing run of key-like questions
 *      (bare option labels / pure number→label pair rows), corroborated by a
 *      پاسخنامه/کلید/answer-key banner (in a stem or in the raw parse-trace
 *      lines) or, banner-less, by a run of >= 3 pure pair rows at the very
 *      end. Conservative on purpose: real questions never look like pairs.
 *   2. SEPARATE — the key rows are REMOVED from the question list (strict
 *      metadata/question separation: the key is metadata, never questions).
 *   3. MAP + VALIDATE — each entry ("12.الف", "۱- ۳", "5 صحیح") maps onto the
 *      remaining question with that printed number. Every mismatch is a named
 *      warning (orphan / ambiguous / invalid-option / duplicate / unmapped);
 *      nothing is ever guessed. Applied MCQ answers store the OPTION ID
 *      ('a'..'d' — the app-wide MCQ contract: invariant ANSWER_VALID requires
 *      correctAnswer ∈ the question's option ids) with answerMeta.method
 *      'official' — ABOVE human and every AI draft rank. The printed option
 *      TEXT is preserved on the report entry (optionText) so review/export
 *      surfaces can still show exactly what the sheet printed.
 *
 *   4. The answer flow (App.handleRunAnswerFlow) then skips AI answer
 *      production for keyed questions: Jev still verifies separation +
 *      metadata, difficulty/attribution metrics run as usual, and the quick
 *      "did the app point the right answer at the right question" check IS
 *      the mapping validation here (warnings surface in Final Review).
 *
 * Pure functions only: no network, no AI, no mutation of the input document.
 */

/** Mirrors parserRules R02 (answer-key banner) — kept in sync by the gate. */
export const KEY_BANNER_RE =
  /(?:answer\s*key|key\s*answers?|پاسخنامه|کلید\s*آزمون|کلید\s*سوالات|کلید)/i;

const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';

/** Normalize Persian/Arabic-Indic digits to Latin for matching. */
export function normalizeKeyDigits(s: string): string {
  return s.replace(/[۰-۹٠-٩]/g, (d) => {
    const fa = FA_DIGITS.indexOf(d);
    return fa >= 0 ? String(fa) : String(AR_DIGITS.indexOf(d));
  });
}

/** Iranian MCQ option order: الف=1 ب=2 ج=3 د=4 (ه=5 for rare 5-option
 *  items) — the SAME order parserRules looksLikeOptionRow matches. */
const OPTION_LABELS: Record<string, number> = { الف: 0, ب: 1, ج: 2, د: 3, ه: 4 };
const TRUE_LABELS = new Set(['صحیح', 'درست']);
const FALSE_LABELS = new Set(['غلط', 'نادرست']);
const WORD_LABEL_RE = '(?:الف|ب|ج|د|ه|صحیح|درست|غلط|نادرست)';

/**
 * Number→word-label pair: separator OPTIONAL ("1.الف", "1 الف", "1-الف").
 * Word labels cannot be prefixes of numbers, so a loose separator is safe.
 */
const PAIR_WORD_RE = new RegExp(`(?<![0-9۰-۹٠-٩])(\\d{1,3})\\s*[.\\)\\-–—:]?\\s*(${WORD_LABEL_RE})`, 'g');
/**
 * Number→digit-label pair: separator REQUIRED ("1-3", "1.3", "1 3") so a
 * plain number like "10" can never split into pair (1, 0).
 */
const PAIR_DIGIT_RE = /(?<![0-9۰-۹٠-٩])(\d{1,3})[.\)\-–—:]\s*([1-9])(?![0-9۰-۹٠-٩])|(?<![0-9۰-۹٠-٩])(\d{1,3})\s+([1-9])(?![0-9۰-۹٠-٩])/g;

/** A stem that is ONLY key pairs / separators — the classic printed key row. */
export function looksLikeKeyRow(text: string): boolean {
  const t = normalizeKeyDigits(text).trim();
  if (!t) return false;
  const withoutPairs = t
    .replace(PAIR_WORD_RE, ' ')
    .replace(PAIR_DIGIT_RE, ' ')
    .replace(/[\s,;،؛.()\-–—:/|]+/g, '');
  return withoutPairs.length === 0;
}

/** A stem that is a single bare option/TF label (the row "1. ب" parses to "ب"). */
const BARE_LABEL_RE = new RegExp(`^(?:${WORD_LABEL_RE}|[1-9])$`);

/** Recover the PRINTED number: originalNumber, else the parse id's number
 *  component (q-<rowId>-<printed>-<line>), else the (possibly renumbered)
 *  question number. Renumbering never touches the id. */
function printedNumberOf(q: QuestionItem): number {
  if (q.originalNumber !== undefined) {
    const n = Number(normalizeKeyDigits(String(q.originalNumber)));
    if (Number.isFinite(n)) return n;
  }
  const m = /^q-[^-]*-(\d+)-\d+$/.exec(q.id || '');
  if (m) return Number(m[1]);
  const n = Number(normalizeKeyDigits(String(q.number ?? '')));
  return Number.isFinite(n) ? n : NaN;
}

function isKeyLike(q: QuestionItem): boolean {
  const stem = normalizeKeyDigits(q.stem || '').trim();
  if (!stem) return false;
  if (!(q.options && q.options.length > 0) && !q.hasImage) {
    if (looksLikeKeyRow(stem)) return true;
    if (BARE_LABEL_RE.test(stem)) return true;
  }
  return false;
}

export interface KeyRegion {
  questions: { q: QuestionItem; printed: number }[];
  via: 'banner' | 'pattern';
}

/**
 * The key region is the TRAILING consecutive run of key-like questions.
 * Banner corroboration widens acceptance to short runs (a 2-question key
 * after a banner is still a key); without a banner only a run of >= 3
 * qualifies. Returns null when no key region exists.
 */
export function findKeyRegion(doc: ExamDocument): KeyRegion | null {
  const flat = doc.sections.flatMap((s) => s.questions || []);
  if (flat.length === 0) return null;
  const run: QuestionItem[] = [];
  for (let i = flat.length - 1; i >= 0 && isKeyLike(flat[i]); i--) run.unshift(flat[i]);
  if (run.length === 0) return null;

  const bannerInStems = flat.some(
    (q) => KEY_BANNER_RE.test(q.stem || '') || KEY_BANNER_RE.test(q.persianInstruction || ''),
  );
  const bannerInTitles = doc.sections.some((s) => KEY_BANNER_RE.test(s.title || ''));
  const bannerInTrace = (doc.parseTrace?.lines || []).some((l) => KEY_BANNER_RE.test(l));
  const banner = bannerInStems || bannerInTitles || bannerInTrace;

  if (run.length >= 3) return { questions: run.map((q) => ({ q, printed: printedNumberOf(q) })), via: banner ? 'banner' : 'pattern' };
  if (banner && run.length >= 1) return { questions: run.map((q) => ({ q, printed: printedNumberOf(q) })), via: 'banner' };
  return null;
}

/** Extract number→label entries from key-region text lines. */
export function extractKeyEntries(lines: string[]): AnswerKeyEntry[] {
  const entries: AnswerKeyEntry[] = [];
  for (const raw of lines) {
    const line = normalizeKeyDigits(raw);
    for (const m of line.matchAll(PAIR_WORD_RE)) {
      const number = Number(m[1]);
      const label = m[2];
      if (Number.isFinite(number)) entries.push({ number, label, optionIndex: OPTION_LABELS[label] });
    }
    for (const m of line.matchAll(PAIR_DIGIT_RE)) {
      const number = Number(m[1] ?? m[3]);
      const label = m[2] ?? m[4];
      if (Number.isFinite(number) && label !== undefined) {
        entries.push({ number, label, optionIndex: Number(label) - 1 });
      }
    }
  }
  return entries;
}

/** The text each key question contributes to extraction. A stem that already
 *  carries full pairs is used as-is; a bare label gets its printed number
 *  restored ("ب" + printed 1 -> "1. ب"). */
function keyLineOf(k: { q: QuestionItem; printed: number }): string {
  const stem = normalizeKeyDigits(k.q.stem || '').trim();
  if (looksLikeKeyRow(stem)) return stem;
  return Number.isFinite(k.printed) ? `${k.printed}. ${stem}` : stem;
}

/**
 * Detect + separate + map. Returns the input document untouched (report
 * null) when no key region exists; otherwise a NEW document with the key
 * rows removed and official answers applied, plus the report.
 */
export function applyAnswerKey(doc: ExamDocument): { doc: ExamDocument; report: AnswerKeyReport | null } {
  const region = findKeyRegion(doc);
  if (!region) return { doc, report: null };

  const warnings: AnswerKeyWarning[] = [];
  const keyIds = new Set(region.questions.map((k) => k.q.id));
  const entries = extractKeyEntries(region.questions.map(keyLineOf));

  // Dedupe: the same question number keyed twice — FIRST wins.
  const byNumber = new Map<number, AnswerKeyEntry>();
  for (const e of entries) {
    const prev = byNumber.get(e.number);
    if (prev) {
      warnings.push({
        type: 'duplicate-entry',
        message: `Question ${e.number} is keyed twice ("${prev.label}" then "${e.label}") — the first entry wins.`,
        questionNumber: e.number,
      });
      continue;
    }
    byNumber.set(e.number, e);
  }

  // Remaining questions indexed by PRINTED number. Repeated numbers across
  // sections are AMBIGUOUS — never guessed, always a named warning.
  const index = new Map<number, QuestionItem[]>();
  for (const sec of doc.sections) {
    for (const q of sec.questions || []) {
      if (keyIds.has(q.id)) continue;
      const printed = printedNumberOf(q);
      if (!Number.isFinite(printed)) continue;
      const list = index.get(printed) || [];
      list.push(q);
      index.set(printed, list);
    }
  }

  let applied = 0;
  const appliedEntries: AnswerKeyEntry[] = [];
  const patched = new Map<string, QuestionItem>(); // id -> updated question (immutable apply)
  const answerable: QuestionItem[] = [];
  for (const [n, list] of index) {
    if (list.length === 1) answerable.push(list[0]);
  }

  for (const [number, entry] of byNumber) {
    const targets = index.get(number) || [];
    if (targets.length === 0) {
      warnings.push({
        type: 'orphan-entry',
        message: `Key entry ${number}.${entry.label} matches no question on the sheet.`,
        questionNumber: number,
      });
      continue;
    }
    if (targets.length > 1) {
      warnings.push({
        type: 'ambiguous-number',
        message: `Key entry ${number}.${entry.label} matches ${targets.length} questions numbered ${number} (sections restart numbering) — NOT applied, assign manually.`,
        questionNumber: number,
      });
      continue;
    }
    const q = targets[0];
    if (q.answerMeta?.method === 'human' || q.answerMeta?.method === 'official') {
      warnings.push({
        type: 'skipped-existing',
        message: `Question ${number} already has a ${q.answerMeta.method} answer — key entry not applied.`,
        questionNumber: number,
      });
      continue;
    }
    const applyValue = (value: string, opt: AnswerKeyEntry): void => {
      patched.set(q.id, { ...q, correctAnswer: value, answerMeta: { method: 'official' } });
      appliedEntries.push(opt);
      applied++;
    };
    if (TRUE_LABELS.has(entry.label) || FALSE_LABELS.has(entry.label)) {
      if (q.type !== 'true_false') {
        warnings.push({
          type: 'unmapped-type',
          message: `Key entry ${number}.${entry.label} is a true/false answer but question ${number} is ${q.type}.`,
          questionNumber: number,
        });
        continue;
      }
      const value = TRUE_LABELS.has(entry.label) ? 'true' : 'false';
      applyValue(value, { ...entry, optionText: value });
      continue;
    }
    if (q.options && q.options.length > 0 && typeof entry.optionIndex === 'number') {
      if (entry.optionIndex < 0 || entry.optionIndex >= q.options.length) {
        warnings.push({
          type: 'invalid-option',
          message: `Key entry ${number}.${entry.label} points at option ${entry.optionIndex + 1}, but question ${number} has only ${q.options.length} option(s).`,
          questionNumber: number,
        });
        continue;
      }
      // MCQ CONTRACT: correctAnswer is the option ID ('a'..'d'), never the
      // option text — runInvariantChecks (ANSWER_VALID), the UI correct-option
      // highlight, the Moodle/answer-key exports and the autosolver all match
      // by id. The printed text rides the report entry as optionText.
      const option = q.options[entry.optionIndex];
      applyValue(option.id, { ...entry, optionText: option.text });
      continue;
    }
    warnings.push({
      type: 'unmapped-type',
      message: `Key entry ${number}.${entry.label} cannot map to question ${number} (${q.type}${q.options?.length ? `, ${q.options.length} options` : ', no options'}).`,
      questionNumber: number,
    });
  }

  // Coverage: MCQ/TF questions the key does not cover (info, not an error).
  const coveredNumbers = new Set(appliedEntries.map((e) => e.number));
  const uncovered = answerable.filter(
    (q) =>
      !coveredNumbers.has(printedNumberOf(q)) &&
      (q.type === 'true_false' || (q.options && q.options.length > 0)) &&
      q.answerMeta?.method !== 'human' &&
      q.answerMeta?.method !== 'official',
  ).length;
  if (uncovered > 0) {
    warnings.push({
      type: 'uncovered-questions',
      message: `${uncovered} MCQ/true-false question(s) have no key entry — they will route to the normal AI answer flow if you run it.`,
    });
  }

  // Immutable separation + application: swap in patched questions, drop the
  // key rows, and drop sections left empty.
  const sections = doc.sections
    .map((s) => ({
      ...s,
      questions: (s.questions || [])
        .map((q) => patched.get(q.id) || q)
        .filter((q) => !keyIds.has(q.id)),
    }))
    .filter((s) => (s.questions || []).length > 0);
  const report: AnswerKeyReport = {
    detected: true,
    source: 'on-file',
    via: region.via,
    removedQuestions: region.questions.length,
    entries: appliedEntries,
    applied,
    warnings,
    appliedAt: new Date().toISOString(),
  };
  const nextDoc: ExamDocument = {
    ...doc,
    sections,
    totalQuestions: sections.reduce((sum, s) => sum + (s.questions?.length || 0), 0),
    answerKeyOnFile: report,
  };
  return { doc: nextDoc, report };
}
