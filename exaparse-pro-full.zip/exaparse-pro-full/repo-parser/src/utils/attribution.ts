import { DifficultyScore, ExamDocument, LessonAttribution } from '../types/exam';
import { availabilityHint, computeDifficulty, DEFAULT_WEIGHTS, DifficultyWeights } from './difficulty';

/**
 * M3 attribution application — immutable helpers that stamp the AI signals
 * onto questions and compute the deterministic difficulty score. Signals are
 * EVIDENCE: they attach to QuestionItem.attribution / .difficulty and stay
 * human-editable; nothing about them auto-commits anything.
 */

/** Stamp one question's attribution signals. Returns a NEW document. */
export function applyAttribution(doc: ExamDocument, questionId: string, attribution: LessonAttribution): ExamDocument {
  return {
    ...doc,
    sections: doc.sections.map((sec) => ({
      ...sec,
      questions: sec.questions.map((q) => (q.id === questionId ? { ...q, attribution } : q)),
    })),
  };
}

/**
 * Compute + stamp difficulty for one question from its signals.
 * Deterministic: same signals + same weights => same score (gate-checked).
 */
export function computeAndApplyDifficulty(
  doc: ExamDocument,
  questionId: string,
  weights: DifficultyWeights = DEFAULT_WEIGHTS,
  weightsVersion?: string,
): ExamDocument {
  const q = doc.sections.flatMap((s) => s.questions).find((x) => x.id === questionId);
  if (!q) return doc;
  const attr = q.attribution;
  if (!attr) return doc;
  const lessons = [attr.lesson1, attr.lesson2].filter(Boolean).length;
  const span: 1 | 2 | 3 = lessons >= 2 ? (lessons >= 3 ? 3 : 2) : 1;
  const allMarks = doc.sections.flatMap((s) => s.questions).map((x) => x.mark).filter((m) => m > 0).sort((a, b) => a - b);
  const mid = Math.floor(allMarks.length / 2);
  const medianMark = allMarks.length === 0 ? undefined : allMarks.length % 2 === 1 ? allMarks[mid] : (allMarks[mid - 1] + allMarks[mid]) / 2;
  const difficulty: DifficultyScore = computeDifficulty(
    {
      lessonSpan: span,
      provenance: attr.inBook,
      cognitive: attr.cognitive,
      availability: q.answer ? availabilityHint(q.answer.value, q.stem, q.parentContextText) : undefined,
      mark: q.mark,
      medianMark,
      stemLength: q.stem.length,
      passageLength: q.parentContextText?.length || 0,
    },
    weights,
    weightsVersion,
  );
  return {
    ...doc,
    sections: doc.sections.map((sec) => ({
      ...sec,
      questions: sec.questions.map((x) => (x.id === questionId ? { ...x, difficulty } : x)),
    })),
  };
}
