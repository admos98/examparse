import { ExamDocument, QuestionItem } from '../types/exam';
import { normalizeForFingerprint } from './answerCache';

/**
 * AI-as-referee: the deterministic pre-solver.
 *
 * Before a single token is spent, every question gets a chance to be solved
 * offline:
 *   1. Matching rows — solved as a bipartite assignment between column A items
 *      and column B items using token/character similarity (near-perfect when
 *      the pairing is unique).
 *   2. Semantic cache — an identical stem+choices seen before returns its
 *      known-good answer instantly.
 *
 * Only the *contested* remainder is dispatched to the AI. This is the core of
 * the "insane accuracy, tiny AI usage" story.
 */

export interface PreSolvedAnswer {
  answer: string;
  method: 'heuristic' | 'cache';
  confidence: number;
}

export interface PreSolveResult {
  /** questionId -> deterministic answer */
  solved: Map<string, PreSolvedAnswer>;
  /** questionIds that still need the AI */
  contested: QuestionItem[];
  /** number of matching rows resolved by the bipartite heuristic */
  heuristicSolved: number;
  cacheHits: number;
}

const MATCH_CONFIDENCE_THRESHOLD = 0.86;
const MATCH_MARGIN = 0.08;

// ---------- string similarity helpers ----------

function tokenSet(text: string): Set<string> {
  return new Set(normalizeForFingerprint(text).split(' ').filter((t) => t.length > 1));
}

function jaccard(a: string, b: string): number {
  const ta = tokenSet(a);
  const tb = tokenSet(b);
  if (ta.size === 0 || tb.size === 0) return 0;
  let inter = 0;
  for (const t of ta) if (tb.has(t)) inter++;
  return inter / (ta.size + tb.size - inter);
}

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  const m = a.length;
  const n = b.length;
  if (!m || !n) return Math.max(m, n);
  let prev = new Array(n + 1).fill(0).map((_, i) => i);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) {
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
    prev = cur;
  }
  return prev[n];
}

function charSimilarity(a: string, b: string): number {
  const na = normalizeForFingerprint(a);
  const nb = normalizeForFingerprint(b);
  if (!na && !nb) return 0;
  const maxLen = Math.max(na.length, nb.length);
  if (!maxLen) return 0;
  return 1 - levenshtein(na, nb) / maxLen;
}

function pairSimilarity(a: string, b: string): number {
  // Blend token-level and character-level signals; Persian inflections favor chars.
  return Math.max(jaccard(a, b) * 0.6 + charSimilarity(a, b) * 0.4, charSimilarity(a, b) * 0.85);
}

// ---------- bipartite matching (Hungarian-lite greedy + augmenting paths) ----------

/**
 * Maximum-bipartite-matching via Kuhn's algorithm on a similarity graph.
 * Items whose best matched score >= threshold are returned as confident pairs.
 */
function matchBipartite(
  lefts: { id: string; text: string }[],
  rights: { key: string; text: string }[],
  threshold: number,
): Map<string, { key: string; score: number }> {
  // Build adjacency: left index -> eligible right indices
  const adj: number[][] = lefts.map((l) => {
    const scores = rights.map((r) => pairSimilarity(l.text, r.text));
    const maxScore = Math.max(...scores, 0);
    // Keep only candidates within a reasonable band of the best score
    return scores
      .map((s, ri) => ({ s, ri }))
      .filter((x) => x.s >= Math.min(threshold, maxScore) && x.s >= threshold * 0.9)
      .sort((a, b) => b.s - a.s)
      .map((x) => x.ri);
  });

  const matchRight = new Array<number>(rights.length).fill(-1); // right idx -> left idx

  const tryAugment = (li: number, visited: boolean[]): boolean => {
    for (const ri of adj[li]) {
      if (visited[ri]) continue;
      visited[ri] = true;
      if (matchRight[ri] === -1 || tryAugment(matchRight[ri], visited)) {
        matchRight[ri] = li;
        return true;
      }
    }
    return false;
  };

  for (let li = 0; li < lefts.length; li++) {
    tryAugment(li, new Array<boolean>(rights.length).fill(false));
  }

  const result = new Map<string, { key: string; score: number }>();
  for (let ri = 0; ri < rights.length; ri++) {
    const li = matchRight[ri];
    if (li !== -1) {
      const score = pairSimilarity(lefts[li].text, rights[ri].text);
      if (score >= threshold) {
        result.set(lefts[li].id, { key: rights[ri].key, score });
      }
    }
  }
  return result;
}

// ---------- matching-question solving ----------

function solveMatchingSection(section: ExamDocument['sections'][number]): Map<string, PreSolvedAnswer> {
  const out = new Map<string, PreSolvedAnswer>();
  const matchQs = section.questions.filter((q) => q.type === 'matching');

  // 1. Draft-key extraction: the teacher's sheet often carries partial keys
  //    (rightKey / rightText inside the pairs). Those are pure data — copy them
  //    with maximum confidence, zero inference, zero tokens.
  for (const q of matchQs) {
    const first = q.matchingPairs?.[0];
    if (first?.rightKey && first.rightKey.trim()) {
      out.set(q.id, { answer: first.rightKey.trim(), method: 'heuristic', confidence: 1 });
    } else if (first?.rightText && first.rightText.trim()) {
      // rightText without key: map text back to the column B id
      const colB = section.matchingColumns?.columnB || [];
      const hit = colB.find((c) => c.text.trim() === first.rightText!.trim());
      if (hit) {
        out.set(q.id, { answer: String(hit.id), method: 'heuristic', confidence: 1 });
      }
    }
  }

  // 2. Textual bipartite matching for the rows still unsolved (leftText that
  //    genuinely appears among column B texts — e.g. scrambled matching lists).
  const unsolved = matchQs.filter((q) => !out.has(q.id));
  if (unsolved.length === 0) return out;

  // Build the right-hand candidates: prefer explicit matchingColumns.columnB,
  // else per-question pairs' rightText entries.
  let rights: { key: string; text: string }[] = [];
  if (section.matchingColumns?.columnB?.length) {
    rights = section.matchingColumns.columnB.map((c) => ({ key: String(c.id), text: c.text }));
  } else {
    const seen = new Set<string>();
    for (const q of unsolved) {
      for (const p of q.matchingPairs || []) {
        const key = p.rightKey || p.rightText || '';
        const text = p.rightText || p.rightKey || '';
        if (key && text && !seen.has(key)) {
          seen.add(key);
          rights.push({ key, text });
        }
      }
    }
  }
  if (rights.length === 0) return out;

  // Left-hand items: prefer matchingPairs[0].leftText, else the stem.
  const lefts = unsolved
    .map((q) => {
      const leftText = q.matchingPairs?.[0]?.leftText?.trim() || q.stem || '';
      return { id: q.id, text: leftText };
    })
    .filter((l) => l.text.length > 0);

  const matches = matchBipartite(lefts, rights, MATCH_CONFIDENCE_THRESHOLD);
  for (const [qid, m] of matches) {
    out.set(qid, { answer: m.key, method: 'heuristic', confidence: Math.round(m.score * 100) / 100 });
  }
  return out;
}

// ---------- main entry ----------

export function preSolveDocument(
  doc: ExamDocument,
  cacheLookup?: (q: QuestionItem) => PreSolvedAnswer | undefined,
): PreSolveResult {
  const solved = new Map<string, PreSolvedAnswer>();
  const contested: QuestionItem[] = [];
  let heuristicSolved = 0;
  let cacheHits = 0;

  for (const sec of doc.sections) {
    // 1. Bipartite matching solve per matching-bearing section
    const matchAnswers = solveMatchingSection(sec);
    for (const [qid, ans] of matchAnswers) {
      solved.set(qid, ans);
      heuristicSolved++;
    }

    // 2. Everything else: cache or contest
    for (const q of sec.questions) {
      if (solved.has(q.id)) continue;
      if (!q.stem || !q.stem.trim()) {
        contested.push(q); // broken question — let AI/anomaly flow deal
        continue;
      }
      const cached = cacheLookup?.(q);
      if (cached) {
        solved.set(q.id, cached);
        cacheHits++;
        continue;
      }
      contested.push(q);
    }
  }

  return { solved, contested, heuristicSolved, cacheHits };
}

/**
 * MCQ answer-distribution sanity check (deterministic post-AI audit).
 * A key where >85% of >=8 MCQ answers share one letter is statistically
 * implausible for a real exam — flag it for review.
 */
export function checkAnswerDistribution(
  questions: QuestionItem[],
): { questionId: string; message: string } | null {
  const mcq = questions.filter(
    (q) => q.type === 'multiple_choice' && q.correctAnswer && /^[a-d]$/i.test(q.correctAnswer.trim()),
  );
  if (mcq.length < 8) return null;

  const counts = new Map<string, number>();
  for (const q of mcq) {
    const k = q.correctAnswer!.trim().toLowerCase();
    counts.set(k, (counts.get(k) || 0) + 1);
  }
  const [topKey, topCount] = [...counts.entries()].sort((a, b) => b[1] - a[1])[0];
  if (topCount / mcq.length > 0.85) {
    const flagged = mcq.find((q) => q.correctAnswer!.trim().toLowerCase() === topKey)!;
    return {
      questionId: flagged.id,
      message: `Answer key is statistically implausible: ${topCount}/${mcq.length} MCQ answers are "${topKey}". Verify the key.`,
    };
  }
  return null;
}
