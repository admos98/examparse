/**
 * brainBridge.ts — BrainResult -> engine section blocks + uncertainty report.
 *
 * The layout brain decides boundaries with cross-checked geometry evidence;
 * the bridge translates its verdict into the block shape the text engine's
 * per-section machinery already consumes. The contract (user charter):
 *
 *  - CONFIRMED sections  -> one block PER ROW when rows carry their own lines
 *    (the graded shape: each printed letter row = one section with its mark),
 *    else one block per section. Residual lines inside a confirmed section
 *    (prelude, gaps) ride with the nearest row — coverage is exact.
 *  - EVERYTHING ELSE     -> honest General blocks (unconfirmed boundaries,
 *    prelude above the first boundary): every content line lands in exactly
 *    one block. Structure is never fabricated, content is never dropped.
 *  - KEY SHEET           -> lines at/after the brain's answer-key boundary are
 *    metadata and are excluded from every block.
 *  - NOTHING confirmed   -> null: the caller runs today's text splitters
 *    unchanged. Worst case = status quo, by construction.
 *
 * Every block carries a `brain` receipt (confidence + boundary kind + notes)
 * so downstream surfaces can SHOW the uncertainty instead of hiding it.
 */

import type { BrainResult, BrainSection, BrainRow, BrainLine } from './layoutBrain';
import { toLatinDigits } from './layoutBrain';

/** Mirrors parserEngine's RawSectionBlock category union (kept in sync there). */
export type RawBlockCategory = 'Listening' | 'Vocabulary' | 'Grammar' | 'Writing' | 'Reading' | 'General';

export interface BrainBlockReceipt {
  confirmed: boolean;
  confidence: number;
  boundaryKind?: string;
  subject?: string;
  /** numeric (radif) section identity when the brain perceived one */
  numeric?: number;
  evidenceNotes: string[];
}

export interface BrainReportSummary {
  /** confirmed = every section committed; partial = brain + fallback mix;
   *  abstained = brain produced no confident separation (caller falls back). */
  mode: 'confirmed' | 'partial' | 'abstained';
  sections: number;
  confirmed: number;
  fallbacks: number;
  sumMarks: number;
  printedTotal?: number;
  notes: string[];
  stats: BrainResult['stats'];
}

export interface RawBridgeBlock {
  rowId: string;
  category: RawBlockCategory;
  mark: number;
  text: string;
  headerLine: string;
  /** The block is a slice of the FULL normalized text (engine re-locates it). */
  startIndex: number;
  labelCategory?: boolean;
  brain?: BrainBlockReceipt;
}

export interface BridgedBrain {
  blocks: RawBridgeBlock[];
  report: BrainReportSummary;
}

/** Brain subject -> engine category (the engine's union has no Speaking etc.). */
function subjectToCategory(subject?: string): RawBlockCategory {
  switch (subject) {
    case 'Vocabulary':
    case 'Grammar':
    case 'Reading':
    case 'Writing':
    case 'Listening':
      return subject;
    default:
      // Speaking / Pronunciation / Language Function / unlabeled: the engine's
      // generic machinery types the content; the receipt keeps the real subject.
      return 'General';
  }
}

const linesText = (lines: BrainLine[]): string =>
  lines
    .map((l) => l.text)
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

/**
 * Translates a brain result into engine blocks (FULL coverage guaranteed).
 * Returns null when the brain confirmed nothing (caller -> status quo).
 */
export function bridgeBrainResult(result: BrainResult): BridgedBrain | null {
  const confirmedSections = result.sections.filter((s) => s.confirmed && !s.demoted);
  if (confirmedSections.length === 0) return null;

  // ---- document order over the brain's own flat line list (identity map)
  const orderOf = new Map<BrainLine, number>();
  result.lines.forEach((l, i) => orderOf.set(l, i));

  // ---- key-sheet cut: lines at/after the answer-key boundary are metadata
  let keyCutIdx = Infinity;
  if (result.keyBoundary) {
    for (const l of result.lines) {
      if (l.page > result.keyBoundary.page) {
        keyCutIdx = Math.min(keyCutIdx, orderOf.get(l) ?? Infinity);
        continue;
      }
      if (l.page === result.keyBoundary.page && l.bbox[1] >= result.keyBoundary.y - 2) {
        keyCutIdx = Math.min(keyCutIdx, orderOf.get(l) ?? Infinity);
      }
    }
  }
  const isKey = (i: number) => i >= keyCutIdx;

  // ---- coverage sets: a line is brain-owned when a CONFIRMED section holds it
  const confirmedLine = new Set<BrainLine>();
  for (const s of confirmedSections) for (const l of s.lines) confirmedLine.add(l);
  // document-order emission state: each confirmed section owns its lines and
  // emits ONCE at its first line; uncovered lines become General runs IN PLACE
  const lineOwner = new Map<BrainLine, BrainSection>();
  const emitted = new Set<BrainSection>();
  for (const s of confirmedSections)
    for (const l of s.lines) if (!lineOwner.has(l)) lineOwner.set(l, s);

  const blocks: RawBridgeBlock[] = [];
  // Row IDs are the PRINTED identifiers, verbatim — letters for lettered rows
  // (per-part restarts legitimately repeat letters and the grader supports
  // duplicate rowIds), the printed radif NUMBER for numeric sections, and
  // 'General' only when the brain truly perceived no identity. Fabricating a
  // continuation here would corrupt identity.
  const pickRowId = (preferred: string | undefined, numeric?: number): string => {
    if (preferred && preferred.trim()) return preferred.trim();
    if (numeric !== undefined && numeric > 0) return String(numeric);
    return 'General';
  };

  const receiptOf = (s: BrainSection): BrainBlockReceipt => ({
    confirmed: true,
    confidence: Math.round(s.confidence * 100) / 100,
    boundaryKind: s.boundaryKind,
    subject: s.subject,
    numeric: s.evidence.numeric,
    evidenceNotes: s.notes.slice(0, 8),
  });

  /** Emit one confirmed section: per-row blocks when every row carries its
   *  own lines (residual section lines ride with the nearest row), else one
   *  block with the section's full text. */
  const emitConfirmed = (s: BrainSection) => {
    const category = subjectToCategory(s.subject);
    const keyFilteredLines = s.lines.filter((l) => {
      const i = orderOf.get(l);
      return i === undefined || !isKey(i);
    });
    const backed = s.rows.filter((r) => (r.lines?.length ?? 0) > 0);
    const stripRows = s.rows.filter((r) => (r.lines?.length ?? 0) === 0);

    if (s.rows.length >= 2 && backed.length === s.rows.length) {
      // per-row emission with residual assignment (prelude/gaps/tail)
      const rowSet = s.rows.map((r) => new Set(r.lines ?? []));
      const rowStart = s.rows.map((r) =>
        Math.min(...(r.lines ?? []).map((l) => orderOf.get(l) ?? Infinity))
      );
      const buckets: BrainLine[][] = s.rows.map((r) => {
        const ls = (r.lines ?? []).filter((l) => {
          const i = orderOf.get(l);
          return i === undefined || !isKey(i);
        });
        return [...ls];
      });
      const ordered = [...keyFilteredLines].sort(
        (a, b) => (orderOf.get(a) ?? 0) - (orderOf.get(b) ?? 0)
      );
      for (const l of ordered) {
        if (s.rows.some((r, k) => rowSet[k].has(l))) continue; // row's own line
        const p = orderOf.get(l) ?? -1;
        let owner = -1;
        for (let k = 0; k < s.rows.length; k++) {
          if (rowStart[k] <= p) owner = k;
          else break;
        }
        buckets[owner >= 0 ? owner : 0].push(l);
      }
      s.rows.forEach((r: BrainRow, k) => {
        const text = linesText(buckets[k]);
        if (!text.trim()) return;
        blocks.push({
          rowId: pickRowId(r.letter, s.evidence.numeric),
          category,
          mark: r.mark ?? 0,
          text,
          headerLine: r.headerText || s.headerText || '',
          startIndex: 0,
          labelCategory: !!s.subject,
          brain: receiptOf(s),
        });
      });
      return;
    }

    if (backed.length > 0) {
      // MIXED: body rows carry the content; strip rows are the marks index.
      // A strip row whose letter matches a backed row is the SAME row — its
      // mark transfers. Untwinned strip rows keep their instruction text so
      // the mark survives (never a phantom empty section).
      for (const sr of stripRows) {
        const twin = backed.find((r) => r.letter === sr.letter);
        if (twin && twin.mark === undefined && sr.mark !== undefined) twin.mark = sr.mark;
      }
      for (const r of backed) {
        const text = linesText(
          (r.lines ?? []).filter((l) => {
            const i = orderOf.get(l);
            return i === undefined || !isKey(i);
          })
        );
        if (!text.trim()) continue;
        blocks.push({
          rowId: pickRowId(r.letter, s.evidence.numeric),
          category,
          mark: r.mark ?? 0,
          text,
          headerLine: r.headerText || s.headerText || '',
          startIndex: 0,
          labelCategory: !!s.subject,
          brain: receiptOf(s),
        });
      }
      for (const sr of stripRows) {
        if (backed.some((r) => r.letter === sr.letter)) continue; // twin consumed the mark
        const text = (sr.headerText ?? '').trim();
        if (!text) continue;
        blocks.push({
          rowId: pickRowId(sr.letter, s.evidence.numeric),
          category,
          mark: sr.mark ?? 0,
          text,
          headerLine: sr.headerText || s.headerText || '',
          startIndex: 0,
          labelCategory: !!s.subject,
          brain: receiptOf(s),
        });
      }
      return;
    }

    // rows the brain could not line up (marks-strip sections) or rowless
    // rule/matching/content boundaries: ONE block with the full section
    // text — content is never dropped or duplicated.
    const text = linesText(keyFilteredLines) || s.rows.map((r) => r.headerText || '').join('\n');
    if (!text.trim()) return;
    blocks.push({
      rowId: pickRowId(s.rows[0]?.letter, s.evidence.numeric),
      category,
      mark: s.rows.length ? Math.round(s.rows.reduce((m, r) => m + (r.mark ?? 0), 0) * 100) / 100 : 0,
      text,
      headerLine: s.headerText || '',
      startIndex: 0,
      labelCategory: !!s.subject,
      brain: receiptOf(s),
    });
  };
  // ---- fallback runs: every non-confirmed, non-key line, grouped into
  // maximal contiguous runs — emitted IN PLACE (document order), so the
  // engine sees prelude/header runs BEFORE the sections that follow them
  // and gaps between confirmed sections where they physically occur.
  const pendingRun: BrainLine[] = [];
  const flushRun = () => {
    if (!pendingRun.length) return;
    const text = linesText(pendingRun);
    pendingRun.length = 0;
    if (!text.trim()) return;
    blocks.push({
      rowId: 'General',
      category: 'General',
      mark: 0,
      text,
      headerLine: '',
      startIndex: 0,
      brain: {
        confirmed: false,
        confidence: 0.3,
        boundaryKind: 'uncovered',
        evidenceNotes: [
          'outside the confirmed layout structure — separated by the generic machinery, flagged for review',
        ],
      },
    });
  };
  // SINGLE document-order walk: a confirmed section emits at its FIRST line
  // (rows stay in their internal order); uncovered lines accumulate into a
  // run that flushes the moment confirmed content resumes. Fixes the G4 bug
  // where fallback runs all landed AFTER the confirmed blocks (pm57's
  // Listening sections were appended past R).
  for (const l of result.lines) {
    const i = orderOf.get(l);
    if (i !== undefined && isKey(i)) continue; // answer-key metadata
    const owner = lineOwner.get(l);
    if (owner) {
      flushRun();
      if (!emitted.has(owner)) {
        emitConfirmed(owner);
        emitted.add(owner);
      }
    } else {
      pendingRun.push(l);
    }
  }
  flushRun();

  // ---- strip-index digits at block edges: unruled marks strips print a bare
  // row-number/mark digit beside every row; at a block's LEADING edge such a
  // digit is index furniture, not content. If the canonical slice opens with
  // it, the engine's instruction capture is blinded (p566 B: "2\nB) Match...")
  // and the matching cue never fires. Trim edge digits; blocks reduced to
  // nothing were pure furniture and drop out.
  const contentBlocks: RawBridgeBlock[] = [];
  for (const b of blocks) {
    const ls = b.text.split('\n');
    while (ls.length && /^\d{1,2}(\.\d+)?$/.test(toLatinDigits(ls[0].trim()))) ls.shift();
    // Unconfirmed runs are outside the confirmed structure — trailing strip
    // digits there are index furniture that would parse as junk questions
    // (p566's stamp run). Confirmed blocks keep their tails: the text path
    // tolerates them and their sections are graded shapes.
    if (b.brain && !b.brain.confirmed)
      while (ls.length && /^\d{1,2}(\.\d+)?$/.test(toLatinDigits(ls[ls.length - 1].trim()))) ls.pop();
    const text = ls.join('\n').trim();
    if (!text) continue;
    contentBlocks.push({ ...b, text });
  }
  if (contentBlocks.length === 0) return null;

  // ---- drive-worthiness gate (charter: worst case = status quo).
  // The brain only DRIVES the parse when its separation is structurally sane:
  //   0. FULL CONFIRMATION — corpus evidence: every partial-mode drive lost
  //      to the text splitters (unconfirmed holes become General runs that
  //      shift question numbering). Partial = advisory, never drive.
  //   1. COVERAGE — confirmed sections hold most of the document's content
  //      lines. A brain that "confirmed" only a furniture fragment must never
  //      shadow the text splitters (pd24nl1531 drove with ONE footer line).
  //   2. MARKS CLOSURE — when the sheet prints its total (جمع بارم), the
  //      extracted marks must close on it. Unclosed marks = the row model is
  //      wrong somewhere = do not drive; flag it instead.
  const fallbackCount = result.fallbacks.length;
  const contentLines = result.lines.filter((l) => {
    const i = orderOf.get(l);
    return i === undefined || !isKey(i);
  });
  const coveredCount = contentLines.reduce((n, l) => n + (lineOwner.has(l) ? 1 : 0), 0);
  const coverage = contentLines.length ? coveredCount / contentLines.length : 0;
  const printedTotal = result.stats.printedTotal;
  const marksClose =
    printedTotal === undefined || Math.abs(result.stats.sumOfMarks - printedTotal) <= 2;
  if (fallbackCount > 0 || coverage < 0.6 || !marksClose) {
    result.notes.push(
      `drive gate: ${fallbackCount > 0 ? `${fallbackCount} unconfirmed section(s), ` : ''}coverage ${(
        coverage * 100
      ).toFixed(0)}% (need 60%), marks ${
        !marksClose ? `sum ${result.stats.sumOfMarks} vs printed ${printedTotal} NOT closed` : 'closed'
      } -> advisory only, text splitters parse`
    );
    return null;
  }

  const report: BrainReportSummary = {
    mode: fallbackCount === 0 ? 'confirmed' : 'partial',
    sections: result.sections.length,
    confirmed: confirmedSections.length,
    fallbacks: fallbackCount,
    sumMarks: result.stats.sumOfMarks,
    printedTotal: result.stats.printedTotal,
    notes: result.notes.slice(0, 30),
    stats: result.stats,
  };
  return { blocks: contentBlocks, report };
}
