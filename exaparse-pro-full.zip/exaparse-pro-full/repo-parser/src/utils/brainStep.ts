/**
 * brainStep.ts — the shared layout-brain step used by BOTH the main parse
 * pipeline and the off-main-thread parse worker (kept in its own module so
 * the worker chunk never needs to import the pipeline itself).
 *
 * geometry (BrainDoc) -> verified section blocks + report, with every failure
 * captured: the brain can slow down a parse, never break one.
 */

import { runLayoutBrain, BrainDoc } from './layoutBrain';
import { bridgeBrainResult, BrainReportSummary } from './brainBridge';
import type { RawSectionBlock } from './parserEngine';

/** A brainDoc is only worth running when it actually carries signals. */
function looksLikeGeometry(doc: BrainDoc): boolean {
  if (!doc || !Array.isArray(doc.pages) || doc.pages.length === 0) return false;
  return doc.pages.some(
    (p) =>
      (Array.isArray(p.lines) && p.lines.length > 0) ||
      (Array.isArray(p.hlines) && p.hlines.length > 0) ||
      (Array.isArray(p.tables) && p.tables.length > 0)
  );
}

export interface BrainStepResult {
  preSplit?: RawSectionBlock[];
  report?: BrainReportSummary;
  failed?: string;
}

/**
 * @param mode 'drive' (default) = the brain's verified blocks ARE the section
 *   split whenever the drive gate passes (full confirmation + coverage +
 *   marks closure — corpus-proven 0 regressions, Wave G5); otherwise the
 *   text splitters parse and the brain rides along as an advisory report.
 *   'advisory' = force the text splitters to parse (the brain only reports).
 */
export function buildBrainPreSplit(brainDoc?: BrainDoc, mode: 'advisory' | 'drive' = 'drive'): BrainStepResult {
  if (!brainDoc || !looksLikeGeometry(brainDoc)) return {};
  try {
    const brainResult = runLayoutBrain(brainDoc);
    const bridged = bridgeBrainResult(brainResult);
    if (!bridged) {
      // Gate refused to drive (coverage/marks closure) or nothing confirmed:
      // still surface the brain's perception + the refusal reason — the
      // charter says flag uncertainty, never hide it.
      return {
        report: {
          mode: 'abstained',
          sections: brainResult.sections.length,
          confirmed: brainResult.sections.filter((s) => s.confirmed && !s.demoted).length,
          fallbacks: brainResult.fallbacks.length,
          sumMarks: brainResult.stats.sumOfMarks,
          printedTotal: brainResult.stats.printedTotal,
          notes: brainResult.notes.slice(0, 30),
          stats: brainResult.stats,
        },
      };
    }
    if (mode !== 'drive') {
      bridged.report.notes = [
        ...bridged.report.notes,
        'advisory mode: the layout verdicts are informational — the text splitters parsed this file.',
      ];
      return { report: bridged.report };
    }
    return { preSplit: bridged.blocks, report: bridged.report };
  } catch (e) {
    return { failed: e instanceof Error ? e.message : String(e) };
  }
}
