import { CalibrationReport, CalibrationCategory } from '../types/exam';
import { classifyBucket } from './answerFlow';
import { DIGEST_VERSION } from './curriculum';
import { DEFAULT_WEIGHTS_VERSION } from './difficulty';

/**
 * M4 §6 — the calibration gate: MEASURED trust before auto-accept.
 *
 * D1 auto-accept and the review grid's bulk-accept switch on only for
 * categories whose accuracy Jev/producer answers were MEASURED against
 * hand-built golden answers. The mechanics:
 *
 *   - One category = (answer-kind × cognitive level), e.g. "choice|recall".
 *     (The plan's original "by subject incl. math" was corrected during the
 *     external-audit round: the corpus is language exams; the cognitive axis
 *     is the reasoning proxy that also powers the routing rule.)
 *   - A category is auto-acceptable ONLY when measured accuracy >= threshold
 *     AND the sample size >= minCell (thin cells NEVER grant trust).
 *   - The report is version-bound: it is valid only for the exact
 *     (digestVersion, weightsVersion, promptVersion) tuple measured. Any bump
 *     invalidates it — re-measure before re-enabling auto-accept.
 *   - Hard vetoes independent of the report: pending mediations, bucket B
 *     free-text (never auto-accepts), application-level items, and questions
 *     the keyword cross-check flagged. See bulkAcceptAllowed().
 *
 * This module is pure: measurement collection happens wherever a golden exam
 * with hand-built answers meets produced answers (verifyCalibration in the
 * gate; the calibration affordance in the app with live keys).
 */

export interface CalibrationSample {
  questionId: string;
  kind: 'choice' | 'free-text';
  cognitive?: 'recall' | 'comprehension' | 'application';
  /** The produced/verified draft value compared against GOLDEN ground truth. */
  produced: string;
  /** The hand-built official answer for the golden exam (never AI-sourced). */
  golden: string;
}

export const CALIBRATION_THRESHOLD = 0.95;
export const CALIBRATION_MIN_CELL = 20;
export const CALIBRATION_PROMPT_VERSION = 'ap1';

export function calibrationCategoryOf(kind: CalibrationSample['kind'], cognitive?: string): string {
  return `${kind}|${cognitive || 'unclassified'}`;
}

/** Compare a produced answer to the golden one (normalized, case-insensitive). */
export function answerMatchesGolden(produced: string, golden: string): boolean {
  const norm = (s: string) =>
    String(s || '')
      .toLowerCase()
      .replace(/\s+/g, ' ')
      .replace(/[.,;:!؟?]+$/g, '')
      .trim();
  if (!norm(produced) || !norm(golden)) return false;
  if (norm(produced) === norm(golden)) return true;
  // Option-KEY equivalence: produced 'b' vs golden 'goes' is resolved by the
  // caller (the draft value is the candidate text); bare-key comparison here
  // covers golden keys stored as letters.
  return false;
}

/** Build the measured report from samples (pure math + policy). */
export function buildCalibrationReport(
  samples: CalibrationSample[],
  opts: { digestVersion?: string; weightsVersion?: string; promptVersion?: string; threshold?: number; minCell?: number } = {},
): CalibrationReport {
  const threshold = opts.threshold ?? CALIBRATION_THRESHOLD;
  const minCell = opts.minCell ?? CALIBRATION_MIN_CELL;
  const byCat = new Map<string, { n: number; correct: number }>();
  for (const s of samples) {
    const cat = calibrationCategoryOf(s.kind, s.cognitive);
    const cell = byCat.get(cat) || { n: 0, correct: 0 };
    cell.n++;
    if (answerMatchesGolden(s.produced, s.golden)) cell.correct++;
    byCat.set(cat, cell);
  }
  const categories: CalibrationCategory[] = [...byCat.entries()]
    .map(([category, cell]) => ({
      category,
      n: cell.n,
      correct: cell.correct,
      accuracy: cell.n > 0 ? Math.round((cell.correct / cell.n) * 1000) / 1000 : 0,
      autoAcceptable: cell.n >= minCell && cell.correct / cell.n >= threshold,
    }))
    .sort((a, b) => a.category.localeCompare(b.category));
  return {
    ranAt: new Date().toISOString(),
    digestVersion: opts.digestVersion ?? DIGEST_VERSION,
    weightsVersion: opts.weightsVersion ?? DEFAULT_WEIGHTS_VERSION,
    promptVersion: opts.promptVersion ?? CALIBRATION_PROMPT_VERSION,
    threshold,
    minCell,
    categories,
  };
}

/** Version binding: a report from another tuple authorizes NOTHING. */
export function reportIsCurrent(report: CalibrationReport): boolean {
  return (
    report.digestVersion === DIGEST_VERSION &&
    report.weightsVersion === DEFAULT_WEIGHTS_VERSION &&
    report.promptVersion === CALIBRATION_PROMPT_VERSION
  );
}

/** The lookup the review grid uses before auto-accepting a row. */
export function autoAcceptAllowed(report: CalibrationReport | null | undefined, category: string): boolean {
  if (!report || !reportIsCurrent(report)) return false;
  const cell = report.categories.find((c) => c.category === category);
  return !!cell?.autoAcceptable;
}

/**
 * BULK-ACCEPT refusal rules (M4, the amended plan §6.3 a-d). A question may
 * be bulk-accepted ONLY when ALL of these hold:
 *   (a) its category is calibrated-above-threshold with a current report;
 *   (b) the keyword cross-check did NOT flag it;
 *   (c) its cognitive level is NOT application (those route to R3/human);
 *   (d) it is NOT a bucket-B free-text answer (free text never auto-accepts);
 *   + no pending mediation, a draft exists, and the draft is not empty.
 * Individual (non-bulk) human decisions are NEVER restricted by this —
 * bulk-accept is the only thing the gate limits.
 */
export function bulkAcceptAllowed(
  q: import('../types/exam').QuestionItem,
  report: CalibrationReport | null | undefined,
): boolean {
  if (!q.answer || !q.answer.value) return false;
  if (q.answerMediation && q.answerMediation.status === 'pending') return false;
  if (q.correctAnswer) return false; // already answered
  const bucket = classifyBucket(q);
  if (bucket === 'B') return false; // (d) free-text: human weight is highest
  if (q.attribution?.cognitive === 'application') return false; // (c)
  if (q.attribution?.supportFlag) return false; // (b)
  const kind: CalibrationSample['kind'] = bucket === 'A' ? 'choice' : 'free-text';
  return autoAcceptAllowed(report, calibrationCategoryOf(kind, q.attribution?.cognitive)); // (a)
}
