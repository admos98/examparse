/**
 * codecFeatures.ts — W1 SEMANTIC CODEC, shared feature layer.
 *
 * The codec is the first stage of the Specialist architecture: a tiny
 * char-level classifier that maps EVERY line of an exam document into a
 * closed alphabet of structural symbols. Its output stream is the "text"
 * that the W2 structure transformer reads — a language of exams instead of
 * a language of words.
 *
 * This module owns everything the trainer and the runtime must agree on
 * byte-for-byte:
 *   - text normalization (digits, NFKC, both storage orders for Persian)
 *   - the closed alphabets (ROLE / SUBJECT / INSTRUCTION axes)
 *   - the discrete feature vocabulary (geometry tokens + lexical flags)
 *   - FNV-1a hashing into the shared embedding index
 *
 * NO weights live here — the trainer imports this before codecWeights.ts
 * exists, and the runtime imports it together with the weights. Teacher
 * labels (brain receipts, GTs) are NEVER a feature: the student only sees
 * what a deployed BrainDoc can compute on its own.
 */

import type { BrainDoc, BrainLine, BrainPage } from './layoutBrain';
import { toLatinDigits } from './layoutBrain';

// ---------------------------------------------------------------- alphabets

/** ROLE axis — the primary structural symbol of a line. */
export const ROLES = [
  'FURN', // print furniture: page headers/footers, page numbers, dates, stamps
  'SUBJ', // subject / section header line
  'ROW', // row opener (lettered or numeric radif): carries the row identity
  'MARK', // marks-strip line: بارم token, mark cell, marks-table row content
  'OPT', // MCQ option line
  'INSTR', // instruction line (no row identity of its own)
  'STEM', // question stem / content line inside a row
  'PASS', // reading/listening passage prose
  'WORD', // word-bank / vocabulary list item
  'KEY', // answer-key sheet line
  'TOTAL', // جمع بارم / totals row
  'IDX', // bare index digit (strip furniture outside marks tables)
] as const;
export type Role = (typeof ROLES)[number];
export const N_ROLES = ROLES.length;

/** SUBJECT axis — the current section's subject (propagated downstream). */
export const SUBJECTS = [
  'none',
  'Vocabulary',
  'Grammar',
  'Reading',
  'Writing',
  'Listening',
  'Speaking',
  'Pronunciation',
  'Function',
] as const;
export type Subj = (typeof SUBJECTS)[number];
export const N_SUBJ = SUBJECTS.length;

/** INSTRUCTION axis — what the nearest instruction tells the student to do. */
export const INSTRS = [
  'none',
  'fillin',
  'mcq',
  'match',
  'cloze',
  'truefalse',
  'define',
  'write',
  'translate',
  'other',
] as const;
export type Instr = (typeof INSTRS)[number];
export const N_INSTRS = INSTRS.length;

// ------------------------------------------------------------- normalization

const nfkc = (s: string) => {
  try {
    return s.normalize('NFKC');
  } catch {
    return s;
  }
};

/** Normalized view used for char n-grams: latin digits, NFKC, squeezed space. */
export function normText(s: string): string {
  return nfkc(toLatinDigits(s)).replace(/\s+/g, ' ').trim();
}

// --------------------------------------------------------------- hashing

/** FNV-1a 32-bit — identical in trainer and runtime, no deps. */
export function fnv1a(str: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
  }
  return h >>> 0;
}

/** Hash a feature token into the shared index (bucket space = CODEC_DIM). */
export function hashToken(t: string, dim: number): number {
  return fnv1a(t) % dim;
}

// ------------------------------------------------- instruction lexicon (dev)

type LexEntry = { instr: Instr; keys: string[] };
const INSTR_LEXICON: LexEntry[] = [
  {
    instr: 'fillin',
    keys: ['جاهای خالی', 'جا های خالی', 'جاهای خالی', 'پر کنید', 'پرکنید', 'fill in', 'complete the', 'blank'],
  },
  {
    instr: 'mcq',
    keys: ['گزینه', 'انتخاب کنید', 'مناسب ترین', 'مناسب‌ترین', 'صحیح', 'گدام', 'choose', 'choose the best', 'select'],
  },
  { instr: 'match', keys: ['وصل کنید', 'طاب', 'طبقه بندی', 'match', 'connect', 'related'] },
  { instr: 'cloze', keys: ['cloze', 'متن زیر', 'read the text', 'text below'] },
  { instr: 'truefalse', keys: ['true', 'false', 'درست', 'غلط', 'نادرست'] },
  {
    instr: 'define',
    keys: ['تعریف', 'define', 'معنی', 'متظادل', 'مترادف', 'opposite', 'synonym', 'definition'],
  },
  { instr: 'write', keys: ['بنویسید', 'بنویس', 'write', 'تولید کنید'] },
  { instr: 'translate', keys: ['ترجمه', 'translate'] },
  {
    instr: 'other',
    keys: ['با توجه به', 'according to', 'به تصویر', 'look at', 'به تلفظ', 'listen', 'گوش کنید', 'sentence'],
  },
];

/** Best instruction hit for a normalized line (checked in both orders). */
export function matchInstr(normed: string): Instr {
  const t = normed.toLowerCase();
  const rev = t.split('').reverse().join('');
  for (const { instr, keys } of INSTR_LEXICON) {
    for (const k of keys) {
      const kk = k.toLowerCase();
      if (t.includes(kk) || rev.includes(kk)) return instr;
    }
  }
  return 'none';
}

// -------------------------------------------------------- geometry features

export interface LineGeom {
  page: number;
  sizeRatio: number; // line size / body size
  bold: boolean;
  xRatio: number; // 0..1 center position across the page
  yRatio: number; // 0..1 center position down the page
  widthRatio: number; // line width / page width
  inTable: boolean;
  tableKind: string | null; // classified kind when inTable (marksTable etc.)
  boxedCell: boolean;
  ruleBelow: boolean; // a rule crosses within a few px below the line
  ruleAbove: boolean;
  firstOnPage: boolean;
  lastOnPage: boolean;
  pagePos: 'first' | 'mid' | 'last'; // document position of the page
  docFrac: number; // 0..1 global position of the line in the document
}

/**
 * Deterministic geometry features for one line, computed from the BrainDoc
 * alone (never from brain decisions). Cheap: O(lines x tables).
 * @param docFrac global line position / total lines (caller computes it)
 */
export function extractGeom(doc: BrainDoc, line: BrainLine, bodySize: number, docFrac = 0): LineGeom {
  const page: BrainPage | undefined = doc.pages[line.page];
  const w = page?.width || 595;
  const h = page?.height || 842;
  const x0 = line.bbox[0],
    y0 = line.bbox[1],
    x1 = line.bbox[2],
    y1 = line.bbox[3];
  const xc = (x0 + x1) / 2;
  const yc = (y0 + y1) / 2;

  let inTable = false;
  let tableKind: string | null = null;
  let boxedCell = false;
  for (const t of page?.tables ?? []) {
    const b = t.bbox;
    if (xc >= b[0] && xc <= b[2] && yc >= b[1] && yc <= b[3]) {
      inTable = true;
      tableKind = (t as { kind?: string }).kind ?? null;
      // boxed cell: a rect whose center sits inside the same cell region
      for (const r of page?.rects ?? []) {
        const rcx = (r[0] + r[2]) / 2,
          rcy = (r[1] + r[3]) / 2;
        if (rcx >= x0 - 2 && rcx <= x1 + 2 && rcy >= y0 - 2 && rcy <= y1 + 2) {
          boxedCell = true;
          break;
        }
      }
      break;
    }
  }

  let ruleBelow = false;
  let ruleAbove = false;
  for (const hl of page?.hlines ?? []) {
    const hy = hl[1];
    const covers = hl[0] <= x1 && hl[0] + hl[2] >= x0; // rule spans the line
    if (!covers) continue;
    if (Math.abs(hy - y1) <= 6) ruleBelow = true;
    if (Math.abs(hy - y0) <= 6) ruleAbove = true;
  }

  const pagePos: 'first' | 'mid' | 'last' =
    line.page === 0 ? 'first' : line.page === doc.pages.length - 1 ? 'last' : 'mid';

  return {
    page: line.page,
    sizeRatio: bodySize > 0 ? line.size / bodySize : 1,
    bold: line.bold,
    xRatio: xc / w,
    yRatio: yc / h,
    widthRatio: Math.max(0, x1 - x0) / w,
    inTable,
    tableKind,
    boxedCell,
    ruleBelow,
    ruleAbove,
    firstOnPage: yc <= h * 0.08,
    lastOnPage: yc >= h * 0.92,
    pagePos,
    docFrac,
  };
}

/**
 * Discrete feature tokens for one line — the codec's full input vocabulary.
 * Char n-grams (1..3) of BOTH storage orders + geometry + lexical flags,
 * all hashed at training/runtime into CODEC_DIM buckets by the caller.
 *
 * SELF-CONTAINED by contract: everything derives from the raw line text and
 * its geometry, so the trainer (this repo) and the deployed runtime cannot
 * diverge — no brain decisions, no perception sets, just surface + layout.
 */
export function featureTokens(raw: string, geom: LineGeom): string[] {
  const t = normText(raw);
  const tokens: string[] = [];

  // char n-grams, both orders (Persian may be stored visually reversed)
  const rev = t.split('').reverse().join('');
  for (const src of [t, rev]) {
    const n = src.length;
    for (let i = 0; i < n; i++) {
      tokens.push('c1:' + src[i]);
      if (i + 1 < n) tokens.push('c2:' + src.slice(i, i + 2));
      if (i + 2 < n) tokens.push('c3:' + src.slice(i, i + 3));
    }
    if (n === 0) tokens.push('c0:empty');
  }

  // geometry buckets
  const sr = geom.sizeRatio;
  const sz = sr < 0.85 ? 0 : sr < 1.12 ? 1 : sr < 1.4 ? 2 : 3;
  tokens.push(`G:sz${sz}`);
  if (geom.bold) tokens.push('G:bold');
  const xb = Math.min(4, Math.max(0, Math.floor(geom.xRatio * 5)));
  tokens.push(`G:x${xb}`);
  const yb = Math.min(4, Math.max(0, Math.floor(geom.yRatio * 5)));
  tokens.push(`G:y${yb}`);
  const wb = geom.widthRatio < 0.12 ? 0 : geom.widthRatio < 0.35 ? 1 : geom.widthRatio < 0.7 ? 2 : 3;
  tokens.push(`G:w${wb}`);
  tokens.push(`G:pg${geom.pagePos === 'first' ? 0 : geom.pagePos === 'mid' ? 1 : 2}`);
  if (geom.inTable) tokens.push('G:tbl');
  if (geom.tableKind === 'marksTable') tokens.push('G:mtbl');
  else if (geom.tableKind === 'bubbleGrid') tokens.push('G:bubble');
  else if (geom.tableKind === 'matchingLayout') tokens.push('G:match');
  else if (geom.tableKind === 'contentTable') tokens.push('G:ctbl');
  const dfB = Math.min(9, Math.floor(geom.docFrac * 10));
  tokens.push(`G:df${dfB}`);
  if (geom.boxedCell) tokens.push('G:box');
  if (geom.ruleBelow) tokens.push('G:ruleB');
  if (geom.ruleAbove) tokens.push('G:ruleA');
  if (geom.firstOnPage) tokens.push('G:top');
  if (geom.lastOnPage) tokens.push('G:bot');

  // lexical flags
  const digits = (t.match(/\d/g) ?? []).length;
  const digB = digits === 0 ? 0 : digits <= 2 ? 1 : digits <= 5 ? 2 : 3;
  tokens.push(`L:dg${digB}`);
  // margin bare digit = page number (mirrors perceive()'s deterministic rule)
  if (/^\d{1,3}$/.test(t) && (geom.yRatio < 0.085 || geom.yRatio > 0.925)) tokens.push('L:pgnum');
  if (hasMarkPattern(t)) tokens.push('L:barm');
  if (/^\(?([A-Z]|الف|هـ|[\u0621-\u064A])[).:ـ]/.test(t)) tokens.push('L:letter');
  if (/\.{4,}|…{2,}/.test(t)) tokens.push('L:dots');
  if (/[،;:]$/.test(t)) tokens.push('L:colon');
  if (/[؟?]$/.test(t)) tokens.push('L:qmark');
  if (/["«»""]/.test(t)) tokens.push('L:quote');
  if (/^\d{1,3}[).\-:]/.test(t)) tokens.push('L:numstart');
  const words = t ? t.split(' ').length : 0;
  tokens.push(`L:ln${words === 0 ? 0 : words <= 3 ? 1 : words <= 8 ? 2 : words <= 16 ? 3 : 4}`);

  return tokens;
}

/** Shared check: does this line carry a بارم-style mark pattern? */
export function hasMarkPattern(normed: string): boolean {
  return /بارم|نمره/.test(normed) || /^\d{1,2}(\.\d)?$/i.test(normed.trim());
}

/**
 * Token weight in the hashed mean: high-signal discrete features (geometry
 * buckets, lexical flags) must not drown in hundreds of char n-grams.
 * SHARED by trainer and runtime — changing this changes the model contract.
 */
export function tokenWeight(tok: string): number {
  if (tok.startsWith('G:')) return 6;
  if (tok.startsWith('L:')) return 10;
  return 1;
}

/**
 * Geometry summary token for the W2 structure transformer: a compact,
 * bucketed description of ONE line's layout context. The transformer reads
 * it as an extra input channel next to the codec's role/subject/instruction
 * symbols. SHARED trainer/runtime — same contract as featureTokens.
 */
export function geomSummaryToken(geom: LineGeom, normed: string): string {
  const sr = geom.sizeRatio;
  const sz = sr < 0.85 ? 0 : sr < 1.12 ? 1 : sr < 1.4 ? 2 : 3;
  const xb = Math.min(4, Math.max(0, Math.floor(geom.xRatio * 5)));
  const yb = Math.min(4, Math.max(0, Math.floor(geom.yRatio * 5)));
  const wb = geom.widthRatio < 0.12 ? 0 : geom.widthRatio < 0.35 ? 1 : geom.widthRatio < 0.7 ? 2 : 3;
  const dg = (normed.match(/\d/g) ?? []).length;
  const digB = dg === 0 ? 0 : dg <= 2 ? 1 : dg <= 5 ? 2 : 3;
  const dfB = Math.min(9, Math.floor(geom.docFrac * 10));
  const tk = geom.tableKind === 'marksTable' ? 'm' : geom.tableKind === 'bubbleGrid' ? 'b' : geom.tableKind === 'matchingLayout' ? 'l' : geom.tableKind === 'contentTable' ? 'c' : geom.inTable ? 't' : '-';
  return [
    `g${sz}`,
    geom.bold ? 'B1' : 'B0',
    `x${xb}`,
    `y${yb}`,
    `w${wb}`,
    tk,
    geom.ruleBelow ? 'r1' : 'r0',
    geom.ruleAbove ? 'a1' : 'a0',
    `d${digB}`,
    `f${dfB}`,
    /\.{4,}|…{2,}/.test(normed) ? 'D1' : 'D0',
    /بارم|نمره/.test(normed) ? 'M1' : 'M0',
    /^\d{1,3}$/.test(normed) && (geom.yRatio < 0.085 || geom.yRatio > 0.925) ? 'P1' : 'P0',
  ].join('');
}

/** Body text size of a document: the length-weighted most-common rounded
 * size. Shared by trainer and runtime so sizeRatio buckets never diverge.
 */
export function bodySizeOf(doc: BrainDoc): number {
  const w = new Map<number, number>();
  for (const p of doc.pages)
    for (const l of p.lines) {
      const k = Math.round(l.size * 2) / 2;
      const len = Math.max(4, l.text.length);
      w.set(k, (w.get(k) ?? 0) + len);
    }
  let best = 12;
  let bw = -1;
  for (const [k, v] of w) {
    if (v > bw) {
      bw = v;
      best = k;
    }
  }
  return best;
}
