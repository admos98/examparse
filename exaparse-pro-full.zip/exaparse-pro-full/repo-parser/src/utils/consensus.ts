import { ConsensusCheck, ConsensusReport, ExamDocument } from '../types/exam';
import { parseExamRawText } from './parserEngine';
import { runOfflineOcr, extractTextFromDocx } from './fileExtractor';
import { normalizeForFingerprint } from './answerCache';

/**
 * Dual-extraction consensus — RAID for OCR.
 *
 * Two INDEPENDENT offline extraction paths are run over the same source:
 *   - Digital PDFs:  text layer  vs.  render + OCR
 *   - Scans/images:  OCR @ PSM 3 vs.  OCR @ PSM 6
 * The parsed ASTs are diffed question-by-question. Agreement = green lock.
 * Only disagreements are surfaced. Zero AI tokens, pure cross-validation.
 */

export interface ConsensusRunResult {
  report: ConsensusReport | null;
  message?: string;
}

export type ConsensusProgress = (status: string, percent?: number) => void;

function stemKey(stem: string): string {
  return normalizeForFingerprint(stem.replace(/^\s*\d{1,3}\s*[\.\)\-]\s*/, '')).slice(0, 80);
}

function tokens(text: string): Set<string> {
  return new Set(normalizeForFingerprint(text).split(' ').filter((t) => t.length > 1));
}

function similarity(a: string, b: string): number {
  const ta = tokens(a);
  const tb = tokens(b);
  if (ta.size === 0 || tb.size === 0) return 0;
  let inter = 0;
  for (const t of ta) if (tb.has(t)) inter++;
  return inter / (ta.size + tb.size - inter);
}

/** Build a lookup of question number -> question for comparison. */
function questionIndex(doc: ExamDocument): Map<string, { stem: string; answerCount: number; sectionRowId: string }> {
  const idx = new Map<string, { stem: string; answerCount: number; sectionRowId: string }>();
  for (const sec of doc.sections) {
    for (const q of sec.questions) {
      const key = `${sec.rowId}/${q.displayNumber}`;
      idx.set(key, {
        stem: q.stem || '',
        answerCount: q.options?.length || 0,
        sectionRowId: sec.rowId,
      });
    }
  }
  return idx;
}

export function diffAsts(docA: ExamDocument, docB: ExamDocument, method: string): ConsensusReport {
  const idxA = questionIndex(docA);
  const idxB = questionIndex(docB);
  const checks: ConsensusCheck[] = [];
  const paths = new Set<string>([...idxA.keys(), ...idxB.keys()]);

  for (const path of paths) {
    const a = idxA.get(path);
    const b = idxB.get(path);
    if (!a && b) {
      checks.push({ path, a: '(missing)', b: b.stem.slice(0, 80), agree: false, similarity: 0 });
      continue;
    }
    if (a && !b) {
      checks.push({ path, a: a.stem.slice(0, 80), b: '(missing)', agree: false, similarity: 0 });
      continue;
    }
    if (!a || !b) continue;

    const stemSim = similarity(a.stem, b.stem);
    const optAgree = a.answerCount === 0 || b.answerCount === 0 ? true : Math.abs(a.answerCount - b.answerCount) === 0;
    const agree = stemSim >= 0.75 && optAgree;
    checks.push({
      path,
      a: a.stem.slice(0, 80),
      b: b.stem.slice(0, 80),
      agree,
      similarity: Math.round(stemSim * 100) / 100,
    });
  }

  const agreements = checks.filter((c) => c.agree).length;
  return {
    ranAt: new Date().toISOString(),
    method,
    agreementRate: checks.length > 0 ? Math.round((agreements / checks.length) * 1000) / 10 : 0,
    disagreements: checks.length - agreements,
    checks,
  };
}

/**
 * Run the two-path consensus over a source file. Returns null report when the
 * format can't support dual paths (e.g. plain text).
 */
export async function runConsensusCheck(
  file: Blob | File,
  onProgress?: ConsensusProgress,
): Promise<ConsensusRunResult> {
  const name = (file as File).name?.toLowerCase() || '';
  const isPdf = name.endsWith('.pdf') || (file as Blob).type === 'application/pdf';
  const isImage =
    name.endsWith('.png') || name.endsWith('.jpg') || name.endsWith('.jpeg') ||
    name.endsWith('.webp') || name.endsWith('.bmp') || name.endsWith('.tiff') ||
    (file as Blob).type?.startsWith('image/');
  const isDocx = name.endsWith('.docx');

  try {
    if (isDocx) {
      // DOCX has a single deterministic XML path — a second path would be identical.
      return { report: null, message: 'DOCX files have a single deterministic extraction path — consensus applies to PDFs and scans.' };
    }

    if (isPdf) {
      onProgress?.('Path A: extracting the digital text layer...', 10);
      const { extractTextFromPdf } = await import('./fileExtractor');
      const buffer = await file.arrayBuffer();
      const textA = await extractTextFromPdf(buffer.slice(0), (s, p) => onProgress?.(s, (p || 0) / 2));
      const hasTextLayer = textA && textA.length >= 30 && !textA.includes('Page Break');

      if (hasTextLayer) {
        onProgress?.('Path B: rendering + OCR of the same pages...', 50);
        const textB = await ocrWholePdf(buffer.slice(0), (s, p) => onProgress?.(s, 50 + (p || 0) / 2));
        return finish(textA, textB, 'pdf_text_layer_vs_ocr');
      }
      // Scanned PDF: OCR twice with different segmentation modes
      onProgress?.('Path A: OCR pass 1 (auto page segmentation)...', 10);
      const textA2 = await ocrWholePdf(buffer.slice(0), (s, p) => onProgress?.(s, (p || 0) / 2), '3');
      onProgress?.('Path B: OCR pass 2 (single-column segmentation)...', 50);
      const textB2 = await ocrWholePdf(buffer.slice(0), (s, p) => onProgress?.(s, 50 + (p || 0) / 2), '6');
      return finish(textA2, textB2, 'ocr_psm3_vs_psm6');
    }

    if (isImage) {
      onProgress?.('Path A: OCR pass 1 (auto page segmentation)...', 10);
      const textA = await runOfflineOcr(file, undefined, { psm: '3' });
      onProgress?.('Path B: OCR pass 2 (single-column segmentation)...', 50);
      const textB = await runOfflineOcr(file, undefined, { psm: '6' });
      return finish(textA, textB, 'ocr_psm3_vs_psm6');
    }

    return { report: null, message: 'Consensus requires a PDF or image source.' };
  } catch (err: any) {
    return { report: null, message: `Consensus check failed: ${err?.message || err}` };
  }
}

function finish(textA: string, textB: string, method: string): ConsensusRunResult {
  onProgressFinish();
  const docA = parseExamRawText(textA, 'path-a');
  const docB = parseExamRawText(textB, 'path-b');
  const report = diffAsts(docA, docB, method);
  return { report };
}

function onProgressFinish() {
  // hook point for future progress reporting; keeps finish() signature stable
}

async function ocrWholePdf(
  data: ArrayBuffer,
  onProgress?: ConsensusProgress,
  psm: string = '3',
): Promise<string> {
  const pdfjsLib = await import('pdfjs-dist');
  const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(data), useSystemFonts: true });
  const pdf = await loadingTask.promise;
  const pageTexts: string[] = [];

  for (let i = 1; i <= pdf.numPages; i++) {
    onProgress?.(`Rendering + OCR page ${i}/${pdf.numPages}...`, Math.round((i / pdf.numPages) * 100));
    const page = await pdf.getPage(i);
    const viewport = page.getViewport({ scale: 2.0 });
    const canvas = document.createElement('canvas');
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) continue;
    await page.render({ canvasContext: ctx, viewport, canvas } as any).promise;
    const text = await runOfflineOcr(canvas, undefined, { psm });
    if (text.trim()) pageTexts.push(text.trim());
  }
  return pageTexts.join('\n\n');
}
