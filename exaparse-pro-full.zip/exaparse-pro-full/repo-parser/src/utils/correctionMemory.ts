import { kvGet, kvSet } from './localStore';
import { normalizeForFingerprint } from './answerCache';

/**
 * Correction memory — the compounding-moat feature.
 *
 * Every human fix (redline approve/reject, manual answer edit) is recorded as
 * an exemplar. On the next solve, the most similar past corrections for the
 * same school/teacher are injected into the AI prompt as few-shot examples.
 * Tiny token cost, compounding accuracy: the system learns *this* exam style.
 */

const LIST_KEY = 'corrections:list';
const MAX_EXEMPLARS = 2000;

export interface CorrectionExemplar {
  id: string;
  questionType: string;
  stem: string; // raw stem at correction time
  before: string;
  after: string;
  field: 'correctAnswer' | 'type';
  examId?: string;
  schoolName?: string;
  createdAt: string;
}

export async function recordCorrection(
  exemplar: Omit<CorrectionExemplar, 'id' | 'createdAt'> & { id?: string },
): Promise<CorrectionExemplar> {
  const list = await getAllCorrections();
  const full: CorrectionExemplar = {
    ...exemplar,
    id: exemplar.id || `corr-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
    createdAt: new Date().toISOString(),
  };
  list.unshift(full);
  if (list.length > MAX_EXEMPLARS) list.length = MAX_EXEMPLARS;
  await kvSet(LIST_KEY, list);
  return full;
}

export async function getAllCorrections(): Promise<CorrectionExemplar[]> {
  const list = await kvGet<CorrectionExemplar[]>(LIST_KEY);
  return Array.isArray(list) ? list : [];
}

export async function clearCorrections(): Promise<void> {
  await kvSet(LIST_KEY, []);
}

/** 0..1 token-Jaccard similarity on normalized text. */
function similarity(a: string, b: string): number {
  const ta = new Set(normalizeForFingerprint(a).split(' ').filter(Boolean));
  const tb = new Set(normalizeForFingerprint(b).split(' ').filter(Boolean));
  if (ta.size === 0 || tb.size === 0) return 0;
  let inter = 0;
  for (const t of ta) if (tb.has(t)) inter++;
  return inter / (ta.size + tb.size - inter);
}

/**
 * Retrieve the k most similar past corrections for a given stem.
 * Same question type gets a +0.15 boost.
 */
export async function findSimilarExemplars(
  stem: string,
  questionType: string,
  k = 3,
): Promise<CorrectionExemplar[]> {
  const list = await getAllCorrections();
  if (list.length === 0) return [];
  const scored = list
    .map((c) => ({
      c,
      score: similarity(stem, c.stem) + (c.questionType === questionType ? 0.15 : 0),
    }))
    .filter((x) => x.score >= 0.25)
    .sort((a, b) => b.score - a.score)
    .slice(0, k);
  return scored.map((x) => x.c);
}

/**
 * Pick the most relevant exemplars for a whole exam (dedup by id, cap at max).
 * The client sends these with the solve request; the server few-shots them.
 */
export async function findExemplarsForDocument(
  questions: { stem: string; type: string }[],
  max = 20,
): Promise<CorrectionExemplar[]> {
  const list = await getAllCorrections();
  if (list.length === 0 || questions.length === 0) return [];

  const scoreById = new Map<string, number>();
  for (const q of questions) {
    for (const c of list) {
      const s = similarity(q.stem, c.stem) + (c.questionType === q.type ? 0.15 : 0);
      if (s >= 0.2) {
        scoreById.set(c.id, Math.max(scoreById.get(c.id) || 0, s));
      }
    }
  }
  return [...scoreById.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, max)
    .map(([id]) => list.find((c) => c.id === id)!)
    .filter(Boolean);
}
