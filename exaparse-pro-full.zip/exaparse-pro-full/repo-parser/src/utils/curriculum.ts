import digestJson from '../../data/curriculum-digest-v2.json';

/**
 * M3 curriculum integration — the digest asset, the grade resolver, and the
 * deterministic keyword cross-check.
 *
 * The digest (data/curriculum-digest-v2.json) is book-sourced ground truth:
 * every lesson's title, function, grammar, reading passage, pronunciation,
 * listening/speaking topic and keywords, read from the official 1405-1406
 * student books. It rides ONE grade per judge call as Choice criteria
 * (~0.6-1.1K tokens per grade) and powers:
 *   - l1:/l2: lesson attribution Choices (criteria = the grade's lessons)
 *   - b: in-book provenance Choice (in-book inventory = the tested
 *     vocabulary/grammar of these lessons — NEVER passage provenance)
 *   - the deterministic keyword cross-check (zero-support pick -> flag)
 *
 * digestVersion rides every attribution cache key, so a digest edit
 * invalidates stale attributions without re-billing AI for unchanged content.
 */

export interface CurriculumLesson {
  title: string;
  function?: string;
  grammar?: string[];
  reading?: string;
  writingFocus?: string;
  pronunciation?: string;
  melody?: string;
  sounds?: string;
  listeningSpeaking?: string;
  conversation?: string;
  readingStrategy?: string;
  vocabDevelopment?: string;
  vocabOfficial?: string[];
  keywords?: string;
  choiceDescription?: string;
}

export interface CurriculumGrade {
  book: string;
  bookCode?: string;
  lessonCount: number;
  aliases: string[];
  lessons: Record<string, CurriculumLesson>;
  lessonParts?: string[];
}

export interface CurriculumDigest {
  version: number;
  digestVersion: string;
  grades: Record<string, CurriculumGrade>;
}

export const DIGEST: CurriculumDigest = digestJson as unknown as CurriculumDigest;
export const DIGEST_VERSION = DIGEST.digestVersion;
export const GRADE_KEYS = Object.keys(DIGEST.grades);

// ---------- grade resolver ----------

export type ResolveStatus = 'resolved' | 'ambiguous' | 'unknown';

export interface GradeResolution {
  status: ResolveStatus;
  /** The resolved grade key (english_7th_grade style) when status is resolved. */
  key?: string;
  /** Multiple plausible keys — the UI asks the human to confirm. */
  candidates?: string[];
}

const normalize = (s: unknown): string =>
  String(s ?? '')
    // unify Persian/Arabic ye & kaf + strip ZWNJ/diacritics
    .replace(/[\u064A\u0649]/g, '\u06CC')
    .replace(/\u0643/g, '\u06A9')
    .replace(/[\u200C\u200F\u200E]/g, '')
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();

const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';

function normalizeDigits(s: string): string {
  return s.replace(/[۰-۹]/g, (d) => String(FA_DIGITS.indexOf(d))).replace(/[٠-٩]/g, (d) => String(AR_DIGITS.indexOf(d)));
}

/** Score one field against every grade's aliases; exact alias match wins. */
function matchGrade(fields: string[]): Map<string, number> {
  const scores = new Map<string, number>();
  const normedFields = fields.map((f) => normalizeDigits(normalize(f))).filter((f) => f.length > 0);
  for (const key of GRADE_KEYS) {
    const grade = DIGEST.grades[key];
    const aliases = grade.aliases.map((a) => normalizeDigits(normalize(a)));
    // Numeric fallback: the grade NUMBER itself (7..12) as a standalone token.
    const gradeNum = key.match(/english_(\d+)(?:th|st|nd|rd)_grade/)?.[1];
    let score = 0;
    for (const field of normedFields) {
      for (let i = 0; i < aliases.length; i++) {
        const alias = aliases[i];
        if (!alias) continue;
        if (field === alias) score = Math.max(score, 100 - i); // exact alias hit
        else if (field.includes(alias) && alias.length >= 3) score = Math.max(score, 40 - i); // substring hit
        else if (alias.includes(field) && field.length >= 2 && /\d|م|th|st|nd|rd/i.test(field)) score = Math.max(score, 20);
      }
      if (gradeNum) {
        const digitHit = new RegExp(`(?<!\\d)${gradeNum}(?!\\d)`).test(field);
        if (digitHit) score = Math.max(score, 30);
      }
    }
    if (score > 0) scores.set(key, score);
  }
  return scores;
}

/**
 * Resolve the exam header to a digest grade. Deterministic; on ambiguity the
 * caller MUST ask the human (never guess — a wrong grade poisons attribution).
 */
export function resolveGrade(header: {
  grade?: string;
  gradeAndMajor?: string;
  courseName?: string;
  examName?: string;
}): GradeResolution {
  const scores = matchGrade([header.grade || '', header.gradeAndMajor || '', header.courseName || '', header.examName || '']);
  if (scores.size === 0) return { status: 'unknown' };
  const sorted = [...scores.entries()].sort((a, b) => b[1] - a[1]);
  const top = sorted[0];
  const tied = sorted.filter(([, s]) => s === top[1]);
  if (tied.length > 1) {
    return { status: 'ambiguous', candidates: tied.map(([k]) => k) };
  }
  return { status: 'resolved', key: top[0] };
}

// ---------- lesson helpers ----------

/** Ordered lesson keys of a grade (L1..., L2...). */
export function lessonKeys(gradeKey: string): string[] {
  return Object.keys(DIGEST.grades[gradeKey]?.lessons || {});
}

/** The Choice criteria for the l1: axis — full descriptions, one per lesson. */
export function lessonCriteria(gradeKey: string): Record<string, string> | null {
  const grade = DIGEST.grades[gradeKey];
  if (!grade) return null;
  const out: Record<string, string> = {};
  for (const [key, lesson] of Object.entries(grade.lessons)) {
    out[key] = lesson.choiceDescription || lesson.title;
  }
  return Object.keys(out).length > 0 ? out : null;
}

/** Lighter criteria for the l2: axis (secondary lesson) — key + title. */
export function lessonCriteriaLight(gradeKey: string): Record<string, string> | null {
  const grade = DIGEST.grades[gradeKey];
  if (!grade) return null;
  const out: Record<string, string> = {};
  for (const [key, lesson] of Object.entries(grade.lessons)) {
    out[key] = lesson.title;
  }
  out['none'] = 'No single second lesson — the item spans none / general review';
  return out;
}

/** In-book provenance criteria for the b: axis. */
export function provenanceCriteria(): Record<string, string> {
  return {
    in: 'In-book — the tested vocabulary/grammar/structure is taught in this grade\'s book lessons',
    mixed: 'Mixed — partly in-book, partly beyond it',
    out: 'Out-of-book — the tested material is not covered by the book lessons',
  };
}

/** Cognitive-level criteria for the c: axis. */
export function cognitiveCriteria(): Record<string, string> {
  return {
    recall: 'Recall — remember/recognize a memorized item (word, form, fact)',
    comprehension: 'Comprehension — understand and restate/apply a known rule or meaning',
    application: 'Application — produce/transform with the rule in a new step (multi-step reasoning)',
  };
}

// ---------- deterministic keyword cross-check ----------

/**
 * Count how many of the lesson's keywords actually appear in the question
 * text (stem + options + context). Normalized like the answer cache so
 * Persian/Arabic variants do not defeat the match. Zero hits is a STRONG
 * signal the attribution is wrong (the flag asks a human to look).
 */
export function keywordSupport(questionText: string, gradeKey: string, lessonKey: string): number {
  const lesson = DIGEST.grades[gradeKey]?.lessons[lessonKey];
  if (!lesson) return 0;
  const words = new Set<string>();
  for (const kw of (lesson.keywords || '').split(',')) {
    const w = normalize(kw);
    if (w.length >= 3) words.add(w);
  }
  words.add(normalize(lesson.title));
  const text = normalizeDigits(normalize(questionText));
  if (!text) return 0;
  let hits = 0;
  for (const w of words) {
    if (text.includes(w)) hits++;
  }
  return hits;
}
