/**
 * Black Box (#19) — a local, private flight recorder for the parse path.
 *
 * Every parse attempt (success or failure) appends an anonymized entry to a
 * bounded ring buffer in localStorage. When something mis-parses, the user
 * exports the black box and sends it — real bug reports WITHOUT a server and
 * WITHOUT shipping their exam to anyone by default.
 *
 * Privacy: only the first 240 chars of normalized text are kept, non-ASCII
 * characters are preserved (they're exam content, not PII) but names/schools
 * in the header area are NOT specially protected — the buffer lives only in
 * the user's own browser until THEY choose to export it.
 */

const KEY = 'exaparse_blackbox';
const MAX_ENTRIES = 60;

export type BlackBoxEvent =
  | 'parse_start'
  | 'parse_success'
  | 'parse_error'
  | 'extraction_fallback'
  | 'eqs_poor'
  | 'answer_key_detected'
  | 'consensus_run'
  | 'adjudicate_run'
  | 'migrate'
  | 'layout_brain_applied'
  | 'layout_brain_failed';

export interface BlackBoxEntry {
  at: string;
  event: BlackBoxEvent;
  filename?: string;
  detail?: string;
  /** First chars of the normalized text (for reproducing parse bugs). */
  snippet?: string;
  /** Numbers that matter: question counts, EQS, etc. */
  metrics?: Record<string, number>;
}

function readAll(): BlackBoxEntry[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeAll(entries: BlackBoxEntry[]): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(entries.slice(-MAX_ENTRIES)));
  } catch {
    // Storage full or unavailable — black box is best-effort by design.
  }
}

export function logBlackBox(entry: Omit<BlackBoxEntry, 'at'>): void {
  const full: BlackBoxEntry = { ...entry, at: new Date().toISOString() };
  const all = readAll();
  all.push(full);
  writeAll(all);
}

export function getBlackBox(): BlackBoxEntry[] {
  return readAll();
}

export function clearBlackBox(): void {
  try {
    localStorage.removeItem(KEY);
  } catch {
    // ignore
  }
}

/** Download the black box as a JSON file the user can attach to a bug report. */
export function exportBlackBox(): void {
  const entries = readAll();
  const blob = new Blob([JSON.stringify({ app: 'ExaParse Pro', exportedAt: new Date().toISOString(), entries }, null, 2)], {
    type: 'application/json',
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `exaparse-blackbox-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

// ---------------------------------------------------------------------------
// Crash-safe resume (#19): remember the last active session so the user gets
// a "Resumed — your work was saved at HH:MM" banner after a crash or reload.
// ---------------------------------------------------------------------------

const RESUME_KEY = 'exaparse_last_session';

export interface ResumeState {
  at: string;
  activeDocId?: string;
  screen?: string;
}

export function saveResumeState(state: Omit<ResumeState, 'at'>): void {
  try {
    localStorage.setItem(RESUME_KEY, JSON.stringify({ ...state, at: new Date().toISOString() }));
  } catch {
    // ignore
  }
}

export function loadResumeState(): ResumeState | null {
  try {
    const raw = localStorage.getItem(RESUME_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as ResumeState;
    // Only offer resume for recent sessions (< 48h).
    if (parsed.at && Date.now() - new Date(parsed.at).getTime() < 48 * 3600 * 1000) return parsed;
    return null;
  } catch {
    return null;
  }
}

export function clearResumeState(): void {
  try {
    localStorage.removeItem(RESUME_KEY);
  } catch {
    // ignore
  }
}
