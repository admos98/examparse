import { DifficultyScore } from '../types/exam';

/**
 * M3 difficulty calculator — a PURE deterministic function over typed AI
 * signals + configurable weights. Jev returns SIGNALS (lesson span, provenance,
 * cognitive level); the app computes the score. Re-tuning the weights re-scores
 * the library WITHOUT re-billing any AI call (that's why the weights live
 * client-side and weightsVersion rides the display cache).
 *
 * Default formula (all configurable):
 *   score = base(30)
 *         + lesson span   {1 lesson: 0, 2 lessons: +15, 3+: +25}
 *         + provenance    {in-book: 0, mixed: +10, out-of-book: +20}
 *         + cognitive     {recall: 0, comprehension: +15, application: +30}
 *         + availability  {verbatim: 0, transformation: +10}
 *         + mark pressure {0..8  — the exam's own mark vs the exam median}
 *         + linguistic load {0..7 — stem+passage length bucket}
 *   clamped to 0..100, banded easy(<40) / medium(40-69) / hard(>=70).
 *
 * Reliability ranking: lesson span > provenance > cognitive; availability is
 * a small refinement; mark/load are deterministic freebies. In-book is judged
 * over TESTED vocabulary/grammar only — passage provenance never counts.
 */

export interface DifficultyWeights {
  base: number;
  span2: number;
  span3: number;
  provMixed: number;
  provOut: number;
  cogComprehension: number;
  cogApplication: number;
  availTransformation: number;
  markMax: number;
  loadMax: number;
}

export const DEFAULT_WEIGHTS: DifficultyWeights = {
  base: 30,
  span2: 15,
  span3: 25,
  provMixed: 10,
  provOut: 20,
  cogComprehension: 15,
  cogApplication: 30,
  availTransformation: 10,
  markMax: 8,
  loadMax: 7,
};

export const DEFAULT_WEIGHTS_VERSION = 'w1';

export interface DifficultyInput {
  /** Count of distinct lessons the item spans (1, 2, 3+). */
  lessonSpan: 1 | 2 | 3;
  provenance?: 'in-book' | 'mixed' | 'out-of-book';
  cognitive?: 'recall' | 'comprehension' | 'application';
  /** Verbatim-in-support vs transformation-required (deterministic hint). */
  availability?: 'verbatim' | 'transformation';
  /** The exam's own mark for this item + the exam median (mark pressure). */
  mark?: number;
  medianMark?: number;
  /** Lengths for the linguistic-load heuristic (chars). */
  stemLength?: number;
  passageLength?: number;
}

const clamp = (n: number, lo: number, hi: number): number => Math.max(lo, Math.min(hi, n));

export function computeDifficulty(
  input: DifficultyInput,
  weights: DifficultyWeights = DEFAULT_WEIGHTS,
  weightsVersion: string = DEFAULT_WEIGHTS_VERSION,
): DifficultyScore {
  const factors: DifficultyScore['factors'] = [];

  const spanPts = input.lessonSpan === 3 ? weights.span3 : input.lessonSpan === 2 ? weights.span2 : 0;
  if (spanPts > 0) {
    factors.push({ id: 'span', label: input.lessonSpan === 2 ? 'Spans 2 lessons' : 'Spans 3+ lessons', points: spanPts });
  }

  const provPts = input.provenance === 'out-of-book' ? weights.provOut : input.provenance === 'mixed' ? weights.provMixed : 0;
  if (provPts > 0) {
    factors.push({ id: 'provenance', label: input.provenance === 'out-of-book' ? 'Out-of-book material' : 'Mixed in/out-of-book', points: provPts });
  }

  const cogPts = input.cognitive === 'application' ? weights.cogApplication : input.cognitive === 'comprehension' ? weights.cogComprehension : 0;
  if (cogPts > 0) {
    factors.push({ id: 'cognitive', label: input.cognitive === 'application' ? 'Application-level' : 'Comprehension-level', points: cogPts });
  }

  const availPts = input.availability === 'transformation' ? weights.availTransformation : 0;
  if (availPts > 0) {
    factors.push({ id: 'availability', label: 'Transformation required', points: availPts });
  }

  // Mark pressure: how far ABOVE the exam median this item's mark sits.
  let markPts = 0;
  if (typeof input.mark === 'number' && typeof input.medianMark === 'number' && input.medianMark > 0) {
    const ratio = input.mark / input.medianMark; // 1.0 = typical
    markPts = Math.round(clamp((ratio - 1) / 1.5, 0, 1) * weights.markMax);
    if (markPts > 0) factors.push({ id: 'mark', label: 'Above-median mark', points: markPts });
  }

  // Linguistic load: stem+passage length bucket (deterministic, free).
  let loadPts = 0;
  const len = (input.stemLength || 0) + (input.passageLength || 0);
  if (len > 400) loadPts = Math.round(weights.loadMax);
  else if (len > 220) loadPts = Math.round(weights.loadMax * 0.6);
  else if (len > 120) loadPts = Math.round(weights.loadMax * 0.3);
  if (loadPts > 0) factors.push({ id: 'load', label: 'Long text', points: loadPts });

  const raw = weights.base + spanPts + provPts + cogPts + availPts + markPts + loadPts;
  const score = clamp(Math.round(raw), 0, 100);
  const band: DifficultyScore['band'] = score >= 70 ? 'hard' : score >= 40 ? 'medium' : 'easy';

  return { score, band, factors, weightsVersion, computedAt: new Date().toISOString() };
}

/**
 * Deterministic availability hint: if the picked answer appears verbatim in
 * the stem/context, the item was likely copy-from-support (easier).
 */
export function availabilityHint(value: string, stem: string, contextText?: string): 'verbatim' | 'transformation' {
  const norm = (s: string) => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();
  const v = norm(value);
  if (v.length >= 2 && (norm(stem).includes(v) || norm(contextText || '').includes(v))) return 'verbatim';
  return 'transformation';
}
