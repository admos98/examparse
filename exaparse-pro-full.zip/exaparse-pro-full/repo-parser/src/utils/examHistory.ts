import { ExamDocument } from '../types/exam';

/**
 * Time Travel (#13) — every mutation of a document is a transaction with a
 * human label. Undo/redo is global (Ctrl+Z / Ctrl+Shift+Z), and the scrubber
 * can jump to any labeled state.
 *
 * Snapshots live in memory (capped per document) — they are session-scoped by
 * design: the persisted store keeps the present, history keeps the road there.
 */

export interface HistoryEntry {
  /** Label describing the action that PRODUCED this state ("Edit Q3 stem"). */
  label: string;
  at: string;
  doc: ExamDocument;
}

interface DocHistory {
  past: HistoryEntry[]; // most recent last
  future: HistoryEntry[]; // most recent first (redo stack)
}

const MAX_HISTORY = 40;

const histories = new Map<string, DocHistory>();

type Listener = () => void;
const listeners = new Set<Listener>();

function emit() {
  for (const l of listeners) l();
}

export function subscribeHistory(listener: Listener): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function entryOf(doc: ExamDocument, label: string): HistoryEntry {
  return { label, at: new Date().toISOString(), doc };
}

/**
 * Record the CURRENT state as a past state before applying a change, and
 * clear the redo stack (standard undo semantics).
 */
export function pushHistory(doc: ExamDocument, label: string): void {
  if (!doc?.id) return;
  const h = histories.get(doc.id) || { past: [], future: [] };
  // Deduplicate: identical document state twice in a row is not a new entry.
  const last = h.past[h.past.length - 1];
  if (last && JSON.stringify(stripVolatile(last.doc)) === JSON.stringify(stripVolatile(doc))) {
    h.future = [];
    histories.set(doc.id, h);
    emit();
    return;
  }
  h.past.push(entryOf(doc, label));
  if (h.past.length > MAX_HISTORY) h.past.shift();
  h.future = [];
  histories.set(doc.id, h);
  emit();
}

function stripVolatile(doc: ExamDocument): unknown {
  // parsedAt changes on every re-parse; history compares structure, not timestamps.
  const { parsedAt, trust, ...rest } = doc;
  return rest;
}

/** Undo: returns the previous state, or null when there is nothing to undo. */
export function undo(doc: ExamDocument, label = 'Undo'): ExamDocument | null {
  const h = histories.get(doc.id);
  if (!h || h.past.length === 0) return null;
  const prev = h.past[h.past.length - 1];
  h.past.pop();
  h.future.unshift(entryOf(doc, 'current'));
  histories.set(doc.id, h);
  emit();
  return { ...prev.doc };
}

/** Redo: returns the next state, or null. */
export function redo(doc: ExamDocument): ExamDocument | null {
  const h = histories.get(doc.id);
  if (!h || h.future.length === 0) return null;
  const nextEntry = h.future[0];
  h.future.shift();
  h.past.push(entryOf(doc, 'redo'));
  histories.set(doc.id, h);
  emit();
  return { ...nextEntry.doc };
}

export function canUndo(docId: string): boolean {
  return (histories.get(docId)?.past.length || 0) > 0;
}

export function canRedo(docId: string): boolean {
  return (histories.get(docId)?.future.length || 0) > 0;
}

/** Labeled past states for the scrubber UI (oldest first). */
export function listHistory(docId: string): { label: string; at: string }[] {
  return (histories.get(docId)?.past || []).map((e) => ({ label: e.label, at: e.at }));
}

/** Jump to a specific past entry index (keeps the current state as redo). */
export function jumpTo(doc: ExamDocument, index: number): ExamDocument | null {
  const h = histories.get(doc.id);
  if (!h || index < 0 || index >= h.past.length) return null;
  const target = h.past[index];
  // Everything after `index` becomes the redo stack (newest first).
  const rolled = h.past.slice(index + 1).reverse();
  h.future = [...rolled, entryOf(doc, 'current'), ...h.future];
  h.past = h.past.slice(0, index);
  histories.set(doc.id, h);
  emit();
  return { ...target.doc };
}

export function clearHistory(docId: string): void {
  histories.delete(docId);
  emit();
}
