import { ExamDocument, ExamSection } from '../types/exam';
import { getSurfaceFilterSettings } from './surfaceFilter';

/**
 * Round-trip serializer (#4): ExamDocument -> canonical exam text.
 *
 * Used by the golden-corpus replay to prove IDEMPOTENCE: re-parsing the
 * serialization of a parsed document must reproduce the same structure.
 * Any divergence is a parser bug or an ambiguous source — caught in CI,
 * not in front of a user.
 *
 * FAITHFULNESS GUARDS: the parser can leave benign artifacts on section
 * metadata (a phantom passage that embeds the section's own header/bank line,
 * an instruction that duplicates the header desc, a no-header fallback that
 * leaves a section line inside courseName). Serialized verbatim, those
 * artifacts change the re-parse (a garbage line becomes a question). Each
 * guard below strips one artifact class so round-trip stays byte-faithful.
 */

function serializeNorm(s: string): string {
  return s.replace(/\s+/g, ' ').trim().toLowerCase();
}

/** Section-marker shape at line start: "A)", "C.", "الف)" (NOT "مدرسه:"). */
const SECTION_MARKER_START = /^\s*[A-Za-z\u0627-\u0644]{1,4}\s*[\)\.]\s*/;

/**
 * Option-row marker INSIDE a string: "الف) علی" / "b) x". Sentences ending in
 * a period never match (the marker requires a closing parenthesis).
 */
const OPTION_MARKER_ANYWHERE = /[A-Za-z\u0627-\u0644]{1,4}\s*\)/g;

/** Escape regex metacharacters before building RegExp from option text. */
function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Pick the header description source. The engine's instruction capture can
 * glue following OPTION ROWS into the section instruction (a known artifact —
 * the questions themselves parse fine). A polluted instruction in the header
 * line changes the re-parse.
 *
 * The detector is deliberately NARROW (false negatives are recoverable, false
 * positives would drop a real instruction): pollution requires several option
 * markers AND a REPEATED marker letter — glued option rows always reuse the
 * same letter cycle (الف…ب…ج…د…الف…), while a legitimate instruction like
 * "write a) if true or b) if false" uses each letter once.
 */
function headerDescSource(sec: ExamSection): { text: string; pollutedInstruction: boolean } {
  const instr = sec.englishInstruction || sec.persianInstruction || '';
  const title = sec.title || '';
  const markers = instr.match(OPTION_MARKER_ANYWHERE) || [];
  if (instr && markers.length >= 4 && title) {
    const letters = markers.map((m) => serializeNorm(m.replace(/[\s\)]/g, '')));
    const repeats = new Set<string>();
    for (const l of letters) if (letters.filter((x) => x === l).length > 1) repeats.add(l);
    if (repeats.size > 0) return { text: title, pollutedInstruction: true };
  }
  return { text: instr || title, pollutedInstruction: false };
}

function sectionHeaderLine(sec: ExamSection): string {
  // Clean the description: strip the "Section X:" prefix, any leading letter
  // marker (instruction lines often carry "B)" from the source), and any
  // trailing mark — we re-add the mark ourselves.
  const { text: raw } = headerDescSource(sec);
  let desc = raw;
  desc = desc
    .replace(/^\s*Section\s+[A-Z\u0627-\u0644]+:\s*/i, '')
    .replace(/^\s*[A-Z\u0627-\u0644]{1,4}\s*[\)\.\-–—:]\s*/, '')
    .replace(/\(\s*[\d\.]+\s*(?:marks?|نمره|pts?|points?)?\s*\)\s*$/i, '')
    .trim();
  if (desc.length > 110) desc = desc.slice(0, 110).trim();
  const parts = [`${sec.rowId})`];
  if (desc) parts.push(desc);
  parts.push(`(${sec.markTotal})`);
  return parts.join(' ');
}

export function serializeExamToText(doc: ExamDocument): string {
  const out: string[] = [];

  // ---- Header ----
  // No-header fallback can leave a section line inside courseName/schoolName;
  // emitting it as a header field makes the re-parse swallow the section.
  const courseName = (doc.header.courseName || '').trim();
  if (courseName && !SECTION_MARKER_START.test(courseName)) out.push(`نام درس: ${courseName}`);
  // Surface filter (D4): the school line is personal metadata — emitted only
  // under the Settings power-user toggle. Keeps the re-parse round-trip clean
  // (the serializer text is also the source of the Mirror re-parse).
  const schoolNameFull = getSurfaceFilterSettings().showFullHeaderFields
    ? (doc.header.schoolName || '').trim()
    : '';
  if (schoolNameFull && !SECTION_MARKER_START.test(schoolNameFull)) out.push(`نام مدرسه: ${schoolNameFull}`);
  if (doc.header.durationMinutes) out.push(`مدت آزمون: ${doc.header.durationMinutes} دقیقه`);

  // ---- Sections ----
  for (const sec of doc.sections) {
    out.push('');
    out.push(sectionHeaderLine(sec));
    // Instruction dedupe: sectionHeaderLine already carries the instruction
    // (english || persian || title). Write the persian line only when it is a
    // DIFFERENT string AND not suppressed as polluted (a polluted instruction
    // in the body would re-glue option rows into the re-parsed instruction).
    const { text: descSrc, pollutedInstruction } = headerDescSource(sec);
    if (sec.persianInstruction && !pollutedInstruction && sec.persianInstruction !== descSrc) {
      out.push(sec.persianInstruction);
    }
    if (sec.hasWordBank && sec.wordBank?.length) out.push(`[${sec.wordBank.join(', ')}]`);
    if (sec.hasPassage && sec.passageText) {
      // Phantom-passage guard: the engine sometimes prepends the section's own
      // header/instruction line (plus the word bank) to the passage text. Strip
      // that first line ONLY when it mirrors a REAL instruction (not just the
      // title — a real passage may legitimately open like the title); then drop
      // what is left only if it is COMPOSED of bank words/punctuation, not
      // merely containing them.
      let pText = sec.passageText;
      const lines = pText.split('\n');
      const realInstruction = sec.englishInstruction || sec.persianInstruction || '';
      const first = (lines[0] || '').trim();
      // The instruction requirement (not the title) is what protects real
      // passages: a phantom's first line IS the instruction line, while a real
      // passage may open like the title with no instruction present at all.
      if (realInstruction) {
        const instrCore = realInstruction
          .replace(/^\s*Section\s+[A-Z\u0627-\u0644]+:\s*/i, '')
          .replace(SECTION_MARKER_START, '')
          .replace(/\s*\(\s*[\d\.]+\s*\)\s*$/, '')
          .trim();
        const firstCore = first
          .replace(SECTION_MARKER_START, '')
          .replace(/\s*\(\s*[\d\.]+\s*\)\s*$/, '')
          .trim();
        if (instrCore && firstCore && serializeNorm(firstCore).startsWith(serializeNorm(instrCore))) {
          pText = lines.slice(1).join('\n').trim();
        }
      }
      // Bank-only remainder: after REMOVING every bank word and punctuation,
      // nothing meaningful may survive ("I am ... sisters are ..." survives;
      // "[careful, pollution]" does not).
      if (pText && sec.hasWordBank && sec.wordBank?.length) {
        let remainder = serializeNorm(pText);
        const words = [...sec.wordBank].sort((a, b) => b.length - a.length);
        for (const w of words) remainder = remainder.split(serializeNorm(w)).join(' ');
        remainder = remainder.replace(/[\d\[\]\.,;:\(\)\-—\s]/g, '');
        if (remainder.length === 0) pText = '';
      }
      if (pText) {
        out.push(sec.passageTitle ? `Passage: ${sec.passageTitle}` : 'Passage:');
        out.push(pText);
      }
    }

    for (const q of sec.questions) {
      const num = q.originalNumber !== undefined ? `${q.originalNumber}. ${q.number}.` : `${q.number}.`;
      let stem = q.stem || '';
      // Mark suffix: re-attach explicit marks so the round-trip preserves them.
      // 1 is the parser's default mark — writing it would be redundant; any
      // OTHER value (0.5, 1.5, 2, 0.67...) MUST ride along or the re-parse
      // silently restores the default. (This used to skip 0.5 — backwards.)
      const markSuffix = q.mark !== 1 ? ` (${q.mark})` : '';
      // Re-attach inline choice / options depending on type
      if (q.type === 'multiple_choice' || q.type === 'cloze_item') {
        out.push(`${num} ${stem}`);
        const opts = q.options || [];
        opts.forEach((o, i) => {
          const isLast = i === opts.length - 1;
          out.push(`${o.id}) ${o.text}${isLast ? markSuffix : ''}`);
        });
      } else if (q.type === 'inline_choice' && q.options?.length) {
        const inline = q.options.map((o) => o.text).join(' / ');
        // Only re-embed the choices when the stem lost them (it usually keeps
        // them). Option text is interpolated into a RegExp — it MUST be
        // escaped ("1) watch" would otherwise throw Invalid RegExp on the
        // unmatched ')'), and a missing first word must not crash either.
        const firstWord = escapeRegExp((inline.split(/[\s']+/)[0] || '').trim());
        const hasChoices = firstWord.length > 0 && new RegExp(`\\(\\s*[^)]*${firstWord}`).test(stem);
        const markedStem = hasChoices ? stem : `${stem}( ${inline} )`;
        out.push(`${num} ${markedStem}${markSuffix}`);
      } else if (q.type === 'true_false') {
        out.push(`${num} ${stem.includes('True') ? stem : `${stem} True / False`}${markSuffix}`);
      } else if (q.type === 'form_in_parentheses' && !/\)\s*$/.test(stem)) {
        out.push(`${num} ${stem}${stem ? ' ' : ''}(${q.correctAnswer || '...'})${markSuffix}`);
      } else {
        out.push(`${num} ${stem}${markSuffix}`);
      }
    }
  }

  return out.join('\n');
}

/** Structural fingerprint used by round-trip and fuzz comparisons. */
export function structuralFingerprint(doc: ExamDocument): string {
  const parts: string[] = [];
  for (const sec of doc.sections) {
    for (const q of sec.questions) {
      const stem = (q.stem || '').toLowerCase().replace(/\s+/g, ' ').trim();
      const opts = (q.options || []).map((o) => o.text.toLowerCase().trim()).join('|');
      parts.push(`${sec.rowId}/${q.number}/${q.type}/${stem}/${opts}/${q.mark}`);
    }
  }
  return parts.join('\n');
}

/** Compare two documents structurally; returns a list of divergences. */
export function diffStructures(a: ExamDocument, b: ExamDocument): string[] {
  const fa = structuralFingerprint(a);
  const fb = structuralFingerprint(b);
  if (fa === fb) return [];

  const la = fa.split('\n');
  const lb = fb.split('\n');
  const diffs: string[] = [];
  const max = Math.max(la.length, lb.length);
  for (let i = 0; i < max; i++) {
    if (la[i] !== lb[i]) diffs.push(`line ${i}: "${la[i] || '(none)'}" != "${lb[i] || '(none)'}"`);
    if (diffs.length >= 5) break;
  }
  return diffs;
}
