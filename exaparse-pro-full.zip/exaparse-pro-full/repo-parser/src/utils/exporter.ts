import * as XLSX from 'xlsx';
import JSZip from 'jszip';
import { ExamDocument, QuestionItem } from '../types/exam';
import { getQuestionTypeInfo } from './questionTypeMapper';
import { stripHeavyFields } from './storage';
import { surfaceHeader } from './surfaceFilter';

// Surface filter (D4): personal header fields (school/teacher/district/date)
// are stripped from EVERY export by default; the Settings power-user toggle
// (showFullHeaderFields) is the only way they reappear. Every site below
// reads the header through surfaceHeader() — never doc.header directly.

/**
 * Download a file in the browser safely.
 */
export function downloadFile(content: string | Blob, filename: string, mimeType: string) {
  const blob = content instanceof Blob ? content : new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Export single exam as Clean Online Exam Platform JSON
 */
export function exportToCleanJson(doc: ExamDocument): string {
  const cleanData = formatDocumentForJson(doc);
  return JSON.stringify(cleanData, null, 2);
}

/**
 * Export multiple exams in a single combined JSON bundle
 */
export function exportBatchToJson(documents: ExamDocument[]): string {
  const batchData = {
    batchMetadata: {
      totalExams: documents.length,
      totalQuestions: documents.reduce((sum, d) => sum + d.totalQuestions, 0),
      exportedAt: new Date().toISOString(),
      platformVersion: '2.0.0-batch',
    },
    exams: documents.map(formatDocumentForJson),
    consolidatedQuestionBank: documents.flatMap((doc) =>
      getAllQuestions(doc).map((q) => ({
        examId: doc.id,
        examTitle: doc.header.courseName,
        school: surfaceHeader(doc.header).schoolName || undefined,
        grade: doc.header.gradeAndMajor,
        questionNumber: q.number,
        sectionRow: q.sectionRowId,
        category: q.sectionName,
        type: q.type,
        stem: q.stem,
        options: q.options ? q.options.map((o) => `${o.id.toUpperCase()}: ${o.text}`).join(' | ') : null,
        correctAnswer: q.correctAnswer || null,
        mark: q.mark,
        context: q.parentContextTitle || null,
      })),
    ),
  };
  return JSON.stringify(batchData, null, 2);
}

function formatDocumentForJson(doc: ExamDocument) {
  return {
    metadata: {
      examId: doc.id,
      examTitle: doc.header.examName || doc.header.courseName,
      officialCourseName: doc.header.courseName,
      school: surfaceHeader(doc.header).schoolName || undefined,
      grade: doc.header.grade || doc.header.gradeAndMajor,
      term: doc.header.term || null,
      district: surfaceHeader(doc.header).district || undefined,
      date: surfaceHeader(doc.header).examDate || undefined,
      durationMinutes: doc.header.durationMinutes,
      totalQuestions: doc.totalQuestions,
      totalMarks: doc.totalMarks,
      parsedAt: doc.parsedAt,
      isAiSolved: doc.isAiSolved,
      // Provenance stamp: makes every exported file self-identifying, so
      // "was this made by the AI?" never requires reading server logs again.
      parseStage: doc.parseStage || (doc.isAiSolved ? 'stage2_ai_solved' : 'stage1_offline_unsolved'),
      pipeline: {
        engine: doc.isAiSolved ? 'ai' : 'offline',
        aiQuestionsAnswered: doc.aiUsage?.aiSolved ?? 0,
        totalQuestions: doc.totalQuestions,
        aiTokens: doc.aiUsage?.totalTokens ?? 0,
        note: doc.isAiSolved
          ? `AI solve pass merged answers into ${doc.aiUsage?.aiSolved ?? 0} of ${doc.totalQuestions} questions.`
          : 'No AI output was merged — structure and fields come from the deterministic offline engine.',
      },
    },
    sections: doc.sections.map((sec) => ({
      sectionRowId: sec.rowId,
      category: sec.majorCategory,
      title: sec.title,
      instructions: {
        persian: sec.persianInstruction || null,
        english: sec.englishInstruction || null,
      },
      marksAllocated: sec.markTotal,
      context: sec.hasPassage
        ? {
            type: 'passage',
            title: sec.passageTitle,
            text: sec.passageText,
          }
        : sec.hasWordBank
        ? {
            type: 'word_bank',
            words: sec.wordBank,
          }
        : null,
      questions: sec.questions.map((q) => {
        const typeInfo = getQuestionTypeInfo(q.type);
        return {
          id: q.id,
          number: q.number,
          displayNumber: q.displayNumber,
          type: q.type,
          typeEnName: q.typeEnName || typeInfo.enName,
          typeFaName: q.typeFaName || typeInfo.faName,
          stem: q.stem,
          options: q.options || null,
          correctAnswer: q.correctAnswer || null,
          mark: q.mark,
          wordBankWords: q.wordBankWords || null,
          parentContext:
            q.parentContextType !== 'none'
              ? {
                  type: q.parentContextType,
                  title: q.parentContextTitle,
                  text: q.parentContextText || null,
                  wordBankOptions: q.wordBankWords || null,
                }
              : null,
        };
      }),
    })),
    flatQuestionBank: getAllQuestions(doc).map((q) => {
      const typeInfo = getQuestionTypeInfo(q.type);
      return {
        id: q.id,
        number: q.number,
        section: q.sectionName,
        row: q.sectionRowId,
        type: q.type,
        typeEnName: q.typeEnName || typeInfo.enName,
        typeFaName: q.typeFaName || typeInfo.faName,
        stem: q.stem,
        options: q.options ? q.options.map((o) => `${o.id.toUpperCase()}: ${o.text}`).join(' | ') : null,
        answer: q.correctAnswer || null,
        mark: q.mark,
        wordBankWords: q.wordBankWords || null,
        linkedPassageText: q.parentContextText || null,
        parentContext: q.parentContextTitle || null,
      };
    }),
  };
}

/**
 * Single source of truth for the flat Question_Bank sheet rows (#18 WYSIWYS):
 * the export preview renders EXACTLY these objects, so what the user sees in
 * the preview is byte-for-byte what lands in the .xlsx.
 */
export function buildQuestionRows(doc: ExamDocument): Record<string, string | number>[] {
  return getAllQuestions(doc).map((q) => {
    const optA = q.options?.find((o) => o.id === 'a')?.text || '';
    const optB = q.options?.find((o) => o.id === 'b')?.text || '';
    const optC = q.options?.find((o) => o.id === 'c')?.text || '';
    const optD = q.options?.find((o) => o.id === 'd')?.text || '';
    const typeInfo = getQuestionTypeInfo(q.type);

    return {
      'No.': q.number,
      'Row ID': q.sectionRowId,
      Section: q.sectionName,
      'Question Type (EN)': q.typeEnName || typeInfo.enName,
      'نوع سوال (FA)': q.typeFaName || typeInfo.faName,
      'Question Stem': q.stem,
      'Option A': optA,
      'Option B': optB,
      'Option C': optC,
      'Option D': optD,
      'Correct Answer': q.correctAnswer || '',
      'Mark (Points)': q.mark,
      'Word Box Candidate Words': q.wordBankWords ? q.wordBankWords.join(', ') : '',
      'Linked Passage / Reading Text': q.parentContextText || '',
      'Context Title': q.parentContextTitle || '',
      'Has Image': q.hasImage ? 'Yes' : 'No',
      'Image Asset File': q.imageFileName || '',
      'Image Description': q.imageCaption || '',
      'Persian Instruction': q.persianInstruction || '',
    };
  });
}

/** Grid projection for the export preview modal (#18). */
export function buildPreviewGrid(doc: ExamDocument): { headers: string[]; rows: (string | number)[][] } {
  const rows = buildQuestionRows(doc);
  const headers = rows.length > 0 ? Object.keys(rows[0]) : [];
  return {
    headers,
    rows: rows.map((r) => headers.map((h) => r[h] ?? '')),
  };
}

/**
 * Export single exam as Multi-Sheet Excel (.xlsx) file
 */
export function exportToExcel(doc: ExamDocument): void {
  const wb = XLSX.utils.book_new();

  // Sheet 1: Flat Questions Table (WYSIWYS source: buildQuestionRows)
  const flatQuestions = buildQuestionRows(doc);

  const wsQuestions = XLSX.utils.json_to_sheet(flatQuestions);
  XLSX.utils.book_append_sheet(wb, wsQuestions, 'Question_Bank');

  // Sheet 2: Sections & Passages Summary
  const sectionSummary = doc.sections.map((sec) => ({
    'Row ID': sec.rowId,
    Category: sec.majorCategory,
    'Section Title': sec.title || '',
    'Questions Count': sec.questions.length,
    'Total Marks': sec.markTotal,
    'Persian Instruction': sec.persianInstruction || '',
    'Word Bank Words': sec.wordBank ? sec.wordBank.join(', ') : 'None',
    'Has Passage': sec.hasPassage ? 'Yes' : 'No',
    'Passage Title': sec.passageTitle || '',
    'Passage Content': sec.passageText || '',
  }));

  const wsSections = XLSX.utils.json_to_sheet(sectionSummary);
  XLSX.utils.book_append_sheet(wb, wsSections, 'Sections_and_Passages');

  // Sheet 3: Exam Metadata
  const metadataRows = [
    { Key: 'AI Identified Exam Title', Value: doc.header.examName || doc.header.courseName },
    { Key: 'Course Name', Value: doc.header.courseName },
    { Key: 'School', Value: surfaceHeader(doc.header).schoolName },
    { Key: 'District', Value: surfaceHeader(doc.header).district },
    { Key: 'Grade', Value: doc.header.grade || doc.header.gradeAndMajor },
    { Key: 'Term / Exam Period', Value: doc.header.term || 'نوبت اول' },
    { Key: 'Exam Date', Value: surfaceHeader(doc.header).examDate },
    { Key: 'Duration (Mins)', Value: doc.header.durationMinutes },
    { Key: 'Total Questions', Value: doc.totalQuestions },
    { Key: 'Total Marks', Value: doc.totalMarks },
    { Key: 'Confidence Score', Value: `${doc.confidenceScore}%` },
    { Key: 'Original File', Value: doc.filename },
  ];
  const wsMeta = XLSX.utils.json_to_sheet(metadataRows);
  XLSX.utils.book_append_sheet(wb, wsMeta, 'Exam_Info');

  // Write file
  const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([excelBuffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const safeTitle = (doc.header.examName || doc.header.courseName).replace(/[^\w\u0600-\u06FF]/g, '_').slice(0, 30);
  downloadFile(blob, `${safeTitle}_QuestionBank.xlsx`, blob.type);
}

/**
 * Export BATCH of all exams into a unified multi-sheet Excel (.xlsx) file
 */
export function exportBatchToExcel(documents: ExamDocument[], customFilename?: string): void {
  const wb = XLSX.utils.book_new();

  // Master Sheet: Consolidated Questions across ALL exams
  const consolidatedQuestions = documents.flatMap((doc) =>
    getAllQuestions(doc).map((q) => {
      const optA = q.options?.find((o) => o.id === 'a')?.text || '';
      const optB = q.options?.find((o) => o.id === 'b')?.text || '';
      const optC = q.options?.find((o) => o.id === 'c')?.text || '';
      const optD = q.options?.find((o) => o.id === 'd')?.text || '';

      const typeInfo = getQuestionTypeInfo(q.type);
      return {
        'Exam ID': doc.id,
        'Exam Name': doc.header.examName || doc.header.courseName,
        'School / Institution': surfaceHeader(doc.header).schoolName,
        Grade: doc.header.grade || doc.header.gradeAndMajor,
        Term: doc.header.term || 'نوبت اول',
        'Question No.': q.number,
        'Row Letter': q.sectionRowId,
        Category: q.sectionName,
        'Question Type (EN)': q.typeEnName || typeInfo.enName,
        'نوع سوال (FA)': q.typeFaName || typeInfo.faName,
        'Question Stem': q.stem,
        'Option A': optA,
        'Option B': optB,
        'Option C': optC,
        'Option D': optD,
        'Correct Answer': q.correctAnswer || '',
        Mark: q.mark,
        'Word Box Candidate Words': q.wordBankWords ? q.wordBankWords.join(', ') : '',
        'Linked Passage Text': q.parentContextText || '',
        'Has Image': q.hasImage ? 'Yes' : 'No',
        'Image Asset File': q.imageFileName || '',
        'Image Description': q.imageCaption || '',
        'Attached Context': q.parentContextTitle || '',
        'Persian Instruction': q.persianInstruction || '',
      };
    }),
  );

  const wsConsolidated = XLSX.utils.json_to_sheet(consolidatedQuestions);
  XLSX.utils.book_append_sheet(wb, wsConsolidated, 'ALL_QUESTIONS_MASTER');

  // Individual sheets per exam (cleanly truncated sheet names)
  documents.forEach((doc, idx) => {
    const sheetName = `Exam_${idx + 1}_${(doc.header.grade || doc.header.gradeAndMajor).replace(/[^\w]/g, '').slice(0, 10)}`;
    const examQuestions = getAllQuestions(doc).map((q) => {
      const typeInfo = getQuestionTypeInfo(q.type);
      return {
        'No.': q.number,
        'Row ID': q.sectionRowId,
        Section: q.sectionName,
        'Type (EN)': q.typeEnName || typeInfo.enName,
        'نوع سوال': q.typeFaName || typeInfo.faName,
        Stem: q.stem,
        'Answer Key': q.correctAnswer || '',
        Mark: q.mark,
        'Word Box Words': q.wordBankWords ? q.wordBankWords.join(', ') : '',
        'Linked Passage': q.parentContextText ? q.parentContextText.slice(0, 150) + '...' : '',
        Context: q.parentContextTitle || '',
      };
    });
    const ws = XLSX.utils.json_to_sheet(examQuestions);
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
  });

  // Batch Overview Sheet
  const overviewRows = documents.map((doc, idx) => ({
    '#': idx + 1,
    'AI Identified Exam Title': doc.header.examName || doc.header.courseName,
    'Official Course': doc.header.courseName,
    School: surfaceHeader(doc.header).schoolName,
    Grade: doc.header.grade || doc.header.gradeAndMajor,
    'Date / Term': `${surfaceHeader(doc.header).examDate} - ${doc.header.term || 'نوبت اول'}`,
    'Total Questions': doc.totalQuestions,
    'Total Marks': doc.totalMarks,
    'Confidence Score': `${doc.confidenceScore}%`,
    Filename: doc.filename,
  }));
  const wsOverview = XLSX.utils.json_to_sheet(overviewRows);
  XLSX.utils.book_append_sheet(wb, wsOverview, 'BATCH_SUMMARY');

  const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([excelBuffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  downloadFile(blob, customFilename || `Batch_Exams_Export_${documents.length}_Files.xlsx`, blob.type);
}

export const exportExamToExcel = exportToExcel;

/**
 * Export single exam as CSV
 */
export function exportToCsv(doc: ExamDocument): string {
  const allQ = getAllQuestions(doc);
  return formatQuestionsCsv(allQ);
}

/**
 * Export BATCH of all exams as CSV
 */
export function exportBatchToCsv(documents: ExamDocument[]): string {
  const allQ = documents.flatMap((d) => getAllQuestions(d));
  return formatQuestionsCsv(allQ);
}

function formatQuestionsCsv(allQ: QuestionItem[]): string {
  const headers = [
    'number',
    'row_id',
    'section',
    'type_en',
    'type_fa',
    'stem',
    'option_a',
    'option_b',
    'option_c',
    'option_d',
    'correct_answer',
    'mark',
    'word_bank_words',
    'linked_passage_text',
    'parent_context_title',
  ];

  const escapeCsv = (str: string) => {
    if (!str) return '""';
    const escaped = str.replace(/"/g, '""');
    return `"${escaped}"`;
  };

  const rows = allQ.map((q) => {
    const optA = q.options?.find((o) => o.id === 'a')?.text || '';
    const optB = q.options?.find((o) => o.id === 'b')?.text || '';
    const optC = q.options?.find((o) => o.id === 'c')?.text || '';
    const optD = q.options?.find((o) => o.id === 'd')?.text || '';
    const typeInfo = getQuestionTypeInfo(q.type);

    return [
      q.number,
      escapeCsv(q.sectionRowId),
      escapeCsv(q.sectionName),
      escapeCsv(q.typeEnName || typeInfo.enName),
      escapeCsv(q.typeFaName || typeInfo.faName),
      escapeCsv(q.stem),
      escapeCsv(optA),
      escapeCsv(optB),
      escapeCsv(optC),
      escapeCsv(optD),
      escapeCsv(q.correctAnswer || ''),
      q.mark,
      escapeCsv(q.wordBankWords ? q.wordBankWords.join(', ') : ''),
      escapeCsv(q.parentContextText || ''),
      escapeCsv(q.parentContextTitle || ''),
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\n');
}

/**
 * Export in Moodle GIFT Format for direct online LMS import
 */
export function exportToMoodleGift(doc: ExamDocument): string {
  const allQ = getAllQuestions(doc);
  const giftLines: string[] = [`// ${doc.header.courseName} - ${surfaceHeader(doc.header).schoolName}`];

  for (const q of allQ) {
    giftLines.push(`\n// Question ${q.number} [${q.sectionName}]`);
    const title = `::Q${q.number}::`;

    if (q.type === 'multiple_choice' && q.options) {
      const optionsGift = q.options
        .map((opt) => {
          const isCorrect = q.correctAnswer?.toLowerCase() === opt.id.toLowerCase();
          return `${isCorrect ? '=' : '~'}${opt.text}`;
        })
        .join(' ');
      giftLines.push(`${title} ${q.stem} {${optionsGift}}`);
    } else if (q.type === 'true_false') {
      const isTrue = q.correctAnswer?.toLowerCase() === 'true';
      giftLines.push(`${title} ${q.stem} {${isTrue ? 'TRUE' : 'FALSE'}}`);
    } else {
      const ans = q.correctAnswer ? `={=${q.correctAnswer}}` : '{}';
      giftLines.push(`${title} ${q.stem} ${ans}`);
    }
  }

  return giftLines.join('\n');
}

export function getAllQuestions(doc: ExamDocument): QuestionItem[] {
  return doc.sections.flatMap((s) => s.questions);
}

// ============================================================================
// Trust Pack (#6) — the artifact that defends itself.
// A single ZIP: the clean exam JSON, the Excel question bank, and a
// self-contained verification report (invariants, consensus, provenance
// coverage, AI token receipts, redline review status).
// ============================================================================

function buildVerificationReportHtml(doc: ExamDocument): string {
  const inv = doc.invariants;
  const invRows = (inv?.violations || [])
    .map(
      (v) => `<tr><td>${v.severity}</td><td>${esc(v.rule)}</td><td>${esc(v.message)}</td><td>${esc(v.suggestedFix || '—')}</td><td>${v.isFixed ? 'fixed' : 'open'}</td></tr>`,
    )
    .join('');
  const consensusRows = (doc.consensus?.checks || [])
    .filter((c) => !c.agree)
    .map((c) => `<tr><td>${esc(c.path)}</td><td>${esc(c.a)}</td><td>${esc(c.b)}</td><td>${c.similarity}</td></tr>`)
    .join('');
  const usage = doc.aiUsage;
  const review = doc.review;
  const reviewRows = (review?.changes || [])
    .map(
      (c) =>
        `<tr><td>Q${esc(String(c.questionNumber))}</td><td>${esc(c.field)}</td><td>${esc(c.before) || '(empty)'}</td><td>${esc(c.after) || '(empty)'}</td><td>${esc(c.method)}</td><td>${c.status}</td></tr>`,
    )
    .join('');

  const bad = (cond: boolean, yes: string, no: string) => (cond ? yes : no);

  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/>
<title>Verification Report — ${esc(doc.header.courseName)}</title>
<style>
 body { font-family: system-ui, -apple-system, 'Segoe UI', sans-serif; background:#0f172a; color:#e2e8f0; margin:0; padding:32px; }
 .card { background:#1e293b; border:1px solid #334155; border-radius:14px; padding:20px; margin-bottom:16px; max-width: 900px; }
 h1 { font-size:20px; margin:0 0 4px; } h2 { font-size:14px; color:#94a3b8; text-transform:uppercase; letter-spacing:1px; margin:0 0 12px; }
 .badge { display:inline-block; padding:3px 12px; border-radius:999px; font-size:11px; font-weight:700; margin:0 6px 6px 0; border:1px solid #475569; }
 .good { background:#064e3b; color:#6ee7b7; border-color:#059669; } .warn { background:#451a03; color:#fcd34d; border-color:#d97706; }
 table { border-collapse:collapse; width:100%; font-size:12px; } th { text-align:left; color:#94a3b8; border-bottom:1px solid #475569; padding:6px 8px; }
 td { padding:6px 8px; border-bottom:1px solid #334155; } .meta { color:#64748b; font-size:11px; }
</style></head><body>
<h1>ExaParse Pro — Verification Report</h1>
<p class="meta">${esc(doc.header.examName || doc.header.courseName)} · ${esc(surfaceHeader(doc.header).schoolName)} · ${esc(doc.filename)} · generated ${new Date().toLocaleString()}</p>

<div class="card">
 <h2>Trust Summary</h2>
 <span class="badge ${bad(doc.confidenceScore >= 90, 'good', 'warn')}">Parser confidence ${doc.confidenceScore}%</span>
 ${inv ? `<span class="badge ${bad((inv.violations.filter((v) => !v.isFixed).length) === 0, 'good', 'warn')}">Invariants ${inv.passed}/${inv.total}</span>` : ''}
 ${doc.provenanceCoverage !== undefined ? `<span class="badge ${bad(doc.provenanceCoverage >= 80, 'good', 'warn')}">Evidence coverage ${doc.provenanceCoverage}%</span>` : ''}
 ${doc.consensus ? `<span class="badge ${bad(doc.consensus.agreementRate >= 95, 'good', 'warn')}">Dual-extraction consensus ${doc.consensus.agreementRate}%</span>` : ''}
 ${usage ? `<span class="badge good">AI tokens ${usage.totalTokens} vs naive ${usage.baselineTokens} (−${usage.savedPct}%)</span>` : '<span class="badge good">0 AI tokens — fully offline</span>'}
 <span class="badge">Stage ${doc.isAiSolved ? `2 — AI-solved (${doc.aiUsage?.aiSolved ?? 0}/${doc.totalQuestions} answers by AI)` : '1 — offline raw'}</span>
</div>

${inv ? `<div class="card"><h2>Structural invariants (deterministic proofs)</h2>
 ${inv.violations.length === 0 ? '<p class="meta">All checks passed — the document obeys the physics of exams.</p>' : `
 <table><tr><th>Severity</th><th>Rule</th><th>Detail</th><th>Suggested fix</th><th>Status</th></tr>${invRows}</table>`}
</div>` : ''}

${doc.consensus ? `<div class="card"><h2>Dual-extraction consensus (${esc(doc.consensus.method)})</h2>
 ${doc.consensus.disagreements === 0 ? '<p class="meta">Both independent extraction paths agree on every question.</p>' : `
 <p class="meta">${doc.consensus.disagreements} of ${doc.consensus.checks.length} comparisons disagreed — review these rows first:</p>
 <table><tr><th>Path</th><th>Extraction A</th><th>Extraction B</th><th>Similarity</th></tr>${consensusRows}</table>`}
</div>` : ''}

${usage ? `<div class="card"><h2>AI token receipt</h2>
 <table>
 <tr><th>Metric</th><th>Value</th></tr>
 <tr><td>Questions solved deterministically (matching engine)</td><td><b>${usage.heuristicSolved}</b></td></tr>
 <tr><td>Answers reused from the semantic cache</td><td><b>${usage.cacheHits}</b></td></tr>
 <tr><td>Questions sent to the AI (contested only)</td><td><b>${usage.aiSolved}</b></td></tr>
 <tr><td>Tokens actually spent (prompt + completion)</td><td><b>${usage.totalTokens}</b></td></tr>
 <tr><td>Tokens a naive pipeline would have burned</td><td>${usage.baselineTokens}</td></tr>
 <tr><td>Savings</td><td><b>${usage.savedPct}%</b></td></tr>
 </table>
</div>` : ''}

${review && review.changes.length > 0 ? `<div class="card"><h2>Redline review (${review.changes.filter((c) => c.status === 'approved').length} approved / ${review.changes.filter((c) => c.status === 'rejected').length} reverted)</h2>
 <table><tr><th>Question</th><th>Field</th><th>Before</th><th>After</th><th>Source</th><th>Status</th></tr>${reviewRows}</table>
</div>` : ''}

<p class="meta">Invariants are proofs, not heuristics. AI (when used) adjudicated only contested cells. This report was generated fully offline.</p>
</body></html>`;
}

function esc(s: string): string {
  return String(s || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/** Build the Trust Pack ZIP and trigger the download. */
export async function exportTrustPack(doc: ExamDocument): Promise<void> {
  const zip = new JSZip();

  // 1. Clean exam JSON (no source-file blob)
  zip.file('exam.json', JSON.stringify(stripHeavyFields(doc), null, 2));

  // 2. Excel question bank (array buffer, same shape as exportToExcel)
  const wb = XLSX.utils.book_new();
  const flat = getAllQuestions(doc).map((q) => ({
    'No.': q.number,
    'Row ID': q.sectionRowId,
    Section: q.sectionName,
    Type: q.type,
    'Question Stem': q.stem,
    'Correct Answer': q.correctAnswer || '',
    Mark: q.mark,
    'Answer Source': q.answerMeta?.method || '',
    'Answer Confidence': q.answerMeta?.confidence ?? '',
    'Source Page': q.provenance?.page ?? '',
    'OCR Confidence': q.provenance?.ocrConfidence ?? '',
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(flat), 'Question_Bank');
  const xlsxBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  zip.file('question-bank.xlsx', xlsxBuffer);

  // 3. Self-contained verification report
  zip.file('verification-report.html', buildVerificationReportHtml(doc));

  const blob = await zip.generateAsync({ type: 'blob' });
  const safeTitle = (doc.header.examName || doc.header.courseName || 'exam')
    .replace(/[^\w\u0600-\u06FF]/g, '_')
    .slice(0, 40);
  downloadFile(blob, `TrustPack_${safeTitle}.zip`, 'application/zip');
}

// ============================================================================
// Training-log JSONL export ("the json thing") — verified-correct questions
// only, one compact JSON object per line, de-duplicated by content
// fingerprint. 100% offline. See utils/trainingLog.ts for the gate + schema.
// ============================================================================

import { buildTrainingJsonl, TrainingLogOptions } from './trainingLog';

/** Single exam → training JSONL (verified-correct lines only). */
export function exportToTrainingJsonl(doc: ExamDocument, opts?: Partial<TrainingLogOptions>): string {
  return buildTrainingJsonl([doc], opts);
}

/** Whole library / batch → training JSONL (de-duplicated across exams). */
export function exportBatchToTrainingJsonl(documents: ExamDocument[], opts?: Partial<TrainingLogOptions>): string {
  return buildTrainingJsonl(documents, opts);
}
