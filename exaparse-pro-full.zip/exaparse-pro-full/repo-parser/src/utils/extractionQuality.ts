import { ExtractionQualityReport } from '../types/exam';
import { LayoutLine } from './fileExtractor';

/**
 * Extraction Quality Score (#6) — "is this text even parseable?" answered
 * deterministically BEFORE the parser runs.
 *
 * Five signals, 0-100:
 *  - dictionaryHit: share of extracted words that look like real Persian /
 *    English words (vs OCR garbage)
 *  - garbageRatio: non-word symbol soup (inverse quality)
 *  - structure: does the text carry exam structure (numbers, section
 *    letters, option markers)?
 *  - headerHit: did we find the exam header fields?
 *  - density: enough content at all?
 *
 * The cascade in fileExtractor uses this to pick the winning strategy and to
 * warn the user in plain words when the file quality is fighting them.
 */

// Small Persian + English function/content word lists — enough to estimate
// "does this look like language", not a dictionary competition.
const FA_WORDS = new Set(
  ('در با این را از که به است بود برای یک های خود بر تا هم می شد کرد نظر های دیگر هر بین همه ما شما آنها چیست اگر پس یا اما ' +
    'نام درس مدرسه دبیرستان آموزش پرورش آزمون سوال پاسخ گزینه نمره بارم زمان تاریخ کلاس پایه رشته دانش آموز معلم ' +
    'زبان انگلیسی واژگان دستور نگارش درک مطلب شنیداری خوانید دهید کنید انتخاب جای خالی کلمات جمله متن').split(/\s+/).filter(Boolean),
);
const EN_WORDS = new Set(
  ('the a an and or of to in is are was were be been do does did have has had will would can could should i you he she it we they ' +
    'this that these those not no yes for with on at by from as but if then than so such about into over under out up down ' +
    'choose fill read match write make complete listen answer look question questions exam quiz school teacher student grade ' +
    'lesson english vocabulary grammar writing reading passage word words sentence sentences correct option options true false ' +
    'what where when why how who which whose circle underline complete').split(/\s+/).filter(Boolean),
);

function looksLikeWord(token: string): boolean {
  if (!token) return false;
  if (/^\d+[\.\)]?$/.test(token)) return true; // numbers count
  if (/^[A-Za-z']{2,}$/.test(token)) return true; // latin alpha
  if (/^[\u0600-\u06FF\u200C]{2,}$/.test(token)) return true; // persian alpha (ZWNJ allowed inside)
  return false;
}

export interface EqsWithLines {
  report: ExtractionQualityReport;
}

export function scoreExtraction(text: string, lines: LayoutLine[] = []): ExtractionQualityReport {
  const reasons: string[] = [];
  const signals: Record<string, number> = {};
  const trimmed = (text || '').trim();

  if (!trimmed) {
    return {
      score: 0,
      verdict: 'poor',
      signals: { density: 0 },
      reasons: ['No text was extracted at all.'],
    };
  }

  const tokens = trimmed.split(/\s+/).filter(Boolean);
  const wordTokens = tokens.filter((t) => /[A-Za-z\u0600-\u06FF]/.test(t));

  // --- 1. density (0-100) ---
  const charCount = trimmed.length;
  const density = charCount >= 400 ? 100 : Math.round((charCount / 400) * 100);
  signals.density = density;
  if (density < 40) reasons.push('Very little text came out of the file — the scan may be blank, rotated, or unreadable.');

  // --- 2. garbageRatio ---
  const garbage = tokens.filter((t) => !looksLikeWord(t) && !/^[^\w\u0600-\u06FF]+$/.test(t)).length;
  const garbageRatio = wordTokens.length > 0 ? garbage / Math.max(tokens.length, 1) : 1;
  signals.garbageRatio = Math.round(garbageRatio * 100) / 100;
  if (garbageRatio > 0.35) reasons.push('More than a third of the tokens are symbol soup — classic sign of a broken text layer or bad OCR.');

  // --- 3. dictionaryHit ---
  let hits = 0;
  for (const t of wordTokens) {
    const lower = t.toLowerCase().replace(/[^\w\u0600-\u06FF']/g, '');
    if (EN_WORDS.has(lower) || FA_WORDS.has(t.replace(/[\u200C]/g, '')) || FA_WORDS.has(lower)) hits++;
  }
  const dictHit = wordTokens.length > 0 ? hits / wordTokens.length : 0;
  signals.dictionaryHit = Math.round(dictHit * 100) / 100;
  if (dictHit < 0.08 && wordTokens.length > 30) {
    reasons.push('Almost none of the words match real Persian/English vocabulary — the OCR likely mis-read the page.');
  }

  // --- 4. structure ---
  const questionNums = (trimmed.match(/(?:^|\n)\s*\d{1,3}\s*[\.\)]/g) || []).length;
  const sectionMarks = (trimmed.match(/(?:^|\n)\s*[A-Z][\)\.\-–—:]/g) || []).length;
  const optionMarkers = (trimmed.match(/(?:^|\s)[a-d][\)\.]\s*\S/gi) || []).length;
  const structScore = Math.min(
    100,
    Math.min(questionNums, 40) * 1.5 + Math.min(sectionMarks, 8) * 4 + Math.min(optionMarkers, 30) * 1,
  );
  signals.structure = Math.round(structScore);
  if (questionNums === 0 && optionMarkers === 0) {
    reasons.push('No question numbers or option markers were found — the text may be prose, or the layout is unreadable.');
  }

  // --- 5. headerHit ---
  const headerHits =
    (/نام\s*درس|درس|Subject|Course/i.test(trimmed) ? 1 : 0) +
    (/مدرسه|دبیرستان|School/i.test(trimmed) ? 1 : 0) +
    (/مدت|Duration|Time/i.test(trimmed) ? 1 : 0) +
    (/پایه|مقطع|Grade/i.test(trimmed) ? 1 : 0);
  signals.headerHit = headerHits;
  if (headerHits === 0) reasons.push('No exam header fields (course, school, duration, grade) were recognized.');

  // --- mean OCR confidence (bonus signal when available) ---
  const confs = lines.map((l) => l.confidence).filter((c): c is number => typeof c === 'number');
  if (confs.length > 0) {
    const meanConf = confs.reduce((s, c) => s + c, 0) / confs.length;
    signals.ocrConfidence = Math.round(meanConf * 10) / 10;
    if (meanConf < 55) reasons.push(`Mean OCR confidence is only ${Math.round(meanConf)}%.`);
  }

  // --- weighted score ---
  const score = Math.max(
    0,
    Math.min(
      100,
      Math.round(
        density * 0.1 +
          (100 - garbageRatio * 100) * 0.25 +
          Math.min(dictHit * 400, 100) * 0.2 +
          structScore * 0.3 +
          (headerHits / 4) * 100 * 0.1 +
          (signals.ocrConfidence !== undefined ? (signals.ocrConfidence / 100) * 5 : 5),
      ),
    ),
  );

  const verdict: ExtractionQualityReport['verdict'] = score >= 70 ? 'good' : score >= 45 ? 'fair' : 'poor';
  return { score, verdict, signals, reasons };
}
