import JSZip from 'jszip';
import * as pdfjsLib from 'pdfjs-dist';
import { createWorker } from 'tesseract.js';
import { preprocessImageForOcr, normalizeOcrText } from './ocrPreprocessor';
import { normalizeForFingerprint } from './answerCache';
import { scoreExtraction } from './extractionQuality';
import { ExtractionQualityReport } from '../types/exam';
import { BBox } from '../types/exam';

// Configure PDF.js worker for browser execution
if (typeof window !== 'undefined' && pdfjsLib.GlobalWorkerOptions) {
  try {
    pdfjsLib.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjsLib.version || '4.10.38'}/build/pdf.worker.min.mjs`;
  } catch (e) {
    console.warn('Could not set GlobalWorkerOptions.workerSrc:', e);
  }
}

export type OcrProgressCallback = (status: string, percent: number) => void;

// ---------- layout-aware extraction (provenance backbone) ----------

/** One recognized source line with optional geometry + OCR confidence. */
export interface LayoutLine {
  page: number;
  text: string;
  bbox?: BBox;
  /** 'pdf' = PDF text-space (y up from bottom), 'pixel' = processed image px. */
  coordSpace?: 'pdf' | 'pixel';
  pageWidth?: number;
  pageHeight?: number;
  confidence?: number;
  lineIndex: number;
}

export interface OcrDetailedResult {
  text: string;
  lines: Omit<LayoutLine, 'lineIndex'>[];
}

export interface ExtractionResult {
  text: string;
  lines: LayoutLine[];
  sourceType: 'pdf_text' | 'ocr' | 'docx' | 'text';
  pageCount?: number;
  /** Extraction Quality Score (#6) of the winning strategy. */
  eqs?: ExtractionQualityReport;
  /** Minimal offline OCR of pictures embedded in the source (docx media).
   *  Verification context ONLY — never part of the parse input. */
  pictureNotes?: string[];
  /** Layout geometry (digital PDF text-layer path only): feeds the sectioning
   *  brain. Lines match `text` 1:1; rules/rects come from the render ops. */
  brainDoc?: import('./layoutBrain').BrainDoc;
}

/** Create a tesseract worker (local traineddata first, CDN fallback). */
async function createTesseractWorker(
  onProgress?: OcrProgressCallback,
): Promise<any> {
  const localLangPath = typeof window !== 'undefined'
    ? `${window.location.origin}/tessdata`
    : '/tessdata';

  const logger = (m: any) => {
    if (m.status === 'recognizing text') {
      const pct = Math.round((m.progress || 0) * 100);
      onProgress?.(`Recognizing text (${pct}%)...`, pct);
    } else if (m.status) {
      onProgress?.(`OCR: ${m.status}...`, 15);
    }
  };

  try {
    return await createWorker(['eng', 'fas'], 1, { langPath: localLangPath, gzip: true, logger });
  } catch (localErr) {
    console.warn('Local /tessdata load failed, attempting uncompressed or CDN fallback:', localErr);
    try {
      return await createWorker(['eng', 'fas'], 1, { langPath: localLangPath, gzip: false, logger });
    } catch (secondErr) {
      console.warn('Uncompressed local load failed, trying standard fallback:', secondErr);
      return await createWorker(['eng', 'fas'], 1, { logger });
    }
  }
}

/** Preprocess an image-like source into a canvas (keeps coordinates stable). */
async function toProcessedCanvas(imageSource: any): Promise<any> {
  if (typeof window === 'undefined') return imageSource;
  try {
    if (imageSource instanceof HTMLCanvasElement) {
      return preprocessImageForOcr(imageSource);
    }
    if (typeof imageSource !== 'string' && 'size' in imageSource) {
      const imgBitmap = await createImageBitmap(imageSource as Blob);
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = imgBitmap.width;
      tempCanvas.height = imgBitmap.height;
      const ctx = tempCanvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(imgBitmap, 0, 0);
        return preprocessImageForOcr(tempCanvas);
      }
    }
  } catch (prepErr) {
    console.warn('Image pre-filter skipped:', prepErr);
  }
  return imageSource;
}

/** Extract line geometry from a tesseract.js v4–v7 result, defensively. */
function extractOcrLines(ret: any): Omit<LayoutLine, 'lineIndex'>[] {
  const out: Omit<LayoutLine, 'lineIndex'>[] = [];
  try {
    const data = ret?.data || {};
    // v4–v5 style: data.lines[]; v6+/blocks style: data.blocks[].paragraphs[].lines[]
    let lineObjs: any[] = Array.isArray(data.lines) ? data.lines : [];
    if (lineObjs.length === 0 && Array.isArray(data.blocks)) {
      for (const block of data.blocks) {
        for (const para of block?.paragraphs || []) {
          for (const line of para?.lines || []) lineObjs.push(line);
        }
      }
    }
    if (lineObjs.length === 0 && Array.isArray(data.blocks)) {
      // v7 can hand back word-only blocks; group words into pseudo-lines by y.
      const words: any[] = [];
      for (const block of data.blocks) {
        for (const para of block?.paragraphs || []) {
          for (const line of para?.lines || []) {
            for (const w of line?.words || []) words.push(w);
          }
        }
      }
      words.sort((a, b) => (a.bbox?.y0 ?? 0) - (b.bbox?.y0 ?? 0));
      let cur: any[] = [];
      let curY = -1;
      for (const w of words) {
        const y = w.bbox?.y0 ?? 0;
        if (curY === -1 || Math.abs(y - curY) <= Math.max(10, (w.bbox?.y1 ?? 0) - y)) {
          cur.push(w);
          curY = curY === -1 ? y : curY;
        } else {
          lineObjs.push({ words: cur, text: cur.map((x) => x.text).join(' ') });
          cur = [w];
          curY = y;
        }
      }
      if (cur.length) lineObjs.push({ words: cur, text: cur.map((x) => x.text).join(' ') });
    }

    for (const line of lineObjs) {
      const text = String(line.text || '').trim();
      if (!text) continue;
      const bb = line.bbox;
      const words = Array.isArray(line.words) ? line.words : [];
      const confs = words.map((w: any) => w.confidence).filter((c: any) => typeof c === 'number');
      out.push({
        text,
        page: 1,
        bbox: bb ? { x: bb.x0, y: bb.y0, w: bb.x1 - bb.x0, h: bb.y1 - bb.y0 } : undefined,
        confidence: confs.length ? Math.round((confs.reduce((s: number, c: any) => s + c, 0) / confs.length) * 10) / 10 : undefined,
      });
    }
  } catch (e) {
    console.warn('OCR line extraction degraded to text-only:', e);
  }
  return out;
}

/**
 * OCR with line geometry. Returns normalized text plus per-line bboxes (pixel
 * space of the processed canvas) and mean per-line confidences.
 */
export async function runOfflineOcrDetailed(
  imageSource: string | HTMLCanvasElement | Blob | File,
  onProgress?: OcrProgressCallback,
  opts?: { psm?: string; preprocess?: boolean },
): Promise<OcrDetailedResult> {
  onProgress?.('Preparing image & initializing local offline OCR...', 5);

  let processedSource: any = imageSource;
  if (opts?.preprocess !== false) {
    processedSource = await toProcessedCanvas(imageSource);
  }

  const worker = await createTesseractWorker(onProgress);

  try {
    await worker.setParameters({ tessedit_pageseg_mode: opts?.psm || '3' });
  } catch {
    // ignore
  }

  const ret = await worker.recognize(processedSource);
  await worker.terminate();

  const lines = extractOcrLines(ret).map((l) => ({
    ...l,
    page: 1,
    coordSpace: 'pixel' as const,
    pageWidth: processedSource?.width,
    pageHeight: processedSource?.height,
  }));

  const rawOcrText = ret?.data?.text || '';
  const text = normalizeOcrText(rawOcrText);

  // The normalized text has different line breaks than raw OCR lines; re-derive
  // line geometry from the NORMALIZED text so stems can be matched to lines.
  return { text, lines: reindexLinesToNormalizedText(text, lines) };
}

/**
 * normalizeOcrText can merge/split lines, so we re-align geometry to the
 * normalized text: for each normalized line, find the OCR line with the best
 * fuzzy overlap and inherit its bbox/confidence.
 */
function reindexLinesToNormalizedText(
  normalizedText: string,
  ocrLines: Omit<LayoutLine, 'lineIndex'>[],
): Omit<LayoutLine, 'lineIndex'>[] {
  const normLines = normalizedText.split(/\r?\n/).filter((l) => l.trim());
  if (ocrLines.length === 0 || normLines.length === 0) return ocrLines;

  const normKey = (s: string) => normalizeForFingerprint(s).slice(0, 60);
  const used = new Set<number>();
  const out: Omit<LayoutLine, 'lineIndex'>[] = [];

  for (const nLine of normLines) {
    const key = normKey(nLine);
    let bestIdx = -1;
    let bestScore = 0;
    for (let i = 0; i < ocrLines.length; i++) {
      if (used.has(i)) continue;
      const oKey = normKey(ocrLines[i].text);
      if (!oKey) continue;
      const score = oKey === key ? 1 : charOverlap(key, oKey);
      if (score > bestScore) {
        bestScore = score;
        bestIdx = i;
      }
    }
    if (bestIdx !== -1 && bestScore >= 0.5) {
      used.add(bestIdx);
      out.push({ ...ocrLines[bestIdx], text: nLine });
    } else {
      out.push({ page: 1, text: nLine, coordSpace: 'pixel' });
    }
  }
  return out;
}

function charOverlap(a: string, b: string): number {
  if (!a || !b) return 0;
  const sa = new Set(a.split(' '));
  const sb = new Set(b.split(' '));
  let inter = 0;
  for (const t of sa) if (sb.has(t)) inter++;
  return inter / Math.max(sa.size, sb.size);
}

/**
 * Runs pure offline OCR on an image or HTMLCanvasElement using tesseract.js.
 * Reads eng and fas traineddata directly from local /tessdata with 0 external network requests!
 */
export async function runOfflineOcr(
  imageSource: string | HTMLCanvasElement | Blob | File,
  onProgress?: OcrProgressCallback,
  opts?: { psm?: string },
): Promise<string> {
  const res = await runOfflineOcrDetailed(imageSource, onProgress, opts);
  return res.text;
}

/**
 * Word AUTO-NUMBERING support: teacher docx files number questions with
 * w:numPr list numbering, which Word renders but never stores as text.
 * Without this, every numbered stem lost its number on the docx path.
 * numbering.xml: numId -> abstractNumId -> per-ilvl {numFmt, lvlText, start}.
 */
interface DocxNumLevel { numFmt: string; lvlText: string; start: number }
interface DocxNumInfo { abstractId: string; levels: Map<number, DocxNumLevel> }

function parseDocxNumbering(numberingXml: string): Map<string, DocxNumInfo> {
  const numToAbstract = new Map<string, string>();
  const abstracts = new Map<string, Map<number, DocxNumLevel>>();
  const numRe = /<w:num\s+[^>]*w:numId="([^"]+)"[^>]*>[\s\S]*?<w:abstractNumId\s+w:val="([^"]+)"[^>]*\/?>[\s\S]*?<\/w:num>/g;
  let m: RegExpExecArray | null;
  while ((m = numRe.exec(numberingXml)) !== null) numToAbstract.set(m[1], m[2]);
  const absRe = /<w:abstractNum\s+[^>]*w:abstractNumId="([^"]+)"[\s\S]*?<\/w:abstractNum>/g;
  while ((m = absRe.exec(numberingXml)) !== null) {
    const levels = new Map<number, DocxNumLevel>();
    const lvlRe = /<w:lvl\s+[^>]*w:ilvl="(\d+)"[^>]*>([\s\S]*?)<\/w:lvl>/g;
    let lm: RegExpExecArray | null;
    while ((lm = lvlRe.exec(m[0])) !== null) {
      const fmt = (lm[2].match(/<w:numFmt\s+w:val="([^"]+)"/) || [])[1] || 'bullet';
      const txt = (lm[2].match(/<w:lvlText\s+w:val="([^"]+)"/) || [])[1] || '%1.';
      const start = parseInt(((lm[2].match(/<w:start\s+w:val="([^"]+)"/) || [])[1]) || '1', 10);
      levels.set(parseInt(lm[1], 10), { numFmt: fmt, lvlText: txt, start: isNaN(start) ? 1 : start });
    }
    abstracts.set(m[1], levels);
  }
  const out = new Map<string, DocxNumInfo>();
  for (const [numId, absId] of numToAbstract) {
    const levels = abstracts.get(absId);
    if (levels) out.set(numId, { abstractId: absId, levels });
  }
  return out;
}

/** Render the list label for (numId, ilvl), advancing counters. */
function docxNumberLabel(
  info: DocxNumInfo,
  numId: string,
  ilvl: number,
  counters: Map<string, number[]>,
): string | null {
  const lvl = info.levels.get(ilvl);
  if (!lvl || lvl.numFmt !== 'decimal') return null; // bullets / roman skip
  const key = `${numId}`;
  if (!counters.has(key)) counters.set(key, []);
  const arr = counters.get(key)!;
  while (arr.length <= ilvl) arr.push(0);
  // deeper levels restart when a shallower one advances
  for (let d = ilvl + 1; d < arr.length; d++) arr[d] = 0;
  arr[ilvl] = arr[ilvl] === 0 ? lvl.start : arr[ilvl] + 1;
  // lvlText like "%1." or "%1-%2" — substitute each level's counter
  return lvl.lvlText.replace(/%(\d)/g, (_x, d: string) => {
    const idx = parseInt(d, 10) - 1;
    return String(arr[idx] ?? arr[ilvl]);
  });
}

/** Extract numPr (numId, ilvl) from a paragraph's pPr XML, if any. */
function extractNumPr(pXml: string): { numId: string; ilvl: number } | null {
  const numPr = pXml.match(/<w:numPr>[\s\S]*?<\/w:numPr>/);
  if (!numPr) return null;
  const numId = (numPr[0].match(/<w:numId\s+w:val="([^"]+)"/) || [])[1];
  if (!numId) return null;
  const ilvl = parseInt((numPr[0].match(/<w:ilvl\s+w:val="([^"]+)"/) || [])[1] || '0', 10);
  return { numId, ilvl: isNaN(ilvl) ? 0 : ilvl };
}

/**
 * Minimal offline OCR of pictures EMBEDDED in a .docx (word/media/*).
 * The approved verification flow wants the raw source the judge reads to
 * include a simple OCR pass over the pictures when possible. These notes
 * NEVER enter the parse input (the line-based parser would spawn phantom
 * questions); they ride on the document and are appended to the VERIFICATION
 * source only (buildVerificationSheet).
 * Fail-soft by construction: per-image failures are skipped, and the whole
 * call degrades to [] when no media exists or OCR is unavailable.
 */
export async function extractDocxPictureNotes(
  data: ArrayBuffer,
  onProgress?: OcrProgressCallback,
): Promise<string[]> {
  const notes: string[] = [];
  try {
    const zip = await JSZip.loadAsync(data);
    const media = Object.keys(zip.files)
      .filter((p) => /^word\/media\/.+\.(png|jpe?g|gif|bmp|webp)$/i.test(p))
      .sort()
      .slice(0, 8); // bounded: a media-heavy file must not stall the flow
    for (let i = 0; i < media.length; i++) {
      try {
        const entry = zip.file(media[i]);
        if (!entry) continue;
        const buf = await entry.async('arraybuffer');
        if (buf.byteLength > 4 * 1024 * 1024) continue; // sanity bound
        onProgress?.(`OCR of embedded picture ${i + 1}/${media.length}...`, Math.round(((i + 1) / media.length) * 100));
        const text = await runOfflineOcr(new Blob([buf]), undefined);
        const clean = String(text || '').replace(/\s+/g, ' ').trim();
        if (clean.length >= 3) notes.push(`[picture ${i + 1} OCR] ${clean.slice(0, 600)}`);
      } catch {
        // per-image failure — the note is best-effort, keep going
      }
    }
  } catch {
    // no media / zip failure — pictures are optional metadata
  }
  return notes;
}

/**
 * Extracts raw textual layout from a Microsoft Word .docx file by unzipping
 * word/document.xml and converting paragraph tags (<w:p>) to lines.
 */
export async function extractTextFromDocx(data: ArrayBuffer): Promise<string> {
  const zip = await JSZip.loadAsync(data);
  const docXmlFile = zip.file('word/document.xml');
  if (!docXmlFile) {
    throw new Error('Invalid .docx file: word/document.xml not found.');
  }

  const xmlContent = await docXmlFile.async('text');
  const numberingFile = zip.file('word/numbering.xml');
  const numbering = numberingFile
    ? parseDocxNumbering(await numberingFile.async('text'))
    : new Map<string, DocxNumInfo>();
  const counters = new Map<string, number[]>();
  const prefixFor = (pXml: string): string => {
    const np = extractNumPr(pXml);
    if (!np) return '';
    const info = numbering.get(np.numId);
    if (!info) return '';
    const label = docxNumberLabel(info, np.numId, np.ilvl, counters);
    return label ? `${label} ` : '';
  };

  if (typeof DOMParser !== 'undefined') {
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlContent, 'application/xml');
    const paragraphs = xmlDoc.getElementsByTagName('w:p');
    const lines: string[] = [];

    for (let i = 0; i < paragraphs.length; i++) {
      const p = paragraphs[i];
      const textNodes = p.getElementsByTagName('w:t');
      let pText = '';
      for (let j = 0; j < textNodes.length; j++) {
        pText += textNodes[j].textContent || '';
      }
      const pXml = new XMLSerializer().serializeToString(p);
      const prefixed = prefixFor(pXml) + pText;
      if (prefixed.trim()) {
        lines.push(prefixed.trim());
      }
    }

    if (lines.length > 0) {
      return normalizeOcrText(lines.join('\n'));
    }
  }

  const pRegex = /<w:p(?:\s+[^>]*)?>([\s\S]*?)<\/w:p>/gi;
  const tRegex = /<w:t(?:\s+[^>]*)?>([^<]*)<\/w:t>/gi;
  const lines: string[] = [];
  let pMatch: RegExpExecArray | null;

  while ((pMatch = pRegex.exec(xmlContent)) !== null) {
    const pContent = pMatch[1];
    let pText = '';
    let tMatch: RegExpExecArray | null;
    while ((tMatch = tRegex.exec(pContent)) !== null) pText += tMatch[1];
    const prefixed = prefixFor(pContent) + pText;
    if (prefixed.trim()) {
      lines.push(prefixed.trim());
    }
  }

  return normalizeOcrText(lines.join('\n'));
}

/**
 * Extracts text from PDF:
 * 1. Checks standard text layer via pdf.js getTextContent().
 * 2. If PDF has NO text layer (image-only / scanned pages), automatically renders
 *    each page to high-res canvas and runs 100% offline OCR on the canvas!
 */
export async function extractTextFromPdf(
  data: ArrayBuffer,
  onProgress?: OcrProgressCallback,
): Promise<string> {
  try {
    const loadingTask = pdfjsLib.getDocument({
      data: new Uint8Array(data),
      useSystemFonts: true,
    });

    const pdf = await loadingTask.promise;
    const pageTexts: string[] = [];
    let totalTextChars = 0;

    // First pass: extract digital text layers if available
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      const strings: string[] = [];
      let lastY: number | null = null;

      for (const item of content.items) {
        if ('str' in item) {
          if (lastY !== null && Math.abs(item.transform[5] - lastY) > 6) {
            strings.push('\n');
          } else if (strings.length > 0 && !strings[strings.length - 1].endsWith(' ')) {
            strings.push(' ');
          }
          strings.push(item.str);
          lastY = item.transform[5];
        }
      }

      const pageJoined = strings.join('').trim();
      if (pageJoined) {
        pageTexts.push(pageJoined);
        totalTextChars += pageJoined.length;
      }
    }

    // If PDF contains real text layer (>= 30 characters), normalize and return
    if (totalTextChars >= 30) {
      return normalizeOcrText(pageTexts.join('\n\n'));
    }

    // CASE: SCANNED / IMAGE-ONLY PDF DETECTED!
    onProgress?.(`Scanned image-only PDF detected (${pdf.numPages} pages). Starting offline OCR...`, 5);
    const ocrPageTexts: string[] = [];

    for (let i = 1; i <= pdf.numPages; i++) {
      onProgress?.(`Rendering Page ${i}/${pdf.numPages} to high-res canvas...`, Math.round((i / (pdf.numPages + 1)) * 30));
      const page = await pdf.getPage(i);
      const viewport = page.getViewport({ scale: 2.0 }); // 2.0 scale provides crisp text for OCR

      const canvas = document.createElement('canvas');
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        throw new Error('Canvas 2D context unavailable');
      }

      await page.render({ canvasContext: ctx, viewport, canvas } as any).promise;

      onProgress?.(`Running offline OCR on Page ${i}/${pdf.numPages} (Persian + English)...`, Math.round((i / pdf.numPages) * 70));
      const pageOcrText = await runOfflineOcr(canvas, (status, pct) => {
        onProgress?.(`Page ${i}/${pdf.numPages}: ${status}`, pct);
      });

      if (pageOcrText.trim()) {
        ocrPageTexts.push(pageOcrText.trim());
      }
    }

    return ocrPageTexts.join('\n\n--- Page Break ---\n\n');
  } catch (err: any) {
    console.error('PDF text extraction error:', err);
    throw new Error(`Failed to extract text from PDF: ${err.message || 'Corrupt or unreadable PDF'}`);
  }
}

/**
 * Universal text extractor for uploaded files:
 * Supports: .docx, .pdf (both text-based and scanned image-only),
 * and image files (.png, .jpg, .jpeg, .webp, .tiff) via offline OCR!
 */
export async function extractTextFromFile(
  file: File,
  onProgress?: OcrProgressCallback,
): Promise<string> {
  const res = await extractTextFromFileDetailed(file, onProgress);
  return res.text;
}

/**
 * Layout-aware extraction: returns the normalized text PLUS one LayoutLine per
 * source line (page + bbox + confidence). This is what makes evidence-linked
 * provenance and the X-ray overlay possible.
 */
export async function extractTextFromFileDetailed(
  file: File,
  onProgress?: OcrProgressCallback,
): Promise<ExtractionResult> {
  const name = file.name.toLowerCase();

  // 1. Direct image files -> OCR with geometry
  if (
    name.endsWith('.png') ||
    name.endsWith('.jpg') ||
    name.endsWith('.jpeg') ||
    name.endsWith('.webp') ||
    name.endsWith('.tiff') ||
    name.endsWith('.bmp') ||
    file.type.startsWith('image/')
  ) {
    onProgress?.(`Running offline OCR on ${file.name}...`, 10);
    const ocr = await runOfflineOcrDetailed(file, onProgress);
    const lines = ocr.lines.map((l, i) => ({ ...l, lineIndex: i }));
    return {
      text: ocr.text,
      lines,
      sourceType: 'ocr',
      pageCount: 1,
      eqs: scoreExtraction(ocr.text, lines),
    };
  }

  const buffer = await file.arrayBuffer();

  // 2. Word .docx -> lines without geometry (provenance = line numbers only)
  if (name.endsWith('.docx')) {
    onProgress?.('Extracting text from Word DOCX XML...', 50);
    const text = await extractTextFromDocx(buffer);
    // Minimal offline OCR of embedded pictures (verification context only).
    // Fail-soft: never blocks or breaks the text extraction itself.
    let pictureNotes: string[] = [];
    try {
      pictureNotes = await extractDocxPictureNotes(buffer, onProgress);
    } catch {
      pictureNotes = [];
    }
    const lines = text.split(/\r?\n/).filter((l) => l.trim());
    return {
      text,
      lines: lines.map((t, i) => ({ page: 1, text: t, coordSpace: 'pixel' as const, lineIndex: i })),
      sourceType: 'docx',
      pageCount: 1,
      eqs: scoreExtraction(text),
      pictureNotes,
    };
  }

  // 3. PDF -> text layer with geometry, or scanned pages via OCR with geometry
  if (name.endsWith('.pdf')) {
    return extractPdfDetailed(buffer, onProgress);
  }

  // 4. Plain text fallback
  const text = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => resolve((e.target?.result as string) || '');
    reader.onerror = reject;
    reader.readAsText(file);
  });
  const norm = normalizeOcrText(text);
  const lines = norm.split(/\r?\n/).filter((l) => l.trim());
  return {
    text: norm,
    lines: lines.map((t, i) => ({ page: 1, text: t, coordSpace: 'pixel' as const, lineIndex: i })),
    sourceType: 'text',
    pageCount: 1,
    eqs: scoreExtraction(norm),
  };
}

/** PDF extraction with per-line geometry for both digital and scanned PDFs. */
async function extractPdfDetailed(
  data: ArrayBuffer,
  onProgress?: OcrProgressCallback,
): Promise<ExtractionResult> {
  const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(data), useSystemFonts: true });
  const pdf = await loadingTask.promise;
  const lines: LayoutLine[] = [];
  let pageTexts: string[] = [];
  let totalTextChars = 0;
  let brainDoc: import('./layoutBrain').BrainDoc | undefined;

  // ---- Path A: digital text layer with geometry ----
  const brainPages: import('./layoutBrain').BrainPage[] = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    // render ops FIRST: this also resolves fonts into commonObjs, which the
    // bold lookups in the text loop depend on
    const viewport0 = page.getViewport({ scale: 1 });
    const shapes = await extractPdfShapes(page, viewport0.height);
    const content = await page.getTextContent();
    const viewport = page.getViewport({ scale: 1 });
    const pageHeight = viewport.height;
    const pageWidth = viewport.width;

    type PendingLine = { text: string; x0: number; y0: number; x1: number; y1: number; y: number; size: number; bold: boolean };
    const pending: PendingLine[] = [];

    // bold detection: resolve the item's font through commonObjs (loaded by
    // getOperatorList below) — the font's own bold flag or a heavy-face name
    const fontBold = new Map<string, boolean>();
    const boldOf = async (fontName: string): Promise<boolean> => {
      const hit = fontBold.get(fontName);
      if (hit !== undefined) return hit;
      let bold = false;
      try {
        const f: any = await (page as any).commonObjs.get(fontName);
        if (f) bold = !!f.bold || /bold|black|heavy|titr|lalezar|morvarid|kostar/i.test(String(f.name || ''));
      } catch {
        bold = false;
      }
      fontBold.set(fontName, bold);
      return bold;
    };

    for (const item of content.items) {
      if (!('str' in item) || !item.str) continue;
      const x = item.transform[4];
      const yBase = item.transform[5];
      const w = item.width || 0;
      const h = item.height || 10;
      const size = Math.hypot(item.transform[0], item.transform[1]) || h || 10;
      const bold = await boldOf(item.fontName);
      const last = pending[pending.length - 1];
      if (last && Math.abs(yBase - last.y) <= 6) {
        last.text += (last.text.endsWith(' ') ? '' : ' ') + item.str;
        last.x0 = Math.min(last.x0, x);
        last.x1 = Math.max(last.x1, x + w);
        last.y0 = Math.max(last.y0, yBase);
        last.y1 = Math.min(last.y1, yBase - h);
        last.size = Math.max(last.size, size);
        last.bold = last.bold || bold;
      } else {
        pending.push({ text: item.str, x0: x, x1: x + w, y0: yBase, y1: yBase - h, y: yBase, size, bold });
      }
    }

    let pageHasText = false;
    const brainLines: import('./layoutBrain').BrainLine[] = [];
    for (const pl of pending) {
      const t = pl.text.trim();
      if (!t) continue;
      pageHasText = true;
      totalTextChars += t.length;
      lines.push({
        page: i,
        text: t,
        bbox: { x: pl.x0, y: pl.y0, w: pl.x1 - pl.x0, h: Math.abs(pl.y0 - pl.y1) || 10 },
        coordSpace: 'pdf',
        pageWidth,
        pageHeight,
        lineIndex: lines.length,
      });
      // brain line: same text, y flipped to top-down screen space
      const bTop = pageHeight - pl.y0;
      const bH = Math.abs(pl.y0 - pl.y1) || pl.size * 1.2 || 10;
      brainLines.push({ text: t, size: pl.size, bold: pl.bold, bbox: [pl.x0, bTop, pl.x1, bTop + bH], page: i - 1 });
    }
    if (pageHasText) {
      // Join this page's lines for the plain-text view (page break separated)
      pageTexts.push(lines.filter((l) => l.page === i).map((l) => l.text).join('\n'));
    }
    brainPages.push({
      width: pageWidth,
      height: pageHeight,
      hlines: shapes.hlines,
      rects: shapes.rects,
      tables: [],
      lines: brainLines,
    });
  }
  brainDoc = { file: '', pages: brainPages };

  if (totalTextChars >= 30) {
    const textA = normalizeOcrText(pageTexts.join('\n\n'));
    const linesA = reindexPdfLines(textA, lines);
    const eqsA = scoreExtraction(textA, linesA);
    eqsA.strategy = 'pdf_text_layer';

    // ---- Strategy cascade (#6): a digital text layer can still be garbage
    // (broken CMap, scanned-looking embedded fonts). If the text layer scores
    // poorly, try the OCR path and keep the higher-scoring extraction.
    if (eqsA.score < 50) {
      try {
        onProgress?.('Text layer looks poor — trying the OCR fallback path...', 30);
        const ocrResult = await ocrPdfPages(data, onProgress, pdf.numPages);
        if (ocrResult.text.trim()) {
          const eqsB = scoreExtraction(ocrResult.text, ocrResult.lines);
          eqsB.strategy = 'render_and_ocr';
          if (eqsB.score > eqsA.score) {
            // OCR won: its lines do NOT match the text-layer geometry, so the
            // brainDoc must not ride along (mismatched coordinates).
            return {
              text: ocrResult.text,
              lines: ocrResult.lines,
              sourceType: 'ocr',
              pageCount: pdf.numPages,
              eqs: eqsB,
            };
          }
        }
      } catch (cascadeErr) {
        console.warn('EQS cascade OCR fallback failed:', cascadeErr);
      }
    }

    return {
      text: textA,
      lines: linesA,
      sourceType: 'pdf_text',
      pageCount: pdf.numPages,
      eqs: eqsA,
      brainDoc,
    };
  }

  // ---- Path B: scanned / image-only PDF -> per-page OCR with geometry ----
  const ocrResult = await ocrPdfPages(data, onProgress, pdf.numPages, true);
  return {
    text: ocrResult.text,
    lines: ocrResult.lines,
    sourceType: 'ocr',
    pageCount: pdf.numPages,
    eqs: scoreExtraction(ocrResult.text, ocrResult.lines),
  };
}

/**
 * Rule/box geometry from the page's RENDER OPS — the client-side stand-in for
 * the PyMuPDF extraction the brain was validated on. Horizontal stroke
 * segments become hlines [x, y, width] and filled rectangles become rects
 * [x0, y0, x1, y1], both in top-down space. Scan-noise pages (10^5+ ops) are
 * capped so the brain stays fast; the brain re-caps on its side as well.
 */
async function extractPdfShapes(page: any, pageHeight: number): Promise<{ hlines: number[][]; rects: number[][] }> {
  const hlines: number[][] = [];
  const rects: number[][] = [];
  try {
    const OPS = (pdfjsLib as any).OPS;
    const ops = await page.getOperatorList();
    const fnArr: number[] = ops.fnArray;
    const argsArr: any[] = ops.argsArray;
    if (!fnArr || fnArr.length > 400_000) return { hlines, rects }; // scan noise: skip silently
    for (let k = 0; k < fnArr.length; k++) {
      if (fnArr[k] !== OPS.constructPath) continue;
      const args = argsArr[k];
      if (typeof args[0] === 'number') {
        // pdf.js >= 6: [paintOp, [subpath...], minMax] — the paint is baked
        // in and each subpath is a flat (op, x, y) triple record
        // (0=moveTo, 1=lineTo, 2/3=curve, 4=closePath).
        const paintOp: number = args[0];
        if (paintOp === OPS.endPath) continue; // unpainted (clip bookkeeping)
        const isStroke = paintOp === OPS.stroke || paintOp === OPS.closeStroke;
        const isFill = paintOp === OPS.fill || paintOp === OPS.eoFill || paintOp === OPS.fillStroke || paintOp === OPS.closeFillStroke || paintOp === OPS.eoFillStroke;
        if (!isStroke && !isFill) continue;
        const segs: number[][] = [];
        const paths = args[1];
        if (!Array.isArray(paths)) continue;
        for (const rec of paths) {
          if (!rec || typeof rec.length !== 'number') continue;
          let i = 0;
          let sx = 0, sy = 0, cx = 0, cy = 0;
          while (i < rec.length) {
            const op = rec[i];
            if (op === 0) { cx = rec[i + 1]; cy = rec[i + 2]; sx = cx; sy = cy; i += 3; }
            else if (op === 1) { const nx = rec[i + 1], ny = rec[i + 2]; segs.push([cx, cy, nx, ny]); cx = nx; cy = ny; i += 3; }
            else if (op === 2 || op === 3) { i += 7; }
            else if (op === 4) { segs.push([cx, cy, sx, sy]); i += 1; }
            else break;
          }
        }
        applyShapePaint(isStroke, isFill, segs, [], hlines, rects, pageHeight);
      } else {
        // pdf.js 3.x-5.x fallback: [opsArray, coordsArray, minMax] with the
        // paint op as the NEXT operator
        const pathOps: number[] = args[0];
        const coords: number[] = args[1];
        if (!Array.isArray(pathOps) || !coords) continue;
        const paint: number = fnArr[k + 1];
        const isStroke = paint === OPS.stroke || paint === OPS.closeStroke;
        const PAINT = new Set<number>([OPS.stroke, OPS.closeStroke, OPS.fill, OPS.eoFill, OPS.fillStroke, OPS.closeFillStroke, OPS.eoFillStroke]);
        const isFill = PAINT.has(paint) && !isStroke;
        if (!isStroke && !isFill) continue;
        const segs: number[][] = [];
        const rcts: number[][] = [];
        let ci = 0;
        let sx = 0, sy = 0, cx = 0, cy = 0;
        let ok = true;
        for (const po of pathOps) {
          if (po === OPS.moveTo) { cx = coords[ci]; cy = coords[ci + 1]; sx = cx; sy = cy; ci += 2; }
          else if (po === OPS.lineTo) { const nx = coords[ci], ny = coords[ci + 1]; segs.push([cx, cy, nx, ny]); cx = nx; cy = ny; ci += 2; }
          else if (po === OPS.rectangle) { const x = coords[ci], y = coords[ci + 1], w2 = coords[ci + 2], h2 = coords[ci + 3]; rcts.push([x, y, x + w2, y + h2]); ci += 4; }
          else if (po === OPS.curveTo || po === OPS.curveTo2 || po === OPS.curveTo3) { ci += 6; }
          else if (po === OPS.closePath) { segs.push([cx, cy, sx, sy]); }
          else { ok = false; break; }
        }
        if (ok) applyShapePaint(isStroke, isFill, segs, rcts, hlines, rects, pageHeight);
      }
    }
  } catch (e) {
    console.debug('extractPdfShapes: operator walk failed (rules/rects unavailable):', e);
  }
  return { hlines: hlines.slice(0, 40000), rects: rects.slice(0, 40000) };
}

function applyShapePaint(
  isStroke: boolean,
  isFill: boolean,
  segs: number[][],
  rcts: number[][],
  hlines: number[][],
  rects: number[][],
  pageHeight: number,
): void {
  if (isStroke) {
    for (const [x1, y1, x2, y2] of segs) {
      if (Math.abs(y1 - y2) <= 1.5 && Math.abs(x2 - x1) >= 20) {
        hlines.push([Math.min(x1, x2), pageHeight - Math.max(y1, y2), Math.abs(x2 - x1)]);
      }
    }
  } else if (isFill) {
    // v6 fills arrive as polygons — use the polygon bbox (exam furniture is
    // axis-aligned: bubbles, boxes, shaded rules)
    const polys = [...rcts];
    if (segs.length) {
      let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
      for (const [ax, ay, bx, by] of segs) {
        x0 = Math.min(x0, ax, bx); x1 = Math.max(x1, ax, bx);
        y0 = Math.min(y0, ay, by); y1 = Math.max(y1, ay, by);
      }
      polys.push([x0, y0, x1, y1]);
    }
    for (const [rx0, ry0, rx1, ry1] of polys) {
      const w2 = rx1 - rx0, h2 = ry1 - ry0;
      if (h2 <= 2.5 && w2 >= 20) hlines.push([rx0, pageHeight - Math.max(ry0, ry1), w2]);
      else if (w2 > 4 && h2 > 4) rects.push([rx0, pageHeight - Math.max(ry0, ry1), rx1, pageHeight - Math.min(ry0, ry1)]);
    }
  }
}

/** OCR every page of a PDF (shared by the primary path and the EQS cascade). */
async function ocrPdfPages(
  data: ArrayBuffer,
  onProgress?: OcrProgressCallback,
  pageCount = 0,
  verbose = false,
): Promise<{ text: string; lines: LayoutLine[] }> {
  const pdfjsLib2 = pdfjsLib;
  const loadingTask2 = pdfjsLib2.getDocument({ data: new Uint8Array(data), useSystemFonts: true });
  const pdf = await loadingTask2.promise;
  const lines: LayoutLine[] = [];
  const pageTexts: string[] = [];
  let globalLineIndex = 0;

  for (let i = 1; i <= pdf.numPages; i++) {
    if (verbose) onProgress?.(`Rendering Page ${i}/${pageCount || pdf.numPages} to high-res canvas...`, Math.round((i / (pageCount + 1)) * 30));
    const page = await pdf.getPage(i);
    const viewport = page.getViewport({ scale: 2.0 });

    const canvas = document.createElement('canvas');
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) continue;
    await page.render({ canvasContext: ctx, viewport, canvas } as any).promise;

    if (verbose) onProgress?.(`Running offline OCR on Page ${i}/${pageCount || pdf.numPages} (Persian + English)...`, Math.round((i / (pageCount || pdf.numPages)) * 70));
    const ocr = await runOfflineOcrDetailed(canvas, verbose
      ? (status, pct) => onProgress?.(`Page ${i}/${pageCount || pdf.numPages}: ${status}`, pct)
      : undefined);

    if (ocr.text.trim()) {
      pageTexts.push(ocr.text.trim());
      for (const l of ocr.lines) {
        if (!l.text.trim()) continue;
        lines.push({
          ...l,
          page: i,
          lineIndex: globalLineIndex++,
        });
      }
    }
  }

  return { text: pageTexts.join('\n\n'), lines };
}

/** Re-align pdf text-layer geometry to the normalized text (line fuzzy match). */
function reindexPdfLines(normalizedText: string, geoLines: LayoutLine[]): LayoutLine[] {
  const normLines = normalizedText.split(/\r?\n/).filter((l) => l.trim());
  if (geoLines.length === 0 || normLines.length === 0) return geoLines;

  // Greedy-match in reading order against a small look-ahead window.
  const out: LayoutLine[] = [];

  let cursor = 0;
  const normKey = (s: string) => normalizeForFingerprint(s).slice(0, 60);

  for (const nLine of normLines) {
    const key = normKey(nLine);
    let matched: LayoutLine | undefined;
    // Look ahead a small window of geometry lines (normalized text reorders little)
    for (let k = cursor; k < Math.min(geoLines.length, cursor + 6); k++) {
      if (normKey(geoLines[k].text) === key || charOverlap(key, normKey(geoLines[k].text)) >= 0.6) {
        matched = geoLines[k];
        cursor = k + 1;
        break;
      }
    }
    if (matched) {
      out.push({ ...matched, text: nLine });
    } else {
      const prev = out[out.length - 1];
      out.push({
        page: prev?.page ?? 1,
        text: nLine,
        coordSpace: prev?.coordSpace,
        pageWidth: prev?.pageWidth,
        pageHeight: prev?.pageHeight,
        lineIndex: out.length,
      });
    }
  }
  return out.map((l, i) => ({ ...l, lineIndex: i }));
}
