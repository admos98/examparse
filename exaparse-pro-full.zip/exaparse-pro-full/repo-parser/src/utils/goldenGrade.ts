import { ExamDocument } from '../types/exam';

/**
 * Shared golden-grading core — ONE definition of "does this parse match the
 * hand-built ground truth", used by:
 *   - scripts-batch/grade.mts (the 30-exam + 20-mock strict gate)
 *   - src/utils/ruleMiner.ts  (mined-rule target check + corpus shadow run)
 *
 * Extracted verbatim from grade.mts so a mined rule is judged by exactly the
 * same semantics that guard the corpus. Any change here changes BOTH gates —
 * intentionally: the grader IS the promotion authority.
 */

export interface GTQuestion {
  n: number | number[];
  t: string;
  stem?: string | RegExp;
}
export interface GTSection {
  id: string;
  cat: string;
  mark: number;
  qs: GTQuestion[];
}
export interface GoldenGT {
  file: string;
  header: Record<string, string | number>;
  totalMarks: number;
  sections: GTSection[];
}

export interface GradeResult {
  score: number;
  issues: string[];
  total: number;
}

function normStem(s: string): string {
  return (s || '')
    .replace(/\s+/g, ' ')
    .replace(/[.,!?;:"'’“”()]+/g, '')
    .trim()
    .toLowerCase();
}

export function gradeParse(doc: ExamDocument, gt: GoldenGT): GradeResult {
  const issues: string[] = [];
  let total = 0;

  // Sections
  const gotIds = doc.sections.map((s) => s.rowId).join(',');
  const wantIds = gt.sections.map((s) => s.id).join(',');
  total++;
  if (gotIds !== wantIds) issues.push(`section ids: got [${gotIds}] want [${wantIds}]`);

  // Duplicate row ids (sheets that print the same letter twice — pc4i517871
  // repeats "D"): the k-th GT section with an id matches the k-th parse
  // section with that rowId, in document order.
  const idSeen = new Map<string, number>();
  for (const gts of gt.sections) {
    const occurrence = idSeen.get(gts.id) ?? 0;
    idSeen.set(gts.id, occurrence + 1);
    const matches = doc.sections.filter((s) => s.rowId === gts.id);
    const sec = matches[occurrence];
    if (!sec) {
      issues.push(`section ${gts.id} MISSING`);
      continue;
    }
    total += 2;
    if (sec.majorCategory !== gts.cat) issues.push(`${gts.id} category: got ${sec.majorCategory} want ${gts.cat}`);
    const markOk = Math.abs(sec.markTotal - gts.mark) < 0.011;
    if (!markOk) issues.push(`${gts.id} markTotal: got ${sec.markTotal} want ${gts.mark}`);

    // question numbers + types
    const gotQs = sec.questions.map((q) => ({ n: q.number as number, t: q.type }));
    const wantQs: { n: number; t: string }[] = [];
    for (const q of gts.qs) {
      if (q.stem !== undefined) continue; // spot-check entry, not a question row
      if (Array.isArray(q.n)) for (const n of q.n) wantQs.push({ n, t: q.t });
      else wantQs.push({ n: q.n as number, t: q.t });
    }
    total++;
    if (gotQs.length !== wantQs.length) issues.push(`${gts.id} count: got ${gotQs.length} want ${wantQs.length}`);
    const len = Math.min(gotQs.length, wantQs.length);
    for (let i = 0; i < len; i++) {
      if (gotQs[i].n !== wantQs[i].n) issues.push(`${gts.id} q# at pos ${i}: got ${gotQs[i].n} want ${wantQs[i].n}`);
      if (gotQs[i].t !== wantQs[i].t) issues.push(`${gts.id} q${gotQs[i].n} type: got ${gotQs[i].t} want ${wantQs[i].t}`);
    }

    // stem spot checks
    for (const q of gts.qs) {
      if (!q.stem) continue;
      const nums = Array.isArray(q.n) ? q.n : [q.n];
      for (const n of nums) {
        total++;
        const got = sec.questions.find((x) => x.number === n);
        if (!got) {
          issues.push(`${gts.id} q${n} missing for stem check`);
          continue;
        }
        if (q.stem instanceof RegExp) {
          if (!q.stem.test(got.stem)) issues.push(`${gts.id} q${n} stem !~ ${q.stem}: got "${got.stem.slice(0, 60)}"`);
        } else if (normStem(String(q.stem)) !== normStem(got.stem)) {
          issues.push(`${gts.id} q${n} stem: got "${got.stem.slice(0, 60)}" want "${String(q.stem).slice(0, 60)}"`);
        }
      }
    }
  }

  // header + totals
  total += 2;
  for (const [k, v] of Object.entries(gt.header || {})) {
    total++;
    const got = (doc.header as unknown as Record<string, unknown>)[k];
    if (typeof v === 'number' ? got !== v : String(got || '').trim() !== String(v).trim()) {
      issues.push(`header.${k}: got "${got}" want "${v}"`);
    }
  }
  const marksOk = Math.abs(doc.totalMarks - gt.totalMarks) < 0.011;
  if (!marksOk) issues.push(`totalMarks: got ${doc.totalMarks} want ${gt.totalMarks}`);
  const score = total > 0 ? Math.round(((total - issues.length) / total) * 1000) / 10 : 0;
  return { score, issues, total };
}
