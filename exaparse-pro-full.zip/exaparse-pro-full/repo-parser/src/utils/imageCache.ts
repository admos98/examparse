import { kvGet, kvSet } from './localStore';

/**
 * Content-hash cache for the vision pipeline (Idea 3).
 *
 * Hard constraint: every vision result is cached by the CONTENT HASH of the
 * image bytes (embedded picture) or the page render (scanned transcription),
 * so each image or page is extracted at most once, EVER — re-runs are free
 * and make no wire call. Follows the existing answerCache pattern (async KV
 * on IndexedDB with a localStorage fallback via localStore).
 *
 * Cache entries are keyed by (hash, purpose, model): the same bytes asked for
 * an alt vs a full-page transcription, or asked of a different model, are
 * different entries — correctness first, dedupe second.
 */

const VISION_CACHE_PREFIX = 'vc1:';

/**
 * SHA-256 hex of raw bytes, with a deterministic djb2 fallback for
 * non-secure contexts (plain-HTTP LAN deployments where crypto.subtle is
 * unavailable). Both are stable for identical bytes; only the SHA-256 form
 * ever collides with real-world images.
 */
export async function hashBytes(data: ArrayBuffer | Uint8Array): Promise<string> {
  const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
  try {
    if (typeof crypto !== 'undefined' && crypto.subtle) {
      const digest = await crypto.subtle.digest('SHA-256', bytes as unknown as BufferSource);
      return Array.from(new Uint8Array(digest))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
    }
  } catch {
    // fall through to the deterministic fallback
  }
  // djb2 ×2 (different seeds) — 64 bits of fingerprint, fine for a cache key
  let h1 = 5381;
  let h2 = 52711;
  for (let i = 0; i < bytes.length; i++) {
    h1 = ((h1 << 5) + h1 + bytes[i]) | 0;
    h2 = ((h2 << 7) + h2 + bytes[i]) | 0;
  }
  return `fb${(h1 >>> 0).toString(16)}${(h2 >>> 0).toString(16)}`;
}

export type VisionPurpose = 'alts' | 'transcribe';

/** Cache key: content hash + what was asked + which model answered. */
export function visionCacheKey(contentHash: string, purpose: VisionPurpose, model: string): string {
  return `${VISION_CACHE_PREFIX}${purpose}:${model}:${contentHash}`;
}

export interface CachedVisionResult {
  alt: string;
  kind: 'text' | 'photo' | 'diagram' | 'unknown';
  confidence: number;
  model: string;
  ts: number;
}

export async function visionCacheGet(key: string): Promise<CachedVisionResult | undefined> {
  const hit = await kvGet<CachedVisionResult>(key);
  if (!hit || typeof hit.alt !== 'string' || !hit.alt.trim()) return undefined;
  return hit;
}

export async function visionCachePut(key: string, value: CachedVisionResult): Promise<void> {
  if (!value?.alt?.trim()) return;
  await kvSet(key, value);
}
