import { ExamDocument, QuestionItem } from '../types/exam';

/**
 * The two-phase Jev contract (single source of truth — parseVerifier AND the
 * vision UI read this; duplicating the predicate here would recreate the
 * computeTrust/applyTrust drift bug).
 *
 * Phase 1: questions that depend on an image WITHOUT an alt yet are EXCLUDED
 *          from the judge call and marked "unchecked / awaiting image alt"
 *          (they get an 'unverified' verdict that is never cached).
 * Phase 2: once vision alts are attached (imageCaption set), ONLY those
 *          now-complete questions re-verify — the content fingerprint changed
 *          and the App forces their ids, so no question is ever sent twice.
 */

/** Figure/alt markers the vision pipeline and the transcriber insert. */
export const FIGURE_MARKER_RE = /\[(?:FIGURE|figure|تصویر|picture|Picture|image|Image)[^\]]*\]/;

/** A question depends on an image when it carries one, or its text references one. */
export function isImageDependent(q: QuestionItem): boolean {
  if (q.hasImage) return true;
  if (q.imgPending) return true;
  if (q.parentContextType === 'image_prompt') return true;
  if (FIGURE_MARKER_RE.test(q.stem || '')) return true;
  return false;
}

/** True when the question is image-dependent but has NO alt text yet. */
export function needsImageAlt(q: QuestionItem): boolean {
  if (!isImageDependent(q)) return false;
  return !q.imageCaption || !q.imageCaption.trim();
}

/** Questions skipped by the FIRST Jev pass (unchecked / awaiting image alt). */
export function imagePendingQuestionIds(doc: ExamDocument): string[] {
  const out: string[] = [];
  for (const sec of doc.sections) {
    for (const q of sec.questions) {
      if (needsImageAlt(q)) out.push(q.id);
    }
  }
  return out;
}
