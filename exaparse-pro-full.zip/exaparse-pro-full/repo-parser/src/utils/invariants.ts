import { ExamDocument, InvariantReport, InvariantViolation, QuestionItem } from '../types/exam';

/**
 * Structural invariants — "the physics of exams".
 *
 * Exams obey hard rules: question numbers run sequentially, a section's mark
 * total equals the sum of its question marks, MCQs carry options, chosen
 * option letters must exist, marks take standard values. Any violation is
 * *provably* a parsing or drafting error — deterministically, with zero AI.
 */

const STANDARD_MARKS = [0.25, 0.5, 0.75, 1, 1.5, 2, 2.5, 3, 4, 5];

let counter = 0;
const nextId = (rule: string) => `inv-${rule.toLowerCase()}-${Date.now().toString(36)}-${counter++}`;

function normStemKey(stem: string): string {
  return stem.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, '').replace(/\s+/g, ' ').trim();
}

export function runInvariantChecks(doc: ExamDocument): InvariantReport {
  const violations: InvariantViolation[] = [];
  let checks = 0;

  const add = (v: Omit<InvariantViolation, 'id'>) => {
    violations.push({ id: nextId(v.rule), ...v });
  };

  for (const sec of doc.sections) {
    // ---- 1. Sequential numbering within a section ----
    const numeric = sec.questions
      .map((q) => ({ q, n: typeof q.number === 'number' ? q.number : parseInt(String(q.number), 10) }))
      .filter((x) => Number.isFinite(x.n));
    checks++;
    if (numeric.length >= 2) {
      for (let i = 1; i < numeric.length; i++) {
        const prev = numeric[i - 1].n as number;
        const cur = numeric[i].n as number;
        if (cur !== prev + 1) {
          // cur === prev has two distinct realities: the parser duplicated a
          // block (stems identical — provable parse error, severity error) or
          // the SHEET itself prints one number twice ("31, 32, 33, 33, 34, 35"
          // — a teacher's numbering typo kept faithfully; differing stems
          // prove the two items are distinct questions, severity warning).
          const isDup = cur === prev;
          const sameStem =
            isDup &&
            normStemKey(String(numeric[i - 1].q.stem || '')) === normStemKey(String(numeric[i].q.stem || ''));
          add({
            rule: 'SEQ_NUMBER',
            severity: isDup ? (sameStem ? 'error' : 'warning') : 'warning',
            sectionRowId: sec.rowId,
            questionId: numeric[i].q.id,
            message: isDup
              ? sameStem
                ? `Duplicate question number ${cur} in section ${sec.rowId}.`
                : `Printed number ${cur} appears twice in section ${sec.rowId} (distinct items — the sheet reuses the number).`
              : `Numbering jumps from ${prev} to ${cur} in section ${sec.rowId} (${Math.abs(cur - prev) - 1} missing).`,
            suggestedFix: isDup
              ? sameStem
                ? 'Re-number the questions of this section sequentially.'
                : 'Verify against the original sheet: two distinct items share the printed number.'
              : `Verify whether questions ${Math.min(prev, cur) + 1}–${Math.max(prev, cur) - 1} were dropped by OCR, or re-number sequentially.`,
            autoFix: 'renumber',
          });
        }
      }
    }

    // ---- 2. Section mark total == sum of question marks ----
    checks++;
    const sumMarks = Math.round(sec.questions.reduce((s, q) => s + (Number.isFinite(q.mark) ? q.mark : 0), 0) * 100) / 100;
    const declared = Math.round((sec.markTotal || 0) * 100) / 100;
    if (sec.questions.length > 0 && Math.abs(declared - sumMarks) > 0.01) {
      add({
        rule: 'SECTION_MARKS',
        severity: Math.abs(declared - sumMarks) > 1 ? 'error' : 'warning',
        sectionRowId: sec.rowId,
        message: `Section ${sec.rowId} declares ${declared} marks but its questions sum to ${sumMarks}.`,
        suggestedFix: `Recalculate the section total to ${sumMarks}.`,
        autoFix: 'recalc_marks',
      });
    }

    // ---- Per-question checks ----
    const seenStems = new Map<string, number>();
    for (const q of sec.questions) {
      // 3. MCQ options
      if (q.type === 'multiple_choice') {
        checks++;
        const optCount = q.options?.length || 0;
        if (optCount < 2) {
          add({
            rule: 'MCQ_OPTIONS',
            severity: 'error',
            sectionRowId: sec.rowId,
            questionId: q.id,
            message: `MCQ #${q.displayNumber} has ${optCount || 'no'} options.`,
            suggestedFix: 'Re-check the OCR of the options line for this question.',
          });
        } else if (optCount > 5) {
          add({
            rule: 'MCQ_OPTIONS',
            severity: 'warning',
            sectionRowId: sec.rowId,
            questionId: q.id,
            message: `MCQ #${q.displayNumber} has ${optCount} options — unusual for a standard exam.`,
            suggestedFix: 'Verify option extraction; inline choices may have been mis-split.',
          });
        }

        // 4. Answer must reference an existing option id
        const ans = (q.correctAnswer || '').trim().toLowerCase();
        if (ans && optCount > 0 && q.options) {
          checks++;
          const exists = q.options.some((o) => o.id.toLowerCase() === ans);
          if (!exists) {
            add({
              rule: 'ANSWER_VALID',
              severity: 'error',
              sectionRowId: sec.rowId,
              questionId: q.id,
              message: `Answer "${q.correctAnswer}" of MCQ #${q.displayNumber} is not one of its option keys (${q.options.map((o) => o.id).join(', ')}).`,
              suggestedFix: 'Clear the invalid answer so it can be re-solved.',
              autoFix: 'clear_invalid_answer',
            });
          }
        }
      }

      // 5. Mark values
      checks++;
      if (!(q.mark > 0)) {
        add({
          rule: 'MARK_VALUES',
          severity: 'error',
          sectionRowId: sec.rowId,
          questionId: q.id,
          message: `Question #${q.displayNumber} has mark ${q.mark}.`,
          suggestedFix: `Snap to the nearest standard mark (${STANDARD_MARKS.join(', ')}).`,
          autoFix: 'snap_mark',
        });
      } else if (!STANDARD_MARKS.includes(q.mark)) {
        add({
          rule: 'MARK_VALUES',
          severity: 'info',
          sectionRowId: sec.rowId,
          questionId: q.id,
          message: `Question #${q.displayNumber} carries a non-standard mark (${q.mark}).`,
          suggestedFix: `Snap to the nearest standard mark (${STANDARD_MARKS.join(', ')}) if this is an OCR slip.`,
          autoFix: 'snap_mark',
        });
      }

      // 6. Empty stem
      checks++;
      if (!q.stem || !q.stem.trim()) {
        add({
          rule: 'EMPTY_STEM',
          severity: 'error',
          sectionRowId: sec.rowId,
          questionId: q.id,
          message: `Question #${q.displayNumber} has an empty stem.`,
          suggestedFix: 'Re-check OCR for this line; the stem may have been swallowed.',
        });
      }

      // 7. Duplicate stems within a section
      checks++;
      const key = normStemKey(q.stem || '');
      if (key.length >= 12) {
        if (seenStems.has(key)) {
          add({
            rule: 'DUP_STEM',
            severity: 'warning',
            sectionRowId: sec.rowId,
            questionId: q.id,
            message: `Question #${q.displayNumber} duplicates #${sec.questions[seenStems.get(key)!].displayNumber} (identical stem).`,
            suggestedFix: 'Verify the page was not double-fed into the scanner / OCR.',
          });
        } else {
          seenStems.set(key, sec.questions.indexOf(q));
        }
      }

      // 8. Word-bank questions need a bank
      if (q.type === 'word_bank_fill') {
        checks++;
        if (!q.wordBankWords?.length && !sec.wordBank?.length) {
          add({
            rule: 'WORD_BANK',
            severity: 'warning',
            sectionRowId: sec.rowId,
            questionId: q.id,
            message: `Word-bank question #${q.displayNumber} has no candidate word bank.`,
            suggestedFix: 'Re-check OCR around the word box for this section.',
          });
        }
      }
    }

    // ---- 9. Matching column balance ----
    if (sec.matchingColumns) {
      checks++;
      const a = sec.matchingColumns.columnA.length;
      const b = sec.matchingColumns.columnB.length;
      if (a !== b) {
        add({
          rule: 'MATCHING_BALANCE',
          severity: 'warning',
          sectionRowId: sec.rowId,
          message: `Matching columns are unbalanced in section ${sec.rowId} (A: ${a} vs B: ${b}).`,
          suggestedFix: 'Verify OCR of both columns; extra items may be distractors.',
        });
      }
    }
  }

  return {
    ranAt: new Date().toISOString(),
    passed: checks - violations.length,
    total: checks,
    violations,
  };
}

/**
 * Apply an auto-fixable violation. Returns a NEW document (immutable update).
 * Returns the original document when the violation is not auto-fixable.
 */
export function applyInvariantFix(doc: ExamDocument, violationId: string): ExamDocument {
  const report = doc.invariants;
  const violation = report?.violations.find((v) => v.id === violationId);
  if (!violation || !violation.autoFix || violation.isFixed) return doc;

  const mapQuestion = (doc_: ExamDocument, fn: (q: QuestionItem) => QuestionItem): ExamDocument => ({
    ...doc_,
    sections: doc_.sections.map((sec) => ({
      ...sec,
      questions: sec.questions.map(fn),
    })),
  });

  switch (violation.autoFix) {
    case 'renumber': {
      // Re-number sequentially within the violation's section (or all sections).
      const sections = doc.sections.map((sec) => {
        if (violation.sectionRowId && sec.rowId !== violation.sectionRowId) return sec;
        let n = 1;
        return {
          ...sec,
          questions: sec.questions.map((q) => ({
            ...q,
            number: n,
            displayNumber: String(n++),
            answerMeta: q.answerMeta, // untouched
          })),
        };
      });
      return finishFix({ ...doc, sections }, violationId);
    }
    case 'recalc_marks': {
      const sections = doc.sections.map((sec) =>
        sec.rowId === violation.sectionRowId
          ? { ...sec, markTotal: Math.round(sec.questions.reduce((s, q) => s + q.mark, 0) * 100) / 100 }
          : sec,
      );
      return finishFix({ ...doc, sections }, violationId);
    }
    case 'clear_invalid_answer': {
      const next = mapQuestion(doc, (q) =>
        q.id === violation.questionId ? { ...q, correctAnswer: '', answerMeta: undefined } : q,
      );
      return finishFix(next, violationId);
    }
    case 'snap_mark': {
      const next = mapQuestion(doc, (q) => {
        if (q.id !== violation.questionId) return q;
        const snapped = STANDARD_MARKS.reduce((best, m) =>
          Math.abs(m - q.mark) < Math.abs(best - q.mark) ? m : best, STANDARD_MARKS[0]);
        return { ...q, mark: snapped };
      });
      return finishFix(next, violationId);
    }
    default:
      return doc;
  }
}

function finishFix(doc: ExamDocument, violationId: string): ExamDocument {
  const next = {
    ...doc,
    invariants: doc.invariants
      ? {
          ...doc.invariants,
          violations: doc.invariants.violations.map((v) =>
            v.id === violationId ? { ...v, isFixed: true } : v,
          ),
        }
      : undefined,
  };
  return next;
}

/** Re-run checks after edits; keeps fix history out of the fresh report. */
export function refreshInvariants(doc: ExamDocument): ExamDocument {
  return { ...doc, invariants: runInvariantChecks(doc) };
}
