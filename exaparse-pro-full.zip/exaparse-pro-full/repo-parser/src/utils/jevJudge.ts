import { ExamDocument, JevJudgement, QuestionItem, QuestionType } from '../types/exam';
import { JevConfig } from '../types/settings';
import { normalizeForFingerprint } from './answerCache';
import { kvGetMany, kvSet } from './localStore';
import { AdjudicationCell } from './adjudicator';

/**
 * Jev judge client (judge-ONLY protocol).
 *
 * Jev never parses text and never authors exam answers — it only evaluates
 * what the offline parser + adjudicator already produced:
 *   • Noul  → P(the proposed correctAnswer is correct)  → confidence cascade
 *   • Choice → question category (QuestionType) + skill area
 *   • Score → extracted-question well-formedness (feeds the Trust Engine)
 *
 * Efficiency contract (hard requirement):
 *   1. ALL decisions for one question ride in ONE judge call (Jev evaluates
 *      many typed questions against a shared state in parallel).
 *   2. Questions are batched `config.batchSize` per call — one request per
 *      ~20-40 questions, never one call per decision.
 *   3. Every (stem + options + correctAnswer) tuple is fingerprinted and
 *      cached in IndexedDB — re-runs are near-zero calls.
 *
 * Confidence cascade (TypeSafe "confidence-gated routing" pattern):
 *   pCorrect >= threshold        → 'correct'   (act)
 *   pCorrect <= lowBand          → 'incorrect' (act)
 *   otherwise                    → 'uncertain' → escalate to /api/adjudicate
 *
 * This module is THROW-FREE: every failure mode returns a result object.
 */

const CACHE_PREFIX = 'jev:';

export interface JevJudgeStats {
  selected: number;
  judged: number;
  cacheHits: number;
  skipped: number;
  calls: number;
  backend: 'jev' | 'llm-fallback' | 'none';
  model: string;
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  correct: number;
  incorrect: number;
  uncertain: number;
}

export interface JevJudgeResult {
  ok: boolean;
  error?: string;
  /** questionId -> fresh or cached judgement (only for questions actually judged). */
  judgements: Map<string, JevJudgement>;
  /** Mid-band questions the caller should escalate to /api/adjudicate. */
  escalations: AdjudicationCell[];
  stats: JevJudgeStats;
  warnings: string[];
}

// ---------- fingerprint (reuse the answer-cache normalization) ----------

/** Stable content fingerprint of the judged tuple: stem + options + correctAnswer. */
export function jevFingerprint(q: Pick<QuestionItem, 'stem' | 'options' | 'correctAnswer'>): string {
  const parts = [
    normalizeForFingerprint(q.stem || ''),
    (q.options || []).map((o) => normalizeForFingerprint(o.text)).join('|'),
    normalizeForFingerprint(q.correctAnswer || ''),
  ];
  const raw = parts.join('::');
  let h = 5381;
  for (let i = 0; i < raw.length; i++) {
    h = ((h << 5) + h + raw.charCodeAt(i)) | 0;
  }
  return `${CACHE_PREFIX}${(h >>> 0).toString(36)}`;
}

// ---------- selection ----------

export interface SelectionReport {
  selected: QuestionItem[];
  skipped: number;
}

/**
 * Only judge what matters: solved questions with non-empty stems, priority to
 * contested/single-trust questions (collectContestedCells-style priority).
 * Verified questions still get judged (they fill category + quality) but go
 * last — batches are cut in priority order, so a budget cut drops them first.
 */
export function selectJudgable(doc: ExamDocument): SelectionReport {
  const contestedFirst: QuestionItem[] = [];
  const rest: QuestionItem[] = [];
  let skipped = 0;

  for (const sec of doc.sections) {
    for (const q of sec.questions) {
      if (!q.stem || !q.stem.trim() || !q.correctAnswer || !q.correctAnswer.trim()) {
        skipped++;
        continue;
      }
      if (q.trustLevel === 'contested' || q.trustLevel === 'single') contestedFirst.push(q);
      else rest.push(q);
    }
  }
  return { selected: [...contestedFirst, ...rest], skipped };
}

/** Count of questions the Judge button would evaluate (for UI affordances). */
export function countJudgable(doc: ExamDocument): number {
  let n = 0;
  for (const sec of doc.sections) {
    for (const q of sec.questions) {
      if (q.stem && q.stem.trim() && q.correctAnswer && q.correctAnswer.trim()) n++;
    }
  }
  return n;
}

// ---------- typed question construction (TypeSafe System One primitives) ----------

const QUESTION_TYPE_OPTIONS: Record<string, string> = {
  multiple_choice: 'A stem with lettered options a/b/c/d to choose from',
  cloze_item: 'A passage with numbered blanks to fill from given choices',
  word_bank_fill: 'A sentence completed with a word taken from a word box',
  fill_blank: 'A sentence where the answer is written into a blank',
  matching: 'Match items from column A to column B',
  true_false: 'A statement judged true or false',
  short_answer: 'A brief written answer, one word or a few words',
  long_answer_essay: 'A long written response, paragraph or essay',
  unscramble: 'Rearrange scrambled words into a correct sentence',
  form_in_parentheses: 'Put the word in parentheses into the correct grammatical form',
  combine_sentences: 'Join two sentences into one using a cue',
  active_passive: 'Rewrite between active and passive voice',
  error_correction: 'Find and correct a mistake in the sentence',
  letter_reorder: 'Rearrange jumbled letters into a word',
  inline_choice: 'A blank inside the sentence with numbered inline choices',
  dialogue_response: 'Choose or write the fitting line of a dialogue',
  odd_one_out: 'Pick the word that does not belong in a group',
  phonetic_pronunciation: 'Pick the word whose underlined part sounds different',
  sentence_ordering: 'Order sentences into a coherent paragraph',
  picture_description: 'A question that refers to a picture',
  translation: 'Translate between Persian and English',
  definition_matching: 'Match definitions to words',
  numerical_calculation: 'A math calculation item',
};

const SKILL_AREAS: Record<string, string> = {
  Vocabulary: 'Word knowledge: synonyms, definitions, word forms, collocations',
  Grammar: 'Structures, tenses, voice, conditionals, sentence transformation',
  Reading: 'Comprehension of a passage or text',
  Writing: 'Guided writing, punctuation, ordering into a text',
  Listening: 'Items tied to an audio script or listening transcript',
  General: 'Does not fit any named skill area (escape hatch)',
};

interface Bundle {
  questions: Record<string, any>;
  itemStates: Record<string, any>;
}

function buildQuestionBundle(batch: QuestionItem[], doc: ExamDocument, cfg: JevConfig): Bundle {
  const questions: Record<string, any> = {};
  const itemStates: Record<string, any> = {};

  const sectionOf = new Map<string, ExamDocument['sections'][number]>();
  for (const sec of doc.sections) {
    for (const q of sec.questions) sectionOf.set(q.id, sec);
  }

  for (const q of batch) {
    const sec = sectionOf.get(q.id);
    // Shared state slice for this question (Jev ingests the state once and
    // evaluates every question against it in parallel).
    const passage = q.parentContextText || sec?.passageText || undefined;
    itemStates[q.id] = {
      stem: q.stem,
      proposedAnswer: q.correctAnswer || '',
      options: q.options && q.options.length > 0
        ? q.options.map((o) => `${o.id}) ${o.text}`).join(' | ')
        : undefined,
      wordBank: q.wordBankWords && q.wordBankWords.length > 0
        ? q.wordBankWords.join(', ')
        : sec?.wordBank && sec.wordBank.length > 0
          ? sec.wordBank.join(', ')
          : undefined,
      passage: passage ? String(passage).slice(0, 900) : undefined,
    };

    // 1) Correctness (Noul → P(true)) — the core judge decision.
    questions[`c:${q.id}`] = {
      type: 'noul',
      instructions: {
        question: `Given the item \`${q.id}\` in the state's items map (stem, options/wordBank, any passage), is its 'proposedAnswer' the correct answer to this exam question?`,
        itemId: q.id,
      },
      criteria: {
        true: 'The proposed answer is the correct answer to the question as printed.',
        false: 'The proposed answer is wrong, unsupported by the state, or the question is too garbled to verify.',
      },
    };

    // 2) Category (Choice) — classify into the QuestionType enum + escape hatch.
    questions[`k:${q.id}`] = {
      type: 'choice',
      instructions: {
        question: `Which exam-question format is item \`${q.id}\` (see the items map in the state)? Use the 'other' option only when nothing fits.`,
        itemId: q.id,
      },
      criteria: { ...QUESTION_TYPE_OPTIONS, other: 'None of the listed formats fit' },
    };

    // 3) Skill area (Choice) — small useful extra, same call, ~zero latency cost.
    questions[`s:${q.id}`] = {
      type: 'choice',
      instructions: {
        question: `Which skill area does item \`${q.id}\` (see the items map in the state) primarily test?`,
        itemId: q.id,
      },
      criteria: SKILL_AREAS,
    };

    // 4) Optional extraction-quality (Score, ordered 0..3) — feeds the Trust Engine.
    if (cfg.judgeQuality) {
      questions[`q:${q.id}`] = {
        type: 'score',
        instructions: {
          question: `How well-formed is the extracted question text for item \`${q.id}\` (clean stem, intact options, no OCR garbage)?`,
          itemId: q.id,
        },
        criteria: [
          'Garbled: mostly unreadable or structurally broken',
          'Poor: readable but many OCR artifacts or missing parts',
          'Good: minor artifacts only',
          'Clean: perfectly formed question',
        ],
      };
    }
  }

  return { questions, itemStates };
}

// ---------- cascade ----------

export function verdictFromP(pCorrect: number, cfg: JevConfig): JevJudgement['verdict'] {
  if (pCorrect >= cfg.threshold) return 'correct';
  if (pCorrect <= cfg.lowBand) return 'incorrect';
  return 'uncertain';
}

// ---------- main entry ----------

export async function judgeDocument(
  doc: ExamDocument,
  cfg: JevConfig,
  providerConfig: any,
  opts: { forceRejudgeIds?: Set<string>; onProgress?: (done: number, total: number, note: string) => void } = {},
): Promise<JevJudgeResult> {
  const emptyStats: JevJudgeStats = {
    selected: 0, judged: 0, cacheHits: 0, skipped: 0, calls: 0,
    backend: 'none', model: cfg.model || 'typesafe/jev-1.13',
    promptTokens: 0, completionTokens: 0, totalTokens: 0,
    correct: 0, incorrect: 0, uncertain: 0,
  };
  try {
    const selection = selectJudgable(doc);
    const stats: JevJudgeStats = { ...emptyStats, selected: selection.selected.length, skipped: selection.skipped };
    const judgements = new Map<string, JevJudgement>();
    const escalations: AdjudicationCell[] = [];
    const warnings: string[] = [];

    if (selection.selected.length === 0) {
      return { ok: true, judgements, escalations, stats, warnings: ['No solved questions with non-empty stems to judge.'] };
    }

    // ---- 1. Fingerprint + cache lookup (never re-judge an unchanged tuple) ----
    const fpOf = new Map<string, string>();
    for (const q of selection.selected) fpOf.set(q.id, jevFingerprint(q));

    const cacheMap = await kvGetMany<JevJudgement>([...new Set([...fpOf.values()])]);
    const toJudge: QuestionItem[] = [];
    for (const q of selection.selected) {
      const fp = fpOf.get(q.id)!;
      const hit = opts.forceRejudgeIds?.has(q.id) ? undefined : cacheMap.get(fp);
      if (hit && hit.fingerprint === fp) {
        judgements.set(q.id, { ...hit, cached: true });
        stats.cacheHits++;
      } else {
        toJudge.push(q);
      }
    }

    const hasFallback = !!providerConfig;
    const nativeEnabled = cfg.enabled && !!cfg.baseUrl && !!cfg.apiKey;
    if (toJudge.length > 0 && !nativeEnabled && !hasFallback) {
      return {
        ok: false,
        error: 'No judge backend available: enable Jev in Settings or configure the fallback AI provider.',
        judgements,
        escalations,
        stats,
        warnings,
      };
    }

    // ---- 2. Batched judging: one call per ~batchSize questions ----
    const batchSize = Math.max(1, Math.min(60, Math.round(cfg.batchSize || 20)));
    let backend: JevJudgeStats['backend'] = nativeEnabled ? 'jev' : 'llm-fallback';
    let model = cfg.model || 'typesafe/jev-1.13';

    for (let i = 0; i < toJudge.length; i += batchSize) {
      const batch = toJudge.slice(i, i + batchSize);
      opts.onProgress?.(Math.min(i + batch.length, toJudge.length), toJudge.length, `Judging questions ${i + 1}–${i + batch.length} of ${toJudge.length}`);
      const bundle = buildQuestionBundle(batch, doc, cfg);
      const state = {
        exam: {
          course: doc.header?.courseName,
          grade: doc.header?.grade || doc.header?.gradeAndMajor,
          term: doc.header?.term,
        },
        items: bundle.itemStates,
      };

      try {
        const res = await fetch('/api/judge', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            state,
            questions: bundle.questions,
            jevConfig: { enabled: cfg.enabled, baseUrl: cfg.baseUrl, apiKey: cfg.apiKey, model: cfg.model },
            providerConfig: nativeEnabled ? undefined : providerConfig,
          }),
        });

        if (!res.ok) {
          const err = await res.json().catch(() => ({}));
          warnings.push(`Judge call failed (HTTP ${res.status}): ${err.error || res.statusText}. Batch of ${batch.length} left unjudged.`);
          continue;
        }

        const data = await res.json();
        backend = data.backend || backend;
        model = data.model || model;
        stats.calls += data.calls || 1;
        stats.backend = backend;
        stats.model = model;
        if (data.usage) {
          stats.promptTokens += data.usage.promptTokens || 0;
          stats.completionTokens += data.usage.completionTokens || 0;
          stats.totalTokens += data.usage.totalTokens || 0;
        }
        if (Array.isArray(data.warnings)) warnings.push(...data.warnings);

        const answers: Record<string, any> = data.answers || {};
        const now = new Date().toISOString();

        for (const q of batch) {
          const correctness = answers[`c:${q.id}`];
          const category = answers[`k:${q.id}`];
          const skill = answers[`s:${q.id}`];
          const quality = answers[`q:${q.id}`];

          const pCorrect = correctness?.type === 'noul' && typeof correctness.p === 'number' ? correctness.p : undefined;
          if (pCorrect === undefined) {
            warnings.push(`No correctness verdict returned for one question — left unjudged.`);
            continue;
          }

          const validCategory =
            category?.type === 'choice' && category.choice && !category.invalid
              ? (category.choice as QuestionType)
              : undefined;
          const validSkill =
            skill?.type === 'choice' && skill.choice && !skill.invalid ? skill.choice : undefined;
          const qualityScore =
            quality?.type === 'score' && typeof quality.score === 'number' && quality.score >= 0
              ? quality.score
              : undefined;

          const judgement: JevJudgement = {
            category: validCategory,
            skillArea: validSkill,
            pCorrect,
            quality: qualityScore,
            qualityConfidence: quality?.confidence,
            verdict: verdictFromP(pCorrect, cfg),
            judgedAt: now,
            model,
            backend: backend === 'jev' ? 'jev' : 'llm-fallback',
            fingerprint: fpOf.get(q.id),
          };

          judgements.set(q.id, judgement);
          stats.judged++;
          if (judgement.verdict === 'correct') stats.correct++;
          else if (judgement.verdict === 'incorrect') stats.incorrect++;
          else {
            stats.uncertain++;
            // Mid-band → escalate ONLY these to the existing 3-vote adjudicator.
            const sec = doc.sections.find((s) => s.rowId === q.sectionRowId);
            if (cfg.autoEscalate && q.options && q.options.length >= 2) {
              escalations.push({
                questionId: q.id,
                sectionRowId: q.sectionRowId,
                number: q.displayNumber,
                type: q.type,
                stem: q.stem,
                optionKeys: q.options.map((o) => o.id),
                wordBankWords: q.wordBankWords || sec?.wordBank,
                passageSnippet: (q.parentContextText || sec?.passageText || '').slice(0, 300) || undefined,
              });
            }
          }

          // Persist to the judge cache (even uncertain — re-runs stay near-free).
          kvSet(fpOf.get(q.id)!, judgement).catch(() => undefined);
        }
      } catch (e: any) {
        warnings.push(`Judge call for batch ${Math.floor(i / batchSize) + 1} failed: ${e?.message || e}. Those questions were left unjudged.`);
      }
    }

    opts.onProgress?.(toJudge.length, toJudge.length, 'Judging complete');

    return { ok: stats.judged > 0 || stats.cacheHits > 0, judgements, escalations, stats, warnings };
  } catch (e: any) {
    return {
      ok: false,
      error: e?.message || 'Unexpected failure during judging.',
      judgements: new Map(),
      escalations: [],
      stats: emptyStats,
      warnings: [],
    };
  }
}

// ---------- immutable document application ----------

/**
 * Stamp judgements onto questions. Returns a NEW document; never mutates.
 * Jev verdicts never change answers — they only attach evidence (q.jev).
 */
export function applyJudgements(doc: ExamDocument, judgements: Map<string, JevJudgement>): ExamDocument {
  if (judgements.size === 0) return doc;
  return {
    ...doc,
    sections: doc.sections.map((sec) => ({
      ...sec,
      questions: sec.questions.map((q): QuestionItem => {
        const j = judgements.get(q.id);
        if (!j) return q;
        return { ...q, jev: j };
      }),
    })),
  };
}
