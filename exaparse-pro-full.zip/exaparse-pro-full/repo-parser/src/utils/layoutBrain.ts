/**
 * layoutBrain.ts — the perception → fusion → verification sectioning brain.
 *
 * Instead of making irreversible sectioning decisions from ONE signal family
 * (text patterns), the brain perceives ALL structural signals at once, fuses
 * them, and only commits a separation when independent signals agree.
 * Every committed section carries an evidence receipt (auditable).
 *
 * Input : BrainDoc (scratch/brain-qu2/<stem>.json) — merged geometry
 *         (PyMuPDF tables/rules/rects/font data) + logical text lines
 *         (pdftotext -bbox-layout) per page.
 * Output: BrainResult — confirmed sections + fallback ranges + diagnostics.
 *
 * Stages:
 *   1 PERCEIVE  — headers, letter openers, mark tokens, table classification
 *                 (marksTable / bubbleGrid / matchingLayout / content),
 *                 boxes-in-cells, full-width rules, body font size.
 *   2 FUSE      — one spatial walk; boundary events from ALL sources; every
 *                 candidate section collects evidence from every signal.
 *   3 VERIFY    — cross-checks: letter-sequence continuity, mark plausibility,
 *                 mark-sum vs printed total, header/letter agreement, rule
 *                 corroboration. Confidence = weighted agreement.
 *   4 COMMIT    — confirmed sections (>= threshold) + row merging under the
 *                 same group header; uncovered ranges become fallback blocks
 *                 (downstream = today's engine, so worst case = status quo).
 */

export interface BrainLine {
  text: string;
  size: number;
  bold: boolean;
  bbox: number[]; // [x0, y0, x1, y1]
  page: number; // 0-based, filled by normalize
  src?: string;
}

export interface BrainCell {
  r: number;
  c: number;
  text: string;
  bbox: number[];
  boxes: number; // boxed rects whose center falls inside this cell
}

export type TableKind = 'marksTable' | 'bubbleGrid' | 'matchingLayout' | 'contentTable' | 'empty';

export interface BrainTable {
  page: number;
  bbox: number[];
  rows: number;
  cols: number;
  cellBboxes?: number[][]; // per-cell [x0,y0,x1,y1] (input, consumed by classifyTables)
  cellTexts?: string[][]; // per-row cell text matrix (input)
  cells: BrainCell[];
  kind: TableKind;
  letterRows: { letter: string; mark?: number; instruction: string; bbox: number[] }[];
  groupHeader?: string; // colspan header row inside the table (e.g. "Grammar")
}

export interface BrainPage {
  width: number;
  height: number;
  hlines: number[][]; // [x, y, width]
  rects: number[][];
  tables: BrainTable[];
  lines: BrainLine[];
}

export interface BrainDoc {
  file: string;
  pages: BrainPage[];
}

export interface Evidence {
  header: boolean;
  letter: boolean;
  mark: boolean;
  table: boolean;
  rules: boolean;
  ladder: number; // consecutive numbered lines detected
  boxes: number;
  /** set on candidates born from a numeric (radif) section opener */
  numeric?: number;
}

export interface BrainRow {
  letter: string;
  mark?: number;
  headerText?: string;
  lineStart: number;
  lineEnd: number;
  confidence: number;
  /** The row's own content lines, tracked through every merge/fold so the
   *  bridge can emit one block PER ROW (the graded shape). Strip-born rows
   *  (marks-table letters) have no own lines — their instruction is the text. */
  lines?: BrainLine[];
}

export interface BrainSection {
  index: number;
  pageStart: number;
  pageEnd: number;
  headerText?: string;
  subject?: string;
  boundaryKind?: 'header' | 'letter' | 'tableRow' | 'rule' | 'matching' | 'content';
  lines: BrainLine[];
  rows: BrainRow[]; // lettered sub-rows (when the section is row-structured)
  evidence: Evidence;
  confidence: number;
  confirmed: boolean;
  demoted?: boolean; // ladder-restart demotion — sticky, re-scoring must not resurrect
  notes: string[];
}

export interface BrainDebugCandidate {
  index: number;
  note: string;
  page: number;
  y: number;
  headerText?: string;
  subject?: string;
  rows: { letter: string; mark?: number }[];
  lineCount: number;
  evidence: Evidence;
  confidence: number;
}

export interface BrainResult {
  file: string;
  sections: BrainSection[];
  fallbacks: BrainSection[];
  /** The full post-watermark-filter line list, document order — the bridge
   *  uses it to guarantee FULL coverage (nothing outside the confirmed
   *  structure is ever dropped). */
  lines: BrainLine[];
  /** Printed answer-key boundary: lines at/after this are key metadata. */
  keyBoundary?: { page: number; y: number; text: string };
  notes: string[];
  __debug?: {
    events: { kind: string; page: number; y: number; letter?: string; mark?: number; headerText?: string; rows?: { letter: string; mark?: number }[]; note: string }[];
    candidates: BrainDebugCandidate[];
    dropped: number[];
  };
  stats: {
    bodySize: number;
    headerCount: number;
    letterCount: number;
    marksTables: number;
    sumOfMarks: number;
    printedTotal?: number;
  };
}

// ---------------------------------------------------------------- utilities

const FA_DIGITS: Record<string, string> = {
  '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4', '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
  '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4', '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
};

export function toLatinDigits(s: string): string {
  return s.replace(/[۰-۹٠-٩]/g, (d) => FA_DIGITS[d] ?? d);
}

export function reverseStr(s: string): string {
  return s.split('').reverse().join('');
}

// ---- row-letter identity (Latin A-Z + Persian row letters) -----------------
// Persian exam sheets label their rows either with Latin letters (A..R) or
// with Persian letters (الف ب پ ت ...). ALL sequence arithmetic (advancement,
// regression, min/max, sorting) goes through letterRank so both alphabets
// behave identically. Ranks encode the alphabet in the base (Latin 0..25,
// Persian 100+), so a mixed-alphabet paper can never be misread as a gap or
// a regression — the caller sees a base switch and resets its expectation.
export const PERSIAN_ROW_ALPHABET = 'بپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی'; // rank = index + 1 (الف = 0)
const RANK_PERSIAN_BASE = 100;

const PERSIAN_ROW_LETTER_CLASS = 'بپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی';

/** True for a token that can be a ROW letter: A-Z, الف, هـ, or one Persian letter. */
export function isRowLetterToken(s: string): boolean {
  return /^[A-Z]$/.test(s) || s === 'الف' || s === 'هـ' || (s.length === 1 && PERSIAN_ROW_LETTER_CLASS.includes(s));
}

/** Alphabet-encoded rank of a row letter, or undefined when it is not one. */
export function letterRank(letter: string): number | undefined {
  if (/^[A-Z]$/.test(letter)) return letter.charCodeAt(0) - 65;
  if (letter === 'الف' || letter === 'هـ') return RANK_PERSIAN_BASE;
  const i = PERSIAN_ROW_LETTER_CLASS.indexOf(letter);
  return i >= 0 ? RANK_PERSIAN_BASE + 1 + i : undefined;
}

/** Inverse of letterRank (Latin returns uppercase, Persian returns the letter). */
export function letterFromRank(rank: number): string {
  if (rank < 0) return '';
  if (rank < RANK_PERSIAN_BASE) return String.fromCharCode(65 + rank);
  if (rank === RANK_PERSIAN_BASE) return 'الف';
  return PERSIAN_ROW_LETTER_CLASS[rank - RANK_PERSIAN_BASE - 1] ?? '';
}

const sameAlphabet = (a: number, b: number) => (a < RANK_PERSIAN_BASE) === (b < RANK_PERSIAN_BASE);

/** True when `next` is exactly the successor of `prev` in the same alphabet. */
export function letterAdvance(prev: string, next: string): boolean {
  const a = letterRank(prev);
  const b = letterRank(next);
  return a !== undefined && b !== undefined && sameAlphabet(a, b) && b === a + 1;
}

/** True when `next` moves FORWARD in the same alphabet, skipping allowed.
 *  Persian papers routinely skip letters (الف ب ج د skips پ ت ث), and Latin
 *  part-restarts may skip too — forward motion is evidence, a gap is not a
 *  crime, only REGRESSION suggests a key/copy. */
export function letterForward(prev: string, next: string): boolean {
  const a = letterRank(prev);
  const b = letterRank(next);
  return a !== undefined && b !== undefined && sameAlphabet(a, b) && b > a;
}

/** Successor letter in the same alphabet ('A'->'B', 'الف'->'ب'); '' at the end. */
export function nextLetter(letter: string): string {
  const r = letterRank(letter);
  if (r === undefined) return '';
  return letterFromRank(r + 1);
}

/** Row-letter matcher used by cell/text perception: strict token or fused "X) text". */
const ROW_LETTER_CORE = `(?:[A-Z]|الف|هـ|[${PERSIAN_ROW_LETTER_CLASS}])`;
const ROW_LETTER_STRICT_RE = new RegExp(`^\\(?(${ROW_LETTER_CORE})[\\).:ـ]?$`);
const ROW_LETTER_FUSED_RE = new RegExp(`^\\(?(${ROW_LETTER_CORE})[\\).:ـ]\\s+\\S`);

const SUBJECT_KEYWORDS: { subject: string; keys: string[] }[] = [
  { subject: 'Vocabulary', keys: ['vocabulary', 'vocab', 'واژگان', 'ژاژوا', 'لغت', 'تغل', 'word bank'] },
  { subject: 'Grammar', keys: ['grammar', 'دستور', 'روتسد', 'قواعد', 'داقوق'] },
  { subject: 'Reading', keys: ['reading', 'درک مطلب', 'لبتم کرد', 'reading comprehension'] },
  { subject: 'Writing', keys: ['writing', 'نوشتاری', 'یراتشون', 'نوشتار'] },
  { subject: 'Listening', keys: ['listening', 'شنیداری', 'یرادینش'] },
  { subject: 'Speaking', keys: ['speaking', 'گفتاری', 'یراتفگ', 'مکالمه', 'هملاکم'] },
  { subject: 'Pronunciation', keys: ['pronunciation', 'تلفظ', 'ظفلت'] },
  { subject: 'Language Function', keys: ['language function', 'کارکرد زبانی', 'ینابز درکراق'] },
];

export function matchSubject(text: string): string | undefined {
  const t = toLatinDigits(text).toLowerCase().trim();
  if (!t) return undefined;
  const rev = reverseStr(t).toLowerCase();
  for (const { subject, keys } of SUBJECT_KEYWORDS) {
    for (const k of keys) {
      const kk = k.toLowerCase();
      if (t.includes(kk) || rev.includes(kk)) return subject;
    }
  }
  return undefined;
}

const yCenter = (b: number[]) => (b[1] + b[3]) / 2;
const xCenter = (b: number[]) => (b[0] + b[2]) / 2;

function pointInBbox(x: number, y: number, b: number[], pad = 0): boolean {
  return x >= b[0] - pad && x <= b[2] + pad && y >= b[1] - pad && y <= b[3] + pad;
}

function bboxArea(b: number[]): number {
  return Math.max(0, b[2] - b[0]) * Math.max(0, b[3] - b[1]);
}

function unionBbox(a: number[], b: number[]): number[] {
  return [Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[2], b[2]), Math.max(a[3], b[3])];
}

function parseMarkNum(s: string): number | undefined {
  const t = toLatinDigits(s).replace(/[.,]/g, '.').replace(/\s/g, '');
  const m = t.match(/^(\d{1,2})(?:\.(\d{1,2}))?$/);
  if (!m) return undefined;
  const v = parseFloat(m[1] + (m[2] !== undefined ? '.' + m[2] : ''));
  return isFinite(v) ? v : undefined;
}

// NFKC folds Arabic presentation forms (ﺻﻔﺤﻪ -> صفحه) — pdf.js emits the
// glyph-shaped codepoints for some embedders, and furniture matching must
// survive that. Matching uses BOTH storage orders (Persian may be reversed).
const nfkc = (s: string) => {
  try {
    return s.normalize('NFKC');
  } catch {
    return s;
  }
};

// watermark = print furniture (kanoon ads, brand lines, URLs). Persian lines
// may be stored visually reversed, so test BOTH orders against BOTH pattern
// sets. Only unambiguous ad furniture is matched (brand, discount-code, the
// kanoon service number) — generic words like شماره are NOT here to avoid
// swallowing real content.
const WM_PAT =
  /کانون|نوناک|کد\s*تخفیف|فیفتک|نمونه\s*سوال|لاوس\s*هنمن|خرید\s*کتاب|تایس|سایت|90008\d{4,}|55908\d{4,}/;
// assessment-center footers + continuation markers, e.g.
//   «ادامه ي سوالات در صفحه ي ششم» / مرکز سنجش و پایش کیفیت آموزشی /
//   نظام آموزش و پرورش - مرکز ارزشیابی — never exam content (G5: these were
//   confirmed as rule-boundary "sections" and once DROVE a whole parse).
const FOOTER_PAT = /مرکز\s*سنجش|سنجش\s*و\s*پایش|مرکز\s*ارزشیابی|کیفیت\s*آموزش|نظام\s*آموزش/;
const CONT_PAT = /ادامه\s*ي?\s*سوالات|ادامه\s*سوالات/;
const isWatermark = (l: BrainLine) => {
  if (l.size >= 40 || /kanoon|www\.|\.ir\b|\.com\b/i.test(l.text)) return true;
  const t = nfkc(l.text);
  const r = nfkc(reverseStr(l.text));
  if (WM_PAT.test(t) || WM_PAT.test(r)) return true;
  if (FOOTER_PAT.test(t) || FOOTER_PAT.test(r)) return true;
  if (CONT_PAT.test(t) || CONT_PAT.test(r)) return true;
  return false;
};

// ------------------------------------------------------------------ PERCEIVE

export interface Perception {
  bodySize: number;
  pages: BrainPage[];
  headers: BrainLine[];
  letterOpeners: { line: BrainLine; letter: string }[];
  markTokens: { line: BrainLine; value: number }[];
  /** Fused numeric section openers: "8 Grammar", "12 درک مطلب" — number +
   *  subject keyword on one line. The keyword is a strong prior, so these
   *  are anchors for the numeric (radif) section ladder. */
  numberOpeners: { line: BrainLine; num: number; subject: string; text: string }[];
  /** Bare bold integer lines in content (radif candidates, decided by the
   *  ladder in runLayoutBrain — never alone). */
  bareBoldNums: { line: BrainLine; num: number }[];
  /** Bare digit lines in the top/bottom margins: PAGE NUMBERS. Never marks
   *  (they used to be eaten as بارم and poison section marks) and never
   *  openers on their own. */
  pageNumbers: { line: BrainLine; num: number }[];
  printedTotal?: number;
  keyBoundary?: { page: number; y: number; text: string };
  fullRules: Map<number, number[]>; // page -> sorted y list of full-width rules
  /** Lines identified as MCQ option runs — never row openers. */
  optionLines: Set<BrainLine>;
}

export function perceive(doc: BrainDoc): Perception {
  // attach page indices, drop watermarks
  const pages: BrainPage[] = doc.pages.map((p, pi) => ({
    ...p,
    lines: p.lines
      .map((l) => ({ ...l, page: pi, bold: !!l.bold }))
      .filter((l) => !isWatermark(l)),
  }));

  // margin page numbers: a bare 1-3 digit line near the top/bottom edge is a
  // PAGE NUMBER — it must never serve as a بارم mark (p566h5f982's marks
  // 1..7 were page numbers) and never as a row opener on its own.
  const pageNumbers: { line: BrainLine; num: number }[] = [];
  const pageNumberLines = new Set<BrainLine>();
  for (const p of pages) {
    for (const l of p.lines) {
      const t = toLatinDigits(l.text.trim());
      if (!/^\d{1,3}$/.test(t)) continue;
      const yc = yCenter(l.bbox);
      if (yc < 0.085 * p.height || yc > 0.925 * p.height) {
        pageNumbers.push({ line: l, num: parseInt(t, 10) });
        pageNumberLines.add(l);
      }
    }
  }
  if (pageNumbers.length)
    for (const p of pages) p.lines = p.lines.filter((l) => !pageNumberLines.has(l));

  // global body size: char-count-weighted mode
  const sizeHist = new Map<string, number>();
  for (const p of pages)
    for (const l of p.lines) {
      const k = String(Math.round(l.size * 2) / 2);
      sizeHist.set(k, (sizeHist.get(k) ?? 0) + l.text.length);
    }
  let bodySize = 12;
  let best = 0;
  for (const [k, v] of sizeHist)
    if (v > best) {
      best = v;
      bodySize = parseFloat(k);
    }

  // full-width rules per page (cluster nearby y's, dedupe, drop scan noise)
  const fullRules = new Map<number, number[]>();
  for (const [pi, p] of pages.entries()) {
    const ys: number[] = [];
    for (const h of p.hlines) {
      const width = h[2];
      if (width >= 0.5 * p.width) ys.push(h[1]);
    }
    ys.sort((a, b) => a - b);
    const clustered: number[] = [];
    for (const y of ys) {
      if (!clustered.length || y - clustered[clustered.length - 1] > 3) clustered.push(y);
    }
    fullRules.set(pi, clustered);
  }

  // significant boxes per page (frames, word boxes — not table borders, not slivers)
  const sigBoxes = new Map<number, number[][]>();
  for (const [pi, p] of pages.entries()) {
    const arr: number[][] = [];
    for (const r of p.rects) {
      const a = bboxArea(r);
      const w = r[2] - r[0];
      const h = r[3] - r[1];
      if (a > 400 && a < 0.5 * p.width * p.height && w > 12 && h > 10 && h < 120) arr.push(r);
    }
    sigBoxes.set(pi, arr);
  }

  // headers: bigger than body, short, bold or clearly larger
  const headers: BrainLine[] = [];
  // letter openers: bold standalone uppercase single letter
  const letterOpeners: { line: BrainLine; letter: string }[] = [];
  // mark tokens: standalone plausible بارم numbers
  const markTokens: { line: BrainLine; value: number }[] = [];

  // MCQ option-run detection: >= 3 consecutive letter+sep+text lines with
  // small gaps whose letters advance from 'A' are question OPTIONS ("A) ...",
  // "B) ..." under one stem), not row openers. Row openers are spread out by
  // their questions; strip-row labels are covered by their tableRow twins.
  // Persian option runs (الف/ب/ج/د or ب/ج/د/ه) advance identically via ranks;
  // they may start at الف OR ب (some papers skip الف for the stem itself).
  const optionLines = new Set<BrainLine>();
  // dialogue speakers: "A: ..." / "B: ..." alternating transcript lines carry
  // a COLON after the letter. Row openers print "A)" / "A." / "A-" — a colon
  // form is a speaker label (listening transcripts), never a section row.
  const DIALOGUE_RE = new RegExp(`^\\\(?(?:${ROW_LETTER_CORE})\\s*[:：]`);
  for (const p of pages) {
    const shaped = p.lines
      .map((l) => ({ l, m: l.text.trim().match(ROW_LETTER_FUSED_RE) }))
      .filter((x) => x.m !== null && x.l.text.trim().length <= 120) as { l: BrainLine; m: RegExpMatchArray }[];
    let run: { l: BrainLine; letter: string }[] = [];
    const flush = () => {
      if (run.length >= 3) {
        const r0 = letterRank(run[0].letter);
        const advancing =
          r0 !== undefined &&
          r0 <= (r0 >= RANK_PERSIAN_BASE ? RANK_PERSIAN_BASE + 1 : 0) &&
          run.every((x, i) => i === 0 || letterForward(run[i - 1].letter, x.letter));
        if (advancing) run.forEach((x) => optionLines.add(x.l));
      }
      run = [];
    };
    let prevY: number | undefined;
    for (const x of shaped) {
      const y = yCenter(x.l.bbox);
      if (prevY !== undefined && y - prevY > 45) flush();
      run.push({ l: x.l, letter: x.m[1] });
      prevY = y;
    }
    flush();
  }

  const numberOpeners: { line: BrainLine; num: number; subject: string; text: string }[] = [];
  const bareBoldNums: { line: BrainLine; num: number }[] = [];
  for (const p of pages) {
    for (const l of p.lines) {
      const t = l.text.trim();
      if (!t) continue;
      const hasLetter = /[A-Za-z\u0600-\u06FF]/.test(t);
      const isSingleLetterToken = ROW_LETTER_STRICT_RE.test(t);
      // dialogue speaker lines ("A: ...") are transcript content
      if (DIALOGUE_RE.test(t)) continue;
      // option lines ("b) he is sick ...", "12- not to touch", "ب) گزینه ...")
      // are question content, never section headers — even when printed large
      const isOptionLine = ROW_LETTER_FUSED_RE.test(t) || /^\d{1,2}[\).\-]\s*\S/.test(t);
      if (
        hasLetter &&
        !isSingleLetterToken &&
        !isOptionLine &&
        l.size >= bodySize * 1.12 &&
        t.length <= 35 &&
        (l.bold || l.size >= bodySize * 1.2) &&
        (matchSubject(t) || l.size >= bodySize * 1.18)
      ) {
        headers.push(l);
        continue;
      }
      // fused numeric section openers: "8 Grammar" / "12 درک مطلب" — a number
      // followed by a subject keyword. The printed subject is a strong prior;
      // bold/size is NOT required (radif headers are often body-size).
      const numM = toLatinDigits(t).match(/^\s*(\d{1,2})\s*[\).\-]?\s+([^\s.][^.]{0,58})$/);
      if (numM && !isOptionLine) {
        const subj = matchSubject(numM[2]);
        if (subj) {
          numberOpeners.push({ line: l, num: parseInt(numM[1], 10), subject: subj, text: t });
          continue;
        }
      }
      // bare bold integer in CONTENT: radif candidate (the numeric ladder in
      // runLayoutBrain decides; a lone bold number never opens a section)
      const bareM = toLatinDigits(t).match(/^(\d{1,2})$/);
      if (bareM && l.bold && !pageNumberLines.has(l)) {
        const v = parseInt(bareM[1], 10);
        if (v >= 1 && v <= 60) bareBoldNums.push({ line: l, num: v });
      }
      // fused row openers: "A) Fill in the blanks." / "الف) متن زیر را ..." —
      // the most common row format in text-native exams (rows are letter+text
      // lines, not table strips). Uppercase Latin only (lowercase MCQ options
      // never collide); Persian row letters are single-letter tokens or الف/هـ
      // followed by a separator, so ordinary Persian words (بخوانید، متن) never
      // match. Advancing option runs are excluded by option-run detection.
      const fusedM = t.match(ROW_LETTER_FUSED_RE);
      if (fusedM && t.length <= 80 && !optionLines.has(l) && isRowLetterToken(fusedM[1])) {
        letterOpeners.push({ line: l, letter: fusedM[1] });
        continue;
      }
      const letterM = t.match(ROW_LETTER_STRICT_RE);
      if (letterM && (l.bold || l.size >= bodySize) && l.size < 40 && l.size >= bodySize * 0.85) {
        letterOpeners.push({ line: l, letter: letterM[1] });
        continue;
      }
      // standalone marks: "(1)" / "1" — bare tokens must be bold so question
      // numbers and list indices never masquerade as بارم
      const markM = t.match(/^\(?([\d۰-۹٠-٩]+(?:[.,][\d۰-۹٠-٩]+)?)\)?$/);
      if (markM && l.bold) {
        const v = parseMarkNum(markM[1]);
        if (v !== undefined && v >= 0.25 && v <= 8) markTokens.push({ line: l, value: v });
        continue;
      }
      // textual marks: "1 نمره" / "(2 نمره)" / "بارم 1.5" — the printed
      // unit word is a strong prior, so bold is NOT required; try both
      // storage orders (Persian lines may be visually reversed)
      const markM2 = [t, reverseStr(toLatinDigits(t))]
        .map((s) => s.match(/^\(?\s*([\d۰-۹٠-٩]+(?:[.,][\d۰-۹٠-٩]+)?)\s*(?:نمره|بارم)\s*\)?$/))
        .find(Boolean);
      if (markM2) {
        const v = parseMarkNum(markM2[1]);
        if (v !== undefined && v >= 0.25 && v <= 8) markTokens.push({ line: l, value: v });
      }
    }
  }

  // ---- unruled strip-pair resolution: some papers print the marks INDEX
  // WITHOUT ruling — two bold number columns bracketing the content per row
  // (RTL: ردیف row-number at the far edge, بارم mark at the other). Two
  // bare marks sharing a y are a PAIR, and the row-number column is the one
  // whose values form a strict ascending 1..N ladder in row order — the mark
  // column never does. Row numbers are index furniture, not marks.
  {
    const byY = new Map<string, { line: BrainLine; value: number }[]>();
    for (const mt of markTokens) {
      const t = mt.line.text.trim();
      if (!/^\d{1,2}$/.test(toLatinDigits(t))) continue; // pairs form from bare ints
      const k = `${mt.line.page}:${Math.round(yCenter(mt.line.bbox) / 3)}`;
      (byY.get(k) ?? byY.set(k, []).get(k)!).push(mt);
    }
    const pairs: { left: { line: BrainLine; value: number }; right: { line: BrainLine; value: number } }[] = [];
    for (const group of byY.values()) {
      if (group.length !== 2) continue;
      const [a, b] = group[0].line.bbox[0] <= group[1].line.bbox[0] ? [group[0], group[1]] : [group[1], group[0]];
      if (xCenter(b.line.bbox) - xCenter(a.line.bbox) < 0.4 * doc.pages[a.line.page].width) continue;
      pairs.push({ left: a, right: b });
    }
    pairs.sort((p, q) => p.left.line.page - q.left.line.page || yCenter(p.left.line.bbox) - yCenter(q.left.line.bbox));
    if (pairs.length >= 3) {
      const ladder = (vals: number[]) => vals.every((v, i) => v === i + 1);
      const leftVals = pairs.map((p) => p.left.value);
      const rightVals = pairs.map((p) => p.right.value);
      const rowCol = ladder(leftVals) && !ladder(rightVals) ? 'left' : ladder(rightVals) && !ladder(leftVals) ? 'right' : undefined;
      if (rowCol) {
        const dropped = pairs.map((p) => (rowCol === 'left' ? p.left : p.right));
        const dropLines = new Set(dropped.map((d) => d.line));
        for (let i = markTokens.length - 1; i >= 0; i--) if (dropLines.has(markTokens[i].line)) markTokens.splice(i, 1);
      }
    }
  }

  // tables: classify + count boxes per cell
  const marksTablesCount = pages.reduce((n, p) => n + p.tables.filter((t) => t.kind === 'marksTable').length, 0);

  // printed total / answer-key boundary: Persian lines may arrive visually
  // reversed, so test BOTH the stored order and its reverse against the
  // forward patterns (the old code tested reversed patterns against the
  // reversed text — they never fired on reversed files).
  let printedTotal: number | undefined;
  // answer-key boundary: everything after the key header is furniture
  let keyBoundary: { page: number; y: number; text: string } | undefined;
  const KEY_FWD = /پاسخنامه|پاسخ نامه|answer\s*key|answer\s*sheet/i;
  const TOTAL_FWD = /جمع|بارم|total/i;
  outer: for (const p of pages) {
    for (const l of p.lines) {
      const t = toLatinDigits(l.text);
      const r = reverseStr(t);
      if (KEY_FWD.test(t) || KEY_FWD.test(r)) {
        keyBoundary = { page: pages.indexOf(p), y: l.bbox[1], text: l.text.trim().slice(0, 30) };
        break outer;
      }
      if (TOTAL_FWD.test(t) || TOTAL_FWD.test(r)) {
        // digit runs may appear reversed depending on extraction order —
        // take them from both orders, un-reversing runs found in r
        const cands = [
          ...(t.match(/\d+(?:\.\d+)?/g) ?? []).map(parseFloat),
          ...(r.match(/\d+(?:\.\d+)?/g) ?? []).map((s) => parseFloat(reverseStr(s))),
        ].filter((v) => isFinite(v) && v >= 10 && v <= 100);
        if (cands.length && printedTotal === undefined) printedTotal = Math.max(...cands);
      }
    }
  }

  if (!keyBoundary) {
    // Banner-less kanoon key (#qu2 wave R4, pt7kkv4576): the paper appends the
    // answer key (bare skill label + DENSE short-answer rows that RESTART the
    // numbering) followed by a textbook digest — no پاسخنامه banner, so the
    // heading test above never fires and the key+textbook pages poison both
    // the section model and the drive-gate coverage. Same signature as the
    // text-side findKeySheetBoundary: >=4 dense rows (>=2 "N." markers, no
    // blanks, no "?"), >=1 bare skill label, first row number <= 5 while a
    // number >= 12 printed earlier, duds bounded.
    const isDenseKeyRow = (s: string) => {
      if (/\.{3,}|…|_{2,}|\?|؟/.test(s)) return false;
      const nums = s.match(/(?:^|\s)\d{1,3}\s*[.،)]/g);
      return !!nums && nums.length >= 2 && s.split(/\s+/).length <= 40;
    };
    const isBareSkillLabel = (s: string) =>
      /^(?:Listening|Speaking|Reading|Writing|Vocabulary|Grammar|Language Function|Pronunciation)\s*$/i.test(s.trim());
    const flat: { page: number; y: number; text: string }[] = [];
    for (let pi = 0; pi < pages.length; pi++) {
      for (const l of pages[pi].lines) {
        flat.push({ page: pi, y: l.bbox[1], text: toLatinDigits(l.text) });
      }
    }
    let ran = false;
    for (let i = 8; i < flat.length - 4; i++) {
      const winEnd = Math.min(flat.length, i + 45);
      let dense = 0;
      let labels = 0;
      let duds = 0;
      let firstRowNum = Infinity;
      let firstDenseLine = -1;
      let lastDenseLine = -2;
      let maxRun = 0;
      for (let k = i; k < winEnd; k++) {
        const t = flat[k].text.trim();
        const r = reverseStr(t);
        if (!t) continue;
        if (isBareSkillLabel(t) || isBareSkillLabel(r)) {
          labels++;
          continue;
        }
        if (isDenseKeyRow(t)) {
          dense++;
          if (firstDenseLine < 0) {
            firstDenseLine = k;
            const m = t.match(/^(\d{1,3})\s*[.،)]/);
            if (m) firstRowNum = parseInt(m[1], 10);
          }
          maxRun = k - lastDenseLine <= 6 ? maxRun + 1 : 1;
          lastDenseLine = k;
          continue;
        }
        duds++;
      }
      if (dense < 4 || maxRun < 3 || labels < 1 || duds > dense + labels || firstRowNum > 5) continue;
      // the exam before the window must have run well past the restart point
      for (let k = 0; k < i; k++) {
        const m = flat[k].text.match(/(?:^|\s)(\d{1,3})\s*[.،)]\s*\S/);
        if (m && parseInt(m[1], 10) >= 12) {
          ran = true;
          break;
        }
      }
      if (!ran) continue;
      // cut at the FIRST DENSE ROW (never at the window start — the window
      // may open on exam content); a bare skill label directly above it is
      // the printed key header.
      let cutIdx = firstDenseLine;
      if (
        cutIdx > 0 &&
        (isBareSkillLabel(flat[cutIdx - 1].text.trim()) || isBareSkillLabel(reverseStr(flat[cutIdx - 1].text.trim())))
      )
        cutIdx -= 1;
      keyBoundary = { page: flat[cutIdx].page, y: flat[cutIdx].y, text: flat[cutIdx].text.trim().slice(0, 30) };
      break;
    }
  }

  return {
    bodySize,
    pages,
    headers,
    letterOpeners,
    markTokens,
    numberOpeners,
    bareBoldNums,
    pageNumbers,
    printedTotal,
    keyBoundary,
    fullRules,
    optionLines,
  };
}

// ------------------------------------------------- table classification pass

export function classifyTables(doc: BrainDoc): BrainDoc {
  for (const p of doc.pages) {
    for (const t of p.tables) {
      t.page = doc.pages.indexOf(p);
      const cells: BrainCell[] = [];
      const R = t.rows;
      const C = t.cols;
      for (let ri = 0; ri < R; ri++) {
        for (let ci = 0; ci < C; ci++) {
          const idx = ri * C + ci;
          const bbox = t.cellBboxes?.[idx] ?? [0, 0, 0, 0];
          let text = '';
          if (t.cellTexts && t.cellTexts[ri] && t.cellTexts[ri][ci]) text = t.cellTexts[ri][ci];
          const boxes = p.rects.filter((r) => {
            const a = bboxArea(r);
            const w = r[2] - r[0];
            const h = r[3] - r[1];
            if (!(a > 400 && a < 0.25 * p.width * p.height && w > 12 && h > 10 && h < 120)) return false;
            return pointInBbox(xCenter(r), yCenter(r), bbox, 2);
          }).length;
          cells.push({ r: ri, c: ci, text, bbox, boxes });
        }
      }
      t.cells = cells;
      const nonEmpty = cells.filter((c) => c.text.trim());
      const letterCells = nonEmpty
        .map((c) => ({ c, ltr: cellLetter(c.text) }))
        .filter((x) => x.ltr !== undefined);
      const digitCells = nonEmpty.filter((c) => parseMarkNum(c.text.trim()) !== undefined && c.text.trim().length <= 5);

      if (nonEmpty.length === 0) {
        t.kind = 'empty';
      } else if (R * C >= 30 && digitCells.length >= 0.5 * Math.max(1, nonEmpty.length)) {
        t.kind = 'bubbleGrid';
      } else if (
        R >= 3 &&
        (() => {
          // letter column with alphabetical advance (letter may be a strict
          // single token or fused with the instruction: "A) Fill in ...")
          const byCol = new Map<number, string[]>();
          for (const { c, ltr } of letterCells) {
            const arr = byCol.get(c.c) ?? [];
            arr.push(ltr!);
            byCol.set(c.c, arr);
          }
          for (const [, arr] of byCol) {
            if (arr.length >= 3) {
              let ok = 0;
              for (let i = 1; i < arr.length; i++) {
                const a = letterRank(arr[i - 1]);
                const b = letterRank(arr[i]);
                if (a !== undefined && b !== undefined && b > a) ok++;
              }
              return ok >= arr.length - 1;
            }
          }
          return false;
        })()
      ) {
        t.kind = 'marksTable';
        t.letterRows = extractLetterRows(t);
        const singleRows = cellsByRow(cells).filter((row) => row.filter((c) => c.text.trim()).length === 1);
        for (const row of singleRows) {
          const txt = row.find((c) => c.text.trim())!.text.trim();
          const subj = matchSubject(txt);
          if (subj && txt.length <= 20) t.groupHeader = t.groupHeader ?? txt;
        }
      } else if (
        C >= 2 &&
        (() => {
          const firstRow = cells.filter((c) => c.r === 0 && c.text.trim()).map((c) => c.text.trim());
          return firstRow.length >= 2 && firstRow.every((s) => /^\(?[A-Za-z][\).:]?$/.test(s));
        })()
      ) {
        t.kind = 'matchingLayout';
      } else {
        t.kind = 'contentTable';
      }
    }
  }
  return doc;
}

function cellsByRow(cells: BrainCell[]): BrainCell[][] {
  const rows: BrainCell[][] = [];
  for (const c of cells) {
    (rows[c.r] ??= []).push(c);
  }
  return rows;
}

/** Letter token in a cell: strict ("A", "A)", "الف") or fused with instruction ("A) Fill in ...", "ب) متن ..."). */
function cellLetter(s: string): string | undefined {
  const t = s.trim();
  const m1 = t.match(ROW_LETTER_STRICT_RE);
  if (m1 && isRowLetterToken(m1[1])) return m1[1];
  const m2 = t.match(ROW_LETTER_FUSED_RE);
  if (m2 && isRowLetterToken(m2[1])) return m2[1];
  return undefined;
}

function extractLetterRows(t: BrainTable): { letter: string; mark?: number; instruction: string; bbox: number[] }[] {
  const out: { letter: string; mark?: number; instruction: string; bbox: number[] }[] = [];
  for (const row of cellsByRow(t.cells)) {
    const filled = row.filter((c) => c.text.trim());
    if (!filled.length) continue;
    const letterEntry = filled.map((c) => ({ c, ltr: cellLetter(c.text) })).find((x) => x.ltr !== undefined);
    if (!letterEntry) continue;
    const letter = letterEntry.ltr!;
    let mark: number | undefined;
    const parts: string[] = [];
    for (const c of filled) {
      if (c === letterEntry.c) continue;
      const v = parseMarkNum(c.text.trim());
      if (v !== undefined && mark === undefined && c.text.trim().length <= 5) mark = v;
      else parts.push(c.text.trim());
    }
    // fused shape: the instruction lives in the letter cell itself
    const fusedText = letterEntry.c.text.trim().replace(new RegExp(`^\\(?(?:${ROW_LETTER_CORE})[\\).:ـ]\\s*`), '');
    if (fusedText && fusedText !== letterEntry.c.text.trim()) parts.unshift(fusedText);
    out.push({ letter, mark, instruction: parts.join(' '), bbox: letterEntry.c.bbox });
  }
  return out;
}

// ---------------------------------------------------------------------- FUSE

interface BoundaryEvent {
  page: number;
  y: number;
  kind: 'header' | 'letter' | 'tableRow' | 'rule' | 'matching' | 'content';
  line?: BrainLine;
  letter?: string;
  mark?: number;
  headerText?: string;
  table?: BrainTable;
  rows?: { letter: string; mark?: number; instruction?: string }[]; // collapsed multi-row table events
  note: string;
  /** set when this header event is a numeric (radif) section opener */
  numeric?: number;
}

export function runLayoutBrain(raw: BrainDoc, opts?: { debug?: boolean }): BrainResult {
  // ---- hardening: validate + normalize + cap hostile inputs -------------
  // A malformed sidecar must throw into the caller's fallback (never hang or
  // poison the parse), and scan noise (~10^5 shapes/page) must be capped.
  if (!raw || !Array.isArray(raw.pages)) throw new TypeError('layout brain: doc.pages[] missing');
  const MAX_PAGES = 300;
  const MAX_LINES_PER_PAGE = 8000;
  const MAX_SHAPES_PER_PAGE = 40000;
  const notesCaps: string[] = [];
  const isMat = (a: unknown[], n: number) => a.length >= n && a.every((v) => isFinite(Number(v)));
  const pages: BrainPage[] = raw.pages.slice(0, MAX_PAGES).map((p, pi) => {
    if (!p || typeof p !== 'object') return { width: 612, height: 792, hlines: [], rects: [], tables: [], lines: [] };
    const lines = (Array.isArray(p.lines) ? p.lines : []).filter(
      (l): l is BrainLine => !!l && typeof l.text === 'string' && Array.isArray(l.bbox) && l.bbox.length >= 4 && isFinite(Number(l.size))
    );
    if (lines.length > MAX_LINES_PER_PAGE) {
      notesCaps.push(`pg${pi + 1}: ${lines.length} lines capped to ${MAX_LINES_PER_PAGE} (scan noise)`);
      lines.length = MAX_LINES_PER_PAGE;
    }
    const hl = (Array.isArray(p.hlines) ? p.hlines : []).filter((h): h is number[] => Array.isArray(h) && isMat(h, 3));
    const rc = (Array.isArray(p.rects) ? p.rects : []).filter((r): r is number[] => Array.isArray(r) && isMat(r, 4));
    if (hl.length > MAX_SHAPES_PER_PAGE) {
      notesCaps.push(`pg${pi + 1}: ${hl.length} hlines capped to ${MAX_SHAPES_PER_PAGE} (scan noise)`);
      hl.length = MAX_SHAPES_PER_PAGE;
    }
    if (rc.length > MAX_SHAPES_PER_PAGE) {
      notesCaps.push(`pg${pi + 1}: ${rc.length} rects capped to ${MAX_SHAPES_PER_PAGE} (scan noise)`);
      rc.length = MAX_SHAPES_PER_PAGE;
    }
    const tables = (Array.isArray(p.tables) ? p.tables : []).filter(
      (t) => !!t && typeof t.rows === 'number' && typeof t.cols === 'number'
    );
    return { width: Number(p.width) || 612, height: Number(p.height) || 792, hlines: hl, rects: rc, tables, lines };
  });
  if (raw.pages.length > MAX_PAGES) notesCaps.push(`doc: ${raw.pages.length} pages capped to ${MAX_PAGES}`);
  const doc = classifyTables({ file: String(raw.file ?? ''), pages });
  const P = perceive(doc);
  const notes_global: string[] = notesCaps;

  // ---- events
  const events: BoundaryEvent[] = [];
  // numeric (radif) section ladder: fused "N Subject" openers anchor the
  // ladder (the printed keyword is a strong prior); bare bold integers join
  // ONLY while they continue the ladder (N in [expected, expected+2]) — a
  // lone bold number never opens a section. Ladder cross-check = the numeric
  // counterpart of the letter-sequence check (user charter: signals agree).
  const numericEventLines = new Set<BrainLine>();
  let numericAnchored = false; // a fused "N Subject" opener exists in this doc
  {
    const numCands: { page: number; y: number; num: number; fused: boolean; line: BrainLine; subject?: string; text: string }[] = [
      ...P.numberOpeners.map((o) => ({ page: o.line.page, y: yCenter(o.line.bbox), num: o.num, fused: true, line: o.line, subject: o.subject, text: o.text })),
      ...P.bareBoldNums.map((o) => ({ page: o.line.page, y: yCenter(o.line.bbox), num: o.num, fused: false, line: o.line, subject: undefined, text: o.line.text.trim() })),
    ].sort((a, b) => a.page - b.page || a.y - b.y);
    let anchored = false;
    let expectedNext = 0;
    let numericMax = 0;
    const numericAccepted: { line: BrainLine; text: string; subject?: string; num: number }[] = [];
    for (const c of numCands) {
      if (c.fused) {
        numericAccepted.push({ line: c.line, text: c.text, subject: c.subject, num: c.num });
        numericEventLines.add(c.line);
        anchored = true;
        numericAnchored = true;
        expectedNext = c.num + 1;
        numericMax = Math.max(numericMax, c.num);
      } else if (anchored) {
        if (c.num >= expectedNext && c.num <= expectedNext + 2 && c.num > numericMax - 3) {
          numericAccepted.push({ line: c.line, text: c.text, num: c.num });
          numericEventLines.add(c.line);
          expectedNext = c.num + 1;
          numericMax = Math.max(numericMax, c.num);
        } else {
          notes_global.push(
            `bare number ${c.num} breaks the section ladder (expected ${expectedNext}) -> content, not an opener (pg${c.page + 1})`
          );
        }
      }
    }
    // combined header-like candidates: size-based headers + numeric openers,
    // in document order, each with its own mark pairing below
    const headerCands: { line: BrainLine; headerText: string; subject?: string; numeric?: number }[] = [
      ...P.headers
        .filter((h) => !numericEventLines.has(h))
        .map((h) => ({ line: h, headerText: h.text.trim(), subject: undefined as string | undefined, numeric: undefined as number | undefined })),
      ...numericAccepted.map((n) => ({ line: n.line, headerText: n.text, subject: n.subject, numeric: n.num })),
    ].sort((a, b) => a.line.page - b.line.page || yCenter(a.line.bbox) - yCenter(b.line.bbox));
    // a numeric-opener line is consumed as a boundary — it must not also be
    // paired as a nearby mark for another row
    const markTok = P.markTokens.filter((mt) => !numericEventLines.has(mt.line));
    for (const h of headerCands) {
      const subj = h.subject ?? matchSubject(h.headerText);
      let hmark: number | undefined;
      let hbestD = 1e9;
      for (const mt of markTok) {
        if (mt.line.page !== h.line.page) continue;
        const d = Math.abs(yCenter(mt.line.bbox) - yCenter(h.line.bbox));
        if (d < hbestD && d <= 34) {
          hbestD = d;
          hmark = mt.value;
        }
      }
      events.push({
        page: h.line.page,
        y: h.line.bbox[1],
        kind: 'header',
        line: h.line,
        headerText: h.headerText,
        mark: hmark,
        numeric: h.numeric,
        note:
          (h.numeric !== undefined ? `section ${h.numeric} ` : `header "${h.headerText}"`) +
          (subj ? ` (${subj})` : '') +
          (hmark !== undefined ? ` (mark ${hmark})` : ''),
      });
    }
  }
  // table-wins: when a page's marksTable already carries a letter column,
  // text-level openers of those letters on the same page are duplicates
  const tableLettersByPage = new Map<number, Set<string>>();
  for (const [pi, p] of doc.pages.entries()) {
    const s = new Set<string>();
    for (const t of p.tables) if (t.kind === 'marksTable') for (const lr of t.letterRows) s.add(lr.letter);
    tableLettersByPage.set(pi, s);
  }
  for (const { line, letter } of P.letterOpeners) {
    const tl = tableLettersByPage.get(line.page);
    if (tl && tl.size >= 2 && tl.has(letter)) continue;
      // letter opener: pair the nearest mark token AT or BELOW the opener
      // (rows carry their بارم after their questions; kanoon strip rows have
      // it inline) — not just any token within 34pt in either direction
      let mark: number | undefined;
      let bestD = 1e9;
      const oy = yCenter(line.bbox);
      for (const mt of P.markTokens) {
        if (mt.line.page !== line.page) continue;
        const d = yCenter(mt.line.bbox) - oy;
        if (d < -6) continue;
        if (d < bestD && d <= 150) {
          bestD = d;
          mark = mt.value;
        }
      }
    events.push({
      page: line.page,
      y: line.bbox[1],
      kind: 'letter',
      line,
      letter,
      mark,
      note: `row ${letter}${mark !== undefined ? ` (mark ${mark})` : ''}`,
    });
  }
  for (const p of doc.pages) {
    for (const t of p.tables) {
      if (t.kind !== 'marksTable') continue;
      for (const lr of t.letterRows) {
        events.push({
          page: p === doc.pages[t.page] ? t.page : doc.pages.indexOf(p),
          y: lr.bbox[1],
          kind: 'tableRow',
          letter: lr.letter,
          mark: lr.mark,
          headerText: t.groupHeader,
          table: t,
          note: `table row ${lr.letter}${lr.mark !== undefined ? ` (mark ${lr.mark})` : ''}`,
        });
      }
    }
  }
  // table-top boundaries: matching layouts (two-sided A/B tables) and large
  // content tables can start their own section (user charter tier 1/4) — but
  // ONLY when nothing else claims the region: (a) no header/letter/tableRow
  // event above on the same page, (b) a full-width rule (that is NOT the
  // table's own border) within 25pt above the table top, or (c) the table
  // sits before any structural event of the document AND the doc has no
  // structural events at all (tables-only document). Otherwise the table is
  // a sub-element of the surrounding section (pm57's matching table inside
  // Reading, the pg1 student-info box) and stays inside it.
  const floor = doc.pages.reduce<{ page: number; y: number } | undefined>((acc, p, pi) => {
    for (const e of events) {
      if (e.kind !== 'header' && e.kind !== 'letter' && e.kind !== 'tableRow') continue;
      if (!acc || e.page < acc.page || (e.page === acc.page && e.y < acc.y)) acc = { page: e.page, y: e.y };
    }
    return acc;
  }, undefined);
  const belowFloor = (page: number, y: number) => !!floor && (page < floor.page || (page === floor.page && y < floor.y - 2));
  // a letter/tableRow event DIRECTLY above a candidate boundary means the
  // lettered row ladder (rows A..R) is still open there — the boundary would
  // cut INSIDE a row's region (pm57's matching table between K and M).
  // Tables/rules defer to the ladder; they only section when the preceding
  // structure is a header (or nothing).
  const structuralSorted = events
    .filter((e) => e.kind === 'header' || e.kind === 'letter' || e.kind === 'tableRow')
    .sort((a, b) => a.page - b.page || a.y - b.y);
  const prevStructural = (page: number, y: number): BoundaryEvent | undefined => {
    let prev: BoundaryEvent | undefined;
    for (const e of structuralSorted) {
      if (e.page > page || (e.page === page && e.y >= y)) break;
      prev = e;
    }
    return prev;
  };
  const freeRules = (pi: number) =>
    (P.fullRules.get(pi) ?? []).filter(
      (y) => !doc.pages[pi].tables.some((t) => y > t.bbox[1] - 4 && y < t.bbox[3] + 4)
    );
  const tableEvents: BoundaryEvent[] = [];
  for (const [pi, p] of doc.pages.entries()) {
    for (const t of p.tables) {
      if (t.kind === 'matchingLayout' || t.kind === 'contentTable') {
        const filled = t.cells.filter((c) => c.text.trim());
        const avgLen = filled.length ? filled.reduce((n, c) => n + c.text.trim().length, 0) / filled.length : 0;
        const height = t.bbox[3] - t.bbox[1];
        const isBigContent = t.kind === 'matchingLayout' || (filled.length >= 2 && avgLen >= 10 && height >= 120);
        if (!isBigContent) continue;
        const noEventAbove = !events.some(
          (e) => e.page === pi && (e.kind === 'header' || e.kind === 'letter' || e.kind === 'tableRow') && e.y < t.bbox[1]
        );
        const ruleAbove = freeRules(pi).some((y) => Math.abs(y - t.bbox[1]) <= 25);
        const prevE = prevStructural(pi, t.bbox[1]);
        if (prevE && (prevE.kind === 'letter' || prevE.kind === 'tableRow')) continue; // ladder claims region
        if ((!noEventAbove && !ruleAbove) || belowFloor(pi, t.bbox[1])) continue;
        tableEvents.push({
          page: pi,
          y: t.bbox[1],
          kind: t.kind === 'matchingLayout' ? 'matching' : 'content',
          table: t,
          note:
            (t.kind === 'matchingLayout' ? `matching layout table ${t.rows}x${t.cols}` : `content table ${t.rows}x${t.cols} (avg cell ${avgLen.toFixed(0)} chars)`) +
            `${ruleAbove ? ' + rule above' : ''} @pg${pi + 1}`,
        });
      }
    }
  }
  events.push(...tableEvents);
  // full-width rule boundaries (user charter tier 3): a rule that is NOT a
  // table border, has content on BOTH sides (a separator, not a frame or
  // underline), sits away from already-proposed boundaries and below the
  // document floor (rules above the first structural event are furniture
  // underlines of the metadata box), and is not scan noise. Half rules are
  // deliberately NOT boundaries — too ambiguous.
  for (const [pi, p] of doc.pages.entries()) {
    const rules = P.fullRules.get(pi) ?? [];
    if (rules.length > 40) {
      notes_global.push(`pg${pi + 1}: ${rules.length} full rules -> scan noise, rule boundaries skipped`);
      continue;
    }
    for (const y of rules) {
      if (p.tables.some((t) => y > t.bbox[1] - 4 && y < t.bbox[3] + 4)) continue; // table border
      if (events.some((e) => e.page === pi && Math.abs(e.y - y) < 16)) continue; // dedupe
      if (belowFloor(pi, y)) continue; // furniture separator above first structural event
      const prevE = prevStructural(pi, y);
      if (prevE && (prevE.kind === 'letter' || prevE.kind === 'tableRow')) continue; // ladder claims region
      const above = p.lines.some((l) => l.bbox[1] < y - 8 && l.bbox[3] > y - 140);
      const below = p.lines.some((l) => l.bbox[1] > y + 4 && l.bbox[1] < y + 140);
      if (!above || !below) continue;
      events.push({ page: pi, y: y + 2, kind: 'rule', note: `full-width rule @pg${pi + 1} y=${Math.round(y)}` });
    }
  }
  events.sort((a, b) => a.page - b.page || a.y - b.y);

  // suppression 1: events after the answer-key boundary are furniture
  if (P.keyBoundary) {
    const kb = P.keyBoundary;
    const kept = events.filter((e) => e.page < kb.page || (e.page === kb.page && e.y < kb.y - 5));
    const dropped = events.length - kept.length;
    if (dropped > 0) notes_global.push(`answer-key boundary "${kb.text}" -> dropped ${dropped} events after pg${kb.page + 1}`);
    events.length = 0;
    events.push(...kept);
  }

  // suppression 2: letterOpeners that live INSIDE a marksTable cell (the table
  // source already carries them richer) or duplicate a tableRow of the same letter
  const marksCellBoxes: { page: number; bbox: number[] }[] = [];
  for (const p of doc.pages)
    for (const t of p.tables)
      if (t.kind === 'marksTable') for (const c of t.cells) if (c.text.trim()) marksCellBoxes.push({ page: doc.pages.indexOf(p), bbox: c.bbox });
  const tableRowLetters = new Map<string, { page: number; y: number }[]>();
  for (const e of events)
    if (e.kind === 'tableRow' && e.letter) {
      const arr = tableRowLetters.get(e.letter) ?? [];
      arr.push({ page: e.page, y: e.y });
      tableRowLetters.set(e.letter, arr);
    }
  const preFilter = events.length;
  const filtered: BoundaryEvent[] = [];
  for (const e of events) {
    if (e.kind === 'letter' && e.line) {
      const cx = xCenter(e.line.bbox);
      const cy = yCenter(e.line.bbox);
      const inCell = marksCellBoxes.some((m) => m.page === e.page && pointInBbox(cx, cy, m.bbox, 3));
      if (inCell) continue;
      const twins = tableRowLetters.get(e.letter ?? '') ?? [];
      if (twins.some((t) => t.page === e.page && Math.abs(t.y - e.y) < 120)) continue;
    }
    filtered.push(e);
  }
  if (filtered.length !== preFilter) notes_global.push(`suppressed ${preFilter - filtered.length} duplicate letter events`);
  events.length = 0;
  events.push(...filtered);

  // dedupe: letter opener + tableRow for the same letter within 60pt -> keep tableRow (richer)
  const deduped: BoundaryEvent[] = [];
  for (const e of events) {
    const prev = deduped[deduped.length - 1];
    if (
      prev &&
      e.kind === 'letter' &&
      prev.kind === 'tableRow' &&
      prev.letter === e.letter &&
      e.page === prev.page &&
      Math.abs(e.y - prev.y) < 60
    )
      continue;
    if (
      prev &&
      e.kind === 'tableRow' &&
      prev.kind === 'letter' &&
      prev.letter === e.letter &&
      e.page === prev.page &&
      Math.abs(e.y - prev.y) < 60
    ) {
      deduped[deduped.length - 1] = e; // upgrade to tableRow
      continue;
    }
    deduped.push(e);
  }

  // collapse: consecutive tableRow events of the SAME table -> one boundary
  // (rows of a compact strip must not bound each other to zero content)
  const byTable = new Map<BrainTable, BoundaryEvent>();
  const collapsed: BoundaryEvent[] = [];
  for (const e of deduped) {
    if (e.kind === 'tableRow' && e.table) {
      const anchor = byTable.get(e.table);
      if (anchor) {
        anchor.rows!.push({
          letter: e.letter!,
          mark: e.mark,
          instruction: e.table?.letterRows.find((lr) => lr.letter === e.letter)?.instruction,
        });
        continue;
      }
      const clone: BoundaryEvent = {
        ...e,
        y: Math.min(e.y, e.table.bbox[1]),
        rows: [
          {
            letter: e.letter!,
            mark: e.mark,
            instruction: e.table?.letterRows.find((lr) => lr.letter === e.letter)?.instruction,
          },
        ],
      };
      byTable.set(e.table, clone);
      collapsed.push(clone);
      continue;
    }
    collapsed.push(e);
  }
  // answer-key restart vs per-part letter restart (cross-checked, not blind):
  // a letter batch that repeats/regresses the high-water mark is either (a) a
  // SECOND lettered structure — the printed answer key — or (b) a legitimate
  // per-part numbering restart (each part's rows begin at A again). The
  // discriminator is the separating header: a REAL part header between the two
  // batches means restart (keep); no separating header means key (drop). A
  // header that belongs to a strip table ABOVE it (kanoon strip-above-header
  // layout) is ownership-inverted and does NOT count as a separator.
  // The batch letter range is order-independent (RTL tables extract mirrored).
  const stripOwnedHeader = new Set<BoundaryEvent>();
  for (let i = 1; i < collapsed.length; i++) {
    const h = collapsed[i];
    if (h.kind !== 'header') continue;
    const prev = collapsed[i - 1];
    if (prev.kind === 'tableRow' && prev.page === h.page && h.y - prev.y >= -10 && h.y - prev.y < 250)
      stripOwnedHeader.add(h);
  }
  let maxLetter = '';
  let headerSinceBatch = true;
  const finalEvents: BoundaryEvent[] = [];
  for (let ci = 0; ci < collapsed.length; ci++) {
    const e = collapsed[ci];
    if (e.kind === 'header') {
      if (!stripOwnedHeader.has(e)) headerSinceBatch = true;
      finalEvents.push(e);
      continue;
    }
    const batch = e.rows?.length ? e.rows.map((r) => r.letter) : e.letter ? [e.letter] : [];
    if (batch.length) {
      const rankOf = (l: string) => letterRank(l) ?? -1;
      const bMax = batch.reduce((a, b) => (rankOf(b) > rankOf(a) ? b : a), batch[0]);
      const bMin = batch.reduce((a, b) => (rankOf(b) < rankOf(a) ? b : a), batch[0]);
      if (maxLetter && rankOf(bMin) <= rankOf(maxLetter)) {
        // kanoon strip-above-header: the regressed batch may be a marks strip
        // whose part header comes BELOW it — look ahead for that header
        const nxt = collapsed[ci + 1];
        const stripAboveHeader =
          !!nxt &&
          nxt.kind === 'header' &&
          nxt.page === e.page &&
          nxt.y - e.y >= -10 &&
          nxt.y - e.y < 250;
        if (headerSinceBatch || stripAboveHeader) {
          notes_global.push(
            stripAboveHeader
              ? `letter restart at ${bMin} as strip-above-header (its part header follows) -> kept (pg${e.page + 1})`
              : `letter restart at ${bMin} under a new part header -> per-part numbering kept (pg${e.page + 1})`
          );
          maxLetter = bMax;
        } else {
          notes_global.push(
            `letter ${bMin} repeats/regresses past ${maxLetter} with no separating header -> answer-key structure dropped (pg${e.page + 1})`
          );
          continue;
        }
      } else {
        maxLetter = bMax;
      }
      headerSinceBatch = false;
    }
    finalEvents.push(e);
  }
  // RTL tables extract mirrored: keep row letters in their alphabet order
  for (const e of finalEvents)
    if (e.rows && e.rows.length > 1)
      e.rows.sort((a, b) => (letterRank(a.letter) ?? 0) - (letterRank(b.letter) ?? 0));

  // ---- candidate sections between events
  // Flatten the SAME line objects the events reference (P.pages), so the
  // identity check below works: a HEADER's own line is metadata (carried by
  // headerText, excluded from content), while a ROW opener's line is content
  // (the instruction "A) Fill in..." belongs to its row's text).
  const flatLines: BrainLine[] = [];
  P.pages.forEach((p) => p.lines.forEach((l) => flatLines.push(l)));

  const candidates: BrainSection[] = [];
  // printed radif identity seen so far (highest section number claimed)
  let numericIdentityFloor = 0;
  for (let ei = 0; ei < finalEvents.length; ei++) {
    const e = finalEvents[ei];
    const next = finalEvents[ei + 1];
    const lines: BrainLine[] = [];
    let pageStart = e.page;
    let pageEnd = next ? next.page : doc.pages.length - 1;
    for (const l of flatLines) {
      // a pure-label header line is metadata (carried by headerText); a
      // NUMERIC opener's line is content too — "12 درک مطلب" often carries
      // the section instruction, and the engine must see exactly what the
      // text splitters would have seen
      if (e.line && e.kind === 'header' && l === e.line && e.numeric === undefined) continue;
      if (l.page < e.page) continue;
      if (next && l.page > next.page) continue;
      if (l.page === e.page && l.bbox[1] < e.y - 2) continue;
      if (next && l.page === next.page && l.bbox[1] >= next.y - 2) continue;
      lines.push(l);
    }
    if (next === undefined && lines.length === 0) continue; // tail event with no content
    // numeric identity from content: a section whose first line opens with
    // the printed radif number ("6 برای کلمات..." under a rule boundary)
    // carries that number as its identity. Only in numeric-anchored docs
    // (a fused "N Subject" opener exists) and only when the number ADVANCES
    // the ladder — question strays can never claim an identity.
    if (e.numeric === undefined && numericAnchored && lines.length) {
      const mNum = toLatinDigits(lines[0].text.trim()).match(/^(\d{1,2})\s*[\).\-]?\s+\S/);
      if (mNum) {
        const n = parseInt(mNum[1], 10);
        if (n > numericIdentityFloor && n <= numericIdentityFloor + 4) {
          e.numeric = n;
          notes_global.push(`section identity ${n} adopted from its first content line (pg${e.page + 1})`);
        }
      }
    }
    if (e.numeric !== undefined) numericIdentityFloor = Math.max(numericIdentityFloor, e.numeric);
    const ev: Evidence = {
      header: e.kind === 'header',
      letter: e.kind === 'letter' || e.kind === 'tableRow',
      mark: e.mark !== undefined,
      table: e.kind === 'tableRow' || e.kind === 'matching' || e.kind === 'content',
      rules: false,
      ladder: 0,
      boxes: 0,
      numeric: e.numeric,
    };
    // header context: a header's subject comes ONLY from its own text (a
    // generic big line must not inherit the previous header's keyword bonus);
    // non-header boundaries inherit from the nearest previous header event
    let headerText = e.headerText;
    let subject: string | undefined;
    if (e.kind === 'header') {
      subject = matchSubject(e.headerText ?? '');
    } else {
      for (let j = ei - 1; j >= 0; j--) {
        if (finalEvents[j].kind === 'header') {
          headerText = headerText ?? finalEvents[j].headerText;
          subject = matchSubject(finalEvents[j].headerText ?? '');
          break;
        }
      }
    }
    // ladder: consecutive numbered lines (Latin or Persian digits)
    let ladder = 0;
    let run = 0;
    for (const l of lines) {
      const t = toLatinDigits(l.text.trim());
      if (/^\(?\d{1,2}[\).:،]\s*\S/.test(t) || /^\(?\d{1,2}[\).:،]?\s*[-—…]{2,}/.test(t)) {
        run++;
        ladder = Math.max(ladder, run);
      } else if (t.length > 0) run = 0;
    }
    ev.ladder = ladder;
    // boxes within section region
    for (let pi = e.page; pi <= pageEnd; pi++) {
      const boxes = doc.pages[pi]?.rects ?? [];
      for (const r of boxes) {
        const a = bboxArea(r);
        const w = r[2] - r[0];
        const h = r[3] - r[1];
        if (!(a > 400 && a < 0.25 * doc.pages[pi].width * doc.pages[pi].height && w > 12 && h > 10 && h < 120))
          continue;
        if (pi === e.page && r[1] < e.y - 2) continue;
        if (next && pi === next.page && r[3] > next.y) continue;
        ev.boxes++;
      }
    }
    // rule corroboration: full-width rule at or near the section top (and bottom)
    const topRules = P.fullRules.get(e.page) ?? [];
    ev.rules = topRules.some((y) => Math.abs(y - e.y) < 14);
    const candRows: BrainRow[] = (e.rows ?? []).map((r) => ({
      letter: r.letter,
      mark: r.mark,
      // a strip row's own instruction IS its label text ("A) Fill in ..."),
      // falling back to the table's group header
      headerText: r.instruction || e.headerText,
      lineStart: ei,
      lineEnd: ei,
      confidence: 0,
    }));
    candidates.push({
      index: ei,
      pageStart,
      pageEnd,
      headerText,
      subject,
      boundaryKind: e.kind,
      lines,
      rows: candRows,
      evidence: {
        ...ev,
        mark: ev.mark || candRows.some((r) => r.mark !== undefined),
      },
      confidence: 0,
      confirmed: false,
      notes: [e.note],
    });
  }

  // ---- subject-keyword attachment (G5): a short keyword-only line printed
  // just above a section opener ("Vocabulary" above "B) Match ...") labels
  // THAT section. The span filter parks it at the tail of the previous
  // candidate (or in a gap) — move it into the follower and adopt its
  // subject. Header EVENT lines are labels already owned by their own section
  // and are never stolen.
  {
    const posOf = new Map<BrainLine, number>();
    flatLines.forEach((l, i) => posOf.set(l, i));
    const headerEventLines = new Set<BrainLine>();
    for (const e of finalEvents) if (e.kind === 'header' && e.line) headerEventLines.add(e.line);
    for (let i = 1; i < candidates.length; i++) {
      const cand = candidates[i];
      if (!cand.lines.length || cand.evidence.header) continue;
      const first = cand.lines[0];
      const idx = posOf.get(first);
      if (idx === undefined || idx === 0) continue;
      const prev = flatLines[idx - 1];
      const pt = prev.text.trim();
      if (!pt || pt.length > 25) continue;
      if (headerEventLines.has(prev) || P.optionLines.has(prev)) continue;
      if (prev.page !== first.page) continue;
      const gap = first.bbox[1] - prev.bbox[3];
      if (gap < -2 || gap > 45) continue;
      const subj = matchSubject(pt);
      if (!subj) continue;
      const prevCand = candidates[i - 1];
      if (prevCand.lines.length && prevCand.lines[prevCand.lines.length - 1] === prev) prevCand.lines.pop();
      cand.lines.unshift(prev);
      if (!cand.subject) {
        cand.subject = subj;
        cand.notes.push(`subject ${subj} adopted from attached keyword header "${pt}"`);
      }
    }
  }

  // ---- VERIFY: confidence + cross-checks
  // base reflects boundary-kind reliability (rules/matching are physically
  // printed separators; a bare letter is weaker); header adds more when a
  // subject keyword AGREES with the size signal (two independent checks).
  const baseFor = (s: { boundaryKind?: string; subject?: string; evidence: Evidence; lines: BrainLine[] }) => {
    let c =
      s.boundaryKind === 'rule'
        ? 0.55
        : s.boundaryKind === 'matching'
        ? 0.6
        : s.boundaryKind === 'content'
        ? 0.45
        : 0.35;
    if (s.evidence.header) c += s.subject ? 0.35 : 0.2;
    if (s.evidence.letter) c += 0.15;
    if (s.evidence.mark) c += 0.15;
    if (s.evidence.letter && s.evidence.mark) c += 0.05; // letter+mark co-occurrence: two signals agree
    if (s.evidence.table) c += 0.1;
    if (s.evidence.ladder >= 3) c += 0.1;
    if (s.evidence.boxes > 0) c += 0.05;
    if (s.evidence.rules) c += 0.05;
    if (s.evidence.numeric !== undefined) c += 0.1; // printed radif number: a physical label
    if (
      (s.boundaryKind === 'rule' || s.boundaryKind === 'matching' || s.boundaryKind === 'content') &&
      s.lines.length >= 8
    )
      c += 0.1;
    return c;
  };
  let expectedLetter: string | undefined;
  // numbered-ladder restart detection: question numbers marching continuously
  // then dropping well below the high-water mark WITHOUT a separating header
  // = a second structure (printed key / duplicated answer sheet). Unlike key
  // letters (dropped), numbered copies are only DEMOTED to fallback — numbers
  // restart legitimately more often than letters, so uncertainty is flagged,
  // never deleted.
  let maxFirstNum = 0;
  let numberedSinceHeader = false;
  const ladderNums = (s: BrainSection): number[] => {
    const nums: number[] = [];
    for (const l of s.lines) {
      const m = toLatinDigits(l.text.trim()).match(/^\(?(\d{1,3})[\).:،]/);
      if (m) nums.push(parseInt(m[1], 10));
    }
    return nums;
  };
  for (const s of candidates) {
    const ev = s.evidence;
    let c = baseFor(s);
    if (ev.header) numberedSinceHeader = true;
    // letter sequence continuity (alphabet-encoded ranks: a Latin->Persian
    // or Persian->Latin switch RESETS the expectation instead of penalizing)
    const rowLetter = s.rows.length ? s.rows[s.rows.length - 1].letter : undefined;
    const letter = rowLetter ?? (ev.letter ? lastLetterFromNotes(s.notes) : undefined);
    if (letter) {
      const rLetter = letterRank(letter);
      const rExpected = expectedLetter ? letterRank(expectedLetter) : undefined;
      if (expectedLetter && rLetter !== undefined && rExpected !== undefined && !sameAlphabet(rLetter, rExpected)) {
        s.notes.push(`alphabet switch (${expectedLetter} -> ${letter}), sequence expectation reset`);
        expectedLetter = letter;
      } else if (expectedLetter && letter === expectedLetter) {
        c += 0.1;
        s.notes.push(`sequence ok (${letter})`);
        expectedLetter = nextLetter(letter);
      } else if (expectedLetter && rLetter !== undefined && rExpected !== undefined && rLetter > rExpected + 1) {
        // forward skip (الف ب ج skips پ ت ث; part-restarts with omitted
        // letters): still forward motion — small bonus, never a penalty
        c += 0.05;
        s.notes.push(`letter skip ${expectedLetter} -> ${letter} (forward, skipped letters)`);
        expectedLetter = nextLetter(letter);
      } else if (expectedLetter && rLetter !== undefined && rExpected !== undefined && rLetter < rExpected) {
        c -= 0.1;
        s.notes.push(`letter regression: expected >= ${nextLetter(expectedLetter)}, got ${letter}`);
        expectedLetter = nextLetter(letter);
      } else {
        expectedLetter = nextLetter(letter);
      }
    }
    // mark plausibility
    if (s.rows.some((r) => (r.mark ?? 0) > 8)) {
      c -= 0.1;
      s.notes.push('implausible mark');
    }
    if (s.lines.length === 0) {
      c -= 0.2;
      s.notes.push('empty section');
    }
    const fNums = ladderNums(s);
    if (fNums.length) {
      const first = fNums[0];
      const candMax = Math.max(...fNums);
      if (maxFirstNum >= 6 && first <= maxFirstNum - 3 && !numberedSinceHeader) {
        const msg = `numbered ladder restarts at ${first} after ${maxFirstNum} with no separating header -> second structure, demoted to fallback`;
        s.notes.push(msg);
        notes_global.push(msg);
        s.confidence = Math.max(0, Math.min(0.95, c));
        s.confirmed = false;
        s.demoted = true;
        numberedSinceHeader = true;
      } else {
        maxFirstNum = Math.max(maxFirstNum, candMax);
        numberedSinceHeader = false;
      }
    }
    s.confidence = Math.max(0, Math.min(0.95, c));
    s.confirmed = s.confidence >= 0.7;
  }

  // ---- strip-content merge (kanoon layout): the marks index strip is printed
  // ABOVE its part header; a table-strip candidate followed by a header with
  // the real content hands its rows (and tiny intro lines) over.
  // ONLY candidates born from a tableRow event are strip sources — a header
  // candidate that RECEIVED rows in an earlier merge must never act as a
  // source itself, or the rows cascade strip->Grammar->Reading (pm57 bug).
  const stripOrigins = new Set<number>();
  for (const c of candidates) {
    if (finalEvents[c.index]?.kind === 'tableRow') stripOrigins.add(c.index);
  }
  const dropped = new Set<number>();
  for (let i = 0; i < candidates.length - 1; i++) {
    const a = candidates[i];
    if (dropped.has(a.index) || !stripOrigins.has(a.index) || !a.rows.length) continue;
    // find the next live candidate, skipping contentless intermediates
    let j = i + 1;
    while (j < candidates.length && dropped.has(candidates[j].index)) j++;
    while (
      j < candidates.length &&
      !dropped.has(candidates[j].index) &&
      !candidates[j].evidence.header &&
      !candidates[j].rows.length &&
      candidates[j].lines.length <= 12
    )
      j++;
    const b = candidates[j];
    if (!b || !b.evidence.header) continue;
    // rows ALWAYS transfer to the part header they belong to (the strip is
    // that header's marks index, however small the part is); the strip's own
    // label lines move too unless the header region is dwarfed
    b.rows = [...a.rows.map((r) => ({ ...r })), ...b.rows];
    b.evidence.letter = b.evidence.letter || b.rows.length > 0;
    b.evidence.mark = b.evidence.mark || b.rows.some((r) => r.mark !== undefined);
    b.evidence.table = true;
    b.notes.push(`absorbed marks strip [${a.rows.map((r) => r.letter + (r.mark !== undefined ? ':' + r.mark : '')).join(',')}]`);
    if (a.lines.length <= 12 || b.lines.length >= a.lines.length) {
      b.lines = [...a.lines, ...b.lines];
      dropped.add(a.index);
      a.notes.push('strip merged into following header section');
    } else {
      a.rows = [];
      a.notes.push('rows transferred to following header section');
    }
  }

  // re-score: merges changed evidence after the VERIFY pass
  const scoreEvidence = (s: BrainSection) => {
    const scored = Math.max(0, Math.min(0.95, baseFor(s)));
    if (scored > s.confidence) s.confidence = scored;
    s.confirmed = s.confidence >= 0.7 && !s.demoted;
  };
  for (const c of candidates) scoreEvidence(c);

  // ---- COMMIT: merge consecutive lettered rows under the same group
  const sections: BrainSection[] = [];
  let prevLetter: string | undefined; // last row letter committed so far (sequence cross-check)
  for (const cand of candidates) {
    if (dropped.has(cand.index)) continue;
    const prev = sections[sections.length - 1];
    const candFirstLetter = cand.rows.length ? cand.rows[0].letter : lastLetterFromNotes(cand.notes);
    const prevLastLetter = prev?.rows.length ? prev.rows[prev.rows.length - 1].letter : undefined;
    const isAdjacentRow =
      !!candFirstLetter && !!prevLastLetter && letterForward(prevLastLetter, candFirstLetter);
    if (
      prev &&
      candFirstLetter &&
      isAdjacentRow &&
      cand.subject &&
      prev.subject === cand.subject &&
      prev.rows.length > 0 &&
      cand.evidence.letter
    ) {
      prev.lines.push(...cand.lines);
      prev.pageEnd = cand.pageEnd;
      if (cand.rows.length) {
        prev.rows.push(
          ...cand.rows.map((r) => ({
            ...r,
            lineStart: cand.index,
            lineEnd: cand.index,
            confidence: cand.confidence,
            // a single-row candidate's lines belong to that row; multi-row
            // (strip) rows keep their own (unknown) split
            lines: r.lines ?? (cand.rows.length === 1 ? [...cand.lines] : undefined),
          }))
        );
      } else {
        prev.rows.push({
          letter: candFirstLetter,
          mark: firstMark(cand),
          headerText: cand.headerText,
          lineStart: cand.index,
          lineEnd: cand.index,
          confidence: cand.confidence,
          lines: [...cand.lines],
        });
      }
      prev.evidence.ladder = Math.max(prev.evidence.ladder, cand.evidence.ladder);
      prev.evidence.boxes += cand.evidence.boxes;
      prev.confidence = Math.max(prev.confidence, cand.confidence);
      prevLetter = prev.rows.length ? prev.rows[prev.rows.length - 1].letter : candFirstLetter;
      continue;
    }
    const sec: BrainSection = {
      ...cand,
      lines: [...cand.lines],
      rows: cand.rows.map((r) => ({ ...r })),
      notes: [...cand.notes],
    };
    // header section followed by its lettered rows under the same subject ->
    // fold them in. Two shapes: (a) a RUN of rowless letter candidates
    // (Reading header + K,L,M text openers), (b) one rows-bearing candidate
    // (strip rows that strip-merge did not absorb). The run is cross-checked
    // against the running letter sequence (or a legitimate restart at 'A').
    const myIdx = candidates.indexOf(cand);
    const nextCand = candidates[myIdx + 1];
    if (cand.evidence.header && !sec.rows.length) {
      const runIdx: number[] = [];
      for (let k = myIdx + 1; k < candidates.length; k++) {
        const nc = candidates[k];
        if (dropped.has(nc.index)) continue;
        if (nc.evidence.header || nc.rows.length || !nc.evidence.letter) break;
        if (nc.subject !== cand.subject) break;
        runIdx.push(k);
      }
      const runFirst = runIdx.length ? lastLetterFromNotes(candidates[runIdx[0]].notes) : undefined;
      const runSeqOk =
        !!runFirst &&
        (!prevLetter ||
          letterRank(runFirst) === 0 || // a fresh alphabet (A / الف) is a legitimate restart
          letterForward(prevLetter, runFirst));
      if (runIdx.length && runSeqOk) {
        for (const k of runIdx) {
          const nc = candidates[k];
          sec.lines.push(...nc.lines);
          sec.pageEnd = nc.pageEnd;
          const lt = lastLetterFromNotes(nc.notes);
          if (lt)
            sec.rows.push({
              letter: lt,
              mark: firstMark(nc),
              headerText: nc.headerText,
              lineStart: nc.index,
              lineEnd: nc.index,
              confidence: nc.confidence,
              lines: [...nc.lines],
            });
          dropped.add(nc.index);
        }
        sec.evidence.letter = true;
        sec.notes.push(`folded letter rows [${sec.rows.map((r) => r.letter).join(',')}] from following candidates`);
        scoreEvidence(sec);
      } else if (
        nextCand &&
        !dropped.has(nextCand.index) &&
        nextCand.subject &&
        nextCand.subject === cand.subject &&
        nextCand.rows.length &&
        nextCand.evidence.letter
      ) {
        sec.rows.push(
          ...nextCand.rows.map((r) => ({
            ...r,
            lines: r.lines ?? (nextCand.rows.length === 1 ? [...nextCand.lines] : undefined),
          }))
        );
        sec.lines.push(...nextCand.lines);
        sec.pageEnd = nextCand.pageEnd;
        sec.evidence.letter = true;
        sec.evidence.mark = sec.evidence.mark || nextCand.evidence.mark;
        sec.evidence.ladder = Math.max(sec.evidence.ladder, nextCand.evidence.ladder);
        sec.confidence = Math.max(sec.confidence, nextCand.confidence);
        dropped.add(nextCand.index);
        sec.notes.push(`folded rows [${nextCand.rows.map((r) => r.letter).join(',')}] from following candidate`);
        scoreEvidence(sec);
      } else if (runIdx.length) {
        sec.notes.push(
          `letter run [${runIdx
            .map((k) => lastLetterFromNotes(candidates[k].notes) ?? '?')
            .join(',')}] breaks sequence (expected ${prevLetter ? nextLetter(prevLetter) : '?'}) -> left as separate candidates`
        );
      }
    }
    if (!sec.rows.length && candFirstLetter && cand.evidence.letter) {
      sec.rows.push({
        letter: candFirstLetter,
        mark: firstMark(cand),
        headerText: cand.headerText,
        lineStart: cand.index,
        lineEnd: cand.index,
        confidence: cand.confidence,
        lines: [...sec.lines],
      });
    }
    if (sec.rows.length) prevLetter = sec.rows[sec.rows.length - 1].letter;
    sections.push(sec);
  }
  sections.forEach((s, i) => (s.index = i));

  // ---- strip-row content recovery: a marks-table row carries letter+mark
  // but no content (the table is an INDEX; the row's body opens later with
  // its printed letter among the section's lines). Walk a confirmed section's
  // lines once: a line that opens the NEXT expected row letter hands ownership
  // to that row. Option runs never open rows; prelude lines (before the first
  // opener) ride with the first row as instruction context. Pure-strip only —
  // sections with ANY line-backed rows keep their candidate-borne ranges.
  for (const s of sections) {
    if (!s.confirmed || s.demoted || !s.rows.length) continue;
    if (!s.rows.every((r) => (r.lines?.length ?? 0) === 0)) continue;
    if (!s.lines.length) continue;
    const openRow = (l: BrainLine): number => {
      if (P.optionLines.has(l)) return -1;
      const t = l.text.trim();
      const m = ROW_LETTER_FUSED_RE.exec(t) ?? ROW_LETTER_STRICT_RE.exec(t);
      if (!m || !isRowLetterToken(m[1])) return -1;
      // the opener must name a row that has not opened yet (forward search —
      // mirrored RTL batches were already sorted into alphabet order)
      for (let k = ri; k < s.rows.length; k++) {
        if (s.rows[k].letter === m[1]) return k;
        break; // only the immediately-expected row can open
      }
      return -1;
    };
    let ri = 0;
    let opened = false;
    let firstOpened = -1;
    const prelude: BrainLine[] = [];
    const buckets: BrainLine[][] = s.rows.map(() => []);
    for (const l of s.lines) {
      const k = openRow(l);
      if (!opened) {
        if (k >= 0) {
          opened = true;
          firstOpened = k;
          ri = k;
          buckets[k].push(l);
        } else {
          prelude.push(l);
        }
        continue;
      }
      if (k >= 0 && k !== ri) {
        ri = k;
        buckets[k].push(l);
      } else {
        buckets[ri].push(l);
      }
    }
    if (!opened) continue;
    s.rows.forEach((r, k) => {
      if (buckets[k].length > 0 || (k === firstOpened && prelude.length > 0)) {
        r.lines = k === firstOpened ? [...prelude, ...buckets[k]] : buckets[k];
      }
    });
    s.notes.push(`strip rows recovered from body openers [${s.rows.map((r) => r.letter + ':' + (r.lines?.length ?? 0)).join(',')}]`);
  }

  // ---- duplicate-cycle detection (G5 hardening): the same subject+row cycle
  // printed twice (double-printed exam sheets in one PDF) is a COPY, not
  // per-part numbering. A legitimate per-part restart repeats LETTERS under
  // NEW subjects; here the document's OPENING cycle (subject + first row
  // letter, several sections long) repeats AND the question numbers restart
  // from the top. The repeated tail is flagged + demoted: the drive gate then
  // abstains (worst case = status quo) and the report says exactly why.
  if (sections.length >= 4) {
    const sig = (s: BrainSection) => `${s.subject ?? ''}|${s.rows[0]?.letter ?? ''}`;
    const firstNumOf = (s: BrainSection): number | undefined => {
      for (const l of s.lines) {
        const m = toLatinDigits(l.text.trim()).match(/^\(?(\d{1,3})[\).:،]/);
        if (m) return parseInt(m[1], 10);
      }
      return undefined;
    };
    const headStart = firstNumOf(sections[0]);
    for (let k = Math.floor(sections.length / 2); k >= 3; k--) {
      const head = sections.slice(0, k);
      const tail = sections.slice(k, 2 * k);
      if (tail.length < k) break;
      const sameCycle = head.every((s, i) => sig(s) === sig(tail[i]) && !!s.subject && !!tail[i].subject);
      const tailStart = firstNumOf(tail[0]);
      const numbersRestarted =
        headStart !== undefined && tailStart !== undefined && tailStart <= headStart + 1;
      if (sameCycle && numbersRestarted) {
        notes_global.push(
          `duplicate sheet: sections ${k}..${sections.length - 1} repeat the opening cycle (subjects ${head
            .map((s) => s.subject)
            .join('→')}) with question numbers restarting at ${tailStart} -> flagged as a repeated print`
        );
        for (let i = k; i < sections.length; i++) {
          sections[i].demoted = true;
          sections[i].confirmed = false;
          sections[i].notes.push('part of a repeated sheet cycle (duplicate print)');
        }
        break;
      }
    }
  }

  // ---- fallbacks: uncovered confirmed-less ranges
  const fallbacks: BrainSection[] = [];
  for (const s of sections) {
    if (!s.confirmed) {
      s.notes.push('below confidence -> fallback path');
      fallbacks.push(s);
    }
  }

  const sumOfMarks = sections.reduce(
    (n, s) => n + s.rows.reduce((m, r) => m + (r.mark ?? 0), 0) + (s.rows.length === 0 && s.evidence.mark ? firstMark(s) ?? 0 : 0),
    0
  );

  const result: BrainResult = {
    file: doc.file,
    sections,
    fallbacks,
    lines: flatLines,
    keyBoundary: P.keyBoundary,
    stats: {
      bodySize: P.bodySize,
      headerCount: P.headers.length,
      letterCount: P.letterOpeners.length,
      marksTables: doc.pages.reduce((n, p) => n + p.tables.filter((t) => t.kind === 'marksTable').length, 0),
      sumOfMarks,
      printedTotal: P.printedTotal,
    },
    notes: notes_global,
  };
  if (opts?.debug) {
    result.__debug = {
      events: finalEvents.map((e) => ({
        kind: e.kind,
        page: e.page,
        y: Math.round(e.y),
        letter: e.letter,
        mark: e.mark,
        headerText: e.headerText,
        rows: e.rows,
        note: e.note,
      })),
      candidates: candidates.map((c) => ({
        index: c.index,
        note: c.notes[0] ?? '',
        page: c.pageStart,
        y: 0,
        headerText: c.headerText,
        subject: c.subject,
        rows: c.rows.map((r) => ({ letter: r.letter, mark: r.mark })),
        lineCount: c.lines.length,
        evidence: c.evidence,
        confidence: c.confidence,
      })),
      dropped: [...dropped],
    };
  }
  return result;
}

function lastLetterFromNotes(notes: string[]): string | undefined {
  for (const n of notes) {
    const m = n.match(/^(?:row|table row) ((?:[A-Z]|الف|هـ|[الفبپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی]))/);
    if (m) return m[1];
  }
  return undefined;
}

function firstMark(s: BrainSection): number | undefined {
  for (const n of s.notes) {
    const m = n.match(/mark (\d+(?:\.\d+)?)/);
    if (m) return parseFloat(m[1]);
  }
  return undefined;
}
