import { EXAM_SCHEMA_VERSION, ExamDocument } from '../types/exam';
import { sanitizeExam } from './sanitizeExam';

/**
 * Schema migrations (#20) — saved exams survive app upgrades.
 *
 * `migrateDocument` takes any persisted/imported shape and returns a fully
 * migrated document PLUS a human-readable list of what changed, so the app
 * can show "3 fields upgraded, 0 lost" instead of silently rewriting data.
 */

export interface MigrationResult {
  doc: ExamDocument;
  changes: string[];
  fromVersion: number;
  toVersion: number;
}

/**
 * v1 -> v2: trust-architecture fields (invariants/consensus/review) and
 * per-question provenance. v2 -> v3: parse receipts, trust chips, EQS,
 * parse trace, deterministic ids.
 */
function migrateV1toV2(raw: Record<string, unknown>, changes: string[]): void {
  // normalizeOcrText-era docs stored displayNumber inconsistently.
  const sections = Array.isArray(raw.sections) ? raw.sections : [];
  let fixedNumbers = 0;
  for (const sec of sections as Record<string, unknown>[]) {
    const questions = Array.isArray(sec?.questions) ? sec.questions : [];
    for (const q of questions as Record<string, unknown>[]) {
      if (!q.displayNumber && q.number !== undefined) {
        q.displayNumber = String(q.number);
        fixedNumbers++;
      }
    }
  }
  if (fixedNumbers > 0) changes.push(`back-filled displayNumber on ${fixedNumbers} question(s)`);
  changes.push('added trust-architecture fields (invariants, review, provenance)');
}

function migrateV2toV3(raw: Record<string, unknown>, changes: string[]): void {
  // Trust chips + receipts live on questions; nothing to rewrite, but the
  // header may miss fields the sanitizer now expects.
  const header = raw.header as Record<string, unknown> | undefined;
  if (header && !header.gradeAndMajor) {
    header.gradeAndMajor = header.grade ? String(header.grade) : '';
    changes.push('back-filled gradeAndMajor from grade');
  }
  if (!raw.schemaVersion) {
    changes.push('stamped schemaVersion 3');
  }
}

export function migrateDocument(raw: unknown, index = 0): MigrationResult {
  const changes: string[] = [];
  const record = (raw && typeof raw === 'object' ? (raw as Record<string, unknown>) : {}) as Record<string, unknown>;
  const fromVersion = typeof record.schemaVersion === 'number' ? record.schemaVersion : 1;

  if (fromVersion < 2) migrateV1toV2(record, changes);
  if (fromVersion < 3) migrateV2toV3(record, changes);

  // The sanitizer is the final, version-agnostic normalizer.
  const doc = sanitizeExam(record, index);
  doc.schemaVersion = EXAM_SCHEMA_VERSION;

  return { doc, changes, fromVersion, toVersion: EXAM_SCHEMA_VERSION };
}

export function migrateDocumentList(raw: unknown[]): { docs: ExamDocument[]; changes: string[]; upgraded: number } {
  const docs: ExamDocument[] = [];
  const changes: string[] = [];
  let upgraded = 0;
  raw.forEach((item, i) => {
    const res = migrateDocument(item, i);
    docs.push(res.doc);
    if (res.changes.length > 0) {
      upgraded++;
      changes.push(`${res.doc.filename || res.doc.id}: ${res.changes.join(', ')}`);
    }
  });
  return { docs, changes, upgraded };
}
