/**
 * In-memory session cache of the raw source text per parsed document (Idea 1
 * mining needs the raw exam text; the document object deliberately does not
 * store it). Capped, session-only, never persisted — a refresh clears it and
 * the mining UI degrades to "re-parse this exam to enable mining".
 */

const CAP = 8;
const store = new Map<string, { rawText: string; at: number }>();

export function rememberParseSource(documentId: string, rawText: string): void {
  if (!documentId || !rawText) return;
  store.set(documentId, { rawText, at: Date.now() });
  if (store.size > CAP) {
    const oldest = [...store.entries()].sort((a, b) => a[1].at - b[1].at)[0];
    if (oldest) store.delete(oldest[0]);
  }
}

export function getParseSource(documentId: string): string | undefined {
  return store.get(documentId)?.rawText;
}

/** Test helper. */
export function clearParseSources(): void {
  store.clear();
}
