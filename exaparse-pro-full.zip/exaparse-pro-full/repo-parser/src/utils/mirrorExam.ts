import { ExamDocument, ExamOption, QuestionItem } from '../types/exam';

/**
 * Mirror exams (#16) — parallel exam forms from one parsed paper.
 *
 * Deterministic transforms preserve answer validity by construction:
 *   - MCQ:        option order shuffled per question; answer letter remapped
 *   - Word bank:  bank order permuted (sentences unchanged, still valid)
 *   - Matching:   column B permuted; right keys remapped
 *   - Question order within sections: optionally shuffled (renumbered)
 *
 * An optional AI polish pass (see /api/generate-mirror-polish) can rewrite
 * vocabulary/fill stems so different bank words become correct — the teacher
 * chooses; the deterministic core needs zero tokens.
 */

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffled<T>(arr: T[], rng: () => number): T[] {
  const out = [...arr];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

function mirrorOptions(options: ExamOption[], correctAnswer: string, rng: () => number): { options: ExamOption[]; answer: string } {
  const order = shuffled(options, rng);
  const oldKey = (correctAnswer || '').trim().toLowerCase();
  const oldOption = options.find((o) => o.id.toLowerCase() === oldKey);
  // Keep each option's text with its ORIGINAL id? No — the answer key letters
  // must move with the TEXT. So the new option list gets fresh letter ids in
  // the shuffled order, and the answer is the new letter of the same text.
  const remapped: ExamOption[] = order.map((o, i) => ({ id: String.fromCharCode(97 + (i % 26)), text: o.text }));
  let answer = correctAnswer || '';
  if (oldOption) {
    const newIdx = order.indexOf(oldOption);
    if (newIdx >= 0) answer = remapped[newIdx].id;
  }
  return { options: remapped, answer };
}

function mirrorQuestion(q: QuestionItem, rng: () => number, variantLabel: string): QuestionItem {
  const next: QuestionItem = { ...q, id: `${q.id}-m${variantLabel}` };

  if (q.type === 'multiple_choice' && q.options && q.options.length >= 2) {
    const m = mirrorOptions(q.options, q.correctAnswer || '', rng);
    next.options = m.options;
    next.correctAnswer = m.answer;
  }

  if (q.matchingPairs && q.matchingPairs.length > 0) {
    // Only permute presentation order of pairs; keys travel with texts.
    next.matchingPairs = shuffled(q.matchingPairs, rng);
  }

  return next;
}

export interface MirrorOptions {
  variant: string; // 'B', 'C', ...
  seed?: number;
  shuffleQuestions?: boolean;
}

export function createMirrorExam(parent: ExamDocument, opts: MirrorOptions): ExamDocument {
  const rng = mulberry32(opts.seed ?? Date.now() % 2147483647);
  const label = opts.variant || 'B';

  const sections = parent.sections.map((sec) => {
    let questions = sec.questions.map((q) => mirrorQuestion(q, rng, label));
    if (opts.shuffleQuestions) {
      questions = shuffled(questions, rng);
    }
    // Re-number sequentially to keep the blueprint's numbering rule intact
    questions = questions.map((q, i) => ({
      ...q,
      number: i + 1,
      displayNumber: String(i + 1),
    }));

    // Permute word-bank presentation order (text itself unchanged → still valid)
    const wordBank = sec.wordBank ? shuffled(sec.wordBank, rng) : undefined;

    // Permute matching column B; remap each question's rightKey
    let matchingColumns = sec.matchingColumns;
    if (sec.matchingColumns) {
      const newB = shuffled(sec.matchingColumns.columnB, rng);
      // Map old B id -> new B id by text identity
      const textToNewId = new Map(newB.map((c) => [c.text, c.id]));
      questions = questions.map((q) => {
        if (q.type !== 'matching') return q;
        const pairs = (q.matchingPairs || []).map((p) => ({
          ...p,
          rightKey: p.rightText ? textToNewId.get(p.rightText) ?? p.rightKey : p.rightKey,
        }));
        return { ...q, matchingPairs: pairs, correctAnswer: pairs[0]?.rightKey ?? q.correctAnswer };
      });
      matchingColumns = { ...sec.matchingColumns, columnB: newB };
    }

    return {
      ...sec,
      questions,
      wordBank,
      matchingColumns,
      markTotal: sec.markTotal, // marks untouched — blueprint preserved
    };
  });

  const totalQuestions = sections.reduce((s, x) => s + x.questions.length, 0);

  return {
    ...parent,
    id: `exam-${Date.now()}-mirror${label.toLowerCase()}`,
    filename: `${parent.filename.replace(/\.[^.]+$/, '')} — Mirror ${label}.json`,
    parsedAt: new Date().toISOString(),
    sections,
    totalQuestions,
    mirrorOf: parent.id,
    mirrorVariant: label,
    header: {
      ...parent.header,
      examName: `${parent.header.examName || parent.header.courseName} — Variant ${label}`,
    },
    review: undefined,
    consensus: undefined,
    aiUsage: parent.aiUsage
      ? { ...parent.aiUsage, ranAt: new Date().toISOString(), requests: 0, totalTokens: 0, promptTokens: 0, completionTokens: 0, baselineTokens: 0, savedPct: 100 }
      : undefined,
    sourceFile: parent.sourceFile,
    invariants: undefined, // re-run by the caller
  };
}
