/**
 * Offline OCR Preprocessing & Post-Recognition Text Normalizer
 * Optimizes image contrast/binarization before Tesseract and fixes OCR artifacts after recognition.
 */

/**
 * Estimate page skew by maximizing the variance of the horizontal projection
 * profile over candidate angles (-8°..+8°). Deterministic, no ML, ~ms cost.
 */
function estimateSkew(gray: Uint8ClampedArray, width: number, height: number): number {
  // Downscale analysis grid for speed
  const step = Math.max(1, Math.floor(Math.min(width, height) / 300));
  let bestAngle = 0;
  let bestScore = -1;

  for (let deg = -8; deg <= 8; deg += 0.5) {
    const rad = (deg * Math.PI) / 180;
    const sin = Math.sin(rad);
    const cos = Math.cos(rad);
    const proj = new Float64Array(height + width);
    const counts = new Float64Array(height + width);

    for (let y = 0; y < height; y += step) {
      for (let x = 0; x < width; x += step) {
        const grayVal = gray[y * width + x];
        if (grayVal > 128) continue; // dark pixels only (text)
        const py = Math.round(x * sin + y * cos) + width;
        proj[py] += 255 - grayVal;
        counts[py]++;
      }
    }

    // Variance of row sums: a well-aligned page gives sharp text rows
    let mean = 0;
    let n = 0;
    for (let i = 0; i < proj.length; i++) {
      if (counts[i] > 0) {
        mean += proj[i] / counts[i];
        n++;
      }
    }
    if (n === 0) continue;
    mean /= n;
    let variance = 0;
    for (let i = 0; i < proj.length; i++) {
      if (counts[i] > 0) {
        const v = proj[i] / counts[i] - mean;
        variance += v * v;
      }
    }
    if (variance > bestScore) {
      bestScore = variance;
      bestAngle = deg;
    }
  }
  return bestAngle;
}

/**
 * Remove uneven illumination (phone-photo shadows): estimate the background
 * with a fast integral-image box blur, then divide the image by it.
 */
function removeShadows(data: Uint8ClampedArray, width: number, height: number, radius = 40): void {
  const gray = new Float64Array(width * height);
  for (let i = 0, p = 0; i < data.length; i += 4, p++) {
    gray[p] = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
  }

  // Integral image
  const integral = new Float64Array((width + 1) * (height + 1));
  for (let y = 0; y < height; y++) {
    let rowSum = 0;
    for (let x = 0; x < width; x++) {
      rowSum += gray[y * width + x];
      integral[(y + 1) * (width + 1) + (x + 1)] = integral[y * (width + 1) + (x + 1)] + rowSum;
    }
  }

  for (let y = 0; y < height; y++) {
    const y0 = Math.max(0, y - radius);
    const y1 = Math.min(height - 1, y + radius);
    for (let x = 0; x < width; x++) {
      const x0 = Math.max(0, x - radius);
      const x1 = Math.min(width - 1, x + radius);
      const area = (x1 - x0 + 1) * (y1 - y0 + 1);
      const sum =
        integral[(y1 + 1) * (width + 1) + (x1 + 1)] -
        integral[y0 * (width + 1) + (x1 + 1)] -
        integral[(y1 + 1) * (width + 1) + x0] +
        integral[y0 * (width + 1) + x0];
      const background = sum / area;
      const p = y * width + x;
      // Normalize: pixel / background * 230 (keep text dark, flatten shadows)
      const corrected = Math.max(0, Math.min(255, (gray[p] / Math.max(background, 1)) * 230));
      data[p * 4] = corrected;
      data[p * 4 + 1] = corrected;
      data[p * 4 + 2] = corrected;
    }
  }
}

/**
 * Phone-photo enhancement for the Snap-to-Excel flow: deskew -> shadow removal
 * -> the existing grayscale/contrast/Otsu pipeline. Returns the enhanced canvas
 * plus the detected skew so the UI can show what happened.
 */
export function enhanceForCameraScan(sourceCanvas: HTMLCanvasElement): {
  canvas: HTMLCanvasElement;
  skewDeg: number;
  shadowRemoved: boolean;
} {
  let working = sourceCanvas;
  let detectedSkew = 0;

  // 1. Deskew on a downscaled analysis, rotate the full image if needed
  try {
    const small = document.createElement('canvas');
    const s = Math.min(1, 500 / Math.max(sourceCanvas.width, sourceCanvas.height));
    small.width = Math.max(1, Math.round(sourceCanvas.width * s));
    small.height = Math.max(1, Math.round(sourceCanvas.height * s));
    const sctx = small.getContext('2d');
    if (sctx) {
      sctx.drawImage(sourceCanvas, 0, 0, small.width, small.height);
      const sdata = sctx.getImageData(0, 0, small.width, small.height).data;
      const gray = new Uint8ClampedArray(small.width * small.height);
      for (let i = 0, p = 0; i < sdata.length; i += 4, p++) {
        gray[p] = 0.299 * sdata[i] + 0.587 * sdata[i + 1] + 0.114 * sdata[i + 2];
      }
      const skew = estimateSkew(gray, small.width, small.height);
      detectedSkew = skew;
      if (Math.abs(skew) >= 0.5) {
        const rotated = document.createElement('canvas');
        const rad = (skew * Math.PI) / 180;
        rotated.width = Math.round(sourceCanvas.width * Math.abs(Math.cos(rad)) + sourceCanvas.height * Math.abs(Math.sin(rad)));
        rotated.height = Math.round(sourceCanvas.width * Math.abs(Math.sin(rad)) + sourceCanvas.height * Math.abs(Math.cos(rad)));
        const rctx = rotated.getContext('2d');
        if (rctx) {
          rctx.fillStyle = '#ffffff';
          rctx.fillRect(0, 0, rotated.width, rotated.height);
          rctx.translate(rotated.width / 2, rotated.height / 2);
          rctx.rotate(rad);
          rctx.drawImage(sourceCanvas, -sourceCanvas.width / 2, -sourceCanvas.height / 2);
          working = rotated;
        }
      }
    }
  } catch (e) {
    console.warn('Deskew skipped:', e);
  }

  // 2. Shadow removal (in-place on the working canvas)
  let shadowRemoved = false;
  const ctx = working.getContext('2d');
  if (ctx) {
    try {
      const img = ctx.getImageData(0, 0, working.width, working.height);
      removeShadows(img.data, working.width, working.height);
      shadowRemoved = true;
      ctx.putImageData(img, 0, 0);
    } catch (e) {
      console.warn('Shadow removal skipped:', e);
    }
  }

  // 3. Existing upscale + contrast + Otsu pipeline
  return { canvas: preprocessImageForOcr(working), skewDeg: detectedSkew, shadowRemoved };
}

/**
 * Image preprocessor: upscales, converts to grayscale, normalizes contrast, and applies Otsu binarization.
 * Dramatically cuts OCR character confusions (e.g. 1 -> l, c) -> c¢) and improves boundary detection.
 */
export function preprocessImageForOcr(
  sourceCanvas: HTMLCanvasElement,
): HTMLCanvasElement {
  const minWidth = 1800;
  let targetWidth = sourceCanvas.width;
  let targetHeight = sourceCanvas.height;

  // 1. Upscale if low-resolution (below ~200-300 DPI)
  if (targetWidth < minWidth) {
    const scale = minWidth / targetWidth;
    targetWidth = Math.round(targetWidth * scale);
    targetHeight = Math.round(targetHeight * scale);
  }

  const canvas = document.createElement('canvas');
  canvas.width = targetWidth;
  canvas.height = targetHeight;
  const ctx = canvas.getContext('2d');
  if (!ctx) return sourceCanvas;

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(sourceCanvas, 0, 0, targetWidth, targetHeight);

  const imgData = ctx.getImageData(0, 0, targetWidth, targetHeight);
  const data = imgData.data;
  const totalPixels = targetWidth * targetHeight;

  // 2. Grayscale & Histogram computation
  const histogram = new Uint32Array(256);
  let minGray = 255;
  let maxGray = 0;

  for (let i = 0; i < data.length; i += 4) {
    // Luminance grayscale formula
    const gray = Math.round(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
    data[i] = gray;
    data[i + 1] = gray;
    data[i + 2] = gray;

    histogram[gray]++;
    if (gray < minGray) minGray = gray;
    if (gray > maxGray) maxGray = gray;
  }

  // 3. Contrast Stretching
  const range = maxGray - minGray || 1;
  for (let i = 0; i < data.length; i += 4) {
    const stretched = Math.round(((data[i] - minGray) / range) * 255);
    data[i] = stretched;
    data[i + 1] = stretched;
    data[i + 2] = stretched;
  }

  // 4. Otsu's Global Adaptive Thresholding for crisp binary text
  let sum = 0;
  for (let t = 0; t < 256; t++) {
    sum += t * histogram[t];
  }

  let sumB = 0;
  let wB = 0;
  let wF = 0;
  let varMax = 0;
  let threshold = 128;

  for (let t = 0; t < 256; t++) {
    wB += histogram[t];
    if (wB === 0) continue;
    wF = totalPixels - wB;
    if (wF === 0) break;

    sumB += t * histogram[t];
    const mB = sumB / wB;
    const mF = (sum - sumB) / wF;

    const varBetween = wB * wF * (mB - mF) * (mB - mF);
    if (varBetween > varMax) {
      varMax = varBetween;
      threshold = t;
    }
  }

  // Bias threshold slightly towards dark text to prevent thinning strokes
  threshold = Math.min(210, Math.max(80, Math.round(threshold * 1.05)));

  for (let i = 0; i < data.length; i += 4) {
    const val = data[i] < threshold ? 0 : 255;
    data[i] = val;
    data[i + 1] = val;
    data[i + 2] = val;
  }

  ctx.putImageData(imgData, 0, 0);
  return canvas;
}

/**
 * Post-OCR Text Normalizer
 * Repairs typical OCR glitches, letter/digit swaps, glued option markers, and missing whitespace.
 */
/**
 * Persian OCR confusion dictionary (#7).
 * Tesseract's `fas` model frequently confuses visually-similar glyphs. Each
 * entry maps a mis-read token (or character in token context) to its real
 * form. Applied at WORD level, gated by OCR confidence, so we never "fix"
 * something the recognizer was actually sure about.
 */
export const PERSIAN_OCR_CONFUSIONS: { pattern: RegExp; replace: string; note: string }[] = [
  { pattern: /\u0649/g, replace: '\u06CC', note: 'Alef maksura -> Persian Yeh' },
  { pattern: /\u064A/g, replace: '\u06CC', note: 'Arabic Yeh -> Persian Yeh' },
  { pattern: /\u0643/g, replace: '\u06A9', note: 'Arabic Kaf -> Persian Kaf' },
  { pattern: /\u0629/g, replace: '\u0647', note: 'Teh marbuta -> Heh' },
  // Latin confusions in English exam text
  { pattern: /\brn\b/g, replace: 'm', note: 'rn -> m (classic OCR merge)' },
  { pattern: /\b1ate\b/g, replace: 'late', note: '1 -> l at word start' },
];

/**
 * Word-level OCR confidence audit (#7): split lines into words and flag the
 * ones the recognizer was unsure about (< threshold). Deterministic.
 */
export function auditOcrWordConfidence(
  lines: { text: string; confidence?: number; lineIndex?: number }[],
  threshold = 60,
): { word: string; confidence: number; lineIndex: number }[] {
  const flagged: { word: string; confidence: number; lineIndex: number }[] = [];
  for (const line of lines) {
    if (line.confidence === undefined || line.confidence >= threshold) continue;
    for (const word of line.text.split(/\s+/)) {
      if (word.length > 1 && /[A-Za-z\u0600-\u06FF]/.test(word)) {
        flagged.push({ word, confidence: Math.round(line.confidence), lineIndex: line.lineIndex ?? -1 });
      }
    }
  }
  return flagged;
}

export function normalizeOcrText(rawText: string): string {
  if (!rawText) return '';

  let text = rawText;

  // 1. Normalize Persian and Arabic numerals to ASCII digits
  text = text
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 1776))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632));

  // 1b. Strip Private Use Area glyphs (#qu2 wave R4, pt7kkv4576): symbol-font
  // bullets ("\uF054 Listening" — a Wingdings arrow before the section label)
  // are font furniture; the PUA codepoint blocked the bare-label matchers
  // (labelLine, skill-label stamping) from ever seeing the label.
  text = text.replace(/[\uE000-\uF8FF]/g, '');

  // 2. Strip leading noise before section headers, e.g. "| B)" -> "B)" or "_ A." -> "A."
  text = text.replace(/(?:^|\n)\s*[|_\-~*#•]+\s*([A-Za-z\u0600-\u06FF])/g, '\n$1');

  // 3. Repair line-start question number confusions:
  // e.g. "l.Acatisan..." or "l. Acat..." or "I. The..." or "i. She..." -> "1. Acat..."
  text = text.replace(/(?:^|\n)\s*[lIi][\.\)]\s*(?=[A-Za-z\u0600-\u06FF])/g, (m) =>
    m.startsWith('\n') ? '\n1. ' : '1. ',
  );

  // 4. Glued question numbers: "2.Thesunis..." -> "2. Thesunis..."
  text = text.replace(/(?:^|\n)\s*(\d+)[\.\)]([A-Za-z\u0600-\u06FF])/g, (m, num, char) =>
    `${m.startsWith('\n') ? '\n' : ''}${num}. ${char}`,
  );

  // 5. Teacher question with capital "I" misread as "1": "3.1.........to school" -> "3. I ......... to school"
  text = text.replace(
    /(?:^|\n)\s*(\d+)[\.\)]\s*1\s*(\.{3,}|_{3,}|-{3,})/g,
    (m, num, blanks) => `${m.startsWith('\n') ? '\n' : ''}${num}. I ${blanks}`,
  );

  // 6. Option markers: handle OCR noise and missing spaces.
  // ⚠ Same-line whitespace only ([ \t]) — using \s here made "food.\n31."
  // match and MERGE two source lines (golden corpus fuzz caught this).
  // e.g. "c¢)blue" -> "c) blue", "c©)blue" -> "c) blue"
  text = text.replace(/([a-d])[ \t]*[¢©*»>\]][ \t]*\)/gi, '$1)');

  // e.g. "a)animal" -> "a) animal", "b)car" -> "b) car"
  text = text.replace(/([a-d])\)[ \t]*([^\s\)])/gi, '$1) $2');

  // e.g. "a.animal" -> "a. animal"
  text = text.replace(/([a-d])\.[ \t]*([^\s\.])/gi, '$1. $2');

  // Persian options: "الف)حیوان" -> "الف) حیوان"
  text = text.replace(/(الف|ب|ج|د)\)[ \t]*([^\s\)])/g, '$1) $2');

  // 7. Collapse long dot sequences: "........." -> "......"
  text = text.replace(/\.{5,}/g, '......');

  // 8. Fix common OCR glued words in Iranian exams
  text = text.replace(/\bared\b/g, 'a red');
  text = text.replace(/\bthesun\b/gi, 'the sun');
  text = text.replace(/\bacat\b/gi, 'a cat');

  // 9. Persian confusion dictionary (#7) — character-level fixes that are
  // ALWAYS safe (they map glyph variants to canonical forms).
  for (const rule of PERSIAN_OCR_CONFUSIONS) {
    if (rule.pattern.global) {
      text = text.replace(rule.pattern, rule.replace);
    } else {
      text = text.replace(rule.pattern, rule.replace);
    }
  }

  return text;
}
