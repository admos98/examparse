import * as pdfjsLib from 'pdfjs-dist';

/**
 * Page renderer for the X-ray overlay (#12): draws page N of the exam's
 * original source file (PDF or image) onto a canvas so parsed question
 * bounding boxes can be layered on top of the real pixels.
 */

export interface RenderedPage {
  canvas: HTMLCanvasElement;
  /** Native size of the rendered page (X-ray boxes are scaled to this). */
  width: number;
  height: number;
  /** For PDF text-space provenance: scale factor used during rendering. */
  scale: number;
}

const RENDER_SCALE = 1.6;

export async function renderSourcePage(sourceFile: Blob, pageNumber: number): Promise<RenderedPage> {
  const name = (sourceFile as File).name?.toLowerCase() || '';
  const isPdf = name.endsWith('.pdf') || sourceFile.type === 'application/pdf';

  if (isPdf) {
    const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(await sourceFile.arrayBuffer()), useSystemFonts: true });
    const pdf = await loadingTask.promise;
    const pageIdx = Math.min(Math.max(1, pageNumber), pdf.numPages);
    const page = await pdf.getPage(pageIdx);
    const viewport = page.getViewport({ scale: RENDER_SCALE });
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(viewport.width);
    canvas.height = Math.round(viewport.height);
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas 2D context unavailable');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({ canvasContext: ctx, viewport, canvas } as any).promise;
    return { canvas, width: canvas.width, height: canvas.height, scale: RENDER_SCALE };
  }

  // Image file
  const bitmap = await createImageBitmap(sourceFile);
  const canvas = document.createElement('canvas');
  canvas.width = bitmap.width;
  canvas.height = bitmap.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context unavailable');
  ctx.drawImage(bitmap, 0, 0);
  return { canvas, width: bitmap.width, height: bitmap.height, scale: 1 };
}

export async function countSourcePages(sourceFile: Blob): Promise<number> {
  const name = (sourceFile as File).name?.toLowerCase() || '';
  const isPdf = name.endsWith('.pdf') || sourceFile.type === 'application/pdf';
  if (!isPdf) return 1;
  const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(await sourceFile.arrayBuffer()), useSystemFonts: true });
  const pdf = await loadingTask.promise;
  return pdf.numPages;
}
