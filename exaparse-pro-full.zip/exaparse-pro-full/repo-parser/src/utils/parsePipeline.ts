import { ExamDocument } from '../types/exam';
import { parseExamRawText, ParseOptions, RawSectionBlock } from './parserEngine';
import { attachProvenance } from './provenance';
import { runInvariantChecks } from './invariants';
import { computeTrust, applyTrust } from './trustEngine';
import { logBlackBox } from './diagnostics';
import { applyMinedRules, getActiveMinedRules } from './ruleMiner';
import { applyTemplateHints } from './sectionTemplates';
import { applyAnswerKey } from './answerKey';
import { buildBrainPreSplit, type BrainStepResult } from './brainStep';
import type { BrainReportSummary } from './brainBridge';
import type { BrainDoc } from './layoutBrain';
import { MINED_TEMPLATES } from '../data/minedTemplates';

export { buildBrainPreSplit };
export type { BrainStepResult };

/**
 * Parse Pipeline (#5/#17) — the ONE entry point the UI uses.
 *
 * - THROW-FREE: never rejects; returns { ok:false, error } with the black box
 *   already fed. The UI shows findings, not stack traces.
 * - STREAMING: `onStage` callbacks keep the wizard progress bar honest.
 * - TRUSTED: provenance, invariants, trust chips and the parse trace are
 *   attached here so every downstream screen just reads them.
 */

export type ParseStage =
  | 'extract'
  | 'quality'
  | 'parse'
  | 'rules'
  | 'provenance'
  | 'invariants'
  | 'trust'
  | 'done';

export interface ParseStageUpdate {
  stage: ParseStage;
  status: string;
  percent: number; // 0-100
}

export interface ParsePipelineInput {
  rawText: string;
  filename: string;
  options?: ParseOptions;
  /** Layout lines from the extractor (for provenance). Optional. */
  lines?: import('./fileExtractor').LayoutLine[];
  /** EQS report from the extractor, attached to the document. */
  eqs?: import('../types/exam').ExtractionQualityReport;
  /** Minimal offline OCR of embedded pictures (docx media) — verification
   *  context only; attached to the doc, never fed to the parser. */
  pictureNotes?: string[];
  /** Live mined rules (Idea 1). Defaults to the module-wide active set. */
  minedRules?: import('./ruleMiner').MinedRule[];
  /** Layout geometry for the sectioning brain (from the PDF extractor's
   *  pdf.js pass). 'advisory' (default) attaches the brain's verdict +
   *  uncertainty report; 'drive' lets the brain's verified blocks BE the
   *  section split (experimental). */
  brainDoc?: BrainDoc;
  brainMode?: 'advisory' | 'drive';
}

export type ParsePipelineResult =
  | { ok: true; doc: ExamDocument }
  | { ok: false; error: string };

export function runParsePipeline(
  input: ParsePipelineInput,
  onStage?: (u: ParseStageUpdate) => void,
  preParsed?: ExamDocument,
  workerBrainReport?: BrainReportSummary,
): ParsePipelineResult {
  const { rawText, filename, options, lines, eqs, pictureNotes } = input;
  const report = (stage: ParseStage, status: string, percent: number) =>
    onStage?.({ stage, status, percent });

  try {
    const started = Date.now();
    let doc: ExamDocument;
    if (preParsed) {
      doc = preParsed;
      if (workerBrainReport) {
        doc.brainReport = workerBrainReport;
        logBlackBox({
          event: 'layout_brain_applied',
          filename,
          detail: `${workerBrainReport.mode}: ${workerBrainReport.confirmed}/${workerBrainReport.sections} section(s) confirmed`,
          metrics: {
            confirmed: workerBrainReport.confirmed,
            sections: workerBrainReport.sections,
            fallbacks: workerBrainReport.fallbacks,
            sumMarks: workerBrainReport.sumMarks,
          },
        });
      }
    } else {
      report('parse', 'Reading the page layout...', 50);
      // Layout brain (user charter): geometry evidence is perceived, fused and
      // cross-checked FIRST; in 'drive' mode its verified blocks are the
      // section split, in 'advisory' mode (default) the verdict rides along as
      // a report while the text splitters parse. Failures are non-fatal.
      const brainStep = buildBrainPreSplit(input.brainDoc, input.brainMode ?? 'drive');
      if (brainStep.failed) {
        console.warn('layout brain failed (non-fatal, using the text splitters):', brainStep.failed);
        logBlackBox({ event: 'layout_brain_failed', filename, detail: brainStep.failed });
      }
      if (brainStep.report) {
        report('parse', `Layout brain separated ${brainStep.report.confirmed} section(s) from page geometry`, 53);
      }
      report('parse', 'Canonicalizing text & parsing structure...', 55);
      doc = parseExamRawText(rawText, filename, options, brainStep.preSplit);
      if (brainStep.report) {
        doc.brainReport = brainStep.report;
        logBlackBox({
          event: 'layout_brain_applied',
          filename,
          detail: `${brainStep.report.mode}: ${brainStep.report.confirmed}/${brainStep.report.sections} section(s) confirmed`,
          metrics: {
            confirmed: brainStep.report.confirmed,
            sections: brainStep.report.sections,
            fallbacks: brainStep.report.fallbacks,
            sumMarks: brainStep.report.sumMarks,
          },
        });
      }
    }

    if (eqs) doc.extraction = eqs;
    if (pictureNotes && pictureNotes.length > 0) doc.pictureOcrNotes = pictureNotes;

    // Mined-rules layer (Idea 1) — additive, reversible, default empty. Runs
    // BEFORE template hints + trust so the evidence reflects the final parse.
    const rules = input.minedRules ?? getActiveMinedRules();
    if (rules.length > 0) {
      try {
        doc = applyMinedRules(doc, rules);
      } catch (e) {
        console.warn('mined-rule application failed (non-fatal, rules skipped):', e);
      }
    }

    // Mined-template hints (Idea 2) — advisory evidence only, never a stamp.
    try {
      doc = applyTemplateHints(doc, MINED_TEMPLATES);
    } catch (e) {
      console.warn('template hints failed (non-fatal):', e);
    }

    // Answer key PRINTED ON THE SHEET — deterministic, offline. Key rows
    // become METADATA (never questions), answers attach with official
    // provenance, and the AI answer flow later skips answer generation
    // (Jev still verifies separation + metadata; see utils/answerKey.ts).
    try {
      const key = applyAnswerKey(doc);
      if (key.report) {
        doc = key.doc;
        doc.answerKeyOnFile = key.report;
        logBlackBox({
          event: 'answer_key_detected',
          filename,
          detail: `via ${key.report.via}: ${key.report.applied} answer(s) applied, ${key.report.warnings.length} warning(s)`,
          metrics: { applied: key.report.applied, warnings: key.report.warnings.length },
        });
      }
    } catch (e) {
      console.warn('answer-key detection failed (non-fatal):', e);
    }

    report('provenance', 'Linking questions to their source lines...', 70);
    if (lines && lines.length > 0) {
      try {
        attachProvenance(doc, lines);
      } catch (e) {
        console.warn('provenance attach failed (non-fatal):', e);
      }
    }

    report('invariants', 'Validating structural invariants...', 82);
    try {
      doc.invariants = runInvariantChecks(doc);
    } catch (e) {
      console.warn('invariant checks failed (non-fatal):', e);
    }

    report('trust', 'Computing truth chips...', 92);
    let finalDoc = doc;
    try {
      finalDoc = applyTrust(doc);
    } catch (e) {
      console.warn('trust computation failed (non-fatal):', e);
    }

    const ms = Date.now() - started;
    logBlackBox({
      event: 'parse_success',
      filename,
      detail: finalDoc.parseTrace?.fallbackUsed ? 'rule-table fallback used' : 'rule-table path',
      metrics: {
        questions: finalDoc.totalQuestions,
        sections: finalDoc.sections.length,
        eqs: eqs?.score ?? -1,
        ms,
      },
    });
    if (eqs && eqs.verdict === 'poor') {
      logBlackBox({ event: 'eqs_poor', filename, metrics: { eqs: eqs.score } });
    }

    report('done', `Parsed ${finalDoc.totalQuestions} questions in ${ms} ms`, 100);
    return { ok: true, doc: finalDoc };
  } catch (e: any) {
    const error = e?.message || String(e);
    logBlackBox({ event: 'parse_error', filename, detail: error, snippet: String(rawText || '').slice(0, 240) });
    report('done', 'Parse failed', 100);
    return { ok: false, error };
  }
}

/** Convenience for paste/preset flows without a source file. */
export function parseTextTrusted(rawText: string, filename: string): ExamDocument | null {
  const res = runParsePipeline({ rawText, filename });
  return res.ok ? res.doc : null;
}

/** Shared brain step lives in brainStep.ts (also used by the parse worker). */

// ---------------------------------------------------------------------------
// Off-main-thread parsing (#5/#17): large texts run in a Web Worker so the UI
// never freezes. Falls back to the synchronous path when workers are
// unavailable (tests, SSR, old browsers).
// ---------------------------------------------------------------------------

const WORKER_THRESHOLD = 40_000; // chars

export function parseAsync(
  input: ParsePipelineInput,
  onStage?: (u: ParseStageUpdate) => void,
): Promise<ParsePipelineResult> {
  const big = (input.rawText || '').length > WORKER_THRESHOLD;
  if (!big || typeof Worker === 'undefined' || typeof Blob === 'undefined' || typeof URL === 'undefined') {
    // Small text (or no worker support): run synchronously on the microtask queue.
    return Promise.resolve().then(() => runParsePipeline(input, onStage));
  }
  return parseInWorker(input, onStage).catch((e) => {
    console.warn('Worker parse unavailable, falling back to main thread:', e);
    return runParsePipeline(input, onStage);
  });
}

async function parseInWorker(
  input: ParsePipelineInput,
  onStage?: (u: ParseStageUpdate) => void,
): Promise<ParsePipelineResult> {
  onStage?.({ stage: 'parse', status: 'Parsing in a background thread...', percent: 50 });

  const worker = new Worker(new URL('../workers/parseWorker.ts', import.meta.url), { type: 'module' });

  try {
    const result = await new Promise<{
      ok: boolean;
      doc?: ExamDocument;
      error?: string;
      brainReport?: BrainReportSummary;
    }>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Worker parse timed out (30s)')), 30_000);
      worker.onmessage = (e: MessageEvent) => {
        clearTimeout(timer);
        const data = e.data;
        if (data && typeof data === 'object' && 'ok' in data) {
          resolve(data.ok ? { ok: true, doc: data.doc, brainReport: data.brainReport } : { ok: false, error: data.error });
        } else {
          reject(new Error('Malformed worker response'));
        }
      };
      worker.onerror = (err) => {
        clearTimeout(timer);
        reject(new Error(err.message || 'Worker crashed'));
      };
      worker.postMessage({
        rawText: input.rawText,
        filename: input.filename,
        options: input.options,
        brainDoc: input.brainDoc,
        brainMode: input.brainMode,
      });
    });

    if (!result.ok || !result.doc) return { ok: false, error: result.error || 'worker parse failed' };

    // Finish the trust pipeline on the main thread (cheap, needs no worker);
    // the worker's brain verdict rides along and is attached + logged there.
    return runParsePipeline(input, onStage, result.doc, result.brainReport);
  } finally {
    worker.terminate();
  }
}
