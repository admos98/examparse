import {
  ExamDocument,
  ParseVerdict,
  ParseVerifyReceipt,
} from '../types/exam';
import { JevConfig } from '../types/settings';
import { kvGetMany, kvSet } from './localStore';
import { serializeExamToText } from './examSerializer';
import { imagePendingQuestionIds } from './imagePending';
import { getSurfaceFilterSettings } from './surfaceFilter';
import { bucketACandidates, isHumanOnly } from './answerFlow';
import {
  cognitiveCriteria,
  DIGEST_VERSION,
  keywordSupport,
  lessonCriteria,
  lessonCriteriaLight,
  provenanceCriteria,
} from './curriculum';
import { LessonAttribution } from '../types/exam';

/**
 * Parse verification — the Jev consensus gate over the PARSE itself.
 *
 * Approved flow (user directive):
 *   1. The offline parser runs first. When it matches a known layout family and
 *      produces a structurally valid sheet, the parse is "first round true".
 *   2. The WHOLE raw parsed sheet + the raw extracted source text ride to the
 *      judge in ONE call ("in context, not multiple calls").
 *   3. For EVERY question the judge answers ONLY true/false on three axes:
 *        type        — is the parsed question type right?
 *        separation  — is the question correctly separated from its neighbors?
 *        metadata    — number, mark, options, word-bank membership, passage link.
 *      Word banks are judged as the WHOLE bank (shipped once in the shared
 *      state) with each question's bank membership specified in its metadata.
 *   4. Consensus gate:  parser-true ∧ JEV-true  → 'accepted' (auto-accept).
 *      Any disagreement on any axis (either side) → 'flagged' → the question
 *      enters the human/AI validation queue. Nothing is ever auto-fixed.
 *
 * Engineering contract (fail-safe by construction):
 *   • THROW-FREE: every failure mode returns { ok:false } + warnings.
 *   • The parse is NEVER mutated — verdicts attach as evidence only.
 *   • Missing/unparseable verdicts → 'unverified', never silently 'accepted'.
 *   • Per-question content fingerprints + IndexedDB cache → re-runs are ~free.
 *   • The single-call contract degrades to explicit chunking ONLY when the
 *     sheet physically cannot fit one call, and says so in warnings.
 *   • Reuses the existing /api/judge dual-backend pipeline (native Jev first,
 *     LLM fallback) — one retry ladder, one auth path, one usage meter.
 */

const CACHE_PREFIX = 'jv1:';

/** Hard cap on questions per judge call — keeps the answer map inside budget. */
const MAX_QUESTIONS_PER_CALL = 250;
/** Raw source text is capped; larger scans get an explicit warning. */
const MAX_SOURCE_CHARS = 200_000;
/** Cap on parent-context text shipped per item (metadata, not the full text). */
const MAX_CTX_CHARS = 600;

export interface SheetQuestion {
  id: string;
  number: string;
  type: string;
  mark: number;
  stem: string;
  options?: string;
  usesWordBank: boolean;
  wordBankWords?: string[];
  parentContext?: { kind: string; title?: string; text?: string };
  matchingPairs?: string;
  /** Vision alt/transcription attached to this question's image (if any). */
  imageCaption?: string;
  /**
   * M2 answer axis: the item's OWN candidate set (option key -> text) for the
   * `a:` Choice question. Present ONLY for bucket-A items; bucket-B free-text
   * items have none (they are answered by the R3 producer-critic instead).
   */
  candidates?: Record<string, string>;
}

export interface SheetSection {
  id: string;
  category: string;
  title?: string;
  instruction?: string;
  wordBank?: string[];
  passage?: { title?: string; text?: string };
  questions: SheetQuestion[];
}

export interface VerificationBuild {
  /** Raw extracted exam text (parse-trace lines) — the ground truth to verify against. */
  source: string;
  /** True when the source was reconstructed from the AST (no parse trace kept). */
  sourceReconstructed: boolean;
  header: Record<string, string | number | undefined>;
  /** Compact but COMPLETE parsed sheet (every question, every piece of metadata). */
  sheet: { sections: SheetSection[] };
  questionCount: number;
  /** Non-fatal construction warnings (source truncation, fallbacks). */
  warnings: string[];
}

export interface VerifyParseResult {
  ok: boolean;
  error?: string;
  /** questionId -> verdict (only for questions that carry one). */
  verdicts: Map<string, ParseVerdict>;
  /**
   * M2: questionId -> the judge's `a:` Choice pick for bucket-A items
   * (VALUE = the candidate text, key = the option label). These are AI DRAFTS
   * (single-model, jevVerified:false) — the caller attaches them via
   * attachProducedAnswer; they never touch correctAnswer directly.
   */
  answers: Map<string, R1AnswerPick>;
  /** M3: questionId -> lesson/provenance/cognitive attribution signals. */
  attributions: Map<string, LessonAttribution>;
  receipt: ParseVerifyReceipt | null;
  warnings: string[];
}

export interface R1AnswerPick {
  questionId: string;
  /** The chosen option key (e.g. 'b', 'true', '3'). */
  key: string;
  /** The candidate TEXT the key maps to. */
  value: string;
  confidence?: number;
}

// ---------- fingerprint ----------

function hash36(raw: string): string {
  let h = 5381;
  for (let i = 0; i < raw.length; i++) {
    h = ((h << 5) + h + raw.charCodeAt(i)) | 0;
  }
  return (h >>> 0).toString(36);
}

function norm(s: unknown): string {
  return String(s ?? '').replace(/\s+/g, ' ').trim().toLowerCase();
}

/**
 * Stable per-question cache key: everything the three axes are judged against
 * (the item, its section context, the header). Any change re-verifies.
 */
export function questionVerifyKey(item: SheetQuestion, sec: SheetSection, header: VerificationBuild['header']): string {
  // NOTE: the metadata axis judges the question NUMBER, so the number must be
  // part of the key — a renumbered question is a different parse shape.
  // Instruction/passage are hashed in FULL (no truncation): two exams sharing
  // a stem + passage PREFIX must not share a cache entry.
  const raw = [
    item.id,
    item.number,
    item.type,
    item.mark,
    norm(item.stem),
    norm(item.options),
    norm(item.matchingPairs),
    (item.wordBankWords || []).map(norm).join(','),
    item.usesWordBank ? 'bank' : 'nobank',
    norm(item.parentContext?.kind),
    norm(item.parentContext?.title),
    norm(item.parentContext?.text),
    norm(sec.id),
    norm(sec.instruction),
    (sec.wordBank || []).map(norm).join(','),
    norm(sec.passage?.text),
    norm(header.courseName),
    norm(header.grade),
    norm(item.imageCaption),
  ].join('::');
  return `${CACHE_PREFIX}${hash36(raw)}`;
}

// ---------- sheet construction ----------

/**
 * Build the verification payload. The source is the ACTUAL raw text the parser
 * consumed (parse-trace lines) so Jev compares the parse against the same
 * bytes the parser saw. Falls back to a faithful round-trip serialization.
 */
export function buildVerificationSheet(
  doc: ExamDocument,
  opts: { skipAnswerAxis?: boolean } = {},
): VerificationBuild {
  const warnings: string[] = [];
  let source = '';
  let sourceReconstructed = false;

  const lines = doc.parseTrace?.lines;
  if (Array.isArray(lines) && lines.length > 0) {
    source = lines.join('\n');
  } else {
    source = serializeExamToText(doc);
    sourceReconstructed = true;
  }
  // Minimal offline OCR of the pictures embedded in the source (docx media,
  // pre-extracted fail-soft by the extractor). These annotations NEVER enter
  // the parse input (the line-based parser would spawn phantom questions);
  // they exist so the judge can verify picture-referencing stems against the
  // same pixels the candidate saw. Capped so a media-heavy file cannot blow
  // the payload.
  if (Array.isArray(doc.pictureOcrNotes) && doc.pictureOcrNotes.length > 0) {
    const notes = doc.pictureOcrNotes.join('\n').slice(0, 20_000);
    source += `\n\n[picture OCR annotations — minimal offline OCR of the pictures embedded in the source]\n${notes}`;
    warnings.push(`${doc.pictureOcrNotes.length} embedded-picture OCR annotation(s) appended to the verification source.`);
  }
  // Vision alts (Idea 3): the authoritative text of each placed image rides in
  // the verification source so image-dependent questions are text-complete and
  // Jev — text-only — can judge them. NEVER part of the parse input.
  if (Array.isArray(doc.images) && doc.images.some((i) => i.alt)) {
    const altLines = doc.images
      .filter((i) => i.alt)
      .map((i) => {
        const q = i.questionId
          ? doc.sections.flatMap((s) => s.questions).find((x) => x.id === i.questionId)
          : undefined;
        const owner = q ? ` (placed at Q${q.displayNumber}, ${i.placementStatus || '?'})` : ' (unplaced)';
        return `${i.id}${owner}: ${i.alt!.slice(0, 400)}`;
      })
      .join('\n');
    source += `\n\n[image alts — vision-generated, human-reviewable]\n${altLines.slice(0, 20_000)}`;
    warnings.push(`${doc.images.filter((i) => i.alt).length} vision alt annotation(s) appended to the verification source.`);
  }
  if (source.length > MAX_SOURCE_CHARS) {
    source = source.slice(0, MAX_SOURCE_CHARS);
    warnings.push(`Raw source exceeded ${MAX_SOURCE_CHARS} chars and was truncated for verification.`);
  }

  // Surface filter (D4): school/date never ride AI payloads. The h:header
  // noul only checks course+grade — the judge does not need the school name
  // to verify the parse, and the paper's identity is not our data to share.
  const header = {
    courseName: doc.header.courseName || undefined,
    grade: doc.header.grade || doc.header.gradeAndMajor || undefined,
    term: doc.header.term || undefined,
    schoolName: getSurfaceFilterSettings().showFullHeaderFields
      ? doc.header.schoolName || undefined
      : undefined,
    examDate: getSurfaceFilterSettings().showFullHeaderFields
      ? doc.header.examDate || undefined
      : undefined,
    durationMinutes: doc.header.durationMinutes || undefined,
  };

  const sheet: { sections: SheetSection[] } = {
    sections: doc.sections.map((sec) => ({
      id: sec.rowId,
      category: sec.majorCategory,
      title: sec.title || undefined,
      instruction: sec.englishInstruction || sec.persianInstruction || undefined,
      // WHOLE word bank, shipped once in the shared state (per the flow spec:
      // the bank is judged together with the questions that draw from it).
      wordBank: sec.hasWordBank && sec.wordBank?.length ? sec.wordBank : undefined,
      passage:
        sec.hasPassage && sec.passageText
          ? { title: sec.passageTitle || undefined, text: sec.passageText.slice(0, 2000) }
          : undefined,
      questions: sec.questions.map((q): SheetQuestion => ({
        id: q.id,
        number: q.displayNumber,
        type: q.type,
        mark: q.mark,
        stem: q.stem,
        options:
          q.options && q.options.length > 0
            ? q.options.map((o) => `${o.id}) ${o.text}`).join(' | ')
            : undefined,
        // M2: the item's own candidate set for the `a:` answer Choice (essays
        // never carry one — machine-answering them is forbidden by design).
        // Printed-key mode (skipAnswerAxis): answers come from the sheet's own
        // key with official provenance — the judge verifies separation and
        // metadata only, and NO answer picks are requested (zero wasted tokens).
        candidates:
          opts.skipAnswerAxis || isHumanOnly(q) ? undefined : bucketACandidates(q) || undefined,
        // Metadata that tells Jev what this question is supposed to be attached to.
        // PER-QUESTION scoping only: a section-level bank does NOT mean every
        // question in the section draws from it (mixed sections exist — MCQs
        // next to bank fills). Claiming otherwise fed the judge false metadata
        // and produced noise flags on questions that never touch the bank.
        usesWordBank: !!q.wordBankWords?.length,
        wordBankWords: q.wordBankWords?.length ? q.wordBankWords : undefined,
        parentContext:
          q.parentContextType && q.parentContextType !== 'none'
            ? {
                kind: q.parentContextType,
                title: q.parentContextTitle || undefined,
                text: q.parentContextText ? String(q.parentContextText).slice(0, MAX_CTX_CHARS) : undefined,
              }
            : undefined,
        matchingPairs:
          q.matchingPairs && q.matchingPairs.length > 0
            ? q.matchingPairs
                .map(
                  (p) =>
                    `${p.leftNumber}-${p.leftText}=>${p.rightKey || '?'}${p.rightText ? `(${p.rightText})` : ''}`,
                )
                .join('; ')
            : undefined,
        imageCaption: q.imageCaption || undefined,
      })),
    })),
  };

  const questionCount = doc.sections.reduce((n, s) => n + s.questions.length, 0);
  return { source, sourceReconstructed, header, sheet, questionCount, warnings };
}

// ---------- typed JEV questions ----------

const TYPE_MEANINGS: Record<string, string> = {
  multiple_choice: 'a stem with lettered options a/b/c/d to choose from',
  cloze_item: 'a passage with numbered blanks filled from given choices',
  word_bank_fill: 'a sentence completed with a word taken from a word box',
  fill_blank: 'a sentence where the answer is written into a blank',
  matching: 'match items from column A to column B',
  true_false: 'a statement judged true or false',
  short_answer: 'a brief written answer, one word or a few words',
  long_answer_essay: 'a long written response, paragraph or essay',
  unscramble: 'rearrange scrambled words into a correct sentence',
  form_in_parentheses: 'put the word in parentheses into the correct grammatical form',
  combine_sentences: 'join two sentences into one using a cue',
  active_passive: 'rewrite between active and passive voice',
  error_correction: 'find and correct a mistake in the sentence',
  letter_reorder: 'rearrange jumbled letters into a word',
  inline_choice: 'a blank inside the sentence with numbered inline choices',
  dialogue_response: 'choose or write the fitting line of a dialogue',
  odd_one_out: 'pick the word that does not belong in a group',
  phonetic_pronunciation: 'pick the word whose underlined part sounds different',
  sentence_ordering: 'order sentences into a coherent paragraph',
  picture_description: 'a question that refers to a picture',
  translation: 'translate between Persian and English',
  definition_matching: 'match definitions to words',
  numerical_calculation: 'a math calculation item',
};

interface VerifyTargets {
  headerCourse?: string;
  headerGrade?: string;
}

function noul(instructions: string): { type: 'noul'; instructions: string; criteria: { true: string; false: string } } {
  return {
    type: 'noul',
    instructions,
    criteria: { true: 'Yes — as described.', false: 'No — not as described, or too garbled to confirm.' },
  };
}

function choiceQ(instructions: string, criteria: Record<string, string>): { type: 'choice'; instructions: string; criteria: Record<string, string> } {
  return { type: 'choice', instructions, criteria };
}

export type VerifyQuestion = ReturnType<typeof noul> | ReturnType<typeof choiceQ>;

/** M3: attribution context — a resolved digest grade rides ONE per call. */
export interface AttributionContext {
  gradeKey: string;
}

/** Build ALL typed questions for one call: header + 3 nouls per item + the
 * `a:` answer Choice for every bucket-A item (its own candidate set) + the
 * l1/l2/b/c attribution Choices when a digest grade is resolved. */
export function buildVerifyQuestions(
  items: { item: SheetQuestion; sec: SheetSection }[],
  targets: VerifyTargets,
  attribution?: AttributionContext,
): Record<string, VerifyQuestion> {
  const out: Record<string, VerifyQuestion> = {};

  // Header sanity — one cheap noul for the whole sheet (the "method and grade
  // matched" first-round-true spot-check). Omitted when the header is empty.
  if (targets.headerCourse || targets.headerGrade) {
    out['h:header'] = noul(
      `id="h:header". Compare the parsed header (course="${targets.headerCourse || '?'}", grade="${targets.headerGrade || '?'}") ` +
        `against the raw source text in the state. Are these fields actually supported by the source — ` +
        `no invented school/grade/term, no wrong course?`,
    );
  }

  for (const { item, sec } of items) {
    // Word-bank metadata is stated truthfully in BOTH directions: the judge
    // must be told when an item draws from the bank AND when it does not —
    // silence on the negative case invites a false "metadata mismatch".
    const bankNote = sec.wordBank?.length
      ? item.usesWordBank
        ? ` The section's word bank (shared state) is: [${sec.wordBank.join(', ')}]. This item draws from that bank` +
          `${item.wordBankWords?.length ? ` with scoped words [${item.wordBankWords.join(', ')}]` : ''}.`
        : ` The section has a word bank (shared state): [${sec.wordBank.join(', ')}], but this item does NOT draw from it — it is answered independently.`
      : '';
    const ctxNote = item.parentContext
      ? ` Its parent context (${item.parentContext.kind}) is attached in the item's metadata.`
      : '';

    out[`t:${item.id}`] = noul(
      `id="t:${item.id}". Item "${item.id}" was parsed as type "${item.type}" (${TYPE_MEANINGS[item.type] || item.type}). ` +
        `Check the item's raw line(s) in the source text: is "${item.type}" the correct format for this item?`,
    );

    out[`s:${item.id}`] = noul(
      `id="s:${item.id}". Separation check for item "${item.id}" (number ${item.number}): in the raw source, is this EXACTLY ` +
        `one question printed under that number — no other question's text merged into it, and none of its own text ` +
        `missing into a neighboring question? Stem: "${String(item.stem || '').slice(0, 200)}".`,
    );

    out[`m:${item.id}`] = noul(
      `id="m:${item.id}". Metadata check for item "${item.id}": number (${item.number}), mark (${item.mark})` +
        `${item.options ? `, options (${item.options})` : ''}` +
        `${item.matchingPairs ? `, matching pairs (${item.matchingPairs})` : ''}` +
        `${bankNote}${ctxNote}` +
        `${item.imageCaption ? ` The question references an image; the authoritative content of that image (vision-transcribed, human-reviewable) is: "${item.imageCaption.slice(0, 200)}".` : ''}` +
        ` — do all of these match the source for this question?`,
    );

    // M2 answer axis (bucket A only): Jev picks the answer from the item's OWN
    // candidate set. The pick is an AI DRAFT (single-model, never auto-committed
    // until the calibration gate says this category may be trusted).
    if (item.candidates && Object.keys(item.candidates).length > 0) {
      const cands = item.candidates;
      const keys = Object.keys(cands);
      out[`a:${item.id}`] = choiceQ(
        `id="a:${item.id}". Answer item "${item.id}" (${item.type}) by choosing its correct answer. The allowed options are: ` +
          keys.map((k) => `${k}) ${String(cands[k]).slice(0, 80)}`).join('; ') +
          `. Read the item's raw line(s) in the source text${item.parentContext ? ' and its attached context' : ''}` +
          `${item.imageCaption ? ' and the image content given in its metadata' : ''}, then reply ONLY with the option key (${keys.join('/')}).`,
        cands,
      );
    }

    // M3 attribution axes (only when the digest grade is resolved): lesson span,
    // in-book provenance, cognitive level. These are SIGNALS — the app computes
    // the difficulty deterministically from configurable weights.
    if (attribution) {
      const stemHint = String(item.stem || '').slice(0, 120);
      const l1c = lessonCriteria(attribution.gradeKey);
      if (l1c) {
        out[`l1:${item.id}`] = choiceQ(
          `id="l1:${item.id}". Which lesson of the book primarily teaches the material this item tests? ` +
            `Item stem: "${stemHint}". Pick the single best lesson key.`,
          l1c,
        );
        const l2c = lessonCriteriaLight(attribution.gradeKey);
        if (l2c) {
          out[`l2:${item.id}`] = choiceQ(
            `id="l2:${item.id}". Does this item ALSO draw on a second lesson? Item stem: "${stemHint}". ` +
              `Pick the second lesson key, or "none".`,
            l2c,
          );
        }
      }
      out[`b:${item.id}`] = choiceQ(
        `id="b:${item.id}". Is the material this item TESTS (its vocabulary/grammar/structure — not the reading ` +
          `passage topic) covered by the book lessons listed in the grade state? Pick in / mixed / out.`,
        provenanceCriteria(),
      );
      out[`c:${item.id}`] = choiceQ(
        `id="c:${item.id}". What cognitive level does this item demand? Item stem: "${stemHint}". ` +
          `Pick recall / comprehension / application.`,
        cognitiveCriteria(),
      );
    }
  }

  return out;
}

// ---------- verdict assembly (the consensus gate) ----------

export interface AxisProbabilities {
  type?: number;
  separation?: number;
  metadata?: number;
}

/**
 * Assemble one ParseVerdict from the three noul probabilities.
 *   all axes >= threshold             → accepted
 *   any axis <= lowBand               → flagged (clear disagreement)
 *   axes between bands, or missing    → flagged-uncertain / unverified (needs review)
 */
export function assembleVerdict(
  p: AxisProbabilities,
  cfg: JevConfig,
  meta: { checkedAt: string; model: string; backend: 'jev' | 'llm-fallback'; fingerprint?: string; cached?: boolean },
): ParseVerdict {
  const threshold = typeof cfg.threshold === 'number' ? cfg.threshold : 0.9;
  const lowBand = typeof cfg.lowBand === 'number' ? cfg.lowBand : 0.2;

  const pt = p.type;
  const ps = p.separation;
  const pm = p.metadata;

  if (pt === undefined || ps === undefined || pm === undefined) {
    return {
      typeOk: pt !== undefined ? pt >= threshold : false,
      separationOk: ps !== undefined ? ps >= threshold : false,
      metadataOk: pm !== undefined ? pm >= threshold : false,
      verdict: 'unverified',
      note:
        pt === undefined && ps === undefined && pm === undefined
          ? 'No verdict was returned for this question.'
          : 'Some axes returned no verdict — treated as unverified (fail-safe).',
      ...meta,
    };
  }

  const typeOk = pt >= threshold;
  const separationOk = ps >= threshold;
  const metadataOk = pm >= threshold;

  if (typeOk && separationOk && metadataOk) {
    return { typeOk, separationOk, metadataOk, verdict: 'accepted', ...meta };
  }

  const badAxes: string[] = [];
  if (!typeOk) badAxes.push(`type (p=${pt.toFixed(2)})`);
  if (!separationOk) badAxes.push(`separation (p=${ps.toFixed(2)})`);
  if (!metadataOk) badAxes.push(`metadata (p=${pm.toFixed(2)})`);
  const uncertain = [pt, ps, pm].some((v) => v > lowBand && v < threshold);

  return {
    typeOk,
    separationOk,
    metadataOk,
    verdict: 'flagged',
    note: `${badAxes.join(', ')}${uncertain ? ' — judge was uncertain, not outright wrong' : ''}`,
    ...meta,
  };
}

function clamp01(n: unknown): number | undefined {
  const v = typeof n === 'number' ? n : parseFloat(String(n));
  return Number.isFinite(v) && v >= 0 && v <= 1 ? v : undefined;
}

// ---------- main entry ----------

export async function verifyParse(
  doc: ExamDocument,
  cfg: JevConfig,
  providerConfig: any,
  opts: {
    forceIds?: Set<string>;
    onProgress?: (note: string) => void;
    attribution?: AttributionContext;
    /** Printed-key mode: verify axes only — the a: answer Choice axis is
     *  omitted (answers already exist with official provenance). */
    skipAnswerAxis?: boolean;
  } = {},
): Promise<VerifyParseResult> {
  const warnings: string[] = [];
  const emptyReceipt: ParseVerifyReceipt = {
    ranAt: new Date().toISOString(),
    backend: cfg.enabled ? 'jev' : 'llm-fallback',
    model: cfg.model || 'unknown',
    questionsChecked: 0,
    cacheHits: 0,
    calls: 0,
    accepted: 0,
    flagged: 0,
    unverified: 0,
    promptTokens: 0,
    completionTokens: 0,
    totalTokens: 0,
    sourceChars: 0,
  };

  try {
    const build = buildVerificationSheet(doc, { skipAnswerAxis: opts.skipAnswerAxis });
    warnings.push(...build.warnings);
    if (build.questionCount === 0) {
      return {
        ok: true,
        verdicts: new Map(),
        answers: new Map(),
        attributions: new Map(),
        receipt: { ...emptyReceipt, sourceChars: build.source.length },
        warnings: ['No questions to verify.'],
      };
    }
    if (build.sourceReconstructed) {
      warnings.push('No parse trace kept for this document — the raw source was reconstructed from the AST.');
    }

    // ---- 1. Fingerprint + cache lookup (never re-verify an unchanged question) ----
    const flat: { item: SheetQuestion; sec: SheetSection }[] = [];
    const keyOf = new Map<string, string>();
    for (const sec of build.sheet.sections) {
      for (const item of sec.questions) {
        flat.push({ item, sec });
        keyOf.set(item.id, questionVerifyKey(item, sec, build.header));
      }
    }

    // ---- Two-phase Jev check (image pipeline contract): questions that depend
    // on an image WITHOUT an alt are not text-complete yet. Jev is text-only,
    // so judging them now would waste a call on an incomplete question. They
    // are SKIPPED by this pass ("unchecked / awaiting image alt", unverified,
    // never cached); once vision alts are attached, pass 2 re-verifies exactly
    // those ids — the content fingerprint changed, so nothing is sent twice.
    const pendingIds = new Set(imagePendingQuestionIds(doc));
    let pendingSkipped = 0;
    if (pendingIds.size > 0) {
      warnings.push(
        `${pendingIds.size} image-dependent question(s) were NOT sent to the judge — unchecked, awaiting image alt. ` +
          `They re-verify automatically once alts are generated in the Images review panel.`,
      );
    }

    const cachedMap = await kvGetMany<ParseVerdict>([...new Set([...keyOf.values()])]).catch(() => new Map<string, ParseVerdict>());
    const answers = new Map<string, R1AnswerPick>();
    const attributions = new Map<string, LessonAttribution>();
    const answerKeyOf = new Map<string, string>();
    const attrKeyOf = new Map<string, string>();
    for (const [qid, key] of keyOf) {
      answerKeyOf.set(qid, `${key}:a`);
      if (opts.attribution) attrKeyOf.set(qid, `${key}:attr:${opts.attribution.gradeKey}:${DIGEST_VERSION}`);
    }
    const cachedAnswerMap = await kvGetMany<R1AnswerPick>([...answerKeyOf.values()]).catch(() => new Map<string, R1AnswerPick>());
    const cachedAttrMap = opts.attribution
      ? await kvGetMany<LessonAttribution>([...attrKeyOf.values()]).catch(() => new Map<string, LessonAttribution>())
      : new Map<string, LessonAttribution>();
    const verdicts = new Map<string, ParseVerdict>();
    const fresh: { item: SheetQuestion; sec: SheetSection }[] = [];
    let cacheHits = 0;
    let cachedAnswerHits = 0;

    for (const entry of flat) {
      if (pendingIds.has(entry.item.id)) {
        // Phase-1 skip: incomplete question, judged by NOBODY (not cached —
        // an unverified verdict must never poison the cache).
        verdicts.set(entry.item.id, {
          typeOk: false,
          separationOk: false,
          metadataOk: false,
          verdict: 'unverified',
          note: 'unchecked / awaiting image alt',
          checkedAt: new Date().toISOString(),
          model: 'skipped',
          backend: cfg.enabled ? 'jev' : 'llm-fallback',
        });
        pendingSkipped++;
        continue;
      }
      const key = keyOf.get(entry.item.id)!;
      const hit = opts.forceIds?.has(entry.item.id) ? undefined : cachedMap.get(key);
      if (hit && hit.fingerprint === key) {
        verdicts.set(entry.item.id, { ...hit, cached: true });
        cacheHits++;
      } else {
        fresh.push(entry);
      }
      // Cached `a:` picks ride with cached verdicts (same content fingerprint).
      if (entry.item.candidates && !opts.forceIds?.has(entry.item.id)) {
        const aHit = cachedAnswerMap.get(answerKeyOf.get(entry.item.id)!);
        if (aHit && aHit.value) {
          answers.set(entry.item.id, aHit);
          cachedAnswerHits++;
        }
      }
      // Cached attributions ride the same way (digestVersion in the key).
      if (opts.attribution && !opts.forceIds?.has(entry.item.id)) {
        const attrHit = cachedAttrMap.get(attrKeyOf.get(entry.item.id)!);
        if (attrHit && (attrHit.lesson1 || attrHit.inBook || attrHit.cognitive)) {
          attributions.set(entry.item.id, attrHit);
        }
      }
    }

    const nativeEnabled = cfg.enabled && !!cfg.baseUrl && !!cfg.apiKey;
    if (fresh.length > 0 && !nativeEnabled && !providerConfig) {
      return {
        ok: false,
        error: 'No verification backend available: enable Jev in Settings or configure the fallback AI provider.',
        verdicts,
        answers,
        attributions,
        receipt: { ...emptyReceipt, questionsChecked: verdicts.size, cacheHits, imgPending: pendingSkipped, sourceChars: build.source.length },
        warnings,
      };
    }

    const receipt: ParseVerifyReceipt = {
      ...emptyReceipt,
      cacheHits,
      questionsChecked: verdicts.size,
      imgPending: pendingSkipped,
      sourceChars: build.source.length,
    };

    // ---- 2. ONE call for the whole fresh sheet (explicit chunking only if needed) ----
    const state = {
      exam: { course: doc.header.courseName, grade: doc.header.grade || doc.header.gradeAndMajor, term: doc.header.term },
      sheet: build.sheet,
      source: build.source,
    };
    const chunks: { item: SheetQuestion; sec: SheetSection }[][] = [];
    for (let i = 0; i < fresh.length; i += MAX_QUESTIONS_PER_CALL) {
      chunks.push(fresh.slice(i, i + MAX_QUESTIONS_PER_CALL));
    }
    if (chunks.length > 1) {
      warnings.push(
        `Sheet is too large for a single judge call (${fresh.length} fresh questions) — split into ${chunks.length} calls.`,
      );
    }

    const targets: VerifyTargets = {
      headerCourse: doc.header.courseName,
      headerGrade: doc.header.grade || doc.header.gradeAndMajor,
    };

    for (let ci = 0; ci < chunks.length; ci++) {
      const chunk = chunks[ci];
      opts.onProgress?.(
        chunks.length === 1
          ? `Verifying ${chunk.length} question(s) in one judge call...`
          : `Verifying questions ${ci * MAX_QUESTIONS_PER_CALL + 1}–${(ci + 1) * MAX_QUESTIONS_PER_CALL} of ${fresh.length}...`,
      );

      const questions = buildVerifyQuestions(chunk, targets, opts.attribution);
      const payloadChars = JSON.stringify({ state, questions }).length;
      if (payloadChars > MAX_SOURCE_CHARS) {
        warnings.push(`Verification payload is very large (${payloadChars} chars); the provider may reject it.`);
      }

      try {
        const res = await fetch('/api/judge', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            state,
            questions,
            jevConfig: { enabled: cfg.enabled, baseUrl: cfg.baseUrl, apiKey: cfg.apiKey, model: cfg.model },
            providerConfig: nativeEnabled ? undefined : providerConfig,
          }),
        });

        if (!res.ok) {
          const err = await res.json().catch(() => ({}));
          warnings.push(
            `Verification call failed (HTTP ${res.status}): ${(err as any).error || res.statusText}. Questions left unverified.`,
          );
          continue;
        }

        const data = await res.json();
        receipt.backend = (data.backend === 'jev' ? 'jev' : 'llm-fallback') as 'jev' | 'llm-fallback';
        receipt.model = data.model || receipt.model;
        receipt.calls += 1;
        receipt.promptTokens += data.usage?.promptTokens || 0;
        receipt.completionTokens += data.usage?.completionTokens || 0;
        receipt.totalTokens += data.usage?.totalTokens || 0;
        if (Array.isArray(data.warnings)) warnings.push(...data.warnings);

        const answersRaw: Record<string, any> = data.answers || {};
        const now = new Date().toISOString();

        for (const { item } of chunk) {
          const verdict = assembleVerdict(
            {
              type: clamp01(answersRaw[`t:${item.id}`]?.p),
              separation: clamp01(answersRaw[`s:${item.id}`]?.p),
              metadata: clamp01(answersRaw[`m:${item.id}`]?.p),
            },
            cfg,
            { checkedAt: now, model: receipt.model, backend: receipt.backend, fingerprint: keyOf.get(item.id) },
          );
          verdicts.set(item.id, verdict);
          // Cache only COMPLETE verdicts: an 'unverified' verdict (the judge
          // omitted axes) must NOT poison the cache, or the question could
          // never become verified without a forced re-check.
          if (verdict.verdict !== 'unverified') {
            kvSet(keyOf.get(item.id)!, verdict).catch(() => undefined);
          }
          // M2: collect the `a:` Choice pick (bucket A). Only VALID keys count —
          // an off-criteria pick is dropped, never guessed into a candidate.
          if (item.candidates) {
            const raw = answersRaw[`a:${item.id}`];
            const pickKey = raw && typeof raw.choice === 'string' ? raw.choice.trim().toLowerCase() : '';
            const cand = pickKey ? Object.keys(item.candidates).find((k) => k.toLowerCase() === pickKey) : undefined;
            if (cand) {
              const pick: R1AnswerPick = {
                questionId: item.id,
                key: cand,
                value: item.candidates[cand],
                confidence: typeof raw.confidence === 'number' ? raw.confidence : undefined,
              };
              answers.set(item.id, pick);
              receipt.answersProduced = (receipt.answersProduced || 0) + 1;
              // Cache the pick under its own fingerprint-suffix key (only when
              // the parse verdict was cacheable — same poison rule as verdicts).
              if (verdict.verdict !== 'unverified') {
                kvSet(answerKeyOf.get(item.id)!, pick).catch(() => undefined);
              }
            }
          }
          // M3: collect the attribution signals (lesson span, in-book, cognitive)
          // and run the DETERMINISTIC keyword cross-check on the picked lesson.
          if (opts.attribution) {
            const pickOf = (qk: string, criteria: Record<string, string>): string | undefined => {
              const raw = answersRaw[`${qk}:${item.id}`];
              const c = raw && typeof raw.choice === 'string' ? raw.choice.trim().toLowerCase() : '';
              if (!c) return undefined;
              return Object.keys(criteria).find((k) => k.toLowerCase() === c);
            };
            const l1c = lessonCriteria(opts.attribution.gradeKey);
            const l2c = lessonCriteriaLight(opts.attribution.gradeKey);
            const b = pickOf('b', provenanceCriteria());
            const cog = pickOf('c', cognitiveCriteria());
            let lesson1 = l1c ? pickOf('l1', l1c) : undefined;
            if (lesson1 === 'none') lesson1 = undefined;
            let lesson2 = l2c ? pickOf('l2', l2c) : undefined;
            if (lesson2 === 'none') lesson2 = undefined;
            const attr: LessonAttribution = {
              lesson1,
              lesson2: lesson2 && lesson2 !== lesson1 ? lesson2 : undefined,
              inBook: b as LessonAttribution['inBook'],
              cognitive: cog as LessonAttribution['cognitive'],
              digestVersion: DIGEST_VERSION,
              attributedAt: now,
              model: receipt.model,
            };
            if (attr.lesson1 && l1c) {
              const hits = keywordSupport(
                [item.stem, item.options, item.parentContext?.text, item.imageCaption].filter(Boolean).join(' '),
                opts.attribution.gradeKey,
                attr.lesson1,
              );
              attr.supportFlag = hits === 0; // near-zero support -> human looks at it
            }
            if (attr.lesson1 || attr.inBook || attr.cognitive) {
              attributions.set(item.id, attr);
              if (verdict.verdict !== 'unverified' && attrKeyOf.get(item.id)) {
                kvSet(attrKeyOf.get(item.id)!, attr).catch(() => undefined);
              }
            }
          }
        }
      } catch (e: any) {
        warnings.push(`Verification call ${ci + 1} failed: ${e?.message || e}. Questions left unverified.`);
      }
    }

    opts.onProgress?.('Verification complete');

    // ---- 3. Tally + receipt ----
    let accepted = 0;
    let flagged = 0;
    let unverified = 0;
    for (const v of verdicts.values()) {
      if (v.verdict === 'accepted') accepted++;
      else if (v.verdict === 'flagged') flagged++;
      else unverified++;
    }
    receipt.accepted = accepted;
    receipt.flagged = flagged;
    receipt.unverified = unverified;
    receipt.questionsChecked = verdicts.size;
    receipt.answersFromCache = cachedAnswerHits;

    const ok = verdicts.size > 0 || answers.size > 0 || attributions.size > 0;
    if (!ok) {
      // Fail-safe contract: ok:false MUST carry an error — the caller gates on
      // `!result.ok` and must never treat a failed run as a success.
      return {
        ok: false,
        error: warnings[0] || 'No verdicts were produced for this sheet.',
        verdicts,
        answers,
        attributions,
        receipt,
        warnings,
      };
    }
    return { ok, verdicts, answers, attributions, receipt, warnings };
  } catch (e: any) {
    return {
      ok: false,
      error: e?.message || 'Unexpected failure during parse verification.',
      verdicts: new Map(),
      answers: new Map(),
      attributions: new Map(),
      receipt: null,
      warnings,
    };
  }
}

// ---------- immutable document application ----------

/** Stamp verdicts + receipt. Returns a NEW document; never mutates the parse. */
export function applyParseVerdicts(
  doc: ExamDocument,
  verdicts: Map<string, ParseVerdict>,
  receipt?: ParseVerifyReceipt | null,
): ExamDocument {
  const next: ExamDocument = {
    ...doc,
    sections: doc.sections.map((sec) => ({
      ...sec,
      questions: sec.questions.map((q) => {
        const v = verdicts.get(q.id);
        return v ? { ...q, parseVerdict: v } : q;
      }),
    })),
  };
  return receipt ? { ...next, parseVerifyReceipt: receipt } : next;
}

/**
 * Human validation-queue decision: accept the parse of one question as-is.
 * The consensus gate then treats it as agreed (human replaced the judge).
 */
export function acceptParseVerdictByHuman(doc: ExamDocument, questionId: string): ExamDocument {
  return {
    ...doc,
    sections: doc.sections.map((sec) => ({
      ...sec,
      questions: sec.questions.map((q) => {
        if (q.id !== questionId) return q;
        const base: ParseVerdict = q.parseVerdict || {
          typeOk: false,
          separationOk: false,
          metadataOk: false,
          verdict: 'flagged',
          note: 'No prior AI verdict.',
          checkedAt: new Date().toISOString(),
          model: 'human',
          backend: 'llm-fallback',
        };
        return {
          ...q,
          parseVerdict: { ...base, verdict: 'accepted', humanReviewed: true, note: undefined },
        };
      }),
    })),
  };
}

/**
 * Questions currently sitting in the validation queue: the consensus gate
 * could NOT auto-accept them. That is 'flagged' (JEV disagreed or was
 * uncertain on some axis) AND 'unverified' (JEV returned no verdict at all —
 * per the fail-safe rule, no consensus = no auto-accept = needs review).
 */
export function flaggedQuestions(doc: ExamDocument): { q: { id: string; displayNumber: string; stem: string; type: string; parseVerdict?: ParseVerdict }; sectionRowId: string }[] {
  const out: { q: { id: string; displayNumber: string; stem: string; type: string; parseVerdict?: ParseVerdict }; sectionRowId: string }[] = [];
  for (const sec of doc.sections) {
    for (const q of sec.questions) {
      const verdict = q.parseVerdict?.verdict;
      if ((verdict === 'flagged' || verdict === 'unverified') && !q.parseVerdict!.humanReviewed) {
        out.push({ q, sectionRowId: sec.rowId });
      }
    }
  }
  return out;
}
