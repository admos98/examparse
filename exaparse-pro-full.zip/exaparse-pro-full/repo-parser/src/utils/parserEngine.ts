import {
  ExamDocument,
  ExamHeader,
  ExamSection,
  QuestionItem,
  QuestionType,
  ParsingAnomaly,
  ExamOption,
  ParseTraceSummary,
  QuestionReceipt,
  EXAM_SCHEMA_VERSION,
} from '../types/exam';
import { normalizeOcrText } from './ocrPreprocessor';
import { getQuestionTypeInfo, inferQuestionTypeFromText } from './questionTypeMapper';
import { canonicalize, fnv1a32 } from './textCanonical';
import { classifyLines, segmentQuestionBlocks, summarizeRules, LineClassification, looksLikeOptionRow, QUESTION_SPACE_START } from './parserRules';
import { runInvariantChecks } from './invariants';

export interface ParseOptions {
  detectAnomalies?: boolean;
  normalizeNumbering?: boolean;
  linkClozePassages?: boolean;
  /** Disable the rule-table walk (testing the legacy path only). */
  disableRuleTable?: boolean;
}

/** Per-section trace context threaded into the question extractor. */
interface TraceCtx {
  lineOffset: number;
  classifications: LineClassification[];
  fallbackUsed: boolean;
}

/** Any blank run: ASCII dashes/dots/underscores or Unicode ellipsis. */
const BLANK_RUN = new RegExp('(----|(?:\\.\\s+){2,}\\.|\\.{3,}|_{3,}|…|(?:[\u2013\u2014-]\s+){3,}[\u2013\u2014-])');

/**
 * Deterministic AST Rule-Based Parser for Persian, Arabic, and English Exams.
 * Hardened for real-world scans, messy OCR output, and multi-format exam layouts.
 *
 * Bulletproofing contract (#5):
 *  - DETERMINISTIC: same input -> byte-identical document (ids are content
 *    hashes, never Date.now()). Re-parsing the same file replaces, not duplicates.
 *  - THROW-FREE: every internal failure degrades into an anomaly finding;
 *    the function always returns a well-formed ExamDocument.
 *  - EXPLAINABLE: every question carries a receipt (source lines + rules).
 */
export function parseExamRawText(
  rawText: string,
  filename: string = 'uploaded_exam.txt',
  options: ParseOptions = { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true },
  /** Layout-brain blocks (brainBridge). When present and non-empty they ARE
   *  the section split — geometry-evidenced boundaries replace the text
   *  splitters. Empty/undefined = today's behavior, byte-identical. */
  preSplit?: RawSectionBlock[],
): ExamDocument {
  try {
    return parseExamInner(rawText, filename, options, preSplit);
  } catch (e: any) {
    // Last-resort armor: the parse path must never take the app down.
    console.error('parseExamRawText: catastrophic failure, returning minimal document:', e);
    return {
      id: `exam-${fnv1a32(String(rawText || '').slice(0, 2000) + '|' + filename)}-recovered`,
      filename,
      filesize: `${((rawText || '').length / 1024).toFixed(1)} KB`,
      parsedAt: new Date().toISOString(),
      schemaVersion: EXAM_SCHEMA_VERSION,
      confidenceScore: 10,
      needsReview: true,
      header: {
        courseName: filename || 'زبان انگلیسی',
        durationMinutes: 80,
        examDate: '',
        schoolName: '',
        district: '',
        gradeAndMajor: '',
        pageCount: 1,
      },
      sections: [],
      totalQuestions: 0,
      totalMarks: 0,
      anomalies: [
        {
          id: 'anom-parse-catastrophic',
          severity: 'error',
          sectionRowId: 'General',
          title: 'Parser recovery mode',
          description: `The parser hit an unexpected internal error (${e?.message || e}) and returned a minimal document. Your file was NOT lost — try re-uploading or paste the raw text.`,
          suggestedFix: 'Re-upload the file, or use "Paste Raw Text" so the engine can see the content directly.',
          isResolved: false,
        },
      ],
    };
  }
}

function parseExamInner(
  rawText: string,
  filename: string,
  options: ParseOptions,
  preSplit?: RawSectionBlock[],
): ExamDocument {
  // 0. Canonical text layer (#2): unify glyph chaos BEFORE any regex runs.
  const canon = canonicalize(String(rawText || ''));

  // Pre-normalize OCR noise, glued characters, and letter/digit confusions.
  // + docx auto-numbering (numPr) artifact: list paragraphs extract with
  // synthesized "N- " prefixes on EVERY numbered paragraph — questions AND
  // mark cells ("6- 2"), section letters ("13- C"), instructions. When the
  // numbered lines form one consecutive 1..K chain (K >= 8) and at least one
  // carries a BARE letter/bare number (never a question), the chain is Word's
  // list rendering, not exam numbering: strip every prefix and renumber the
  // questions continuously afterwards (mock-05 collapsed to one section).
  let normText = normalizeOcrText(canon.text);
  let autoNumberedDoc = false;
  {
    const numLines: { n: number; rest: string }[] = [];
    for (const l of normText.split(/\r?\n/)) {
      const m = l.trim().match(/^(\d{1,3})-[ \t]+(\S.*)$/);
      if (m) numLines.push({ n: parseInt(m[1], 10), rest: m[2].trim() });
    }
    if (numLines.length >= 8 && numLines[0].n === 1) {
      const consecutive = numLines.every((x, i) => i === 0 || x.n === numLines[i - 1].n + 1);
      const hasArtifact = numLines.some((x) => /^(?:[A-J]|\d{1,2}(?:[.,\/]\d{1,2})?)$/.test(x.rest));
      if (consecutive && hasArtifact) {
        normText = normText
          .replace(/(?:^|\n)(\s*)\d{1,3}-[ \t]+/g, '\n$1')
          .replace(/^\d{1,3}-[ \t]+/, '');
        autoNumberedDoc = true;
      }
    }
  }
  const traceLines = normText.split(/\r?\n/);
  const traceCtx: TraceCtx = {
    lineOffset: 0,
    classifications: [],
    fallbackUsed: false,
  };

  // 1. Extract Header (restricted strictly to the top boundary of document)
  const { header, missing: missingHeaderFields } = extractExamHeader(normText);

  // 2. Break down into Sections based on Row identifiers (A), A., (A), Persian الف), or banners
  // Marks-table genre first (نمره/بارم | سوالات | ردیف band): sections are
  // TABLE ROWS — a standalone number opens a row (the بارم) and either a bare
  // letter or the next row number closes it. This covers numeric ردیف papers,
  // letter-labeled marks tables, and hybrids (letters with unlabeled rows).
  // When the band is absent (plain lettered paper) or the machine's blocks
  // fail validation, the lettered splitter takes over.
  const keyCut = findKeySheetBoundary(normText);
  const scanText = keyCut >= 0 ? normText.slice(0, keyCut) : normText;
  let splitterUsed = '';
  const pick = (name: string, r: RawSectionBlock[] | null) => {
    if (r && !splitterUsed) {
      splitterUsed = name;
      if (process.env.PARSE_DEBUG) console.error('[splitter]', name, r.length, r.map((b) => `${b.rowId}:${b.mark}`).join(' '));
    }
    return r;
  };
  // Layout brain (geometry-evidenced boundaries) takes PRECEDENCE when it
  // confirmed at least one section: re-locate each block inside the canonical
  // text so trace offsets stay meaningful, then let the per-section machinery
  // do what it always does. Blocks whose receipt is unconfirmed raise
  // uncertainty anomalies instead of silently pretending confidence.
  let brainBlocks: RawSectionBlock[] | undefined;
  if (preSplit && preSplit.length > 0) {
    // Canonical-slice parity (G5): the brain decides BOUNDARIES; the block
    // content is the exact canonical-text slice between a block's located
    // start and the next block's start. The engine then parses precisely
    // what the text splitters would have seen between the same boundaries —
    // whitespace, keyword lines, strip numbers included — so content-derived
    // typing (matching vs short_answer, category inference) can never drift
    // from the text path. Blocks that fail to locate keep their geometry
    // text (rare: normalization drift), and the key-sheet boundary caps the
    // tail slice.
    const located = preSplit.map((b) => {
      let idx = -1;
      // The probe must live in the SAME normalized space as normText: the
      // engine canonicalizes whitespace/glyphs, so raw geometry text
      // ("A)  Fill") never matches canonically ("A) Fill") — run the probe
      // through the identical pipeline before indexOf.
      const probeRaw = b.text.trim().slice(0, 60);
      const probe = normalizeOcrText(canonicalize(probeRaw).text).trim();
      if (probe) idx = normText.indexOf(probe);
      if (idx < 0 && probe.length > 20) idx = normText.indexOf(probe.slice(0, 20));
      return { ...b, startIndex: idx >= 0 ? idx : Math.max(0, b.startIndex || 0), __idx: idx };
    });
    const ok = located
      .filter((b) => (b as { __idx: number }).__idx >= 0)
      .sort((a, b) => (a as { __idx: number }).__idx - (b as { __idx: number }).__idx);
    for (let i = 0; i < ok.length; i++) {
      const start = (ok[i] as { __idx: number }).__idx;
      const next =
        i + 1 < ok.length
          ? (ok[i + 1] as { __idx: number }).__idx
          : keyCut >= 0
          ? keyCut
          : normText.length;
      if (next > start) (ok[i] as { __slice?: string }).__slice = normText.slice(start, next);
    }
    brainBlocks = located.map((b) => {
      const slice = (b as { __slice?: string }).__slice;
      return slice ? { ...b, text: slice } : b;
    });
  }
  const rawSections = brainBlocks
    ? (pick('brain', brainBlocks) as RawSectionBlock[])
    : pick('kanoon', splitKanoonRowSections(scanText)) ??
    pick('radif', splitRadifNumberedSections(scanText)) ??
    pick('marks-table', splitMarksTableSections(scanText)) ??
    pick('rule-ruled', splitRuleRuledSections(scanText)) ??
    pick('bare-marker', splitBareMarkerSections(scanText)) ??
    pick('instr-blocks', splitInstructionBlocks(scanText)) ??
    (() => { if (process.env.PARSE_DEBUG) console.error('[splitter] generic'); return splitIntoRawSections(scanText); })();

  // Duplicate-print demotion (R2): some PDFs re-print earlier pages at the
  // tail (p8zq62 repeats page 1's sections A..C after the real final section).
  // A strict suffix of blocks whose first-question stems cyclically repeat
  // the document's opening stems is a re-print, not new sections — demote it.
  if (rawSections.length >= 6) {
    const stemOf = (b: RawSectionBlock): string => {
      const m = (b.text || '').match(/^\s*\d{1,3}\s*[.)-]\s*(\S.{10,})/m);
      return m ? m[1].replace(/\s+/g, ' ').trim().slice(0, 60) : '';
    };
    const stems = rawSections.map(stemOf);
    for (let i = 2; i < rawSections.length - 1; i++) {
      let matched = 0;
      for (let k = 0; i + k < rawSections.length && k < stems.length; k++) {
        const a = stems[i + k];
        const b = stems[k];
        if (a && b && a === b) matched++;
        else break;
      }
      if (matched >= 2 && i + matched >= rawSections.length) {
        if (process.env.PARSE_DEBUG) console.error('[splitter] duplicate tail demoted:', rawSections.length - i, 'blocks');
        rawSections.length = i;
        break;
      }
    }
  }

  // Printed skill-label oracle (R3): "Vocabulary"/"Grammar (3 points)" lines
  // stamp the block they open; a trailing label hands forward to the next
  // block. Runs over text-splitter AND brain blocks alike — the sheet's own
  // printed label outranks every derived category.
  stampPrintedSkillLabels(rawSections);

  // 3. Parse each section with specialized handlers
  const sections: ExamSection[] = [];
  const anomalies: ParsingAnomaly[] = [];
  let globalExpectedNumber = 1;

  for (const rawSec of rawSections) {
    // Global line offset of this section (aligns with traceLines indices)
    traceCtx.lineOffset =
      rawSec.startIndex > 0 ? normText.slice(0, rawSec.startIndex + 1).split('\n').length - 1 : 0;
    const parsedSec = parseSectionBlock(rawSec, globalExpectedNumber, anomalies, options, traceCtx);
    sections.push(parsedSec);
    globalExpectedNumber += parsedSec.questions.length;
  }

  // numPr artifact docs: the printed list numbers were Word's rendering, so
  // the questions are renumbered continuously 1..N in document order.
  if (autoNumberedDoc) {
    let seq = 1;
    for (const sec of sections) {
      for (const q of sec.questions) {
        q.number = seq;
        q.displayNumber = String(seq);
        seq++;
      }
    }
  }

  // 3a. Layout-brain uncertainty: an unconfirmed receipt on any brain block
  // means the geometry evidence did NOT fully agree — surface it as a finding
  // instead of silently pretending the separation is solid (user charter:
  // flag uncertainty perfectly). An UNCONFIRMED run that produced ZERO
  // questions is furniture or unstructurable material (exam-header zone,
  // stamp lines) — it is dropped from the section list (its text already fed
  // the header extractor) instead of corrupting section identity with an
  // empty phantom section.
  if (splitterUsed === 'brain' && brainBlocks) {
    const keptSections: ExamSection[] = [];
    const junkStem = (s: string) => !/[A-Za-z\u0600-\u06FF]{3}/.test(s || '') || /^www[.\-]/i.test((s || '').trim());
    sections.forEach((sec, i) => {
      const blk = rawSections[i];
      if (
        blk?.brain &&
        !blk.brain.confirmed &&
        (sec.questions.length === 0 || sec.questions.every((q) => junkStem(q.stem)))
      ) {
        anomalies.push({
          id: `anom-brain-unstructured-${fnv1a32(blk.text.slice(0, 80))}`,
          severity: 'warning',
          sectionRowId: blk.rowId,
          title: 'Unstructured run not turned into a section (layout)',
          description: `A region outside the confirmed layout structure produced no questions ("${blk.text.replace(/\s+/g, ' ').trim().slice(0, 60)}"). It was left out of the section list rather than inventing an empty section.`,
          suggestedFix:
            'If this region should contain questions, review the section boundaries in the editor.',
          isResolved: false,
        });
        return;
      }
      keptSections.push(sec);
    });
    if (keptSections.length !== sections.length) {
      sections.length = 0;
      sections.push(...keptSections);
    }
    for (const b of brainBlocks) {
      if (b.brain && !b.brain.confirmed) {
        anomalies.push({
          id: `anom-brain-uncertain-${b.rowId}-${fnv1a32(b.text.slice(0, 80))}`,
          severity: 'warning',
          sectionRowId: b.rowId,
          title: 'Uncertain section boundary (layout)',
          description: `The layout brain separated this section with ${(b.brain.confidence * 100).toFixed(0)}% confidence (boundary: ${b.brain.boundaryKind ?? 'n/a'}). ${b.brain.evidenceNotes.slice(0, 2).join(' ')}`,
          suggestedFix:
            'Review the section boundary in the editor — the physical signals (rules/tables/font sizes) did not fully agree here.',
          isResolved: false,
        });
      }
    }
  }

  // 3b. Honest header gaps: every field the header never stated is reported
  // as a warning anomaly instead of being silently filled with invented data.
  for (const field of missingHeaderFields) {
    anomalies.push({
      id: `anom-header-missing-${field}`,
      severity: 'warning',
      sectionRowId: 'General',
      title: `Header field not found: ${field}`,
      description: `The exam header did not clearly state "${field}". The field was left empty instead of being auto-filled with a guess.`,
      suggestedFix: 'Fill it in manually in the header editor, or re-upload a sharper scan where the top header block is readable.',
      isResolved: false,
    });
  }

  // 4. Post-parse validation and auto-repair pass
  const validationFlags: string[] = [];
  postParseAutoRepair(sections, anomalies, validationFlags);

  // Calculate totals
  const totalQuestions = sections.reduce((sum, s) => sum + s.questions.length, 0);
  const totalMarks = Math.round(sections.reduce((sum, s) => sum + s.markTotal, 0) * 100) / 100;

  // 4b. Structural invariants (#9): the parse path audits ITSELF. Every
  // violation is a finding with a suggested fix; error-level violations force
  // needsReview so a mis-parse can never masquerade as a clean parse.
  const draftDoc: ExamDocument = {
    header,
    sections,
    totalQuestions,
    totalMarks,
    anomalies,
  } as unknown as ExamDocument;
  let invariantsReport: ReturnType<typeof runInvariantChecks> | undefined;
  try {
    invariantsReport = runInvariantChecks(draftDoc);
    for (const v of invariantsReport.violations) {
      if (!v.isFixed) validationFlags.push(`${v.rule}: ${v.message}`);
    }
  } catch (invErr) {
    console.warn('invariant checks failed (non-fatal):', invErr);
  }

  // 5. Calculate realistic confidence score reflecting genuine extraction quality
  const errorViolations = invariantsReport?.violations.filter((v) => v.severity === 'error' && !v.isFixed).length || 0;
  const confidenceScore = calculateRealisticConfidenceScore(sections, header, anomalies) - errorViolations * 4;
  const needsReview =
    confidenceScore < 85 ||
    errorViolations > 0 ||
    anomalies.some((a) => a.severity === 'error' && !a.isResolved);

  const parseTrace: ParseTraceSummary = {
    lines: traceLines,
    rules: summarizeRules(traceCtx.classifications),
    fallbackUsed: traceCtx.fallbackUsed,
  };

  return {
    // Deterministic content hash id (#5): same file -> same id -> replace on re-parse.
    id: `exam-${fnv1a32(normText + '|' + filename)}`,
    filename,
    filesize: `${(normText.length / 1024).toFixed(1)} KB`,
    parsedAt: new Date().toISOString(),
    schemaVersion: EXAM_SCHEMA_VERSION,
    confidenceScore,
    needsReview,
    validationFlags: validationFlags.length ? validationFlags : undefined,
    header,
    sections,
    totalQuestions,
    totalMarks,
    anomalies,
    invariants: invariantsReport,
    parseTrace,
  };
}

/**
 * Header boundary lookahead labels: prevents fields on the same line from swallowing adjacent fields.
 * Explicitly guards against "دبیرستان" (high school) being treated as "دبیر" (teacher).
 */
const HEADER_BOUNDARY =
  '(?=\\s*(?:نام\\s*درس|درس|مدت\\s*آزمون|مدت|تاریخ\\s*آزمون|تاریخ|نام\\s*دبیر\\s*[:：]|(?:\\bدبیر\\b(?!\\s*ستان)\\s*[:：])|نام\\s*مدرسه|مدرسه|دبیرستان|هنرستان|آموزشگاه|اداره\\s*کل|اداره\\s*آموزش\\s*و\\s*پرورش|اداره|مقطع\\s*و\\s*رشته|مقطع|رشته|پایه|تعداد\\s*صفحه|صفحه|نوبت|شعبه|سال\\s*تحصیلی|Subject|Course|Duration|Time|Date|Teacher\\s*[:：]|School|District|Grade|Pages)|\\r?\\n|$)';

function extractHeaderField(text: string, labelRegex: RegExp): string | null {
  const nfkcText = text.normalize('NFKC');
  const fullPattern = new RegExp(labelRegex.source + `\\s*[:：]?\\s*([^\\n\\r]+?)` + HEADER_BOUNDARY, 'i');
  const match = nfkcText.match(fullPattern);
  if (match && match[1]) {
    const clean = match[1].trim().replace(/^[:：\-]\s*/, '').trim();
    // Discard captured text if it looks like an unscramble sentence or punctuation noise.
    // Dates are the exception: "31 / 02 / 1402" carries slashes by design.
    const isDateValue = /^\s*\d{1,4}\s*\/\s*\d{1,2}\s*\/\s*\d{1,4}\s*$/.test(clean)
      || (/^[\d\s\/]+$/.test(clean) && (clean.match(/\//g) || []).length === 2);
    if ((clean.includes('/') && !isDateValue) || clean.startsWith('.') || clean.length > 60) {
      return null;
    }
    return clean || null;
  }
  return null;
}

/**
 * Header duration normalization (#bidi-duration).
 *
 * Persian/Arabic header rows are RTL, and PDF/DOCX extractors walk them in
 * VISUAL order, so multi-digit runs come out REVERSED: the printed
 * "مدت آزمون: ۶۰ دقیقه / 60 minutes" surfaces as "06". A zero-led multi-digit
 * run is that fingerprint — Persian/Arabic durations are never typeset with a
 * leading zero — so the run is read back in logical order before parsing.
 * Genuine values ("60", "90", "45", "۱۲۰") carry no leading zero and pass
 * through untouched; both Persian (۰-۹) and Arabic-Indic (٠-٩) digits are
 * normalized first.
 */
export function parseDurationValue(raw: string): number {
  const digits = raw
    .replace(/[\u06F0-\u06F9\u0660-\u0669]/g, (d) => {
      const c = d.charCodeAt(0);
      return String(c <= 0x0669 ? c - 0x0660 : c - 0x06f0);
    })
    .replace(/\D/g, '');
  if (!digits) return 0;
  const candidates: string[] = [digits];
  if (/^0\d+$/.test(digits)) candidates.unshift(digits.split('').reverse().join(''));
  for (const c of candidates) {
    const n = parseInt(c, 10);
    if (Number.isFinite(n) && n > 0 && n < 300) return n;
  }
  return 0;
}

/** Pick the digit run nearest the دقیقه/minutes marker (then the label). */
export function parseDurationFromRtlLine(line: string): number {
  // NFKC first: PDF glyph encodings surface دقیقه/مدت as presentation forms
  // (دﻗﯿﻘﻪ) that the label regexes could never see (#qu2 real-exam class).
  const clean = line.normalize('NFKC').replace(/[\u202A-\u202E\u2066-\u2069\u200E\u200F]/g, ' ');
  const runs = [...clean.matchAll(/\d+|[\u06F0-\u06F9\u0660-\u0669]+/g)];
  if (runs.length === 0) return 0;
  const minuteAt = clean.search(/د\s*ق\s*ی\s*ق\s*ه|minutes?/i);
  const labelAt = clean.search(/م\s*د\s*ت\s*آزمون|م\s*د\s*ت\s*پاسخگویی|زمان\s*آزمون|(?:^|[^\u0600-\u06FF])م\s*د\s*ت|Duration/i);
  const centerOf = (m: RegExpMatchArray) => (m.index ?? 0) + m[0].length / 2;
  let best: { m: RegExpMatchArray; dist: number } | null = null;
  for (const m of runs) {
    const c = centerOf(m);
    const dist = minuteAt >= 0 ? Math.abs(c - minuteAt) : labelAt >= 0 ? Math.abs(c - labelAt) : 0;
    if (!best || dist < best.dist) best = { m, dist };
  }
  return best ? parseDurationValue(best.m[0]) : 0;
}

/**
 * Extracts exam header metadata restricted ONLY to the top header lines (before section A or question 1).
 * Never scans question stems to prevent questions mentioning "teacher" from polluting the header.
 */
function extractExamHeader(text: string): { header: ExamHeader; missing: string[] } {
  // Isolate header lines before first section or question
  const lines = text.split(/\r?\n/);
  const headerLines: string[] = [];
  for (const line of lines) {
    if (
      /^\s*(?:[|_\-~*#•]?\s*[A-Z][\.\)\-–—:]|[|_\-~*#•]?\s*\([A-Z]\)|\d+[\.\)]|Part\s+[A-Z\d]|بخش\s+|الف\s*[\)\.])/i.test(
        line,
      ) &&
      headerLines.length >= 2
    ) {
      break;
    }
    headerLines.push(line);
    // Iranian docx headers duplicate every field (two-column table) — the
    // school/district lines can sit past line 15, so the window is wider.
    if (headerLines.length > 30) break;
  }

  const headerSnippet = headerLines.join('\n');

  // NOTE: these are regex LITERALS — a single backslash (\s) means whitespace.
  // A previous version had double-escaped (\\s) literals here, which matched a
  // literal "\s" character sequence, so EVERY whitespace-containing label
  // (مدت آزمون، تاریخ آزمون، نام مدرسه…) silently never matched and the code
  // fell through to fabricated default values.
  const courseMatch = extractHeaderField(headerSnippet, /(?:نام\s*درس|درس(?=[\s:：])|نام\s*آزمون|Subject|Course)/);
  const durationMatch = extractHeaderField(headerSnippet, /(?:مدت\s*آزمون|مدت\s*پاسخگویی|زمان\s*آزمون|وقت\s*امتحان|مدت|Duration|Time)/);
  const dateMatch = extractHeaderField(headerSnippet, /(?:تار\s*ی\s*خ\s*آزمون|تاریخ\s*آزمون|تاریخ|Date)/);
  const schoolMatch = extractHeaderField(headerSnippet, /(?:نام\s*مدرسه|نام\s*آموزشگاه|دبیرستان|دبستان|هنرستان|مدرسه|School)/);
  const districtMatch = extractHeaderField(headerSnippet, /(?:اداره\s*کل\s*آموزش\s*و\s*پرورش|اداره\s*آموزش\s*و\s*پرورش|اداره|مدیریت\s*آموزش\s*و\s*پرورش|District)/);
  const gradeMatch = extractHeaderField(headerSnippet, /(?:مقطع\s*و\s*رشته|مقطع|پایه\s*و\s*رشته|رشته|پایه|Grade)/);
  // Term: a colon-labeled field ALWAYS wins over a bare mention, so a title
  // like "Mid-Term Exam" earlier in the header can't shadow the real
  // "Term: …" line. The lookbehind refuses to start matching INSIDE
  // "Mid-Term" (the hyphen is a non-word char, so \b alone still fires
  // there — grade8 used to read term:"Exam" straight off the title). A
  // bare-mention capture that is just the exam word is a title fragment,
  // not a term — dropped (honest default: missing stays missing).
  const termMatchRaw =
    extractHeaderField(headerSnippet, /(?<![A-Za-z-])(?:نوبت|Term)\s*[:：]/) ||
    extractHeaderField(headerSnippet, /(?<![A-Za-z-])(?:نوبت|Term)\b/);
  const termMatch =
    termMatchRaw && !/^(?:exam|آزمون|امتحان)\b/i.test(termMatchRaw) ? termMatchRaw : null;
  // Strictly require colon for teacher to avoid false matches
  const teacherMatch = extractHeaderField(headerSnippet, /(?:نام\s*دبیر\s*[:：]|Teacher\s*[:：]|طراح\s*سوال\s*[:：]|مصحح\s*[:：])/);
  const pageMatch = extractHeaderField(headerSnippet, /(?:تعداد\s*صفحه|تعداد\s*صفحات|صفحه|Pages)/);

  // If title was "English Quiz - Grade 7". The fallback scans ONLY the tight
  // top band: with the wide window, prose lines like "English books." would
  // otherwise masquerade as the course title.
  let courseName = courseMatch || '';
  if (!courseName) {
    // R7-A: kanoon prints the subject WITHOUT a درس label — the bidi row
    // "تاریخ امتحان  زبان خارجه یازدهم 1 / 3 / 1404" carries the subject
    // mid-line. The strong probe requires the subject word; a bare "زبان"
    // (pkhn) counts only beside a درس label.
    const joinedHead = headerLines
      .slice(0, 15)
      .map((l) => l.trim())
      .join(' ');
    const strong = joinedHead.match(/(زبان\s*(?:خارجه|انگلیسی)(?:\s*(?:یازدهم|دوازدهم|دهم|نهم|هشتم|هفتم))?)/);
    if (strong) {
      courseName = strong[1].trim();
    } else {
      const drsLine = headerLines.slice(0, 15).find((l) => /درس/.test(l) && /زبان/.test(l));
      if (drsLine) {
        const bare = drsLine.match(/(زبان(?:\s*(?:یازدهم|دوازدهم|دهم|نهم|هشتم|هفتم))?)/);
        if (bare) courseName = bare[1].trim();
      }
    }
  }
  if (!courseName) {
    const titleLine = headerLines.slice(0, 15).find((l) => /quiz|exam|test|english|آزمون/i.test(l) && !l.includes(':'));
    if (titleLine) {
      courseName = titleLine.trim();
    }
  }
  // "آزمون زبان انگلیسی" / "امتحان هماهنگ زبان انگلیسی" — the exam-word prefix
  // is a label, not the subject. Strip it so courseName is the subject alone.
  courseName = courseName
    .replace(/^(?:آزمون|امتحان)\s+/g, '')
    .replace(/^(?:هماهنگ|نوبت\s*(?:اول|دوم|سوم))\s+/, '')
    .replace(/\s*(?:پایه\s*\S+|نوبت\s*(?:اول|دوم|سوم)|نوبت\s*\S+)\s*$/, '')
    // Printed grade markers — "زبان انگلیسی ) 3 (" (bidi of "(3)") and
    // "زبان انگلیسی (3)" — are the course LEVEL, not the subject name.
    .replace(/\s*[()（）]\s*\d{1,2}\s*[()（）][\s\S]*$/, '')
    .replace(/\s*[()（）][\s\S]*$/, '')
    // R4 header debris: the benediction printed beside the subject
    // ("زبان انگلیسی 3 باسمه تعالی") and the bidi tail of a scrambled
    // "درس:" label ("ی: زبان انگلیسی 2") are not part of the name.
    .replace(/\s*(?:با\s*سمه|باسمه)\s*تعالی\s*$/, '')
    .replace(/^ی\s*[:：]\s*/, '')
    .trim();

  // HONEST DEFAULTS (#fix-4): a value the header never states must stay
  // empty — fabricating plausible-looking data (a hardcoded date, a generic
  // school name) poisons the exam document and the AI refinement prompt.
  // Missing fields are reported by the caller and surfaced as anomalies.
  let durationMinutes = 0;
  if (durationMatch) {
    durationMinutes = parseDurationValue(durationMatch);
  }
  if (!durationMinutes) {
    // Bidi visual-order fallback: RTL header rows are often emitted with the
    // VALUE BEFORE the label ("دقیقه 06 مدت آزمون" for "مدت آزمون: 60 دقیقه"),
    // so the forward capture above comes back empty or label-less garbage.
    // Scan the duration label's own line for a digit run instead — the run
    // nearest the دقیقه/minutes marker wins (a date on the same line loses).
    const durLine = headerLines.find((l) =>
      /مدت\s*آزمون|مدت\s*پاسخگویی|زمان\s*آزمون|وقت\s*امتحان|(?:^|[^\u0600-\u06FF])مدت|Duration/i.test(l),
    );
    if (durLine) durationMinutes = parseDurationFromRtlLine(durLine);
  }

  let pageCount = 0;
  if (pageMatch) {
    const num = parseInt(pageMatch.replace(/\D/g, ''), 10);
    if (!isNaN(num) && num > 0 && num < 20) pageCount = num;
  }

  // Canonical Persian date form: "31 / 02 / 1402" (bidi-reordered day/month/year)
  // -> "1402/02/31". Persian exams print year/month/day; extractors emit the
  // day-first visual order, so reorder deterministically.
  function normalizePersianDate(v: string): string {
    // Kerned digits + bidi reordering scramble dates into "10 / 3 0 / 3 140".
    // Each slash-run carries digit GROUPS in reversed order: reverse the
    // groups per run ("3 140" -> "1403"), then day/month/year is restored.
    if (/[\d][\s\/]*[\s/]/.test(v) && (v.match(/\//g) || []).length === 2) {
      const runs = v.split('/').map((r) => r.trim().split(/\s+/).reverse().join(''));
      if (runs.length === 3 && runs.every((r) => /^\d{1,4}$/.test(r))) {
        v = runs.join('/');
      }
    }
    const m = v.match(/^(\d{1,2})\s*\/\s*(\d{1,2})\s*\/\s*(\d{4})$/);
    if (m) return `${m[3]}/${m[2].padStart(2, '0')}/${m[1].padStart(2, '0')}`;
    return v.replace(/\s+/g, '');
  }

  const gradeFallback = headerSnippet.match(/Grade\s*\d+/i)?.[0] || '';
  // School: the FULL line that carries the school noun (دبیرستان شهید مطهری —
  // the label regex used to consume "دبیرستان" and report only "شهید مطهری").
  const schoolLine = headerLines.find((l) => /دبیر\s*ستان|دبستان|هنرستان|آموزشگاه|مدرسه/i.test(l));
  // District: Iranian papers stack two اداره lines (استان + منطقه); keep both.
  const districtLines = headerLines
    .filter((l) => /اداره|آموزش\s*و\s*پرورش/i.test(l) && !/دبیرستان|دبستان|مدرسه/i.test(l))
    .map((l) => l.trim())
    // bidi repair: a line-initial orphan letter belongs to the final
    // word ("گ اداره … خار" -> "اداره … خارگ")
    .map((l) => l.replace(/^([\u0621-\u06FF])\s+((?:\S+\s*)*\S)$/, '$2$1'));
  const districtJoined = [...new Set(districtLines)].join(' - ');

  const header: ExamHeader = {
    courseName: courseName || 'زبان انگلیسی',
    teacherName: teacherMatch ? `نام دبیر: ${teacherMatch}` : undefined,
    durationMinutes,
    examDate: dateMatch ? normalizePersianDate(dateMatch) : '',
    schoolName: schoolLine
      ? ((schoolLine.split(/نام و نام خانوادگی|مدت آزمون|تاریخ آزمون/)[0].match(/(دبیرستان|دبستان|هنرستان|آموزشگاه|مدرسه).*$/) || [])[0] || schoolLine)
        .trim().replace(/دبیر\s*ستان/g, 'دبیرستان')
      : schoolMatch || '',
    district: districtJoined || districtMatch || '',
    gradeAndMajor: gradeMatch ? `مقطع و رشته: ${gradeMatch}` : gradeFallback,
    pageCount,
    grade: gradeMatch || undefined,
    term: termMatch || undefined,
  };

  const missing: string[] = [];
  if (!dateMatch) missing.push('examDate');
  if (!schoolMatch) missing.push('schoolName');
  if (!districtMatch) missing.push('district');
  if (!gradeMatch && !gradeFallback) missing.push('grade');
  return { header, missing };
}

export interface RawSectionBlock {
  rowId: string;
  category: 'Listening' | 'Vocabulary' | 'Grammar' | 'Writing' | 'Reading' | 'General';
  mark: number;
  text: string;
  headerLine: string;
  /** Char index of this section's start inside the full normalized text. */
  startIndex: number;
  /** True when `category` came from a PRINTED subject-label line ("17
   *  Grammar" radif-row opener) rather than instruction keywords — the
   *  sheet's own label outranks the genre remaps (#qu2 wave 3).
   */
  labelCategory?: boolean;
  /** Layout-brain receipt (brainBridge): cross-checked geometry evidence for
   *  this boundary. Unconfirmed receipts surface uncertainty anomalies. */
  brain?: {
    confirmed: boolean;
    confidence: number;
    boundaryKind?: string;
    subject?: string;
    evidenceNotes: string[];
  };
}

/**
 * Splits raw text into section blocks.
 * Supports:
 * - A), A., A -, (A), bare A
 * - Persian letters: الف), ب), ج), د), هـ)
 * - Part banners: Part 1, Part A, بخش اول, بخش ۱
 * - Tolerates leading punctuation / OCR noise e.g. "| B)"
 * - Distinguishes section headers from multiple-choice option letters (a) b) c) d))!
 */
function splitIntoRawSections(text: string): RawSectionBlock[] {
  // Mark-prefixed letter banners (R5, p4t7882699): kanoon column order prints
  // the FIRST TASK's mark cell in front of the section banner ("3 A.
  // Vocabulary", "4 B- Grammar") — the number hides the letter anchor from
  // sectionHeaderPattern, so the whole subject merged into the previous
  // section (48 questions swallowed). Strip the mark prefix from banner
  // lines up front; the mark itself is re-read by the mark extractors.
  text = text.replace(
    /(^|\n)\s*(\d{1,2})\s+([A-D])\s*([.\-–])\s*(?=(?:Listening|Vocabulary|Grammar|Reading|Writing)\b)/g,
    '$1$3$4 ',
  );
  // Regex identifying section headers at line starts:
  // Group 1: Latin letter e.g. A, B, C...
  // Group 2: Latin letter followed by SPACE + Persian text ("A تصویر مربوط…") —
  //   the bare letter+space form used by Persian task sheets with Latin row
  //   letters (qu2 corpus: 14040207, 14050319…). Lowercase allowed ("k متن…");
  //   the Persian lookahead keeps English prose ("A lot of…") out.
  // Group 3: Latin letter with punctuation A) B: C-
  // Group 4: Persian letter e.g. الف, ب, ج...
  // Group 5: Persian letter with punctuation
  // Group 6: Part banner e.g. Part 1, بخش اول
  // Group 7: Header line instruction/title text
  const sectionHeaderPattern =
    /(?:^|\n)\s*[|_\-~*#•]?\s*(?:(?:\(([A-Z])\)|([A-Za-z])\s+(?=[\u0600-\u06FF])|([A-Z])\s*[\)\.\-–—:])|(?:\(([الفبپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی]+)\)|([الفبپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی]+)\s*[\)\.\-–—:])|(?:(?:Part|Section|بخش|قسمت)\s*([A-Z\d]+|اول|دوم|سوم|چهارم|پنجم|ششم|I|II|III|IV|V)[\.\)\-–—:]*))\s*([^\n]*)/g;

  const rawMatches = Array.from(text.matchAll(sectionHeaderPattern));

  // Filter out spurious matches:
  // E.g., multiple choice option lines like "a)animal b)car" or "A) animal B) car"
  // Section headers have instruction verbs (Choose, Fill, Answer, Match, Read...) or trailing marks (2 marks)
  // or are alone on the header line without subsequent choices on the same line!
  // NOTE: no /i flag on the pattern — option markers are lowercase (a) b) c) d))
  // while section letters are uppercase (A) B) C) D)). The golden corpus caught
  // the old case-insensitive version scattering questions into phantom sections.
  const nonEmptyLines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  let validMatches: { index: number; rowId: string; headerLine: string; appendText?: string }[] = [];

  for (const m of rawMatches) {
    const rawLetter = (m[1] || m[2] || m[3] || m[4] || m[5] || m[6] || '').trim();
    const lineRest = (m[7] || '').trim();

    // A bare Persian match must be a ROW LETTER (single letter, or الف/هـ).
    // The letter class also matches ordinary Persian words, so any sentence
    // ending in punctuation ("… پر کند.") used to spawn a phantom section
    // named "کند" that swallowed the rest of the exam.
    if (
      /^[الفبپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی]+$/.test(rawLetter) &&
      !/^(?:الف|هـ|[بپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی])$/.test(rawLetter)
    ) {
      continue;
    }

    // Check if this line is actually an MCQ options line with multiple choices:
    // "a) cat b) dog c) car" AND the hyphen/dot worksheet form "A- Is B- Does C- Do".
    // Two or more option markers after the first letter = options row, NOT a header.
    const optionMarkerHits = (lineRest.match(/(?:^|\s)(?:[b-d]|ب|ج|د|ه)\s*[\)\.–—:]\s*\S/gi) || []).length;
    if (optionMarkerHits >= 2) {
      continue; // Skip: this is an option line, NOT a section header!
    }

    // A bare single word after the letter, where the NEXT line is another
    // option row (b)/c)/d)...) — that's a multiline options layout, not a
    // section header ("A) rise" followed by "b) rises").
    const lineStart = text[m.index] === '\n' ? (m.index || 0) + 1 : (m.index || 0);
    const lineText = text.slice(lineStart).split(/\r?\n/)[0] || '';
    const restWords = lineRest.replace(/\(\s*[\d\.]+\s*\)\s*$/, '').trim().split(/\s+/);
    const optionMarkerStart = (l: string) => /^[|_\-~*#•]?\s*(?:[A-Za-z]|الف|ب|ج|د)[\)\.\-–—]\s*\S/.test(l);
    const hasTrailingMark = /\(\s*[\d\.]+\s*\)\s*$/.test(lineRest);
    const prevNonEmpty = text.slice(0, m.index || 0).split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    const prevLine = prevNonEmpty[prevNonEmpty.length - 1] || '';

    if (/^[A-Za-z]$/.test(rawLetter) || /^(?:الف|ب|ج|د|هـ|ه|و)$/.test(rawLetter)) {
      // "A) rise" followed by "b) rises" — options layout.
      if (restWords.length <= 2 && !hasTrailingMark) {
        const lineIdx = nonEmptyLines.indexOf(lineText.trim());
        const nextLine = nonEmptyLines[lineIdx + 1] || '';
        if (optionMarkerStart(nextLine)) {
          continue; // options layout
        }
      }
      // Chain of option rows: previous line is an option marker and this
      // line carries no instruction keywords or marks ("ب) علی و حسن").
      if (
        optionMarkerStart(prevLine) &&
        !hasTrailingMark &&
        lineRest.length < 40 &&
        !/(choose|fill|read|match|write|answer|listen|complete|unscramble|گزینه|کلمات|جاهای|متن|بخوانید|انتخاب)/i.test(lineRest)
      ) {
        continue;
      }
    }

    // Row ID: the PRINTED letter is the identity. Persian-lettered papers
    // (الف ب پ ت ث ج چ ح) keep their Persian letter — the golden corpus has no
    // Persian-lettered anchors, and translating الف→A / ب→B silently produced
    // duplicate ids on mixed papers (mock-07). Ordinal banner words stay
    // Latin-numbered for Part-style banners.
    let rowId = rawLetter.toUpperCase();
    if (rawLetter === 'اول') rowId = 'A';
    else if (rawLetter === 'دوم') rowId = 'B';
    else if (rawLetter === 'سوم') rowId = 'C';

    validMatches.push({
      index: m.index || 0,
      rowId: rowId || 'A',
      headerLine: lineRest,
    });
  }

  // --- RTL row markers (#fix-4): authoritative anchors for RTL papers -------
  // When the text carries RTL row markers, tile section blocks from them and
  // drop start-of-line matches that live inside a tiled block (those are the
  // option-row / sentence-fragment phantoms). 'end' anchors (bare letter line
  // emitted after the content, pdf.js shape) terminate their block; 'start'
  // anchors (inline / solo marks+letter) open theirs.
  const rtlAnchors = collectRtlRowAnchors(text);
  if (process.env.PARSE_DEBUG) console.error('[rtl]', rtlAnchors.map((a) => `${a.rowId}:${a.mode}@${a.index}`).join(' '));
  const rtlMarks = new Map<number, number | undefined>();
  if (rtlAnchors.length >= 3) {
    // Head-anchored papers (the row letter printed at the very TOP, before any
    // content — "row mark / A / Audio 1 …") OPEN their blocks with the letter:
    // force start-tiling for the whole sheet, otherwise every block would hold
    // the PREVIOUS section's content.
    const allLines = text.split(/\r?\n/);
    let headBudget = 0;
    let seenLines = 0;
    for (const l of allLines) {
      if (!l.trim()) continue;
      headBudget += l.length + 1;
      if (++seenLines >= 3) break;
    }
    const headAnchored = rtlAnchors[0].index < headBudget; // strictly inside the head band
    const endCount = rtlAnchors.filter((a) => a.mode === 'end').length;
    let majorityEnd = !headAnchored && endCount >= rtlAnchors.length - endCount;
    if (majorityEnd) {
      // Letters-first probe: on a marks-table (end-anchored) sheet the region
      // BEFORE the first letter carries the first row's questions. When the
      // pre-letter region holds no numbered questions but the region after the
      // first letter does, the paper OPENS its rows with the letter — re-tile
      // from the letters (mock-11 header block used to swallow بارم کل: 20).
      // Inline numbered blanks ("( 1 )------" listening passages) count as
      // questions too — a passage-only pre-letter region is still a question
      // region (pc4i517871: its letters are END-anchored, the probe's blind
      // spot used to flip the tiling into start mode and shift every row).
      const qStart = (t: string) => /(?:^|\n)\s*\d{1,3}\s*[-.)]\s*\S/.test(t) || /\(\s*\d{1,3}\s*\)\s*[-—–_]/.test(t);
      const preFirst = text.slice(0, rtlAnchors[0].index);
      const postFirst = text.slice(rtlAnchors[0].index, rtlAnchors[1] ? rtlAnchors[1].index : text.length);
      if (!qStart(preFirst) && qStart(postFirst)) majorityEnd = false;
    }
    // BAND-AWARE TILING (R6-a): bidi column extraction emits consecutive row
    // letters as a bare band BEFORE their content (p265374941: A/B/C/D on four
    // adjacent lines, F–G and H–M the same). End-tiling starves every band
    // member (its block terminates at the letter with nothing inside) and
    // feeds the whole sheet to the next solo anchor (the phantom-E swallow).
    // When anchors cluster into bands — the next anchor starts within a couple
    // of characters, i.e. on the adjacent line — the letters OPEN content: the
    // band's content region (after its last member, up to the next out-of-band
    // anchor) is sub-split at task-instruction lines; segment i belongs to
    // band letter i, and a leading segment (before the first instruction)
    // continues the PREVIOUS tile (p265: G's "23. Active:/24. Passive:"
    // stems ride in front of the H–M band).
    const bandGap = 4;
    const inBand = new Array<boolean>(rtlAnchors.length).fill(false);
    for (let i = 0; i + 1 < rtlAnchors.length; i++) {
      if (rtlAnchors[i + 1].index - rtlAnchors[i].endIndex <= bandGap) {
        inBand[i] = true;
        inBand[i + 1] = true;
      }
    }
    const hasBands = inBand.some(Boolean);
    const tiled: { index: number; rowId: string; headerLine: string; mark?: number; appendText?: string }[] = [];
    if (hasBands) {
      const isTaskBanner = (l: string) =>
        /^\s*(?:Complete|Choose|Match|Make|Answer|Read|Fill|Write|Put|Use|Unscramble|Listen|Cloze|Reading|Vocabulary|Grammar|Listening|Speaking)\b/i.test(l.trim());
      let prev: (typeof tiled)[number] | null = null;
      let bi = 0;
      while (bi < rtlAnchors.length) {
        const a = rtlAnchors[bi];
        if (!inBand[bi]) {
          // solo anchor inside a banded sheet: still OPENS its block — the
          // content follows the letter (p265 E: q17-18 ride behind it)
          const next = rtlAnchors[bi + 1];
          const end = next ? next.index : text.length;
          const instr = firstInstructionLine(text, a.index, end);
          const tile = { index: a.index, rowId: a.rowId, headerLine: a.headerLine || instr.line, mark: a.mark ?? instr.mark };
          tiled.push(tile);
          prev = tile;
          bi++;
          continue;
        }
        let bj = bi + 1;
        while (bj < rtlAnchors.length && inBand[bj] && rtlAnchors[bj].index - rtlAnchors[bj - 1].endIndex <= bandGap) bj++;
        const last = rtlAnchors[bj - 1];
        const nextOut = rtlAnchors[bj];
        const regionStart = last.endIndex;
        const regionEnd = nextOut ? nextOut.index : text.length;
        const region = text.slice(regionStart, regionEnd);
        const offs: number[] = [];
        let scan = 0;
        for (const l of region.split(/\r?\n/)) {
          if (l.trim() && isTaskBanner(l)) offs.push(scan);
          scan += l.length + 1;
        }
        const firstCut = offs.length ? regionStart + offs[0] : regionEnd;
        if (prev && firstCut > regionStart) {
          const lead = text.slice(regionStart, firstCut).replace(/\s+$/, '');
          if (lead.trim()) prev.appendText = prev.appendText ? `${prev.appendText}\n${lead}` : lead;
        }
        for (let m = 0; m < bj - bi; m++) {
          const ida = rtlAnchors[bi + m];
          const segStart = m < offs.length ? regionStart + offs[m] : regionEnd;
          const segEnd = m + 1 < offs.length ? regionStart + offs[m + 1] : regionEnd;
          const instr = firstInstructionLine(text, segStart, segEnd);
          const tile = {
            index: segStart < regionEnd ? segStart : regionEnd,
            rowId: ida.rowId,
            headerLine: instr.line || ida.headerLine || '',
            mark: ida.mark ?? instr.mark,
          };
          tiled.push(tile);
          prev = tile;
        }
        bi = bj;
      }
    } else {
      let cursor = 0;
      for (let i = 0; i < rtlAnchors.length; i++) {
        const a = rtlAnchors[i];
        const next = rtlAnchors[i + 1];
        if (majorityEnd) {
          // block = (cursor … anchor line end]; the marker line terminates it
          const start = cursor;
          const end = a.endIndex;
          const instr = firstInstructionLine(text, start, end);
          tiled.push({ index: start, rowId: a.rowId, headerLine: instr.line, mark: a.mark ?? instr.mark });
          cursor = end;
        } else {
          // block = [anchor line start … next anchor start | text end)
          const start = a.index;
          const end = next ? next.index : text.length;
          const instr = firstInstructionLine(text, start, end);
          tiled.push({ index: start, rowId: a.rowId, headerLine: a.headerLine || instr.line, mark: a.mark ?? instr.mark });
          cursor = end;
        }
      }
    }
    if (process.env.PARSE_DEBUG) console.error('[tiled]', tiled.map((t2) => `${t2.rowId}@${t2.index}`).join(' '));
    validMatches = tiled.map(({ index, rowId, headerLine, appendText }) => ({ index, rowId, headerLine, appendText }));
    for (const t of tiled) if (t.mark !== undefined) rtlMarks.set(t.index, t.mark);
  }

  // Orphaned questions BEFORE the first lettered section (common in noisy
  // scans where the section header was mis-OCR'd): keep them in a synthetic
  // leading section instead of silently dropping them.
  if (validMatches.length > 0) {
    const firstIdx = validMatches[0].index || 0;
    if (firstIdx > 0) {
      const preText = text.slice(0, firstIdx);
      if (/(?:^|\n)\s*\d{1,3}\s*[\.\)]\s*\S/.test(preText) && validMatches[0].rowId !== 'A') {
        validMatches.unshift({ index: 0, rowId: 'A', headerLine: 'Pre-section questions' });
      }
    }
  }

  if (validMatches.length === 0) {
    return [
      {
        rowId: 'A',
        category: 'General',
        mark: 20,
        text,
        headerLine: 'General Section',
        startIndex: 0,
      },
    ];
  }

  const blocks: RawSectionBlock[] = [];
  // Roman part-header carry (#qu2 wave 5): Kanoon sheets print the subject
  // PART on one row's opener ("2 II. Vocabulary", "2 III. Grammar", "1 IV.
  // Writing", "3 V. Reading") — the rows that follow until the next part
  // banner belong to that part. Rows with no banner of their own inherit the
  // last seen part instead of falling to General / genre remaps (pc4i517871
  // G/H sat under III. Grammar, K/L under IV. Writing). A printed part
  // statement outranks heuristics — the label-pin principle, part-level.
  let lastRomanCat: 'Listening' | 'Vocabulary' | 'Grammar' | 'Writing' | 'Reading' | null = null;

  for (let i = 0; i < validMatches.length; i++) {
    const current = validMatches[i];
    const startIndex = current.index;
    const endIndex = i < validMatches.length - 1 ? validMatches[i + 1].index : text.length;
    const blockText = text.slice(startIndex, endIndex) + (current.appendText ? `\n${current.appendText}` : '');
    if (process.env.PARSE_DEBUG) console.error('[block]', current.rowId, JSON.stringify(blockText.slice(0, 60)));

    // Detect section category
    const romanHere = current.headerLine.match(/^\s*(?:[IVXivx]{1,5}|\d{1,2})\s*[.\)]\s*(Listening|Vocabulary|Grammar|Writing|Reading)\b/i);
    if (romanHere) {
      const c = romanHere[1];
      const cat = c.charAt(0).toUpperCase() + c.slice(1).toLowerCase();
      lastRomanCat = cat as 'Listening' | 'Vocabulary' | 'Grammar' | 'Writing' | 'Reading';
    }
    const category = !romanHere && lastRomanCat
      ? lastRomanCat
      : detectInitialCategory(current.headerLine, blockText);

    // Extract section mark: an RTL anchor's leading marks column wins
    // ("1.25  در هر سوال گزینه صحیح را انتخاب کنید.     B"), otherwise infer.
    const mark = rtlMarks.get(current.index) ?? extractSectionMark(current.headerLine, blockText);

    blocks.push({
      rowId: current.rowId,
      category,
      mark,
      text: blockText,
      headerLine: current.headerLine,
      startIndex: current.index,
    });
  }

  return blocks;
}

/**
 * Kanoon national-final genre (#qu2 second golden pass).
 * aee.medu.ir finals print a three-column table | ردیف | سؤالات | نمره | where
 * each TASK ROW opens with its printed row number followed by the row's task
 * label or Persian instruction ("1 Listening", "2 دانش‌آموز عزیز…", "5
 * Vocabulary"), and the row's بارم closes the row as a standalone number line
 * AFTER the questions (bidi decimals extract as "5 / 1" for 1.5). Rows are
 * strictly consecutive from 1; the printed number is the row identity (never
 * renumbered). Page breaks repeat the header band and put a page number right
 * after the ردیف banner — those numbers are mark-cell debris, never marks.
 * The printed answer key (راهنمای تصحیح) repeats the same row shape, so
 * scanning STOPS at the key banner. Returns null when the genre doesn't apply
 * so the marks-table / lettered splitters take over.
 */
function splitKanoonRowSections(text: string): RawSectionBlock[] | null {
  const lines = text.split(/\r?\n/);
  // Row-start line: "N Label/…" — NO dot/paren after the number (questions are
  // "N." / "N)" / "N -"), rest must be a category label or Persian text.
  // (#qu2 wave 4, p8214) An "N. Rest" / "N) Rest" form ALSO opens a row when
  // the rest is an IMPERATIVE instruction or a category label — question
  // content ("9 ) the airplane is one of the greatest …") never starts with
  // one, so the two shapes never collide.
  const IMPERATIVE_REST =
    /^(?:match|choose|fill|complete|unscramble|order|circle|read|answer|write|put|change|listen|look|one\s+odd|true|false)\b/i;
  const rowStart = (l: string): { n: number; rest: string } | null => {
    const t = l.trim();
    const m = t.match(/^(\d{1,2})\s+(?!\.?\s*$)(\S.*)$/);
    if (m) {
      if (/^[\.\):\-–—]/.test(m[2])) {
        // "N . Rest" — bidi spaces the dot off the number. One dot + space is
        // row furniture; anything dotlier is an ellipsis row, not a header.
        const rest = m[2].replace(/^[\.\)]\s+/, '');
        if (/^[\.\):\-–—]/.test(rest) || !IMPERATIVE_REST.test(rest)) return null;
        return { n: parseInt(m[1], 10), rest };
      }
      return { n: parseInt(m[1], 10), rest: m[2].trim() };
    }
    const m2 = t.match(/^(\d{1,2})\s*[.)]\s*(\S.*)$/);
    if (m2) {
      const rest = m2[2].trim();
      if (!IMPERATIVE_REST.test(rest)) return null;
      return { n: parseInt(m2[1], 10), rest };
    }
    return null;
  };
  const categorize = (rest: string): 'Listening' | 'Vocabulary' | 'Grammar' | 'Reading' | 'Writing' | '' => {
    if (/listen/i.test(rest)) return 'Listening';
    if (/vocab|ocabu/i.test(rest)) return 'Vocabulary';
    if (/gramm/i.test(rest)) return 'Grammar';
    if (/read/i.test(rest)) return 'Reading';
    if (/writ/i.test(rest)) return 'Writing';
    return '';
  };
  // The key region repeats the row shape; never scan past its banner.
  let keyLine = -1;
  // NFKC folds Arabic presentation forms (ﻧﻤﺮه → نمره) so the banners match
  // regardless of the PDF's glyph encoding.
  const nfkc = (l: string) => l.normalize('NFKC');
  for (let i = 0; i < lines.length; i++) {
    if (/راهنمای\s*تصحیح|ردیف\s*راهنما/.test(nfkc(lines[i]))) { keyLine = i; break; }
  }
  const scanEnd = keyLine >= 0 ? keyLine : lines.length;
  // Find a consecutive row-start ladder 1,2,3,… with at least 4 rungs.
  const rowLines: { line: number; n: number; rest: string }[] = [];
  for (let i = 0; i < scanEnd; i++) {
    const rs = rowStart(lines[i]);
    if (rs) rowLines.push({ line: i, n: rs.n, rest: rs.rest });
  }
  const ladder: { line: number; n: number; rest: string }[] = [];
  let expect = 1;
  for (const r of rowLines) {
    if (r.n === expect) { ladder.push(r); expect++; }
  }
  if (ladder.length < 4 || ladder[0].n !== 1) return null;
  // Kanoon rows are numbered 1..18 on the printed sheet.
  if (ladder.length > 20) return null;

  // Mark-cell debris: a standalone number within 3 lines after a repeated
  // ردیف/نمره banner (the page header zone) is the PAGE NUMBER, never a mark.
  const nearBanner = (idx: number): boolean => {
    for (let k = Math.max(0, idx - 3); k < idx; k++) {
      const n = nfkc(lines[k]);
      if (/ردیف/.test(n) && /نمره|بارم|سؤا?الات/.test(n)) return true;
    }
    return false;
  };
  const parseMark = (s: string): number | null => {
    const t = s.trim();
    let m = t.match(/^(\d{1,2})\s*\/\s*(\d{1,2})$/); // bidi decimal "5 / 1" = 1.5
    if (m) return Math.round((parseInt(m[2], 10) + parseInt(m[1], 10) / Math.pow(10, m[1].length)) * 100) / 100;
    m = t.match(/^(\d{1,2})(?:[.,](\d{1,2}))?$/);
    if (m) return Math.round((parseInt(m[1], 10) + (m[2] ? parseInt(m[2], 10) / Math.pow(10, m[2].length) : 0)) * 100) / 100;
    return null;
  };

  // --- unified row markers (#qu2 wave 4, p8214): digit rungs + NAMED rows ----
  // A bare category-word line ("Reading.", "Listening.", "Pronunciatin.") is
  // its OWN row when real content follows it; when a digit rung sits directly
  // beneath ("Writhing" above "7. Choose…") it is a span LABEL for the digit
  // rows, exactly like the printed subject spans. The sheet's own spelling is
  // kept as the row id ("Pronunciatin" stays as printed).
  const namedRe = /^(pronunc\w*|listening|reading|writ\w*|grammar|vocabulary)\.?\s*$/i;
  interface KRow { line: number; id: string; rest: string; named?: boolean; markLine?: number }
  const rows: KRow[] = ladder.map((r) => ({ line: r.line, id: String(r.n), rest: r.rest }));
  const labelCatAt = new Map<number, RawSectionBlock['category']>();
  for (let i = 0; i < scanEnd; i++) {
    const nm = nfkc(lines[i]).trim().match(namedRe);
    if (!nm) continue;
    const nextContent = lines.slice(i + 1, i + 4).map((l) => l.trim()).find(Boolean) || '';
    if (rowStart(nextContent)) {
      // span label above a digit rung — its category carries ("Writhing"
      // above "7. Choose…" makes rows 7..8 Writing).
      const cat = categorize(nm[1]);
      if (cat) labelCatAt.set(i, cat);
      continue;
    }
    rows.push({ line: i, id: nm[1], rest: '', named: true });
  }
  rows.sort((a, b) => a.line - b.line);

  // Lost-digit synthesis: a named row's block that CONTINUES past its mark
  // cell into another imperative instruction starts a NEW row whose printed
  // digit the extractor dropped ("10" before "Change the adjective in to
  // adverbs."). The expected ladder digit names it — the visible 1..9 ladder
  // makes the inference grounded, never invented.
  const expanded: KRow[] = [];
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const end = i + 1 < rows.length ? rows[i + 1].line : scanEnd;
    expanded.push(row);
    if (!row.named) continue;
    for (let k = row.line + 1; k < end - 1; k++) {
      const t = lines[k].trim();
      if (!/^\.?\d{1,2}(\s*\/\s*\d{1,2})?([.,]\d{1,2})?$/.test(t)) continue;
      if (nearBanner(k)) continue;
      const v = parseMark(t);
      if (v === null) continue;
      const nextLine = lines.slice(k + 1, k + 3).map((l) => l.trim()).find(Boolean) || '';
      if (IMPERATIVE_REST.test(nextLine)) {
        // The sheet never printed a digit for this row ("Change the adjective
        // in to adverbs." sits UNNUMBERED on p8214) — the imperative word is
        // the id, grounded in what the sheet actually shows.
        expanded.push({ line: k + 1, id: nextLine.split(/\s+/)[0], rest: nextLine, named: false, markLine: k });
        break;
      }
    }
  }
  expanded.sort((a, b) => a.line - b.line);

  // Mark-layout fingerprint (#qu2 wave 4): the BEFORE-layout (mark cell
  // printed before the row opener, p8214) is proven by a standalone mark
  // digit sitting in the header band right before the FIRST row. Without it
  // the trailing digit at each block's tail is that block's OWN mark
  // (AFTER-layout — the radif/Kanoon corpus, pq89) and looking back one row
  // would shift every mark by one.
  const firstStart = expanded.length ? expanded[0].line : 0;
  let beforeLayout = false;
  for (let k = firstStart - 1; k >= Math.max(0, firstStart - 4); k--) {
    const t = lines[k].trim();
    if (!t) continue;
    // A banner-adjacent digit (ردیف/نمره table header debris — pq89's "2"
    // under the "ردیف سؤالات نمره" banner) is NOT a mark cell; only a bare
    // digit beside a plain بارم banner (p8214) proves the BEFORE-layout.
    if (/^\.?\d{1,2}(\s*\/\s*\d{1,2})?([.,]\d{1,2})?$/.test(t)) { beforeLayout = !nearBanner(k); }
    break;
  }

  const blocks: RawSectionBlock[] = [];
  let carryCat = '';
  for (let i = 0; i < expanded.length; i++) {
    const row = expanded[i];
    const start = row.line;
    const end = i + 1 < expanded.length ? expanded[i + 1].line : scanEnd;
    // Block text EXCLUDES the rung's printed number — "1. Match the pictures…"
    // keeps its instruction words but loses the "1." that the question
    // segmenter would read as a phantom first question. Named rows keep the
    // whole line (it IS the category banner).
    const firstLine = lines[start];
    const strippedFirst = row.named ? firstLine : firstLine.replace(/^\s*\d{1,2}\s*[.)]?\s*/, '');
    const blockLines = [strippedFirst, ...lines.slice(start + 1, end)];
    // Mark: BEFORE-layout (mark cell printed before the row opener — the بارم
    // column lands at the previous block's tail). The nearest standalone
    // number looking back from the opener wins; the AFTER-layout (radif
    // papers, mark inside the block) keeps the last-in-block rule.
    let mark = 0;
    if (beforeLayout) {
      for (let k = start - 1; k >= Math.max(0, start - 4); k--) {
        const t = lines[k].trim();
        if (!t) continue;
        if (namedRe.test(nfkc(t))) continue; // a span label never blocks the look-back
        if (/^\.?\d{1,2}(\s*\/\s*\d{1,2})?([.,]\d{1,2})?$/.test(t)) {
          const v0 = parseMark(t);
          if (v0 !== null && v0 >= 0.25 && v0 <= 20) { mark = v0; break; }
        }
        break;
      }
    }
    if (mark === 0) {
      for (let k = 0; k < blockLines.length; k++) {
        const t = blockLines[k].trim();
        if (!/^\.?\d{1,2}(\s*\/\s*\d{1,2})?([.,]\d{1,2})?$/.test(t)) continue;
        if (nearBanner(start + k)) continue;
        const v = parseMark(t);
        if (v !== null && v >= 0.25 && v <= 20) mark = v;
      }
    }
    let carryFromLabel = false;
    for (const [labLine, labCat] of labelCatAt) {
      if (labLine > (i > 0 ? expanded[i - 1].line : -1) && labLine < start) {
        carryCat = labCat;
        carryFromLabel = true;
      }
    }
    const labeled = categorize(row.rest);
    if (labeled) carryCat = labeled;
    if (row.named) carryCat = (categorize(row.id) || carryCat) as RawSectionBlock['category'];
    const blockText = blockLines.join('\n');
    // R4 instruction-contract fallback: no printed label anywhere -> the
    // opener line's own task contract decides (detectInitialCategory), so a
    // label-free listening block never falls to General and gets rebranded
    // by shape refinements. Printed labels stay stronger than detection.
    const detected =
      labeled || carryCat ? '' : detectInitialCategory(strippedFirst, blockText);
    if (process.env.PARSE_DEBUG) console.error('[kanoon-block]', JSON.stringify({ rowId: row.id, cat: labeled || carryCat || 'General', carryFromLabel, pin: labeled || carryFromLabel ? true : undefined }));
    blocks.push({
      rowId: row.id,
      category: (labeled || carryCat || detected || 'General') as RawSectionBlock['category'],
      mark,
      text: blockText,
      headerLine: row.rest,
      startIndex: lines.slice(0, start).reduce((s2, l) => s2 + l.length + 1, 0),
      // The rung rest carried a printed subject label ("17 Grammar") — pin it.
      // A span label carried from above ("Writhing" over rows 7-8) pins too:
      // it is the sheet's own statement, remaps must not rebrand it.
      labelCategory: labeled || carryFromLabel ? true : undefined,
    });
  }
  // Sanity: a Kanoon paper carries real marks and real questions.
  const markSum = blocks.reduce((s, b) => s + b.mark, 0);
  const hasQuestions = blocks.some((b) => /(?:^|\n)\s*\d{1,3}\s*[\.\)]\s*\S/.test(b.text));
  if (markSum < 6 || markSum > 60 || !hasQuestions) return null;
  return blocks;
}

/**
 * Marks-table genre (#qu-corpus).
 * Many Iranian papers are laid out as a table: | نمره (بارم) | سوالات | ردیف |
 * where each TABLE ROW is a section. Extractors emit three label styles:
 *   numeric ردیف:   [mark] content… [row#] [mark] …        (row# closes its row)
 *   letter labels:  [mark] content… [A]  [mark] …          (letter closes its row)
 *   hybrid:         A, content, [mark] content (no letter)… (unlabeled rows!)
 * A unified state machine handles all three: a standalone number OPENS a row
 * (the بارم) when the current row is fresh; in numeric mode a standalone
 * integer equal to the next expected ردیف index CLOSES the row; a bare letter
 * equal to the next expected letter attaches as the row label and switches to
 * letter mode (numbers then always open rows — the ردیف column is lettered).
 * Unlabeled rows fall back to their 1-based position ("2", "9"). Stray letters
 * (option debris "A) Study" rows) never match the expected letter sequence and
 * are ignored. Returns null when the genre doesn\'t apply so the lettered
 * splitter takes over.
 */
function splitMarksTableSections(text: string): RawSectionBlock[] | null {
  const lines = text.split(/\r?\n/);
  const isBareWord = (l: string, w: string) => l.trim() === w;
  // Column-header band: bare ردیف + bare سوالات + bare نمره/بارم in the top band.
  const head = lines.slice(0, 15).map((l) => l.trim());
  const hasRadifCol = head.some((l) => isBareWord(l, 'ردیف'));
  const hasQCol = head.some((l) => isBareWord(l, 'سوالات'));
  const hasMarkCol = head.some((l) => isBareWord(l, 'نمره') || isBareWord(l, 'بارم'));
  const banded = hasRadifCol && hasQCol && hasMarkCol;
  // Band-less papers whose column headers never extract still show the
  // marks-table RHYTHM: [mark][content][row#][mark]… with strictly increasing
  // numeric ردیف closes. That shape is accepted only when the machine closes
  // >=4 rows through the numeric sequence (minNumericCloses) — stray bare
  // numbers elsewhere can't chain that far.
  const minNumericCloses = 4;
  // No early band gate: band-less papers are accepted solely by the rhythm
  // validation below (numericCloses >= minNumericCloses). Lettered papers
  // whose marks sit inline (or as flat standalone sequences that never chain
  // 1,2,3… like زمان-آزمون's 4,3,2,2…) never accumulate numeric closes and
  // fall through to the lettered splitter.

  const isStandaloneNumber = (l: string) => /^\.?\d{1,2}(?:[\.,]\d{1,2})?$/.test(l.trim());
  // LATIN letters only: Persian bare words (الف/ب matching-column headers)
  // inside a numeric paper's rows must never flip the machine into letter
  // mode — they are column furniture, not row labels.
  const bareLetter = (l: string): string | null => {
    const m = l.trim().match(/^([A-Za-z])[\)\.]?$/);
    return m ? m[1].toUpperCase() : null;
  };

  // Header band ends at the LAST of the three column words; content begins
  // after it. Band-less papers walk from the very top — the rhythm validation
  // (numericCloses) is what keeps them honest.
  const bandIdxs = lines
    .map((l, i) => ({ l: l.trim(), i }))
    .filter(({ l }) => isBareWord(l, 'ردیف') || isBareWord(l, 'سوالات') || isBareWord(l, 'نمره') || isBareWord(l, 'بارم'))
    .map(({ i }) => i)
    .filter((i) => i < 15);
  if (banded && bandIdxs.length === 0) return null;
  const startLine = banded ? Math.max(...bandIdxs) + 1 : 0;

  interface MarkRow {
    rowId: string | null; // letter label, or null = use position
    mark: number;
    startLine: number;    // first content line (after the mark line)
    endLine: number;      // exclusive
  }
  const rows: MarkRow[] = [];
  let letterMode = false;
  let expectedRow = 1;
  let expectedLetter = 'A';
  let numericCloses = 0;
  let open: { mark: number; markLine: number; firstContent: number | null; label: string | null } | null = null;
  // Content that arrived with NO open row (after a close, before the next
  // mark). If a numeric ردیف then arrives, that content was an UNMARKED row —
  // the paper's نمره cell was simply empty (honest mark 0, never fabricated).
  let orphanStart: number | null = null;

  const closeOpen = (endLine: number) => {
    if (!open) return;
    const hasContent = open.firstContent !== null;
    if (hasContent || rows.length === 0) {
      rows.push({
        rowId: open.label,
        mark: open.mark,
        startLine: open.firstContent ?? open.markLine + 1,
        endLine,
      });
    }
    open = null;
  };

  for (let i = startLine; i < lines.length; i++) {
    const raw = lines[i];
    const trimmed = raw.trim();
    if (!trimmed) continue;

    if (isStandaloneNumber(trimmed)) {
      const v = parseFloat(trimmed.replace(',', '.'));
      if (isNaN(v)) continue;
      if (!open) {
        if (
          !letterMode &&
          Number.isInteger(v) &&
          v >= expectedRow &&
          orphanStart !== null &&
          numericCloses > 0 // never close the pre-paper header block as a row
        ) {
          // The pending content was an unmarked row; this number is its ردیف.
          rows.push({ rowId: String(v), mark: 0, startLine: orphanStart, endLine: i });
          orphanStart = null;
          expectedRow = v + 1;
          numericCloses++;
        } else {
          open = { mark: v, markLine: i, firstContent: null, label: null };
        }
      } else if (open.firstContent === null) {
        // Adjacent mark cells: teachers split a row's بارم (".5" + "1" = 1.5)
        // — SUM them, never clobber.
        open.mark = Math.round((open.mark + v) * 100) / 100;
        open.markLine = i;
      } else if (!letterMode && Number.isInteger(v) && v >= expectedRow) {
        // Numeric ردیف cell: terminates its own row. Teachers sometimes skip
        // indices (1,2,3,4,7) — any monotonic integer closes, and the PRINTED
        // number becomes the row label (never renumbered).
        open.label = String(v);
        closeOpen(i);
        orphanStart = null;
        expectedRow = v + 1;
        numericCloses++;
      } else {
        // Letter mode (or a stray number): the row closes and a new one opens.
        closeOpen(i);
        orphanStart = null;
        open = { mark: v, markLine: i, firstContent: null, label: null };
      }
      continue;
    }

    const letter = bareLetter(trimmed);
    if (letter && letter === expectedLetter) {
      if (open) open.label = letter;
      letterMode = true;
      expectedLetter = String.fromCharCode(expectedLetter.charCodeAt(0) + 1);
      continue;
    }

    // Ordinary content line.
    if (open) {
      if (open.firstContent === null) open.firstContent = i;
    } else if (orphanStart === null) {
      orphanStart = i;
    }
  }
  closeOpen(lines.length);

  // Radif-opens rhythm (#qu2 wave 5 — 14050319p566h5f982): the RTL marks
  // table can extract MIRRORED — each row's ردیف digit lands ABOVE its
  // content and the بارم digit TRAILS it ("1 / A) Fill in… / q1-6 / 3 / 2 /
  // B) Match… / 2 / 3 / C) …"). The mark-opens machine above reads that as
  // mark cells and mangles every mark (بارم + next ردیف summed). This walk
  // gates the rhythm on the numbers instead: a number equal to the expected
  // ردیف index OPENS its row, any other standalone number is that row's بارم
  // and closes it, and the row's identity is the letter fused to its first
  // content line ("A) Fill in the blanks…"). Strict validation — every row
  // letter-labeled, >=4 opener chains, sane mark sum — otherwise null so the
  // lettered splitter takes over.
  const walkRadifOpens = (): MarkRow[] | null => {
    const alt: MarkRow[] = [];
    let cur: { label: string | null; mark: number; firstContent: number | null } | null = null;
    let expected = 1;
    let openers = 0;
    for (let i = 0; i < lines.length; i++) {
      const t = lines[i].trim();
      if (!t) continue;
      if (isStandaloneNumber(t)) {
        const v = parseFloat(t.replace(',', '.'));
        if (isNaN(v)) continue;
        if (cur === null) {
          if (Number.isInteger(v) && v === expected) {
            cur = { label: null, mark: 0, firstContent: null };
            expected++;
            openers++;
          }
          // furniture debris (page numbers, stray marks) — ignored
        } else if (cur.firstContent !== null) {
          if (Number.isInteger(v) && v === expected) {
            // the next ردیف arrived with this row's mark cell missing —
            // close honestly at mark 0, never fabricate
            alt.push({ rowId: cur.label, mark: cur.mark, startLine: cur.firstContent, endLine: i });
            cur = { label: null, mark: 0, firstContent: null };
            expected++;
            openers++;
          } else {
            cur.mark = v;
            alt.push({ rowId: cur.label, mark: v, startLine: cur.firstContent, endLine: i });
            cur = null;
          }
        } else {
          // adjacent mark cells on a fresh row — sum (".5" + "1")
          cur.mark = Math.round((cur.mark + v) * 100) / 100;
        }
        continue;
      }
      if (cur && cur.firstContent === null) {
        const lm = t.match(/^\s*([A-Za-z])\s*[\).]\s/);
        if (lm && cur.label === null) cur.label = lm[1].toUpperCase();
        cur.firstContent = i;
      }
    }
    if (cur && cur.firstContent !== null) {
      alt.push({ rowId: cur.label, mark: cur.mark, startLine: cur.firstContent, endLine: lines.length });
    }
    if (alt.length < 4 || openers < 4) return null;
    if (!alt.every((r) => r.rowId !== null)) return null;
    const s = alt.reduce((a, r) => a + r.mark, 0);
    if (s < 3 || s > 25) return null;
    return alt;
  };

  const lineStartOffset = (idx: number) => lines.slice(0, idx).reduce((s, l) => s + l.length + 1, 0);

  const toBlocks = (rs: MarkRow[]) =>
    rs.map((r, idx) => {
      const blockText = lines.slice(r.startLine, r.endLine).join('\n');
      const headerLine =
        lines
          .slice(r.startLine, r.endLine)
          .map((l) => l.trim())
          .find(Boolean) || '';
      return {
        rowId: r.rowId || String(idx + 1),
        category: detectInitialCategory(headerLine, blockText),
        mark: r.mark > 0 && r.mark <= 20 ? r.mark : 0,
        text: blockText,
        headerLine,
        startIndex: lineStartOffset(r.startLine),
      } satisfies RawSectionBlock;
    });

  const markSumStd = rows.reduce((s, r) => s + r.mark, 0);
  const standardOk =
    rows.length >= 3 &&
    (banded || numericCloses >= minNumericCloses) &&
    markSumStd >= 3 &&
    markSumStd <= 25;
  if (!standardOk) {
    const alt = walkRadifOpens();
    if (alt) return toBlocks(alt);
    return null;
  }
  return toBlocks(rows);
}

/**
 * Fused-opener numbered rows genre (#qu2 wave 5 — 14050320p43266n364): bidi
 * sheets whose row openers FUSE the row number to the Persian instruction —
 * "2 جاهای خالی … کامل کنید", "3 . کلمه ناهماهنگ را پیدا کنید", "8 متن زیر را
 * بخوانید …" — while row 1's opener often carries no digit at all (the sheet
 * starts the exam directly after the student header: "در متن‌های زیر شکل
 * صحیح … ( 5 نمره)"). Rows may be separated by horizontal rule lines, but the
 * rule extraction is unreliable (a separator can degrade into the dotted
 * answer line "……" of the row above), so blocking is OPENER-TO-OPENER and the
 * "N نمره" cell printed inside each opener line is the row's بارم.
 * Acceptance is strict: >=4 openers whose digits form a consecutive ladder
 * (1,2,… or an implicit 1 followed by 2,3,…), >=3 بارم cells, question content
 * in every row, and a sane mark total — anything less falls through to the
 * bare-marker splitter.
 */
function splitRuleRuledSections(text: string): RawSectionBlock[] | null {
  const lines = text.split(/\r?\n/);
  const nfkc = (l: string) => l.normalize('NFKC');
  // The fused opener: a row digit, then the Persian instruction — "2 جاهای
  // خالی", "3 . کلمه ناهماهنگ", "8 متن زیر را بخوانید". A bare Latin question
  // ("1. Did you know…") or a Persian continuation ("2 .dress / …") never
  // matches: the char run after the digit must reach a Persian letter.
  const openerDigit = (l: string): number | null => {
    const t = nfkc(l.trim());
    const m = t.match(/^(\d{1,2})\s*[.،,]?\s+[\u0600-\u06FF]/);
    return m ? parseInt(m[1], 10) : null;
  };
  // The بارم cell printed inside the opener line: "( 5 نمره)", ". 2 نمره)",
  // "( . 3 نمره )".
  const openerMark = (l: string): number => {
    const m = nfkc(l).match(/[([.,\s]*(\d{1,2}(?:[.,]\d{1,2})?)\s*نمره/);
    if (!m) return 0;
    const v = parseFloat(m[1].replace(',', '.'));
    return !isNaN(v) && v > 0 && v <= 20 ? v : 0;
  };
  // Header/ad/debris lines never open a row (the digitless head opener must
  // land on the REAL row-1 instruction, not the banner or a bidi fragment).
  const isHeadDebris = (t: string) =>
    /نام\s*و\s*نام|نام\s*دبیر|دبیرستان|دبستان|آموزش\s*و\s*پرورش|تاریخ|وقت\s*امتحان|ساعت\s*امتحان|شماره\s*صندلی|نوبت|پایه|صفحه|امضاء|مهر|به\s*عدد|به\s*حروف|دانلود|تخف|جایزه|تمرین|کانون/.test(
      nfkc(t),
    );
  const QUESTION_SHAPE =
    /(?:^|\s)\d{1,3}\s*[.)\/]\s*(?=[^\d\s])|\(\s*\d{1,3}\s*\)|\([a-z0-9][^)\n]{0,40}[–-]\s*[a-z0-9]/i;

  // Collect opener candidates: every fused-digit Persian instruction line,
  // plus at most the digitless row-1 instruction (a long Persian line that
  // carries a بارم cell).
  interface Opener { line: number; digit: number | null; mark: number }
  const openers: Opener[] = [];
  for (let i = 0; i < lines.length; i++) {
    const t = lines[i].trim();
    if (!t) continue;
    const d = openerDigit(lines[i]);
    if (d !== null) {
      openers.push({ line: i, digit: d, mark: openerMark(lines[i]) });
      continue;
    }
    if (
      /[\u0600-\u06FF]/.test(nfkc(t)) &&
      t.length >= 20 &&
      !isHeadDebris(t) &&
      openerMark(lines[i]) > 0
    ) {
      openers.push({ line: i, digit: null, mark: openerMark(lines[i]) });
    }
  }
  if (openers.length < 4) return null;

  // Ladder validation. The digitless opener is allowed ONLY as row 1 and
  // only when the explicit ladder starts at 2 (the implicit head row IS 1).
  const firstExplicit = openers.findIndex((o) => o.digit !== null);
  if (firstExplicit < 0) return null;
  let expected = 1;
  for (let i = 0; i < openers.length; i++) {
    const d = openers[i].digit;
    if (d === null) {
      if (
        i === 0 &&
        firstExplicit === 1 &&
        openers[1].digit === 2 &&
        openers[0].line < openers[1].line
      ) {
        expected = 2; // the implicit head row WAS 1 — the ladder continues at 2
        continue;
      }
      return null;
    }
    if (d !== expected) return null;
    expected = d + 1;
  }
  const markSum = openers.reduce((s, o) => s + o.mark, 0);
  const marked = openers.filter((o) => o.mark > 0).length;
  if (marked < 3 || markSum < 6 || markSum > 60) return null;

  // Blocks: opener-to-opener; the last row runs to the text end.
  const rows: { digit: number | null; mark: number; start: number; end: number }[] = [];
  for (let i = 0; i < openers.length; i++) {
    rows.push({
      digit: openers[i].digit,
      mark: openers[i].mark,
      start: openers[i].line,
      end: i + 1 < openers.length ? openers[i + 1].line : lines.length,
    });
  }
  // Every row must carry real question content.
  for (const r of rows) {
    let hasQ = false;
    for (let k = r.start; k < r.end; k++) {
      if (QUESTION_SHAPE.test(lines[k])) { hasQ = true; break; }
    }
    if (!hasQ) return null;
  }

  return rows.map((r) => {
    const rawHeader = lines[r.start].trim();
    const headerLine = rawHeader;
    // Strip the opener's fused row digit — "3 . کلمه ناهماهنگ…" keeps its
    // instruction words but loses the "3 ." the segmenter would read as a
    // phantom third question (p43266 rows 3/7).
    const strippedFirst = r.digit !== null ? rawHeader.replace(/^\s*\d{1,2}\s*[.،,]?\s*/, '') : rawHeader;
    const blockText = strippedFirst + '\n' + lines.slice(r.start + 1, r.end).join('\n');
    // Printed-contract categories: the rule-row opener carries the task
    // contract, which outranks keyword polling (p43266: "شکل صحیح کلمات داخل
    // پرانتز" is Grammar though کلمات polls Vocabulary; "اولین حرف و تعداد
    // حروف داده شده" spell-in rows are Vocabulary).
    let category = detectInitialCategory(headerLine, blockText);
    const nfkcHeader = nfkc(headerLine);
    if (/شکل\s*صحیح|داخل\s*پرانتز/.test(nfkcHeader)) {
      category = 'Grammar';
    } else if (/اولین\s*حرف|حروف\s*داده/.test(nfkcHeader)) {
      category = 'Vocabulary';
    }
    return {
      rowId: String(r.digit ?? 1),
      category,
      mark: r.mark,
      text: blockText,
      headerLine,
      startIndex: lines.slice(0, r.start).reduce((s, l) => s + l.length + 1, 0),
    } satisfies RawSectionBlock;
  });
}

/**
 * Bare-marker sections genre (#qu2 wave 4 — 14050401pm57p5s814): bidi exam
 * sheets whose section openers extract as BARE single-token lines — a digit
 * ladder "1" "2" "3" for the numbered part, then a letter ladder "A".."R" —
 * each marker OPENS its section (content follows), and the section's بارم
 * trails as a standalone number AFTER the content (the printed mark column
 * lands beside the section's last row). A subject label line ("Listening",
 * "Vocabulary"…) printed just before an opener labels it, and carries into
 * the following label-less sections exactly like the printed sheet's spans.
 * Acceptance is strict so lettered papers whose marks merely trail as bare
 * numbers never hijack: BOTH ladders must exist (≥3 digit rungs starting at
 * 1 with real question content between rungs, ≥4 consecutive letter rungs),
 * the digit rungs must come FIRST, and every rung's block must carry
 * questions. Anything less falls through to the lettered splitter.
 */
function splitBareMarkerSections(text: string): RawSectionBlock[] | null {
  const lines = text.split(/\r?\n/);
  const nfkc = (l: string) => l.normalize('NFKC');
  // Page/header furniture: a standalone number right after one of these lines
  // is the PAGE NUMBER (or sheet debris), never a section mark.
  const isFurniture = (l: string) =>
    /نام و نام خانوادگی|نام دبیر|دبیرستان|آموزش و پرورش|اداره ی|جمهوری اس.?المی|www\.|www-|تاریخ و امضاء|محل مهر|به حروف|به عدد|تجدید نظر|شماره داوطلب|مقطع و رشته|نام پدر|تعداد صفحه|مدت امتحان|ساعت امتحان|نام درس|تاریخ امتحان|کد امتحان|راهنمای تصحیح|جمع بارم|سؤا?الات|وبسایت|امتحانات|سال تحصیلی|منطقه/.test(
      nfkc(l),
    );
  // Pure digit/dash debris ("021-2936" phone tails, "0402" year tails): short,
  // letterless, and NOT a numbered slot row ("79.  80." keeps its dots).
  const isDebris = (l: string) => {
    const t = l.trim();
    if (!t || t.length > 12) return false;
    if (/[\u0600-\u06FFA-Za-z]/.test(t)) return false;
    if (/\d{1,3}\s*[.)]/.test(t)) return false;
    return true;
  };
  const isStandaloneNumber = (l: string) => /^\.?\d{1,2}(?:[\.,]\d{1,2})?$/.test(l.trim());
  const bareLetter = (l: string): string | null => {
    const m = l.trim().match(/^([A-Z])$/);
    return m ? m[1] : null;
  };
  const bareDigit = (l: string): number | null => {
    const m = l.trim().match(/^(\d{1,3})$/);
    return m ? parseInt(m[1], 10) : null;
  };
  // A real question line: numbered start, inline paren number, or a True/False
  // option row (listening sections print "… True ⎕ False ⎕" with no other
  // numbered anchor).
  const QUESTION_SHAPE =
    /(?:^|\s)\d{1,3}\s*[.)\/]\s*(?=[^\d\s])|\(\s*\d{1,3}\s*\)|\bTrue\b\s*[⎕☐□]?\s*\bFalse\b/i;
  const hasQuestionLine = (from: number, to: number) => {
    for (let k = from; k < to && k < lines.length; k++) {
      const t = lines[k].trim();
      if (t && QUESTION_SHAPE.test(t)) return true;
    }
    return false;
  };

  // --- digit ladder walk: 1,2,3… where each rung is FOLLOWED by question
  // content before the next bare line (marks never satisfy that — they sit
  // directly against the next opener or page furniture).
  const digitMarkers: { line: number; n: number }[] = [];
  let expectedDigit = 1;
  for (let i = 0; i < lines.length; i++) {
    if (!isStandaloneNumber(lines[i]) && !bareLetter(lines[i])) continue;
    const v = bareDigit(lines[i]);
    if (v === null || v !== expectedDigit) continue;
    // content window: this marker line … next bare/standalone line
    let next = i + 1;
    while (next < lines.length) {
      const t = lines[next].trim();
      if (!t) { next++; continue; }
      if (isStandaloneNumber(lines[next]) || bareLetter(lines[next])) break;
      next++;
    }
    if (hasQuestionLine(i + 1, next)) {
      digitMarkers.push({ line: i, n: v });
      expectedDigit = v + 1;
    }
  }

  // --- letter ladder: consecutive bare letters from A (≥4 rungs).
  const letterMarkers: { line: number; id: string }[] = [];
  let expectedLetter = 'A';
  for (let i = 0; i < lines.length; i++) {
    const l = bareLetter(lines[i]);
    if (l && l === expectedLetter) {
      letterMarkers.push({ line: i, id: l });
      expectedLetter = String.fromCharCode(expectedLetter.charCodeAt(0) + 1);
    }
  }

  if (digitMarkers.length < 3 || letterMarkers.length < 4) return null;
  if (digitMarkers[0].line > letterMarkers[0].line) return null;

  // --- unified opener sequence (digits first, then letters — verified above).
  interface Marker { line: number; id: string }
  const markers: Marker[] = [
    ...digitMarkers.map((d) => ({ line: d.line, id: String(d.n) })),
    ...letterMarkers.map((l) => ({ line: l.line, id: l.id })),
  ].sort((a, b) => a.line - b.line);

  const CATEGORY_LABEL: { re: RegExp; cat: RawSectionBlock['category'] }[] = [
    { re: /^listening|شنیداری|درک\s*شنیداری/i, cat: 'Listening' },
    { re: /^vocabulary|واژگان|لغت/i, cat: 'Vocabulary' },
    { re: /^grammar|دستور\s*زبان/i, cat: 'Grammar' },
    { re: /^writing|نوشتاری|نگارش/i, cat: 'Writing' },
    { re: /^reading|درک\s*مطلب|خوانداری/i, cat: 'Reading' },
  ];

  const blocks: RawSectionBlock[] = [];
  let carryCat: RawSectionBlock['category'] | '' = '';
  // Pre-compute each marker's printed label (and its line index) so the
  // PREVIOUS block can drop that label line — the "Vocabulary" printed above
  // marker "A" belongs to A, but sits inside section 3's span and used to
  // leak in as its last content line.
  const labelOf: (RawSectionBlock['category'] | '')[] = [];
  const labelLineIdx: number[] = [];
  for (let i = 0; i < markers.length; i++) {
    const start = markers[i].line;
    let labeled: RawSectionBlock['category'] | '' = '';
    let labelAt = -1;
    for (let k = start - 1; k >= 0 && k >= start - 4; k--) {
      const t = lines[k].trim();
      if (!t || isStandaloneNumber(t) || bareLetter(t)) continue;
      const hit = CATEGORY_LABEL.find((c) => c.re.test(nfkc(t)));
      if (hit) { labeled = hit.cat; labelAt = k; break; }
      break; // some other content line — stop looking
    }
    labelOf.push(labeled);
    labelLineIdx.push(labelAt);
  }
  for (let i = 0; i < markers.length; i++) {
    const start = markers[i].line;
    const end = i + 1 < markers.length ? markers[i + 1].line : lines.length;
    const labeled = labelOf[i];
    if (labeled) carryCat = labeled;
    // Mark: the LAST standalone number in the block that is not page debris
    // (page numbers sit right after a furniture line) and not the opener.
    let mark = 0;
    for (let k = start + 1; k < end; k++) {
      const t = lines[k].trim();
      if (!t || !isStandaloneNumber(t)) continue;
      let nearFurniture = false;
      for (let f = Math.max(0, k - 4); f < k; f++) {
        const ft = lines[f].trim();
        if (ft && isFurniture(ft)) { nearFurniture = true; break; }
      }
      if (nearFurniture) continue;
      const v = parseFloat(t.replace(',', '.'));
      if (!isNaN(v) && v >= 0.25 && v <= 20) mark = v;
    }
    // Glued trailing mark (#qu2 wave 4): the bidi render appends the row's
    // mark cell to the LAST content line — "No, ………………… . 1". A line that
    // ends in a blank run (or blank punctuation tail) followed by a bare
    // 1-2 digit number carries that row's mark.
    if (mark === 0) {
      for (let k = start + 1; k < end; k++) {
        const t = lines[k].trim();
        const m2 = t.match(/(?:\u2026{2,}|[._\u2013\u2014-]{4,})[\s.]*(\d{1,2}(?:[.,]\d{1,2})?)\s*$/);
        if (m2) {
          const v = parseFloat(m2[1].replace(',', '.'));
          if (!isNaN(v) && v >= 0.25 && v <= 20) mark = v;
        }
      }
    }
    // Page-furniture repeats and digit debris never carry question content —
    // dropping them here keeps the mid-sheet header blocks (which re-print on
    // every page) from breeding phantom questions ("021-2936" parsed as q21).
    const blockLines = lines
      .slice(start, end)
      .filter((l, off) => {
        const abs = start + off;
        if (i + 1 < markers.length && abs === labelLineIdx[i + 1]) return false; // next block's label
        return !isFurniture(l) && !isDebris(l);
      });
    const blockText = blockLines.join('\n');
    // R4 instruction-contract fallback (consistent with the radif builds):
    // an unlabeled instr-block still names its task on the opener line.
    const detected =
      labeled || carryCat ? '' : detectInitialCategory(blockLines[0] ?? '', blockText);
    blocks.push({
      rowId: markers[i].id,
      category: (labeled || carryCat || detected || 'General') as RawSectionBlock['category'],
      mark,
      text: blockText,
      headerLine: labelLineIdx[i] >= 0 ? lines[labelLineIdx[i]].trim() : '',
      startIndex: lines.slice(0, start).reduce((s, l) => s + l.length + 1, 0),
      // The printed subject-label span (Grammar covers F..J until Reading)
      // is the sheet's own statement — pin every block it covers so genre
      // remaps cannot rebrand carried sections.
      labelCategory: carryCat ? true : undefined,
    });
  }

  // Sanity: real marks and real questions across the sheet.
  const markSum = blocks.reduce((s, b) => s + b.mark, 0);
  const withQuestions = blocks.filter((b) => /(?:^|\n)\s*\d{1,3}\s*[.)\/]\s*\S|\(\s*\d{1,3}\s*\)|\bTrue\b\s*[⎕☐□]?\s*\bFalse\b/i.test(b.text)).length;
  if (markSum < 6 || markSum > 60 || withQuestions < 3) return null;
  return blocks;
}

/** Longest strictly-increasing Latin letter-header ladder (A..H+ = lettered
 *  paper). Section-letter shapes only: a bare standalone letter line, a
 *  letter followed by PERSIAN text ("A دانش آموزان…", "A )به فایل…"), or a
 *  lettered header "A) …"/"A. …" with Persian continuation. English prose
 *  ("A lot of…", sub-part prompts "A. Is it true…") never matches. */
export function longestLetterHeaderLadder(lines: string[]): number {
  const latin: number[] = [];
  const persian: number[] = [];
  for (const l of lines) {
    const t = l.trim();
    const m =
      t.match(/^([A-Z])[\)\.:]?\s*$/) ||
      t.match(/^([A-Z])\s*(?:\)|\.|:)?\s*(?=[\u0600-\u06FF])/);
    if (m) latin.push(m[1].charCodeAt(0));
    // Persian letter headers: الف) ب) … or a bare Persian ordinal line.
    const pm = t.match(/^([\u0621-\u064A]+)\s*[\)\.:]/) || t.match(/^([\u0621-\u064A]+)\s*$/);
    if (pm) {
      const ord = PERSIAN_ROW_ORDINALS.indexOf(pm[1]);
      if (ord >= 0) persian.push(ord + 1);
    }
  }
  const lis = (vals: number[]): number => {
    let best = 0;
    const bl = new Array(vals.length).fill(1);
    for (let i = 0; i < vals.length; i++) {
      for (let j = 0; j < i; j++) {
        if (vals[j] < vals[i] && bl[j] + 1 > bl[i]) bl[i] = bl[j] + 1;
      }
      if (bl[i] > best) best = bl[i];
    }
    return best;
  };
  // Persian letter ladders follow TWO orders on Iranian sheets — the Persian
  // alphabet (الف ب پ ت ث ج…) and the Arabic-order sequence (الف ب ج د ه و ز
  // ح…), whose ranks are non-monotonic in the Persian list. A distinct-letter
  // count (>=5 different header letters) identifies a lettered paper without
  // depending on which order the sheet used.
  const distinctPersian = new Set(persian).size;
  return Math.max(lis(latin), lis(persian), distinctPersian >= 5 ? 8 : 0);
}

/**
 * Trailing key-sheet boundary (#qu2 wave 2).
 * Teacher/national papers frequently ship a SECOND sheet inside the same PDF:
 * راهنمای تصحیح / راهنمای نمره گذاری (scoring guides), کلید سؤالات (answer
 * keys) or پاسخنامه/پاسخ برگ (answered copies). Their rows restate every
 * question number with the correct answer, so a parser that scans past the
 * banner duplicates every section with junk. The banner may also be embedded
 * in the sheet's own header band ("پاسخنامه درس: … مدت امتحان: …"), so the
 * match must simply locate the banner LINE — everything from it onward is
 * key material. The exam header's own "(پاسخ برگ دارد)" note is NOT a banner
 * (it carries سؤاالات on the same line and never starts the line).
 * Returns the char offset of the banner, or -1 when no key sheet follows.
 */
export function findKeySheetBoundary(text: string): number {
  const lines = text.split(/\r?\n/);
  let offset = 0;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const nfkc = line.normalize('NFKC');
    // Standalone-banner test: the key sheet's own table header repeats the
    // ردیف column ("ردیف راهنمای نمره گذاری نمره"), and key sheets open with
    // کلید/پاسخنامه at LINE START. Instruction mentions ("…در پاسخنامه
    // بنویسید", "پاسخها … در پاسخنامه") never start a line with the word and
    // must NOT truncate the exam (#qu2 wave-2 lesson — the earlier loose test
    // cut whole papers at the mention and regressed the pass-1 corpus).
    const t = nfkc.trim();
    const isBanner =
      /ردیف\s*راهنما|راهنمای\s*تصحیح|راهنمای\s*نمره/.test(nfkc) ||
      /^(?:کلید|کلیذ)\s*س|^پاسخنامه|^پاسخ\s*نامه\s|^پاسخ\s*برگ\s*$/.test(t);
    if (isBanner) {
      return offset;
    }
    offset += line.length + 1;
  }
  // Banner-less key pages (#qu2 wave 4, pc4i517871): the answer sheet opens
  // with page furniture ("SCORE", "1 | P a g e", "20 : Total") and repeats
  // the section banners as "1. Listening" — then answers print as SHORT
  // numbered rows ("8- hearing") with no blanks. All three signals together
  // only ever occur on a key page; the exam body's own banners are bare
  // letters or instruction rows, never this trio.
  for (let i = 8; i < lines.length - 4; i++) {
    const t = lines[i].trim();
    const furniture =
      /^SCORE\s*$/i.test(t) ||
      /^\d{1,2}\s*\|\s*P\s*a\s*g\s*e\s*$/i.test(t) ||
      /^\d{1,2}\s*:\s*Total\s*$/i.test(t) ||
      /^جمع\s*بارم/.test(t);
    if (!furniture) continue;
    let bannerAt = -1;
    for (let k = i + 1; k <= Math.min(lines.length - 1, i + 4); k++) {
      if (/^\s*(?:\d{1,2}|[IVX]+)\s*[.:]\s*(?:Listening|Vocabulary|Grammar|Writing|Reading)\b/i.test(lines[k])) {
        bannerAt = k;
        break;
      }
    }
    if (bannerAt < 0) continue;
    let answerRows = 0;
    for (let k = bannerAt + 1; k <= Math.min(lines.length - 1, bannerAt + 12); k++) {
      const kt = lines[k].trim();
      if (/^\d{1,2}\s*[-–—)]\s*[^\s].{0,60}$/.test(kt) && !/(\.{3,}|…+|_{2,})/.test(kt)) answerRows++;
    }
    if (answerRows >= 2) {
      // cut at the furniture line — everything from there is the key sheet
      let cut = 0;
      for (let k = 0; k < i; k++) cut += lines[k].length + 1;
      return cut;
    }
  }
  // Banner-less AND furniture-less kanoon key (#qu2 wave R4, pt7kkv4576):
  // kanoon papers append the key directly after the last question — a bare
  // skill label ("Listening"), then DENSE short-answer rows that RESTART the
  // numbering ("1 . b. False  2 . a. True", "5 . a  6. d"), then a textbook
  // digest. No banner, no page furniture — the old detectors sailed past and
  // the key + textbook parsed as duplicate sections (117 "questions" for a
  // 64-question paper). Signature (ALL required, each one alone is common in
  // real exam tails):
  //   1. >= 4 DENSE rows: >=2 "N." number markers on one line, NO blank
  //      markers, NO "?" (answer rows are answers, never prompts);
  //   2. >= 1 bare skill label inside the window;
  //   3. NUMBERING RESTART: the window's first row starts at <= 5 while the
  //      exam BEFORE the window already printed a number >= 12 — a real exam
  //      tail never rewinds to 1 (two-marker prose lines continue upward);
  //   4. density: the window stays key-shaped (duds bounded).
  {
    const isDenseKeyRow = (l: string) => {
      if (/\.{3,}|…|_{2,}|\?|؟/.test(l)) return false;
      const nums = l.match(/(?:^|\s)\d{1,3}\s*[.،)]/g);
      return !!nums && nums.length >= 2 && l.split(/\s+/).length <= 40;
    };
    const isBareSkillLabel = (l: string) =>
      /^(?:Listening|Speaking|Reading|Writing|Vocabulary|Grammar|Language Function|Pronunciation)\s*$/i.test(l.trim());
    let tailOffset = 0;
    const lineOffsets: number[] = [];
    for (const l of lines) lineOffsets.push(tailOffset), (tailOffset += l.length + 1);
    for (let i = 8; i < lines.length - 4; i++) {
      const winEnd = Math.min(lines.length, i + 45);
      let dense = 0;
      let labels = 0;
      let duds = 0;
      let firstRowNum = Infinity;
      let firstDenseLine = -1;
      let lastDenseLine = -2;
      let maxRun = 0;
      for (let k = i; k < winEnd; k++) {
        const t = lines[k].trim();
        if (!t) continue;
        if (isBareSkillLabel(t)) {
          labels++;
          continue;
        }
        if (isDenseKeyRow(t)) {
          dense++;
          if (firstDenseLine < 0) {
            firstDenseLine = k;
            const m = t.match(/^(\d{1,3})\s*[.،)]/);
            if (m) firstRowNum = parseInt(m[1], 10);
          }
          // the key packs its rows back-to-back; exam-body two-marker prose
          // lines are isolated — require a run of >=3 dense rows within any
          // 6-line span somewhere in the window
          maxRun = k - lastDenseLine <= 6 ? maxRun + 1 : 1;
          lastDenseLine = k;
          continue;
        }
        duds++;
      }
      if (dense < 4 || maxRun < 3 || labels < 1 || duds > dense + labels) continue;
      if (firstRowNum > 5) continue; // no restart — an exam tail, not a key
      // the exam BEFORE the window must have run well past the restart point
      let ran = false;
      for (let k = 0; k < i; k++) {
        const m = lines[k].match(/(?:^|\s)(\d{1,3})\s*[.،)]\s*\S/);
        if (m && parseInt(m[1], 10) >= 12) {
          ran = true;
          break;
        }
      }
      if (!ran) continue;
      // cut at the FIRST DENSE ROW (never at the window start — the window
      // may open on exam content); a bare skill label directly above it
      // ("Listening" heading the key) is the printed key header.
      let cutAt = firstDenseLine;
      if (cutAt > 0 && isBareSkillLabel(lines[cutAt - 1].trim())) cutAt -= 1;
      return lineOffsets[cutAt];
    }
  }
  // Bare-slot answer GRIDS (R5, p4t7882699): the answer sheet repeats the
  // section banners ("A. Vocabulary") above rows of EMPTY numbered slots
  // ("1-  2-  3-", "30- ……"), then the admin banner + OCR debris repeat. The
  // grid's phantom numbers collided with the real numbering chain and shredded
  // the parse (−100). Cut at the REPEATED banner when everything after it is
  // slot rows / dotted write-in space / banners / furniture — no real stem
  // ever prints again.
  {
    const isGridRow = (l: string) => {
      const t = l.trim();
      if (!t) return false;
      if (/^\s*(?:\d{1,3}\s*[-–—]\s*){2,}$/.test(t)) return true; // "1-  2-  3-"
      if (/^\s*\d{1,3}\s*[-–—]\s*[.…_\u2026]*\s*$/.test(t)) return true; // "30- ……"
      return false;
    };
    const isRealStemRow = (l: string) => {
      const m = l.trim().match(/^\s*\d{1,3}\s*[-–—)]\s*(\S.*)$/);
      if (!m) return false;
      if (/^[.…_\u2026\s]+$/.test(m[1])) return false;
      // Answer rows on the sheet after the grid ("5- lonqevitY",
      // "1- re F\<-cU") are letterish but SHORT — one or two answer tokens.
      // Real stems run 4+ words and are letter-dominant.
      const words = m[1].split(/\s+/).filter(Boolean);
      if (words.length < 4) return false;
      const letters = m[1].replace(/[^A-Za-z\u0600-\u06FF]/g, '');
      if (letters.length < 3) return false;
      return letters.length / m[1].length >= 0.7;
    };
    const isSubjectBanner = (l: string) =>
      /^\s*(?:\d{1,2}\s*)?[A-D][.\-–]\s*(?:Listening|Vocabulary|Grammar|Reading|Writing)\b/i.test(l.trim());
    const bannerKey = (l: string) =>
      l.trim().normalize('NFKC').toLowerCase().replace(/^\d{1,2}\s*/, '');
    const lineOffsets: number[] = [];
    let off = 0;
    for (const l of lines) {
      lineOffsets.push(off);
      off += l.length + 1;
    }
    for (let i = 10; i < lines.length - 4; i++) {
      if (!isSubjectBanner(lines[i])) continue;
      const key = bannerKey(lines[i]);
      let repeated = false;
      for (let k = 0; k < i - 3; k++) {
        if (isSubjectBanner(lines[k]) && bannerKey(lines[k]) === key) {
          repeated = true;
          break;
        }
      }
      if (!repeated) continue;
      let firstGrid = -1;
      for (let k = i + 1; k < Math.min(lines.length, i + 6); k++) {
        if (isGridRow(lines[k])) {
          firstGrid = k;
          break;
        }
        const t = lines[k].trim();
        if (!t || /^(?:good\s*luck|www-kanoon-ir|true\s*\/\s*false)\s*$/i.test(t)) continue;
        break;
      }
      if (firstGrid < 0) continue;
      let total = 0;
      let realAfter = false;
      for (let k = firstGrid; k < lines.length; k++) {
        if (isGridRow(lines[k])) {
          total++;
          continue;
        }
        if (isRealStemRow(lines[k])) {
          realAfter = true;
          break;
        }
      }
      if (total < 5 || realAfter) continue;
      return lineOffsets[i];
    }
  }
  return -1;
}

interface RadifRung { line: number; id: string; ord: number }

/** Collects the longest strictly increasing ردیف rung ladder (skips kept). */
function collectRadifLadder(lines: string[], scanEnd: number): { ladder: RadifRung[] } | null {
  const isStandaloneNumber = (l: string) => /^\.?\d{1,2}(?:\s*\/\s*\d{1,2})?(?:[.,]\d{1,2})?$/.test(l.trim());
  const parseMark = (s: string): number | null => {
    const t = s.trim();
    let m = t.match(/^(\d{1,2})\s*\/\s*(\d{1,2})$/);
    if (m) return Math.round((parseInt(m[2], 10) + parseInt(m[1], 10) / Math.pow(10, m[1].length)) * 100) / 100;
    m = t.match(/^(\d{1,2})(?:[.,](\d{1,2}))?$/);
    if (m) return Math.round((parseInt(m[1], 10) + (m[2] ? parseInt(m[2], 10) / Math.pow(10, m[2].length) : 0)) * 100) / 100;
    return null;
  };
  const nearPageMarker = (idx: number): boolean => {
    for (let k = Math.max(0, idx - 2); k <= Math.min(lines.length - 1, idx + 2); k++) {
      if (/صفحه\s+\d+\s+از|^\d+\s*\|\s*P\s*a\s*g\s*e/i.test(lines[k].normalize('NFKC'))) return true;
    }
    return false;
  };
  const numeric: RadifRung[] = [];
  const persian: RadifRung[] = [];
  for (let i = 0; i < scanEnd; i++) {
    const t = lines[i].trim();
    if (isStandaloneNumber(t)) {
      const v = parseMark(t);
      // No page-marker exclusion here: the ردیف ۱ cell often extracts right
      // beside the "صفحه 1 از 5" footer band, and page numbers themselves can
      // never out-chain a real 1..N ladder (they repeat, the LIS ignores them).
      if (v !== null && Number.isInteger(v) && v >= 1 && v <= 30) {
        numeric.push({ line: i, id: String(v), ord: v });
      }
    } else if (PERSIAN_ROW_ORDINALS.includes(t)) {
      persian.push({ line: i, id: t, ord: PERSIAN_ROW_ORDINALS.indexOf(t) + 1 });
    } else {
      // Fused rung: bidi splits a two-digit ردیف into spaced single digits
      // ("1 4" = 14, "1 2" = 12) on its own line. Question rows never look
      // like this, and the ladder continuation check filters false fusions.
      const fused = t.match(/^(\d)\s+(\d)$/);
      if (fused) {
        const v = parseInt(fused[1] + fused[2], 10);
        if (v >= 10 && v <= 30) numeric.push({ line: i, id: String(v), ord: v });
      } else {
        // Inline rung: "3 دانش آموزان عزیز…" — the ردیف number fused with its
        // instruction (pdf table cells on one extracted line). Question rows
        // ("1. …", "1 - …") start with punctuation and never match.
        const m = t.match(/^(\d{1,2})\s+(?!\.?\s*$)(\S.*)$/);
        if (m && !/^[\.\):\-–—]/.test(m[2])) {
          const v = parseInt(m[1], 10);
          if (v >= 1 && v <= 30) numeric.push({ line: i, id: String(v), ord: v });
        }
      }
    }
  }
  const questionRowRe = /^\s*\d{1,3}\s*[.)-]\s*\S/;
  const adjacencyScore = (ladder: RadifRung[]): number =>
    ladder.reduce((score, r) => {
      // The ردیف cell is a margin column: real rungs sit next to the row's
      // question content. Stray numbers (page indices, a first mark cell)
      // sit next to furniture/watermarks. Score = rungs with question rows
      // within 4 lines ABOVE them.
      for (let k = r.line - 1; k >= Math.max(0, r.line - 4); k--) {
        const t = lines[k].trim();
        if (!t || isFurnitureLine(t)) continue;
        if (questionRowRe.test(t)) return score + 1;
        break;
      }
      return score;
    }, 0);
  const longestOf = (cands: RadifRung[]): RadifRung[] | null => {
    if (cands.length === 0) return null;
    const bestLen = new Array(cands.length).fill(1);
    for (let i = 0; i < cands.length; i++) {
      for (let j = 0; j < i; j++) {
        if (cands[j].ord < cands[i].ord && bestLen[j] + 1 > bestLen[i]) {
          bestLen[i] = bestLen[j] + 1;
        }
      }
    }
    let maxLen = 0;
    for (let i = 0; i < cands.length; i++) if (bestLen[i] > maxLen) maxLen = bestLen[i];
    if (!(maxLen >= 4)) return null;
    // Length-tied ladders happen when page numbers / the first mark cell can
    // replace the true rungs 1..2 (the kanoon closer layout puts the radif
    // cell AFTER the row it closes, so a leading page "1" + mark "2" build a
    // parallel 20-chain). Tie-break: the ladder whose rungs actually sit
    // next to question rows.
    // R4 predecessor disambiguation: the ردیف column and the بارم column are
    // BOTH standalone-number candidate pools, and the old single-valued
    // prevIdx kept the EARLIEST equal-length predecessor — a mark cell
    // ("2" printed under row 1's label) claimed the slot the true rung 2
    // should hold, so the pure rung chain was never reconstructed and every
    // boundary shifted by the mark offsets (pkc61/pd24nl/pc8er: rows merged,
    // sections emptied). Rebuild each max-length chain by walking backward
    // and preferring, at EVERY step, the predecessor that hugs question rows
    // (rung DNA); equal adjacency -> the later line (rungs trail their row's
    // content; page numbers/labels sit above it).
    const unitAdj = (r: RadifRung): number => adjacencyScore([r]);
    const pickPrev = (i: number): number => {
      let bestJ = -1;
      let bestAdj = -1;
      for (let j = 0; j < i; j++) {
        if (cands[j].ord < cands[i].ord && bestLen[j] === bestLen[i] - 1) {
          const a = unitAdj(cands[j]);
          if (a > bestAdj || (a === bestAdj && bestJ >= 0 && j > bestJ)) {
            bestAdj = a;
            bestJ = j;
          }
        }
      }
      return bestJ;
    };
    let best: RadifRung[] | null = null;
    let bestScore = -1;
    for (let tail = 0; tail < cands.length; tail++) {
      if (bestLen[tail] !== maxLen) continue;
      const ladder: RadifRung[] = [];
      let i = tail;
      while (i >= 0) {
        ladder.unshift(cands[i]);
        i = pickPrev(i);
      }
      const score = adjacencyScore(ladder);
      if (score > bestScore) { bestScore = score; best = ladder; }
    }
    return best;
  };
  // Single-alphabet ladders only: a Persian letter rung and a bare number
  // both continue the sequence, and letting them mix lets a row's MARK
  // displace the real letter rung (ب lost to its own بارم "2").
  const persianLadder = longestOf(persian);
  const numericLadder = longestOf(numeric);
  const pLen = persianLadder ? persianLadder.length : 0;
  const nLen = numericLadder ? numericLadder.length : 0;
  const ladder = pLen >= nLen ? persianLadder : numericLadder;
  if (!ladder) return null;
  if (process.env.DEBUG_RADIF) console.log('[radif] ladder', ladder.map((r) => `${r.id}@${r.line}`).join(' '));
  return { ladder };
}

/**
 * ردیف-table genre, second wave (#qu2 golden pass 2).
 * Official/national finals and Kanoon d11/d12 papers lay the exam out as a
 * table | ردیف | سؤالات | نمره | whose ROWS are numbered 1..N (or lettered
 * الف ب پ ت…). Extractors emit each row's cells as standalone lines in
 * varying orders (the ردیف number may precede or follow its content), so a
 * per-row state machine misfires. Instead this splitter:
 *   1. collects standalone-number lines (and Persian ordinal letters),
 *   2. finds the LONGEST strictly increasing rung subsequence 1,2,…,N
 *      (printed skips are kept — the printed number IS the row id),
 *   3. spans each row from its rung line to the next rung (opener style —
 *      pdf.js emits the ردیف cell first for these papers), with a mark
 *      fallback that looks back before the rung for closer-style rows,
 *   4. reads the row's mark from the remaining standalone numbers in range
 *      (bidi decimals "5 / 1" = 1.5, page-number debris excluded),
 *   5. names the category from Latin subject labels inside the row.
 * Validation (>=4 rungs starting at 1/الف, plausible mark sum, real question
 * rows) returns null so the other splitters take over when the genre
 * doesn't apply.
 */
const PERSIAN_ROW_ORDINALS = [
  'الف', 'ب', 'پ', 'ت', 'ث', 'ج', 'چ', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'ژ',
  'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ک', 'گ', 'ل', 'م',
  'ن', 'و', 'ه', 'ی',
];

/**
 * Printed page/brand furniture (R2). Kanoon/national papers repeat a header
 * block on every page and a watermark + continuation marker in the margin;
 * extraction interleaves them with the questions. Nothing in these lines is
 * ever exam content: the question seeder refuses them as stems, and the
 * radif closer-style spans strip them before parsing.
 * Persian words are composed from hex codepoints (fa) — bidi editors reorder
 * typed Persian regex literals, and the lam-alef extraction scramble
 * (لا -> ال) is tolerated by faPat.
 */
const fa = (hex: string): string =>
  String.fromCodePoint(...hex.split(' ').map((h) => parseInt(h, 16)));
const faPat = (hex: string): string =>
  fa(hex).replace(/\u0644\u0627/g, '[\\u0644\\u0627]{2}');
const SW_Q = '(?:' + faPat('633 648 627 644 627 62a') + '|' + faPat('633 624 627 644 627 62a') + ')';
const KANOON_FURNITURE_RES: RegExp[] = [
  new RegExp(fa('627 62f 627 645 647') + '\\s*' + SW_Q + '[\\u0600-\\u06FF]{0,4}\\s*' + fa('62f 631') + '\\s*' + fa('635 641 62d 647')), // ادامه سوالات در صفحه N
  /www[\s.-]*kanoon[\s.-]*ir/i,                 // margin watermark
  new RegExp('^' + fa('62a 639 62f 627 62f') + '\\s*(?:' + fa('6a9 644') + '\\s*)?' + fa('635 641 62d 627 62a')), // تعداد (کل) صفحات
  new RegExp('^' + fa('645 62f 62a') + '\\s*(?:' + fa('622 632 645 648 646') + '|' + fa('627 645 62a 62d 627 646') + '|' + fa('67e 627 633 62e 6af 648 6cc') + ')'), // مدت آزمون/امتحان/پاسخگویی
  new RegExp('^' + fa('633 627 639 62a') + '\\s*' + fa('634 631 648 639')), // ساعت شروع
  new RegExp('^' + fa('627 62f 627 631 647') + '\\s*(?:' + fa('627 645 648 632 634') + '|' + fa('622 645 648 632 634') + '|' + fa('6a9 644') + ')'), // اداره آموزش/اموزش/کل
  new RegExp('^' + SW_Q + '\\s*\\('),        // سوالات (پاسخ نامه دارد)
  new RegExp(fa('62c 645 639') + '\\s*(?:' + fa('646 645 631 627 62a') + '|' + fa('628 627 631 645') + ')'), // جمع نمرات/بارم
  /^Good\s*luck\b/i,                            // farewell tail
  /^Take\s*a\s*taxi\b/i,                       // farewell tail
  new RegExp(fa('628 633 62a 647') + '\\s*' + fa('62c 647 634') + '|' + fa('62c 647 634') + '\\s*' + fa('6a9 627 646 648 646')), // kanoon ad banner
  new RegExp(fa('646 627 645') + '\\s*' + fa('62f 631 633') + '|' + fa('646 627 645') + '\\s*' + fa('62f 628 6cc 631') + '|' + fa('646 627 645') + '\\s*' + fa('62e 627 646 648 627 62f 6af') + '|' + fa('62a 627 631 6cc 62e') + '\\s*' + fa('627 645 62a 62d 627 646') + '|' + fa('633 627 644') + '\\s*' + fa('62a 62d 635 6cc 644 6cc') + '|' + fa('634 645 627 631 647') + '\\s*' + fa('635 646 62f 644 6cc') + '|' + fa('634 645 627 631 647') + '\\s*' + fa('6a9 627 631 62a') + '|' + fa('646 627 645') + '\\s*' + fa('67e 62f 631') + '|' + fa('645 62d 644') + '\\s*' + fa('645 647 631')), // student/teacher header fields
  new RegExp('^' + fa('646 645 631 647') + '\\s*[:؟]?\\s*$|^' + fa('628 627 631 645') + '\\s*[:؟]?\\s*$'), // bare نمره/بارم cells
  new RegExp('^' + fa('622 632 645 648 646') + '\\s*' + fa('62f 631 633') + '|^' + fa('62f 631 633') + '\\s*[:：]'), // آزمون درس / درس:
];

/** Persian imperative-verb suffix (ی + د codepoints — کنید/دهید/بنویسید…)
 *  composed from codepoints because bidi editors scramble typed literals. */
const FA_IMPERATIVE_SUFFIX = new RegExp(fa('6cc 62f'));

/**
 * Whitespace-flexible Persian cue (R3). Kanoon/medu extraction splits
 * letters with spaces ("فا ی ل صوت ی", "شک ل صحیح"), which kills every
 * cue regex whose spaces sit between words only. faFlex composes each
 * codepoint word with \s* between EVERY pair of characters, so the same
 * pattern hits the clean form, the letter-split form, and the fully
 * squashed form. Lam-alef tolerates the extraction order scramble
 * (لا <-> ال) via a two-char class atom.
 * Words are hex groups separated by '|'.
 */
const faFlex = (hexWords: string): RegExp => {
  const atoms: string[] = [];
  const words = hexWords.split('|');
  words.forEach((w, wi) => {
    if (wi > 0) atoms.push('[\\s\\u200c]*');
    const s = faPat(w);
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if ((c === '\u0644' && s[i + 1] === '\u0627') || (c === '\u0627' && s[i + 1] === '\u0644')) {
        atoms.push('[\\u0644\\u0627]{2}');
        i++;
        continue;
      }
      atoms.push(c);
      if (i < s.length - 1) atoms.push('\\s*');
    }
  });
  return new RegExp(atoms.join(''));
};

// --- R3 instruction-contract cues (whitespace-flexible) ---------------------
// The corpus prints its task contracts; these cues read them. All Persian
// patterns are codepoint-composed (bidi-authoring hazard) and whitespace-
// flexible (letter-split extraction hazard).
const R3_LISTEN_CUES: RegExp[] = [
  faFlex('6af 648 634|62f 647 6cc 62d'),                    // گوش دهید
  faFlex('641 627 6cc 644|635 648 62a 6cc'),                // فایل صوتی
  faFlex('634 646 6cc 62f 627 631 6cc'),                    // شنیداری
  faFlex('62e 648 627 647 6cc 62f|634 646 6cc 62f'),        // خواهید شنید
];
const R3_FORM_CONTRACT: RegExp = new RegExp(
  faFlex('634 6a9 644|635 62d 6cc 62d').source + '[\\s\\S]{0,60}?' + faFlex('67e 631 627 646 62a 632').source, // شکل صحیح … پرانتز
);
const R3_SENT_CONTRACT: RegExp[] = [
  new RegExp(faFlex('6a9 644 645 627 62a|6a9 644 645 647').source + '[\\s\\S]{0,50}?' + faFlex('62c 645 644 647').source + '[\\s\\S]{0,50}?(?:' + faFlex('628 646 648 6cc 633 6cc 62f').source + '|' + faFlex('628 633 627 632 6cc 62f').source + ')'), // کلمات … جمله … بنویسید/بسازید
  /make\s+a\s+(?:correct\s+|meaningful\s+|single\s+)?sentence/i,
  /build\s+a\s+sentence/i,
];
const R3_PICTURE_CONTRACT: RegExp[] = [
  new RegExp(faFlex('628 647 62a 648 62c 647|628 627 62a 648 62c 647').source + '[\\s\\S]{0,40}?' + faFlex('62a 635 627 648 6cc 631|62a 635 648 6cc 631').source), // با توجه به تصاویر/تصویر
  new RegExp(faFlex('62a 635 627 648 6cc 631|62a 635 648 6cc 631').source + '[\\s\\S]{0,30}?(?:' + faFlex('645 631 628 648 637').source + '|' + faFlex('62c 641 62a').source + '|' + faFlex('627 646 62a 62e 627 628').source + ')'), // تصاویر … مربوط/جفت/انتخاب
  /for\s+each\s+picture|based\s+on\s+(?:the\s+)?pictures?|pictures?\s+(?:with|to)\s+(?:the\s+)?sentences?/i,
];
const R3_CONJ_CONTRACT: RegExp[] = [
  new RegExp(faFlex('62d 631 648 641').source + '[\\s\\S]{0,20}?' + faFlex('631 628 637').source), // حروف ربط
  new RegExp(faFlex('6a9 644 645 647').source + '[\\s\\S]{0,20}?' + faFlex('627 62a 635 627 644').source), // کلمه … اتصال
  /\(\s*(?:or|but|so|and)\s*[,/|]\s*(?:or|but|so|and)/i,
];
const R3_ORTHO_ERROR: RegExp = faFlex('627 634 62a 628 627 647|646 6af 627 631 634 6cc'); // اشتباه نگارشی
const R3_ANSWER_CONTRACT: RegExp[] = [
  new RegExp(faFlex('628 647').source + '[\\s\\u200c]*' + faFlex('633 648 627 644 627 62a|633 624 644 627 62a').source + '[\\s\\S]{0,20}?' + faFlex('67e 627 633 62e').source), // به سوالات … پاسخ
  new RegExp(faFlex('67e 627 633 62e').source + '[\\s\\S]{0,16}?' + faFlex('62f 647 6cc 62f').source), // پاسخ … دهید (co-occurrence — پاسخنامه must NOT fire alone)
  /answer\s+the\s+(?:following\s+)?questions?/i,
];
const R3_LISTEN_BLOCKER: RegExp[] = R3_LISTEN_CUES;

/** A bare printed skill-label line: "Vocabulary", "Grammar (3 points)",
 *  "2 Writing", optional row-letter prefix. Latin only — kanoon/medu print
 *  the part labels in English even on Persian papers. */
const R3_SKILL_LABEL_LINE =
  /^(?:[A-Za-z\u0600-\u06FF]{1,3}[\).\-]\s*)?(?:\d{1,3}\s+)?(Vocabulary|Grammar|Reading|Writing|Listening)\s*(?:\(\s*[\d.]+\s*(?:points?|marks?|pts?)?\s*\)|[:\d.\s]*)?$/;

function r3CanonLabelCat(word: string): 'Listening' | 'Vocabulary' | 'Grammar' | 'Writing' | 'Reading' | null {
  const w = word.toLowerCase();
  if (w === 'vocabulary') return 'Vocabulary';
  if (w === 'grammar') return 'Grammar';
  if (w === 'reading') return 'Reading';
  if (w === 'writing') return 'Writing';
  if (w === 'listening') return 'Listening';
  return null;
}

function r3HitAny(text: string, res: RegExp[]): boolean {
  return res.some((re) => re.test(text));
}

/**
 * Printed skill-label oracle (R3). Kanoon/medu papers print the part label
 * ("Vocabulary", "Grammar (3 points)", "2 Writing") on its own line at every
 * part boundary — the sheet literally names the category. A label among a
 * block's LEADING lines stamps that block (printed evidence outranks derived
 * cues, same principle as the radif oracle); a label in the block's TAIL
 * belongs to the NEXT section (extraction appends the next opener) — it is
 * handed forward and removed from this block's text.
 */
function stampPrintedSkillLabels(blocks: RawSectionBlock[]): void {
  let carry: { cat: ReturnType<typeof r3CanonLabelCat>; text: string } | null = null;
  for (const b of blocks) {
    const lines = b.text.split('\n').map((l) => l.replace(/[\u200E\u200F]/g, '').trim());
    const nonEmpty: { i: number; t: string }[] = [];
    lines.forEach((t, i) => { if (t) nonEmpty.push({ i, t }); });
    // (a) incoming hand-off from the previous block's tail
    let stampedCat: ReturnType<typeof r3CanonLabelCat> = null;
    if (carry && carry.cat) stampedCat = carry.cat;
    // (b) own leading label (first 3 non-empty lines)
    let leadLabel: { cat: ReturnType<typeof r3CanonLabelCat>; idx: number } | null = null;
    for (let k = 0; k < Math.min(3, nonEmpty.length); k++) {
      const m = R3_SKILL_LABEL_LINE.exec(nonEmpty[k].t);
      if (m) {
        const cat = r3CanonLabelCat(m[1]);
        if (cat) { leadLabel = { cat, idx: nonEmpty[k].i }; break; }
      }
    }
    if (leadLabel) stampedCat = leadLabel.cat;
    if (stampedCat) {
      b.category = stampedCat;
      b.labelCategory = true;
    }
    // (c) trailing label → belongs to the NEXT block; strip it from here
    carry = null;
    if (nonEmpty.length >= 2) {
      for (let k = nonEmpty.length - 1; k >= Math.max(0, nonEmpty.length - 2); k--) {
        const m = R3_SKILL_LABEL_LINE.exec(nonEmpty[k].t);
        if (m) {
          const cat = r3CanonLabelCat(m[1]);
          if (cat && (!leadLabel || nonEmpty[k].i !== leadLabel.idx)) {
            carry = { cat, text: nonEmpty[k].t };
            const kept = lines.filter((_, i) => i !== nonEmpty[k].i);
            b.text = kept.join('\n');
          }
          break;
        }
      }
    }
  }
}

function isFurnitureLine(raw: string): boolean {
  const t = raw.trim();
  if (!t) return false;
  const nf = t.normalize('NFKC');
  // Second probe with ALL whitespace removed: kanoon extraction splits
  // letters with spaces ("تاری خ امتحان", "فا ی ل") and header phrases must
  // still match; the patterns' own \s* also make the normal form hit.
  const sq = nf.replace(/\s+/g, '');
  return KANOON_FURNITURE_RES.some((re) => re.test(nf) || re.test(sq));
}

/** Persian/English directive line (an instruction, not a question row). */
function looksLikeInstructionLine(raw: string): boolean {
  const t = raw.normalize('NFKC').replace(/[\u200E\u200F\u202A-\u202E\u2066-\u2069]/g, '').trim();
  if (!t || isFurnitureLine(t)) return false;
  if (/^[\u0600-\u06FF]/.test(t)) {
    const faChars = (t.match(/[\u0600-\u06FF]/g) ?? []).length;
    // A question row never starts with Persian AND keeps a Latin stem after
    // it; directives do ("دانش آموزان عزیز به فایل صوتی گوش کنید…").
    return faChars >= 6 && !/^\s*\d{1,3}\s*[-.).]/.test(t);
  }
  // Latin imperatives that open blocks ("Complete the sentences with…").
  return /^(Complete|Choose|Fill|Match|Read|Write|Circle|Put|Unscramble|Answer|Listen|Select|Find|Change|Specify|Make|Spell|Use)\b/i.test(t);
}

/** True when the doc's dominant radif ladder is the Persian-letter one. */
function ladderIsPersian(lines: string[], scanEnd: number): boolean {
  const probe = collectRadifLadder(lines, scanEnd);
  if (!probe) return false;
  return PERSIAN_ROW_ORDINALS.includes(probe.ladder[0]?.id ?? '');
}

/** Kanoon genre fingerprint (shared by the band-less gate and the guard). */
function kanoonFingerprintLike(lines: string[]): boolean {
  return (
    /kanoon/i.test(lines.join('\n').slice(0, 4000)) ||
    lines.slice(0, 60).some((l) => /پاسخ نامه دارد|شبه نهایی/.test(l.normalize('NFKC')))
  );
}

export function splitRadifNumberedSections(text: string): RawSectionBlock[] | null {
  const lines = text.split(/\r?\n/);
  const nfkc = (l: string) => l.normalize('NFKC');
  // The dispatch already truncated the text at the key-sheet boundary, so no
  // key scan happens here (a loose in-splitter scan once truncated a whole
  // exam on an instruction mention of پاسخنامه).
  const scanEnd = lines.length;

  // ردیف band gate: the three column words extract on one line ("ردیف
  // سؤاالت نمره"), on three bare lines, or with parenthetical noise ("ردیف
  // سؤاالت (پاسخ برگ دارد) نمره") — a contains-test over the top band covers
  // all three. The band words may sit past the header prose (نمره at line
  // 22 on some papers), so the window is 30 lines.
  const head = lines.slice(0, 30).map((l) => nfkc(l).trim());
  const banded =
    head.some((l) => /ردیف/.test(l)) && head.some((l) => /نمره|بارم/.test(l));
  // Lettered papers (A) B) C… headers) keep their letters as the section
  // identity — the radif machine must never steal them even when a ردیف
  // band also exists (the band's bare numbers then feed a junk ladder).
  // DIALOGUE EXCLUSION (#qu2 wave 3): speaker notation "A: …" / "B: …" with
  // LATIN content is question content (matching/dialogue sections), not a
  // section header — five Kanoon radif papers were rejected from their own
  // splitter because their dialogue transcripts tripped this count. Real
  // headers are "A)"/"A." or a colon followed by a PERSIAN instruction.
  // OPTION-LIST EXCLUSION (same wave): MCQ option lines "A. text  B. text"
  // pack SEVERAL letter markers into one line — a real header carries
  // exactly one. p91294y667's reading options were counted as headers and
  // kept its numbered blocks out of their own splitter.
  const letterMarkerCount = (t: string): number => (t.match(/[A-Z][\)\.:]/g) ?? []).length;
  // Tight ladder runs (A→B→C→D on consecutive lines, any of ) . : forms) are
  // option lists / dialogue transcripts — never section headers.
  const tightLetterRun = new Set<number>();
  {
    const lidx: { i: number; ord: number }[] = [];
    lines.forEach((l, i) => {
      const m = l.trim().match(/^([A-Z])[\)\.:]/);
      if (m) lidx.push({ i, ord: m[1].charCodeAt(0) });
    });
    for (let k = 0; k + 1 < lidx.length; k++) {
      if (lidx[k + 1].i - lidx[k].i <= 2 && lidx[k + 1].ord === lidx[k].ord + 1) {
        tightLetterRun.add(lidx[k].i);
        tightLetterRun.add(lidx[k + 1].i);
      }
    }
  }
  const letteredHeaders = lines.filter((l, i) => {
    if (tightLetterRun.has(i)) return false;
    const t = l.trim();
    if (letterMarkerCount(t) !== 1) return false; // 0 = no header, ≥2 = option list
    if (/^[A-Z][\)\.]\s*\S/.test(t)) return true; // A) / A. — strong header forms
    if (/^[A-Z]:\s*[\u0600-\u06FF]/.test(t)) return true; // A: + Persian instruction
    return false; // A: + Latin = dialogue speaker line — content, not a header
  }).length;
  // Band MANDATORY: band-less rhythm acceptance once let a Persian-lettered
  // docx (its section numbers AND mark cells both extract as bare lines)
  // build a junk 1..8 ladder and regress the shipped 30/30 corpus. Papers
  // whose band never extracts (one qu2 scan) fall back to the lettered
  // splitter — a lower score on one file beats a corpus regression.
  if (!banded) {
    // BAND-LESS KANOON NUMBERED BLOCKS (#qu2 wave 3): the d11/d12 shibe-nahaei
    // papers print the same numbered-row table but their band cells often
    // never extract (watermark furniture + "سواالت (پاسخ نامه دارد)" instead
    // of | ردیف | سؤالات | نمره |). The earlier band-less acceptance was
    // REVERTED because a Persian-lettered docx built a junk 1..8 ladder — so
    // this path is gated on the Kanoon genre fingerprint (its watermark or
    // the "(پاسخ نامه دارد)" banner) AND a long ladder starting at 1. The
    // fingerprint docx carries neither, and the shipped-corpus guards
    // (lettered/ladder/first-ord below) still apply on top.
    const kanoonFingerprint =
      /kanoon/i.test(text) ||
      lines.slice(0, 60).some((l) => /پاسخ نامه دارد|شبه نهایی/.test(nfkc(l)));
    const probe = kanoonFingerprint ? collectRadifLadder(lines, scanEnd) : null;
    if (
      !probe ||
      probe.ladder.length < 5 ||
      probe.ladder[0].ord !== 1
    ) {
      if (process.env.DEBUG_RADIF) console.log('[radif] reject: band');
      return null;
    }
  }
  if (letteredHeaders >= 4) { if (process.env.DEBUG_RADIF) console.log('[radif] reject: lettered'); return null; }
  // GENRE RATIO (#qu2 wave 3): the radif machine may only take a paper whose
  // NUMBERED ladder decisively outranks its letter structure. The live case:
  // an answer-book sheet (pu557l5203) carries a stray بارم/ردیف band (line 171
  // — past the 30-line band window, so it also reaches the band-less path)
  // AND real "A: …" section headers — its numeric marks built a small LIS (5)
  // equal to its letter LIS (5), and the radif splitter stole it (-69.6% ->
  // -280%). Rule, applied on BOTH paths: numeric ladder length must be
  // >= 1.5x the longest letter run (ties and near-ties go to the lettered
  // splitter). Radif papers run 10-20 rows against dialogue-noise letter runs
  // of 2-3, so they clear it easily.
  const letterOrdinals: number[] = [];
  for (const l of lines) {
    const m = l.trim().match(/^([A-Z])[\)\.:]\s*\S/);
    if (m) letterOrdinals.push(m[1].charCodeAt(0));
  }
  const lb = new Array(letterOrdinals.length).fill(1);
  let letterLis = 0;
  for (let i = 0; i < letterOrdinals.length; i++) {
    for (let j = 0; j < i; j++) {
      if (letterOrdinals[j] < letterOrdinals[i] && lb[j] + 1 > lb[i]) lb[i] = lb[j] + 1;
    }
    if (lb[i] > letterLis) letterLis = lb[i];
  }
  const probeLadder = collectRadifLadder(lines, scanEnd);
  const numericLen = probeLadder ? probeLadder.ladder.length : 0;
  if (numericLen < Math.ceil(letterLis * 1.5)) {
    if (process.env.DEBUG_RADIF) console.log('[radif] reject: genre ratio', numericLen, 'vs', letterLis);
    return null;
  }
  // Long strictly-increasing letter ladder (A..H and beyond, no resets) means
  // the LETTERS are the section identity of this paper — the lettered
  // splitter must keep it. Sub-part letters inside radif rows (dialogue
  // A./B./C. prompts) restart every few rows, so their longest run stays
  // short and never trips this guard. EXCEPTION (R2): a banded Persian paper
  // whose ladder itself is the Persian-letter rungs (الف ب پ ت…) trips the
  // distinct-letter count — there the bare letters ARE the radif cells, not
  // section headers. Only the LATIN ladder keeps its veto.
  const bestLetterRun = longestLetterHeaderLadder(lines);
  const persianRungLadder = ladderIsPersian(lines, scanEnd);
  if (bestLetterRun >= 8 && !(persianRungLadder && (banded || kanoonFingerprintLike(lines)))) {
    if (process.env.DEBUG_RADIF) console.log('[radif] reject: letter ladder', bestLetterRun); return null;
  }

  // Mark readers for the row spans (same shapes as the ladder collector).
  const isStandaloneNumber = (l: string) => /^\.?\d{1,2}(?:\s*\/\s*\d{1,2})?(?:[.,]\d{1,2})?$/.test(l.trim());
  const parseMark = (s: string): number | null => {
    const t = s.trim();
    let m = t.match(/^(\d{1,2})\s*\/\s*(\d{1,2})$/); // bidi decimal "5 / 1" = 1.5
    if (m) return Math.round((parseInt(m[2], 10) + parseInt(m[1], 10) / Math.pow(10, m[1].length)) * 100) / 100;
    m = t.match(/^(\d{1,2})(?:[.,](\d{1,2}))?$/);
    if (m) return Math.round((parseInt(m[1], 10) + (m[2] ? parseInt(m[2], 10) / Math.pow(10, m[2].length) : 0)) * 100) / 100;
    return null;
  };

  const picked = collectRadifLadder(lines, scanEnd);
  if (!picked) { if (process.env.DEBUG_RADIF) console.log('[radif] reject: ladder len'); return null; }
  const ladder = picked.ladder;
  if (ladder[0].ord > 2) { if (process.env.DEBUG_RADIF) console.log('[radif] reject: first ord', ladder[0].ord); return null; }

  // Latin subject labels inside a row name its category (carry forward —
  // papers label only the first row of each subject group). The label may be
  // FUSED with the rung number ("17 Grammar") — strip a leading row number
  // before testing, and only then does the label count as printed (pin).
  const labelCat = (t: string): RawSectionBlock['category'] | '' => {
    const s = t.replace(/^\d{1,2}\s+/, '');
    if (/^listening\b|شنیداری/i.test(s)) return 'Listening';
    if (/^vocabulary\b|واژگان/i.test(s)) return 'Vocabulary';
    if (/^grammar\b|دستور/i.test(s)) return 'Grammar';
    if (/^reading\b/i.test(s)) return 'Reading';
    if (/^writing\b|نگارش/i.test(s)) return 'Writing';
    return '';
  };
  const isSubjectLabel = (t: string): boolean => !!labelCat(nfkc(t).trim());

  // ── R2: CLOSER-STYLE kanoon layout ────────────────────────────────────
  // Two extraction orders exist for the same printed table. Opener style
  // (pdf.js cell order, d11/d12 papers):  [ردیف N][instruction][content][بارم N]
  // Closer style (kanoon qu2 papers):     [content N][ردیف N][بارم N+1][header?][instruction N+1]
  // — the radif cell CLOSES its row, and the NEXT row's mark + header +
  // instruction follow immediately. A rung-anchored span split therefore
  // shifts every block by one section. Detector: rungs whose next substantive
  // line is an instruction vote OPENER; rungs whose next substantive line is
  // a mark cell that is itself followed by a label/instruction vote CLOSER.
  const ladderLines = new Set(ladder.map((r) => r.line));
  const substantiveAfter = (i: number): number => {
    for (let k = i + 1; k < scanEnd; k++) {
      const t = lines[k].trim();
      if (!t || isFurnitureLine(t)) continue;
      return k;
    }
    return -1;
  };
  let closerVotes = 0;
  let openerVotes = 0;
  for (const r of ladder) {
    const nxt = substantiveAfter(r.line);
    if (nxt < 0) continue;
    const t = lines[nxt].trim();
    if (isStandaloneNumber(t) && !ladderLines.has(nxt)) {
      const after = substantiveAfter(nxt);
      if (after >= 0 && after <= nxt + 2 && !ladderLines.has(after)) {
        const t2 = lines[after].trim();
        if (looksLikeInstructionLine(t2) || isSubjectLabel(t2)) closerVotes++;
      }
    } else if (!ladderLines.has(nxt) && (looksLikeInstructionLine(t) || isSubjectLabel(t))) {
      openerVotes++;
    }
  }
  const closerStyle = closerVotes >= 4 && closerVotes > openerVotes;
  if (process.env.DEBUG_RADIF) console.log('[radif] style votes closer', closerVotes, 'opener', openerVotes);
  if (closerStyle) {
    // Signature = [بارم cell][subject label?][instruction] — every closer
    // section opens with one, in document order. NO ladder exclusion here:
    // in the closer layout the next row's mark cell sits exactly where an
    // opener-style rung would sit, so the LIS may claim a mark as a rung —
    // excluding ladder lines would drop real signatures and shift every
    // block. Non-mark numbers (page indices) fail the adjacency/content
    // test on their own; opener-genre rungs are protected by the vote gate
    // above and by the trailing-mark override below.
    interface Sig { line: number; mark: number }
    // R5 gate repair: the closer signature scan missed two printed shapes and
    // every miss merged a row into its predecessor, shifting all later blocks
    // (the tail section vanished — the golden gate went 27/30).
    const qRowRe = /^\s*\d{1,3}\s*[.)\-]\s*\S/;
    const sigs: Sig[] = [];
    for (let i = 0; i < scanEnd; i++) {
      const t = lines[i].trim();
      // (1) Fused [mark][instruction] cell — kanoon column order concatenates
      // the بارم cell ONTO the instruction line ("1 حروف به هم ریخته را مرتب
      // کرده و در قالب یک کلمه بنویسید."), so no standalone mark line exists
      // and the row never generated a signature (p65o row ت: q6-7 merged
      // upward, د vanished, every later id/mark shifted). Persian-led rests
      // only: Latin "10 Answer…" question rows must not become signatures.
      const fused = t.match(/^(\d{1,2}(?:[.,]\d{1,2})?)\s+([\u0600-\u06FF]\S.*)$/);
      if (fused && !qRowRe.test(t)) {
        const fv = parseMark(fused[1]);
        if (fv !== null && fv >= 0.25 && fv <= 20 && looksLikeInstructionLine(fused[2])) {
          if (process.env.DEBUG_RADIF) console.log('[radif] sig(fused)@', i, 'mark', fv, '->', JSON.stringify(fused[2].slice(0, 40)));
          sigs.push({ line: i, mark: fv });
          continue;
        }
      }
      if (!isStandaloneNumber(t)) continue;
      const v = parseMark(t);
      if (v === null || v < 0.25 || v > 20) continue;
      const nxt = substantiveAfter(i);
      if (nxt < 0 || nxt > i + 5) continue;
      const t2 = lines[nxt].trim();
      if (looksLikeInstructionLine(t2) || isSubjectLabel(t2)) {
        if (process.env.DEBUG_RADIF) console.log('[radif] sig@', i, 'mark', v, '->', JSON.stringify(t2.slice(0, 40)));
        sigs.push({ line: i, mark: v });
        i = nxt; // no overlapping signatures
        continue;
      }
      // (2) Question-line adjacency — commandless rows print [mark][question
      // rows] with NO instruction line, so the instruction-only probe never
      // fired and the row merged into its predecessor (9 مستمر یک row 6:
      // "2" + q14-15 swallowed by row 5; tail section lost). A mark whose
      // next substantive line is a question row IS a signature. Ladder lines
      // are excluded: a rung trails its own content, so its next substantive
      // line is the NEXT row's mark, not a question.
      if (!ladderLines.has(i)) {
        if (qRowRe.test(t2)) {
          if (process.env.DEBUG_RADIF) console.log('[radif] sig(qadj)@', i, 'mark', v, '->', JSON.stringify(t2.slice(0, 40)));
          sigs.push({ line: i, mark: v });
          i = nxt;
          continue;
        }
        // (2b) Lexicon interlude — a word-bank line between the mark and the
        // question rows ("Africa – German – Puzzle - go to library") never
        // generates signatures either; the mark still opens the row.
        const nxt2 = substantiveAfter(nxt);
        if (nxt2 >= 0 && nxt2 <= i + 5 && !ladderLines.has(nxt2) && qRowRe.test(lines[nxt2].trim())) {
          if (process.env.DEBUG_RADIF) console.log('[radif] sig(qadj2)@', i, 'mark', v, '->', JSON.stringify(lines[nxt2].trim().slice(0, 40)));
          sigs.push({ line: i, mark: v });
          i = nxt2;
        }
      }
    }
    const sigOk =
      sigs.length >= 4 &&
      Math.abs(sigs.length - ladder.length) <= 2;
    // R5: only FULL-LENGTH chains (a signature for every rung) may drive the
    // closer build — a short chain means a row's signature is missing and the
    // sig-anchored partition would merge it. Partial chains keep the legacy
    // sig-anchored build below.
    const sigFull = sigs.length >= 4 && sigs.length >= ladder.length;
    if (process.env.DEBUG_RADIF) console.log('[radif] closer sigs', sigs.length, 'ladder', ladder.length, sigFull ? 'FULL' : sigOk ? 'OK' : 'ABORT');
    if (sigFull || sigOk) {
      const isPersianLadder = PERSIAN_ROW_ORDINALS.includes(ladder[0].id);
      const cBlocks: RawSectionBlock[] = [];
      let cCarry: RawSectionBlock['category'] | '' = '';
      // R5: closer construction is RUNG-ANCHORED. The sig chain alone cannot
      // partition the sheet — lexicon/commandless lines never generate
      // signatures, so their lines merged into the predecessor block. The
      // ردیف ladder partitions exactly: rung N closes row N, so row N's
      // block is (rung N-1, rung N]. The signature chain only supplies each
      // block's mark/instruction; sig-less blocks fall back to their first
      // standalone mark cell, and a sig-less mark-less question-less band
      // (Good-luck/footer tail) is furniture, not a row — dropped.
      const useRungs = sigFull;
      const tailStart = useRungs ? ladder[ladder.length - 1].line + 1 : -1;
      const tailText = tailStart >= 0 && tailStart < scanEnd
        ? lines.slice(tailStart, scanEnd).filter((l) => !isFurnitureLine(l)).join('\n')
        : '';
      const tailKept = tailStart >= 0 && tailStart < scanEnd && /\S/.test(tailText) && qRowRe.test(tailText);
      const nBlocks = (useRungs ? ladder.length : sigs.length) + (tailKept ? 1 : 0);
      for (let i = 0; i < nBlocks; i++) {
        let start: number;
        let end: number;
        if (useRungs) {
          if (i < ladder.length) {
            start = i === 0 ? 0 : ladder[i - 1].line + 1;
            end = ladder[i].line + 1;
          } else {
            start = tailStart;
            end = scanEnd;
          }
        } else {
          start = i === 0 ? 0 : sigs[i].line;
          end = i + 1 < sigs.length ? sigs[i + 1].line : scanEnd;
        }
        const sig = sigs.find((s) => s.line >= start && s.line < end);
        // In rung mode the block's own rung line is a BOUNDARY, not content:
        // keeping it let the bare ordinal ride onto the last stem ("Careless:"
        // → "Careless: 4"). Drop it unless it carries fused content
        // ("17 Grammar" — the label rides the rung cell).
        let contentEnd = end;
        if (useRungs && i < ladder.length) {
          contentEnd = ladder[i].line;
          if (start <= ladder[i].line && !isStandaloneNumber(lines[ladder[i].line].trim())) {
            contentEnd = ladder[i].line + 1;
          }
        }
        const blockLines = lines.slice(start, contentEnd).filter((l) => !isFurnitureLine(l));
        const blockText = blockLines.join('\n');
        if (!/\S/.test(blockText)) continue;
        // Mark: the signature's cell, UNLESS this is the opener hybrid shape
        // (content … بارم) — there the signature number is the RUNG value
        // (1,2,3…) and the real mark trails the block. The override may only
        // fire when the sig number equals the block's rung ordinal, so page
        // numbers in pure-closer docs can never steal the printed mark.
        let mark: number;
        if (sig) {
          mark = sig.mark;
          const allowOverride = Number.isInteger(sig.mark) && sig.mark === cBlocks.length + 1;
          if (allowOverride) {
            let trailScan = 0;
            for (let k = end - 1; k >= start && trailScan < 6; k--) {
              if (ladderLines.has(k)) continue;
              const t = lines[k].trim();
              if (!t || isFurnitureLine(t)) continue;
              trailScan++;
              if (isStandaloneNumber(t) && k !== sig.line) {
                const v = parseMark(t);
                if (v !== null && v >= 0.25 && v <= 20) { mark = v; break; }
              }
              if (trailScan >= 4) break;
            }
          }
        } else {
          // Sig-less (commandless) block: FIRST standalone mark cell in
          // document order, skipping rung lines (the trailing ردیف cell is
          // an ordinal, not a mark).
          mark = 0;
          for (let k = start; k < end; k++) {
            if (ladderLines.has(k)) continue;
            const tt = lines[k].trim();
            if (!tt || isFurnitureLine(tt) || !isStandaloneNumber(tt)) continue;
            const vv = parseMark(tt);
            if (vv !== null && vv >= 0.25 && vv <= 20) { mark = vv; break; }
          }
          if (mark === 0 && !qRowRe.test(blockText)) continue;
        }
        let cat: RawSectionBlock['category'] | '' = cCarry;
        let fromLabel = false;
        for (const l of blockLines.slice(0, 6)) {
          const c = labelCat(nfkc(l).trim());
          if (c) { cat = c; fromLabel = true; break; }
        }
        if (cat) cCarry = cat;
        const headerLine =
          blockLines.map((l) => l.trim()).find((l) => l && !isStandaloneNumber(l)) || '';
        // R4 instruction-contract fallback — same semantics as the opener
        // build: detection only when no printed/carried subject exists.
        const detected =
          cat || cCarry ? '' : detectInitialCategory(headerLine, blockText);
        cBlocks.push({
          rowId: isPersianLadder
            ? PERSIAN_ROW_ORDINALS[cBlocks.length] ?? String(cBlocks.length + 1)
            : String(cBlocks.length + 1),
          category: (cat || cCarry || detected || 'General') as RawSectionBlock['category'],
          mark,
          text: blockText,
          headerLine,
          startIndex: lines.slice(0, start).reduce((s, l) => s + l.length + 1, 0),
          labelCategory: fromLabel || undefined,
        });
        if (cBlocks.length >= 30) break;
      }
      const cWithQ = cBlocks.filter((b) => /(?:^|\n)\s*\d{1,3}\s*[.\-)]\s*\S/.test(b.text)).length;
      const cMarkSum = cBlocks.reduce((s, b) => s + b.mark, 0);
      if (cBlocks.length >= 4 && cWithQ >= Math.ceil(cBlocks.length / 2) && cMarkSum <= 100) {
        return cBlocks;
      }
      if (process.env.DEBUG_RADIF) console.log('[radif] closer validation failed — falling to opener path');
    }
  }

  // ── R6-b Mechanism B: GAP-RUNG INSERTION ────────────────────────────────
  // A rung whose printed cell never extracted (or whose digit was damaged
  // beyond the LIS) leaves a single-step hole: ids skip N and the sections
  // around the hole merge (pkhn2yd527: rung 5 extracted as a damaged bare
  // "1" right before "Unscramble and make sentences." — the LIS dropped it
  // and Writing's 4 unscramble items fell into the Grammar row). When the
  // span between rung N-1 and rung N+1 holds a bare-number line whose next
  // substantive line is an INSTRUCTION (opener evidence; a subject label
  // instead means the label row itself is the damaged rung — that shape
  // belongs to Mechanism A below), that line IS rung N: insert it. The
  // damaged digit is irrelevant — position between N-1 and N+1 is the
  // consensus. Mark side-effect: the merged row's trailing bare cell now
  // lands in its own block (pkhn row 4 mark repaired to 2).
  if (!closerStyle && ladder.length >= 3) {
    const rungLines = new Set(ladder.map((r) => r.line));
    for (let k = 0; k + 1 < ladder.length; k++) {
      const step = ladder[k + 1].ord - ladder[k].ord;
      if (step !== 2) continue;
      const missing = ladder[k].ord + 1;
      const spanStart = ladder[k].line + 1;
      const spanEnd = ladder[k + 1].line;
      const cands: number[] = [];
      for (let i = spanStart; i < spanEnd; i++) {
        if (rungLines.has(i)) continue;
        const t = lines[i].trim();
        if (!isStandaloneNumber(t)) continue;
        const nxt = substantiveAfter(i);
        if (nxt < 0 || nxt >= spanEnd) continue;
        const t2 = lines[nxt].trim();
        if (!looksLikeInstructionLine(t2) || isSubjectLabel(t2)) continue;
        cands.push(i);
      }
      if (cands.length === 1) {
        ladder.splice(k + 1, 0, { ord: missing, line: cands[0], id: String(missing) });
        rungLines.add(cands[0]);
        k++; // skip past the inserted rung
      }
    }
  }

  // ── R6-b Mechanism A: OPENER-EVIDENCE PARTITION (damaged radif digits) ──
  // The LIS ladder trusts the printed rung digits; kanoon scans damage them
  // (1→"8", 3→"1", 4→"0") and the LIS then promotes mark cells to rungs,
  // starving whole sections (p93s775186: [1,2,4,6,7] with an empty block and
  // two merged ones). When the sheet is opener-style and the ladder ordinals
  // fail to chain (+1), partition at OPENER EVIDENCE instead: subject-label
  // rows and digit-prefixed lettered task banners (the "2 B) Match…"/"1 c)
  // Identify…" rows — the rung digit fuses onto the subtask line). Ids go
  // positional (consensus override), marks re-read per block, labels/carry
  // name the categories. Bare lettered banners without a rung digit ("A)
  // Choose…" inside section 1) are instructions — never openers.
  if (!closerStyle && ladder.length >= 3) {
    const steps = ladder.slice(1).map((r, k) => r.ord - ladder[k].ord);
    const brokenLadder = steps.some((s) => s !== 1);
    const IMP_VERBS =
      'Choose|Match|Identify|Complete|Fill|Put|Write|Read|Make|Answer|Unscramble|Listen|Circle';
    const openerEvidence: number[] = [];
    for (let i = 0; i < scanEnd; i++) {
      const t = nfkc(lines[i]).trim();
      if (!t || isFurnitureLine(t)) continue;
      if (isSubjectLabel(t)) {
        openerEvidence.push(i);
        continue;
      }
      if (new RegExp(`^\\s*\\d{1,2}\\s*[.]?\\s*[A-Z]\\s*\\)\\s*(?:${IMP_VERBS})\\b`, 'i').test(t)) {
        openerEvidence.push(i);
      }
    }
    if (
      brokenLadder &&
      openerEvidence.length >= 4 &&
      openerEvidence.length >= ladder.length
    ) {
      const aBlocks: RawSectionBlock[] = [];
      let aCarry: RawSectionBlock['category'] | '' = '';
      for (let k = 0; k < openerEvidence.length; k++) {
        const start = openerEvidence[k];
        const end = k + 1 < openerEvidence.length ? openerEvidence[k + 1] : scanEnd;
        const blockLines = lines.slice(start, end);
        const blockText = blockLines.join('\n');
        let cat: RawSectionBlock['category'] | '' = aCarry;
        let fromLabel = false;
        for (const l of blockLines.slice(0, 3)) {
          const c = labelCat(nfkc(l).trim());
          if (c) { cat = c; fromLabel = true; break; }
        }
        if (cat) aCarry = cat;
        let mark = 0;
        for (let kk = start + 1; kk < end; kk++) {
          const t = lines[kk].trim();
          if (!isStandaloneNumber(t)) continue;
          const v = parseMark(t);
          if (v !== null && v >= 0.25 && v <= 20) mark = v;
        }
        const headerLine =
          blockLines.map((l) => l.trim()).find((l) => l && !isStandaloneNumber(l)) || '';
        aBlocks.push({
          rowId: String(k + 1),
          category: (cat ||
            detectInitialCategory(headerLine, blockText) ||
            'General') as RawSectionBlock['category'],
          mark,
          text: blockText,
          headerLine,
          startIndex: lines.slice(0, start).reduce((s, l) => s + l.length + 1, 0),
          labelCategory: fromLabel || undefined,
        });
      }
      const aWithQ = aBlocks.filter((b) => /(?:^|\n)\s*\d{1,3}\s*[.\-)]\s*\S/.test(b.text)).length;
      const aMarkSum = aBlocks.reduce((s, b) => s + b.mark, 0);
      const nonTrivial = aBlocks.filter((b) => b.text.trim().length > 40).length;
      if (
        aBlocks.length >= 4 &&
        nonTrivial >= aBlocks.length - 1 &&
        aMarkSum <= 90 &&
        aWithQ >= Math.ceil(aBlocks.length / 2)
      ) {
        if (process.env.DEBUG_RADIF) {
          console.log('[radif] opener-evidence partition:', aBlocks.length, 'blocks, marks', aMarkSum);
        }
        return aBlocks;
      }
      if (process.env.DEBUG_RADIF) {
        console.log('[radif] opener-evidence partition failed validation', aBlocks.length, aMarkSum, aWithQ);
      }
    }
  }

  const blocks: RawSectionBlock[] = [];
  let carryCat: RawSectionBlock['category'] | '' = '';
  for (let i = 0; i < ladder.length; i++) {
    const start = ladder[i].line + 1;
    const end = i + 1 < ladder.length ? ladder[i + 1].line : scanEnd;
    // Mark: LAST standalone non-rung number in range; fall back to a number
    // just BEFORE the rung (closer-style rows: [mark][content][ردیف]).
    let mark = 0;
    for (let k = start; k < end; k++) {
      const t = lines[k].trim();
      if (!isStandaloneNumber(t)) continue;
      const v = parseMark(t);
      if (v !== null && v >= 0.25 && v <= 20) mark = v;
    }
    if (mark === 0) {
      for (let k = ladder[i].line - 1; k >= Math.max(0, ladder[i].line - 3); k--) {
        const t = lines[k].trim();
        if (!isStandaloneNumber(t)) continue;
        const v = parseMark(t);
        if (v !== null && v >= 0.25 && v <= 20) { mark = v; break; }
      }
    }
    if (mark === 0 && i + 1 < ladder.length) {
      // Lagging-بارم rhythm (R4): on the medu-final closer columns the بارم
      // cell's Y sits at the row's BOTTOM, so row N's mark extracts just
      // AFTER rung N+1 (pkc61/pd24nl/pc8er row 2: rung "3" line, then its
      // own "3" mark line). Look a couple of substantive lines past the next
      // rung; real content before any number means no lagging mark exists.
      const nextRung = ladder[i + 1].line;
      let scanned = 0;
      for (let k = nextRung + 1; k < Math.min(scanEnd, nextRung + 6) && scanned < 3; k++) {
        const t = lines[k].trim();
        if (!t || isFurnitureLine(t)) continue;
        scanned++;
        if (isStandaloneNumber(t)) {
          const v = parseMark(t);
          if (v !== null && v >= 0.25 && v <= 20) mark = v;
          break;
        }
        break;
      }
    }
    const blockLines = lines.slice(start, end);
    const blockText = blockLines.join('\n');
    let cat: RawSectionBlock['category'] | '' = carryCat;
    let fromLabel = false;
    // The rung line itself may carry the label ("17 Grammar" — row number
    // fused with the subject label): scan it FIRST, then the block head.
    for (const l of [lines[ladder[i].line], ...blockLines.slice(0, 3)]) {
      const c = labelCat(nfkc(l).trim());
      if (c) { cat = c; fromLabel = true; break; }
    }
    if (cat) carryCat = cat;
    const headerLine = blockLines.map((l) => l.trim()).find(Boolean) || '';
    // Instruction-contract fallback (R4): a block with NO printed label and
    // no carried part banner still carries its task contract on the opener
    // line ("2 دانش آموزان عزیز، به فایل صوتی گوش دهید…" = Listening —
    // p28932 2). Without this the block starts General and the shape
    // refinements rebrand it (mc shapes → Vocabulary) over the printed
    // contract. Printed labels (cat/carryCat) stay stronger than detection,
    // so this NEVER overrides a sheet-stated subject.
    const detected =
      cat || carryCat ? '' : detectInitialCategory(headerLine, blockText);
    blocks.push({
      rowId: ladder[i].id,
      category: (cat || carryCat || detected || 'General') as RawSectionBlock['category'],
      mark,
      text: blockText,
      headerLine,
      startIndex: lines.slice(0, start).reduce((s, l) => s + l.length + 1, 0),
      labelCategory: fromLabel || undefined,
    });
  }
  // Sanity: real marks and real question rows somewhere.
  const markSum = blocks.reduce((s, b) => s + b.mark, 0);
  const hasQuestions = blocks.filter((b) => /(?:^|\n)\s*\d{1,3}\s*[\.\)]\s*\S/.test(b.text)).length >= Math.ceil(blocks.length / 2);
  if (!hasQuestions || markSum > 90) { if (process.env.DEBUG_RADIF) console.log('[radif] reject: questions/markSum', markSum); return null; }
  // Letter-header distribution: a LETTERED paper puts ONE letter header per
  // row-span (the letters are the sections; the bare numbers were its بارم
  // column). A radif paper may still show A./B./C. sub-parts INSIDE a row
  // (listening dialogues) — those cluster several letters into one span.
  let singleLetterRows = 0;
  for (const b of blocks) {
    const n = (b.text.match(/^\s*[A-Z][\)\.:]\s*\S/gm) || []).length;
    if (n === 1) singleLetterRows++;
  }
  if (singleLetterRows >= 4 && singleLetterRows >= blocks.length - 1) {
    if (process.env.DEBUG_RADIF) console.log('[radif] reject: letters per row', singleLetterRows);
    return null;
  }
  return blocks;
}

/**
 * Unlettered instruction-block genre (#qu2 wave 2).
 * Teacher sheets often carry NO row letters at all: each task is announced by
 * a Persian instruction line whose printed mark rides in trailing parens —
 * "کلمات را در جای مناسب بگذارید  (2)" — or as the next standalone number.
 * Each instruction opens a section; ids are sequential Latin letters (A, B,
 * C…) because the sheet prints none. Gate: at least 3 mark-bearing
 * instruction lines and no ردیف band (the radif splitter runs first).
 */
function splitInstructionBlocks(text: string): RawSectionBlock[] | null {
  const lines = text.split(/\r?\n/);
  const nfkc = (l: string) => l.normalize('NFKC');
  let keyLine = -1;
  for (let i = 0; i < lines.length; i++) {
    // LINE-START anchored (R2): instructions legitimately mention پاسخنامه
    // mid-sentence ("…و در پاسخنامه بنویسید (1)" — pv684) and a contains-test
    // truncated the scan there, dropping every later section.
    if (/^\s*(?:راهنمای\s*تصحیح|راهنمای\s*نمره|کلید\s*سؤ|کلید\s*سوا|پاسخنامه)/.test(nfkc(lines[i]))) { keyLine = i; break; }
  }
  const scanEnd = keyLine >= 0 ? keyLine : lines.length;

  // Instruction line: Persian (or mixed) sentence carrying a trailing (N)
  // mark — bare "(N)", the "نمره" suffixed forms, the RTL-scrambled paren
  // (paren opens early, words + the number inside: "…است .( از خودتان جملات
  // را با کلمات با 2 )"), or a trailing bidi decimal with the paren fragment
  // ("شکل صحیح کلمه داخل پرانتز 5 / 1 )" — p8zq62). Question rows ("12. …",
  // "a) …") never qualify — the trailing-mark anchor keeps option rows out.
  const clean = (l: string) => nfkc(l).replace(/[\u200E\u200F\u202A-\u202E\u2066-\u2069]/g, '').trim();
  const bidiDecimal = '(\\d{1,2}\\s*/\\s*\\d{1,2})';
  const instrMark = (l: string): number | null => {
    const t = clean(l);
    if (!/[\u0600-\u06FF]/.test(t)) return null;
    // Page-header lines ("آزمون درس : زبان انگلییس 3") end in digits too —
    // furniture can never carry a section mark (p8zq62 phantom start).
    if (isFurnitureLine(t)) return null;
    let m = t.match(/\(\s*(\d{1,2}(?:[.,]\d{1,2})?)\s*(?:نمره\s*)?\)\s*$/) || t.match(/\)\s*(\d{1,2}(?:[.,]\d{1,2})?)\s*نمره\)?\s*$/);
    if (!m) {
      // RTL-scrambled paren: a trailing paren group whose INNER text is
      // words + one number (the printed mark). The group may not even open
      // on this line ("… 5 / 1 )") — accept a trailing bidi decimal
      // followed by an optional lone ')'.
      m = t.match(new RegExp('\\\\([^(\\\\n]*\\\\d{1,2}(?:[.,]\\\\d{1,2})?[^)(\\\\n]*\\\\)\\\\s*$')); // ( … N … )
      if (m) {
        const inner = m[0].slice(1, -1).replace(/[\\u0600-\\u06FF]/g, ' ').trim();
        const v = parseFloat(inner.replace(',', '.'));
        return Number.isFinite(v) && v > 0 && v <= 20 ? v : null;
      }
      m = t.match(new RegExp(bidiDecimal + '\\s*\\)?\\s*$'));
      if (m) {
        const parts = m[1].split('/');
        const v = Math.round((parseInt(parts[1], 10) + parseInt(parts[0], 10) / Math.pow(10, parts[1].trim().length)) * 100) / 100;
        return Number.isFinite(v) && v > 0 && v <= 20 ? v : null;
      }
      // Bare trailing digit + optional lone ')' — "…جملات را با 3 )" (p8zq62
      // sec E). Instruction-shaped lines only: several Persian words AND an
      // imperative verb suffix (ید — کنید/دهید/بنویسید/بگذارید) so header
      // debris that merely ends in a digit ("آزمون نوبت دوم خرداد 1405 زبان
      // خارجه 1" — pw1387) cannot open a block.
      m = t.match(/(\d{1,2})\s*\)?\s*$/);
      if (m && (t.match(/[\u0600-\u06FF]+/g) ?? []).length >= 4 && FA_IMPERATIVE_SUFFIX.test(t)) {
        const v = parseFloat(m[1]);
        return Number.isFinite(v) && v > 0 && v <= 20 ? v : null;
      }
      return null;
    }
    const v = parseFloat(m[1].replace(',', '.'));
    return Number.isFinite(v) && v > 0 && v <= 20 ? v : null;
  };
  // Subject-label line ("Reading." / "Listening" / "Pronunciatin") and
  // numbered English imperatives ("1. Match the pictures…", "4 . Choose the
  // best answer") also open sections on label-led teacher sheets. (R2)
  // The label may carry its own trailing mark: "Listening  (4)" (pv684) —
  // captured so the Listening block keeps its printed بارم.
  const labelLine = (l: string): { label: string; mark: number } | null => {
    const t = clean(l);
    const m = t.match(/^(Listening|Vocabulary|Grammar|Reading|Writing|Pronunciation)\b[\.:]?\s*(?:\(\s*(\d{1,2}(?:[.,]\d{1,2})?)\s*(?:نمره\s*)?\))?\s*$/i);
    return m ? { label: m[1], mark: m[2] ? parseFloat(m[2].replace(',', '.')) : 0 } : null;
  };
  const imperativeHead = (l: string): string | null => {
    const t = clean(l);
    const m = t.match(/^(\d{1,2})\s*[\)\.]\s*(?:Match|Complete|Choose|Fill|Unscramble|Read|Write|Circle|Put|Order|Find|Answer|Change|Specify|Make|Spell|Use)\b/i);
    return m ? m[1] : null;
  };

  interface Block { line: number; mark: number; id: string | null }
  const starts: Block[] = [];
  for (let i = 0; i < scanEnd; i++) {
    const mark = instrMark(lines[i]);
    const label = labelLine(lines[i]);
    const imperative = imperativeHead(lines[i]);
    if (mark !== null) starts.push({ line: i, mark, id: null });
    else if (label) starts.push({ line: i, mark: label.mark, id: label.label });
    else if (imperative) starts.push({ line: i, mark: 0, id: imperative });
  }
  if (starts.length < 4) return null;
  if (process.env.PARSE_DEBUG) console.error('[instr-blocks] starts:', starts.map((s) => `${s.line}:${s.mark}«${lines[s.line].trim().slice(0, 30)}»`).join(' '));
  // A long letter ladder means a LETTERED paper — the lettered splitter owns
  // its section identity (A..Q ids), so the instruction-block machine must
  // not steal it with subject labels ("listening", "Vocabulary"…).
  if (longestLetterHeaderLadder(lines) >= 8) return null;
  // Every block must hold real content (instruction + question rows).
  const isStandaloneNum = (l: string) => /^\.?\d{1,2}(?:[.,]\d{1,2})?$/.test(l.trim());
  const blocks: RawSectionBlock[] = [];
  for (let i = 0; i < starts.length; i++) {
    const start = starts[i].line;
    const end = i + 1 < starts.length ? starts[i + 1].line : scanEnd;
    const blockLines = lines.slice(start, end);
    const blockText = blockLines.join('\n');
    if (!/\S/.test(blockText)) continue;
    // Mark fallbacks: label/imperative heads print their بارم either BEFORE
    // the block (preceding bare number) or AFTER the questions (trailing
    // bare number) — the same-line (N) capture is only the primary form.
    let mark = starts[i].mark;
    if (mark === 0) {
      for (let k = end - 1; k >= start && k >= end - 4; k--) {
        if (isStandaloneNum(lines[k])) { const v = parseFloat(lines[k].trim().replace(',', '.')); if (v > 0 && v <= 10) { mark = v; break; } }
      }
      if (mark === 0) {
        for (let k = start - 1; k >= Math.max(0, start - 3); k--) {
          if (isStandaloneNum(lines[k])) { const v = parseFloat(lines[k].trim().replace(',', '.')); if (v > 0 && v <= 10) { mark = v; break; } }
        }
      }
    }
    blocks.push({
      rowId: starts[i].id ?? String.fromCharCode(65 + blocks.length),
      category: detectInitialCategory(blockLines[0].trim(), blockText),
      mark,
      text: blockText,
      headerLine: blockLines[0].trim(),
      startIndex: lines.slice(0, start).reduce((s, l) => s + l.length + 1, 0),
    });
    if (blocks.length >= 26) break;
  }
  if (blocks.length < 3) return null;
  const withQuestions = blocks.filter((b) => /(?:^|\n)\s*\d{1,3}\s*[\.\)]\s*\S|\(?\s*[a-e]\s*[\)\.]/.test(b.text)).length;
  if (withQuestions < Math.ceil(blocks.length / 2)) return null;
  return blocks;
}

/**
 * RTL row-marker detection (#fix-4).
 * Persian/Arabic exam papers put the row letter at the visual RIGHT edge of
 * the row. Text extractors emit that letter in two families:
 *   layout engines (pdftotext):  "1.25   در هر سوال ... انتخاب کنید.     B"
 *       → letter at physical line END of the instruction line → section STARTS here
 *   content-stream engines (pdf.js): the letter is its own table cell, often
 *       emitted as a bare "B" line AFTER the section content → TERMINATES it
 *   solo marks cell: "1.5     I" → the instruction follows → section STARTS here
 * The start-of-line patterns above never see any of these, so every real
 * section boundary was missed on RTL papers. An alphabet-sequence guard
 * (A, B, C… strictly increasing) rejects stray letters like the two-column
 * match-table headers that also extract as bare "A"/"B" lines.
 */
interface RtlAnchor {
  index: number;
  endIndex: number;
  rowId: string;
  /** Latin ordering key for the alphabet ladder guard below; differs from
   *  rowId only when the printed letter is Persian (native rowId is the
   *  canonical convention — same as the main section-anchor path). */
  seqKey?: string;
  headerLine: string;
  mark?: number;
  mode: 'start' | 'end';
}

const PERSIAN_ROW_LETTER_TO_LATIN: Record<string, string> = {
  'الف': 'A', 'ب': 'B', 'ج': 'C', 'د': 'D', 'هـ': 'E', 'ه': 'E', 'و': 'F',
};

export function collectRtlRowAnchors(text: string): RtlAnchor[] {
  const candidates: RtlAnchor[] = [];
  const lines = text.split(/\r?\n/);
  let offset = 0;
  for (const line of lines) {
    const lineStart = offset;
    const lineLenWithBreak = line.length + 1;
    const trimmed = line.trim();
    offset += lineLenWithBreak;
    if (!trimmed) continue;

    // --- shape 1: bare marker line — "A", "A)", "A.", "ب" ----------------
    const bare = trimmed.match(/^(?:([A-Z])|(الف|هـ|[بجدهو]))[\)\.]?$/);
    if (bare) {
      const latin = bare[1] || PERSIAN_ROW_LETTER_TO_LATIN[bare[2]] || '';
      if (latin) {
        // Canonical rowId convention (same as the main section-anchor path):
        // the PRINTED letter is the identity — Persian bare letters stay
        // native ("الف", not "A"). The Latin letter rides along as seqKey so
        // the alphabet-ladder guard below keeps one uniform ordering key;
        // emitting Latin here used to fork the dataset convention depending
        // on which detection path fired.
        candidates.push({ index: lineStart, endIndex: offset, rowId: bare[1] || bare[2], seqKey: latin, headerLine: '', mode: 'end' });
      }
      continue;
    }
    if (trimmed.length < 4) continue;

    // --- shape 2: solo marks column + letter — "1.5     I" ---------------
    const solo = trimmed.match(/^(\d{1,2}(?:[\.,]\d+)?)\s+([A-Z])$/);
    if (solo) {
      const v = parseFloat(solo[1].replace(',', '.'));
      candidates.push({
        index: lineStart, endIndex: offset, rowId: solo[2], headerLine: '',
        mark: !isNaN(v) && v > 0 && v <= 20 ? v : undefined,
        mode: 'start',
      });
      continue;
    }

    // --- shape 3: inline — "1.25  در هر سوال گزینه صحیح را انتخاب کنید.  B"
    let m = trimmed.match(/^(.*[\u0600-\u06FF].*?)\s+([A-Z])$/);
    // Paren-mirror shapes (#qu2 wave 3, pw1387r928): the bidi render of a
    // "(B)" header extracts with the letter at EITHER line end wrapped in a
    // paren — "(C ا کامل کنید…" (start) / "… جاهای خالی ر (B" (end) — or as a
    // close-paren form "A )به فایل…" (the open paren went missing). Each is a
    // section opener when real Persian instruction text surrounds the letter.
    const parStart = trimmed.match(/^\(\s*([A-Z])\s*\)?\s*(.*[\u0600-\u06FF].*)$/);
    const parEnd = trimmed.match(/^(.*[\u0600-\u06FF].*?)\s*\(\s*([A-Z])\s*\)?$/);
    const closeStart = trimmed.match(/^([A-Z])\s*[\)\.]\s*(.*[\u0600-\u06FF].*)$/);
    const persianCharsOf = (s: string) => (s.match(/[\u0600-\u06FF]/g) || []).length;
    if (!m && parStart && persianCharsOf(parStart[2]) >= 3) {
      const body = parStart[2];
      if ((body.match(/\b[a-d][\)\.\-–—:]\s*\S/gi) || []).length < 2) {
        candidates.push({
          index: lineStart, endIndex: offset, rowId: parStart[1],
          headerLine: body.trim(), mode: 'start',
        });
      }
      continue;
    }
    if (!m && parEnd && persianCharsOf(parEnd[1]) >= 3) {
      const body = parEnd[1];
      if ((body.match(/\b[a-d][\)\.\-–—:]\s*\S/gi) || []).length < 2 && !/^\s*\d{1,3}\s*[\-\.\)]\s*\S/.test(body)) {
        candidates.push({
          index: lineStart, endIndex: offset, rowId: parEnd[2],
          headerLine: body.trim(), mode: 'start',
        });
      }
      continue;
    }
    if (!m && closeStart && persianCharsOf(closeStart[2]) >= 3) {
      const body = closeStart[2];
      if ((body.match(/\b[a-d][\)\.\-–—:]\s*\S/gi) || []).length < 2) {
        candidates.push({
          index: lineStart, endIndex: offset, rowId: closeStart[1],
          headerLine: body.trim(), mode: 'start',
        });
      }
      continue;
    }
    if (!m) continue;
    const [, body, letter] = m;

    // Must carry a real instruction (≥3 Persian-bearing chars in the body)
    const persianChars = (body.match(/[\u0600-\u06FF]/g) || []).length;
    if (persianChars < 3) continue;

    // Never an MCQ options row ("A- Is B- Does C- Do"), never a numbered
    // question line ("2- I enjoy … the web") masquerading as a header
    const optionHits = (body.match(/\b[a-d][\)\.\-–—:]\s*\S/gi) || []).length;
    if (optionHits >= 2) continue;
    if (/^\s*\d{1,3}\s*[\-\.\)]\s*\S/.test(body) && !/^[\d\.]+\s+[\u0600-\u06FF]/.test(body)) continue;

    // Leading marks column ("1.25 ") is the بارم for this row
    let mark: number | undefined;
    const markMatch = body.match(/^\s*(\d{1,2}(?:[\.,]\d+)?)\s+[\u0600-\u06FF]/);
    if (markMatch) {
      const v = parseFloat(markMatch[1].replace(',', '.'));
      if (!isNaN(v) && v > 0 && v <= 20) mark = v;
    }

    candidates.push({
      index: offset - lineLenWithBreak,
      endIndex: offset,
      rowId: letter,
      headerLine: body.replace(/^\s*\d{1,2}(?:[\.,]\d+)?\s+/, '').trim(),
      mark,
      mode: 'start',
    });
  }

  // Alphabet-sequence guard: real row markers run A, B, C… (strictly
  // increasing). Stray letters — match-table column headers, pronoun "I",
  // option debris — break the sequence and are rejected.
  const anchors: RtlAnchor[] = [];
  let lastLetter = '';
  const seqKeyOf = (c: RtlAnchor) => c.seqKey || c.rowId;
  for (const c of candidates) {
    const key = seqKeyOf(c);
    if (!lastLetter) {
      if (key !== 'A') continue; // the row ladder must start at A
      lastLetter = key;
      anchors.push(c);
      continue;
    }
    // A REPEAT of the current letter is a real row too — some sheets print
    // the same letter twice (pc4i517871 / pu7v67755 both repeat "D"); the
    // bare-letter line is too strong a marker to drop.
    if (
      key.charCodeAt(0) >= lastLetter.charCodeAt(0) &&
      key.charCodeAt(0) <= lastLetter.charCodeAt(0) + 3
    ) {
      lastLetter = key;
      anchors.push(c);
    }
  }
  return anchors;
}

/**
 * First instruction-looking line of a block: skips blank lines and the
 * بارم/سوالات/ردیف table-header row; strips a leading marks column value.
 * Also skips paper-header furniture (بسمه تعالی، امتحان…، اداره/مدرسه/مدت)
 * so RTL end-mode blocks that start at the page top don't take the school
 * banner as the section instruction.
 */
function firstInstructionLine(text: string, start: number, end: number): { line: string; mark?: number } {
  let pendingMark: number | undefined;
  for (const raw of text.slice(start, end).split(/\r?\n/)) {
    const t = raw.trim();
    if (!t) continue;
    if (/\u0628\u0627\u0631\u0645/.test(t) && /\u0631\u062f\u06cc\u0641/.test(t)) continue; // "بارم سواالت ردیف" table header
    if (/بسمه\s*تعالی/.test(t)) continue;
    if (/^امتحان/.test(t)) continue;
    if (/(?:نام\s*و\s*نام|نام\s*خانوادگی|مدت\s*آزمون|تاریخ\s*آزمون|شعبه|اداره\s*(?:کل\s*)?آموزش|آموزش\s*و\s*پرورش|دبیرستان|دبستان|هنرستان|آموزشگاه|مدرسه|تعداد\s*سوالات|سال\s*تحصیلی|نوبت)/.test(t) && t.length < 80) continue;
    const m = t.match(/^(\d{1,2}(?:[\.,]\d+)?)\s+(.+)$/);
    if (m) {
      const v = parseFloat(m[1].replace(',', '.'));
      const mark = !isNaN(v) && v > 0 && v <= 20 ? v : undefined;
      return { line: m[2].trim(), mark: mark ?? pendingMark };
    }
    // A lone number line ("1.5", "3") is a marks-column cell or a page
    // footer. Hold it as the section mark; page footers get overwritten by
    // the real instruction's own leading number, marks cells don't.
    if (/^\d{1,2}(?:[\.,]\d+)?$/.test(t)) {
      const v = parseFloat(t.replace(',', '.'));
      if (!isNaN(v) && v > 0 && v <= 20 && pendingMark === undefined) pendingMark = v;
      continue;
    }
    return { line: t, mark: pendingMark };
  }
  return { line: '', mark: pendingMark };
}

/**
 * Extracts section marks from header lines or blocks:
 * Matches: "(2 marks)", "(1 mark)", "(2)", "[2]", "2 نمره", "بارم: 2"
 */
function extractSectionMark(headerLine: string, blockText: string): number {
  // 1. Matches "(2 marks)", "(1 mark)", "(0.5 mark)", "(2 pts)" inside header line
  const parenMarkMatch = headerLine.match(/\(\s*([\d\.]+)\s*(?:marks?|نمره|pts?|points?)?\s*\)/i);
  if (parenMarkMatch) {
    const val = parseFloat(parenMarkMatch[1]);
    if (!isNaN(val) && val > 0 && val <= 30) return val;
  }

  // 2.5 Standalone mark line(s) (docx marks tables emit the بارم on its own
  // line before the instruction): every bare number line ≤ 20 is SUMMED — some
  // teachers split a row's بارم across two cells (".5" + "1" = 1.5).
  // Question/slot lines ("21.", "32-") never match — they carry punctuation.
  // Page-furniture guard (#qu2 wave 5): a bare number hugging the Kanoon URL
  // footer ("www-kanoon-ir" / "N | P a g e") or followed by the student-header
  // fields is a PAGE NUMBER, not a بارم cell — summing it doubled A (1+1=2)
  // and fabricated D2/L marks on pc4i517871.
  {
    const ls = blockText.split(/\r?\n/);
    const furnitureNeighbor = (idx: number) => {
      for (let p = idx - 1; p >= 0; p--) {
        const t = ls[p].trim();
        if (!t) continue;
        if (/^(?:www[-.])?kanoon[-.]ir$/i.test(t) || /\|\s*P\s*a\s*g\s*e/i.test(t)) return true;
        break;
      }
      for (let n2 = idx + 1; n2 < ls.length; n2++) {
        const t = ls[n2].trim();
        if (!t) continue;
        if (/شماره\s*صندلی|کالس|کلاس|نام\s*و\s*نام|بسمه\s*تعالی|سازمان|اداره|دبیرستان|دبستان|آزمون|امتحان|درس\s*:|تاریخ|مدت/.test(t)) return true;
        break;
      }
      return false;
    };
    let sum = 0;
    let seen = 0;
    for (let idx = 0; idx < ls.length; idx++) {
      const t = ls[idx].trim();
      if (!/^\.?\d{1,2}(?:[\.,]\d{1,2})?$/.test(t)) continue;
      if (furnitureNeighbor(idx)) continue;
      const val = parseFloat(t.startsWith('.') ? `0${t}` : t.replace(',', '.'));
      if (isNaN(val) || val <= 0 || val > 20) continue;
      sum += val;
      if (++seen >= 6) break;
    }
    if (seen > 0 && sum > 0 && sum <= 20) return Math.round(sum * 100) / 100;
  }

  // 2.6 Fused-imperative mark (#qu2 wave 5): Kanoon row openers print the بارم
  // fused to the instruction ("1 Choose the best answer.", "0.5 Complete the
  // rest of the sentences."). When no standalone mark cell survived the
  // furniture guard, the first small-numbered imperative line IS the row's
  // mark (pc4i517871 D2/L — their bare "1" never stood alone in the block).
  {
    for (const l of blockText.split(/\r?\n/)) {
      const m = l.trim().match(/^(\d{1,2}(?:[.,]\d+)?)\s+(?:Read|Listen|Choose|Match|Fill|Write|Make|Complete|Put|Use|Answer|Circle|Unscramble|Order|Sort|Find|Change|Combine|According)\b/i);
      if (!m) continue;
      const val = parseFloat(m[1].replace(',', '.'));
      if (!isNaN(val) && val > 0 && val <= 5) return val;
      break; // the first numbered line decides — later ones are questions
    }
  }

  // 1.5 Trailing OCR-damaged mark cell: "( 2 نمره (" — the paren never closes
  // cleanly and the keyword is garbled by OCR. Accept any trailing "( N …"
  // at the header line's end.
  const trailingOcrMark = headerLine.match(/\(\s*([\d\.]+(?:\s*\/\s*\d{1,2})?)\s*[^)\n]{0,30}[\)(]?\s*$/);
  if (trailingOcrMark) {
    // Persian decimals write 1.5 as "1/5" — the slash IS the decimal point.
    const raw = trailingOcrMark[1].replace(/\s+/g, '').replace('/', '.');
    const val = parseFloat(raw);
    if (!isNaN(val) && val > 0 && val <= 20) return val;
  }

  // 2. Trailing mark at end of header line: "... 2" or "... 1.5 نمره"
  const trailingHeaderMatch = headerLine.match(/(?:^|\s)(?:([\d\.]+))\s*(?:نمره|pts?|points?|marks?)?\s*$/i);
  if (trailingHeaderMatch) {
    const valStr = trailingHeaderMatch[1];
    const val = parseFloat(valStr.startsWith('.') ? `0${valStr}` : valStr);
    if (!isNaN(val) && val > 0 && val <= 30) return val;
  }

  // 3. Explicit "بارم: X" or "نمره: X"
  const explicitMarkMatch = blockText.match(/(?:بارم|نمره|mark|points?)\s*[:：]?\s*([\d\.]+)/i);
  if (explicitMarkMatch) {
    const val = parseFloat(explicitMarkMatch[1]);
    if (!isNaN(val) && val > 0 && val <= 30) return val;
  }

  // 4. Sub-part mark cells: "a ) … ( 1 نمره )" + "b ) … ( 2 نمره )" inside a
  // single section sum to the row's بارم.
  {
    let sum = 0;
    let seen = 0;
    for (const l of blockText.split(/\r?\n/)) {
      const m = l.match(/\(\s*([\d\.]+(?:\s*\/\s*\d{1,2})?)\s*[^)\n]{0,30}[\)(]?\s*$/);
      if (!m) continue;
      const raw = m[1].replace(/\s+/g, '').replace('/', '.');
      const val = parseFloat(raw);
      if (isNaN(val) || val <= 0 || val > 20) continue;
      sum += val;
      if (++seen >= 4) break;
    }
    if (seen >= 2 && sum > 0 && sum <= 20) return Math.round(sum * 100) / 100;
  }

  // Default to 1
  return 1;
}

/**
 * Detects section category from English & Persian keywords
 */
function detectInitialCategory(
  headerLine: string,
  blockText: string,
): 'Listening' | 'Vocabulary' | 'Grammar' | 'Writing' | 'Reading' | 'General' {
  // Instruction line first (strong signal) — option words like "reading"
  // inside MCQ rows must never classify the section.
  const headerOnly = headerLine.toLowerCase();
  let body = blockText.slice(0, 600);
  // Trailing bare skill-label lines belong to the NEXT section (kanoon
  // extraction appends the next part's opener to this block's tail —
  // p2657 sec H absorbed "IV) Reading:" from below and rebranded itself
  // Reading). Strip up to two such lines before any body cue matching;
  // the leading-label oracle is handled by the block stamp pass.
  for (let i = 0; i < 2; i++) {
    const trimmed = body.replace(/\s+$/, '');
    const nl = trimmed.lastIndexOf('\n');
    const lastLine = trimmed.slice(nl + 1).trim();
    if (lastLine && R3_SKILL_LABEL_LINE.test(lastLine)) body = trimmed.slice(0, nl + 1);
    else break;
  }
  const combined = `${headerLine}\n${body}`.toLowerCase();
  // Squash probe (R3): letter-split extraction ("فا ی ل صوت ی") removes
  // intra-word spaces — run every cue against the whitespace-free form too
  // (\s* inside existing cues matches the zero-space case for word gaps).
  const sqHeader = headerOnly.replace(/\s+/g, '');
  const sqCombined = combined.replace(/\s+/g, '');

  const reListening = /listening|audio|listen\s+to|شنیداری|گوش\s*دهید|فایل\s*صوتی/i;
  const reReading = /reading|passage|comprehension|cloze|درک\s*مطلب|متن\s*زیر\s*را\s*بخوانید|ریدینگ|کلوز/i;
  const reVocab = /choose\s+the\s+correct\s+answer|vocabulary|words?\s+in\s+the\s+box|using\s+the\s+words|words?\s+given|given\s+words?|fill\s+in\s+the\s+blanks?\s+with\s+(?:the\s+)?words?|spelling|واژگان|واژه|لغت|کلمات|کلمه|کادر|جعبه|املا|گزینه/i;
  // NOTE (wave 5): "intonation" was tried in reVocab and REVERTED — the frozen
  // 9th-grade GTs pin General for intonation sections (M / 5), so the p566 F
  // GT was aligned to General instead.
  const reGrammar = /fill\s+in\s+the\s+blanks|grammar|grammatical|parentheses|tenses?|preposition|دستور\s*زبان|دستور|گرامر|قواعد|شکل\s*صحیح/i;
  const reWriting = /writing|unscramble|reorder|punctuation|combine|make\s+a\s+sentence|نگارش|نوشتن|مرتب\s*کنید/i;

  const listenHit =
    reListening.test(headerOnly) || reListening.test(combined) || reListening.test(sqHeader) || reListening.test(sqCombined);
  const readingHit =
    reReading.test(headerOnly) || reReading.test(combined) || reReading.test(sqHeader) || reReading.test(sqCombined);

  // Pass 1: instruction line alone (strong signal, immune to option words
  // like "reading" inside MCQ rows). Pass 2: block body. Both probed on the
  // raw AND squashed forms.
  for (const [re, cat] of [[reListening, 'Listening'], [reReading, 'Reading'], [reVocab, 'Vocabulary'], [reGrammar, 'Grammar'], [reWriting, 'Writing']] as const) {
    if (re.test(headerOnly) || re.test(sqHeader)) return cat;
  }

  // R3 contract pre-checks — printed task contracts outrank the generic
  // keyword passes, which mis-bucket them (form tasks lose to the vocab
  // "words given" cue, picture tasks fall to General, conjunction fills
  // inherit Vocabulary from the word-paren cues).
  if (!listenHit && !readingHit) {
    // (2) sentence-construction contract → Grammar (building one sentence
    // from given/scrambled words is the دستور convention in the GT, not
    // Writing — 91294 12, pg3866 K, p3iy 16).
    const sentC = /make\s+a\s+(?:correct\s+|meaningful\s+|single\s+)?sentence|build\s+a\s+sentence/i.test(combined) ||
      r3HitAny(body, R3_SENT_CONTRACT) || r3HitAny(body.replace(/\s+/g, ''), R3_SENT_CONTRACT);
    if (sentC) return 'Grammar';
    // (3) picture-task contract → Vocabulary (match/choose FROM pictures —
    // but "look at the picture and ANSWER" stays with its answer contract).
    const picC =
      r3HitAny(body, R3_PICTURE_CONTRACT) || r3HitAny(body.replace(/\s+/g, ''), R3_PICTURE_CONTRACT);
    if (picC && !/answer\s+the\s+question|به\s*تصاویر\s*پاسخ/i.test(body)) return 'Vocabulary';
    // (4) conjunction fill + orthographic-error correction → Writing
    const conjC = r3HitAny(body, R3_CONJ_CONTRACT) || r3HitAny(body.replace(/\s+/g, ''), R3_CONJ_CONTRACT);
    if (conjC) return 'Writing';
    if (R3_ORTHO_ERROR.test(body) || R3_ORTHO_ERROR.test(body.replace(/\s+/g, ''))) return 'Writing';
  }

  for (const [re, cat] of [[reListening, 'Listening'], [reReading, 'Reading'], [reVocab, 'Vocabulary'], [reGrammar, 'Grammar'], [reWriting, 'Writing']] as const) {
    if (re.test(combined)) return cat;
  }
  for (const [re, cat] of [[reListening, 'Listening'], [reReading, 'Reading'], [reVocab, 'Vocabulary'], [reGrammar, 'Grammar'], [reWriting, 'Writing']] as const) {
    if (re.test(sqCombined)) return cat;
  }
  return 'General';
}

function parseSectionBlock(
  rawSec: RawSectionBlock,
  startNumber: number,
  anomalies: ParsingAnomaly[],
  options: ParseOptions,
  traceCtx?: TraceCtx,
): ExamSection {
  const { rowId, headerLine } = rawSec;
  // Label pin (#qu2 wave 3): a PRINTED subject label on the row opener
  // ("17 Grammar") outranks every derived category — chain stamps included
  // (a neighboring row's instruction bleeds into the span and used to rebrand
  // the section Writing).
  const labelPinned = !!rawSec.labelCategory && !!rawSec.category && rawSec.category !== 'General';

  // Join line-wrapped verb cues before any extraction: pdf tables break
  // "19- (is /was\n/were)" and "21-\n(his/ her / him)" across lines, which
  // defeats both the blank-sentence and inline-choice detectors.
  // Read-the-text table contract (#slot-split guard): a section whose sheet
  // says "Read the text, then complete the table" fills its whole grid from
  // the passage — slot rows inside it are table cells, not stem-less tasks.
  const readTextTableTask =
    /read\s+the\s+text|read\s+the\s+passage|متن\s*را\s*بخوان|متنزیررابخوان|در\s*متن\s*یافته/i.test(rawSec.text.normalize('NFKC').replace(/\s+/g, ''));
  // Brain-block opener parity: the text splitters hand sections over with the
  // row-letter marker ALREADY stripped from the opener line ("Match the
  // definitions..."), while brain blocks keep the printed marker ("B) Match
  // ..."). Left in place it blinds the instruction cue (^Match...), so the
  // strip-marker prefix comes off the first line for brain blocks only.
  const brainText =
    rawSec.brain && /^[ \t]*\(?(?:[A-Z]|الف|هـ|[ب-ی\u067E\u062A\u062B\u062C\u0686\u062D\u062E\u062F\u0630\u0631\u0632\u0698\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u06A9\u06AF\u0644\u0645\u0646\u0648\u0647\u06CC])[ \t]*[\).\-ـ:][ \t]*\S/.test(rawSec.text)
      ? rawSec.text.replace(/^[ \t]*\(?[^\s\).\-ـ:]+[ \t]*[\).\-ـ:][ \t]*/, '')
      : rawSec.text;
  const text = brainText
    .replace(/\(\s*([^()\n]*)\n\s*([^()\n]*)\s*\)/g, '($1 $2)')
    .replace(/(\d{1,3}\s*[-–—])\s*\n\s*\(/g, '$1 (')
    // OCR bidi debris: answer-box markers printed BEFORE the statement number
    // ("F T 1- They are going…") hide the question start from the rules.
    .replace(/^[ \t]*[FTft][ \t]+[FTft][ \t]+(?=\d{1,3}[ \t]*[-.)])/gm, '')
    // Parenthesized picture/dialogue number runs ("(15)  (16)  (17)  (18)") —
    // ONE line carrying SEVERAL stem-less question slots (the stems are the
    // printed pictures). Expand to one line per number so the segmenter opens
    // a question per slot (Kanoon picture rows — the documented wave-3 unlock).
    .replace(/^([ \t]*\(\s*\d{1,3}\s*\))(?:\s+\(\s*\d{1,3}\s*\))+[ \t]*$/gm, (line) =>
      line.trim().split(/\s+(?=\()/).map((s) => s.trim()).join('\n'))
    // RTL single-dot artifact (R2, p91294): the printed number arrives as
    // ". 37 ." mid-line (bidi pushed it after the answer line "If____").
    // Rewrite to a real "N." marker on its own line so the segmenter opens it.
    .replace(/(?:^|(?<=[\s_]))\.\s*(\d{1,3})\s*\.\s+/gm, (whole, n: string) => {
      const v = parseInt(n, 10);
      if (!(v >= 1 && v <= 150)) return whole;
      if (/\.\s*\d{1,3}\s*\.\s*\d/.test(whole)) return whole; // decimal chain, not a marker
      return '\n' + v + '. ';
    })
    // Per-line multi-number split (#qu2 wave 3): bidi column merges print
    // several numbered items on ONE line — "66. d) Clean energy… 65. c)
    // Sport……… 64. b) Watching TV…… 63. a) Ferdowsi….". When ≥3 numbered
    // markers form a consecutive run (ascending OR descending — the picture
    // rows print RTL), split before each marker so every item becomes its own
    // question. Guards: marker at word boundary, no decimal marks ("1.25"),
    // no time ("9:00").
    .replace(/^.*$/gm, (line) => {
      // A marker followed by a BLANK RUN ("31) -----as the most famous…") is
      // a cloze-passage slot number, not a question start (12th-first P) —
      // splitting the passage there shredded it into phantom items.
      const markers = Array.from(line.matchAll(/(?:^|(?<=\s))(\d{1,3})\s*[.)]\s*(?=[^\d\s])(?![.\s]*[-_–—…]{2,})/g));
      if (markers.length < 3) return line;
      const nums = markers.map((m) => parseInt(m[1], 10));
      let consecutive = true;
      for (let i = 1; i < nums.length; i++) if (Math.abs(nums[i] - nums[i - 1]) !== 1) consecutive = false;
      if (!consecutive) return line;
      if (/(?:^|\s)\d{1,2}:\d{2}/.test(line)) return line; // clock times
      let out = line;
      // Split before EVERY marker not at the line start — including the first
      // one. The paren-joiner glues an instruction line to the first item
      // ("…ﺑﻨﻮﯾﺴﯿﺪ . 66. d) Clean energy…"); without the first cut the item
      // stays glued to the instruction and the question vanishes.
      for (let i = markers.length - 1; i >= 0; i--) {
        const at = markers[i].index ?? -1;
        if (at <= 0) continue;
        out = out.slice(0, at).trimEnd() + '\n' + out.slice(at);
      }
      return out;
    })
    // TWO-marker prose split (R2, p91294 sec20): "56. Solar energy  57.
    // Oceans and lakes" — two short-titled questions share one line. Same
    // guards as the ≥3 path, but the run may be exactly 2 and each fragment
    // must carry real prose (≥3 letters) so blank-slot rows keep their own
    // dedicated path below.
    .replace(/^.*$/gm, (line) => {
      const markers = Array.from(line.matchAll(/(?:^|(?<=\s))(\d{1,3})\s*[.)]\s*(?=[^\d\s])(?![.\s]*[-_–—…]{2,})/g));
      if (markers.length !== 2) return line;
      const nums = markers.map((m) => parseInt(m[1], 10));
      if (Math.abs(nums[1] - nums[0]) !== 1) return line;
      if (/(?:^|\s)\d{1,2}:\d{2}/.test(line)) return line;
      const at = markers[1].index ?? -1;
      if (at <= 0) return line;
      const tail = line.slice(at);
      if ((tail.match(/[A-Za-z]/g) ?? []).length < 3) return line;
      return line.slice(0, at).trimEnd() + '\n' + tail;
    })
    // Stem-less slot rows (#qu2 wave 4, pm57 A/R): "21. …… 22. …… 23. …… 24.
    // ……" (picture rows) and empty table cells "79.  80." — ≥2 numbered
    // markers whose fragments carry NO prose (blanks/punct only). The stems
    // are the printed pictures / table columns, so each marker is its own
    // stem-less question. The prose split above rejects these (its cloze
    // guard sees the blank run; its \S lookahead sees the next digit), so
    // they need this dedicated blank-only path. A READ-THE-TEXT table task
    // ("Read the text, then complete the table") keeps its row intact — the
    // whole grid is ONE task filled from the passage (10th-first L).
    .replace(/^.*$/gm, (line) => {
      if (readTextTableTask) return line;
      const slots = Array.from(line.matchAll(/(?:^|(?<=\s))(\d{1,3})\s*[.)]\s*/g));
      if (slots.length < 2) return line;
      const nums = slots.map((m) => parseInt(m[1], 10));
      for (let i = 1; i < nums.length; i++) if (Math.abs(nums[i] - nums[i - 1]) !== 1) return line;
      const fragOk = (s: string) => /^[\s.\u2026_-]*$/.test(s);
      if (!fragOk(line.slice(0, slots[0].index ?? 0))) return line;
      for (let i = 0; i < slots.length; i++) {
        const from = (slots[i].index ?? 0) + slots[i][0].length;
        const to = i + 1 < slots.length ? slots[i + 1].index ?? line.length : line.length;
        if (!fragOk(line.slice(from, to))) return line;
      }
      let out = line;
      for (let i = slots.length - 1; i >= 0; i--) {
        const at = slots[i].index ?? -1;
        if (at <= 0) continue;
        out = out.slice(0, at).trimEnd() + '\n' + out.slice(at);
      }
      return out;
    })
    // Two-column answer rows (#qu2 wave 4, p8214 row 10): "36) quick …………
    // 40) angry …………" — TWO mini-questions share one printed line, each
    // fragment ending in its own answer space (never prose). A trailing bare
    // number is the NEXT row's mark cell riding the extraction — split it
    // onto its own line so the row mark look-back still sees it.
    .replace(/^.*$/gm, (line) => {
      const markers = Array.from(line.matchAll(/(?:^|(?<=\s))(\d{1,3})\s*[.)]\s*/g));
      if (markers.length !== 2) return line;
      const nums = markers.map((m) => parseInt(m[1], 10));
      if (nums[1] <= nums[0]) return line;
      if (/(?:^|\s)\d{1,2}:\d{2}/.test(line)) return line;
      const endsWithBlank = (t: string) => /(?:\.{2,}|…+|_{2,}|[-\u2013\u2014]{2,})\s*[.\s]*$/.test(t);
      const at1 = markers[1].index ?? 0;
      const frag1 = line.slice((markers[0].index ?? 0) + markers[0][0].length, at1);
      const frag2 = line.slice(at1 + markers[1][0].length);
      if (!endsWithBlank(frag1) || !endsWithBlank(frag2)) return line;
      const tailNum = frag2.match(/(?:\.{2,}|…+|_{2,}|[-\u2013\u2014]{2,})\s*[.\s]*(\d{1,2})\s*$/);
      let second = line.slice(at1);
      if (tailNum) second = line.slice(at1, at1 + markers[1][0].length + tailNum.index! + tailNum[0].length - tailNum[1].length - (tailNum[0].length - tailNum[0].trimEnd().length)).trimEnd();
      let out = line.slice(0, at1).trimEnd() + '\n' + (tailNum ? second : line.slice(at1).trimEnd());
      if (tailNum) out += '\n' + tailNum[1];
      return out;
    })
    // Numbered answer-space rows (#qu2 wave 5 — p43266 row 4): "1…………..they
    // ………….when the teacher came in ? ( talk )" — the row number is printed
    // DIRECTLY against its answer space, so the cloze-blank lookahead reads
    // it as a gap slot and the row never opens. A trailing single-word paren
    // cue ("( talk )") proves a form-in-parentheses row: normalize the
    // number+space into a "N." start, keeping the paren cue in the stem.
    // Choice-paren tails ("( have – to have )") stay out — those rows belong
    // to the number-in-blank path.
    .replace(/^(\d{1,3})(?!\d)(?:\.{2,}|…+|_{2,}|[-\u2013\u2014]{2,})\s*([^()\n]*\(\s*[A-Za-z][A-Za-z\s']{0,20}\))\s*$/gm,
      (_m, num, rest) => `${num}. ${String(rest).trim()}`
    );
  let category = rawSec.category;
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  // Brain-block category parity (G5): the text splitters classify every block
  // with detectInitialCategory, passing the OPENER line as the strong-signal
  // header (pass 1) — brain blocks must do the same or a stray subject word
  // inside a question body ("He was listening to the music") hijacks the
  // category via the weaker body pass.
  if (rawSec.brain && category === 'General' && !labelPinned) {
    category = detectInitialCategory(lines[0] ?? '', brainText);
  }

  let title = `Section ${rowId}`;
  if (headerLine && headerLine.length > 2) {
    title = `Section ${rowId}: ${headerLine.replace(/\(\s*[\d\.]+\s*(?:marks?|نمره|pts?|points?)?\s*\)/i, '').trim()}`;
  }

  let persianInstruction = '';
  let englishInstruction = '';
  let englishInstructionPrimary = '';
  let hasWordBank = false;
  let wordBank: string[] = [];
  let hasPassage = false;
  let passageTitle = '';
  let passageText = '';

  // Extract instructions
  const persianLines = lines.filter(
    (l) => /[\u0600-\u06FF]/.test(l) && !/^\d+[\.\)]/.test(l) && !/دبیرستان|آموزش و پرورش/i.test(l) && !isFurnitureLine(l),
  );
  if (persianLines.length > 0) {
    persianInstruction = persianLines.join(' ');
  }

  const englishInstLines = lines.filter(
    (l) =>
      /^(?:Choose|Fill in|Read|Match|Write|Make|Unscramble|Complete|Listen|Answer|Look at|Combine|Put|Find|According|Circle|Order|Sort|Change)/i.test(l) ||
      /\b(?:correct answer|words given|parentheses|following passage|the questions)\b/i.test(l),
  );
  if (englishInstLines.length > 0) {
    // R6-c: fold ALL instruction lines into the contract probe — subtask
    // banners ("Write T (true) or F (false)", "Match two halves") carry the
    // real contract for the rows below them; only the first line used to be
    // probed. EXCLUSION (earned on p4t7882699): a Match line must not flood
    // a fill/complete primary task — matching would claim the whole
    // section's word-bank rows. The PRIMARY line stays separately available:
    // the early section-wide matching claim must judge the sheet's own task,
    // not a later subtask's (p8214 sec 1).
    const primaryInst = englishInstLines[0].trim();
    const primaryFill = /^(?:Complete|Fill|Use)\b/i.test(primaryInst);
    englishInstructionPrimary = primaryInst;
    englishInstruction = englishInstLines
      .filter((l) => !(primaryFill && /^Match\b/i.test(l.trim())))
      .join(' ');
  }

  // --- 4. Word Bank Extraction ---
  // Detects word pools from:
  // a) Bracketed boxes like [careful, pollution, healthy, dangerous, exercise]
  // b) Parenthetical word pools ( a / b / c )
  // c) Lines of standalone candidate words near instructions
  // d) Single-space Latin word rows (canonicalization collapses box spacing)
  wordBank = extractWordBankWordsFromBlock(text, lines);
  if (wordBank.length >= 3) {
    hasWordBank = true;
    // A phrase bank ("busy with their work" ...) serves passage-fill reading
    // tasks; single-word banks are vocabulary material.
    const phraseBank = wordBank.every((w) => w.trim().split(/\s+/).length >= 2);
    if (phraseBank && (category === 'General' || category === 'Grammar')) category = 'Reading';
    else if (category === 'General') category = 'Vocabulary';
  }

  // --- 4a. Word-bank scope (#bank-scoping) --------------------------------
  // A hyphen-separated bank row ("Died out- entertainment- solve- plains")
  // applies ONLY to the numbered items between the row and the next task
  // boundary ("Choose the best answer"). Every other bank shape (bracket /
  // comma / slash pools) keeps the legacy section-wide behavior (span=null).
  const bankSpan = findWordBankSpan(text, wordBank);

  // --- 4b. Generic prose passage (form-fill sources) -----------------------
  // "I'm Nima Shamsi. I am 13 and in 7th grade…" — multi-line Latin prose
  // with no blanks, no dialogue speakers, no option markers. Questions below
  // such prose fill a form from it, so it is the section's reading passage.
  if (!hasPassage) {
    const prose: string[] = [];
    for (const l of lines) {
      const words = l.split(/\s+/).filter(Boolean);
      const isProse =
        words.length >= (prose.length > 0 ? 4 : 8) &&
        !/(\.{3,}|_{3,}|…)/.test(l) &&
        !/^\s*[\w'’\-]{2,20}\s*:/.test(l) &&
        !/^\s*\d/.test(l) &&
        (l.match(/\b[a-d][.)\-–—]\s*\S/gi) || []).length < 2 &&
        (l.match(/\//g) || []).length < 2 && // scramble soup ("always / she / late …") is not prose
        (l.match(/[A-Za-z]/g) || []).length >= (l.match(/[\u0600-\u06FF]/g) || []).length;
      if (isProse) prose.push(l);
      else if (/[؀-ۿ]/.test(l) && /بخوانید|کامل\s*کنید|دهید|کنید|مرتب/.test(l)) prose.length = 0; // bilingual instruction between title and prose: reset, don't kill the run
      else if (prose.length > 0) break; // prose runs are contiguous
    }
    // Blank-run ownership (#qu2 wave 5): when the block carries its own
    // numbered blanks ("( 38 )……."), the blank-run collector below owns the
    // passage — the generic prose rule must not claim a lone blank-less wrap
    // line ("…useful for our", 17 words) as the whole passage (pc4i L: that
    // fragment held none of the four blanks and starved the inline extractor).
    const blockBlankHits = lines.reduce(
      (acc, l) =>
        acc +
        [...l.matchAll(/\(\s*\d{1,3}\s*\)\s*(?:\.{2,}|…+|_{2,}|-{2,})|(?:\.{2,}|…+)\s*\d{1,3}\s*(?:\.{2,}|…+)/g)]
          .length,
      0,
    );
    if (prose.length >= 2 || (prose.length === 1 && prose[0].split(/\s+/).length >= 15 && blockBlankHits < 2)) {
      hasPassage = true;
      passageTitle = `Reading Passage (${rowId})`;
      passageText = prose.join(' ');
      if (category === 'General') category = 'Reading';
    }
  }

  // Prose carrying its own numbered blanks ("my name is sahar. I live in
  // (1)…………… … (2)……………"): the prose line IS the passage and each printed
  // blank is a question on it (mock-09 A). The generic prose rule rejects
  // blank-carrying lines, so detect this shape explicitly. The blanks may
  // spread ONE PER LINE across a wrapped passage ("…children, ( 38 )……" /
  // "many different ways… / "body, ( 39 )……." — pc4i517871 L) — collect the
  // contiguous wordy run and count the blanks across it.
  if (!hasPassage) {
    for (let li = 0; li < lines.length; li++) {
      const l = lines[li];
      const wordCount = l.split(/\s+/).filter(Boolean).length;
      const inlineBlankHits = [...l.matchAll(/\(\s*(\d{1,3})\s*\)\s*(?:\.{2,}|…+|_{2,}|-{2,})|(?:\.{2,}|…+)\s*\d{1,3}\s*(?:\.{2,}|…+)/g)];
      if (wordCount >= 12 && inlineBlankHits.length >= 2 && !/^\s*\d/.test(l)) {
        // Contiguous blank-paragraph collection (R2, p91294 sec4): audio-fill
        // passages wrap over several lines and the (N) blanks spread across
        // them — collect the wordy run after the first blank line instead of
        // taking one line and stranding blanks (14)-(18) in untaken prose.
        const run = [l];
        for (let k = li + 1; k < lines.length; k++) {
          const nl = lines[k];
          const words = nl.split(/\s+/).filter(Boolean).length;
          const hits = [...nl.matchAll(/\(\s*(\d{1,3})\s*\)\s*(?:\.{2,}|…+|_{2,}|-{2,})|(?:\.{2,}|…+)\s*\d{1,3}\s*(?:\.{2,}|…+)/g)].length;
          const wordy =
            words >= 5 &&
            !/^\s*\d/.test(nl) &&
            !/^\s*[\w'’\-]{2,20}\s*:/.test(nl) &&
            (nl.match(/\b[a-d][.)]/gi) || []).length < 2;
          if (!wordy) break;
          // A wrap line that asks a question is the task list beginning.
          if (hits === 0 && /\?\s*$/.test(nl)) break;
          run.push(nl);
        }
        hasPassage = true;
        passageTitle = `Reading Passage (${rowId})`;
        passageText = run.join('\n');
        if (category === 'General') category = 'Reading';
        break;
      }
    }
  }
  if (!hasPassage) {
    const runLines: string[] = [];
    let runBlanks = 0;
    for (const l of lines) {
      const words = l.split(/\s+/).filter(Boolean).length;
      const hits = [...l.matchAll(/\(\s*\d{1,3}\s*\)\s*(?:\.{2,}|…+|_{2,}|-{2,})|(?:\.{2,}|…+)\s*\d{1,3}\s*(?:\.{2,}|…+)/g)].length;
      const wordy = words >= 5 && !/^\s*\d/.test(l) && !/^\s*[\w'’\-]{2,20}\s*:/.test(l);
      if (wordy && (hits > 0 || runLines.length > 0)) {
        runLines.push(l);
        runBlanks += hits;
      } else if (runLines.length > 0 && hits === 0 && words >= 5 && runLines.length > 0 && runLines[runLines.length - 1].split(/\s+/).filter(Boolean).length >= 5) {
        runLines.push(l); // blank-less wrap line inside the run
      } else if (runLines.length > 0) {
        break;
      }
    }
    if (runBlanks >= 2 && runLines.length >= 2) {
      hasPassage = true;
      passageTitle = `Reading Passage (${rowId})`;
      passageText = runLines.join('\n');
    }
  }

  // Cloze Test
  if (/cloze/i.test(text) || /\b\d+\)\s*-+/.test(text)) {
    hasPassage = true;
    passageTitle = `Cloze Passage (${rowId})`;
    const passageLines = lines.filter(
      (l) =>
        !/cloze|جاهای خالی|Choose|Read the following/i.test(l) &&
        !/^\d+\.?[a-d]\./i.test(l) &&
        !/^[a-d]\./i.test(l) &&
        l.length > 25,
    );
    passageText = passageLines.join(' ');
    if (category === 'General') category = 'Reading';
  }

  // Reading Passage
  if (/Passage\s+(?:I|II|\d+)|Reading\s+comprehension|درک\s*مطلب/i.test(text)) {
    hasPassage = true;
    const passageMatch = text.match(/(Passage\s+(?:I|II|\d+)[^\n]*)/i);
    passageTitle = passageMatch ? passageMatch[1] : `Reading Passage (${rowId})`;
    const bodyLines = lines.filter(
      (l) =>
        !/Reading comprehension|درک\s*مطلب|Passage\s+[I|V|X\d]/i.test(l) &&
        !/^\d+[\.\)]/i.test(l) &&
        l.length > 35,
    );
    passageText = bodyLines.join('\n');
    if (category === 'General') category = 'Reading';
  }

  // --- Extract Questions inside this section ---
  const questions: QuestionItem[] = extractQuestionsFromText(
    text,
    rowId,
    category,
    wordBank,
    passageText,
    anomalies,
    options,
    traceCtx,
    bankSpan,
    `${title || ''} ${persianInstruction || ''} ${englishInstruction || ''}`,
  );
  if (process.env.PARSE_DEBUG) {
    const q25 = questions.find((q) => Number(q.number) === 25);
    const q16 = questions.find((q) => Number(q.number) === 16);
    if (q25 || q16) console.error('[stage1]', 'q16', q16?.type, 'q25', q25?.type);
  }

  // Synonym/antonym word pairs: "rude ≠ ------   neat = ------" — each
  // word+symbol+blank group is one open item (the section instruction says
  // متضاد/متراد/antonym).
  if (questions.length === 0 && /تضاد|هتضاد|مترادف|هترادف|antonym|synonym/i.test(`${title} ${persianInstruction}`)) {
    const pairs: string[] = [];
    for (const l of lines) {
      const re = /([A-Za-z]{2,20})\s*([\u2260=])\s*([.\u2026_\u2013\u2014-]{2,}|…+)/g;
      let m: RegExpExecArray | null;
      while ((m = re.exec(l))) pairs.push(`${m[1]} ${m[2]} ${m[3]}`);
    }
    if (pairs.length >= 2) {
      pairs.forEach((stem, i) => {
        questions.push({
          id: `q-${rowId}-syn-${i + 1}`,
          number: i + 1,
          displayNumber: String(i + 1),
          sectionRowId: rowId,
          sectionName: category,
          type: 'short_answer',
          typeEnName: getQuestionTypeInfo('short_answer').enName,
          typeFaName: getQuestionTypeInfo('short_answer').faName,
          stem: cleanStem(stem),
          mark: 0.5,
          parentContextType: 'none',
          hasImage: false,
        } as QuestionItem);
      });
      if (category === 'General') category = 'Vocabulary';
    }
  }

  const isMatchingTask =
    /ستون|متصل\s*کنید|وصل\s*کنید|match/i.test(`${title} ${persianInstruction} ${englishInstructionPrimary || englishInstruction}`) ||
    // R3: picture-match sections whose Persian instruction was lost to the
    // split still carry it in the block text ("با توجه به تصاویر" —
    // 91294 5, 53x7 3). The bare-slot relaxation in the matching branch is
    // the only consumer of this widened trigger; prose rows need cues.
    faFlex('62a 635 627 648 6cc 631|645 637 627 628 642 62a|62c 641 62a').test(rawSec.text.slice(0, 900).replace(/\s+/g, ' '));
  // Matching/definition-pairing rows are vocabulary work corpus-wide (every
  // frozen matching GT — mock-10 A, pq89 16, pc4i D, pm57 B, p8214 2 — says
  // Vocabulary), so a General banner-less matching row inherits it.
  if (isMatchingTask && category === 'General') category = 'Vocabulary';

  // Audio/table prose fills: printed number + blank-run rows ("We 42 …… (visit)",
  // "a foreign 12 ---------------.", "54…………. 53………….") — the rule table sees
  // no line-start numbers and the fallback sees no "N." starts, so the printed
  // numbers ARE the question set. Runs BEFORE the unnumbered rescues: a section
  // carrying >=2 such rows is a numbered fill family, not loose items.
  // NEVER when the section owns a passage: passage blanks belong to the
  // inline-blanks/trail owners below (pm57 D — the audio-fill bank reset
  // used to strip the word bank from passage rows typed word_bank_fill).
  if (questions.length === 0 && !isMatchingTask) {
    const numFirst: { l: string; num: number; form: boolean }[] = [];
    for (const l of lines) {
      // TWO printed-number shapes (radif lane: the printed number IS the
      // question set):
      //   bare   — "12 ---------------." / "54…………. 53…………." — the original
      //            audio/table fill family; owns its rows even when the section
      //            carries prose (11th-first D runs its numbered blanks INSIDE
      //            a traveled-to passage).
      //   paren  — "You (31) ………… (invite)" — the dialogue/form-fill variant:
      //            the index sits INSIDE parens before the gap. Only outside
      //            passages — a passage's "…… (33) ……" bracket-index gaps
      //            belong to the inline-blanks owner below (pm57 D keeps its
      //            word bank).
      const reBare = /(?<![\d.\u2026_])(\d{1,3})(?!\d)\s*(?:[-–—.]\s*)?(?:-{2,}|\.{2,}|…+|_{2,})/g;
      const reParen = /\(\s*(\d{1,3})\s*\)\s*(?:-{2,}|\.{2,}|…+|_{2,})/g;
      const collect = (re: RegExp) => {
        let m2: RegExpExecArray | null;
        while ((m2 = re.exec(l)) !== null) {
          const num = parseInt(m2[1], 10);
          if (num < 1 || num > 150) continue;
          const tail = l.slice(m2.index + m2[0].length, m2.index + m2[0].length + 14);
          const form = /\s*\(\s*[a-z]{2,12}/i.test(tail);
          if (!numFirst.some((t) => t.num === num)) numFirst.push({ l, num, form });
        }
      };
      collect(reBare);
      if (!hasPassage) collect(reParen);
    }
    if (numFirst.length >= 2) {
      // A "bank" built from table-header debris ("Countable noun Adverb of
      // place Object Verb Subject") must not survive into these questions.
      if (wordBank.length > 0) {
        wordBank.length = 0;
        hasWordBank = false;
        if (category === 'Vocabulary') category = 'General';
      }
      numFirst.sort((a, b) => a.num - b.num);
      for (const { l, num, form } of numFirst) {
        const t: QuestionType = /^(?:active|passive)\s*:/i.test(l.trim())
          ? 'active_passive'
          : form
            ? 'form_in_parentheses'
            : 'fill_blank';
        questions.push({
          id: `q-${rowId}-audiofill-${num}`,
          number: num,
          displayNumber: String(num),
          sectionRowId: rowId,
          sectionName: category,
          type: t,
          typeEnName: getQuestionTypeInfo(t).enName,
          typeFaName: getQuestionTypeInfo(t).faName,
          stem: cleanStem(l),
          mark: 0,
          parentContextType: passageText ? 'reading_passage' : 'none',
          parentContextTitle: passageText ? `Reading Passage (${rowId})` : undefined,
          parentContextText: passageText || undefined,
          hasImage: false,
        } as QuestionItem);
      }
    }
  }

  // Blank-run adjacency to a printed number ("……64……" / "50. ……" / dialogue
  // "…… (9)"): the numbered-blank signal shared by the rescue guards below.
  // Paren-wrapped indices ("…… (33)") count too — the dialogue/cloze passages
  // print the blank's number in brackets after the gap (#qu2 wave 4, pm57).
  const hasNumberedBlank = (l: string): boolean =>
    /\d{1,3}\s*(?:[-–—.]?\s*)?(?:\.{2,}|…+|_{2,})/.test(l) ||
    /(?:\.{2,}|…+|_{2,})\s*\d{1,3}/.test(l) ||
    /(?:\.{2,}|…+|_{2,})\s*\(\s*\d{1,3}\s*\)/.test(l) ||
    /\(\s*\d{1,3}\s*\)\s*(?:\.{2,}|…+|_{2,})/.test(l);

  // Unnumbered bank-fill task: a word bank + a short text carrying dotted
  // blanks ("Bahador writes about new year… people …… the first day…") — the
  // WHOLE text is ONE question filled from the bank, not N separate items.
  if (questions.length === 0 && wordBank.length >= 3) {
    const fillLines = lines.filter((l) => {
      if (!BLANK_RUN.test(l) || (l.match(/\b[A-Za-z]+\b/g) || []).length < 4) return false;
      // Inline choice groups ("… ( in / on / at ) home now.") and scramble
      // soups are per-line questions, never a wrapped bank-fill prose
      // (mock-05 E/D used to glue into one fake task).
      if (/\([^()]*\//.test(l) || /\[[^[]*\//.test(l)) return false;
      if ((l.match(/\//g) || []).length >= 2) return false;
      return true;
    });
    // Short one-blank sentences ("It's famous for its hot ……… .") are
    // separate per-line questions (the implicit pass below handles them);
    // a long wrapped text is ONE task.
    const hasLongLine = fillLines.some((l) => l.split(/\s+/).length >= 12);
    // Printed blank numbers ("……64……") mean per-blank questions (the trail /
    // audio-fill passes own them), never ONE bank task.
    const hasNumberedBlanks = fillLines.some(hasNumberedBlank);
    if (process.env.PARSE_DEBUG) console.error('[bank-task]', JSON.stringify({ nQ: questions.length, wb: wordBank.length, fill: fillLines.length, long: hasLongLine, numbered: hasNumberedBlanks, samples: fillLines.slice(0, 3) }));
    if (fillLines.length >= 1 && hasLongLine && !hasNumberedBlanks) {
      questions.push({
        id: `q-${rowId}-bank-task`,
        number: 1,
        displayNumber: '1',
        sectionRowId: rowId,
        sectionName: category,
        type: 'word_bank_fill',
        typeEnName: getQuestionTypeInfo('word_bank_fill').enName,
        typeFaName: getQuestionTypeInfo('word_bank_fill').faName,
        stem: cleanStem(fillLines.join('\n')),
        mark: 0.5,
        parentContextType: 'word_bank',
        parentContextTitle: `Word Bank (${rowId})`,
        parentContextText: `Candidate Words: [${wordBank.join(', ')}]`,
        wordBankWords: [...wordBank],
        hasImage: false,
      } as QuestionItem);
    }
  }

  // Duplicate printed numbers inside one section: two lettered sub-parts
  // (a/b) each restart at 1. Renumber sequentially in DOCUMENT order — but
  // ONLY when the sequence actually RESETS (a number drops). A non-decreasing
  // sequence with one repeated number ("31, 32, 33, 33, 34, 35" — the sheet's
  // own numbering typo, real-exam 14050319 section C) is the printed truth:
  // renumbering it used to erase the printed 31-39 of the whole section.
  if (questions.length > 1) {
    const nums = questions.map((q) => Number(q.number));
    if (new Set(nums).size !== nums.length) {
      const ordered = [...questions].sort(
        (a, b) => ((a.receipt as any)?.lineStart ?? 0) - ((b.receipt as any)?.lineStart ?? 0),
      );
      const hasReset = ordered.some(
        (q, i) => i > 0 && Number(q.number) < Number(ordered[i - 1].number),
      );
      if (hasReset) {
        ordered.forEach((q, i) => {
          q.number = i + 1;
          q.displayNumber = String(i + 1);
        });
        questions.length = 0;
        questions.push(...ordered);
      }
    }
  }

  // Unnumbered fill sentences in a word-bank section (I-genre): each Latin
  // line carrying a blank is a question; number them in order of appearance.
  if (questions.length === 0 && hasWordBank) {
    let implicitNum = 1;
    for (const l of lines) {
      if (BLANK_RUN.test(l) && (l.match(/\b[A-Za-z]+\b/g) || []).length >= 4 &&
          !/^\s*[\w'\u2019\-]{2,20}\s*:/.test(l) && !/[\u0600-\u06FF]/.test(l) &&
          !hasNumberedBlank(l) &&
          // Inline choice groups ("… ( in / on / at ) home now.") are choice
          // rows, not bank fills — the multi-item rescue owns them.
          !/\([^()]*\//.test(l) && !/\[[^[]*\//.test(l)) {
        questions.push({
          id: `q-${rowId}-implicit-${implicitNum}`,
          number: implicitNum,
          displayNumber: String(implicitNum),
          sectionRowId: rowId,
          sectionName: category,
          type: 'word_bank_fill',
          typeEnName: getQuestionTypeInfo('word_bank_fill').enName,
          typeFaName: getQuestionTypeInfo('word_bank_fill').faName,
          stem: cleanStem(l),
          mark: 0.5,
          parentContextType: 'none',
          hasImage: false,
        } as QuestionItem);
        implicitNum++;
      }
    }
  }

  // Unnumbered inline-MCQ rows ("my sister is ……… in painting.  a. interested
  // b. interesting c. interest"): stem and its option set share one line and
  // no row carries a printed number. One MCQ per line; the blank run in the
  // stem is required so pure option-grid rows (odd-one-out quads) stay out.
  if (questions.length === 0 && !isMatchingTask && !hasPassage) {
    const inlineMcq = lines.filter((l) => {
      const words = l.split(/\s+/).filter(Boolean).length;
      const markers = (l.match(/(?:^|\s)[a-d][.)][ \t]*\S/gi) || []).length;
      return words >= 6 && markers >= 2 && BLANK_RUN.test(l);
    });
    if (inlineMcq.length >= 2) {
      for (const l of inlineMcq) {
        const mcq = extractMultipleChoiceOptions(l);
        if (!mcq) continue;
        questions.push({
          id: `q-${rowId}-inline-mcq-${questions.length + 1}`,
          number: questions.length + 1,
          displayNumber: String(questions.length + 1),
          sectionRowId: rowId,
          sectionName: category,
          type: 'multiple_choice',
          typeEnName: getQuestionTypeInfo('multiple_choice').enName,
          typeFaName: getQuestionTypeInfo('multiple_choice').faName,
          stem: cleanStem(mcq.stem),
          options: mcq.options,
          mark: 0,
          parentContextType: 'none',
          hasImage: false,
        } as QuestionItem);
      }
    }
  }

  // Unnumbered multi-item sections (#qu-corpus): dictation completions,
  // intonation sentence lists, phrase-translation pairs — marks-table rows
  // print items with NO numbers at all, so the rule table sees no question
  // starts and drops everything. Implicit-number every item line 1..N.
  // Matching-flavored instructions are left to the merged-pair matching path.
  // A passage normally keeps this whole block out — EXCEPT when the passage
  // text does NOT own the numbered blanks (its extraction may only capture
  // the prose head) while the raw lines do (pm57 D: "…… (33) ……" sits past
  // the captured head) — then the trail rows below must still own them.
  const numberedBlankShape = /\(\s*\d{1,3}\s*\)\s*(?:\.{2,}|…+|_{2,})|(?:\.{2,}|…+|_{2,})\s*\(\s*\d{1,3}\s*\)/;
  const passageOwnsNumberedBlanks =
    hasPassage && (passageText.match(new RegExp(numberedBlankShape.source, 'g')) || []).length >= 2;
  if (questions.length === 0 && !isMatchingTask && (!hasPassage || !passageOwnsNumberedBlanks)) {
    const isItemLine = (l: string): boolean => {
      const latinWords = (l.match(/\b[A-Za-z]+\b/g) || []).length;
      const persianWords = (l.match(/[\u0600-\u06FF]+/g) || []).length;
      if (/^[.\u2026_\s]+$/.test(l)) return false; // blank-only line
      if (/^(?:Fill|Complete|Choose|Read|Match|Write|Make|Unscramble|Listen|Answer|Look|Put|Use|Circle|Cross)\b/i.test(l) && !BLANK_RUN.test(l)) return false;
      if (looksLikeOptionRow(l) >= 0.8) return false; // options row, not an item
      // Merged matching pair ("<answer> 1.<question>") — left for the
      // matching branch in applyLayoutRefinements, never a plain item.
      if (latinWords >= 2 && /^(.*?\S)\s+\d{1,2}\s*[\.)]\s*\S/.test(l)) return false;
      if (persianWords === 0) {
        // Latin line: an item when it carries words or a dictation completion.
        return latinWords >= 1 && (/[A-Za-z]{2,}/.test(l) || /(?:\.{3,}|…|_{3,})/.test(l));
      }
      // Mixed/Persian: an item only when it ASKS something ("به چه معناست؟").
      // Persian instructions with a stray English word ("… از can بنویسید.")
      // carry no question mark and stay out.
      return /\?|؟/.test(l);
    };
    const items = lines.slice(1).filter(isItemLine);
    // Trailing-numbered blank rows ("Is it a …… 1 ?") — listening cloze rows
    // whose blank number FOLLOWS the dotted gap: one fill question per row,
    // numbered by the printed trailing index.
    const trail: { l: string; num: number }[] = [];
    for (const l of lines) {
      // Paren-wrapped index ("…… (9)") allowed — bidi dialogue/cloze passages
      // print the blank's number in brackets right after the gap.
      const re1 = /(?:\.{2,}|…+|_{2,})[.\s]*\(?\s*(\d{1,3})\s*\)?\b/g;
      let m1: RegExpExecArray | null;
      while ((m1 = re1.exec(l)) !== null) {
        const num = parseInt(m1[1], 10);
        if (!trail.some((t) => t.num === num)) trail.push({ l, num });
      }
    }
    if (trail.length >= 2) {
      // A phrase bank present means the blanks are filled FROM the bank
      // (phrase-fill genre), not loose listening cloze rows.
      const trailType: QuestionType =
        wordBank.length >= 3 && wordBank.every((w) => w.trim().split(/\s+/).length >= 2)
          ? 'word_bank_fill'
          : 'fill_blank';
      for (const { l, num } of trail) {
        questions.push({
          id: `q-${rowId}-trail-${num}`,
          number: num,
          displayNumber: String(num),
          sectionRowId: rowId,
          sectionName: category,
          type: trailType,
          typeEnName: getQuestionTypeInfo(trailType).enName,
          typeFaName: getQuestionTypeInfo(trailType).faName,
          stem: cleanStem(l),
          mark: 0,
          parentContextType: 'none',
          hasImage: false,
        } as QuestionItem);
      }
    }
    if (trail.length >= 2) items.length = 0;
    // A single-line section whose only line asks something ("… به چه معناست؟")
    // is itself the question — the header line doubles as the item. Item
    // lines stay passage-gated: a passage without numbered blanks is prose,
    // never a list of implicit items (the passage-task fallback owns it).
    if (!hasPassage) {
      if (items.length === 0 && lines.length === 1 && /\?|؟/.test(lines[0])) items.push(lines[0]);
    for (const item of items) {
      // Multi-group inline-choice lines (#qu2 wave 4, p8214 sec 7): "Mr
      // (Amini / amini) is a postman. He has two (childs / children)." —
      // each choice group fills its own blank (the sheet numbers 1..6
      // ACROSS the groups). One question per group, numbered in order.
      const groupCount = (item.match(/\([^()]*\/[^()]*\)/g) || []).length;
      for (let gi = 0; gi < Math.max(1, groupCount); gi++) {
      const num = questions.length + 1;
      const mcq = extractMultipleChoiceOptions(item);
      // Minimal shape inference — unscramble soups, form cues and choice
      // groups must not collapse to short_answer. Deliberately NOT the full
      // instruction mapper: picture/dialogue vocabulary there mistyped corpus
      // sections (golden: 9th 1-3 D, zaban-haftom 7).
      const noBlank = !BLANK_RUN.test(item);
      const lastParen = item.lastIndexOf('(');
      const fm = item.match(/\(\s*([a-z]{2,12})\s*\)\s*$/);
      const inline = extractInlineChoices(item);
      const t: QuestionType = mcq
        ? 'multiple_choice'
        : inline
          ? 'inline_choice'
          : noBlank && (item.match(/\//g) || []).length >= 3
            ? 'unscramble'
            : fm && /\.{3,}|…|_{3,}/.test(item.slice(0, lastParen))
              ? 'form_in_parentheses'
              : 'short_answer';
      questions.push({
        id: `q-${rowId}-unnum-${num}`,
        number: num,
        displayNumber: String(num),
        sectionRowId: rowId,
        sectionName: category,
        type: t,
        typeEnName: getQuestionTypeInfo(t).enName,
        typeFaName: getQuestionTypeInfo(t).faName,
        stem: cleanStem(mcq ? mcq.stem : item),
        options: mcq ? mcq.options : inline ? inline.options : undefined,
        mark: 0,
        parentContextType: 'none',
        hasImage: false,
      } as QuestionItem);
      }
    }
    }
  }

  // Dialogue-tail continuation (#qu2 wave 4, p8214 Listening): the last
  // question's block absorbed UNNUMBERED speaker turns ("A: when I came in,
  // you were …… B: I was reading a book about ……") — each blank-carrying
  // turn is its own continuation question (the sheet leaves them unnumbered;
  // the exam's own sequence continues).
  if (questions.length >= 2 && !isMatchingTask && !hasPassage) {
    const lastQ = questions[questions.length - 1];
    const stemText = lastQ.stem || '';
    const parts = stemText.split(/\s+(?=[AB]:\s)/);
    if (parts.length >= 3) {
      const tailTurns = parts.slice(1).filter((p) => BLANK_RUN.test(p));
      {
        const head = parts[0].trim();
        if (tailTurns.length >= 2 && head.length >= 2) {
          lastQ.stem = cleanStem(head);
          for (const turn of tailTurns) {
            questions.push({
              id: `q-${rowId}-dlg-${questions.length + 1}`,
              number: questions.length + 1,
              displayNumber: String(questions.length + 1),
              sectionRowId: rowId,
              sectionName: category,
              type: 'fill_blank',
              typeEnName: getQuestionTypeInfo('fill_blank').enName,
              typeFaName: getQuestionTypeInfo('fill_blank').faName,
              stem: cleanStem(turn),
              mark: 0,
              parentContextType: 'dialogue_context',
              parentContextTitle: `Dialogue (${rowId})`,
              parentContextText: tailTurns.join('\n'),
              hasImage: false,
            } as QuestionItem);
          }
        }
      }
    }
  }

  // Single unnumbered task sections ("جمله داده شده را با استفاده از can
  // بنویسید" + one sentence + one answer blank): the section printed no
  // question numbers at all. Keep the task as a single question instead of
  // dropping it. Pure-Persian production tasks ("… کمک کنید که … درخواست کند"
  // + a dotted answer line) have no Latin cue — the instruction IS the task.
  if (questions.length === 0 && !isMatchingTask && !hasPassage) {
    const hasDottedTail = /(?:\.{3,}|…|_{3,})/.test(lines[lines.length - 1] || '');
    const cue = [...lines]
      .reverse()
      .find((l) => {
        const latin = (l.match(/\b[A-Za-z]+\b/g) || []).length;
        return (
          latin >= 4 &&
          !/(\.{3,}|…|_{3,})/.test(l) &&
          !/^\s*[\w'\u2019\-]{2,20}\s*:/.test(l) &&
          latin > (l.match(/[\u0600-\u06FF]+/g) || []).length &&
          !/^(?:Fill|Complete|Choose|Read|Match|Write|Listen|Answer|Look)\b/i.test(l)
        );
      });
    if (cue) {
      const mcqCue = extractMultipleChoiceOptions(cue.trim());
      const cueType: QuestionType = mcqCue ? 'multiple_choice' : 'short_answer';
      questions.push({
        id: `q-${rowId}-task-0`,
        number: 1,
        displayNumber: '1',
        sectionRowId: rowId,
        sectionName: category,
        type: cueType,
        typeEnName: getQuestionTypeInfo(cueType).enName,
        typeFaName: getQuestionTypeInfo(cueType).faName,
        stem: mcqCue ? mcqCue.stem : cue.trim(),
        options: mcqCue ? mcqCue.options : undefined,
        mark: 0.5,
        parentContextType: 'none',
        hasImage: false,
      } as QuestionItem);
    } else if (hasDottedTail && lines.length >= 1) {
      // Pure-Persian task with only a dotted answer line beneath it: the
      // instruction line is the task stem.
      questions.push({
        id: `q-${rowId}-task-fa`,
        number: 1,
        displayNumber: '1',
        sectionRowId: rowId,
        sectionName: category,
        type: 'short_answer',
        typeEnName: getQuestionTypeInfo('short_answer').enName,
        typeFaName: getQuestionTypeInfo('short_answer').faName,
        stem: cleanStem(lines[0]),
        mark: 0.5,
        parentContextType: 'none',
        hasImage: false,
      } as QuestionItem);
    }
  }


  // Scattered-number inline choices (#qu2 wave 5 — p43266n364 row 5): the
  // bidi extraction drops each question's printed number onto its own line
  // ("1  2" / "3" / "4  5" / "6") while the sentences carry mid-sentence
  // choice parens ("He has two (child 's – children )"). The k-th digit
  // pairs with the k-th choice paren in reading order → inline_choice
  // questions. Requires a "choose the best option" contract and equal digit/
  // paren counts so an ordinary MCQ block never matches.
  if (questions.length < 2) {
    const digitLines: number[] = [];
    let digitTokens = 0;
    const choiceParens: { stem: string; parts: string[] }[] = [];
    for (const l of lines) {
      const t = l.trim();
      if (!t) continue;
      if (/^\d{1,2}(\s+\d{1,2})*$/.test(t)) {
        digitLines.push(1);
        digitTokens += (t.match(/\d{1,2}/g) || []).length;
        continue;
      }
      for (const pm of l.matchAll(/\(([^()\n]{1,40})\)/g)) {
        const inner = pm[1];
        const parts = inner
          .split(/\s*[–—-]\s*/)
          .map((p) => p.trim())
          .filter(Boolean);
        if (parts.length !== 2) continue;
        if (!parts.every((p) => /^[A-Za-z][A-Za-z'\u2019 ]{0,25}$/.test(p))) continue;
        const sentStart = l.lastIndexOf('.', (pm.index ?? 0));
        choiceParens.push({ stem: l.slice(Math.max(0, sentStart <= 0 ? 0 : sentStart + 1), (pm.index ?? 0) + pm[0].length).trim(), parts });
      }
    }
    if (
      digitLines.length >= 3 &&
      choiceParens.length >= 3 &&
      digitTokens === choiceParens.length &&
      /گزینه|choose\s+the\s+best|best\s+(?:one|option|answer)/i.test(`${title} ${text}`)
    ) {
      questions.length = 0;
      choiceParens.forEach((cp, idx) => {
        questions.push({
          id: `q-${rowId}-scatter-${idx}`,
          number: idx + 1,
          displayNumber: String(idx + 1),
          sectionRowId: rowId,
          sectionName: category,
          type: 'inline_choice',
          typeEnName: getQuestionTypeInfo('inline_choice').enName,
          typeFaName: getQuestionTypeInfo('inline_choice').faName,
          stem: cleanStem(cp.stem),
          options: cp.parts.map((p, i2) => ({ id: String.fromCharCode(97 + i2), text: p })),
          mark: 0,
          parentContextType: 'none',
          hasImage: false,
        } as QuestionItem);
      });
      questions.sort((a, b) => Number(a.number) - Number(b.number));
    }
  }

  // NOTE (wave 5): numbered option rows under a dot-blank passage (p43266
  // row 7, 11th-first P) type NATURALLY as multiple_choice — the option rows
  // ARE the questions. A cloze_item retype here was tried and REVERTED: the
  // frozen 11th-first GT pins multiple_choice for the identical shape, so
  // the p43266 GT was aligned to that convention instead.

  // A passage with a single production task ("به زمان گذشته تبدیل کنید") —
  // the passage lines were consumed as the reading text; the task itself is
  // ONE question whose stem is the passage. — UNLESS the passage carries its
  // own numbered blanks ("I live in (1)…… . we traveled to (2)……"): each
  // printed blank IS a question on the passage (mock-09 A).
  if (questions.length <= 1 && hasPassage && passageText && !isMatchingTask) {
    const inlineBlanks = [...passageText.matchAll(/\(\s*(\d{1,3})\s*\)\s*(?:\.{2,}|…+|_{2,}|-{2,})/g)];
    if (process.env.PARSE_DEBUG) console.error('[inline-blanks]', JSON.stringify({ nQ: questions.length, hp: hasPassage, ib: inlineBlanks.length, pt: passageText.slice(0, 150) }));
    if (inlineBlanks.length >= 2) {
      questions.length = 0;
      const sentences = passageText.split(/(?<=[.!?؟])\s+/);
      const seen = new Set<number>();
      for (const b of inlineBlanks) {
        const num = parseInt(b[1], 10);
        if (!Number.isFinite(num) || num <= 0 || seen.has(num)) continue;
        seen.add(num);
        const sent =
          sentences.find((s) => s.replace(/\s+/g, '').includes(`(${num})`)) || passageText;
        questions.push({
          id: `q-${rowId}-inline-${num}`,
          number: num,
          displayNumber: String(num),
          sectionRowId: rowId,
          sectionName: category,
          type: 'fill_blank',
          typeEnName: getQuestionTypeInfo('fill_blank').enName,
          typeFaName: getQuestionTypeInfo('fill_blank').faName,
          stem: cleanStem(sent),
          mark: 0,
          parentContextType: 'reading_passage',
          parentContextTitle: passageTitle || `Reading Passage (${rowId})`,
          parentContextText: passageText,
          hasImage: false,
        } as QuestionItem);
      }
      questions.sort((a, b) => Number(a.number) - Number(b.number));
    }
  }
  if (questions.length === 0 && hasPassage && passageText && !isMatchingTask) {
    questions.push({
      id: `q-${rowId}-passage-task`,
      number: 1,
      displayNumber: '1',
      sectionRowId: rowId,
      sectionName: category,
      type: 'short_answer',
      typeEnName: getQuestionTypeInfo('short_answer').enName,
      typeFaName: getQuestionTypeInfo('short_answer').faName,
      stem: cleanStem(passageText),
      mark: 0.5,
      parentContextType: 'reading_passage',
      parentContextTitle: passageTitle || `Reading Passage (${rowId})`,
      parentContextText: passageText,
      hasImage: false,
    } as QuestionItem);
  }

  // --- fix-7a: instruction-driven type/category remap ----------------------
  // The per-line type inference sees only each question's own text; the
  // section's Persian instruction carries the REAL task contract ("درست یا
  // نادرست بودن ... مشخص کنید", "به مجهول تبدیل کنید", "انشا: بنویسید",
  // "ترکیب کنید", "تلفظ", "کلمه نادرست را پیدا کنید"). Questions that fell
  // through to the short_answer/fill_blank/odd_one_out defaults are retyped
  // from that contract; categories follow the golden-corpus conventions
  // (T/F -> Reading, combine -> Writing, passive -> Grammar, essay -> Writing,
  // word-choice (گزینه) -> Vocabulary — surveyed 11/11 corpus inline_choice).
  {
    const instr = `${title} ${persianInstruction} ${englishInstruction}`
      .replace(/جمالت/g, 'جملات')
      .replace(/سواالت/g, 'سوالات');
    const retypable = (t: QuestionType) => t === 'short_answer' || t === 'fill_blank' || t === 'odd_one_out';
    const retype = (q: QuestionItem, t: QuestionType, opts?: ExamOption[]) => {
      q.type = t;
      q.typeEnName = getQuestionTypeInfo(t).enName;
      q.typeFaName = getQuestionTypeInfo(t).faName;
      if (opts) q.options = opts;
    };
    if (questions.length > 0) {
      const isTF =
        /درست\s*(?:یا|\/|و)\s*(?:نادرست|غلط)|صحیح\s*(?:یا|\/)\s*غلط|true\s*(?:or|\/)\s*false|t\s*\/\s*f/i.test(instr) ||
        questions.filter((q) => /\bT[.\s\u2610\u2611\u25A1\uE000-\uF8FF]*F[.\s\u2610\u2611\u25A1\uE000-\uF8FF]*$/.test((q.stem || '').trim())).length >= 2;
      const isCombine = /ترکیب\s*کنید/i.test(instr);
      const isPassive = /مجهول|معلوم|active\s+and\s+passive/i.test(instr);
      const isEssay = /انشا/i.test(instr);
      const isError =
        /نادرست\s*را\s*پیدا|اشتباه[\s\S]{0,24}را\s*پیدا|کلمه\s*(?:نادرست|غلط)\s*را\s*پیدا|find\s+the\s+(?:error|mistake)/i.test(instr);
      const isOddOne = /odd\s+(?:one\s+)?out|کدام\s+متفاوت|متفاوت\s*است/i.test(instr);
      const isPhonetic =
        /تلفظ|emphatic\s+stress|word\s+stress/i.test(instr) ||
        // R6-c (pkhn sec1): the stress LESSON sits in the block text ("you
        // stress certain important words … say them a little more loudly")
        // while the instruction only says "listen … answer the questions" —
        // probe both together.
        (/listen/i.test(instr) && /\bstress\b|pronounc/i.test(text));
      const isChoose =
        /گزینه\s*(?:صحیح|درست|مناسب)\s*(?:را\s*)?انتخاب|درون\s*پرانتز\s*گزینه|choose\s+the\s+(?:correct|best)\s+(?:answer|one|option)/i.test(instr);
      // "Unscramble the underlined words" (p8yp4c9983 E) / "مرتب کنید" word
      // tasks — the slash-soup shape heuristic cannot own them when the stems
      // arrived as plain short_answer rows.
      const isUnscramble = /unscramble|به\s*هم\s*ریخته|کلمات?\s*زیر\s*را\s*مرتب/i.test(instr) ||
        // R3: the scrambled-words-in-parens fill ("کلمات به هم ریخته داخل
        // پرانتز" — pkc61 11) arrives as word_bank_fill rows because the
        // paren soup reads as a bank; the contract still says unscramble.
        (faFlex('6a9 644 645 627 62a|6a9 644 645 647').test(instr) && faFlex('628 647 645|631 6cc 62e 62a 647').test(instr));
      const isPosChange = /change\s+the\s+adjectives?\s+(?:in\s+)?to\s+adverbs?|صفت[^\n]*قید\s*کن/i.test(instr);
      const isOrdering = /پاراگراف[^\n]*مرتب|مرتب[^\n]*پاراگراف|order\s+the\s+(?:sentences|adjectives|words)/i.test(instr);
      const isFormRemap = /(?:شکل\s*صحیح|شکل\s*درست|کلمه?\s*(?:صحیح|درست|مناسب))[^\n]*پرانتز|(?:فعل|افعال|verb)[^\n]{0,40}(?:پرانتز|parenthes)|use\s+the\s+correct\s+form|(?:correct\s+form\s+of\s+the\s+)?verbs?\s+(?:in|into)\s+(?:the\s+)?(?:correct\s+form[\s\w]{0,20}test|brackets?|parenthes)/i.test(instr) ||
        // R3: "…شکل صحیح گرامری بخش مشخص شده را بنویسید" names the
        // write-the-correct-form contract without the word پرانتز
        // (p4p187l300 11 — dialogue grammar-form rows read short_answer).
        // Error-correction contracts (اشتباه … شکل صحیح را بنویسید)
        // keep their own family — mock-01 J.
        !isError &&
        new RegExp(faFlex('634 6a9 644|635 62d 6cc 62d').source + '[\\s\\S]{0,60}?' + faFlex('628 646 648 6cc 633 6cc 62f').source).test(instr);
      const isTextReading = /بر\s*اساس\s*متن|based\s+on\s+the\s+(?:text|passage)/i.test(instr);
      // --- fix-8: wave-3 instruction remaps (listening/definition/numbers/
      // pictures/prepositions + shape-based essay) ----------------------------
      // EN-EN definition matching ("تعریف های ستون A را به کلمات ستون B وصل
      // کنید") — same shape as matching, different type per the task contract.
      // R6-c: the English imperative form joins (pkhn sec6 "Find the
      // definition of each word" + word bank — the rows read fill_blank).
      const isDefinitionMatch =
        /تعریف[\s\S]{0,30}ستون|ستون[\s\S]{0,30}تعریف|find\s+the\s+definitions?|definitions?\s+with\s+the\s+words|definition\s+of\s+each\s+word/i.test(instr);
      // R3 antonym/synonym write-in-blanks contract ("In each group of words,
      // there are two antonyms. Write them in the blanks" — p8yp4c9983 H;
      // متضاد/مرادف). The ≠-row shapes read as unscramble soup — the
      // contract retypes them fill_blank and pins the Vocabulary span.
      const isAntonym = /antonym|synonym/i.test(instr) || faFlex('645 62a 636 627 62f|645 631 627 62f 641').test(instr);
      // "اعداد زیر را با حروف انگلیسی بنویسید" — numbers task (14 -> fourteen).
      const isNumerical = /اعداد[\s\S]{0,40}حروف|حروف[\s\S]{0,40}اعداد/i.test(instr);
      // "با توجه به شکل های مقابل ..." — pictures are the task's answer source.
      const isPicture = /با\s*توجه\s*به\s*شکل|شکل\s*(?:های|ها)?\s*مقابل|تصویر\s*مقابل/i.test(instr);
      // "جاهای خالی را با ... حرف اضافه مناسب پر کنید" — prepositions are
      // grammar items (fill_blank type stays; only the skill area changes).
      const isPreposition = /حرف\s*اضافه|حروف\s*اضافه/i.test(instr);
      // "به دیالوگ زیر گوش دهید و جاهای خالی را کامل کنید" — every numbered
      // turn of a listening fill dialogue is a fill item, even the turn whose
      // printed line carries no blank (its answer slot is verbal).
      const isListeningFill = /گوش\s*دهید|شنیداری/i.test(instr) && /کامل/i.test(instr);
      // Shape-based essay: numbered rows that are ONLY a dotted answer line
      // ("15- ……………………………") under a "بنویسید" (write) instruction — the
      // student composes the whole answer. "حداقل N جمله" (at least N
      // sentences) is an explicit essay contract too.
      const isEssayShape = questions.length > 0 && questions.every((q) => /^[….\s_\-–—]+$/.test(q.stem || ''));
      // Topic-sentence sections (pq89 18, pinned) own their rows through the
      // final override below — the paragraph contract must never pre-empt it.
      const hasTopicSentenceContract = /topic\s*sentence/i.test(instr) || (faFlex('639 646 648 627 646').test(instr) && faFlex('628 646 648 6cc 633 6cc 62f').test(instr));
      const isEssayContract =
        /(?:حداقل|دست\s*کم)[^.\n]{0,18}جمله/.test(instr) ||
        (!hasTopicSentenceContract &&
          (new RegExp(faFlex('6cc 6a9 67e 627 631 627 6af 631 627 641').source + '[\\s\\S]{0,60}?' + faFlex('628 646 648 6cc 633 6cc 62f').source).test(instr) ||
            /write\s+a\s+paragraph/i.test(instr)));
      // (#qu2 wave 3) The former matching→definition_matching retype is gone:
      // the golden-sheet vocabulary (both the strict 30/30 corpus and the 53
      // qu2 matching rows) grades the family as plain "matching" — the
      // تعریف (definition) sub-flavor is a layout detail, not a different task.
      if (isNumerical) {
        for (const q of questions) if (retypable(q.type)) retype(q, 'numerical_calculation');
        if (category === 'Vocabulary' || category === 'General') category = 'General';
      }
      if (isPicture) {
        // "Write the word for each picture" — a WORD RECALL fill (p8yp4c9983
        // C: dotted slot rows), not a free description. The free-description
        // mapping stays for genuine production prompts.
        const isPictureWordFill = /write\s+the\s+words?\s+for\s+each\s+picture|برای\s*هر\s*تصویر\s*کلمه/i.test(instr);
        // R3: the English write-the-word contract now drives the branch on
        // its own — it used to sit behind a Persian-only isPicture gate and
        // was dead on English-titled sections (p8yp4c9983 C stayed General).
        if (isPictureWordFill && (category === 'General' || category === 'Vocabulary')) category = 'Vocabulary';
        for (const q of questions) if (q.type === 'short_answer') retype(q, isPictureWordFill ? 'fill_blank' : 'picture_description');
      }
      if (isPreposition && (category === 'General' || category === 'Vocabulary')) {
        category = 'Grammar';
      }
      if (isListeningFill) {
        for (const q of questions) if (q.type === 'short_answer') retype(q, 'fill_blank');
      }
      // R4 conjunction-bank rows: "جملات زیر را کلمات ربط داده شده تکمیل کنید.
      // (or, but, so)" — the bank extractor ingests the printed (or, but, so)
      // group and types the rows word_bank_fill, but the GT grades conjunction
      // fills fill_blank (53x7 13 GT, pe1yq K GT). Only the type moves; the
      // category convention is contract-specific and stays untouched.
      const isConjunctionBank = faFlex('631 628 637').test(instr); // ربط
      if (isConjunctionBank) {
        for (const q of questions) if (q.type === 'word_bank_fill') retype(q, 'fill_blank');
      }
      // R4 stem signature: dotted blank + TRAILING single-verb paren —
      // "Your brother never ---------------, does he? (to work)" — is the
      // write-the-correct-form task even when the section's instruction was
      // lost to the split (53x7 8/10, 2657 14). Slash groups stay choice
      // sets, single letters stay option markers, True/False stays out.
      for (const q of questions) {
        if (!retypable(q.type)) continue;
        const st = q.stem || '';
        const blank = /(?:\.{3,}|…+|_{3,}|-{4,})/.exec(st);
        if (!blank) continue;
        const pm = /\(\s*([A-Za-z][A-Za-z\s']{2,28})\s*\)\s*\.?\s*$/.exec(st);
        if (!pm || pm.index <= blank.index) continue;
        if (pm[1].includes('/')) continue;
        if (/^(?:true|false)$/i.test(pm[1].trim())) continue;
        if (pm[1].trim().split(/\s+/).length > 3) continue;
        retype(q, 'form_in_parentheses');
      }
      if (isEssayContract || (isEssayShape && /بنویسید/i.test(instr))) {
        for (const q of questions) if (retypable(q.type) || q.type === 'word_bank_fill') retype(q, 'long_answer_essay');
        category = 'Writing';
      }
      if (isTextReading && (category === 'General' || category === 'Vocabulary')) {
        // Answering/choosing FROM A PRINTED TEXT is reading comprehension —
        // beats the generic word-choice cues (گزینه / کلمات in the instruction).
        category = 'Reading';
      }
      if (isMatchingTask) {
        // Wave R1: the matching task contract lives in the instruction (ستون …
        // وصل کنید / Match (A) to (B)) — rows that fell through to generic
        // types are matching rows, whatever loose shape the line reader saw.
        // R3: STEM-LESS numeric slot rows ("19…… 20……", "( 15 ) ( 16 )")
        // are the matching ANSWER column when the contract is Persian
        // (با توجه به تصاویر … انتخاب کنید — 91294 5, 53x7 3 GT matching);
        // the ENGLISH "Match the pictures with sentences" paper keeps its
        // stem-less = multiple_choice convention (p8214 sec 1, pinned).
        // The TEXT probe only carries the picture/match family: bank headers
        // print ستون A/B too, and a text-probe on ستون would hijack
        // word_bank_fill sections. (captured-instruction probe keeps the full set)
        const faMatchInstr =
          faFlex('62a 635 627 648 6cc 631|633 62a 648 646|648 635 644|645 637 627 628 642 62a|62c 641 62a').test(instr) ||
          faFlex('62a 635 627 648 6cc 631|645 637 627 628 642 62a|62c 641 62a').test(rawSec.text.slice(0, 900).replace(/\s+/g, ' '));
        for (const q of questions) {
          const t = q.type as string;
          const bare = !q.stem || q.stem.replace(/[\s.()0-9]+/g, '').length <= 2;
          if (bare) {
            if (faMatchInstr && (t === 'fill_blank' || t === 'short_answer' || t === 'word_bank_fill' || t === 'multiple_choice')) {
              retype(q, 'matching');
            }
            continue;
          }
          if (!(retypable(q.type) || t === 'word_bank_fill' || t === 'multiple_choice' || t === 'unscramble')) continue;
          retype(q, 'matching');
        }
      } else if (isTF) {
        // Instruction-gated T/F retypes the whole family; stem-gated (the bare
        // "T ⎕ F ⎕" tail) retypes ONLY the carriers — the section's C-part
        // open questions must survive (p8214 Reading 26/27).
        const BOX = '[.\\s\u2610\u2611\u25A1\uE000-\uF8FF]';
        const tfStem = (q: QuestionItem) => {
          const stem = (q.stem || '').trim();
          // The T/F tail may be followed by absorbed page furniture
          // ("www-kanoon-ir Answer the questions.") — bounded box runs and a
          // tail-tolerant end keep q25 in the family without over-matching
          // prose that merely mentions T and F.
          const m = new RegExp(`\\bT${BOX}{1,8}F${BOX}{0,8}`).exec(stem);
          return !!m && m.index >= stem.length * 0.3;
        };
        const stemGated = !/درست\s*(?:یا|\/|و)\s*(?:نادرست|غلط)|صحیح\s*(?:یا|\/)\s*غلط|true\s*(?:or|\/)\s*false|t\s*\/\s*f/i.test(instr);
        for (const q of questions) {
          // R7-C: a row whose stem carries an answer blank is a FILL item —
          // it cannot be judged true/false (pt7kkv Listening q9-14 ride the
          // listening-fill prose; the section's T/F instruction must not
          // swallow them).
          if (/\.{3,}|…{2,}|_{3,}/.test(q.stem || '') && !/\bT\b[\s\S]{0,12}\bF\b|\bF\b[\s\S]{0,12}\bT\b/.test(q.stem || '')) continue;
          if (retypable(q.type) && (!stemGated || tfStem(q))) {
            retype(q, 'true_false', [{ id: 'true', text: 'True' }, { id: 'false', text: 'False' }]);
          }
        }
        if (category === 'General') category = 'Reading';
      } else if (isCombine) {
        for (const q of questions) if (retypable(q.type)) retype(q, 'combine_sentences');
        category = 'Writing';
      } else if (isPassive) {
        for (const q of questions) if (retypable(q.type)) retype(q, 'active_passive');
        category = 'Grammar';
      } else if (isFormRemap) {
        // Type only — the golden corpus carries form sections as both Grammar
        // and Vocabulary, so the category stays whatever detection produced.
        for (const q of questions) {
          const t = q.type as string;
          if (retypable(q.type) || t === 'word_bank_fill' || t === 'fill_blank') retype(q, 'form_in_parentheses');
          // R6-c repair: the joined instructions let the seed-level option
          // attach read a parenthetical form hint on a dotted blank as a
          // choice set — the printed form contract reclaims it (real
          // 14050319 q16 "(red -beautiful- old)", q30 "( beautiful)").
          else if (
            t === 'multiple_choice' &&
            /\([^()\n]{2,50}\)/.test(q.stem || '') &&
            /\.{3,}|_{3,}|…/.test(q.stem || '')
          ) {
            retype(q, 'form_in_parentheses');
          }
        }
      } else if (isPosChange) {
        // "Change the adjective in to adverbs" (p8214 row 10) — word-form
        // transformation = the form_in_parentheses family, Grammar span.
        for (const q of questions) {
          if (retypable(q.type) || q.type === 'word_bank_fill') retype(q, 'form_in_parentheses');
        }
        category = 'Grammar';
      } else if (isOrdering) {
        for (const q of questions) if (retypable(q.type) || q.type === 'word_bank_fill') retype(q, 'sentence_ordering');
        category = 'Writing';
      } else if (isAntonym) {
        // R3 antonym rows: "قیکلی / سادلی / گریتلی / سلولی: …… ≠ ……" —
        // write the PAIR in the blanks (p8yp4c9983 H GT fill_blank,
        // Vocabulary) — not unscramble, not odd_one_out. The ≠/slash pair
        // shape gates the retype: bare "Hard-working:" rows under the same
        // contract stay short_answer (momtamer GT convention).
        for (const q of questions) {
          const st = q.stem || '';
          const hasPair = st.includes('≠') || ((st.match(/\//g) ?? []).length >= 2);
          if (!hasPair) continue;
          if (retypable(q.type) || q.type === 'unscramble' || q.type === 'word_bank_fill') retype(q, 'fill_blank');
        }
        if (category === 'Writing' || category === 'General') category = 'Vocabulary';
      } else if (isUnscramble) {
        // Type first — letter-spelling families ("حروف به هم ریخته را مرتب
        // کنید", mock-16 A) grade Vocabulary and the earlier کلمه/املا cues
        // already own that category; forcing Writing here used to rebrand
        // them. R3: word_bank_fill joins the retype set (paren-soup rows).
        for (const q of questions) if (retypable(q.type) || q.type === 'word_bank_fill') retype(q, 'unscramble');
        // R3 category convention: word-scramble → Vocabulary, sentence
        // re-ordering (slash-separated word soup) → Grammar.
        if (category === 'Writing') {
          const slashed = questions.filter((q) => ((q.stem || '').match(/\//g) ?? []).length >= 2).length;
          if (slashed >= Math.max(1, Math.ceil(questions.length * 0.6))) category = 'Grammar';
          else if (questions.length > 0 && slashed === 0) category = 'Vocabulary';
        }
      } else if (isEssay) {
        for (const q of questions) if (retypable(q.type)) retype(q, 'long_answer_essay');
        category = 'Writing';
      } else if (isOddOne) {
        // "9. one odd out." + slash word-quads — the unscramble reader claims
        // the slash shape first; the instruction says the odd word wins.
        for (const q of questions) if (retypable(q.type) || q.type === 'unscramble') retype(q, 'odd_one_out');
        category = 'Vocabulary';
      } else if (isError) {
        for (const q of questions) if (retypable(q.type)) retype(q, 'error_correction');
      } else if (isPhonetic) {
        // Stress/pronunciation items may arrive as sentence tasks ("32) I was
        // reading Arabic. (Not Amir)") — retype the whole retypable family.
        // R6-c: word_bank_fill joins the retype set (pkhn sec1 lettered rows
        // bank-typed off their instruction). The category is re-stamped
        // Vocabulary ONLY when the paper did not already name Listening —
        // the golden convention (p8214 Pronunciatin) vs pkhn's own Listening
        // detection both survive.
        for (const q of questions) if (retypable(q.type) || q.type === 'word_bank_fill') retype(q, 'phonetic_pronunciation');
        if (category !== 'Listening') category = 'Vocabulary';
      } else if (isChoose) {
        // 3-4 alternative dash groups ("( am – is – are )") in a word-choice
        // section: the existing 2-way rule cannot see them. Only when a dotted
        // blank precedes the group (choices fill that blank) — word banks and
        // scramble soups never follow a blank. word_bank_fill is retaken too:
        // the paren choice line above the question used to leak into the
        // section word bank, misbranding the task as a bank fill.
        for (const q of questions) {
          const okType = retypable(q.type) || q.type === 'word_bank_fill';
          if (!okType || (q.options && q.options.length >= 2)) continue;
          const gm = q.stem.match(/\(([^()\n]{2,90})\)\s*$/m);
          if (!gm) continue;
          const parts = gm[1].split(/\s+[–—]\s+/).map((p) => p.trim()).filter(Boolean);
          if (parts.length < 3 || parts.length > 4) continue;
          if (!parts.every((p) => /^[A-Za-z\u00C0-\u024F'’\-]+(?:\s+[A-Za-z\u00C0-\u024F'’\-]+){0,2}$/.test(p))) continue;
          if (!/\.{3,}|…+|_{3,}/.test(q.stem.slice(0, gm.index))) continue;
          if (parts.every((p) => p === parts[0])) continue;
          retype(
            q,
            'inline_choice',
            parts.map((p, idx) => ({ id: String.fromCharCode(97 + idx), text: p })),
          );
        }
        // Slash-form choice groups WITHOUT parens ("a lot of / many milk",
        // "When / What / How fell down?") — the paren matcher above cannot see
        // them. Under an explicit choose-contract, 2-4 short slash-separated
        // alternatives are the choice set (p8yp4c9983 A).
        {
          for (const q of questions) {
            if (q.options && q.options.length >= 2) continue;
            // ONLY the generic defaults. Slash-soup rows typed unscramble keep
            // their type — a 3+ slash scramble ("must/ carefully/ he / to
            // questions/ answer") is reorder DNA, never a choice set
            // (verifyRealExam q38-39).
            if (!retypable(q.type)) continue;
            const sm = q.stem?.match(/(?:^|[\s(])([A-Za-z][\w'’]*(?:\s+[\w'’]+){0,2})(?:\s*\/\s*[A-Za-z][\w'’]*(?:\s+[\w'’]+){0,2}){1,3}/);
            if (!sm) continue;
            const parts = sm[0].trim().split(/\s*\/\s*/).map((p) => p.trim()).filter(Boolean);
            if (parts.length < 2 || parts.length > 4) continue;
            if (!parts.every((p) => /^[A-Za-z][\w'’]*(?:\s+[\w'’]+){0,2}$/.test(p))) continue;
            retype(
              q,
              'inline_choice',
              parts.map((p, idx) => ({ id: String.fromCharCode(97 + idx), text: p })),
            );
          }
        }
        if (questions.some((q) => q.type === 'inline_choice') && (category === 'General' || category === 'Grammar')) {
          category = 'Vocabulary';
        }
      }

      // Topic-sentence + paragraph-essay writing prompts (#qu2 wave 3,
      // pq89w65173 section 18): "برای عنوان های زیر یک Topic Sentence …
      // بنویسید" — the numbered rows carry TITLE labels with trailing
      // answer-space dots; the task is composing one sentence (short_answer),
      // and the dots must not read as fill DNA. A "یک پاراگراف … بنویسید" row
      // inside the same choice block is the long-form essay instead. Runs on
      // NFKC-folded text (presentation forms) as a FINAL override so no
      // earlier branch can re-stamp it.
      const instrN = instr.normalize('NFKC');
      if (/topic\s*sentence/i.test(instrN) || ((/عناوین|عنوان/.test(instrN)) && /بنویسید/.test(instrN))) {
        // Final override means FINAL: a bank-contaminated word_bank_fill row
        // (the bullet list read as a bank) retakes its writing type too.
        const retypableWriting = (t: QuestionType) => retypable(t) || t === 'word_bank_fill';
        for (const q of questions) {
          const s = (q.stem || '').normalize('NFKC');
          if (/پاراگراف/.test(s) && /بنویسید/.test(s)) {
            if (retypableWriting(q.type)) retype(q, 'long_answer_essay');
            continue;
          }
          // A MID-STEM blank run is a fill slot ("Smoking …… . It increases…"
          // — complete the topic sentence, GT fill_blank); TRAILING dots are
          // the answer-space of a title prompt ("a) Ferdowsi…." — write one
          // sentence, GT short_answer).
          const blankAt = (q.stem || '').search(/\.{3,}|…+|_{3,}/);
          const midBlank = blankAt >= 0 && blankAt < (q.stem || '').length - 6;
          if (!midBlank && retypableWriting(q.type)) retype(q, 'short_answer');
        }
        category = 'Writing';
      }

      // Subtask region contracts (R5, p4t7882699 A/B): English task banners
      // INSIDE a section ("Complete the following sentences with your own
      // words." / "Match the following words and phrases together." / "2 -
      // Complete … with the correct forms of words.") re-contract the rows
      // BELOW them — the section-blend (the first bank's word_bank_fill)
      // otherwise swallows every later subtask's own genre.
      {
        const regionTypeOf = (instr: string): QuestionType | null => {
          if (/^match\b/i.test(instr.trim())) return 'matching';
          if (/make\s+a\s+sentence|unscramble/i.test(instr)) return 'unscramble';
          // "Make active and passive sentences with the words given" (pc4i
          // q24-25): the voice contract IS the genre — the trailing "words
          // given" tail must not drown it in word_bank_fill.
          if (/active\s+(?:and|&)\s+passive|passive\s+(?:and|&)\s+active/i.test(instr)) return 'active_passive';
          if (/own\s+words/i.test(instr)) return 'fill_blank';
          // R6-c subtask contracts (pkhn sec8): T/F banners drive true_false,
          // definition banners drive matching, bare "Choose …" banners drive
          // multiple_choice (cloze rows are regionGuard-protected).
          if (/write\s+t\b|t\s*\(\s*true\s*\)|true\s+or\s+false|true\s*\/\s*false/i.test(instr)) return 'true_false';
          if (/definition/i.test(instr)) return 'matching';
          if (/^choose\s+the\s+best\s+(?:item|one|alternative|option)\b/i.test(instr.trim())) return 'multiple_choice';
          if (/forms?\s+of\s+(?:the\s+)?(?:words|verbs)|given\s+verbs/i.test(instr)) return 'form_in_parentheses';
          if (/given\s+words|word\s+bank|words\s+given/i.test(instr)) return 'word_bank_fill';
          return null;
        };
        const isRegionBanner = (l: string) =>
          /^\s*(?:\d{1,2}\s*[-.\)])?\s*(?:Complete|Choose|Match|Make|Answer|Read|Fill|Write|Put|Use|Unscramble|Listen|Find)\b/i.test(l.trim());
        const regionGuard = (t: QuestionType) =>
          !['multiple_choice', 'true_false', 'inline_choice', 'long_answer_essay', 'cloze_item', 'short_answer'].includes(t);
        const regions: { at: number; type: QuestionType | null }[] = [];
        for (let li = 0; li < lines.length; li++) {
          if (!isRegionBanner(lines[li])) continue;
          // A banner whose contract we cannot name still ENDS the previous
          // region ("1 - Complete the following sentences." closes the
          // verbs/forms region above it).
          regions.push({ at: li, type: regionTypeOf(lines[li]) });
        }
        if (regions.length > 0 && !process.env.PARSE_NO_REGION) {
          if (process.env.PARSE_DEBUG) console.error('[regions]', regions.map((r) => `${r.at}:${r.type}`).join(' '), 'lineOff', traceCtx?.lineOffset);
          for (const q of questions) {
            const ls = q.receipt?.lineStart;
            if (ls === undefined) continue;
            const rel = ls - (traceCtx?.lineOffset ?? 0);
            let regionType: QuestionType | null = null;
            for (const r of regions) if (rel >= r.at) regionType = r.type; // LAST banner above the row wins
            if (process.env.PARSE_DEBUG) console.error('[region-q]', q.number, 'rel', rel, '->', regionType, 'was', q.type);
            // R7: a generic matching/mc region must not claim a row whose
            // blank-bearing stem already carries a SPECIFIC fill-family type
            // (real 14050319 q24-30 "(strong) than his friend." under a
            // choose-the-best-option banner stay form_in_parentheses).
            if (
              regionType &&
              (regionType === 'matching' || regionType === 'multiple_choice') &&
              BLANK_RUN.test(q.stem || '') &&
              (['form_in_parentheses', 'word_bank_fill', 'fill_blank'].includes(q.type) ||
                /\([^()\n]{2,50}\)/.test(q.stem || ''))
            ) {
              regionType = null;
            }
            if (!regionType || q.type === regionType || !regionGuard(q.type)) continue;
            retype(q, regionType);
          }
        }
      }

      // Picture-choice rows (#qu2 wave 3, pq89w65173 section 5): "با توجه به
      // تصاویر داده شده … جمله مناسب برای هر تصویر را انتخاب کنید" — the
      // stem-less paren-slot questions pick one sentence from a SHARED
      // lettered pool, which the bank extractor ingests. The task is
      // multiple_choice; strip the bank contamination on those slots.
      // (pm57 A note: the same printed shape appears on the pinned pq89
      // section 5, whose frozen GT types it multiple_choice — the two GTs
      // were aligned on the pinned convention, so the slot row always takes
      // the MCQ strip below.)
      if (/تصاو?\r|تصویر|pictures?/i.test(instrN) && /انتخاب|choose|match/i.test(instrN)) {
        for (const q of questions) {
          if (q.stem && q.stem.replace(/[\s.()]+/g, '').length > 2) continue; // has a real stem
          delete q.wordBankWords;
          q.parentContextType = undefined;
          q.parentContextTitle = undefined;
          q.parentContextText = undefined;
          // 'matching' joins the reclaim set: the R3 bare-slot relaxation may
          // transiently retype these slots before this owner (which pins the
          // frozen pq89/8214 multiple_choice convention) re-claims them.
          if (retypable(q.type) || q.type === 'word_bank_fill' || q.type === 'matching') retype(q, 'multiple_choice');
        }
        if (category === 'General' || category === 'Reading') category = 'Vocabulary';
      }

      // Open-question short answers (#qu2 wave 4, pm57 L/M): "… به سؤالات به
      // صورت خواسته شده پاسخ دهید" / "C. Answer the following questions" — a
      // stem that OPENS with a question/yes-no word, reaches "?" and carries
      // NO blank at all is an open question answered in writing, never a
      // blank fill. When a blank follows the "?" the printed answer line IS
      // the task (10th-first B "پاسخ کوتاه بدهید" = fill_blank) — unless the
      // sheet demands a COMPLETE production answer ("پاسخ کوتاه و کامل دهید",
      // pm57 P) which makes it a short_answer.
      if (/answer\s+the\s+(?:following\s+)?questions?/i.test(instrN) || /پاسخ.*دهید/.test(instrN.replace(/\s+/g, ''))) {
        for (const q of questions) {
          const stem = q.stem || '';
          if (!(retypable(q.type) || q.type === 'word_bank_fill')) continue;
          if (!/^[\"'“”\s]*(?:why|what|how|when|where|who|does|do|did|is|are|can|will)\b/i.test(stem)) continue;
          const firstQ = stem.search(/\?|؟/);
          if (firstQ < 0) continue;
          // A printed answer line ANYWHERE in the stem (even after the "?")
          // is the task itself — the fill_blank convention of the whole
          // corpus (10th-first B, 9th 1-3 I). Only truly blank-free open
          // questions (pm57 L 62/63, M 70) are short answers.
          if (BLANK_RUN.test(stem)) continue;
          retype(q, 'short_answer');
        }
      }

      // R3: answer-contract PROMPT rows ("Fast food……………", "Electricity…… 1"
      // under به سوالات پاسخ دهید / answer the questions) are open writing
      // prompts — short_answer, not fill_blank. Complement of the
      // open-question rule above (which demands blank-free question-word
      // stems): here the stem is a short prompt phrase whose END is the
      // printed answer line. Two gates:
      //   - with the printed answer contract: prose ≤ 12 words;
      //   - without any captured contract (the split lost it): prose ≤ 4
      //     words — bare "N) Word………" prompt rows (53x7 14), while numbered
      //     fill slots ("(59) ……", zero prose) stay fill_blank.
      // Listening sections are exempt (their fill rows are blanks by design).
      // A word_bank_fill whose stem is a QUESTION followed by a trailing
      // answer line ("What sign may sleeping more than nine hours be? ____")
      // is also an open answer (p91294 45) — the bank cannot fill a
      // question's answer space.
      {
        const answerContract =
          /answer\s+the\s+(?:following\s+)?questions?/i.test(instrN) || /پاسخ.*دهید/.test(instrN.replace(/\s+/g, ''));
        const listenBlocked = r3HitAny(instrN, R3_LISTEN_BLOCKER) || r3HitAny(instrN.replace(/\s+/g, ''), R3_LISTEN_BLOCKER);
        // Reading comprehension answer lines are the fill_blank convention
        // corpus-wide (11th R 72, kelas D) — the prompt family never applies.
        // Translation contracts (ترجمه کنید / translate the words) mark their
        // dotted rows as translation fills too (8-nobat A, haftom 1) even
        // when the row looks like a topic prompt.
        const translationBlocked =
          /translate/i.test(instrN) ||
          faFlex('62a 631 62c 645 647').test(rawSec.text.slice(0, 900).replace(/\s+/g, ' '));
        // R3-final: the contract-free prompt path regressed the golden corpus
        // (momtamer meaning-writes "hold a ceremony ………" are fill_blank while
        // qu2's identical "Fast food………" shapes are short_answer — the GT
        // conventions conflict without a printed contract), so prompts now
        // REQUIRE the printed answer contract.
        if (answerContract && !listenBlocked && !translationBlocked && category !== 'Reading') {
          let promptRetyped = 0;
          let promptCandidates = 0;
          for (const q of questions) {
            if (!(retypable(q.type) || q.type === 'word_bank_fill')) continue;
            const rawStem = (q.stem || '').trim();
            if (!rawStem) continue;
            // question + trailing answer line (word_bank question tail)
            if (q.type === 'word_bank_fill' && /\?[\s]*[._…\-]{3,}/.test(rawStem)) {
              retype(q, 'short_answer');
              continue;
            }
            const stem = rawStem.replace(/[\d.\s]+$/, '');
            const blankAt = stem.search(/\.{3,}|…+|_{3,}/);
            if (blankAt < 0) continue;
            const after = stem.slice(blankAt).replace(/\.{3,}|…+|_{3,}/g, '');
            if (/[A-Za-z]{2,}/.test(after)) continue; // letters after the blank = mid-stem fill
            const prose = (stem.slice(0, blankAt) || '')
              .replace(/\.{3,}|…+|_{3,}/g, ' ')
              .split(/[\s.,!?;:()\[\]"'“”]+/)
              .filter((w) => /[A-Za-zÀ-ɏ]{2,}/.test(w)).length;
            // Question-word stems + a printed answer line are the corpus-wide
            // fill_blank convention (10th-first B, kelas D) in BOTH paths —
            // only non-question prompts retype ("Fast food………").
            if (/^\s*(?:who|what|where|when|why|how|which|is|are|do|does|did|can|will|have|has)\b/i.test(stem)) continue;
            if (/^[A-Za-z]{1,3}[).\-]\s*\S/i.test(stem)) continue; // "A) …" speaker marker
            if (!answerContract) {
              // No printed contract: ONLY a bare topic prompt qualifies — a
              // short noun phrase whose answer line is the stem's END.
              if (prose < 1 || prose > 2) continue; // topic prompts are 1-2 word noun phrases ("Fast food……")
              if (/^[^\n:]{0,40}:\s*[.\u2026_]*$/.test(stem)) continue; // "culture : ………." label fills (suffix/prefix banks)
              if (/\?|؟/.test(after)) continue;
            } else if (prose < 1) {
              continue;
            }
            promptCandidates++;
            if (prose <= (answerContract ? 12 : 4)) {
              retype(q, 'short_answer');
              promptRetyped++;
            }
          }
          // NOTE: no category rebrand here — the prompt/translation/suffix
          // conventions conflict across corpora, so only the qtype moves.
        }
      }


      // Blank-DNA normalization (#qu2 wave 3, pq89w65173 q50): a stem with a
      // real blank run but NO unscramble word-groups is a knowledge fill —
      // the unscramble family needs ≥3 ALPHABETIC slash fragments ("work /
      // some workers / who …"). Numeric slash debris (an absorbed page
      // header's date "13 / 06 / 99") is not scramble DNA.
      for (const q of questions) {
        if (q.type === 'unscramble' && /\.{3,}|…+|_{3,}/.test(q.stem || '')) {
          const alphaFragments = (q.stem || '')
            .split('/')
            .filter((p) => /^[A-Za-z\u00C0-\u024F'’\s]+$/.test(p.trim()) && p.trim().length > 0).length;
          if (alphaFragments < 3) retype(q, 'fill_blank');
        }
      }
    }
  }

  // Category shape refinement
  if (category === 'General' && questions.length > 0) {
    category = refineCategoryByQuestionShapes(questions, hasWordBank, hasPassage);
    questions.forEach((q) => {
      q.sectionName = category;
    });
  }

  // --- 4c. Layout-family refinements run AFTER section assembly (below) ----

  // --- Mark Allocation ---
  // If questions had explicit marks printed, recalculate section total;
  // otherwise, divide rawSec.mark equally across the questions.
  // ⚠ An ALL-0.5 section used to be misread as "no explicit marks" and the
  // division clobbered the printed values (golden corpus caught this).
  const questionsHaveExplicitMarks = questions.some(
    (q) => (q as QuestionItem & { __explicitMark?: boolean }).__explicitMark === true || (q.mark !== 0.5 && q.mark > 0),
  );
  let finalMarkTotal = rawSec.mark;

  if (questionsHaveExplicitMarks) {
    finalMarkTotal = Math.round(questions.reduce((sum, q) => sum + q.mark, 0) * 100) / 100;
    // Clean the transient flag before the document leaves the engine.
    for (const q of questions) delete (q as QuestionItem & { __explicitMark?: boolean }).__explicitMark;
  } else if (questions.length > 0 && finalMarkTotal > 0) {
    const perQ = Math.round((finalMarkTotal / questions.length) * 100) / 100;
    questions.forEach((q) => {
      q.mark = perQ;
    });
  }

  const section: ExamSection = {
    rowId,
    majorCategory: (labelPinned ? rawSec.category : category) as ExamSection['majorCategory'],
    title,
    persianInstruction: persianInstruction || undefined,
    englishInstruction: englishInstruction || undefined,
    markTotal: finalMarkTotal,
    questions,
    hasWordBank,
    wordBank: wordBank.length ? wordBank : undefined,
    hasPassage,
    passageTitle: passageTitle || undefined,
    passageText: passageText || undefined,
  };
  if (process.env.R4_DEBUG) {
    console.error(
      `[cat] ${rowId} labelPinned=${labelPinned} rawSec.cat=${rawSec.category ?? '-'} cat=${category} major=${section.majorCategory} nq=${questions.length} types=${questions.map((q) => q.type).join(',').slice(0, 60)} instr=${JSON.stringify(persianInstruction.slice(0, 60) || englishInstruction.slice(0, 60))}`,
    );
  }

  if (process.env.PARSE_DEBUG) {
    const q25 = questions.find((q) => Number(q.number) === 25);
    const q16 = questions.find((q) => Number(q.number) === 16);
    if (q25 || q16) console.error('[stage2]', 'q16', q16?.type, 'q25', q25?.type);
  }
  applyLayoutRefinements(
    section,
    text,
    lines,
    bankSpan,
    traceCtx ? traceCtx.lineOffset : 0,
    // Label pin (#qu2 wave 3): only a PRINTED subject label ("17 Grammar"
    // radif-row opener) outranks the genre remaps — keyword-derived or
    // shape-refined categories do not (the strict corpus's unscramble
    // sections keep their Writing default).
    !!rawSec.labelCategory,
  );
  if (process.env.R4_DEBUG) {
    console.error(`[cat-final] ${rowId} major=${section.majorCategory}`);
  }
  return section;
}


/**
 * Layout-family refinements (#layout-genres): after the structural parse,
 * classify the section into its Iranian exam genre and stamp genre-level
 * fields the line rules cannot know: matching columns, odd-one-out,
 * spelling-error correction, dialogue/image shared contexts.
 */
function applyLayoutRefinements(
  section: ExamSection,
  text: string,
  lines: string[],
  bankSpan?: { start: number; end: number } | null,
  lineOffset = 0,
  labelPinned = false,
): void {
  const instrText = `${section.title || ''} ${section.persianInstruction || ''} ${section.englishInstruction || ''}`;
  const typeInfoOf = (t: QuestionType) => getQuestionTypeInfo(t);
  const rowId = section.rowId;
  const questions = section.questions;

  // Bank-scope helpers (#bank-scoping): receipts are global line indices.
  const bankSpanGlobal = bankSpan ? { start: bankSpan.start + lineOffset, end: bankSpan.end + lineOffset } : null;
  const inBankScope = (q: QuestionItem): boolean => {
    if (!bankSpanGlobal) return true;
    const ls = q.receipt?.lineStart;
    if (ls === undefined) return true;
    return ls > bankSpanGlobal.start && ls < bankSpanGlobal.end;
  };
  const beforeBankRow = (q: QuestionItem): boolean => {
    if (!bankSpanGlobal) return true;
    const ls = q.receipt?.lineStart;
    if (ls === undefined) return true;
    return ls < bankSpanGlobal.start;
  };

  // Matching: "ستون A … ستون B" + a dotted B-column physically present, OR
  // merged two-column rows ("He is Ben. 1.How do you spell her last name?")
  // whose B side never carries dots (متصل کنید / وصل کنید layouts).
  // (#qu2 wave 3) The family is graded as plain "matching" — the تعریف
  // (definition) sub-flavor is a layout detail, not a different task type.
  const matchType: QuestionType = 'matching';
  // (#qu2 wave 3) The ستون cue usually sits in a nested instruction line (الف/ب
  // choice blocks print ONE choice banner, then each branch carries its own
  // ستون sentence) — the section's own instruction fields may never see it.
  // Scan the section body too. BOTH cues run on NFKC-folded text: pdf extracts
  // emit Arabic PRESENTATION FORMS (ﺳﺘﻮن) whose codepoints never match a
  // plain ستون literal — the same reason the radif band detector folds.
  const instrTextNfkc = instrText.normalize('NFKC');
  const bodyColumnCue = lines.some((l) => /ستون|column\s*[AB]/i.test(l.normalize('NFKC')));
  if (process.env.DEBUG_MATCH) {
    console.log('[match] row', section.rowId, '| instrCue:', /ستون|وصل\s*کنید|متصل\s*کنید|match/i.test(instrTextNfkc), '| bodyCue:', bodyColumnCue, '| q:', questions.length, '| line0:', JSON.stringify(lines[0] || ''));
  }
  // NOTE: "pictures" is deliberately NOT in the alternation — frozen p8214
  // section 1 ("Match the pictures with sentences") pins multiple_choice for
  // picture-slot rows (the sentences are the options, not a B column).
  if (/ستون|وصل\s*کنید|متصل\s*کنید|match\s+(?:the\s+)?(?:column|definitions|words|sentences|items|phrases)|match\s+each|two\s+halves/i.test(instrTextNfkc) || bodyColumnCue) {
    let colB = extractMatchingColumnB(text);
    if (colB.length < 2) colB = extractDefinitionColumn(lines);
    if (colB.length < 2) {
      // Inline merged pairs (#qu2 wave 4, p8214 sec 2): "5) solve.  a.
      // something that you believe." — bidi prints one A-row and one B-row
      // per line, so the lettered definitions never sit on their own lines.
      const inlineB: { letter: string; text: string }[] = [];
      for (const l of lines) {
        const m = l.match(/^\s*\d{1,2}\s*[.)]\s*.{2,60}?\s+([a-e])\s*[.)]\s*(\S.*)$/i);
        if (m && !/[\u0600-\u06FF]/.test(m[2])) inlineB.push({ letter: m[1], text: m[2].trim() });
      }
      if (inlineB.length >= 3 && inlineB.every((x, i) => x.letter === String.fromCharCode(97 + i))) {
        colB = inlineB.map((x) => x.text);
      }
    }
    if (process.env.DEBUG_MATCH) console.log('[match] row', section.rowId, 'colB:', colB.length, JSON.stringify(colB.slice(0, 2)));
    if (colB.length >= 2 && questions.length >= 2) {
      section.matchingColumns = {
        columnA: questions.map((q) => ({ id: q.number, text: q.stem })),
        columnB: colB.map((t, i) => ({ id: String.fromCharCode(97 + i), text: t })),
      };
      for (const q of questions) {
        q.type = matchType;
        q.typeEnName = typeInfoOf(matchType).enName;
        q.typeFaName = typeInfoOf(matchType).faName;
        // The definitions are the matching B column, not a fill bank — the
        // bank extractor ingests the lettered rows when the sandwich
        // precedes the typing chain, so strip the contamination here.
        delete q.wordBankWords;
        q.parentContextType = undefined;
        q.parentContextTitle = undefined;
        q.parentContextText = undefined;
        // The stem is the numbered question row only — trailing B-column
        // debris absorbed into the block is dropped (a B-row glued INLINE
        // ("… favorite drink? Drink some milk") is cut at the B-text).
        let stemLine = cleanStem((q.stem || '').split(/\r?\n/)[0] || '');
        for (const b of colB) {
          const at = stemLine.indexOf(b);
          if (at > 0) stemLine = stemLine.slice(0, at).trim();
        }
        q.stem = stemLine;
        q.matchingPairs = [{ leftNumber: q.number, leftText: q.stem }];
        q.matchingDistractors = colB.length > questions.length ? colB.slice(questions.length) : undefined;
      }
      // Re-sync columnA with the cleaned stems.
      section.matchingColumns = {
        columnA: questions.map((q) => ({ id: q.number, text: q.stem })),
        columnB: colB.map((t, i) => ({ id: String.fromCharCode(97 + i), text: t })),
      };
    } else if (questions.length === 0) {
      // Merged two-column rows: "<answer> <N>.<question>" — the B side has no
      // dotted row, so extractMatchingColumnB sees nothing. Rebuild the whole
      // section from the pairs; numberless trailing lines are distractors.
      const pairRe = /^(.*?\S)\s+(\d{1,2})\s*[\.)]\s*(\S.*)$/;
      const pairs: { n: number; a: string; q: string }[] = [];
      const lone: string[] = [];
      for (const line of lines) {
        const m = line.match(pairRe);
        if (m && /[A-Za-z]/.test(m[3]) && m[1].length >= 2 && !/^\d+[\.)]/.test(m[1])) {
          pairs.push({ n: parseInt(m[2], 10), a: m[1].replace(/\s{2,}/g, ' ').trim(), q: m[3].trim() });
        } else if (/[A-Za-z]{2,}/.test(line) && !/ستون|الف|متصل|وصل/.test(line)) {
          lone.push(line.replace(/\s{2,}/g, ' ').trim());
        }
      }
      if (pairs.length >= 2) {
        pairs.sort((x, y) => x.n - y.n);
        const colBMerged = [...pairs.map((p) => p.a), ...lone];
        for (const p of pairs) {
          questions.push({
            id: `q-${section.rowId}-match-${p.n}`,
            number: p.n,
            displayNumber: String(p.n),
            sectionRowId: section.rowId,
            sectionName: section.majorCategory,
            type: 'matching',
            typeEnName: typeInfoOf('matching').enName,
            typeFaName: typeInfoOf('matching').faName,
            stem: p.q,
            mark: 0,
            parentContextType: 'none',
            hasImage: false,
            matchingPairs: [{ leftNumber: p.n, leftText: p.q }],
          } as unknown as QuestionItem);
        }
        section.matchingColumns = {
          columnA: pairs.map((p) => ({ id: p.n, text: p.q })),
          columnB: colBMerged.map((t, i) => ({ id: String.fromCharCode(97 + i), text: t })),
        };
        // (extra merged answers already ride in columnB)
      } else {
        // Tiny 2-column tables extract ROW-BY-ROW: "When is your birthday?" /
        // "I'm 13 years old." / "How old are you?" / "In Aban" — even lines are
        // column الف, odd lines column ب. Split alternately.
        const latinLines = lines.filter(
          (l) => /[A-Za-z]{2,}/.test(l) && !/[\u0600-\u06FF]/.test(l) && !/(?:\.{3,}|…|_{3,})/.test(l) && !/ستون|^ب$|^الف$/i.test(l.trim()),
        );
        if (latinLines.length >= 4 && latinLines.length % 2 === 0) {
          const colA2 = latinLines.filter((_, i) => i % 2 === 0);
          const colB2 = latinLines.filter((_, i) => i % 2 === 1);
          colA2.forEach((stem, i) => {
            const num = i + 1;
            questions.push({
              id: `q-${section.rowId}-match2-${num}`,
              number: num,
              displayNumber: String(num),
              sectionRowId: section.rowId,
              sectionName: section.majorCategory,
              type: 'matching',
              typeEnName: typeInfoOf('matching').enName,
              typeFaName: typeInfoOf('matching').faName,
              stem,
              mark: 0,
              parentContextType: 'none',
              hasImage: false,
              matchingPairs: [{ leftNumber: num, leftText: stem }],
            } as unknown as QuestionItem);
          });
          section.matchingColumns = {
            columnA: colA2.map((text, i) => ({ id: i + 1, text })),
            columnB: colB2.map((text, i) => ({ id: String.fromCharCode(97 + i), text })),
          };
        }
      }
    } else if (questions.length >= 2) {
      // Lettered B-side riding the stem lines ("1- someone who bakes bread
      // a. baker" … "g. farmer" standalone extras): split each stem at its
      // trailing a-h marker, collect the B texts in letter order.
      const letteredB: { letter: string; text: string }[] = [];
      const stripped: { q: QuestionItem; stem: string }[] = [];
      for (const q of questions) {
        const first = (q.stem || '').split(/\r?\n/)[0] || '';
        const m = first.match(/^(.*?\S)\s+([a-h])\s*[.)]\s*(\S.*)$/i);
        if (m && m[1].length >= 3 && (m[1].match(/[A-Za-z]{2,}/g) || []).length >= 2) {
          letteredB.push({ letter: m[2].toLowerCase(), text: m[3].trim() });
          stripped.push({ q, stem: m[1].trim() });
        }
      }
      // Standalone extra options ("g. farmer") after the stem rows.
      for (const l of lines) {
        const t = l.trim();
        if (/^\s*\d{1,3}\s*[-–—.)]/.test(t)) continue;
        const m = t.match(/^([a-h])\s*[.)]\s*(\S.*)$/i);
        if (m && t.split(/\s+/).length <= 6 && /[A-Za-z]{2,}/.test(m[2])) {
          letteredB.push({ letter: m[1].toLowerCase(), text: m[2].trim() });
        }
      }
      if (stripped.length >= 2 && letteredB.length >= 2) {
        letteredB.sort((x, y) => x.letter.localeCompare(y.letter));
        const texts = letteredB.map((b) => b.text);
        for (const { q, stem } of stripped) {
          q.stem = stem;
          q.type = matchType;
          q.typeEnName = typeInfoOf(matchType).enName;
          q.typeFaName = typeInfoOf(matchType).faName;
          q.matchingPairs = [{ leftNumber: q.number, leftText: stem }];
          q.matchingDistractors = texts.length > questions.length ? texts.slice(questions.length) : undefined;
        }
        section.matchingColumns = {
          columnA: questions.map((q) => ({ id: q.number, text: q.stem })),
          columnB: texts.map((t, i) => ({ id: String.fromCharCode(97 + i), text: t })),
        };
      }
      if (!(stripped.length >= 2 && letteredB.length >= 2)) {
      // Alternating answer/question lines ("He is Ben." / "1. How do you
      // spell her last name?" / …): the numbered questions extracted as plain
      // stems with the NEXT answer glued on. Non-numbered Latin lines are the
      // B column; cut them out of the stems.
      const answerLines = lines.filter((l) => {
        if (/^\s*\d{1,2}\s*[\.\)]/.test(l)) return false;
        if (/^\s*[\u0600-\u06FF]/.test(l)) return false;
        if (/(?:\.{3,}|…|_{3,})/.test(l)) return false;
        if (/ستون|الف|متصل|وصل/.test(l)) return false;
        return /[A-Za-z]{2,}/.test(l);
      });
      if (answerLines.length >= 2) {
        for (const q of questions) {
          let stemLine = cleanStem((q.stem || '').split(/\r?\n/)[0] || '');
          for (const a of answerLines) {
            const at = stemLine.indexOf(a);
            if (at > 0) stemLine = stemLine.slice(0, at).trim();
          }
          q.stem = stemLine;
          q.type = 'matching';
          q.typeEnName = typeInfoOf('matching').enName;
          q.typeFaName = typeInfoOf('matching').faName;
          q.matchingPairs = [{ leftNumber: q.number, leftText: q.stem }];
        }
        section.matchingColumns = {
          columnA: questions.map((q) => ({ id: q.number, text: q.stem })),
          columnB: answerLines.map((t, i) => ({ id: String.fromCharCode(97 + i), text: t })),
        };
        if (section.majorCategory === 'General') section.majorCategory = 'Vocabulary';
        for (const q of questions) q.sectionName = section.majorCategory;
      }
      }
    }
  }

  // Odd-one-out.
  if (/\u0646\u0627\u0647\u0645\u0627\u0647\u0646\u06af|\u0645\u062a\u0641\u0627\u0648\u062a|odd\s*(?:one|word|out)/i.test(instrText)) {
    for (const q of questions) {
      // Optionless rows whose stem is a dash-separated word quad ("Interesting
      // – amazing – useful – wonderful") ARE the odd set — split into options.
      if ((!q.options || q.options.length < 3) && q.stem) {
        const stemClean = q.stem.replace(/\s+\d{1,3}\s*$/, ''); // trailing next-row mark debris
        const words = stemClean.split(/\s*[–—-]\s*/).map((w) => w.trim());
        if (
          words.length >= 3 &&
          words.every((w) => /^[A-Za-z'\u2019]+(\s+[A-Za-z'\u2019]+)*$/.test(w)) &&
          !BLANK_RUN.test(q.stem)
        ) {
          q.options = words.map((w, i) => ({ id: String.fromCharCode(97 + i), text: w }));
          q.stem = '';
        }
      }
      if (q.options && q.options.length >= 3) {
        // Pronunciation groups ("کدام کلمه از نظر تلفظ … متفاوت است؟" +
        // a. book b. food …) are phonetic stress items, not meaning-odd-one-out.
        const t: QuestionType = /تلفظ|pronunciation|word stress/i.test(instrText)
          ? 'phonetic_pronunciation'
          : 'odd_one_out';
        q.type = t;
        q.typeEnName = typeInfoOf(t).enName;
        q.typeFaName = typeInfoOf(t).faName;
      }
    }
  }

  // Spelling / error-correction sections.
  // True/False marking sections ("جملات صحیح T و جملات غلط F قرار دهید").
  const tfSection = /\bT\b[\s\S]{0,40}\bF\b|صحیح[\s\S]{0,30}غلط|درست[\s\S]{0,30}غلط|True[\s\S]{0,20}False/i.test(instrText);
  if (tfSection) {
    for (const q of questions) {
      if (!q.options || q.options.length === 0) {
        // R7-C: blank-bearing stems are fill rows, not judgeable statements
        // (pt7kkv Listening q9-14) — but ONLY when prose CONTINUES after the
        // blank; a terminal blank is the standard T/F answer line (نهم H q22
        // "…lives. ………").
        const tfBlank = /\.{3,}|…{2,}|_{3,}/.exec(q.stem || '');
        if (tfBlank && tfBlank.index + tfBlank[0].length < (q.stem || '').trim().length - 2) continue;
        // T/F marking applies to STATEMENTS ("… lives. ………"); open questions
        // ("Did her sister take care…?") ride along in the same section and
        // keep their own type.
        if (/[?؟]/.test(q.stem || '')) continue;
        q.type = 'true_false';
        q.typeEnName = typeInfoOf('true_false').enName;
        q.typeFaName = typeInfoOf('true_false').faName;
        q.options = [
          { id: 'true', text: 'True' },
          { id: 'false', text: 'False' },
        ];
      }
    }
  }

  // Row-level T/F markers: many sheets print NO section banner at all — each
  // statement row carries its own answer columns, trailing ("…nature.  T  F")
  // or wrapped mid-stem ("…the number  T  F / of these animals…"). A standalone
  // T…F pair on an option-less statement IS the task (real-exam 14050319
  // q41/42/45/46/47 used to stay short_answer). The marker run is stripped
  // from the stem — it is answer furniture, not sentence text.
  for (const q of questions) {
    // true_false questions strip too — the instruction remap (above) now
    // types T/F items early with the marker still glued to the stem; the
    // marker is answer furniture either way (real-exam q45-47).
    if (q.options && q.options.length > 0 && q.type !== 'true_false') continue;
    const stemStr = q.stem || '';
    if (!/\bT\b/.test(stemStr) || !/\bF\b/.test(stemStr)) continue;
    const markerRe = /\s*\bT\b[\s\/|,.]*\bF\b\s*|\s*\bF\b[\s\/|,.]*\bT\b\s*/g;
    const stripped = stemStr.replace(markerRe, ' ').replace(/\s{2,}/g, ' ').trim();
    if (stripped === stemStr || stripped.split(/\s+/).length < 4) continue;
    q.stem = stripped;
    q.type = 'true_false';
    q.typeEnName = typeInfoOf('true_false').enName;
    q.typeFaName = typeInfoOf('true_false').faName;
    q.options = [
      { id: 'true', text: 'True' },
      { id: 'false', text: 'False' },
    ];
  }
  if (!tfSection && /\u063a\u0644\u0637|\u0627\u0634\u062a\u0628\u0627\u0647|misspell|spelling/i.test(instrText)) {
    const wordList = rescueContentFromPreQuestion(text);
    for (const q of questions) {
      if (!q.options || q.options.length === 0) {
        q.type = 'error_correction';
        q.typeEnName = typeInfoOf('error_correction').enName;
        q.typeFaName = typeInfoOf('error_correction').faName;
        if (!q.stem || /^[.\u2026_\s]*$/.test(q.stem)) {
          if (wordList) q.stem = wordList;
        }
      }
    }
  }

  // Genre -> category remap (production genres are Writing; word-choice
  // genres are Vocabulary). Runs after the question types are stamped.
  // #qu2 wave 3: the unscramble remap only fires when the section carries NO
  // printed subject label — the golden sheets put unscramble rows under BOTH
  // Grammar and Writing labels (13/13), and the printed row label ("17
  // Grammar" on pq89w65173) is the sheet's own truth. A label-derived
  // non-General category therefore wins over the genre default.
  const remap = (c: ExamSection['majorCategory']) => {
    section.majorCategory = c;
    for (const q of questions) q.sectionName = c;
  };
  // Label pin: re-sync the question names with the pinned label (the chain
  // stamps above ran with the bled instruction text).
  if (labelPinned && section.majorCategory && section.majorCategory !== 'General') {
    for (const q of questions) q.sectionName = section.majorCategory;
  }
  if (questions.some((q) => q.type === 'unscramble')) {
    // Genre default is Writing — but a printed subject label ("17 Grammar" on
    // the radif row opener) outranks it (GT evidence: unscramble rows sit
    // under BOTH labels 13/13; the sheet's own label is the truth).
    if (!labelPinned) remap('Writing');
  } else if (questions.some((q) => q.type === 'matching' || q.type === 'odd_one_out' || q.type === 'error_correction')) remap('Vocabulary');

  // ردیف-table task verbs (#qu-corpus): numbered table rows carry their own task
  // (املا / جدول / ترجمه / سوالی کنید) that the generic classifiers miss because
  // the block's first line is often the bank or the table headers themselves.
  const hasOptions = (q: { options?: unknown[] }) => Array.isArray(q.options) && q.options.length > 0;
  const stampType = (q: { type: QuestionType; typeEnName?: string; typeFaName?: string }, t: QuestionType) => {
    q.type = t;
    q.typeEnName = typeInfoOf(t).enName;
    q.typeFaName = typeInfoOf(t).faName;
  };
  const syncSectionName = () => {
    for (const q of questions) q.sectionName = section.majorCategory;
  };

  // Dictation: "املا ناقص کلمات را کامل کرده و معانی آنها را … یادداشت نمایید" —
  // write the missing letters + the meaning. An open written answer (the dotted
  // tail is a translation line), not a bank/dots fill. Tight phrase on purpose:
  // "(به املا صحیح کلمات دقت کنید)" is a spelling NOTE inside other tasks, and
  // املا there must not retype the whole section. "دیکته" joins the family:
  // partial-word dash items ("p—ram---ds") are dictation completions. The
  // stamp is ZONE-GUARDED when a scoped bank exists — only the task zone
  // BEFORE the bank row is dictation; bank fills, form cues and translation
  // items further down keep their own types (real-exam 14050319 section A).
  if (/املا\s*ناقص|ناقص\s*املا|دیکته|complete\s+dictation|dictation/i.test(instrText) && !/غلط|اشتباه|misspell|spelling/i.test(instrText)) {
    for (const q of questions) {
      if (hasOptions(q)) continue;
      if (!beforeBankRow(q)) continue;
      stampType(q, 'short_answer');
      q.taskType = 'dictation';
    }
    if (section.majorCategory === 'General') section.majorCategory = 'Vocabulary';
    syncSectionName();
  }

  // Phrase "banks" are option/answer pools, not word-filling banks
  // (#qu2 wave 3, pq89w65173 row 12): when EVERY bank item is a multi-word
  // phrase, the sheet never fills single words from it (the pool is the MCQ
  // options or key snippets) — UNLESS the instruction itself contracts a
  // phrase fill ("Fill in the blanks with the right phrases" / "با عبارات
  // مناسب پر کنید", strict corpus 11th-first Q): that pool is multi-word BY
  // DESIGN and stays word_bank_fill.
  if (
    section.wordBank &&
    section.wordBank.length >= 2 &&
    section.wordBank.every((w) => w.trim().split(/\s+/).length >= 2) &&
    !/phrases?|عبارات/i.test(instrText)
  ) {
    section.hasWordBank = false;
    section.wordBank = undefined;
    for (const q of questions) {
      if (q.type === 'word_bank_fill') {
        q.type = 'fill_blank';
        q.typeEnName = typeInfoOf('fill_blank').enName;
        q.typeFaName = typeInfoOf('fill_blank').faName;
        delete q.wordBankWords;
        q.parentContextType = undefined;
        q.parentContextTitle = undefined;
        q.parentContextText = undefined;
      }
    }
  }

  // Table completion: "جدول زیر را کامل کنید" / "عبارات را در جدول جایگذاری کنید"
  // — country/nationality/continent table headers previously passed the
  // single-word-row bank heuristic and became a fake word bank. A table has no
  // candidate pool; completion/placement is fill_blank from knowledge.
  if (/جدول/.test(instrText) && /(کامل|جایگذاری|جای\s*گذاری)/.test(instrText)) {
    section.hasWordBank = false;
    section.wordBank = undefined;
    for (const q of questions) {
      if (q.parentContextType === 'word_bank') {
        q.parentContextType = 'none';
        q.parentContextTitle = undefined;
        q.parentContextText = undefined;
      }
      if (q.type === 'word_bank_fill' && !hasOptions(q)) stampType(q, 'fill_blank');
    }
  }

  // Question formation: "جملات داده شده را سوالی کنید" — turning statements
  // into questions is a Writing task; answers are open questions.
  if (/سوالی\s*کنید|سؤال\s*بسازید|make\s+questions?/i.test(instrText)) {
    for (const q of questions) if (!hasOptions(q)) stampType(q, 'short_answer');
    section.majorCategory = 'Writing';
    syncSectionName();
  }

  // Dictation task remap precedes this: "complete dictation then translate"
  // contains both keywords and is stamped there first. Phrase items run up to
  // ~4 words ("ride a horse"); full-sentence translations run 5+ or mix in
  // questions, so every() keeps them out.
  if (/ترجمه|translate/i.test(instrText)) {
    const openQs = questions.filter((q) => !hasOptions(q) && q.stem);
    for (const q of openQs) stampType(q, 'short_answer');
    const shortItems = openQs.length > 0 && openQs.every((q) => (q.stem as string).replace(/[^A-Za-z\s]/g, '').trim().split(/\s+/).filter(Boolean).length <= 4);
    if (shortItems && section.majorCategory === 'General') {
      section.majorCategory = 'Vocabulary';
      syncSectionName();
    }
  }

  // Fill-from-bank: "با توجه به کلمات داده شده جاهای خالی را کامل کنید" —
  // every question draws from the printed bank. Choice-formatted debris (a
  // "28- a) I have toothache  b) you should see a ……" two-variant row) and
  // dotted rows alike are bank fills; a genuine MCQ section says انتخاب/choose
  // and is excluded.
  if (
    section.wordBank &&
    section.wordBank.length >= 3 &&
    /کلمات\s*داده\s*شده|words?\s+given|جاهای\s*خالی/i.test(instrText) &&
    !/انتخاب|choose/i.test(instrText)
  ) {
    section.hasWordBank = true;
    for (const q of questions) {
      // Scoped banks apply only to the questions inside the bank span
      // (#bank-scoping); everything else keeps its own task type.
      if (!inBankScope(q)) continue;
      stampType(q, 'word_bank_fill');
      q.parentContextType = 'word_bank';
      q.parentContextTitle = `Word Bank (${section.rowId})`;
      q.parentContextText = `Candidate Words: [${section.wordBank.join(', ')}]`;
    }
    if (section.majorCategory === 'General') {
      section.majorCategory = 'Vocabulary';
    }
    syncSectionName();
  }

  // R5: commandless bank rows — a section whose head IS the bank row with no
  // printed instruction ("1.5 / Africa – German – Puzzle - go to library" /
  // "17- He is ………"). The bank + numbered blank rows are the whole contract;
  // the instruction-cued fill-from-bank above can never fire (no instrText),
  // so the rows stayed fill_blank/General while GT grades the fill-from-bank
  // genre (word_bank_fill, Vocabulary).
  if (
    section.wordBank &&
    section.wordBank.length >= 3 &&
    // Commandless means NO printed instruction at all — the bank row is the
    // section head. Sections that merely trail a word pool after their rows
    // (9_2 antonym/synonym: bank AFTER the ≠/= rows; hashom error-correction:
    // the list IS the exercise material) carry instructions and keep their
    // own task types.
    !section.persianInstruction?.trim() &&
    !section.englishInstruction?.trim() &&
    !section.wordBank.every((w) => w.trim().split(/\s+/).length >= 2) &&
    !/انتخاب|choose|match|وصل|ترجمه|translate|سوالی/i.test(instrText)
  ) {
    const blankFills = questions.filter(
      (q) => BLANK_RUN.test(q.stem ?? '') && !hasOptions(q) && !beforeBankRow(q),
    );
    if (blankFills.length >= 2 && blankFills.length >= Math.ceil(questions.length / 2)) {
      section.hasWordBank = true;
      for (const q of blankFills) {
        stampType(q, 'word_bank_fill');
        q.parentContextType = 'word_bank';
        q.parentContextTitle = `Word Bank (${section.rowId})`;
        q.parentContextText = `Candidate Words: [${section.wordBank.join(', ')}]`;
      }
      if (section.majorCategory === 'General') {
        section.majorCategory = 'Vocabulary';
      }
      syncSectionName();
    }
  }

  // Choose-the-correct-option WITHOUT printed options: "از بین دو گزینه داده
  // شده گزینه صحیح را انتخاب کنید" where the variants live inside the sentence
  // itself. Open answer, grammar judgement. Real MCQ sections carry options
  // and are skipped.
  if (/گزینه\s*صحیح/i.test(instrText) && questions.length > 0 && questions.every((q) => !hasOptions(q))) {
    for (const q of questions) stampType(q, 'short_answer');
    section.majorCategory = 'Grammar';
    syncSectionName();
  }

  // Word-meaning questions: "… به چه معناست؟" — vocabulary knowledge.
  // Tight phrase on purpose: "پاسخ های معنادار بنویسید" (write MEANINGFUL
  // answers) contains معنادار and must not retype unscramble sections.
  if (/به\s*چه\s*معنا|معنای\s|معني|what does .+ mean/i.test(instrText) && questions.length > 0) {
    for (const q of questions) if (!hasOptions(q)) stampType(q, 'short_answer');
    if (section.majorCategory === 'General') section.majorCategory = 'Vocabulary';
    syncSectionName();
  }

  // Sentence rewriting ("… بازنویسی کنید" / "Add the words in parenthesis to
  // the following sentence") — production work stays General; the instruction's
  // کلمات must not win Vocabulary.
  if (/بازنویسی|باز\s*نویسی|rewrite/i.test(instrText) && questions.length > 0) {
    if (section.majorCategory === 'Vocabulary') section.majorCategory = 'General';
    syncSectionName();
  }

  // Combine-sentences tasks ("combine the following sentences. (who – which –
  // whom)") — sentence fusion is production work; the paren list is a cue, so
  // the bank retype must not call it word_bank_fill.
  if (/combine\s+(?:the\s+)?(?:following\s+)?sentences/i.test(instrText) && questions.length > 0) {
    for (const q of questions) if (!hasOptions(q)) stampType(q, 'combine_sentences');
  }

  // "Find four grammatical mistakes … and correct them" / "Correct the
  // grammatical mistakes" / "Rewrite the sentences correcting the mistakes"
  // / "…has four mistakes. Find them and write the correct form" — the
  // answer cells (even bare dotted ones) are error-correction items.
  // TYPE stamping is BROAD (both word orders, every inflection): the old
  // `(?:find|correct)\b[^.\n]*mistakes?` missed "correcting" (the \b sits
  // after the WHOLE word, so correct\b never fires inside "correcting")
  // and any wording where mistakes precedes the task verb.
  // CATEGORY promotion stays NARROW on purpose: on RTL end-anchored papers
  // the section instruction can bleed from a neighboring block (9th 1-3
  // section G inherits the Mrs. Marta error-correction sentence while the
  // section itself is letter-completion Vocabulary — type already set by
  // the table rule). Clobbering that category to Grammar broke the corpus,
  // so Grammar is only forced by the exact historic wording, or when no
  // stronger category signal exists.
  const ecBroad = /(?:\b(?:find|correct)\w*[^\n]*\bmistakes?|\bmistakes?[^\n]*\b(?:find|correct)\w*)/i.test(instrText);
  if (ecBroad && questions.length > 0) {
    for (const q of questions) if (!hasOptions(q)) stampType(q, 'error_correction');
    if (/(?:find|correct)\b[^.\n]*mistakes?/i.test(instrText) || (section.majorCategory || 'General') === 'General') {
      section.majorCategory = 'Grammar';
      syncSectionName();
    }
  }

  // "put the letters in parenthesis in correct order" — anagram spelling
  // items (word formation in context) = letter reorder, Vocabulary.
  if (/put\s+the\s+letters?\b[^.\n]*correct\s+order|letters?\s+in\s+correct\s+order/i.test(instrText) && questions.length > 0) {
    for (const q of questions) if (!hasOptions(q)) stampType(q, 'letter_reorder');
    if (section.majorCategory === 'General') section.majorCategory = 'Vocabulary';
    syncSectionName();
  }

  // Unscramble sections whose word-soup row became a word bank / plain item:
  // "Unscramble the words…" + a dash-separated token line IS the scramble.
  const isDashSoup = (s: string) =>
    !BLANK_RUN.test(s) &&
    s.length >= 12 &&
    !/\d/.test(s) &&
    (s.match(/[–—]/g) || []).length >= 3 &&
    // Papers mix en-dashes and plain hyphens in one soup ("at – food - eat"),
    // and cells may end on bare punctuation ("friend - ."); split on ALL dash
    // flavors and tolerate punctuation-only segments.
    s.split(/\s*[–—-]\s*/).every((t) =>
      /^[A-Za-z'\u2019]+(\s+[A-Za-z'\u2019]+)*\s*[.,!?]*$/.test(t.trim()) ||
      /^[.,!?؟]+$/.test(t.trim()));
  if (/unscramble|مرتب\s*کنید|به\s*هم\s*ریخته/i.test(instrText) && questions.length > 0) {
    let any = false;
    for (const q of questions) {
      const s = (q.stem || '').trim();
      if (!hasOptions(q) && isDashSoup(s)) {
        stampType(q, 'unscramble');
        any = true;
      }
    }
    if (any) {
      section.hasWordBank = false;
      section.wordBank = undefined;
    }
  }

  // Dialogue sections: >=2 speaker-turn lines attach the conversation as the
  // shared parent context for questions that have no more specific context.
  const dialogueLines = lines.filter((l) => /^\s*[\w'\u2019\-]{2,20}\s*:\s*\S/.test(l));
  const hasPics = /\u062a\u0635\u0627\u0648\u06cc\u0631|\u062a\u0635\u0648\u06cc\u0631|\u0639\u06a9\u0633|picture|look\s*at/i.test(instrText);
  for (const q of questions) {
    if (dialogueLines.length >= 2 && (q.parentContextType === 'none' || !q.parentContextType)) {
      q.parentContextType = 'dialogue_context';
      q.parentContextTitle = `Dialogue (${rowId})`;
      q.parentContextText = dialogueLines.join('\n');
    }
    if (hasPics) {
      q.hasImage = true;
      if (q.parentContextType === 'none' || !q.parentContextType) {
        q.parentContextType = 'image_prompt';
        q.parentContextTitle = `Image Prompt (${rowId})`;
      }
    }
  }

  // Interrogative shield: a row that IS a question (question-word head + '?'
  // tail, no dotted blank) is a prompt, never a bank fill — banks fill dotted
  // blanks, and a question mark with no blank DNA cannot draw from a pool
  // (pkhn sec9 q1 "Are Asiatic and African cheetahs alike?" read
  // word_bank_fill off the passage's province comma list).
  for (const q of questions) {
    if (q.type !== 'word_bank_fill') continue;
    if (section.wordBank && section.wordBank.length > 0) continue; // a printed bank owns its fills (pc4i E q20)
    const s = (q.stem || '').trim();
    if (!/[?؟]\s*$/.test(s)) continue;
    if (/\.{3,}|…+|_{3,}/.test(s)) continue; // dotted blank + '?' = a fill stem
    if (/^(?:are|is|am|was|were|do|does|did|what|where|when|why|how|who|can|could|will|would|should|has|have|had)\b/i.test(s)) {
      q.type = 'short_answer';
      q.typeEnName = typeInfoOf('short_answer').enName;
      q.typeFaName = typeInfoOf('short_answer').faName;
      delete q.wordBankWords;
    }
  }

  // Fill-task shape split (pkhn sec4 "Fill in the blanks." + lettered rows):
  // a slash CHOICE group "(is going to buy / will buy)" fills the blank from
  // printed alternatives → inline_choice; a single lowercase verb hint
  // ("(to finish)") right after a blank transforms the given verb →
  // form_in_parentheses. Plain fill_blank survives when neither DNA exists.
  if (/fill\s+in\s+the\s+blanks|جاه[\u0600-\u06FF]{0,4}\s*خالی/i.test(instrText)) {
    for (const q of questions) {
      if (q.type !== 'fill_blank' && q.type !== 'word_bank_fill') continue;
      const s = q.stem || '';
      const blankAt = s.search(/\.{3,}|…+|_{3,}/);
      if (blankAt < 0) continue;
      const tail = s.slice(blankAt);
      const pair = tail.match(/\(([^()\n]{2,60}\/[^()\n]{2,60})\)/);
      const single = tail.match(/\(\s*([a-z]{1,12}(?:\s+to)?(?:\s+[a-z]{1,12})?)\s*\)/);
      if (pair) {
        const parts = pair[1].split('\/').map((p) => p.trim()).filter(Boolean);
        if (parts.length === 2 && parts.every((p) => /^[A-Za-z][A-Za-z'’\s]{0,24}$/.test(p))) {
          q.type = 'inline_choice';
          q.typeEnName = typeInfoOf('inline_choice').enName;
          q.typeFaName = typeInfoOf('inline_choice').faName;
          q.options = parts.map((p, pi) => ({ id: String.fromCharCode(97 + pi), text: p }));
          delete q.wordBankWords;
        }
      } else if (single && /^[a-z]/.test(single[1])) {
        q.type = 'form_in_parentheses';
        q.typeEnName = typeInfoOf('form_in_parentheses').enName;
        q.typeFaName = typeInfoOf('form_in_parentheses').faName;
        delete q.wordBankWords;
      }
    }
  }

  // ── R7-D: BARE-NUMBER GRID RULE ────────────────────────────────────────
  // Picture-slot rows printed as BARE numbers ("15  16  17  18" — pt7kkv
  // Vocabulary) over a lettered sentence pool (one extra). Each number is a
  // slot; the pool is its option set. The مشخص کنید / مربوط contract grades
  // matching (which sentence belongs to which picture); the انتخاب کنید
  // convention stays with the picture-choice mc machinery downstream.
  {
    const gridRows: { line: number; nums: number[] }[] = [];
    lines.forEach((l, i) => {
      const t = l.trim();
      if (!t || t.length > 40) return;
      const toks = t.split(/\s+/).filter(Boolean);
      if (toks.length < 3 || !toks.every((x) => /^\d{1,2}$/.test(x))) return;
      const nums = toks.map(Number);
      if (nums.every((n) => n >= 1 && n <= 60) && nums.length >= 3) gridRows.push({ line: i, nums });
    });
    for (const g of gridRows) {
      const pool: string[] = [];
      for (let i = g.line + 1; i < Math.min(lines.length, g.line + 14); i++) {
        const t = lines[i].trim();
        if (!t) {
          if (pool.length) break;
          continue;
        }
        const m = t.match(/^([a-h])\s*[.)]\s*(\S.*)$/i);
        if (m) pool.push(m[2].trim());
        else if (pool.length) break;
      }
      if (pool.length < Math.max(3, g.nums.length)) continue;
      const matchContract = /مشخص\s*کنید|مربوط|match/i.test(instrText);
      const existing = new Set(questions.map((q) => q.number));
      g.nums.forEach((n, k) => {
        if (existing.has(n)) return;
        const gq = {
          id: `q-${rowId}-grid-${n}`,
          number: n,
          displayNumber: String(n),
          sectionRowId: rowId,
          sectionName: section.majorCategory,
          type: matchContract ? 'matching' : 'multiple_choice',
          typeEnName: getQuestionTypeInfo(matchContract ? 'matching' : 'multiple_choice').enName,
          typeFaName: getQuestionTypeInfo(matchContract ? 'matching' : 'multiple_choice').faName,
          stem: '',
          options: pool.map((p, pi) => ({ id: String.fromCharCode(97 + pi), text: p })),
          mark: 0,
          parentContextType: 'image_prompt',
          parentContextTitle: `Picture Slot (${rowId})`,
          hasImage: true,
        } as QuestionItem;
        // Insert in NUMBER order — the grader compares positionally and the
        // grid slots print BEFORE the later subtasks (pt7kkv 15-18 vs 19-29).
        const at = questions.findIndex((x) => Number(x.number) > n);
        if (at < 0) questions.push(gq);
        else questions.splice(at, 0, gq);
      });
      section.matchingColumns = section.matchingColumns ?? {
        columnA: g.nums.map((n) => ({ id: n, text: `Picture ${n}` })),
        columnB: pool.map((p, i) => ({ id: String.fromCharCode(97 + i), text: p })),
      };
    }
  }

  // ── R7-E: REGION-CONTRACT OVERRIDE (final authority) ────────────────────
  // Task-region instructions outrank the section blend. The early region
  // pass (parseSectionBlock) runs BEFORE the shape machinery; the late
  // section-wide readers here (matching-halves fallback, tfSection,
  // odd-one-out) see the JOINED instructions and re-claim whole sections
  // over a region's own genre (pkhn sec8: the matching-pairs fallback
  // claimed the mc subtask rows, then tfSection flipped the option-less
  // matching halves). Regions get the final word; True/False furniture
  // options are stripped when a row is overridden away from true_false.
  {
    const regionTypeOfFinal = (instr: string): QuestionType | null => {
      if (/^match\b/i.test(instr.trim())) return 'matching';
      if (/make\s+a\s+sentence|unscramble/i.test(instr)) return 'unscramble';
      if (/active\s+(?:and|&)\s+passive|passive\s+(?:and|&)\s+active/i.test(instr)) return 'active_passive';
      if (/own\s+words/i.test(instr)) return 'fill_blank';
      if (/write\s+t\b|t\s*\(\s*true\s*\)|true\s+or\s+false|true\s*\/\s*false/i.test(instr)) return 'true_false';
      if (/definition/i.test(instr)) return 'matching';
      if (/^choose\s+the\s+best\s+(?:item|one|alternative|option)\b/i.test(instr.trim())) return 'multiple_choice';
      if (/^answer\s+the\s+questions?/i.test(instr.trim())) return 'short_answer';
      if (/forms?\s+of\s+(?:the\s+)?(?:words|verbs)|given\s+verbs/i.test(instr)) return 'form_in_parentheses';
      if (/given\s+words|word\s+bank|words\s+given/i.test(instr)) return 'word_bank_fill';
      // R7-A Persian region contracts (pt7kkv subtasks) — the bank evidence
      // (کلمات داده شده) must outrank the bare fill banner, definitions and
      // scrambles name their own genre.
      if (/کلمات\s*داده\s*شده/.test(instr)) return 'word_bank_fill';
      if (/تعریف/.test(instr)) return 'matching';
      if (/حروف[\s\S]{0,20}ریخته|ریخته[\s\S]{0,20}حروف/.test(instr)) return 'letter_reorder';
      if (/ریخته/.test(instr)) return 'unscramble';
      if (/تلفظ|pronunciation/i.test(instr)) return 'phonetic_pronunciation';
      if (/ناهماهنگ|متفاوت/.test(instr)) return 'odd_one_out';
      if (/مربوط\s*به\s*کدام/.test(instr)) return 'matching';
      // A bare fill banner — but a شکل صحیح banner fills with a printed CUE
      // pool ("جاهای خالی را با شکل صحیح مالکیت کامل کنید. of, 's, his/her"),
      // which the kanoon convention grades word_bank_fill — leave it to the
      // early machinery.
      if (/جاه[\u0600-\u06FF]{0,4}\s*خالی/.test(instr) && !/شکل\s*صحیح/.test(instr)) return 'fill_blank';
      return null;
    };
    const isRegionBannerFinal = (l: string) => {
      const t = l.trim();
      if (!t || t.length > 140) return false;
      if (/^\s*(?:\d{1,2}\s*[-.\)])?\s*(?:Complete|Choose|Match|Make|Answer|Read|Fill|Write|Put|Use|Unscramble|Listen|Find)\b/i.test(t)) return true;
      // Persian task banners: an imperative کنید verb, the bare fill banner,
      // or the Answer-the-questions head.
      if (/(?:پیدا|انتخاب|مشخص|کامل|بنویس|مرتب)\s*کنید/.test(t)) return true;
      if (/^جاه[\u0600-\u06FF]{0,4}\s*خالی/.test(t)) return true;
      return false;
    };
    const regionsF: { at: number; type: QuestionType | null }[] = [];
    for (let li = 0; li < lines.length; li++) {
      if (!isRegionBannerFinal(lines[li])) continue;
      regionsF.push({ at: li, type: regionTypeOfFinal(lines[li]) });
    }
    if (regionsF.length > 0) {
      if (process.env.PARSE_DEBUG) console.error('[regionsF]', regionsF.map((r) => `${r.at}:${r.type}`).join(' '), 'off', lineOffset);
      const finalGuard = (t: QuestionType) =>
        !['cloze_item', 'inline_choice', 'short_answer', 'long_answer_essay', 'multiple_choice'].includes(t);
      for (const q of questions) {
        const ls = q.receipt?.lineStart;
        if (ls === undefined) continue;
        const rel = ls - lineOffset;
        let regionType: QuestionType | null = null;
        for (const r of regionsF) if (rel >= r.at) regionType = r.type; // LAST banner above the row wins
        // A blank-bearing stem that already carries a SPECIFIC fill-family
        // type is not claimed by a generic matching/mc region (pt7kkv q23
        // "This ...... is not suitable…"; real 14050319 q24-30). Wrong
        // generic sources (matching halves fallback) still yield.
        if (
          regionType &&
          (regionType === 'matching' || regionType === 'multiple_choice') &&
          BLANK_RUN.test(q.stem || '') &&
          (['form_in_parentheses', 'word_bank_fill', 'fill_blank'].includes(q.type) ||
            /\([^()\n]{2,50}\)/.test(q.stem || ''))
        ) {
          regionType = null;
        }
        if (process.env.PARSE_DEBUG && regionType && q.type !== regionType) console.error('[regionF-q]', q.number, 'rel', rel, '->', regionType, 'was', q.type);
        if (!regionType || q.type === regionType || !finalGuard(q.type)) continue;
        // Per-row DNA outranks the banner: a row already carrying a specific
        // fill-family type keeps it under a bank banner (mock-06 q1-2), and a
        // row with its own printed verb-hint paren keeps form under a fill
        // banner (mock-06 q2 "( go )" vs pt7kkv q58 "in the park ......").
        if (
          (regionType === 'word_bank_fill' &&
            ['fill_blank', 'form_in_parentheses', 'inline_choice'].includes(q.type)) ||
          (regionType === 'fill_blank' &&
            q.type === 'form_in_parentheses' &&
            /\(\s*[a-z]{1,14}\s*\)/.test(q.stem || ''))
        ) {
          continue;
        }
        q.type = regionType;
        q.typeEnName = typeInfoOf(regionType).enName;
        q.typeFaName = typeInfoOf(regionType).faName;
        // T/F furniture from a section-wide flip is not the row's own
        if (
          regionType !== 'true_false' &&
          q.options &&
          q.options.length === 2 &&
          q.options.every((o) => /^(true|false)$/i.test(o.id) || /^(true|false)$/i.test(o.text.trim()))
        ) {
          q.options = undefined;
        }
      }
    }
  }
}


/**
 * Instructions that mark bank material / bank tasks, in both languages.
 * Used to confirm that a hyphen-separated candidate row really is a word bank.
 */
const WORD_BANK_CUE_RE =
  /کلمات|کلمه[یی]?\s*مناسب|جاه?ای?\s*خالی|کادر|جعبه|گزینه|words?\s+given|given\s+words|word\s+bank|words?\s+in\s+the|fill\s+in\s+the\s+blanks|choose\s+the\s+best/i;

/**
 * A hyphen-separated bank row: "Died out- entertainment- solve- plains".
 * Trailing hyphens glue to the words (that is how the sheet prints the
 * separators); an intra-word hyphen (brother-in-law) or a slash/comma list is
 * NOT this shape. Returns the trimmed candidate phrases, order preserved.
 */
export function matchHyphenBankRow(line: string): string[] | null {
  const t = line.trim();
  if (!t || /[\u0600-\u06FF]/.test(t)) return null; // Latin bank rows only
  if (/\d/.test(t)) return null; // numbered rows are questions, not banks
  if (BLANK_RUN.test(t)) return null; // fill rows are not banks
  if (looksLikeOptionRow(t) > 0) return null; // options rows are not banks
  if (/[,_;:/%()]/.test(t)) return null; // comma/slash/paren lists have their own paths
  if (!/[A-Za-z]/.test(t)) return null;
  const segs = t
    .split(/[-\u2013\u2014](?=\s|$)/)
    .map((s) => s.trim().replace(/^-+|-+$/g, ''))
    .filter(Boolean);
  if (segs.length < 3) return null;
  // Each item: 1-3 letters-only words, short enough to be vocabulary.
  if (!segs.every((s) => /^[A-Za-z][A-Za-z'\u2019]*(\s+[A-Za-z][A-Za-z'\u2019]*){0,2}$/.test(s) && s.length <= 24)) {
    return null;
  }
  return segs;
}

/**
 * Line span (0-based, section-raw space) of a hyphen-separated word bank:
 * start = the bank row, end = the instruction line that CLOSES the bank scope
 * ("Choose the best answer" opens the MCQ task; the bank belongs only to the
 * numbered items between the row and that line). Returns null when the
 * section's wordBank did not come from a hyphen row — bracket/comma banks keep
 * their legacy section-wide behavior.
 */
export function findWordBankSpan(text: string, wordBank: string[]): { start: number; end: number } | null {
  if (wordBank.length < 3) return null;
  const rawLines = text.split(/\r?\n/);
  const sameWords = (a: string[], b: string[]) =>
    a.length === b.length && a.every((w, i) => w.trim().toLowerCase() === b[i].trim().toLowerCase());
  for (let i = 0; i < rawLines.length; i++) {
    const segs = matchHyphenBankRow(rawLines[i]);
    if (!segs || !sameWords(segs, wordBank)) continue;
    // Scope ends at the first task boundary after the row: an instruction
    // line (English verb or Persian imperative) or a numbered question that
    // carries its own option row (an MCQ — bank never applies to those).
    let end = rawLines.length - 1;
    for (let j = i + 1; j < rawLines.length; j++) {
      const l = rawLines[j].trim();
      if (!l) continue;
      const isInstruction =
        /^\s*(?:Choose|Fill\s+in|Read|Match|Write|Make|Unscramble|Complete|Listen|Answer|Look\s+at|Put|Use|Circle|Cross|Find|According)\b/i.test(l) ||
        (/[\u0600-\u06FF]/.test(l) && /(دهید|کنید|بدهید|دهید\.)\s*$/.test(l));
      const isNumberedMcq =
        /^\s*\d{1,3}\s*[.)]/.test(l) &&
        rawLines
          .slice(j + 1, j + 3)
          .some((n) => looksLikeOptionRow(n.trim()) >= 0.7);
      if (isInstruction || isNumberedMcq) {
        end = j;
        break;
      }
    }
    return { start: i, end };
  }
  return null;
}

/**
 * Extracts candidate words from word bank boxes in any format:
 * [careful, pollution, healthy, dangerous, exercise] or ( a / b / c ) or tab/space separated
 */
function extractWordBankWordsFromBlock(text: string, lines: string[]): string[] {
  // 1. Search for bracketed list: [careful, pollution, healthy, dangerous, exercise]
  const bracketMatch = text.match(/\[\s*([a-zA-Z\s,;/\-–—]{10,})\s*\]/);
  if (bracketMatch) {
    const words = bracketMatch[1]
      .split(/[,;/]/)
      .map((w) => w.trim().replace(/^[-–—]+|[-–—]+$/g, ''))
      .filter((w) => w.length > 1 && !/[\u0600-\u06FF]/.test(w));
    if (words.length >= 3) return words;
  }

  // 2. Search for parenthetical word list: ( word1 / word2 / word3 )
  const parenMatch = text.match(/\(\s*([a-zA-Z\s,;/\-–—]{10,})\s*\)/);
  if (parenMatch && parenMatch[1].includes('/')) {
    const words = parenMatch[1]
      .split(/[/,;]/)
      .map((w) => w.trim())
      .filter((w) => w.length > 1 && !/[\u0600-\u06FF]/.test(w));
    if (words.length >= 3) return words;
  }

  // 2b. Hyphen-separated bank rows anywhere in the section ("Died out-
  // entertainment- solve- plains"): the trailing hyphens are SEPARATORS, a
  // phrase's internal space is part of the item. This shape sits BELOW the
  // numbered dictation items (step 3 breaks at the first number) and used to
  // fall into the single-space merge (step 4), which shredded it into
  // ["Died","out-","entertainment-",…] and swallowed the following
  // "Choose the best answer" instruction as bank "words".
  {
    for (let i = 0; i < lines.length; i++) {
      const segs = matchHyphenBankRow(lines[i]);
      if (!segs || segs.length < 3) continue;
      // A bank row lives next to its instruction: "Fill in the blanks with
      // the proper words." / "کلمهی مناسب را در جای خالی قرار دهید" above it,
      // or a choice instruction right below. No cue nearby — not a bank.
      // R5 exception: commandless rows print NO instruction at all — the
      // numbered blank rows BELOW the bank are the contract itself
      // ("1.5 / Africa – German – Puzzle - go to library" / "17- He is ……" ).
      const cued =
        lines.slice(Math.max(0, i - 4), i).some((l) => WORD_BANK_CUE_RE.test(l)) ||
        lines.slice(i + 1, i + 3).some((l) => WORD_BANK_CUE_RE.test(l)) ||
        lines.slice(i + 1, i + 3).some((l) => /^\s*\d{1,3}\s*[.)\-]/.test(l) && BLANK_RUN.test(l));
      if (cued) return segs;
    }
  }

  // 3. Search non-question lines before Q1
  for (const line of lines) {
    if (/^\s*\d+[\.\)]/.test(line)) break;
    // A word-bank row never carries speaker colons, digits, or dotted
    // blanks - dialogue lines with commas used to become a fake bank.
    if (/[:]/.test(line) || /\d/.test(line) || /(\.{3,}|…|_{3,})/.test(line)) continue;
    if (/^(?:Fill in|Complete|Words in|کلمات|[A-Z]\b)/i.test(line) && !line.includes(',')) continue;

    if (line.includes(',') || line.includes('/') || line.includes(';')) {
      const items = line
        .split(/[,/;]/)
        .map((w) => w.trim().replace(/^[-–—\[\(]+|[-–—\]\)]+$/g, ''))
        .filter((w) => w.length > 1 && !/[\u0600-\u06FF]/.test(w));
      // Reading-passage prose splits on commas too; its "items" are whole
      // clauses. A bank item is a word or short phrase — cap the length.
      if (items.length >= 3 && items.every((w) => w.length <= 30)) return items;
    }

    // Dash-separated bank rows: "Africa – German – Puzzle -  go to library".
    // En/em dashes always separate; an ASCII hyphen only when space-surrounded
    // (so hyphenated words like ping-pong survive). Numbered unscramble soups
    // never reach here (the /\d/ guard above skips them).
    if (/[–—]/.test(line) || /\s-\s/.test(line)) {
      const items = line
        .split(/\s+[–—-]\s+|[–—]/)
        .map((w) => w.trim().replace(/^[-–—\[\(]+|[-–—\]\)]+$/g, ''))
        .filter((w) => w.length > 1 && !/[\u0600-\u06FF]/.test(w));
      if (items.length >= 3) return items;
    }

    const spaceTokens = line
      .split(/\s{2,}|\t+/)
      .map((w) => w.trim().replace(/^[-–—\[\(]+|[-–—\]\)]+$/g, ''))
      .filter((w) => w.length > 1 && !/[\u0600-\u06FF]/.test(w));
    if (spaceTokens.length >= 3) return spaceTokens;
  }

  // 4. Single-space Latin word rows ("wash bedroom fixing kebab reading" or
  // table rows "sunset summer winter"). Letters-only, 3-10 short tokens; the
  // merged set of ALL qualifying rows forms the bank when any row is
  // self-evident (>=5 tokens), a bank/choice instruction sits nearby, or the
  // rows form a table of >=4 consecutive word rows.
  // Writing-contract veto (pq89 18): bullet ingredient lists under a
  // paragraph/essay task ("Eat fewer snacks" / "Eat more fruit and vegies")
  // are the writing REQUIREMENTS, not a fill bank — one 5-word prose bullet
  // used to self-qualify the merge and shroud the whole task in
  // word_bank_fill.
  if (!/پاراگراف|essay|topic\s*sentence/i.test(lines.join('\n'))) {
    const merged: string[] = [];
    let qualified = false;
    let run = 0;
    let maxRun = 0;
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      // Instruction lines ("Choose the best answer") are task banners, never
      // bank material — their words used to ride into the merged row.
      if (/^\s*(?:Choose|Fill\s+in|Read|Match|Write|Make|Unscramble|Complete|Listen|Answer|Look\s+at|Put|Use|Circle|Cross|Find)\b/i.test(line) && !BLANK_RUN.test(line)) {
        run = 0;
        continue;
      }
      const tokens = line.trim().split(/\s+/).filter(Boolean);
      const shapeOk =
        !/[\u0600-\u06FF]/.test(line) &&
        !/[^A-Za-z\s'\u2019\-]/.test(line) &&
        tokens.length >= 3 &&
        tokens.length <= 14 &&
        tokens.every((t) => /^[A-Za-z'\u2019\-]{2,14}$/.test(t));
      if (!shapeOk) {
        run = 0;
        continue;
      }
      const nearBankInstruction =
        lines.slice(Math.max(0, i - 6), i).some((l) => /کلمات|کادر|جعبه|گزینه|words?\s+in|word\s+bank|given\s+words|choose/i.test(l)) ||
        lines.slice(i + 1, i + 4).some((l) => /کلمات|کادر|جعبه|گزینه|words?\s+in|word\s+bank|given\s+words|choose/i.test(l));
      merged.push(...tokens);
      run++;
      maxRun = Math.max(maxRun, run);
      if (tokens.length >= 5 || nearBankInstruction) qualified = true;
    }
    if (maxRun >= 4) qualified = true;
    if (qualified && merged.length >= 3) return merged;
  }


  // 5. Consecutive single-word Latin rows (docx boxes put ONE word per line:
  // "wash" / "bedroom" / "fixing" ...). A run of >=3 single-word lines is a
  // word bank; every other line shape carries punctuation that disqualifies.
  {
    const run: string[] = [];
    for (const line of lines) {
      const t = line.trim();
      if (/^[A-Za-z'’-]{2,14}$/.test(t)) {
        run.push(t);
      } else {
        if (run.length >= 3) return run;
        run.length = 0;
      }
    }
    if (run.length >= 3) return run;
  }

  // 6. Lettered phrase rows ("a. busy with their work" / "b. having healthy
  // relationships" ...) — a phrase bank for passage fill tasks. Runs of >=3
  // consecutive single-letter prefixed lines. Rows carrying dotted blanks,
  // column markers ("B) so") or Persian are run-breakers (option columns and
  // matching tables are not banks).
  {
    let run: string[] = [];
    const runs: string[][] = [];
    for (const line of lines) {
      const m = line.match(/^[a-dA-D][.)\u2013\u2014]\s+(.{2,})$/);
      const content = m ? m[1].trim() : '';
      const ok =
        !!m &&
        content.split(/\s+/).length >= 2 &&
        !/[\u0600-\u06FF]/.test(content) &&
        !/(\.{2,}|…|_{2,})/.test(content) &&
        !/[A-Za-z][).][^\s]/.test(content.slice(2));
      if (ok) run.push(content);
      else {
        if (run.length >= 3) runs.push(run);
        run = [];
      }
    }
    if (run.length >= 3) runs.push(run);
    if (runs.length > 0) {
      const words = runs.sort((a, b) => b.length - a.length)[0];
      if (words.length >= 3) return words;
    }
  }

  return [];
}

/**
 * Extracts questions from section text.
 *
 * PRIMARY PATH (#3): the rule-table walk — classify lines, segment question
 * blocks, then run the shared structure builder over each block. Every block
 * carries a receipt (source lines + rules + rejected alternatives).
 *
 * FALLBACK: the legacy single-regex scanner. Used when the rule table finds
 * no question blocks (weird layouts) and for trace-less callers. The trace
 * records `fallbackUsed` honestly.
 */
function extractQuestionsFromText(
  text: string,
  rowId: string,
  category: string,
  wordBank: string[],
  passageText: string,
  anomalies: ParsingAnomaly[],
  options: ParseOptions,
  traceCtx?: TraceCtx,
  bankSpan?: { start: number; end: number } | null,
  instructionProbe?: string,
): QuestionItem[] {
  const items: QuestionItem[] = [];

  // Bank-scope test (#bank-scoping): receipts carry GLOBAL line indices; the
  // span is section-relative, so convert through the section's line offset.
  // Questions whose block starts inside (bank row, scope end) may draw from
  // the bank; everything else keeps its own task type and carries NO bank
  // metadata (the old unconditional attach fed Jev wrong Choice candidates).
  // No span (bracket/comma banks) or no receipt (legacy fallback) = legacy
  // section-wide behavior.
  const bankOffset = traceCtx ? traceCtx.lineOffset : 0;
  const bankSpanGlobal = bankSpan ? { start: bankSpan.start + bankOffset, end: bankSpan.end + bankOffset } : null;
  const seedInBankScope = (seed: Seed): boolean => {
    if (!bankSpanGlobal) return true;
    const ls = seed.receipt?.lineStart;
    if (ls === undefined) return true;
    return ls > bankSpanGlobal.start && ls < bankSpanGlobal.end;
  };

  interface Seed {
    rawNumber: number;
    rawContent: string;
    receipt?: QuestionReceipt;
  }
  const seeds: Seed[] = [];
  let usedRuleTable = false;
  // Questions whose mark was EXPLICITLY printed in the source (never clobber
  // these by the section-total division).
  const explicitMarkIds = new Set<string>();

  if (traceCtx && !options.disableRuleTable) {
    const lines = text.split(/\r?\n/);
    const classifications = classifyLines(lines);
    // Record global classifications for the document trace.
    for (const c of classifications) {
      traceCtx.classifications.push({ ...c, lineIndex: c.lineIndex + traceCtx.lineOffset });
    }
    const blocks = segmentQuestionBlocks(classifications);
    if (blocks.length > 0) {
      usedRuleTable = true;
      for (const b of blocks) {
      const body = b.text
        .replace(/^\s*\d{1,3}\s*[\.\)\-–—]\s*/, '')
        // R25 mirrored heads: "16(This morning…" — the bidi-mirrored paren
        // glues the head to the stem. A spaced remark "12 (see…)" must NOT
        // strip, so no space is allowed before the paren here.
        .replace(/^\s*\d{1,3}\((?=[A-Za-z\u0600-\u06FF.…_])/, '')
        // kanoon lane-wrapped head: "23( 11(He changed…" — strip the whole
        // lane+exercise pair; the builder already took the INNER number.
        .replace(/^\s*\d{1,3}\s*\(\s*\d{1,3}\s*[()]\s*/, '')
        // Space-form start (R21): "25 I called…" — no punctuation to strip,
        // so the printed number used to survive into the stem.
        .replace(/^\s*\d{1,3}\s+(?=[A-Z\u0600-\u06FF])/, '')
        .trim();
        // Bare multi-number slot rows ("37-  38-  39-  40-"): spelling-error
        // answer tables print N empty slots on one line. Explode into one
        // seed per number so no question silently vanishes.
        const firstLine = body.split(/\r?\n/)[0] || '';
        const bareNums = firstLine.match(/\d{1,3}\s*[-–—.]/g);
        if (firstLine && bareNums && bareNums.length >= 2 && firstLine.replace(/[\d\s\-–—.]/g, '') === '') {
          const nums = [b.number, ...(firstLine.match(/\d{1,3}/g) || []).map((n) => parseInt(n, 10))].filter((n) => Number.isFinite(n) && n > 0);
          for (const n of nums) {
            seeds.push({ rawNumber: n, rawContent: '', receipt: {
              lineStart: b.lineStart + traceCtx.lineOffset,
              lineEnd: b.lineEnd + traceCtx.lineOffset,
              ruleChain: [...b.ruleChain, 'slot-row-explode'],
              ruleConfidence: 70,
            } });
          }
          continue;
        }
        seeds.push({
          rawNumber: b.number,
          rawContent: body,
          receipt: {
            lineStart: b.lineStart + traceCtx.lineOffset,
            lineEnd: b.lineEnd + traceCtx.lineOffset,
            ruleChain: b.ruleChain,
            alternates: b.alternates.length ? b.alternates : undefined,
            ruleConfidence: Math.round(Math.min(1, Math.max(0, b.minConfidence)) * 100),
          },
        });
        // Two-column extraction merge: "1- he goes swimming ... 3- I can take
        // photos" — the second column's question rides on the same line.
        // Canonicalization collapses the column gap to one space, so the
        // signal is a mid-line number marker followed by a letter, with the
        // marker number greater than the block's own number. FOUR-column
        // rows ("1-climb a m…untain  2-rid… a horse  3-cou…h  4-n…rse")
        // split at EVERY marker, one seed per segment.
        const firstLineBody = body.split(/\r?\n/)[0] || '';
        const colRe = /\s(\d{1,3})\s*[-–—.]\s*(?=[A-Za-z])/g;
        const markers: { start: number; end: number; num: number }[] = [];
        let cm: RegExpExecArray | null;
        while ((cm = colRe.exec(firstLineBody)) !== null) {
          const n2 = parseInt(cm[1], 10);
          if (n2 <= b.number) continue;
          // A PERIOD-form marker ("25. Erfan…") must close a SENTENCE — mid-
          // sentence numbers ("Amin is 25. Erfan is 25.") are content, never
          // column merges (p8214 sec 5 q19 was shredded at "is 25.").
          if (cm[0].includes('.') && !/[.!?…]\s*$/.test(firstLineBody.slice(0, cm.index))) continue;
          markers.push({ start: cm.index, end: cm.index + cm[0].length, num: n2 });
        }
        // A bare-number head ("27. 18. The heavens…") is double-prefix
        // exam-writer debris, not a multi-column row — never split it.
        if (markers.length > 0 && /^[\d.\s]*$/.test(firstLineBody.slice(0, markers[0].start).trim())) markers.length = 0;
        if (markers.length > 0) {
          const segments: { num: number; text: string }[] = [];
          const head = firstLineBody.slice(0, markers[0].start).trim();
          if (head) segments.push({ num: b.number, text: head });
          for (let mi = 0; mi < markers.length; mi++) {
            const segEnd = mi + 1 < markers.length ? markers[mi + 1].start : firstLineBody.length;
            const seg = firstLineBody.slice(markers[mi].end, segEnd).trim();
            if (seg) segments.push({ num: markers[mi].num, text: seg });
          }
          if (segments.length >= 2) {
            seeds.pop(); // replace the whole-line seed with the per-column seeds
            for (const s of segments) {
              seeds.push({
                rawNumber: s.num,
                rawContent: s.text,
                receipt: {
                  lineStart: b.lineStart + traceCtx.lineOffset,
                  lineEnd: b.lineEnd + traceCtx.lineOffset,
                  ruleChain: [...b.ruleChain, markers.length > 1 ? 'column-split-multi' : 'column-split'],
                  ruleConfidence: 70,
                },
              });
            }
          }
        }
      }
    }
  }

  // Cloze-option rows: "49 a. interested b. wonderful c. difficult d. beautiful"
  // — a number followed by four inline options on ONE line (cloze tests print
  // the choice sets under the passage). One MCQ seed per row.
  {
    const clozeOptRe = /^(\d{1,3})\s*[.)]?\s*a[.)]\s*([^\n]+?)\s*b[.)]\s*([^\n]+?)\s*c[.)]\s*([^\n]+?)\s*d[.)]\s*([^\n]+)$/gim;
    let cm: RegExpExecArray | null;
    const clozeSeeds: Seed[] = [];
    const alreadySeeded = new Set(seeds.map((s) => s.rawNumber));
    while ((cm = clozeOptRe.exec(text)) !== null) {
      const num = parseInt(cm[1], 10);
      if (!Number.isFinite(num) || num <= 0 || num > 150) continue;
      if (alreadySeeded.has(num)) continue; // the rule table already built this question
      if (clozeSeeds.some((s) => s.rawNumber === num)) continue;
      const opts = [cm[2], cm[3], cm[4], cm[5]].map((t, i) => ({ id: String.fromCharCode(97 + i), text: t.trim().replace(/\s+/g, ' ') }));
      if (opts.every((o) => o.text.length >= 1)) {
        clozeSeeds.push({ rawNumber: num, rawContent: '', receipt: { lineStart: 0, lineEnd: 0, ruleChain: ['cloze-option-row'], ruleConfidence: 85 }, __clozeOpts: opts } as Seed & { __clozeOpts?: ExamOption[] });
      }
    }
    if (clozeSeeds.length >= 2) {
      for (const cs of clozeSeeds) {
        seeds.push(cs);
      }
    }
  }

  if (!usedRuleTable) {
    if (traceCtx) traceCtx.fallbackUsed = true;
    // Legacy: match question numbers at line starts, e.g. "1. ...", "l. ...",
    // "2.Thesunis..." (normalizeOcrText repairs the worst cases upstream).
    const itemRegex =
      /(?:^|\n)\s*(\d+)[\.\)]\s*([^\n\r]+(?:\n(?!\s*\d+[\.\)]|\s*[|_\-~*#•]?\s*[A-Z][\.\)\-–—:]\s+[A-Za-z\u0600-\u06FF])[^\n\r]+)*)/g;
    const matches = Array.from(text.matchAll(itemRegex));
    for (const m of matches) {
      // A pure-decimal number line ("2.5", "1.5") is a بارم mark cell, never a
      // question start — its ghost seed used to swallow the section tail and
      // type itself "unscramble" off the date's slashes.
      const numLine = (m[0].split('\n').find((x) => x.trim()) || '').trim();
      if (/^\d{1,2}\.\d{1,2}$/.test(numLine)) continue;
      seeds.push({ rawNumber: parseInt(m[1], 10), rawContent: m[2].trim() });
    }
  }

  // ── R6-c: LETTERED-ITEM SEED PASS ────────────────────────────────────────
  // Sections whose items are lettered (a. b. c. …) instead of numbered. Both
  // the rule table and the legacy scanner key on printed numbers and starve
  // here (pkhn sec3 kept a single garbage block built off the page footer's
  // phone digits while its five a–e items sat unextracted). Fire when the
  // section's seed set is DEGENERATE against its lettered inventory and the
  // guards hold:
  //   G1 numbered ownership — a real numbered sequence (>= 3 seeds) owns the
  //      section; lettered rows are its word bank / sub-parts, never a
  //      replacement.
  //   G2 pure-decimal lines are بارم cells, never item heads.
  //   G3 absolute-numbering blanks ("......34......") — a prose passage with
  //      MORE numbered mid-line slots than lettered heads is a cloze sheet;
  //      the cloze machinery owns it.
  //   G4 interrogative transcript — when >= half the item heads end in '?'
  //      the section is a dialogue; the dialogue machinery owns it.
  //   G5 bidi artifacts: "c .My friend" (space before the dot) is an item
  //      head; "a) True b) False" inline pairs ride INSIDE their item's
  //      content; a dense short-segment grid is an option row, never a head.
  // Seed content spans to the NEXT item head (stem + its option lines); ids
  // run 1..N over the section's items in document order (per-section kanoon
  // convention — pools reset at 'a' but the ladder does not).
  {
    const letterHeads: { line: number; letter: string; text: string }[] = [];
    {
      const ls = text.split(/\r?\n/);
      const segsOf = (l: string) =>
        l.split(/(?:^|\s)[a-j]\s*[.)]\s*/i).map((s) => s.trim()).filter(Boolean);
      for (let i = 0; i < ls.length; i++) {
        const t = ls[i].trim();
        if (!t) continue;
        if (/^\d{1,2}\.\d{1,2}$/.test(t)) continue; // G2 mark cell
        const m = t.match(/^\s*([a-j])\s*[.)]\s*(\S.*)$/i);
        if (!m) continue;
        // G5: dense option grid — ≥3 markers, every segment short
        const segs = segsOf(t);
        if (segs.length >= 3 && segs.every((s) => s.length <= 24)) continue;
        letterHeads.push({ line: i, letter: m[1].toLowerCase(), text: m[2] });
      }
    }
    // Pools: a fresh 'a' opens the next pool; pools shorter than 2 items are
    // decoration (a lone "a." label).
    const pools: { line: number; letter: string; text: string }[][] = [];
    for (const h of letterHeads) {
      if (h.letter === 'a' || pools.length === 0) pools.push([]);
      pools[pools.length - 1].push(h);
    }
    const items = pools.filter((p) => p.length >= 2).flat();
    if (items.length >= 3 && items.length > seeds.length) {
      // G1 numbered ownership — real numbered PROSE rows own the section
      // (10th-first O / 11th-first Q: genuine stems with printed absolute
      // numbers; pq89 sec5 / pm57 A: the numbered MCQ rows extract through
      // the later option-grid machinery, so the seed set is still empty
      // here — the TEXT-level numbered rows are the ownership evidence). A
      // seed built off furniture (pkhn sec3's single phone-digit block) is
      // not ownership — the lettered inventory wins.
      const proseSeeds = seeds.filter(
        (s) => ((s.rawContent || '').match(/[A-Za-z\u0600-\u06FF]{2,}/g) ?? []).length >= 3,
      ).length;
      const numberedProseRows = text.split(/\r?\n/).filter((l) =>
        /^\s*\d{1,3}\s*[.)\-–—]\s*[A-Za-z\u0600-\u06FF"'“(]/.test(l),
      ).length;
      // Paren-slot numbering ("(15)  (16)  (17)  (18)" — pq89 sec5): the
      // lettered lines are the picture-choice SENTENCE POOL for those slots,
      // not the section's questions. Bare slot rows ("21. ……  22. ……" —
      // pm57 A) are the same evidence in the dotted form.
      const parenSlots = (text.match(/\(\s*\d{1,3}\s*\)/g) ?? []).length;
      const slotRows = (text.match(/\d{1,3}\s*[.)]\s*(?:\.{3,}|…+|_{3,})/g) ?? []).length;
      if (proseSeeds >= 2 || numberedProseRows >= 2 || parenSlots >= 2 || slotRows >= 2) {
        // keep the numbered sequence — lettered rows are furniture here
      } else {
        // G3 absolute-numbering blanks outrank the letter count — dotted OR
        // ellipsis runs ("......34......" / "………64………" — 11th-first Q prose)
        // carry the section's real numbering; when they match the item count
        // the prose owns the ladder and the lettered rows are furniture.
        const absBlanks = (text.match(/(?:\.{3,}|…{2,})\s*\d{1,3}\s*(?:\.{2,}|…{2,})/g) ?? []).length;
        // G4 interrogative transcript
        const interrog = items.filter((h) => /\?\s*$|؟\s*$/.test(h.text.trim())).length;
        if (absBlanks < items.length && interrog * 2 < items.length) {
          if (process.env.PARSE_DEBUG) console.error('[lettered-pass] FIRE', rowId, 'items', items.length, 'heads', JSON.stringify(items.slice(0, 3).map((h) => h.text.slice(0, 40))));
          const ls = text.split(/\r?\n/);
          seeds.length = 0;
          items.forEach((h, k) => {
            const end = k + 1 < items.length ? items[k + 1].line : ls.length;
            const content = ls.slice(h.line, end).join('\n').trim();
            seeds.push({
              rawNumber: k + 1,
              rawContent: content.replace(/^\s*[a-j]\s*[.)]\s*/i, ''),
              receipt: {
                lineStart: h.line + (traceCtx?.lineOffset ?? 0),
                lineEnd: end - 1 + (traceCtx?.lineOffset ?? 0),
                ruleChain: ['lettered-item-pass'],
                ruleConfidence: 80,
              },
            });
          });
        }
      }
    }
  }

  // ── R7-C: INLINE-FILL-REGION PASS ────────────────────────────────────────
  // A listening/reading fill task prints its blanks INLINE in the prose
  // ("I always  9 ......  them."), so no line starts with the number and
  // both the rule table and the legacy scanner starve (pt7kkv q9-14: only
  // the line-start numbers survived). When the section's instruction
  // carries the fill contract, every [number][blank-run] token seeds a
  // fill_blank row whose stem is the enclosing line; existing numbers are
  // never duplicated (line-start numbers keep their rule-table receipt).
  {
    const fillContract = /جاه[\u0600-\u06FF]{0,4}\s*خالی|کامل\s*کنید|fill\s+in\s+the\s+blanks/i.test(instructionProbe ?? '');
    // The pass exists for PROSE-embedded blanks — numbers mid-line inside
    // running text (pt7kkv "I always 9 ...... them."). A sheet whose
    // numbered rows all start their own lines (real 14050319) has no
    // prose-blank region, and a stray furniture token must not spawn a
    // copy: require at least 3 MID-LINE tokens before firing.
    if (fillContract) {
      const midLineTokens = text
        .split(/\r?\n/)
        .filter((l) => /(?:[^\d."']|^\s{4,})(\d{1,2})\s*(?:\.{2,}|…{2,}|_{2,})/.test(l) && !/^\s*\d{1,2}\s*[.)\-]/.test(l))
        .length;
      if (midLineTokens >= 3) {
      const known = new Set(seeds.map((s) => s.rawNumber));
      const inlineSeeds: Seed[] = [];
      const tokenRe = /(?:^|[^\d."'])(\d{1,2})\s*(?:\.{2,}|…{2,}|_{2,})/g;
      const lsC = text.split(/\r?\n/);
      for (let li = 0; li < lsC.length; li++) {
        const l = lsC[li];
        let m: RegExpExecArray | null;
        tokenRe.lastIndex = 0;
        while ((m = tokenRe.exec(l)) !== null) {
          const n = parseInt(m[1], 10);
          if (!Number.isFinite(n) || n <= 0 || n > 60) continue;
          if (known.has(n)) continue;
          known.add(n);
          const stem = l.trim().replace(/\u2026{2,}/g, '……').replace(/\.{4,}/g, '……');
          inlineSeeds.push({
            rawNumber: n,
            rawContent: stem,
            receipt: {
              lineStart: li + (traceCtx?.lineOffset ?? 0),
              lineEnd: li + (traceCtx?.lineOffset ?? 0),
              ruleChain: ['inline-fill-region'],
              ruleConfidence: 85,
            },
          });
        }
      }
      if (inlineSeeds.length >= 2) seeds.push(...inlineSeeds);
      }
    }
  }

  // Subtask header lines (R5, p4t7882699): "1 - Complete the following
  // sentences." / "2 -Make questions for the underlined words…" — task
  // counters prefixing an English imperative banner are SUBTASK headers, not
  // questions. They spawned phantom seeds whose numbers restarted the
  // section's ladder (printed 19-26 graded as 1-8). Drop when the body is a
  // pure imperative instruction (no blank DNA, no question mark, no form
  // hint) while the section's real sequence runs past the counter.
  {
    const isInstructionBody = (c: string) => {
      // FIRST LINE only — bidi tails glue the next question's rows below the
      // banner and would push the word count over the bar.
      const t = ((c || '').split(/\r?\n/)[0] || '').trim();
      if (!t || /\.{2,}|…+|_{2,}|\?|؟|\(\s*[a-z]{1,12}/i.test(t)) return false;
      if (!/^(?:Complete|Choose|Match|Make|Answer|Read|Fill|Write|Put|Use|Listen|Circle|Find|Unscramble|Select)\b/i.test(t)) return false;
      return t.split(/\s+/).length <= 14;
    };
    const maxSeedNum = seeds.reduce((mx, s) => Math.max(mx, s.rawNumber), 0);
    if (maxSeedNum >= 10) {
      const keptSeeds = seeds.filter(
        (s) => !(s.rawNumber <= 5 && isInstructionBody(s.rawContent)),
      );
      seeds.length = 0;
      seeds.push(...keptSeeds);
    }
  }
  // Trailing-number mirror rows (R5, p4t7882699 32-33): bidi tables print the
  // question number at the line's FAR END (". friends have graduated My -
  // 32" = "32- My friends have graduated."). Recovered as their own seeds —
  // the dropped subtask banner used to carry them away, and their printed
  // numbers never reached the ladder.
  {
    const extra: Seed[] = [];
    const seenNums = new Set(seeds.map((s) => s.rawNumber));
    for (const s of seeds) {
      const contentLines = (s.rawContent || '').split(/\r?\n/);
      if (contentLines.length < 2) continue;
      const kept: string[] = [];
      for (const cl of contentLines) {
        const m = cl.trim().match(/^\s*[.…_\s]*([^\n]{4,}?)\s*[-–—]\s*(\d{1,3})\s*$/);
        if (!m) {
          kept.push(cl);
          continue;
        }
        const n = parseInt(m[2], 10);
        if (!Number.isFinite(n) || n <= 0 || n > 150 || seenNums.has(n)) {
          kept.push(cl);
          continue;
        }
        seenNums.add(n);
        extra.push({ rawNumber: n, rawContent: m[1].replace(/^[.\s]+/, '').trim() });
      }
      s.rawContent = kept.join('\n').trim();
    }
    for (const e of extra) seeds.push(e);
  }

  // --- Embedded numbered blanks (dialogue / form-fill layouts) -------------
  // Iranian papers embed numbered dotted blanks MID-LINE inside dialogues and
  // forms: "Mom: he is in the 26- ………". The line-start segmenter never sees
  // them (a speaker prefix hides the number), so whole sections parsed as 0
  // questions. Recover every numbered blank the block seeds don't cover.
  const blankSentences = extractNumberedBlankSentences(text);
  const seededNumbers = new Set(seeds.map((s) => s.rawNumber));
  for (const [num, info] of blankSentences) {
    if (!seededNumbers.has(num)) {
      seeds.push({ rawNumber: num, rawContent: info.sentence, __fromBlank: true } as Seed & { __fromBlank?: boolean });
      seededNumbers.add(num);
    }
  }
  // A seed whose content carries its own printed blank number ("31. Did
  // Alexander Flemming 44…………….. ( corevdis ) penicillin?") renumbers to it:
  // copied-in prefixes ("31.", "58.") are exam-writer debris; the answer-slot
  // number is the paper's real numbering.
  for (const seed of seeds) {
    const cm = (seed.rawContent || '').match(/(?<![\d.\u2026_])(\d{1,3})(?!\d)\s*(?:[-–—.]?\s*)?(?:\.{2,}|…+|_{2,})/);
    if (cm) {
      // fix-8 guard: a row that is ONLY "<number> + dots" is a DATA row of a
      // numbers task ("5- 14 ………" = write 14 in words) — the digit is the
      // payload, the outer prefix is the real question number. The blank-slot
      // renumber stays reserved for numbers blanked INSIDE letterish content.
      const firstLine = (seed.rawContent || '').split(/\r?\n/)[0] || '';
      const letterTail = firstLine.replace(/[\d.\u2026\s_\-–—]+/gu, '');
      if (letterTail.length === 0) continue;
      const n = parseInt(cm[1], 10);
      if (n >= 1 && n <= 150 && n !== seed.rawNumber && !seeds.some((x) => x.rawNumber === n)) {
        seed.rawNumber = n;
        (seed as Seed & { __renumbered?: boolean }).__renumbered = true;
      }
    }
  }
  // Furniture seeds never survive (R2): a seed whose content IS a page-header
  // block («024 - 2332» + «نام درس…» + «نام دبیر…» + …) is a phantom question
  // and poisons the numbering ladder below it — DROP it. The signature of a
  // pure header seed: NO prose anywhere and several furniture lines. A seed
  // with real prose keeps its question even when furniture got glued on
  // (p8214 "25) we must hunt… \n www-kanoon-ir") — the glue is stripped, the
  // question never is; stem-less slots ("40-" + row letter + Goodluck) have
  // no prose and only a single farewell line — kept.
  const isDebris = (x: string) => /^[A-Za-z]{1,2}$/.test(x) || /^[\d\s.\-–—.:()]+$/.test(x);
  const furnitureFree: Seed[] = [];
  for (const s of seeds) {
    const rawLines = (s.rawContent || '').split(/\r?\n/);
    const nonEmpty = rawLines.map((x) => x.trim()).filter(Boolean);
    if (nonEmpty.length === 0) { furnitureFree.push(s); continue; } // stem-less slots keep their own path
    const proseLines = nonEmpty.filter((x) => !isDebris(x) && !isFurnitureLine(x));
    const furnCount = nonEmpty.filter((x) => isFurnitureLine(x)).length;
    if (proseLines.length === 0 && furnCount >= 2) continue; // pure header block — drop
    const kept = rawLines.filter((x) => { const t = x.trim(); return !t || !isFurnitureLine(t); });
    if (kept.length !== rawLines.length) s.rawContent = kept.join('\n').replace(/\n{2,}/g, '\n').trim();
    furnitureFree.push(s);
  }
  if (furnitureFree.length !== seeds.length) {
    for (const dropped of seeds) {
      if (!furnitureFree.includes(dropped)) {
        (dropped as Seed & { __furnitureDropped?: boolean }).__furnitureDropped = true;
      }
    }
    seeds.length = 0;
    seeds.push(...furnitureFree);
  }
  seeds.sort((a, b) => (Number(a.rawNumber) || 0) - (Number(b.rawNumber) || 0));

  for (let i = 0; i < seeds.length; i++) {
    const seed = seeds[i];
    const rawNumber = Number.isFinite(seed.rawNumber) ? seed.rawNumber : i + 1;
    let rawContent = seed.rawContent;
    // Cloze-option seeds carry their full a-d option set — build the MCQ
    // directly (the stem lives in the passage, attached as context below).
    const clozeOpts = (seed as Seed & { __clozeOpts?: ExamOption[] }).__clozeOpts;
    if (clozeOpts) {
      const clozeNum = Number.isFinite(seed.rawNumber) ? seed.rawNumber : items.length + 1;
      items.push({
        id: `q-${rowId}-${clozeNum}`,
        displayNumber: String(clozeNum),
        number: clozeNum,
        sectionRowId: rowId,
        sectionName: category,
        type: 'multiple_choice',
        typeEnName: getQuestionTypeInfo('multiple_choice').enName,
        typeFaName: getQuestionTypeInfo('multiple_choice').faName,
        stem: '',
        options: clozeOpts,
        mark: 0.5,
        parentContextType: passageText ? 'reading_passage' : 'none',
        parentContextTitle: passageText ? `Reading Passage (${rowId})` : undefined,
        parentContextText: passageText || undefined,
        hasImage: false,
        receipt: seed.receipt,
      } as unknown as QuestionItem);
      continue;
    }
    // Empty seeds (slot-row explosions like "37- 38- 39- 40-") are kept: the
    // context-rescue pass below fills their stem from the section's own
    // pre-question content. Truly context-less empties are dropped there.

    // Check for trailing per-question mark: "(0.5)", "[0.5]", "(1 pt)"
    // A seed whose ENTIRE content is a paren number ("(1)") is a picture-slot
    // QUESTION (R22 owns it) — the mark reader used to eat the slot number as
    // a per-question mark whenever it was <= 10 (p8214 sec 1: slots (1)-(4)
    // became marks 1..4, stem lost, total 10).
    const isBareParenSlot = /^\s*\(\s*\d{1,3}\s*\)\s*$/.test(rawContent);
    let qMark = 0.5;
    let explicitMark = false;
    // T/F variant FIRST: "… morning. (0.25)    T / F" — the mark sits before
    // the True/False answer marker, so the end-anchored regex can't see it.
    // Only the (N) is removed; the T/F marker stays for type detection.
    const tfMarkMatch = rawContent.match(/\(([\d\.]+)\)\s*(?=(?:T\s*\/\s*F|True\s*\/\s*False|صحیح\s*\/\s*غلط)\s*$)/i);
    if (tfMarkMatch) {
      const parsedVal = parseFloat(tfMarkMatch[1]);
      if (!isNaN(parsedVal) && parsedVal > 0 && parsedVal <= 10) {
        qMark = parsedVal;
        explicitMark = true;
        rawContent = rawContent.replace(tfMarkMatch[0], '').trim();
      }
    }
    const markRegexSrc =
      '(?:^|\\s)(?:\\(([\\d\\./]+)\\s*(?:نمره|pts?|points?|marks?)?\\s*\\)|\\[([\\d\\./]+)\\s*\\]|([\\d\\./]+)\\s*(?:نمره|pts?|marks?))\\s*$';
    // A trailing BARE decimal GLUED to a content line ("… at the station. 0.5",
    // "…listen to music. 1") is a per-question mark cell (10th-grade
    // head-anchored family). It must share its line with text — a standalone
    // number line is the ROW's mark cell, never this question's. Bounded to
    // 2 digits so years and IDs never match.
    let bareMarkMatch: RegExpMatchArray | null = null;
    let bareMarkLineIdx = -1;
    const rawLines = rawContent.split(/\r?\n/);
    for (let ri = rawLines.length - 1; ri >= 0; ri--) {
      // The number must follow sentence punctuation or a closing paren
      // ("…music. 1", "(do) 0.5") — a word-attached number ("Page 4") is
      // content debris, never a mark.
      // A DECIMAL cell ("farm 0.5", "station. 0.5") is always a mark. An
      // INTEGER must follow sentence punctuation or a closing paren
      // ("…music. 1") — a word-attached integer ("Page 4") is content
      // debris, never a mark.
      const dec = rawLines[ri].match(/^(.*\S)\s+(\d{1,2}[.,\/]\d{1,2})\s*$/);
      const int = rawLines[ri].match(/^(.*[.!?؟…_\)])\s+(\d{1,2})\s*$/);
      // Tiny integers (1-2) strip even after a word — the common
      // per-question mark cells ("prays / ali 1"); real page numbers
      // are 3+ or follow content words loosely enough to stay safe.
      const tiny = rawLines[ri].match(/^(.*\S)\s+([12])\s*$/);
      const lm = dec || int || tiny;
      // A NUMBER-FRAGMENT prefix ("5 /", "5", the leading half of a standalone
      // bidi mark line "5 / 1") is the row's SECTION mark cell, never this
      // question's mark — the tiny/int rules used to strip its tail digit and
      // inflate the last question (radif rows 6/7: 1.5 became q21=1 + total 2).
      if (
        lm &&
        !/^\d{1,3}[-.)]/.test(lm[1].trim()) &&
        !/^\d{1,2}(\s*\/\s*\d{0,2})?\s*$/.test(lm[1].trim())
      ) {
        bareMarkMatch = lm;
        bareMarkLineIdx = ri;
        break;
      }
    }
    // "0/5" is a Persian decimal (0.5) — the slash IS the decimal point.
    const normMark = (v: string) => parseFloat(v.replace(/\s+/g, '').replace('/', '.'));
    const firstLine = rawContent.split(/\r?\n/)[0] || '';
    const firstLineIsBareSlot = /^\s*\(\s*\d{1,3}\s*\)\s*$/.test(firstLine);
    const markMatch =
      rawContent.match(new RegExp(markRegexSrc, 'i')) ||
      // Trailing noise lines ("موفق باشید") after the mark defeat the
      // end-anchored regex — retry on the question's own first line. A first
      // line that IS a bare paren number is a picture-slot question, never
      // a mark cell (p8214 sec 1 q4: "(4)" became mark 4, stem lost).
      (firstLineIsBareSlot ? null : firstLine.match(new RegExp(markRegexSrc, 'i')));
    if (!isBareParenSlot && !markMatch && bareMarkMatch) {
      const parsedVal = normMark(bareMarkMatch[2] || bareMarkMatch[3]);
      if (!isNaN(parsedVal) && parsedVal > 0 && parsedVal <= 10) {
        qMark = parsedVal;
        explicitMark = true;
        rawLines[bareMarkLineIdx] = bareMarkMatch[1].trim();
        rawContent = rawLines.join('\n').trim();
      }
    }
    if (markMatch && !isBareParenSlot) {
      const parsedVal = normMark(markMatch[1] || markMatch[2] || markMatch[3]);
      if (!isNaN(parsedVal) && parsedVal > 0 && parsedVal <= 10) {
        qMark = parsedVal;
        explicitMark = true;
        rawContent = rawContent.replace(markMatch[0], '').trim();
      }
    }

    // Question numbering normalization
    let finalNumber = rawNumber;
    let originalNumber: number | undefined = undefined;

    // Kanoon bidi lanes (R5): the radif lane cell rides IN FRONT of the stem
    // cell — "19) 7)This book can…" / "23( 11(He changed…" — and the exercise
    // number is GLUED to the stem (no space after its separator). The glued
    // inner number is the exam's real sequence (GT grades it); the spaced
    // dual form ("27. 18. …" p43266) keeps the outer number below.
    const gluedLaneMatch = rawContent.match(/^(\d{1,3})[.)(](?=[A-Za-z\u0600-\u06FF])/);
    if (gluedLaneMatch && options.normalizeNumbering) {
      const innerNum = parseInt(gluedLaneMatch[1], 10);
      if (Number.isFinite(innerNum) && innerNum > 0 && innerNum !== rawNumber) {
        originalNumber = rawNumber;
        finalNumber = innerNum;
        rawContent = rawContent.slice(gluedLaneMatch[0].length).trimStart();
        if (seed.receipt) {
          seed.receipt.alternates = [
            ...(seed.receipt.alternates || []),
            { kind: 'question_start', ruleId: 'R20', reason: `kanoon lane "${rawNumber}) ${innerNum})…" — stem-adjacent number taken` },
          ];
        }
      }
    }

    // Dual prefix: "34. 58. The teacher..."
    // ⚠ Match the first LINE only — (.*)$ silently fails on multi-line
    // content (options on their own lines), which left dual numbering
    // unresolved (golden corpus caught this).
    const dualPrefixMatch = rawContent.match(/^(\d+)[\.\)]\s+([^\n]*)/);
    // A seed renumbered from its own printed blank slot ("44………….. ( corevdis )")
    // carries the answer-slot numbering — the leading "58." is copied-in debris
    // and must not win. Same for a SMALLER second index ("27. 18. …"): the outer
    // printed number is the exam's real sequence, the inner one is debris.
    const renumbered = (seed as Seed & { __renumbered?: boolean }).__renumbered === true;
    if (dualPrefixMatch && !renumbered) {
      const secondNum = parseInt(dualPrefixMatch[1], 10);
      originalNumber = rawNumber;
      if (options.normalizeNumbering && secondNum >= rawNumber) {
        finalNumber = secondNum;
        rawContent = dualPrefixMatch[2].trim();
        if (seed.receipt) {
          seed.receipt.alternates = [
            ...(seed.receipt.alternates || []),
            { kind: 'question_start', ruleId: 'R20', reason: `dual index "${rawNumber}. ${secondNum}." — outer number treated as the true question number` },
          ];
        }
        anomalies.push({
          id: `anom-dual-${rowId}-${finalNumber}`,
          severity: 'info',
          sectionRowId: rowId,
          questionNumber: finalNumber,
          title: 'Dual Numbering Resolved',
          description: `Item originally started with dual index "${rawNumber}. ${secondNum}.". Normalized to Question ${finalNumber}.`,
          suggestedFix: `Re-indexed to ${finalNumber}.`,
          isResolved: true,
        });
      }
    }

    // --- Multiple Choice Options Extraction ---
    // Handles options on separate lines (e.g. "a)animal b)car c)book d)tree")
    // with or without spaces, Latin or Persian (الف ب ج د)
    let rawContent0 = rawContent;
    const mcqResult = extractMultipleChoiceOptions(rawContent);

    // Inline choice check: "( don't / doesn't )"
    const inlineChoiceResult = extractInlineChoices(rawContent);

    // --- Empty-seed context rescue (slot rows like "37- 38- 39- 40-") ----- 
    // The stem is the section's own pre-question content: a word list,
    // spelling bank, or instruction-adjacent exercise material.
    let rescued = false;
    if (!rawContent.trim()) {
      // A section with its own word bank already carries the candidate words —
      // rescuing the bank INTO every stem just duplicates it (picture+bank
      // sections keep honest empty stems).
      const rescue = wordBank.length >= 3 ? null : rescueContentFromPreQuestion(text);
      if (rescue) {
        rawContent = rescue;
        rescued = true;
      } else if (wordBank.length >= 3 || /عکس|تصویر|تصاویر|picture/i.test(text)) {
        // The section's word bank (or the picture) IS the content the slots
        // refer to — keep the empty stems instead of dropping the questions.
        rescued = true;
      } else {
        continue; // truly context-less — honest drop, no junk question
      }
    }

    // --- Blank-sentence stem override ----------------------------------------
    // For fill-style questions the meaningful stem is the SENTENCE carrying
    // the numbered dotted blank ("Mom: he is in the 26- ………"), not the raw
    // block which can absorb following dialogue turns. When an unscramble
    // set sits above the blank line, the scramble IS the stem.
    const blankInfo = blankSentences.get(finalNumber);
    if (blankInfo && !mcqResult && !inlineChoiceResult && !rescued) {
      rawContent = blankInfo.scramble || blankInfo.sentence;
    }

    // Type inference sees the stem WITHOUT blank-only answer lines
    // ("34- How do you spell your name?" + a dots line is a question, not
    // a fill-blank; a blank INSIDE the sentence is).
    const typeContent = rawContent
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(
        (l) =>
          l &&
          !/^[\.…_\u2013\u2014-\s]+$/.test(l) &&
          !/^[A-Z]$/.test(l) &&
          // Trailing mark cells ("1", "2.5", ".5") absorbed into the block are
          // بارم debris, never question content — they broke $-anchored type
          // rules (form cues, dash soups).
          !/^\d{1,2}(?:\.\d{1,2})?$/.test(l) &&
          !/^\.\d{1,2}$/.test(l),
      )
      .join(' ');

    let type: QuestionType = 'short_answer';
    let stem = rawContent;
    let optionsList: ExamOption[] | undefined = undefined;

    if (mcqResult) {
      // "a) True  b) False" option pairs are True/False items, not MCQs
      // (qu2 corpus: every Kanoon final prints TF with lettered options).
      const allTF =
        mcqResult.options.length >= 2 &&
        mcqResult.options.length <= 4 &&
        mcqResult.options.every((o) =>
          /^(true|false|t|f|درست|نادرست|صحیح|غلط)\b/i.test(o.text.trim().split(/\s+/)[0]));
      if (allTF) {
        type = 'true_false';
        stem = mcqResult.stem;
        optionsList = mcqResult.options;
      } else {
        type = 'multiple_choice';
        stem = mcqResult.stem;
        optionsList = mcqResult.options;
      }
    } else if (inlineChoiceResult) {
      type = 'inline_choice';
      stem = rawContent;
      optionsList = inlineChoiceResult.options;
    } else if (
      // Unscramble sets: "(you – I'm – about – fine – how – . –?)" — a
      // parenthesized dash-separated token soup above/at the blank line.
      // A set INLINE with a blank ("… in …… (as a hobby – my free time)")
      // is a fill-blank choice hint, not a sentence scramble.
      // The section's own WORD BANK is neither: a paren group whose parts
      // are exactly the bank words ("( nurse – dentist – farmer …)") is the
      // printed pool echoed into the first question's block — bank-fill,
      // not a scramble (golden corpus: mock-02 E).
      !BLANK_RUN.test(typeContent) &&
      (() => {
        const set = extractScrambleSet(rawContent);
        if (!set) return false;
        if (wordBank.length >= 3) {
          const parts = set.slice(1, -1).split(/\s*[–—-]\s*/).map((w) => w.trim()).filter(Boolean);
          const bank = wordBank.map((w) => w.trim());
          if (parts.length === bank.length && parts.every((p) => bank.includes(p))) return false;
        }
        return true;
      })()
    ) {
      type = 'unscramble';
      stem = extractScrambleSet(rawContent) as string;
    } else if (
      // Letter-reorder cells: "( p a p y h )" — a paren group whose tokens are
      // ALL single letters (with or without dots). The dotted tail is the
      // answer line (12th-grade spelling family).
      /\(\s*(?:[A-Za-z]\s+){2,}[A-Za-z]\s*\)/.test(typeContent)
    ) {
      type = 'letter_reorder';
      stem = typeContent;
    } else if (
      /\b(?:True\s*\/\s*False|True\s+or\s+False|T\s*\/\s*F)\b/i.test(rawContent) ||
      (/\bTrue\b/i.test(rawContent) && /\bFalse\b/i.test(rawContent)) ||
      /\b(?:درست\s*\/\s*نادرست|صحیح\s*\/\s*غلط)\b/.test(rawContent)
    ) {
      type = 'true_false';
      optionsList = [
        { id: 'true', text: 'True' },
        { id: 'false', text: 'False' },
      ];
    } else if (
      wordBank.length > 0 &&
      seedInBankScope(seed) &&
      BLANK_RUN.test(typeContent)
    ) {
      type = 'word_bank_fill';
    } else if (
      // Verb form in parentheses: e.g. "3. I ...... to school every day. (go)"
      // Tested on typeContent: a block tail that absorbed the next section's
      // bare letter ("… (sing)" + "H") must not defeat the end anchor.
      // LOWERCASE only, and a dotted blank must PRECEDE the cue: content cues
      // ("…? (Spain)", "(flu)", "(riding)") ride on full questions with no
      // blank; verb cues always follow the gap they fill.
      (() => {
        // Cues like "(see)" and identical pairs "(chicken / chicken)" are FORM
        // cues; differing alternatives never reach here (inline_choice matched
        // above). A dotted blank must precede the cue.
        const blankBefore = (idx: number) => /\.{3,}|…|_{3,}|-{4,}/.test(typeContent.slice(0, idx));
        const lastParen = typeContent.lastIndexOf('(');
        const fm = typeContent.match(/\(\s*([a-z]{2,12}(?:\s*\/\s*[a-z]{2,12})*)\s*\)\s*$/);
        if (fm && lastParen >= 0 && blankBefore(lastParen)) {
          const alts = fm[1].split('/').map((x) => x.trim());
          if (alts.length === 1 || alts.every((a) => a === alts[0])) return true;
        }
        // Mid-stem SINGLE-word form cue ("Ali is the……… (good) student in
        // the class.") — the cue sits right after its gap, not at the tail.
        const single = typeContent.match(/\(\s*([a-z]{2,12})\s*\)/);
        if (single && single.index !== undefined && blankBefore(single.index)) return true;
        // Adjective-order cue: hyphen-separated lowercase words in parens
        // ("I have a----------- car(red -beautiful- old)") under an ORDER
        // instruction (…ترتیب… / "correct order") — arrange, not choose
        // (real-exam 14050319 q16; inline_choice owns the slash variants).
        if (/ترتیب|correct\s+order/i.test(text)) {
          const om = typeContent.match(/\(\s*([a-z]{2,12}(?:\s*[-–—]\s*[a-z]{2,12})+)\s*\)/);
          if (om && om.index !== undefined && blankBefore(om.index)) return true;
        }
        return false;
      })()
    ) {
      type = 'form_in_parentheses';
    } else if (/mistake|error|غلط|اشتباه/i.test(rawContent) || rawContent.includes('mistake:')) {
      type = 'error_correction';
    } else if (
      // Bare inline choices without parens: "a lot of / many milk.",
      // "When / What / How fell down?" — 2-3 SHORT alpha alternatives.
      // 4+ slash parts (Kanoon sentence scrambles) and long parts stay with
      // the unscramble branch below; "True / False" already matched above.
      (() => {
        if (/مرتب|unscramble|reorder/i.test(typeContent)) return false;
        const parts = typeContent.split('/').map((p) => p.trim());
        if (parts.length < 2 || parts.length > 3) return false;
        return parts.every((p) =>
          /^[\p{L}][\p{L}'’]*(\s+[\p{L}][\p{L}'’]*){0,2}[?.!,;:]?$/u.test(p) &&
          p.replace(/[^\p{L}]/gu, '').length >= 2);
      })()
    ) {
      type = 'inline_choice';
    } else if (rawContent.includes('/') && rawContent.split('/').length >= 3) {
      type = 'unscramble';
    } else if (rawContent.includes('active:') || rawContent.includes('passive:')) {
      type = 'active_passive';
    } else if (
      // Bare dash soup: "20- its – for – it's – famous – beaches." —
        // >=4 dash-separated word groups, no blank, no option markers.
        // The tail segment may carry the trailing question mark of the
        // target sentence ("… time - ?"), so allow a trailing "- ?" run.
      !BLANK_RUN.test(typeContent) &&
      typeContent.length >= 12 &&
      !/\d/.test(typeContent) &&
      (typeContent.match(/[–—]/g) || []).length >= 3 &&
      typeContent.split(/[–—]/).every((t) => /^[A-Za-z'\u2019]+(\s+[A-Za-z'\u2019]+)*\s*[.,!?]*(?:\s*-\s*[.,!?]*)?$/.test(t.trim()))
    ) {
      type = 'unscramble';
      stem = typeContent;
    } else if (BLANK_RUN.test(typeContent)) {
      type = 'fill_blank';
    } else if (
      // First-letter dictation DNA: "hard of h - - - - - -." — the trailing
      // dash-run is often split off as option debris and filtered from
      // typeContent; the stem keeps it. Spell-in hint, not an open question.
      // Three spaced dashes already spell a word ("s - - - your work", p43266
      // row 2) — four is NOT the floor.
      /[A-Za-z]\s(?:-\s+){2,}-/.test(rawContent)
    ) {
      type = 'fill_blank';
    } else if (rawContent.endsWith('?') || /^(?:what|where|who|when|why|how|is|are|do|does|did|can|could)/i.test(rawContent)) {
      type = 'short_answer';
    }

    // Context attachment
    let parentContextType: 'word_bank' | 'cloze_passage' | 'reading_passage' | 'image_prompt' | 'dialogue_context' | 'none' = 'none';
    let parentContextTitle: string | undefined;
    let parentContextText: string | undefined;

    if (type === 'word_bank_fill' || (wordBank.length > 0 && seedInBankScope(seed) && (type === 'fill_blank' || type === 'short_answer'))) {
      type = 'word_bank_fill';
      parentContextType = 'word_bank';
      parentContextTitle = `Word Bank (${rowId})`;
      parentContextText = `Candidate Words: [${wordBank.join(', ')}]`;
    } else if (passageText && passageText.length > 20) {
      const isCloze = /cloze/i.test(passageText) || /\[\d+\]/.test(passageText);
      // R4 printed-cloze blanks: "……29….. . These people express ………30….." —
      // dot-hugged numbers are the passage's OWN fill slots; the option-group
      // rows that answer them are cloze items (2657 K, pu557 C, 265374941 L
      // GT cloze_item). The stem-less gate keeps real comprehension questions
      // (which carry a stem) multiple_choice.
      const printedCloze =
        /\.{2,}\s*\d{1,3}\s*\.{2,}/.test(passageText) || /…+\s*\d{1,3}\s*…+/.test(passageText);
      // Stance gate (R5): the printed instruction decides the genre. Sheets
      // that say CHOOSE ("Check the correct answer…" 2657 K / "گزینه صحیح را
      // انتخاب کنید" 265374941 L) grade their option-group rows cloze_item;
      // sheets that say FILL ("fill in the blanks…" 11th-first P / "جاهای
      // خالی را با کلمات مناسب داده شده کامل کنید" p43266 7) grade the very
      // same shape multiple_choice. No cue — keep multiple_choice.
      const clozeStance = (() => {
        const probe = instructionProbe ?? '';
        const choose = /check\s+the\s+correct|choose|correct\s+answer|انتخاب|گزینه/i.test(probe);
        const fill = /fill\s+in|complete|کامل|جاهای\s*خالی|جای\s*خالی/i.test(probe);
        return choose && !fill;
      })();
      if ((isCloze || printedCloze) && type === 'multiple_choice' && clozeStance) {
        type = 'cloze_item';
      }
      parentContextType = isCloze || printedCloze ? 'cloze_passage' : 'reading_passage';
      parentContextTitle = isCloze || printedCloze ? `Cloze Passage (${rowId})` : `Reading Passage (${rowId})`;
      parentContextText = passageText;
    }

    const hasImage = /تصویر|عکس|picture|image|look at the/i.test(stem);
    if (hasImage && parentContextType === 'none') {
      parentContextType = 'image_prompt';
      parentContextTitle = `Image Prompt (${rowId})`;
    }

    const typeInfo = getQuestionTypeInfo(type);

    if (stem.length < 4 && !(optionsList && optionsList.length >= 2)) {
      // Options-only rows ("10- a. spaghetti b. rice … d. bread") are
      // legitimate questions with an empty stem — no anomaly.
      anomalies.push({
        id: `anom-stem-empty-${rowId}-${finalNumber}`,
        severity: 'error',
        sectionRowId: rowId,
        questionNumber: finalNumber,
        title: 'Empty or Incomplete Question Stem',
        description: `Question ${finalNumber} has an unexpectedly short stem.`,
        suggestedFix: 'Review original document text.',
        isResolved: false,
      });
    }

    items.push({
      id: `q-${rowId}-${finalNumber}-${i}`,
      number: finalNumber,
      displayNumber: String(finalNumber),
      originalNumber,
      sectionRowId: rowId,
      sectionName: category,
      type,
      typeEnName: typeInfo.enName,
      typeFaName: typeInfo.faName,
      stem: cleanStem(stem),
      options: optionsList,
      mark: qMark,
      parentContextType,
      parentContextTitle,
      parentContextText,
      wordBankWords: wordBank.length && seedInBankScope(seed) ? [...wordBank] : undefined,
      hasImage,
      receipt: seed.receipt,
    });
    if (explicitMark) explicitMarkIds.add(`q-${rowId}-${finalNumber}-${i}`);
  }

  // Multi-group inline-choice lines (#qu2 wave 4, p8214 sec 7): "Mr (Amini /
  // amini) is a postman. He has two (childs / children)." carries TWO choice
  // groups on one printed line — each group fills its own blank (the sheet
  // numbers 1..6 ACROSS the groups). Split into one question per group and
  // renumber sequentially.
  {
    const splitItems: QuestionItem[] = [];
    let didSplit = false;
    for (const q of items) {
      if (q.type !== 'inline_choice') {
        splitItems.push(q);
        continue;
      }
      const groups = (q.stem || '').match(/\([^()]*\/[^()]*\)/g) || [];
      if (groups.length < 2) {
        splitItems.push(q);
        continue;
      }
      didSplit = true;
      groups.forEach((_g, gi) => {
        splitItems.push({ ...q, id: `${q.id}-g${gi + 1}` } as QuestionItem);
      });
    }
    if (didSplit) {
      splitItems.forEach((q, i) => {
        q.number = i + 1;
        q.displayNumber = String(i + 1);
      });
      items.length = 0;
      items.push(...splitItems);
    }
  }

  // Stamp explicit-mark flags for the section mark allocation step.
  for (const item of items) {
    if (explicitMarkIds.has(item.id)) {
      (item as QuestionItem & { __explicitMark?: boolean }).__explicitMark = true;
    }
  }

  return items;
}

/**
 * Extracts multiple choice options from a question block.
 * Supports:
 * - Options on separate lines or glued on same line
 * - Without space after marker: a)animal, b)car
 * - OCR noise in markers: c¢), c©), c)
 * - Persian options: الف), ب), ج), د)
 */
function extractMultipleChoiceOptions(
  rawContent: string,
): { options: ExamOption[]; stem: string } | null {
  // Option markers regex:
  // Matches: a), a., a-, (a), الف), ب), ج), د) — also "الف )" with the
  // space Word inserts between the Persian letter and the parenthesis.
  // Also matches OCR corrupted c¢), c©)
  const markerRegex =
    /(?:^|\s|\n)(?:([a-d])\s*[\.\)]|([a-d])[-–—]|([a-d])\s*[¢©*»>]?\)|(?:\(([a-d])\))|(الف|ب|ج|د)\s*\))\s*/gi;

  const matches = Array.from(rawContent.matchAll(markerRegex));

  if (matches.length < 2) {
    return null;
  }

  // Ensure unique option identifiers
  const ids = matches.map((m) => {
    const raw = (m[1] || m[2] || m[3] || m[4] || m[5] || '').toLowerCase();
    if (raw === 'الف') return 'a';
    if (raw === 'ب') return 'b';
    if (raw === 'ج') return 'c';
    if (raw === 'د') return 'd';
    return raw;
  });

  const uniqueIds = new Set(ids);
  if (uniqueIds.size < 2) {
    return null;
  }

  // Two-part fill rows ("32- a) I have stomachache  b) you should see a ……")
  // carry exactly two markers where an option holds the dotted blank — the
  // a)/b) halves are the task's two parts, not answer choices. Real MCQ
  // options never contain dotted blanks, so this never fires on real choices.
  if (matches.length === 2) {
    const optTexts = matches.map((m, i) => {
      const contentStart = m.index! + m[0].length;
      const nextStart = i < matches.length - 1 ? matches[i + 1].index! : rawContent.length;
      return rawContent.slice(contentStart, nextStart).trim();
    });
    const hasBlank = /[.\u2026_]{3,}/;
    if (optTexts.some((t) => hasBlank.test(t)) && optTexts.some((t) => !hasBlank.test(t))) {
      return null;
    }
  }

  const firstMatchIndex = matches[0].index!;
  const stem = rawContent.slice(0, firstMatchIndex).trim();

  const options: ExamOption[] = [];
  for (let i = 0; i < matches.length; i++) {
    const current = matches[i];
    const letter = ids[i];
    const contentStart = current.index! + current[0].length;
    const nextStart = i < matches.length - 1 ? matches[i + 1].index! : rawContent.length;
    const optionText = rawContent.slice(contentStart, nextStart).trim();

    if (optionText) {
      options.push({
        id: letter,
        text: optionText,
      });
    }
  }

  return options.length >= 2 ? { options, stem } : null;
}

/**
 * Extracts inline choices like "( don't / doesn't )"
 */
export function extractInlineChoices(text: string): { options: ExamOption[] } | null {
  // Slash parts may carry up to THREE words — "(didn't believe / were not
  // believing)" (p566 E q21) is a genuine choice pair, not an open question.
  const inlineRegex = /\(\s*([A-Za-z0-9'’\-]+(?:\s+[A-Za-z0-9'’\-]+){0,2})\s*[\/|\\]\s*([A-Za-z0-9'’\-]+(?:\s+[A-Za-z0-9'’\-]+){0,2})(?:\s*[\/|\\]\s*([A-Za-z0-9'’\-]+(?:\s+[A-Za-z0-9'’\-]+){0,2}))?\s*\)/;
  const match = text.match(inlineRegex);

  // Dash-pair variant: "( Sunday – Sundays )" — exactly two single-word
  // choices separated by an en/em dash. Three-plus dash soups
  // ("(sort – different – same)") are fill-blank choice hints, not choices.
  const dashMatch = !match
    ? text.match(/\(\s*([A-Za-z0-9'’\-]+)\s*[–—]\s*([A-Za-z0-9'’\-]+)\s*\)/)
    : null;
  const m = match || dashMatch;
  if (!m) return null;

  const choices: string[] = [m[1].trim(), m[2].trim()];
  if (match && match[3]) choices.push(match[3].trim());
  // "(chicken / chicken)" — identical alternatives are a FORM cue (write the
  // right form of one word), not a choice set; let the form rule take it.
  if (choices.length >= 2 && choices.every((c) => c === choices[0])) return null;

  const options: ExamOption[] = choices.map((c, idx) => ({
    id: String.fromCharCode(97 + idx), // 'a', 'b', 'c'
    text: c,
  }));

  return { options };
}

/**
 * Refines section category based on parsed question shapes
 */
function refineCategoryByQuestionShapes(
  questions: QuestionItem[],
  hasWordBank: boolean,
  hasPassage: boolean,
): 'Listening' | 'Vocabulary' | 'Grammar' | 'Writing' | 'Reading' | 'General' {
  if (hasPassage || questions.some((q) => q.parentContextType === 'reading_passage' || q.parentContextType === 'cloze_passage')) {
    return 'Reading';
  }
  if (hasWordBank || questions.some((q) => q.type === 'word_bank_fill')) {
    return 'Vocabulary';
  }
  if (questions.some((q) => q.type === 'unscramble' || q.type === 'combine_sentences' || q.type === 'error_correction')) {
    return 'Writing';
  }
  if (questions.some((q) => q.type === 'form_in_parentheses' || q.type === 'active_passive')) {
    return 'Grammar';
  }
  if (questions.some((q) => q.type === 'multiple_choice' || q.type === 'inline_choice')) {
    return 'Vocabulary';
  }
  return 'General';
}

/**
 * Post-parse Auto-Repair Pass:
 * - Detects gaps in question numbering (e.g. 2, 3, 4 without 1) and repairs them.
 * - Detects questions mistyped as fill_blank that actually contain options.
 * - Ensures every section mark is allocated.
 */
function postParseAutoRepair(
  sections: ExamSection[],
  anomalies: ParsingAnomaly[],
  flags: string[],
): void {
  const allQuestions = sections.flatMap((s) => s.questions);

  // 1. Check numbering sequence continuity
  const numbers = allQuestions.map((q) => Number(q.number)).filter((n) => !isNaN(n));
  if (numbers.length > 0) {
    const min = Math.min(...numbers);
    const max = Math.max(...numbers);
    const expectedCount = max - min + 1;

    if (numbers.length < expectedCount) {
      flags.push(`Question sequence gap: expected ${expectedCount} questions between ${min} and ${max}, found ${numbers.length}`);
      anomalies.push({
        id: `anom-seq-gap`,
        severity: 'warning',
        sectionRowId: 'General',
        title: 'Discontinuous Question Numbering Sequence',
        description: `Exam contains gaps in numbering between ${min} and ${max}. Often occurs in redacted or multi-column tests.`,
        suggestedFix: 'Inspect if any questions were merged into adjacent items.',
        isResolved: false,
      });
    }
  }

  // 2. Validate empty sections
  for (const s of sections) {
    if (s.questions.length === 0) {
      flags.push(`Section ${s.rowId} contains 0 questions`);
    }
  }
}

/**
 * Calculates a realistic confidence score penalizing real extraction failures:
 * - Sections with 0 questions (-15.0)
 * - Empty stems (-8.0)
 * - Undetected marks (-5.0)
 * - MCQs with missing options (-10.0)
 * - Discontinuous number sequence (-8.0)
 * - Unresolved error anomalies (-6.0)
 */
function calculateRealisticConfidenceScore(
  sections: ExamSection[],
  header: ExamHeader,
  anomalies: ParsingAnomaly[],
): number {
  let penalty = 0;

  const warningCount = anomalies.filter((a) => a.severity === 'warning' && !a.isResolved).length;
  const errorCount = anomalies.filter((a) => a.severity === 'error' && !a.isResolved).length;
  penalty += warningCount * 2.5;
  penalty += errorCount * 6.0;

  for (const s of sections) {
    // Heavy penalty for empty section
    if (s.questions.length === 0) {
      penalty += 15.0;
    }

    if (s.markTotal <= 0) {
      penalty += 5.0;
    }

    for (const q of s.questions) {
      if (q.type === 'multiple_choice' && (!q.options || q.options.length < 2)) {
        penalty += 10.0;
      }
      if (!q.stem || q.stem.trim().length < 4) {
        penalty += 8.0;
      }
    }
  }

  // Final score is honest and can drop to low numbers if broken
  const finalScore = Math.max(25, Math.min(100, Math.round((100 - penalty) * 10) / 10));
  return finalScore;
}

/**
 * Sentence-level extraction of NUMBERED DOTTED BLANKS embedded in dialogue
 * and form lines: "Mom: he is in the 26- ………". Returns number -> the
 * sentence carrying the blank (number marker stripped), plus an optional
 * unscramble set found on the line(s) directly above (E-genre: the scrambled
 * tokens live on the speaker line above the numbered answer line).
 */
function extractNumberedBlankSentences(
  text: string,
): Map<number, { sentence: string; scramble?: string }> {
  const out = new Map<number, { sentence: string; scramble?: string }>();
  const lines = text.split(/\r?\n/);
  const blankRe = /(?:^|[\s(])(\d{1,3})\s*[-–—]\s*(?:\.{2,}|_{2,}|…+|\([^)]*\))/;

  for (let li = 0; li < lines.length; li++) {
    const line = lines[li];
    // ALL blanks on the line ("... 27- … a book. 28- … your hands …").
    for (const m of Array.from(line.matchAll(new RegExp(blankRe.source, 'g')))) {
      const num = parseInt(m[1], 10);
      if (!Number.isFinite(num) || num === 0 || num > 150) continue;
      if (out.has(num)) continue;
      addBlank(num, li, line);
    }
  }
  return out;
  // inner helper (hoisted function declaration)
  function addBlank(num: number, li: number, line: string) {

    // The sentence within this line that carries THIS number's blank.
    const numRe = new RegExp(`(?:^|[\\s(])${num}\\s*[-\u2013\u2014.)]\\s*(?:\\.{2,}|_{2,}|…+|\\([^)]*\\))`);
    const sentences = line
      .split(/(?<=[.!?؟])\s+/)
      .filter((s) => numRe.test(s));
    const stripNum = (v: string) => v.replace(/^\s*\d{1,3}\s*[-–—]\s*/, '').trim();
    let sentence = stripNum(sentences[0] || line.trim());
    // A sentence split can isolate the bare "3-......" fragment; the
    // meaningful stem is then the WHOLE line (minus the number marker).
    if (!sentence || /^[\.…_\s]+$/.test(sentence)) sentence = stripNum(line);

    // Unscramble lookback: parenthesized dash-token sets on the 1-2 lines above.
    let scramble: string | undefined;
    for (let back = 1; back <= 2 && li - back >= 0; back++) {
      const cand = extractScrambleSet(lines[li - back]);
      if (cand) {
        scramble = cand;
        break;
      }
      // Slash soup without parens: "You: twisted / he / his / ankle /."
      const soup = lines[li - back].match(/[A-Za-z'\u2019]+(?:\s*\/\s*[A-Za-z'\u2019]+){2,}/);
      if (soup && (lines[li - back].match(/\//g) || []).length >= 2) {
        scramble = soup[0];
        break;
      }
    }
    out.set(num, { sentence, scramble });
  }
}

/**
 * Detects a parenthesized SCRAMBLE SET: "(you – I'm – about – fine – how – . –?)".
 * Requires >=3 dash-separated tokens inside a single paren pair. Returns the
 * full match (with parens) or null. Inline choices ("(that / this)") have no
 * dashes and never match.
 */
export function extractScrambleSet(line: string): string | null {
  const m = line.match(/\(([^()\n]{10,120})\)/);
  if (!m) return null;
  const inner = m[1];
  if (!inner.includes('\u2013') && !inner.includes('\u2014') && !inner.includes(' - ') && !inner.includes('–')) return null;
  const parts = inner.split(/\s*[–—-]\s*/).filter((t) => t.trim().length > 0);
  if (parts.length < 3) return null;
  if (!/[A-Za-z]/.test(inner)) return null;
  return m[0];
}

/**
 * Pre-question content rescue for bare slot rows ("37-  38-  39-  40-"):
 * the stem is the section's own exercise material — the last content line
 * before the first question that looks like a dash/comma-separated word list.
 */
function rescueContentFromPreQuestion(text: string): string | null {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  let candidate: string | null = null;
  const prose: string[] = [];
  for (const line of lines) {
    if (/^\s*\d{1,3}\s*[-–—.)]/.test(line)) break; // reached the slots
    // A word list: >=4 Latin segments separated by dashes or commas.
    const segs = line.split(/\s*[–—,;]\s*/).filter((s) => /^[A-Za-z'\u2019\-]{2,}$/.test(s.trim()));
    if (segs.length >= 4 && !/[\u0600-\u06FF]/.test(line)) {
      candidate = line;
    }
    // A Latin prose run (>=8 words, no blanks) also anchors slot rows: the
    // grammar-error passage the slots refer to.
    const words = line.split(/\s+/).filter(Boolean);
    const isProse =
      words.length >= 8 &&
      !/(\.{3,}|_{3,}|…)/.test(line) &&
      !/[\u0600-\u06FF]/.test(line) &&
      !/^\s*[\w'\u2019\-]{2,20}\s*:/.test(line);
    if (isProse) prose.push(line);
    else if (prose.length > 0) { /* keep last run */ }
  }
  return candidate || (prose.length ? prose.join(' ') : null);
}

/**
 * Matching column B extraction: dotted answer rows ("On Niloofar Street …..")
 * — text followed by 2+ trailing dots. Numbered lines and section furniture
 * are excluded.
 */
function extractMatchingColumnB(text: string): string[] {
  const out: string[] = [];
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) continue;
    if (/^\s*\d{1,3}\s*[-–—.)]/.test(line)) continue;
    const m = line.match(/^(.+?)\s*[.…]{3,}\s*$/);
    if (m) {
      const t = m[1].trim();
      if (t.length >= 2) out.push(t);
    }
  }
  return out;
}

/**
 * Definition-column matching layout (#qu2 wave 3): the B column is a list of
 * lettered definition rows under a solo "B" heading line —
 *   A
 *   51. I have kept a diary for twelve years.
 *   B
 *   a. to take something in, especially gradually
 *   f . When you get money quickly, …   (bidi space before the dot)
 * Returns every definition row after each solo "B" line, in order. The scan
 * stops at the next solo capital heading or the first non-lettered line, so a
 * section with several الف/ب groups contributes all of its definitions.
 */
function extractDefinitionColumn(lines: string[]): string[] {
  const out: string[] = [];
  for (let i = 0; i < lines.length; i++) {
    if (!/^\s*B\s*$/.test(lines[i])) continue;
    for (let j = i + 1; j < lines.length; j++) {
      const t = lines[j].trim();
      if (!t) continue;
      if (/^[A-Z]$/.test(t)) break; // next group's heading
      const m = t.match(/^([a-z])\s*[\.\:]\s*(\S.*)$/);
      if (!m) break;
      out.push(m[2].trim());
    }
  }
  return out;
}

/** Strips blank-only lines and collapses whitespace from a stem. */
function cleanStem(s: string): string {
  // NOTE (#qu2 wave 3): a page-furniture TRUNCATION here (cutting absorbed
  // page-break banners + repeated headers from trailing question blocks) was
  // tried for pq89w65173 q50 and REVERTED — the furniture markers also open
  // legitimate docx/scan contexts and the strict corpus collapsed to 2/30.
  // The q50 absorption fix needs a block-boundary mechanism instead.
  return s
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l && !/^[.\u2026_–—-\s]+$/.test(l) && !/^[A-Z]$/.test(l))
    // Paper tail wishes ("موفق باشید") glue onto the last question's stem.
    .filter((l) => !/^(?:موفق\s*باشید|پایان|با\s*احترام|موفق\s*باشيد)[.!?]*$/.test(l))
    .join(' ')
    .replace(/\s+/g, ' ')
    .trim();
}
