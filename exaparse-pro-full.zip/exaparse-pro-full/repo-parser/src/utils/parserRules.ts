/**
 * The Parser Rule Table (#3) — the parse path as an explicit, ranked,
 * explainable pipeline instead of implicit regex spaghetti.
 *
 * Every source line is classified by an ordered rule table. Each rule has an
 * id, a name, a target LineKind, and a `match(line, ctx) -> 0..1` confidence
 * scorer. The FIRST rule scoring >= WIN_THRESHOLD wins; every rule that scored
 * >= ALTERNATE_THRESHOLD is recorded as a rejected alternative — this is what
 * makes "Explain This Question" receipts (#10) possible.
 *
 * The classifier feeds the block segmenter, which feeds the structure builder
 * in parserEngine. Behavior-compatible with the legacy regex engine: if the
 * rule-table walk finds no questions at all, parserEngine falls back to the
 * legacy path and records `fallbackUsed` in the trace.
 */

import { LineKind } from '../types/exam';

export const WIN_THRESHOLD = 0.5;
export const ALTERNATE_THRESHOLD = 0.35;

export interface LineContext {
  index: number;
  /** Previous non-empty line (trimmed). */
  prev?: string;
  /** Next non-empty line (trimmed). */
  next?: string;
  /** Zero-based index among non-empty lines. */
  ordinal: number;
}

export interface ParserRule {
  id: string;
  name: string;
  kind: LineKind;
  /** Confidence 0..1 that this line is of `kind`. 0 = does not match. */
  match: (line: string, ctx: LineContext) => number;
}

// ---------------------------------------------------------------------------
// Shared micro-patterns
// ---------------------------------------------------------------------------

const RE = {
  /** "12." "12)" "12 -" at line start (already digit-normalized). */
  questionStart: /^\s*(\d{1,3})\s*[\.\)\-–—]\s*(?=\S|\s*$)/,
  /** a) b. c- (a) — single option marker at line start. */
  optionMarkerStart: /^\s*(?:\(?([a-d])[\.\)\-–—]\)|\(?([a-d])[\.\)\-–—]|([a-d])[\.\)\-–—]\))\s*/i,
  /** Two or more option markers anywhere in the line. */
  optionRowMulti: /(?:^|\s)[a-d][\.\)\-–—]\s*\S/i,
  /** Persian option markers الف) ب) ج) د). */
  persianOption: /(?:^|\s)(الف|ب|ج|د)\)\s*\S/,
  /** Section header: Latin letter + punctuation, or (A). */
  sectionLatin: /^\s*[|_\-~*#•]?\s*(?:\(([A-Z])\)|([A-Z])\s*[\)\.\-–—:])/,
  /** Section header: Persian letter + punctuation. */
  sectionPersian: /^\s*[|_\-~*#•]?\s*(?:\((الف|ب|پ|ت|ث|ج|چ|ح|خ|د|ذ|ر|ز|ژ|س|ش|ص|ض|ط|ظ|ع|غ|ف|ق|ک|گ|ل|م|ن|و|ه|ی)\)|([الفبپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی]{1,3})\s*[\)\.\-–—:])/,
  /** Part/بخش banners. */
  partBanner: /^\s*(?:Part|Section|بخش|قسمت)\s*([A-Z\d]+|اول|دوم|سوم|چهارم|پنجم|ششم)/i,
  /** Header field labels. */
  headerField:
    // NOTE: the trailing \b never matches after Persian letters (JS \b is
    // ASCII-\w-based), so the Persian label alternation is INERT — only the
    // English alternatives fire. Activating the Persian side (lookahead
    // instead of \b) made R05 win on repeated page headers EVERYWHERE and
    // truncated 13 strict-corpus sections; the page-furniture boundary needs
    // its own tightly-gated rule before this can go live.
    /^\s*(?:نام\s*درس|درس|نام\s*آزمون|مدت\s*آزمون|مدت\s*پاسخگویی|مدت|تاریخ\s*آزمون|تاریخ\s*امتحان|تاریخ|وقت\s*امتحان|نام\s*مدرسه|نام\s*آموزشگاه|دبیرستان|هنرستان|آموزشگاه|اداره\s*کل|اداره|مدیریت\s*آموزش|مقطع|پایه|رشته|نوبت|سال\s*تحصیلی|تعداد\s*صفحه|صفحه|Subject|Course|School|Teacher|Date|Duration|Time|Grade|Pages|District|Term)\b/i,
  /** Answer-key banners. */
  answerKey: /^\s*(?:answer\s*key|key\s*answers?|پاسخنامه|کلید\s*آزمون|کلید\s*سوالات|answers?\s*:)/i,
  /** English instruction verbs. */
  instructionEn:
    /^\s*(?:Choose|Fill\s+in|Read|Match|Write|Make|Unscramble|Complete|Listen|Answer|Look\s+at|Put|Use|Circle|Cross)\b/i,
  /** Persian instruction verbs / markers. */
  instructionFa:
    /(کلمات\s*داده\s*شده|جاهای\s*خالی|متن\s*زیر\s*را|گزینه\s*درست|با\s*کلمات|را\s*بخوانید|به\s*سوالات|دستور\s*زبان|واژگان|شنیداری|گوش\s*دهید|مرتب\s*کنید|نقش\s*های\s*نحوی)/,
  /** Page furniture / OCR junk. */
  noise:
    /^\s*(?:[-_=~*#•|·.]{3,}|page\s*\d+(?:\s*\/\s*\d+)?|صفحه\s*\d+|\d+\s*\/\s*\d+|---\s*page\s*break\s*---|ادامه\s*دارد|انتهای\s*آزمون)\s*$/i,
  /** Cloze inline marker "(2)" / "[2]" next to a blank. */
  clozeMarker: /(?:\(\s*\d{1,2}\s*\)|\[\s*\d{1,2}\s*\]).{0,40}(?:\.{3,}|_{3,}|-{3,})/,
};

function isMostlyPersian(line: string): boolean {
  const persian = (line.match(/[\u0600-\u06FF]/g) || []).length;
  const latin = (line.match(/[A-Za-z]/g) || []).length;
  return persian > 0 && persian >= latin;
}

/**
 * "25 I called ali while he-------- video game.( play)" — a question number
 * followed by a BARE SPACE (Word processors drop the dot/paren). Only lines
 * with fill DNA (a dash/dot/underscore blank run or a form-in-paren hint)
 * and an uppercase-Latin/Persian body head qualify — prose that merely starts
 * with a number ("100 p—ram---ds …" wrapped mid-sentence) must not spawn
 * phantom questions. Used by rule R21, the block segmenter's number probe and
 * the seed body stripper so all three agree on the same printed number.
 */
export const QUESTION_SPACE_START = /^\s*(\d{1,3})\s+(?=[A-Z\u0600-\u06FF])/;

/** Does this line look like an MCQ options row ("a) cat b) dog c) ...")? */
export function looksLikeOptionRow(line: string): number {
  let markers = 0;
  const latin = line.match(/(?:^|[\s,;])[a-d][\.\)\-–—]\s*\S/gi);
  if (latin) markers += latin.length;
  // "الف) x" and the spaced variant Word prints as "الف ) x".
  const persian = line.match(/(?:^|[\s,;])(الف|ب|ج|د)\s*\)\s*\S/g);
  if (persian) markers += persian.length;
  if (markers >= 3) return 0.95;
  if (markers === 2) return 0.85;
  // Single leading option marker on an otherwise short line — likely an
  // option on its own line (multiline options layout).
  if (markers === 1 && RE.optionMarkerStart.test(line) && line.replace(RE.optionMarkerStart, '').trim().length < 90) {
    return 0.7;
  }
  return 0;
}

// ---------------------------------------------------------------------------
// The rule table — ORDER MATTERS: first rule >= WIN_THRESHOLD wins.
// ---------------------------------------------------------------------------

export const RULE_TABLE: ParserRule[] = [
  {
    id: 'R00',
    name: 'Page furniture / OCR junk',
    kind: 'noise',
    match: (line) => (RE.noise.test(line) ? 0.95 : 0),
  },
  {
    id: 'R02',
    name: 'Answer-key banner',
    kind: 'answer_key',
    match: (line) => (RE.answerKey.test(line) ? 0.95 : 0),
  },
  {
    id: 'R05',
    name: 'Header field (درس/مدرسه/مدت/Date/…)',
    kind: 'header_field',
    match: (line, ctx) => {
      if (!RE.headerField.test(line)) return 0;
      // Header fields live in the top of the document; deep in the body a
      // line mentioning "مدت" is probably a question. Dampen by depth.
      const depthDamp = ctx.ordinal <= 12 ? 1 : ctx.ordinal <= 25 ? 0.55 : 0.3;
      const hasValue = /[:：]/.test(line) || line.length > 6 ? 1 : 0.75;
      return 0.92 * depthDamp * hasValue;
    },
  },
  {
    id: 'R10',
    name: 'Section header (Latin letter)',
    kind: 'section_header',
    match: (line, ctx) => {
      const m = line.match(RE.sectionLatin);
      if (!m) return 0;
      const letter = (m[1] || m[2] || '').toUpperCase();
      if (!letter || letter.length !== 1) return 0;
      // "A) animal B) car" is an options row, not a section header.
      if (looksLikeOptionRow(line) >= 0.85) return 0.05;
      // Dialogue speaker turns ("B: my aunt.") share the "letter + :" shape
      // with section headers and used to cut the question block in half,
      // orphaning its options row. A COLON-form header whose rest is a plain
      // English sentence (no instruction verb, no Persian) mid-exam is a
      // dialogue reply, not a section banner.
      const colonForm = /^[A-Z]\s*:/.test(line.trim());
      const rest = line.replace(RE.sectionLatin, '').trim();
      const looksInstructional =
        RE.instructionEn.test(rest) || RE.instructionFa.test(rest) || /\(\s*[\d\.]+\s*(marks?|نمره)?\s*\)/i.test(rest);
      if (colonForm && !looksInstructional && !/[\u0600-\u06FF]/.test(rest)) {
        return 0.05;
      }
      // Mid-question-block "X: reply" after a question/option line: dialogue.
      // looksLikeOptionRow >= 0.7 (not 0.8): a single-marker option line
      // ("A) my shirt") is a multiline-options layout — the "B) …" follower
      // is the next OPTION, not a section header (0.8 used to split it off).
      const prevIsQuestion = ctx.prev ? RE.questionStart.test(ctx.prev) || looksLikeOptionRow(ctx.prev) >= 0.7 : false;
      if (prevIsQuestion && !looksInstructional && rest.length < 90) {
        return 0.1;
      }
      // Section headers usually carry instruction text, a mark, or stand alone.
      const shortRest = rest.length <= 70;
      const nextIsQuestion = ctx.next ? RE.questionStart.test(ctx.next) : false;
      let conf = 0.55;
      if (looksInstructional) conf += 0.3;
      if (shortRest) conf += 0.1;
      if (nextIsQuestion) conf += 0.05;
      return Math.min(0.97, conf);
    },
  },
  {
    id: 'R12',
    name: 'Section header (Persian letter)',
    kind: 'section_header',
    match: (line) => {
      const m = line.match(RE.sectionPersian);
      if (!m) return 0;
      if (looksLikeOptionRow(line) >= 0.85) return 0.05;
      const letter = (m[1] || m[2] || '').trim();
      const rest = line.replace(RE.sectionPersian, '').trim();
      // A SINGLE option letter (ب/ج/د, and الف when it introduces a short bare
      // phrase) followed by no mark and no instruction keyword is almost
      // always an OPTION of a Persian-options MCQ ("الف) علی" / "ب) علی و حسن").
      const isSingleOptionLetter = /^[بجددو]$/.test(letter) || letter === 'الف';
      const hasMark = /\(\s*[\d\.]+\s*\)\s*$/.test(line);
      const hasInstruction = RE.instructionFa.test(rest) || RE.instructionEn.test(rest);
      if (isSingleOptionLetter && !hasMark && !hasInstruction && rest.length <= 25) {
        return 0.3;
      }
      const looksInstructional = RE.instructionFa.test(rest) || rest.length > 3;
      return looksInstructional ? 0.9 : 0.55;
    },
  },
  {
    // "(15)" — a bare parenthesized question number (Kanoon picture/dialogue
    // rows print stem-less slots whose stems are the printed pictures; the
    // multi-number run line is expanded to one line per slot upstream).
    id: 'R22',
    name: 'Parenthesized bare question number ((15))',
    kind: 'question_start',
    match: (line) => {
      const m = line.match(/^\(\s*(\d{1,3})\s*\)$/);
      if (!m) return 0;
      const num = parseInt(m[1], 10);
      if (!Number.isFinite(num) || num === 0 || num > 150) return 0.1;
      return 0.8;
    },
  },
  {
    // "ب ( (67) . یک پاراگراف…" — the ب) branch label of a choice block glued
    // to a parenthesized question number (bidi merges the label and the slot).
    id: 'R23',
    name: 'Choice label + parenthesized question number',
    kind: 'question_start',
    match: (line) => {
      const m = line.match(/^[\u0600-\u06FF\)\(\s]{1,4}\(\s*(\d{1,3})\s*\)\s*[\.:]?\s*\S/);
      if (!m) return 0;
      const num = parseInt(m[1], 10);
      if (!Number.isFinite(num) || num === 0 || num > 150) return 0;
      return 0.75;
    },
  },
  {
    id: 'R24',
    name: 'Slash question number (71/ Mr. Smith…)',
    kind: 'question_start',
    match: (line) => {
      // "71/ Mr. Smith looked …… (angry)" — bidi tables print the number with
      // a SOLIDUS. The lookahead demands a LETTER (Latin/Persian) or "(" after
      // the slash so bidi mark fractions ("5 / 1") and dates ("13 / 06 / 99")
      // — whose next token is a DIGIT — never spawn questions.
      const m = line.match(/^\s*(\d{1,3})\s*\/\s*(?=[A-Za-z\u0600-\u06FF(])/);
      if (!m) return 0;
      const num = parseInt(m[1], 10);
      if (!Number.isFinite(num) || num === 0 || num > 150) return 0;
      return 0.85;
    },
  },
  {
    id: 'R14',
    name: 'Part banner (Part 1 / بخش اول)',
    kind: 'section_header',
    match: (line) => (RE.partBanner.test(line) ? 0.9 : 0),
  },
  {
    // "16(This morning I …………..my homework." — bidi mirroring swaps the
    // printed ")" of the question header into "(" (kanoon RTL column order),
    // so RE.questionStart ([.\)\-–—]) never sees it and the row used to be
    // swallowed by the previous question (pw1387 E: q16-20 vanished). A
    // number followed by "(" and a LETTER/blank head is that header.
    id: 'R25',
    name: 'Mirrored-paren question header (16(This morning…)',
    kind: 'question_start',
    match: (line) => {
      // direct head: "16(This morning I …………..my homework." — kanoon qu2
      // canonicalization fuses stem AND inline options onto ONE line, whose
      // option-grid shape scores 0.95 at R30; R25 sits EARLIER in the table,
      // so matching that confidence wins the stable sort and keeps the row a
      // question.
      if (/^\s*\d{1,3}\s*\(\s*(?=[A-Za-z\u0600-\u06FF.…_])/.test(line)) {
        const num = parseInt(line.match(/^\s*(\d{1,3})\s*\(/)![1], 10);
        if (Number.isFinite(num) && num > 0 && num <= 150) return 0.95;
        return 0;
      }
      // kanoon lane-wrapped head: "23( 11(He changed…" — the lane cell rides
      // in front, the GLUED inner pair carries the real number.
      const m = line.match(/^\s*\d{1,3}\s*\(\s*(\d{1,3})\s*[()]\s*(?=[A-Za-z\u0600-\u06FF.…_])/);
      if (!m) return 0;
      const num = parseInt(m[1], 10);
      if (!Number.isFinite(num) || num === 0 || num > 150) return 0;
      return 0.85;
    },
  },
  {
    id: 'R20',
    name: 'Question number at line start',
    kind: 'question_start',
    match: (line, ctx) => {
      const m = line.match(RE.questionStart);
      if (!m) return 0;
      const num = parseInt(m[1], 10);
      if (!Number.isFinite(num) || num === 0 || num > 150) return 0.1;
      // RTL بارم column rows lead with a DECIMAL mark ("1.25  در هر سوال…",
      // "0.5  با توجه…"). The regex used to read "1." as question 1 with body
      // "25 …", spawning phantom questions AND poisoning the sequencing prior
      // for the line after (num 0 prev). A decimal lead is a marks cell.
      if (/^\s*\d{1,3}\.\d{1,2}(?:\s|$)/.test(line)) return 0.08;
      const body = line.replace(RE.questionStart, '').trim();
      // A bare number marker line ("37-", "38-") IS a question start:
      // docx spelling tables print one empty slot per line.
      if (!body) return 0.75;
      // Question bodies are sentences/fragments; numbers followed by pure
      // option-marker rows still count as question starts (stem-only line).
      let conf = 0.9;
      // Sequencing prior: within a running exam the next question is usually
      // +1. Dampen wildly-off numbers slightly when context is available.
      // (A prev of 0 is a marks cell, not a question — never sequence-damp.)
      if (ctx.prev) {
        const pm = ctx.prev.match(RE.questionStart);
        if (pm) {
          const prevNum = parseInt(pm[1], 10);
          if (Number.isFinite(prevNum) && prevNum > 0 && Math.abs(num - prevNum) > 3 && !(num === 1 && prevNum >= 10)) {
            conf -= 0.15;
          }
        }
      }
      // "1. a) b) c) d)" inline-question with options glued: still a question.
      if (looksLikeOptionRow(body) >= 0.85) conf += 0.05;
      return Math.min(0.97, conf);
    },
  },
  {
    // "25 I called ali while he-------- video game.( play)" — the exam writer
    // dropped the separator after the number. R20 cannot see it (it requires
    // [.\)-–—]), so the whole item used to be swallowed into the previous
    // question's block (real-exam 14050319: question 25 vanished into 24).
    // Fill DNA + uppercase/Persian body head keep wrapped prose out.
    id: 'R21',
    name: 'Question number with bare space separator',
    kind: 'question_start',
    match: (line, ctx) => {
      if (RE.questionStart.test(line)) return 0; // punctuated forms belong to R20
      const m = line.match(QUESTION_SPACE_START);
      if (!m) return 0;
      const num = parseInt(m[1], 10);
      if (!Number.isFinite(num) || num === 0 || num > 150) return 0;
      if (looksLikeOptionRow(line) >= 0.7) return 0; // option grids never start questions here
      const body = line.replace(QUESTION_SPACE_START, '').trim();
      // Fill DNA: a blank run (dashes/dots/underscores) or a form hint "( play)".
      if (!/[.…_\u2013\u2014-]{3,}/.test(body) && !/\(\s*[a-z]{1,12}/i.test(body)) return 0;
      let conf = 0.78;
      // Same sequencing prior as R20: a number far from the running sequence
      // is probably prose debris, not the next question.
      if (ctx.prev) {
        const pm = ctx.prev.match(RE.questionStart) || ctx.prev.match(QUESTION_SPACE_START);
        if (pm) {
          const prevNum = parseInt(pm[1], 10);
          if (Number.isFinite(prevNum) && prevNum > 0 && Math.abs(num - prevNum) > 3 && !(num === 1 && prevNum >= 10)) {
            conf = 0.3;
          }
        }
      }
      return conf;
    },
  },
  {
    id: 'R30',
    name: 'MCQ options row',
    kind: 'option_row',
    match: (line) => {
      const conf = looksLikeOptionRow(line);
      if (conf === 0) return 0;
      // "10- a. spaghetti b. rice c. quince d. bread" — a NUMBERED line whose
      // content is the options row itself. It is question 10 of an odd-one-out
      // / MCQ row, NOT the options of the previous question (it used to be
      // swallowed into the previous block and the question vanished).
      if (RE.questionStart.test(line)) return 0.2;
      return conf;
    },
  },
  {
    id: 'R40',
    name: 'Word-bank list',
    kind: 'word_bank',
    match: (line) => {
      const bracket = /\[\s*[A-Za-z][^\]\n]{8,}\]/.test(line);
      // Parenthesized pools need ≥3 '/'-separated segments: inline choices
      // ("(that / this)", "(don't / doesn't)") are TWO segments and used to
      // steal the line from R20, deleting the question.
      let paren = false;
      const parenMatch = line.match(/\(\s*([A-Za-z][^\)\n]{8,})\)/);
      if (parenMatch && line.includes('/')) {
        paren = parenMatch[1].split('/').length >= 3;
      }
      const commaList =
        !RE.questionStart.test(line) &&
        !RE.optionMarkerStart.test(line) &&
        ((line.match(/,/g) || []).length >= 3 || (line.match(/\//g) || []).length >= 3) &&
        /[A-Za-z]/.test(line) &&
        line.length < 220;
      if (bracket) return 0.9;
      if (paren) return 0.85;
      if (commaList) return 0.6;
      return 0;
    },
  },
  {
    id: 'R50',
    name: 'Instruction line',
    kind: 'instruction',
    match: (line) => {
      if (RE.instructionEn.test(line)) return 0.85;
      if (isMostlyPersian(line) && RE.instructionFa.test(line)) return 0.85;
      return 0;
    },
  },
  {
    id: 'R60',
    name: 'Passage / long prose',
    kind: 'passage',
    match: (line, ctx) => {
      const words = line.split(/\s+/).filter(Boolean).length;
      if (words < 8) return 0;
      const endsSentence = /[.!?»"]$/.test(line.trim());
      const hasMarkers =
        RE.questionStart.test(line) || looksLikeOptionRow(line) > 0.5 || RE.clozeMarker.test(line);
      if (hasMarkers) return 0.05;
      let conf = 0.4;
      if (words >= 12) conf += 0.15;
      if (endsSentence) conf += 0.15;
      // Prose follows prose (passages run multiple lines).
      if (ctx.prev && !RE.questionStart.test(ctx.prev) && ctx.prev.split(/\s+/).length >= 10) conf += 0.15;
      return Math.min(0.85, conf);
    },
  },
  {
    id: 'R90',
    name: 'Unclassified (fallback)',
    kind: 'other',
    match: () => 0.2,
  },
];

export interface LineClassification {
  lineIndex: number;
  text: string;
  kind: LineKind;
  ruleId: string;
  ruleName: string;
  confidence: number;
  /** Alternatives that also scored >= ALTERNATE_THRESHOLD but lost. */
  alternates: { ruleId: string; kind: LineKind; confidence: number }[];
}

/**
 * Classify every line of `lines` (already trimmed-of-noise by the caller? No —
 * classify RAW lines including empty ones so indices stay stable).
 */
export function classifyLines(lines: string[]): LineClassification[] {
  // Pre-compute non-empty line list for context lookups.
  const nonEmpty: { text: string; idx: number }[] = [];
  lines.forEach((l, idx) => {
    if (l.trim()) nonEmpty.push({ text: l.trim(), idx });
  });
  const ordinalOf = new Map<number, number>();
  nonEmpty.forEach((n, ordinal) => ordinalOf.set(n.idx, ordinal));

  const out: LineClassification[] = [];
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    const trimmed = raw.trim();
    if (!trimmed) {
      out.push({
        lineIndex: i,
        text: raw,
        kind: 'other',
        ruleId: 'R-BLANK',
        ruleName: 'Blank line',
        confidence: 0,
        alternates: [],
      });
      continue;
    }
    const ordinal = ordinalOf.get(i) ?? 0;
    const ctx: LineContext = {
      index: i,
      ordinal,
      prev: ordinal > 0 ? nonEmpty[ordinal - 1]?.text : undefined,
      next: ordinal < nonEmpty.length - 1 ? nonEmpty[ordinal + 1]?.text : undefined,
    };

    // NFKC-FOLDED MATCH VIEW (#qu2 wave 3) — DISABLED: folding made rules
    // fire corpus-wide on lines whose presentation forms previously never
    // matched (13 strict regressions). The folded view needs per-rule
    // re-validation before it can go live; see the pq89w65173 q50 case.
    const matchView = trimmed;

    const scored: { rule: ParserRule; confidence: number }[] = [];
    for (const rule of RULE_TABLE) {
      let confidence = 0;
      try {
        confidence = rule.match(matchView, ctx);
      } catch {
        confidence = 0; // rules must never throw
      }
      if (confidence > 0) scored.push({ rule, confidence });
    }
    scored.sort((a, b) => b.confidence - a.confidence);
    const winner = scored[0];
    if (!winner || winner.confidence < WIN_THRESHOLD) {
      out.push({
        lineIndex: i,
        text: raw,
        kind: 'other',
        ruleId: 'R90',
        ruleName: 'Unclassified (fallback)',
        confidence: winner?.confidence ?? 0,
        alternates: scored.slice(1, 4).map((s) => ({ ruleId: s.rule.id, kind: s.rule.kind, confidence: s.confidence })),
      });
      continue;
    }
    out.push({
      lineIndex: i,
      text: raw,
      kind: winner.rule.kind,
      ruleId: winner.rule.id,
      ruleName: winner.rule.name,
      confidence: Math.round(winner.confidence * 100) / 100,
      alternates: scored
        .slice(1)
        .filter((s) => s.confidence >= ALTERNATE_THRESHOLD)
        .slice(0, 3)
        .map((s) => ({ ruleId: s.rule.id, kind: s.rule.kind, confidence: s.confidence })),
    });
  }
  return out;
}

/** Aggregate rule statistics for the trace summary. */
export function summarizeRules(classifications: LineClassification[]): {
  id: string;
  name: string;
  kind: LineKind;
  hits: number;
  meanConfidence: number;
}[] {
  const stats = new Map<string, { name: string; kind: LineKind; hits: number; total: number }>();
  for (const c of classifications) {
    if (c.ruleId === 'R-BLANK') continue;
    const cur = stats.get(c.ruleId) || { name: c.ruleName, kind: c.kind, hits: 0, total: 0 };
    cur.hits++;
    cur.total += c.confidence;
    stats.set(c.ruleId, cur);
  }
  return [...stats.entries()].map(([id, s]) => ({
    id,
    name: s.name,
    kind: s.kind,
    hits: s.hits,
    meanConfidence: Math.round((s.total / s.hits) * 100) / 100,
  }));
}

/**
 * Block segmenter: walk classified lines and cut the text into question
 * blocks. A block starts at a `question_start` line and extends until the
 * next question_start / section_header / header_field / answer_key line.
 * Option rows, instructions, passages and word banks inside the span belong
 * to the block (the structure builder decides what they mean).
 */
export interface QuestionBlock {
  number: number;
  lineStart: number;
  lineEnd: number; // inclusive
  text: string;
  ruleChain: string[];
  alternates: { kind: string; ruleId: string; reason: string }[];
  minConfidence: number;
}

export function segmentQuestionBlocks(
  classifications: LineClassification[],
  opts: { stopAtOptionRowStandalone?: boolean } = {},
): QuestionBlock[] {
  const blocks: QuestionBlock[] = [];
  let current: QuestionBlock | null = null;
  // R7-B: option-row tally for the current block — an option-complete block
  // must be closed by the NEXT task's instruction banner.
  let optionRows = 0;
  const isTaskInstructionLine = (t: string) =>
    /(?:کنید|دهید|بخوانید|دهید)\s*[.]?\s*$/.test(t) ||
    /^(?:Complete|Choose|Match|Make|Answer|Read|Fill|Write|Put|Use|Unscramble|Listen|Find|Circle)\b/i.test(t);

  for (const c of classifications) {
    const trimmed = c.text.trim();
    if (!trimmed) continue;

    // R7-B: a task instruction line ENDS an option-complete block. The next
    // subtask's banner otherwise rides on the tail of the previous question
    // and its prose floods the block (pt7kkv Listening q8: the fill-task
    // banner merged the whole cloze prose into q8's option grid, which broke
    // the option attach and dropped the row). Instruction lines are dropped
    // here — the section parser owns them.
    if (current && optionRows >= 1 && isTaskInstructionLine(trimmed)) {
      blocks.push(current);
      current = null;
      optionRows = 0;
      continue;
    }

    const boundary =
      c.kind === 'question_start' || c.kind === 'section_header' || c.kind === 'header_field' || c.kind === 'answer_key';

    if (c.kind === 'question_start') {
      // Both start shapes carry the printed number: "25." (R20),
      // "25 I called…" (R21, bare space) and "(15)" (R22, parenthesized). A
      // space-form block that only R21 matched used to fall back to
      // blocks.length+1 and print a WRONG number.
      const m =
        trimmed.match(RE.questionStart) ||
        trimmed.match(QUESTION_SPACE_START) ||
        trimmed.match(/^\(\s*(\d{1,3})\s*\)$/) ||
        trimmed.match(/^[\u0600-\u06FF\)\(\s]{1,4}\(\s*(\d{1,3})\s*\)/) ||
        trimmed.match(/^\s*(\d{1,3})\s*\/\s*(?=[A-Za-z\u0600-\u06FF(])/) ||
        // R25 mirrored heads: "16(This morning…" / lane-wrapped "23( 11(He…"
        trimmed.match(/^\s*(\d{1,3})\s*\(\s*(?=[A-Za-z\u0600-\u06FF.…_])/) ||
        trimmed.match(/^\s*\d{1,3}\s*\(\s*(\d{1,3})\s*[()]\s*(?=[A-Za-z\u0600-\u06FF.…_])/);
      // RADIF LADDER INFERENCE (wave R1): a question_start line with NO
      // printed number continues the LADDER — previous block's number + 1 —
      // never a positional count. Fabricated `blocks.length + 1` used to
      // restart mid-document sections at 1 (the "got 1 want 31" signature)
      // and destroyed the printed sequence whenever a block lacked a
      // readable number (speaker-prefixed lines, bidi debris).
      const prevNumber: number | undefined = (current ?? blocks[blocks.length - 1])?.number;
      const num: number = m ? parseInt(m[1], 10) : (prevNumber ?? 0) + 1;
      if (current) blocks.push(current);
      const qm = c.alternates.length
        ? c.alternates.map((a) => ({ kind: a.kind, ruleId: a.ruleId, reason: `also matched at ${(a.confidence * 100).toFixed(0)}%` }))
        : [];
      current = {
        number: num,
        lineStart: c.lineIndex,
        lineEnd: c.lineIndex,
        text: trimmed,
        ruleChain: [`${c.ruleId}:${c.ruleName}`],
        alternates: qm,
        minConfidence: c.confidence,
      };
      optionRows = 0;
      continue;
    }

    if (boundary) {
      if (current) blocks.push(current);
      current = null;
      continue;
    }

    if (current) {
      current.text += (current.text ? '\n' : '') + trimmed;
      current.lineEnd = c.lineIndex;
      if (c.kind === 'option_row') optionRows++;
      if (!current.ruleChain.includes(`${c.ruleId}:${c.ruleName}`) && c.kind !== 'other' && c.kind !== 'noise') {
        current.ruleChain.push(`${c.ruleId}:${c.ruleName}`);
      }
      // A low-confidence option row (0.6-0.7) might be a continuation line;
      // record it as an alternate interpretation for the receipt.
      if (c.kind === 'option_row' && c.confidence < 0.8) {
        current.alternates.push({
          kind: 'continuation',
          ruleId: c.ruleId,
          reason: `option marker at ${(c.confidence * 100).toFixed(0)}% — could be prose continuation`,
        });
      }
      current.minConfidence = Math.min(current.minConfidence, c.confidence);
    }
    // Lines before the first question (instructions etc.) are dropped here —
    // handled separately by the section parser.
  }
  if (current) blocks.push(current);

  if (opts.stopAtOptionRowStandalone) {
    // Reserved for future layout variants.
  }
  return blocks;
}
