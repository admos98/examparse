import { AnswerFlowReceipt, ExamDocument, ProducedAnswer } from '../types/exam';
import { JevConfig } from '../types/settings';
import { buildVerificationSheet, buildVerifyQuestions, R1AnswerPick } from './parseVerifier';
import { bucketACandidates, classifyBucket, isHumanOnly } from './answerFlow';
import { surfaceDoc } from './surfaceFilter';
import { answerFingerprint, cacheGetMany, cachePutMany, normalizeForFingerprint } from './answerCache';

/**
 * M2 R3 — the producer-critic LAST call of the complete flow.
 *
 *   producer: the text LLM (/api/enhance-exam in `produce_short_answers`
 *             mode) writes JUST a short answer per unresolved question
 *             (bucket B free-text + bucket C image items with alts + any
 *             bucket-A straggler R1 left unanswered). Essays NEVER ride.
 *   critic:   Jev — a DIFFERENT model — checks each produced answer:
 *               - bucket A (candidate set exists): Choice over the item's OWN
 *                 options; the critic's pick IS the correction when it
 *                 disagrees with the producer.
 *               - bucket B/C (no candidate set): Choice over
 *                 {agree, disagree} — the weakest honest form, which is
 *                 exactly why the human stays the highest authority here
 *                 (bucket B/C answers are NEVER auto-accepted).
 *   agreement -> ProducedAnswer { provenance: 'jev-verified-draft' }
 *   disagreement -> AnswerMediation pair for the human (both answers shown).
 *
 * Fail-safe contract (same as parseVerifier): throw-free, never mutates the
 * document, drafts attach via attachProducedAnswer by the caller, and the
 * self-verification circularity is broken by MODEL DIVERSITY (producer ≠
 * critic), not by asking Jev to trust itself.
 */

export interface ProducerCriticResult {
  ok: boolean;
  error?: string;
  /** Cross-model-verified drafts (producer + Jev critic agree). */
  answers: Map<string, ProducedAnswer>;
  /** Disagreements awaiting human mediation: questionId -> {aiAnswer, jevAnswer?}. */
  mediations: Map<string, { aiAnswer: string; jevAnswer?: string }>;
  /** R1 picks carried through for reference (caller merges with R3 output). */
  r1Picks: Map<string, R1AnswerPick>;
  receipt: AnswerFlowReceipt;
  warnings: string[];
}

const PRODUCER_PROMPT_VERSION = 'pc1'; // bump invalidates the producer answer cache

function producerCacheKey(q: { id: string; stem: string; type: string; options?: unknown }, provider: string, model: string): string {
  const stemKey = answerFingerprint(q.type, q.stem, undefined);
  return `pf:${PRODUCER_PROMPT_VERSION}:${provider}:${model}:${stemKey}:${normalizeForFingerprint(q.id)}`;
}

export async function runProducerCritic(
  doc: ExamDocument,
  ids: string[],
  cfg: JevConfig,
  providerConfig: any,
  opts: { onProgress?: (note: string) => void } = {},
): Promise<ProducerCriticResult> {
  const warnings: string[] = [];
  const receipt: AnswerFlowReceipt = {
    ranAt: new Date().toISOString(),
    model: providerConfig?.model || cfg.model || 'unknown',
    r1Picks: 0,
    r3Produced: 0,
    r3Agreed: 0,
    r3Mediated: 0,
    cacheHits: 0,
    producerCalls: 0,
    criticCalls: 0,
    promptTokens: 0,
    completionTokens: 0,
    totalTokens: 0,
  };
  const answers = new Map<string, ProducedAnswer>();
  const mediations = new Map<string, { aiAnswer: string; jevAnswer?: string }>();
  const r1Picks = new Map<string, R1AnswerPick>();

  try {
    const flat = new Map<string, { q: any; secRowId: string }>();
    for (const sec of doc.sections) {
      for (const q of sec.questions) flat.set(q.id, { q, secRowId: sec.rowId });
    }

    // Essays are human-only, always. Ids for questions already answered are
    // skipped too (the caller's unresolvedProducerIds already ensures this).
    const targets = ids.filter((id) => {
      const entry = flat.get(id);
      if (!entry) return false;
      if (isHumanOnly(entry.q)) return false;
      if (entry.q.correctAnswer) return false;
      return true;
    });
    if (targets.length === 0) {
      return { ok: true, answers, mediations, r1Picks, receipt, warnings: ['Nothing to produce — every requested question is already answered or human-only.'] };
    }

    // ---- 1. Producer: short answers (cache pre-lookup first — 0 tokens) ----
    const providerTag = providerConfig?.provider || 'custom';
    const modelTag = providerConfig?.model || 'unknown';
    const need: any[] = [];
    const producedFromCache = new Map<string, string>();
    const cacheKeys = new Map<string, string>();
    for (const id of targets) {
      const entry = flat.get(id)!;
      const ck = producerCacheKey(entry.q, providerTag, modelTag);
      cacheKeys.set(id, ck);
      need.push(entry.q);
    }
    let cached: Map<string, any> = new Map();
    try {
      cached = await cacheGetMany([...cacheKeys.values()]);
    } catch {
      /* cache layer unavailable — produce fresh */
    }
    const toProduce: any[] = [];
    for (const q of need) {
      const ck = cacheKeys.get(q.id)!;
      const hit = cached.get(ck);
      if (hit && typeof hit.answer === 'string' && hit.answer) {
        producedFromCache.set(q.id, hit.answer);
        receipt.cacheHits++;
      } else {
        toProduce.push(q);
      }
    }

    if (toProduce.length > 0) {
      opts.onProgress?.(`Producer: asking for ${toProduce.length} short answer(s)...`);
      // The producer payload is the surface-filtered doc — the school's identity
      // is not the model's business (D4).
      const res = await fetch('/api/enhance-exam', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          exam: surfaceDoc(doc),
          providerConfig,
          mode: 'produce_short_answers',
          onlyIds: toProduce.map((q) => q.id),
        }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        warnings.push(`Producer call failed (HTTP ${res.status}): ${(err as any).error || res.statusText}.`);
      } else {
        const data = await res.json();
        receipt.producerCalls += 1;
        receipt.promptTokens += data.usage?.promptTokens || 0;
        receipt.completionTokens += data.usage?.completionTokens || 0;
        receipt.totalTokens += data.usage?.totalTokens || 0;
        if (Array.isArray(data.warnings)) warnings.push(...data.warnings);
        for (const a of data.answers || []) {
          producedFromCache.set(String(a.id), String(a.answer));
          receipt.r3Produced++;
          // Cache the produced answer for next time (never when empty).
          const ck = cacheKeys.get(String(a.id));
          if (ck) {
            cachePutMany([{ fingerprint: ck, answer: String(a.answer) }]).catch(() => undefined);
          }
        }
      }
    }

    if (producedFromCache.size === 0) {
      return { ok: false, error: warnings[0] || 'The producer returned no answers.', answers, mediations, r1Picks, receipt, warnings };
    }

    // ---- 2. Critic: Jev checks every produced answer (independent model) ----
    opts.onProgress?.(`Critic: Jev is checking ${producedFromCache.size} produced answer(s)...`);
    const build = buildVerificationSheet(doc); // alts ride automatically
    const criticItems: { item: any; sec: any }[] = [];
    const indexOf = new Map<string, { item: any; sec: any }>();
    for (const sec of build.sheet.sections) {
      for (const item of sec.questions) {
        indexOf.set(item.id, { item, sec });
      }
    }
    for (const [id, aiAnswer] of producedFromCache) {
      const found = indexOf.get(id);
      if (!found) continue;
      criticItems.push(found);
      // Stash the producer answer for the criteria build below.
      (found.item as any).__producerAnswer = aiAnswer;
    }

    const chunkSize = Math.max(1, cfg.batchSize || 20);
    const criticAnswers: Record<string, any> = {};
    const chunks: typeof criticItems[] = [];
    for (let i = 0; i < criticItems.length; i += chunkSize) chunks.push(criticItems.slice(i, i + chunkSize));

    for (const chunk of chunks) {
      const questions: Record<string, any> = {};
      for (const { item } of chunk) {
        const aiAnswer = String((item as any).__producerAnswer || '');
        const cands = item.candidates && Object.keys(item.candidates).length > 0 ? item.candidates : null;
        if (cands) {
          // Bucket A: the critic picks the correct option itself. Disagreement
          // with the producer IS the correction (formatted right answer).
          questions[`v:${item.id}`] = {
            type: 'choice',
            instructions:
              `id="v:${item.id}". An AI system answered item "${item.id}" with "${aiAnswer.slice(0, 80)}". ` +
              `Read the item's raw line(s) in the source text and choose the option that is ACTUALLY correct. ` +
              `Allowed option keys: ${Object.keys(cands).join('/')}.`,
            criteria: cands,
          };
        } else {
          // Bucket B/C: no candidate set exists — honest agree/disagree Choice.
          questions[`v:${item.id}`] = {
            type: 'choice',
            instructions:
              `id="v:${item.id}". An AI system answered item "${item.id}" with "${aiAnswer.slice(0, 120)}". ` +
              `Read the item's raw line(s) in the source text${item.parentContext ? ' and its attached context' : ''}` +
              `${item.imageCaption ? ' and the image content given in its metadata' : ''}. ` +
              `Is that answer correct? Reply "agree" or "disagree".`,
            criteria: { agree: 'The produced answer is correct.', disagree: 'The produced answer is wrong or unsupported.' },
          };
        }
      }

      try {
        const res = await fetch('/api/judge', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            state: { exam: build.header, sheet: build.sheet, source: build.source },
            questions,
            jevConfig: { enabled: cfg.enabled, baseUrl: cfg.baseUrl, apiKey: cfg.apiKey, model: cfg.model },
            providerConfig: cfg.enabled ? undefined : providerConfig,
          }),
        });
        if (!res.ok) {
          const err = await res.json().catch(() => ({}));
          warnings.push(`Critic call failed (HTTP ${res.status}): ${(err as any).error || res.statusText}. Produced answers stay UNVERIFIED drafts.`);
          continue;
        }
        const data = await res.json();
        receipt.criticCalls += 1;
        receipt.promptTokens += data.usage?.promptTokens || 0;
        receipt.completionTokens += data.usage?.completionTokens || 0;
        receipt.totalTokens += data.usage?.totalTokens || 0;
        Object.assign(criticAnswers, data.answers || {});
      } catch (e: any) {
        warnings.push(`Critic call failed: ${e?.message || e}. Produced answers stay UNVERIFIED drafts.`);
      }
    }

    // ---- 3. Verdicts per the agreed decision table ----
    const now = new Date().toISOString();
    for (const [id, aiAnswer] of producedFromCache) {
      const found = indexOf.get(id);
      const verdict = criticAnswers[`v:${id}`];
      const bucket = found ? classifyBucket(flat.get(id)!.q) : 'B';
      if (!verdict || verdict.invalid) {
        // No critic verdict = UNVERIFIED draft (fail-safe: never grant trust
        // from silence).
        answers.set(id, {
          value: aiAnswer,
          source: 'r3',
          provenance: 'ai-draft',
          jevVerified: false,
          producedAt: now,
          model: modelTag,
        });
        mediations.set(id, { aiAnswer, jevAnswer: undefined });
        receipt.r3Mediated++;
        continue;
      }
      const choice = String(verdict.choice || '').trim().toLowerCase();
      if (bucket === 'A') {
        const cands = found!.item.candidates as Record<string, string>;
        const keys = Object.keys(cands);
        const pick = keys.find((k) => k.toLowerCase() === choice);
        if (pick) {
          const criticValue = cands[pick];
          // The producer may answer with the option KEY ('b') or the VALUE
          // ('goes') — normalize both to a key before comparing.
          const ans = aiAnswer.trim().toLowerCase();
          const producerPick =
            keys.find((k) => k.toLowerCase() === ans) ||
            keys.find((k) => cands[k].toLowerCase() === ans);
          if (producerPick && producerPick === pick) {
            // Producer picked the same option Jev would — cross-model agree.
            answers.set(id, { value: criticValue, source: 'r3', provenance: 'jev-verified-draft', jevVerified: true, producedAt: now, model: modelTag });
            receipt.r3Agreed++;
            r1Picks.set(id, { questionId: id, key: pick, value: criticValue, confidence: verdict.confidence });
          } else {
            // Correction exists (the critic's pick) — BOTH answers go to the human.
            mediations.set(id, { aiAnswer, jevAnswer: criticValue });
            answers.set(id, { value: aiAnswer, source: 'r3', provenance: 'ai-draft', jevVerified: false, producedAt: now, model: modelTag });
            receipt.r3Mediated++;
          }
        } else {
          answers.set(id, { value: aiAnswer, source: 'r3', provenance: 'ai-draft', jevVerified: false, producedAt: now, model: modelTag });
          mediations.set(id, { aiAnswer, jevAnswer: undefined });
          receipt.r3Mediated++;
        }
      } else {
        if (choice === 'agree') {
          answers.set(id, { value: aiAnswer, source: 'r3', provenance: 'jev-verified-draft', jevVerified: true, producedAt: now, model: modelTag });
          receipt.r3Agreed++;
        } else if (choice === 'disagree') {
          mediations.set(id, { aiAnswer, jevAnswer: undefined });
          answers.set(id, { value: aiAnswer, source: 'r3', provenance: 'ai-draft', jevVerified: false, producedAt: now, model: modelTag });
          receipt.r3Mediated++;
        } else {
          answers.set(id, { value: aiAnswer, source: 'r3', provenance: 'ai-draft', jevVerified: false, producedAt: now, model: modelTag });
          mediations.set(id, { aiAnswer, jevAnswer: undefined });
          receipt.r3Mediated++;
        }
      }
    }

    return { ok: true, answers, mediations, r1Picks, receipt, warnings };
  } catch (e: any) {
    return {
      ok: false,
      error: e?.message || 'Unexpected failure during producer-critic.',
      answers,
      mediations,
      r1Picks,
      receipt,
      warnings,
    };
  }
}

// Re-export for the caller's convenience: bucket-A candidate lookup is needed
// by the review UI to render the mediation options.
export { bucketACandidates };
