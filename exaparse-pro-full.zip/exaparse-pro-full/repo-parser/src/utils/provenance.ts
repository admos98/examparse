import { ExamDocument, ProvenanceRef } from '../types/exam';
import { LayoutLine } from './fileExtractor';
import { normalizeForFingerprint } from './answerCache';

/**
 * Evidence-linked parsing: attach physical provenance to every question.
 *
 * Each question stem is fuzzy-matched back to its source LayoutLine, giving
 * the question a page number, a source rectangle (bbox), the extraction mode
 * and the mean OCR confidence. Hover any parsed question -> see the exact
 * pixels it came from. Trust = visible receipts.
 */

const KEY_LEN = 60;

function lineKey(text: string): string {
  // Strip leading question numbers / section markers so "12. The sun ..." can
  // match a stem stored as "The sun ...".
  return normalizeForFingerprint(text.replace(/^\s*(?:\d{1,3}|[A-Z\u0627-\u0644]{1,4})\s*[\.\)\-–—:]\s*/i, '')).slice(0, KEY_LEN);
}

function stemKey(stem: string): string {
  return normalizeForFingerprint(stem).slice(0, KEY_LEN);
}

function overlap(a: string, b: string): number {
  if (!a || !b) return 0;
  if (a === b) return 1;
  const sa = a.split(' ');
  const sb = new Set(b.split(' '));
  let inter = 0;
  for (const t of sa) if (sb.has(t)) inter++;
  return inter / Math.max(sa.length, sb.size);
}

export interface ProvenanceAttachment {
  coverage: number; // % of questions carrying provenance
  matched: number;
  total: number;
}

export function attachProvenance(doc: ExamDocument, lines: LayoutLine[]): ProvenanceAttachment {
  if (!lines || lines.length === 0) {
    return { coverage: 0, matched: 0, total: countQuestions(doc) };
  }

  // Pre-index lines for fast lookup.
  const exact = new Map<string, LayoutLine>();
  const all: { line: LayoutLine; key: string }[] = [];
  for (const line of lines) {
    const key = lineKey(line.text);
    all.push({ line, key });
    if (key && !exact.has(key)) exact.set(key, line);
  }

  const sourceType = detectSourceType(lines);
  let matchedCount = 0;
  let total = 0;

  for (const sec of doc.sections) {
    for (const q of sec.questions) {
      total++;
      const key = stemKey(q.stem || '');
      if (!key) continue;

      // 1) exact stem-key hit; 2) best fuzzy overlap within a window
      let hit: LayoutLine | undefined = exact.get(key);
      if (!hit) {
        let bestScore = 0;
        for (const { line, key: lKey } of all) {
          if (!lKey) continue;
          const score = overlap(key, lKey);
          if (score > bestScore) {
            bestScore = score;
            hit = line;
          }
          if (bestScore === 1) break;
        }
        if (bestScore < 0.55) hit = undefined;
      }

      if (hit) {
        matchedCount++;
        const prov: ProvenanceRef = {
          source: sourceType,
          page: hit.page,
          bbox: hit.bbox,
          coordSpace: hit.coordSpace,
          pageHeight: hit.pageHeight,
          pageWidth: hit.pageWidth,
          ocrConfidence: hit.confidence,
        };
        // Enhance with the union box of the option lines that follow the stem
        // (when they are separate lines) — gives a fuller highlight region.
        const optLineIdx = hit.lineIndex;
        const following = lines.slice(optLineIdx + 1, optLineIdx + 4);
        let bbox = hit.bbox;
        for (const f of following) {
          if (!f.bbox || f.page !== hit.page) continue;
          if (!bbox) {
            bbox = f.bbox;
            continue;
          }
          const x = Math.min(bbox.x, f.bbox.x);
          const y = Math.min(bbox.y, f.bbox.y);
          const x1 = Math.max(bbox.x + bbox.w, f.bbox.x + f.bbox.w);
          const y1 = Math.max(bbox.y + bbox.h, f.bbox.y + f.bbox.h);
          bbox = { x, y, w: x1 - x, h: y1 - y };
        }
        q.provenance = { ...prov, bbox };
      }
    }
  }

  doc.provenanceCoverage = total > 0 ? Math.round((matchedCount / total) * 1000) / 10 : 0;
  return { coverage: doc.provenanceCoverage, matched: matchedCount, total };
}

function countQuestions(doc: ExamDocument): number {
  return doc.sections.reduce((s, sec) => s + sec.questions.length, 0);
}

function detectSourceType(lines: LayoutLine[]): ProvenanceRef['source'] {
  if (lines.length === 0) return 'text';
  const first = lines[0];
  if (first.coordSpace === 'pdf') return 'pdf_text';
  if (first.bbox) return 'ocr';
  return 'text';
}
