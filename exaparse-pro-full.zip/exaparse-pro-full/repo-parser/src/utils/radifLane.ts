/**
 * radifLane.ts — the radif (row-number) lane extractor + post-hoc numbering
 * layer. Wave R1 of the numbering-doctrine fix (user charter):
 *
 *   "the app dont use the number of question for finding it and numbers would
 *    become a secondary tool for being more confident"
 *
 * The ONLY numbers the pipeline trusts are the printed row numbers (ردیف) —
 * and only after they prove themselves as a LANE: a geometrically aligned
 * band whose values march in a near-monotonic sequence across the document.
 * One number on one line is noise; a monotonic column of numbers along one
 * edge is printed structure. Everything else numeric in the text stream
 * (question numbers fused into content, option values, math operands) never
 * drives a structural decision.
 *
 * Roles the lane plays inside the single pipeline:
 *   1. GATE  — standalone numbers may open sections only when they are cells
 *              of a verified column lane (layoutBrain site A). Strays never.
 *   2. JUDGE — after segmentation the lane is read as a whole: scheme
 *              inference (per-section restart vs continuous), skip /
 *              regression / duplicate receipts, and printed-wins identity
 *              fill. A skip with no boundary evidence and an oversized gap
 *              flags a suspected merge (re-segmentation advised).
 *
 * Robust workarounds for the doctrine's limits (all deliberate):
 *   - no lane found         -> status 'none': the legacy ladder rules stay
 *                              active unchanged (fail-safe, chartered), and
 *                              the numbering layer reports 'none'.
 *   - two-column pages      -> a vertical gutter detection splits lane
 *                              candidates per half; reading order (RTL first)
 *                              orders cells before sequence scoring.
 *   - sub-numbering         -> "1-1" compounds and decimals never enter a
 *                              lane (they stay content).
 *   - MCQ numeric options   -> option columns (values resetting every few
 *                              cells, never exceeding a small max) are
 *                              rejected by sequence shape, not by position.
 *   - teacher skip vs merge -> skips are receipted with distinct codes:
 *                              skip-printed (a printed boundary sits between
 *                              the two cells), skip-suspect-merge (oversized
 *                              gap, no boundary), skip-unexplained.
 */

import type { BrainDoc, BrainLine } from './layoutBrain';
import { toLatinDigits } from './layoutBrain';

// -------------------------------------------------------------------- types

export interface RadifCell {
  page: number; // 0-based
  y: number; // y center
  num: number;
  side: 'L' | 'R'; // page half when two-column; 'R' otherwise
  kind: 'standalone' | 'fused';
  line: BrainLine;
}

export interface RadifLane {
  cells: RadifCell[];
  kind: 'column' | 'leading';
  edge: 'left' | 'right';
  xBand: [number, number]; // absolute page coords of the band
  quality: number; // 0..1 sequence quality
  monotonicRun: number; // longest strict +1 run
  pagesCovered: number;
}

export type RadifScheme = 'continuous' | 'perSection' | 'unknown';

export interface RadifSkipReceipt {
  code:
    | 'skip-printed'
    | 'skip-suspect-merge'
    | 'skip-unexplained'
    | 'radif-regression'
    | 'radif-duplicate';
  afterNum: number;
  nextNum: number;
  page: number; // 0-based page of the break
  sectionIndex: number;
  detail: string;
}

export interface RadifNumbering {
  status: 'column' | 'leading' | 'none';
  scheme: RadifScheme;
  twoColumn: boolean;
  skips: RadifSkipReceipt[];
  notes: string[];
}

export interface RadifAnalysis {
  lanes: RadifLane[];
  status: RadifNumbering['status'];
  scheme: RadifScheme;
  twoColumn: boolean;
  rtl: boolean;
  /** page -> gutter x for two-column docs (empty when single-column). */
  gutters: Map<number, number>;
  /** standalone cells of qualifying COLUMN lanes — these (and only these)
   *  may open sections (layoutBrain site A). */
  columnCellLines: Set<BrainLine>;
  /** every line whose number is lane-backed (any qualifying lane). */
  laneCellLines: Set<BrainLine>;
  cellsByLine: Map<BrainLine, RadifCell>;
  /** The cells the numbering layer judges: all lanes of the dominant kind
   *  (column lanes when any exist, else leading lanes), merged in reading
   *  order — two-column halves flow as one continuous sequence. */
  numberingCells: RadifCell[];
  /** EVERY standalone digit line (lane member or not, marks excluded) — the
   *  full population that must pass the section-opener gate so strays are
   *  receipted, never silently ignored. */
  standaloneCells: RadifCell[];
  notes: string[];
}

// ------------------------------------------------------------- text shapes

const STANDALONE_RE = /^\(?\d{1,3}[\).\-:،]?$/; // "12" / "12." / "(3)" / "۷:"
const COMPOUND_RE = /^\(?\d{1,3}\s*[-–—]\s*\d{1,3}[\).\-:،]?$/; // "1-1" sub-number
const DECIMAL_RE = /^\d{1,3}\.\d/; // "1.5" — a mark, never a row number
const FUSED_RE = /^\(?\d{1,3}[\).\-:،]?\s+\S/; // "6 برای کلمات" / "12) Choose"

function leadingCompoundOrDecimal(t: string): boolean {
  const m = t.match(/^\(?\d{1,3}(?:\.\d+)?(?:\s*[-–—]\s*\d{1,3})?[\).\-:،]?/);
  if (!m) return false;
  const tok = m[0];
  return COMPOUND_RE.test(tok.trim()) || DECIMAL_RE.test(tok);
}

// ------------------------------------------------------------ gutter / rtl

export interface TwoColumnInfo {
  twoColumn: boolean;
  gutters: Map<number, number>; // page -> gutter x (absolute)
  rtl: boolean;
}

/** Vertical gutter detection: a zero-crossing x-run in the middle third that
 *  splits the page into two genuinely used halves. Conservative by design —
 *  a missed gutter degrades to single-column (still correct for lanes that
 *  hug one edge), a fabricated one would scramble reading order. */
export function detectTwoColumn(doc: BrainDoc): TwoColumnInfo {
  const gutters = new Map<number, number>();
  let contentPages = 0;
  let persianLines = 0;
  let letteredLines = 0;
  for (const [pi, p] of doc.pages.entries()) {
    const lines = p.lines.filter((l) => l.text.trim());
    if (!lines.length) continue;
    contentPages++;
    for (const l of lines) {
      if (/[\u0600-\u06FF]/.test(l.text)) persianLines++;
      else if (/[A-Za-z]/.test(l.text)) letteredLines++;
    }
    // grid scan, 4pt steps across the middle third
    let bestRun: [number, number] | null = null;
    let runStart: number | null = null;
    const scan = (x: number): number =>
      lines.filter((l) => l.bbox[0] < x - 3 && l.bbox[2] > x + 3).length;
    for (let xr = 0.32; xr <= 0.68; xr += 0.008) {
      const x = xr * p.width;
      if (scan(x) === 0) {
        if (runStart === null) runStart = x;
      } else {
        if (runStart !== null && (bestRun === null || x - runStart > bestRun[1] - bestRun[0]))
          bestRun = [runStart, x];
        runStart = null;
      }
    }
    if (runStart !== null) {
      const xEnd = 0.68 * p.width;
      if (bestRun === null || xEnd - runStart > bestRun[1] - bestRun[0]) bestRun = [runStart, xEnd];
    }
    if (!bestRun || bestRun[1] - bestRun[0] < 0.04 * p.width) continue;
    const gx = (bestRun[0] + bestRun[1]) / 2;
    const leftLines = lines.filter((l) => (l.bbox[0] + l.bbox[2]) / 2 < gx).length;
    const rightLines = lines.length - leftLines;
    // both halves must be genuinely used — otherwise it is just a wide margin
    if (leftLines < Math.max(3, 0.2 * lines.length) || rightLines < Math.max(3, 0.2 * lines.length))
      continue;
    gutters.set(pi, gx);
  }
  const twoColumn = contentPages > 0 && gutters.size >= Math.max(1, Math.ceil(contentPages / 2));
  return { twoColumn, gutters, rtl: persianLines >= letteredLines };
}

// -------------------------------------------------------------- extraction

interface Cluster {
  cells: RadifCell[];
  relXs: number[];
}

const sideRank = (rtl: boolean) => (c: RadifCell) => (c.side === (rtl ? 'R' : 'L') ? 0 : 1);

function sequenceQuality(vals: number[]): { quality: number; monotonicRun: number; runs: number[] } {
  if (vals.length < 2) return { quality: vals.length ? 0.5 : 0, monotonicRun: vals.length, runs: vals };
  let good = 0;
  let dup = 0;
  let regress = 0;
  let bigJump = 0;
  let run = 1;
  let bestRun = 1;
  const runs: number[] = [];
  for (let i = 1; i < vals.length; i++) {
    const d = vals[i] - vals[i - 1];
    if (d === 1) {
      good += 1;
      run++;
      bestRun = Math.max(bestRun, run);
    } else if (d >= 2 && d <= 3) {
      good += 0.5; // forward skip: plausible (printed skip or a missed row)
      run = 1;
    } else if (d === 0) {
      dup += 1;
      run = 1;
      runs.push(vals[i - 1]);
    } else if (vals[i] <= 2 && d < 0) {
      good += 0.7; // section restart: legitimate (per-section numbering)
      run = 1;
      runs.push(vals[i - 1]);
    } else if (d < 0) {
      regress += 1;
      run = 1;
      runs.push(vals[i - 1]);
    } else {
      bigJump += 1; // d > 3 upward
      run = 1;
    }
  }
  runs.push(vals[vals.length - 1]);
  const quality = Math.max(
    0,
    Math.min(1, good / (vals.length - 1) - 0.15 * dup - 0.25 * regress - 0.1 * bigJump)
  );
  return { quality, monotonicRun: bestRun, runs };
}

/** Numeric option column rejection: option values reset every few cells and
 *  never reach a substantial number ("1,2,3,4  1,2,3,4  ..."). */
function looksLikeOptionColumn(vals: number[]): boolean {
  if (vals.length < 6) return false;
  const { runs } = sequenceQuality(vals);
  // runs are cut at every reset; option columns cut often and stay small
  const cuts = runs.length - 1;
  if (cuts < 2) return false;
  const lens: number[] = [];
  let cur = 1;
  for (let i = 1; i < vals.length; i++) {
    if (vals[i] <= vals[i - 1]) {
      lens.push(cur);
      cur = 1;
    } else cur++;
  }
  lens.push(cur);
  const sorted = [...lens].sort((a, b) => a - b);
  const median = sorted[Math.floor(sorted.length / 2)];
  return Math.max(...vals) <= 6 && median <= 5;
}

/**
 * Extract radif lanes from the whole document. `markLines` are lines claimed
 * as بارم marks by perception — they never become lane cells (a marks column
 * must never masquerade as row numbers; the degenerate "every row worth its
 * index" sheet is ambiguous even to a human, and marks keep their role).
 */
export function analyzeRadifLanes(
  doc: BrainDoc,
  opts: { markLines: Set<BrainLine>; optionLines?: Set<BrainLine> }
): RadifAnalysis {
  const notes: string[] = [];
  const { twoColumn, gutters, rtl } = detectTwoColumn(doc);

  // ---- candidates
  const candidates: RadifCell[] = [];
  for (const [pi, p] of doc.pages.entries()) {
    const h = p.height;
    const gx = gutters.get(pi);
    for (const l of p.lines) {
      const t = toLatinDigits(l.text.trim());
      if (!t) continue;
      const yc = (l.bbox[1] + l.bbox[3]) / 2;
      if (yc < 0.06 * h || yc > 0.94 * h) continue; // margins: furniture zone
      if (opts.markLines.has(l)) continue;
      if (opts.optionLines?.has(l)) continue;
      const side: 'L' | 'R' = gx !== undefined && (l.bbox[0] + l.bbox[2]) / 2 < gx ? 'L' : 'R';
      let num: number | undefined;
      let kind: 'standalone' | 'fused' | undefined;
      if (STANDALONE_RE.test(t)) {
        const v = parseInt(t.replace(/\D/g, ''), 10);
        if (v >= 1 && v <= 99) {
          num = v;
          kind = 'standalone';
        }
      } else if (FUSED_RE.test(t) && !leadingCompoundOrDecimal(t)) {
        const v = parseInt(t.match(/^\(?(\d{1,3})/)![1], 10);
        if (v >= 1 && v <= 99) {
          num = v;
          kind = 'fused';
        }
      }
      if (num === undefined || kind === undefined) continue;
      candidates.push({ page: pi, y: yc, num, side, kind, line: l });
    }
  }
  if (!candidates.length) {
    notes.push('radif lane: no candidate row-number lines (status none — legacy ladder rules stay active)');
    return {
      lanes: [],
      status: 'none',
      scheme: 'unknown',
      twoColumn,
      rtl,
      gutters,
      columnCellLines: new Set(),
      laneCellLines: new Set(),
      cellsByLine: new Map(),
      numberingCells: [],
      standaloneCells: candidates.filter((c) => c.kind === 'standalone'),
      notes,
    };
  }

  // ---- clustering: standalone cells anchor at their x center; fused cells at
  // BOTH edges (a radif number sits at the line's start edge, but storage
  // order/direction can flip which geometric edge that is — sequence quality
  // decides, never a guess).
  const clusters: Cluster[] = [];
  const tryCluster = (cells: RadifCell[], anchor: (l: BrainLine) => number) => {
    if (cells.length < 4) return;
    const widthOf = new Map<number, number>();
    for (const p of doc.pages) widthOf.set(doc.pages.indexOf(p), p.width);
    const ann = cells
      .map((c) => ({ c, rel: anchor(c.line) / (widthOf.get(c.page) ?? 595) }))
      .sort((a, b) => a.rel - b.rel);
    const tol = 0.035;
    let cur: { c: RadifCell; rel: number }[] = [];
    const flush = () => {
      if (cur.length >= 4) clusters.push({ cells: cur.map((x) => x.c), relXs: cur.map((x) => x.rel) });
      cur = [];
    };
    for (const x of ann) {
      if (cur.length && x.rel - cur[cur.length - 1].rel > tol) flush();
      cur.push(x);
    }
    flush();
  };

  const bySide = (side: 'L' | 'R') => candidates.filter((c) => c.side === side);
  for (const side of ['L', 'R'] as const) {
    const pool = bySide(side);
    const standalone = pool.filter((c) => c.kind === 'standalone');
    const fused = pool.filter((c) => c.kind === 'fused');
    tryCluster(standalone, (l) => (l.bbox[0] + l.bbox[2]) / 2);
    if (fused.length >= 4) {
      tryCluster(fused, (l) => l.bbox[2]); // start edge under RTL storage
      tryCluster(fused, (l) => l.bbox[0]); // start edge under LTR storage
    }
  }

  // ---- score clusters into lane candidates
  interface ScoredLane extends RadifLane {
    key: string;
  }
  const scored: ScoredLane[] = [];
  for (const cl of clusters) {
    const cells = [...cl.cells].sort((a, b) => a.page - b.page || sideRank(rtl)(a) - sideRank(rtl)(b) || a.y - b.y);
    const vals = cells.map((c) => c.num);
    const width = doc.pages[0]?.width ?? 595;
    const meanRel = cl.relXs.reduce((s, x) => s + x, 0) / cl.relXs.length;
    const standaloneFrac = cells.filter((c) => c.kind === 'standalone').length / cells.length;
    // option-column rejection applies to clusters INSIDE the content area;
    // a standalone column hugging a far page edge is the radif's natural
    // home — per-section restarts there are numbering, not MCQ options
    const farEdge = meanRel <= 0.15 || meanRel >= 0.85;
    if (looksLikeOptionColumn(vals) && !(farEdge && standaloneFrac >= 0.5)) {
      notes.push(
        `radif lane: rejected a numeric option column (${vals.slice(0, 8).join(',')}...) — values reset every few cells`
      );
      continue;
    }
    const { quality, monotonicRun } = sequenceQuality(vals);
    if (quality < 0.7) continue;
    const xs = cl.relXs;
    const pagesCovered = new Set(cells.map((c) => c.page)).size;
    scored.push({
      key: `${cl.relXs[0].toFixed(2)}|${cells[0].page}`,
      cells,
      kind: standaloneFrac >= 0.5 ? 'column' : 'leading',
      edge: (xs.reduce((s, x) => s + x, 0) / xs.length) < 0.5 ? 'left' : 'right',
      xBand: [Math.round(Math.min(...xs) * width), Math.round(Math.max(...xs) * width)],
      quality: Math.round(quality * 100) / 100,
      monotonicRun,
      pagesCovered,
    });
  }

  // ---- dedupe overlapping lane candidates (same cells seen from two anchor
  // edges): keep the higher-quality one per overlapping group.
  scored.sort((a, b) => b.quality * b.cells.length - a.quality * a.cells.length);
  const kept: ScoredLane[] = [];
  for (const lane of scored) {
    const set = new Set(lane.cells.map((c) => c.line));
    const overlap = kept.some((k) => {
      const inter = k.cells.filter((c) => set.has(c.line)).length;
      return inter / Math.min(k.cells.length, lane.cells.length) > 0.5;
    });
    if (!overlap) kept.push(lane);
  }

  const lanes: RadifLane[] = kept.map(({ key, ...lane }) => lane);
  const status: RadifNumbering['status'] = lanes.some((l) => l.kind === 'column')
    ? 'column'
    : lanes.length
    ? 'leading'
    : 'none';
  for (const lane of lanes)
    notes.push(
      `radif lane: ${lane.kind} @${lane.edge} edge x=${lane.xBand[0]}-${lane.xBand[1]}, ${lane.cells.length} cells q=${lane.quality} run=${lane.monotonicRun} pages=${lane.pagesCovered}`
    );
  if (twoColumn) notes.push(`radif lane: two-column layout detected (${gutters.size} page gutter(s)) — cells paired per half`);
  if (status === 'none' && candidates.length)
    notes.push('radif lane: candidates exist but no band reached lane quality (status none — legacy ladder rules stay active)');

  const columnCellLines = new Set<BrainLine>();
  const laneCellLines = new Set<BrainLine>();
  const cellsByLine = new Map<BrainLine, RadifCell>();
  for (const lane of lanes)
    for (const c of lane.cells) {
      laneCellLines.add(c.line);
      cellsByLine.set(c.line, c);
      if (lane.kind === 'column' && c.kind === 'standalone') columnCellLines.add(c.line);
    }

  // numbering cells: dominant kind only, merged in reading order (two-column
  // halves flow as one continuous sequence)
  const dominantKind: RadifLane['kind'] = lanes.some((l) => l.kind === 'column') ? 'column' : 'leading';
  const numberingCells = lanes
    .filter((l) => l.kind === dominantKind)
    .flatMap((l) => l.cells)
    .sort(
      (a, b) =>
        a.page - b.page ||
        (rtl ? (a.side === 'R' ? 0 : 1) - (b.side === 'R' ? 0 : 1) : 0) ||
        a.y - b.y
    );

  return {
    lanes,
    status,
    scheme: 'unknown',
    twoColumn,
    rtl,
    gutters,
    columnCellLines,
    laneCellLines,
    cellsByLine,
    numberingCells,
    standaloneCells: candidates.filter((c) => c.kind === 'standalone'),
    notes,
  };
}

// ------------------------------------------------------ numbering (post-hoc)

export interface NumberingHelpers {
  orderOf: Map<BrainLine, number>;
  /** true when a printed separator (header/rule/table boundary) sits between
   *  the two lines in document order — a skip with one is "printed". */
  hasBoundaryBetween: (a: BrainLine, b: BrainLine) => boolean;
}

/**
 * Read the lanes AFTER segmentation: pair cells to sections (line identity,
 * then document-order span), infer the document's numbering scheme, receipt
 * every break (intra- AND cross-section), and fill MISSING section identities
 * from the printed lane (printed wins — an existing identity is never
 * overwritten, only corroborated or flagged as a mismatch).
 */
export function applyRadifNumbering(
  sections: { evidence: { numeric?: number }; lines: BrainLine[]; notes: string[]; eventLine?: BrainLine }[],
  analysis: RadifAnalysis,
  helpers: NumberingHelpers
): RadifNumbering {
  const notes: string[] = [];
  const skips: RadifSkipReceipt[] = [];
  const status = analysis.status;
  if (status === 'none' || !analysis.numberingCells.length) {
    return { status, scheme: 'unknown', twoColumn: analysis.twoColumn, skips, notes };
  }

  // ---- claim cells to sections. Priority: (1) the section whose BOUNDARY
  // EVENT is the cell's own line (exact for lane-opened sections, immune to
  // two-column y-span scrambles); (2) line membership; (3) document-order
  // span containment.
  const lineSec = new Map<BrainLine, number>();
  sections.forEach((s, si) => {
    for (const l of s.lines) if (!lineSec.has(l)) lineSec.set(l, si);
  });
  const eventSec = new Map<BrainLine, number>();
  sections.forEach((s, si) => {
    if (s.eventLine && !eventSec.has(s.eventLine)) eventSec.set(s.eventLine, si);
  });
  const spanOf = sections.map((s) => {
    let lo = Infinity;
    let hi = -Infinity;
    for (const l of s.lines) {
      const i = helpers.orderOf.get(l);
      if (i === undefined) continue;
      lo = Math.min(lo, i);
      hi = Math.max(hi, i);
    }
    return [lo, hi] as [number, number];
  });
  const cells = analysis.numberingCells.map((c) => {
    let si = eventSec.get(c.line);
    if (si === undefined) si = lineSec.get(c.line);
    if (si === undefined) {
      const i = helpers.orderOf.get(c.line);
      if (i !== undefined) {
        const hit = spanOf.findIndex(([lo, hi]) => i >= lo && i <= hi);
        if (hit >= 0) si = hit;
      }
    }
    return { ...c, si: si ?? -1 };
  });

  // ---- scheme inference from section starts/maxima
  const bySec = new Map<number, typeof cells>();
  for (const c of cells) if (c.si >= 0) (bySec.get(c.si) ?? bySec.set(c.si, []).get(c.si)!).push(c);
  const secCells = [...bySec.entries()].sort((a, b) => a[0] - b[0]);
  let restarts = 0;
  let advances = 0;
  for (let i = 1; i < secCells.length; i++) {
    const prevMax = Math.max(...secCells[i - 1][1].map((c) => c.num));
    const first = secCells[i][1][0].num;
    if (first <= 2 && first < prevMax) restarts++;
    else if (first > prevMax && first <= prevMax + 2) advances++;
  }
  const scheme: RadifScheme =
    restarts >= 2 && restarts > advances
      ? 'perSection'
      : advances >= 1 && restarts === 0
      ? 'continuous'
      : 'unknown';
  if (secCells.length >= 2)
    notes.push(
      `radif numbering: scheme ${scheme} (${restarts} restart(s), ${advances} advance(s) across ${secCells.length} numbered sections)`
    );

  // ---- row rhythm: the median same-page gap between consecutive +1 cells
  // (the printed row pitch); skips are judged against it
  const pitches: number[] = [];
  for (let i = 1; i < cells.length; i++) {
    const prev = cells[i - 1];
    const cur = cells[i];
    if (cur.page === prev.page && cur.num === prev.num + 1) pitches.push(cur.y - prev.y);
  }
  pitches.sort((a, b) => a - b);
  const pitch = pitches.length ? Math.max(8, pitches[Math.floor(pitches.length / 2)]) : 40;

  // ---- unified break walk: every consecutive cell pair (across section
  // edges too — a question lost at a section boundary is still a question)
  const receipt = (c: (typeof cells)[number], code: RadifSkipReceipt['code'], afterNum: number, detail: string) => {
    skips.push({ code, afterNum, nextNum: c.num, page: c.page, sectionIndex: c.si, detail });
    const msg = `radif ${code}: ${afterNum} -> ${c.num} @pg${c.page + 1} — ${detail}`;
    if (c.si >= 0) sections[c.si].notes.push(msg);
    notes.push(msg);
  };
  for (let i = 1; i < cells.length; i++) {
    const prev = cells[i - 1];
    const cur = cells[i];
    const expected = prev.num + 1;
    if (cur.num === expected) continue;
    const across = cur.si !== prev.si;
    const acrossTxt = across ? ' across the section boundary' : '';
    if (cur.num === prev.num) {
      receipt(cur, 'radif-duplicate', prev.num, 'the same printed row number repeats');
    } else if (cur.num > expected) {
      const missing = `${expected}${cur.num - expected > 1 ? `-${cur.num - 1}` : ''}`;
      if (helpers.hasBoundaryBetween(prev.line, cur.line))
        receipt(cur, 'skip-printed', prev.num, `missing ${missing}${acrossTxt} — a printed boundary sits between (teacher skip or unnumbered block)`);
      else {
        const gap = cur.page === prev.page ? cur.y - prev.y : pitch * 3;
        if (gap > 2.2 * pitch)
          receipt(cur, 'skip-suspect-merge', prev.num, `missing ${missing}${acrossTxt} — oversized gap with no boundary: a question block was likely merged; re-segmentation advised`);
        else
          receipt(cur, 'skip-unexplained', prev.num, `missing ${missing}${acrossTxt} — no boundary, normal gap`);
      }
    } else if (cur.num >= 3) {
      receipt(cur, 'radif-regression', prev.num, 'row numbers regress — possible second structure or answer-key copy');
    }
    // cur.num <= 2 after a higher number = a section restart: the scheme's
    // business, not a receipt (under a CONTINUOUS scheme it is a regression
    // and the branch above already flagged it)
  }

  // ---- printed-wins identity fill (scheme-aware; never overwrites)
  if (scheme !== 'perSection') {
    let floor = 0;
    for (const [si, sc] of secCells) {
      const s = sections[si];
      if (s.evidence.numeric !== undefined) {
        floor = Math.max(floor, s.evidence.numeric);
        continue;
      }
      const first = sc[0].num;
      if (first > floor && first <= floor + 4) {
        s.evidence.numeric = first;
        floor = first;
        const msg = `section identity ${first} adopted from the radif lane (pg${sc[0].page + 1})`;
        s.notes.push(msg);
        notes.push(msg);
      }
    }
  }

  return { status, scheme, twoColumn: analysis.twoColumn, skips, notes };
}
