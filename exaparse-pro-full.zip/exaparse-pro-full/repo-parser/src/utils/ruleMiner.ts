import { ExamDocument, ExamSection, QuestionType } from '../types/exam';
import { gradeParse, GoldenGT, GradeResult } from './goldenGrade';
import { parseExamRawText } from './parserEngine';

/**
 * Rule Mining (Idea 1) — the AI proposes, the corpus decides.
 *
 * PIPELINE (every stage is a hard gate; anything fails -> nothing ships):
 *   1. VALIDATE   — the proposal must fit the constrained DSL below (whitelist
 *                   types/categories, length caps, ReDoS-guarded regexes).
 *   2. GROUND     — the AI's "expected parse" must be anchored in the RAW
 *                   DOCUMENT (section ids + >=60% of question numbers must
 *                   literally appear in the source, marks must sum). This kills
 *                   the self-fulfilling-grader trap: the AI cannot grade its
 *                   own beliefs, only its reading of the printed paper.
 *   3. TARGET     — the proposed rule, applied to a fresh parse of the raw
 *                   text, must produce EXACTLY the grounded expected parse
 *                   (graded with the same semantics as the strict gate).
 *   4. SHADOW     — the rule runs over the WHOLE golden corpus (30 exams +
 *                   20 mocks). A single atomic-check regression rejects it.
 *   5. PROMOTE    — all green AND corpus coverage >= minCorpusForLive -> the
 *                   rule lands as 'live' (auto-promoted, human can retire).
 *                   Target-green but NO corpus coverage -> 'shadow' (never
 *                   live: no coverage means nobody can prove it safe).
 *
 * Fail-safe invariants:
 *   - Mined rules are a SEPARATE layer: applyMinedRules() runs after the
 *     deterministic parse and never edits it in place (returns a new doc).
 *   - Only status === 'live' rules ever apply. Retiring is one status flip.
 *   - The empty rule list is a perfect identity transform — the corpus gate
 *     stays at 100% with zero rules.
 *   - The strict grader (grade.mts) ALSO applies live rules, so a bad future
 *     import turns npm run verify red instead of passing silently.
 */

// ---------------------------------------------------------------------------
// The constrained DSL — the entire space of what a mined rule CAN say
// ---------------------------------------------------------------------------

export type MinedRuleStatus = 'proposed' | 'shadow' | 'live' | 'retired';

export const CATEGORY_WHITELIST = ['Listening', 'Vocabulary', 'Grammar', 'Writing', 'Reading', 'General'] as const;
export const TYPE_WHITELIST: QuestionType[] = [
  'multiple_choice', 'cloze_item', 'word_bank_fill', 'fill_blank', 'matching',
  'true_false', 'short_answer', 'long_answer_essay', 'unscramble',
  'form_in_parentheses', 'combine_sentences', 'active_passive', 'error_correction',
  'letter_reorder', 'inline_choice', 'dialogue_response', 'odd_one_out',
  'phonetic_pronunciation', 'sentence_ordering', 'picture_description',
  'translation', 'definition_matching', 'numerical_calculation',
];

export interface MinedRuleCondition {
  /** Exact section (rowId) this rule is about, e.g. 'ب'. */
  sectionRowId?: string;
  /** Template-scoped condition (Idea 1+2 composition): apply only to sections
   *  whose mined template hints suggest this type. */
  suggestsTypeFromTemplate?: string;
  /** Question-stem pattern (safe, capped regex). */
  stemRegex?: string;
  /** Section instruction pattern (safe, capped regex). */
  instructionRegex?: string;
  /** Explicit question numbers to act on (otherwise all matches in scope). */
  questionNumbers?: number[];
}

export interface MinedRuleAction {
  setType?: QuestionType;
  setCategory?: (typeof CATEGORY_WHITELIST)[number];
  setMark?: number;
}

export interface MinedRuleProvenance {
  sourceFile?: string;
  model?: string;
  minedBy: 'ai' | 'hand';
  promptHash?: string;
  createdAt: string;
}

export interface ShadowReport {
  ranAt: string;
  corpusFiles: number;
  regressions: { file: string; issues: string[] }[];
  targetPassed: boolean;
  targetIssues: string[];
}

export interface MinedRule {
  id: string;
  version: 1;
  status: MinedRuleStatus;
  provenance: MinedRuleProvenance;
  condition: MinedRuleCondition;
  action: MinedRuleAction;
  rationale?: string;
  stats?: { corpusFiles: number; regressions: number; targetFixed: boolean };
  reports?: ShadowReport[];
}

export interface RuleProposal {
  analysis?: string;
  rule: unknown;
  expectedParse?: ExpectedParseInput;
}

export interface ExpectedSection {
  id: string;
  cat: string;
  mark: number;
  questions: { n: number; t: string }[];
}
export interface ExpectedParseInput {
  header?: Record<string, string | number>;
  totalMarks?: number;
  sections: ExpectedSection[];
}

export interface MiningReport {
  ok: boolean;
  error?: string;
  errors?: string[];
  warnings: string[];
  analysis?: string;
  status?: MinedRuleStatus;
  rule?: MinedRule;
  targetPassed?: boolean;
  targetIssues?: string[];
  shadow?: { corpusFiles: number; regressions: { file: string; issues: string[] }[] };
}

// ---------------------------------------------------------------------------
// Caps and guards
// ---------------------------------------------------------------------------

export const MAX_REGEX_LEN = 160;
export const MAX_RATIONALE_LEN = 600;
export const MAX_ANALYSIS_LEN = 1200;
export const MAX_MARK = 100;
export const MAX_RULES = 200;
export const DEFAULT_MIN_CORPUS_FOR_LIVE = 20;

/**
 * Static ReDoS guard: reject nested-quantifier patterns (the (a+)+ / (a|aa)+
 * family) and over-long patterns. Compiled with the 'i' flag only — no
 * user-controlled flags.
 */
export function isSafeRegex(pattern: unknown): { ok: boolean; error?: string } {
  if (typeof pattern !== 'string' || pattern.trim().length === 0) return { ok: false, error: 'regex is empty' };
  if (pattern.length > MAX_REGEX_LEN) return { ok: false, error: `regex exceeds ${MAX_REGEX_LEN} chars` };
  // A group that itself contains a quantifier or alternation must NOT be
  // quantified. This static rule blocks the classic exponential shapes.
  if (/\((?:[^()])*?(?:[+*]|\|)[^()]*\)\s*(?:[+*]|\{)/.test(pattern)) {
    return { ok: false, error: 'nested quantifier pattern rejected (ReDoS guard)' };
  }
  if (/\([^(]*[+*][^)]*\)\s*\{/.test(pattern)) {
    return { ok: false, error: 'nested quantifier pattern rejected (ReDoS guard)' };
  }
  try {
    new RegExp(pattern, 'i');
  } catch (e: any) {
    return { ok: false, error: `invalid regex: ${e?.message || 'compile failed'}` };
  }
  return { ok: true };
}

// ---------------------------------------------------------------------------
// Validation (gate 1)
// ---------------------------------------------------------------------------

export interface Validated {
  ok: boolean;
  errors: string[];
  rule?: MinedRule;
}

export function validateMinedRule(rawRule: unknown, provenance: MinedRuleProvenance): Validated {
  const errors: string[] = [];
  if (!rawRule || typeof rawRule !== 'object') return { ok: false, errors: ['rule is missing or not an object'] };
  const r = rawRule as Record<string, unknown>;
  const cond = (r.condition && typeof r.condition === 'object' ? r.condition : {}) as Record<string, unknown>;
  const act = (r.action && typeof r.action === 'object' ? r.action : {}) as Record<string, unknown>;

  // Condition
  const condition: MinedRuleCondition = {};
  if (cond.sectionRowId !== undefined) {
    if (typeof cond.sectionRowId !== 'string' || cond.sectionRowId.length === 0 || cond.sectionRowId.length > 8) {
      errors.push('condition.sectionRowId must be a short string');
    } else condition.sectionRowId = cond.sectionRowId;
  }
  if (cond.suggestsTypeFromTemplate !== undefined) {
    if (typeof cond.suggestsTypeFromTemplate !== 'string' || !TYPE_WHITELIST.includes(cond.suggestsTypeFromTemplate as QuestionType)) {
      errors.push('condition.suggestsTypeFromTemplate must be a known question type');
    } else condition.suggestsTypeFromTemplate = cond.suggestsTypeFromTemplate;
  }
  if (cond.stemRegex !== undefined) {
    const g = isSafeRegex(cond.stemRegex);
    if (!g.ok) errors.push(`condition.stemRegex: ${g.error}`);
    else condition.stemRegex = cond.stemRegex as string;
  }
  if (cond.instructionRegex !== undefined) {
    const g = isSafeRegex(cond.instructionRegex);
    if (!g.ok) errors.push(`condition.instructionRegex: ${g.error}`);
    else condition.instructionRegex = cond.instructionRegex as string;
  }
  if (cond.questionNumbers !== undefined) {
    if (!Array.isArray(cond.questionNumbers) || cond.questionNumbers.length === 0 || cond.questionNumbers.length > 200 ||
        !cond.questionNumbers.every((n) => Number.isInteger(n) && (n as number) > 0 && (n as number) <= 999)) {
      errors.push('condition.questionNumbers must be 1..200 positive integers');
    } else condition.questionNumbers = [...new Set(cond.questionNumbers as number[])].sort((a, b) => a - b);
  }

  // Action — at least one, all whitelisted
  const action: MinedRuleAction = {};
  let actionCount = 0;
  if (act.setType !== undefined) {
    if (!TYPE_WHITELIST.includes(act.setType as QuestionType)) errors.push(`action.setType "${act.setType}" is not a known type`);
    else { action.setType = act.setType as QuestionType; actionCount++; }
  }
  if (act.setCategory !== undefined) {
    if (!CATEGORY_WHITELIST.includes(act.setCategory as never)) errors.push(`action.setCategory "${act.setCategory}" is not a known category`);
    else { action.setCategory = act.setCategory as MinedRuleAction['setCategory']; actionCount++; }
  }
  if (act.setMark !== undefined) {
    const m = typeof act.setMark === 'number' ? act.setMark : parseFloat(String(act.setMark));
    if (!Number.isFinite(m) || m < 0 || m > MAX_MARK) errors.push(`action.setMark must be 0..${MAX_MARK}`);
    else { action.setMark = Math.round(m * 100) / 100; actionCount++; }
  }
  if (actionCount === 0) errors.push('action must set at least one of setType/setCategory/setMark');

  // Condition must also be non-empty (a rule that matches everything is a weapon)
  const condCount = Object.keys(condition).length;
  if (condCount === 0) errors.push('condition must scope the rule (sectionRowId / template scope / stemRegex / instructionRegex / questionNumbers)');

  let rationale: string | undefined;
  if (r.rationale !== undefined) {
    rationale = String(r.rationale).slice(0, MAX_RATIONALE_LEN);
  }

  if (errors.length > 0) return { ok: false, errors };
  const rule: MinedRule = {
    id: ruleId(condition, action),
    version: 1,
    status: 'proposed',
    provenance,
    condition,
    action,
    rationale,
  };
  return { ok: true, errors: [], rule };
}

function ruleId(cond: MinedRuleCondition, act: MinedRuleAction): string {
  const h = hashCode(JSON.stringify([cond, act]));
  return `mr-${Math.abs(h).toString(36).padStart(7, '0')}`;
}

function hashCode(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  return h;
}

// ---------------------------------------------------------------------------
// Grounding (gate 2) — anchor the expected parse in the RAW DOCUMENT
// ---------------------------------------------------------------------------

const PERSIAN_DIGITS = '۰۱۲۳۴۵۶۷۸۹';

function toLatinDigits(s: string): string {
  return s.replace(/[۰-۹]/g, (d) => String(PERSIAN_DIGITS.indexOf(d)));
}

export interface GroundResult {
  ok: boolean;
  errors: string[];
  grounded?: ExpectedParseInput;
}

export function groundExpectedParse(expected: unknown, rawText: string): GroundResult {
  const errors: string[] = [];
  if (!expected || typeof expected !== 'object') return { ok: false, errors: ['expectedParse is missing'] };
  const e = expected as Record<string, unknown>;
  if (!Array.isArray(e.sections) || e.sections.length === 0 || e.sections.length > 40) {
    return { ok: false, errors: ['expectedParse.sections must be a non-empty array (max 40)'] };
  }

  const rawNorm = toLatinDigits(rawText || '');
  const sections: ExpectedSection[] = [];

  for (const s of e.sections as Record<string, unknown>[]) {
    if (!s || typeof s !== 'object') {
      errors.push('expectedParse.sections: non-object entry');
      continue;
    }
    const id = typeof s.id === 'string' ? s.id.trim() : '';
    const cat = typeof s.cat === 'string' ? s.cat.trim() : '';
    const mark = typeof s.mark === 'number' ? s.mark : parseFloat(String(s.mark));
    if (!id || id.length > 8) {
      errors.push(`section id "${id}" invalid`);
      continue;
    }
    if (!CATEGORY_WHITELIST.includes(cat as never)) {
      errors.push(`section ${id}: category "${cat}" is not in the whitelist`);
      continue;
    }
    if (!Number.isFinite(mark) || mark < 0) {
      errors.push(`section ${id}: mark invalid`);
      continue;
    }
    if (!Array.isArray(s.questions) || s.questions.length === 0) {
      errors.push(`section ${id}: questions must be a non-empty array`);
      continue;
    }
    const questions: { n: number; t: string }[] = [];
    let prev = 0;
    let anchored = 0;
    for (const q of s.questions as Record<string, unknown>[]) {
      const n = typeof q?.n === 'number' ? q.n : parseInt(String(q?.n), 10);
      const t = typeof q?.t === 'string' ? q.t.trim() : '';
      if (!Number.isInteger(n) || n <= 0 || n > 999) {
        errors.push(`section ${id}: question number ${q?.n} invalid`);
        continue;
      }
      if (n <= prev) {
        errors.push(`section ${id}: question numbers must be strictly increasing (got ${n} after ${prev})`);
        continue;
      }
      if (!TYPE_WHITELIST.includes(t as QuestionType)) {
        errors.push(`section ${id} q${n}: type "${t}" is not in the whitelist`);
        continue;
      }
      prev = n;
      questions.push({ n, t });
      if (new RegExp(`(^|[^\\d])${n}(?![\\d])`).test(rawNorm)) anchored++;
    }
    if (questions.length === 0) continue;
    // Document anchor: >=60% of the claimed question numbers must literally
    // appear in the raw source (Latin or Persian digits).
    const anchorPct = anchored / questions.length;
    if (anchorPct < 0.6) {
      errors.push(`section ${id}: only ${anchored}/${questions.length} claimed question numbers appear in the raw document — expected parse is not grounded in the paper`);
    }
    // Section anchor: the id (letter) must appear in the raw source.
    const idAnchor = new RegExp(`(?<![A-Za-z])${escapeRegExp(id)}(?![A-Za-z])`, 'i').test(rawNorm) || rawNorm.includes(id);
    if (!idAnchor) {
      errors.push(`section ${id}: the section marker does not appear in the raw document`);
    }
    sections.push({ id, cat: cat as ExpectedSection['cat'], mark: Math.round(mark * 100) / 100, questions });
  }

  let totalMarks: number | undefined;
  if (e.totalMarks !== undefined) {
    const tm = typeof e.totalMarks === 'number' ? e.totalMarks : parseFloat(String(e.totalMarks));
    if (!Number.isFinite(tm) || tm < 0) errors.push('expectedParse.totalMarks invalid');
    else totalMarks = tm;
  }

  // Mark arithmetic: the AI's sections must sum to its own claimed total.
  if (totalMarks !== undefined && sections.length > 0) {
    const sum = sections.reduce((s, x) => s + x.mark, 0);
    const tol = Math.max(1, totalMarks * 0.02);
    if (Math.abs(sum - totalMarks) > tol) {
      errors.push(`expectedParse marks do not add up: sections sum to ${Math.round(sum * 100) / 100} but totalMarks is ${totalMarks}`);
    }
  }

  if (errors.length > 0 || sections.length === 0) return { ok: false, errors: errors.length > 0 ? errors : ['expectedParse has no valid sections'] };
  const grounded: ExpectedParseInput = { sections };
  if (e.header !== undefined && e.header && typeof e.header === 'object') {
    const header: Record<string, string | number> = {};
    for (const [k, v] of Object.entries(e.header as Record<string, unknown>)) {
      if (typeof k === 'string' && k.length <= 40 && (typeof v === 'string' || typeof v === 'number')) {
        header[k] = typeof v === 'string' ? v.slice(0, 120) : v;
      }
    }
    if (Object.keys(header).length > 0) grounded.header = header;
  }
  if (totalMarks !== undefined) grounded.totalMarks = totalMarks;
  return { ok: true, errors: [], grounded };
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// ---------------------------------------------------------------------------
// Application — the mined layer (additive, reversible, live-only)
// ---------------------------------------------------------------------------

let activeMinedRules: MinedRule[] = [];

/** App-wide active rule set (defaults to empty = pure deterministic parse). */
export function configureMinedRules(rules: MinedRule[]): void {
  activeMinedRules = Array.isArray(rules) ? rules.filter((r) => r && r.status === 'live') : [];
}

export function getActiveMinedRules(): MinedRule[] {
  return activeMinedRules;
}

function sectionMatches(sec: ExamSection, cond: MinedRuleCondition): boolean {
  if (cond.sectionRowId !== undefined && sec.rowId !== cond.sectionRowId) return false;
  if (cond.suggestsTypeFromTemplate !== undefined) {
    const hints = sec.templateHints || [];
    if (!hints.some((h) => h.suggestsType === cond.suggestsTypeFromTemplate)) return false;
  }
  if (cond.instructionRegex !== undefined) {
    const hay = `${sec.persianInstruction || ''}\n${sec.englishInstruction || ''}\n${sec.title || ''}`;
    try {
      if (!new RegExp(cond.instructionRegex, 'i').test(hay)) return false;
    } catch {
      return false; // a rule that cannot compile never matches (fail-safe)
    }
  }
  return true;
}

/**
 * Apply LIVE mined rules to a parsed document. Returns a NEW document; the
 * input is never mutated. Rules are applied in list order; a malformed rule
 * object (never expected — everything passes validation first) is skipped.
 */
export function applyMinedRules(doc: ExamDocument, rules: MinedRule[]): ExamDocument {
  const live = (rules || []).filter((r) => r && r.status === 'live' && r.condition && r.action);
  if (live.length === 0) return doc;

  const next: ExamDocument = { ...doc, sections: doc.sections.map((sec) => ({ ...sec, questions: [...sec.questions] })) };

  for (const rule of live) {
    const { condition, action } = rule;
    for (let si = 0; si < next.sections.length; si++) {
      const sec = next.sections[si];
      if (!sectionMatches(sec, condition)) continue;
      if (action.setCategory !== undefined) {
        next.sections[si] = { ...sec, majorCategory: action.setCategory };
      }
      for (let qi = 0; qi < next.sections[si].questions.length; qi++) {
        const q = next.sections[si].questions[qi];
        const n = typeof q.number === 'number' ? q.number : parseInt(String(q.number), 10);
        if (condition.questionNumbers !== undefined) {
          if (!Number.isInteger(n) || !condition.questionNumbers.includes(n)) continue;
        } else if (condition.stemRegex !== undefined) {
          try {
            if (!new RegExp(condition.stemRegex, 'i').test(q.stem || '')) continue;
          } catch {
            continue;
          }
        }
        if (action.setType !== undefined || action.setMark !== undefined) {
          next.sections[si].questions[qi] = {
            ...q,
            ...(action.setType !== undefined ? { type: action.setType } : {}),
            ...(action.setMark !== undefined ? { mark: action.setMark } : {}),
          };
        }
      }
    }
  }
  return next;
}

// ---------------------------------------------------------------------------
// Status transitions — the human gate
// ---------------------------------------------------------------------------

const ALLOWED_TRANSITIONS: Record<MinedRuleStatus, MinedRuleStatus[]> = {
  proposed: ['shadow', 'retired'],
  shadow: ['live', 'retired'],
  live: ['retired', 'shadow'], // demote = instant kill switch
  retired: [], // terminal — re-mine instead of resurrecting
};

export function transitionRule(rules: MinedRule[], id: string, to: MinedRuleStatus): { ok: boolean; error?: string; rules: MinedRule[] } {
  const idx = rules.findIndex((r) => r.id === id);
  if (idx < 0) return { ok: false, error: `rule ${id} not found`, rules };
  const from = rules[idx].status;
  if (!ALLOWED_TRANSITIONS[from].includes(to)) {
    return { ok: false, error: `illegal transition ${from} -> ${to}`, rules };
  }
  const next = [...rules];
  next[idx] = { ...next[idx], status: to };
  return { ok: true, rules: next };
}

// ---------------------------------------------------------------------------
// The pipeline (gates 3-5) — dependency-injected, no fs / no network
// ---------------------------------------------------------------------------

export interface MiningCorpusEntry {
  name: string;
  text: string;
  gt: GoldenGT;
}

export interface MiningPipelineInput {
  rawText: string;
  sourceFile?: string;
  /** The parsed AI response: { analysis?, rule, expectedParse? }. */
  proposal: unknown;
  /** Golden corpus for the shadow run (absent = rule can never go live). */
  corpus?: MiningCorpusEntry[];
  /** Optional parse overrides (tests). */
  parseFn?: (text: string) => ExamDocument;
  model?: string;
  promptHash?: string;
  minCorpusForLive?: number;
  now?: string;
}

export function runMiningPipeline(input: MiningPipelineInput): MiningReport {
  const warnings: string[] = [];
  const now = input.now || new Date().toISOString();
  const parseFn = input.parseFn || ((text: string) => parseExamRawText(text, 'mined-target', { detectAnomalies: false, normalizeNumbering: true, linkClozePassages: true }));

  // -- 1. VALIDATE -----------------------------------------------------------
  const proposal = (input.proposal && typeof input.proposal === 'object' ? input.proposal : {}) as Record<string, unknown>;
  const analysis = typeof proposal.analysis === 'string' ? proposal.analysis.slice(0, MAX_ANALYSIS_LEN) : undefined;
  const validated = validateMinedRule(proposal.rule, {
    sourceFile: input.sourceFile,
    model: input.model,
    minedBy: 'ai',
    promptHash: input.promptHash,
    createdAt: now,
  });
  if (!validated.ok || !validated.rule) {
    return { ok: false, error: 'The proposed rule failed schema validation.', errors: validated.errors, warnings, analysis };
  }
  const rule = validated.rule;

  // -- 2. GROUND -------------------------------------------------------------
  const ground = groundExpectedParse(proposal.expectedParse, input.rawText || '');
  if (!ground.ok || !ground.grounded) {
    return {
      ok: false,
      error: 'The proposed expected parse is not anchored in the raw document (self-fulfilling-grader guard).',
      errors: ground.errors,
      warnings,
      analysis,
    };
  }

  // -- 3. TARGET: the rule must reproduce the grounded expected parse --------
  let targetDoc: ExamDocument;
  try {
    targetDoc = parseFn(input.rawText || '');
  } catch (e: any) {
    return { ok: false, error: `Parsing the raw text failed inside the mining pipeline: ${e?.message || e}`, warnings, analysis };
  }
  let ruledDoc: ExamDocument;
  try {
    ruledDoc = applyMinedRules(targetDoc, [{ ...rule, status: 'live' }]);
  } catch (e: any) {
    return { ok: false, error: `Applying the proposed rule crashed: ${e?.message || e}`, warnings, analysis };
  }
  const target: GradeResult = gradeParse(
    ruledDoc,
    // The expected parse IS a ground truth shape minus provenance fields the
    // grader never reads. If the AI claimed no totalMarks, nothing is claimed
    // — compare against the parsed doc's own total (no invented check).
    {
      file: 'expected',
      header: ground.grounded.header || {},
      totalMarks: ground.grounded.totalMarks ?? ruledDoc.totalMarks,
      sections: ground.grounded.sections.map((s) => ({ id: s.id, cat: s.cat, mark: s.mark, qs: s.questions })),
    },
  );
  const targetPassed = target.issues.length === 0;
  if (!targetPassed) {
    return {
      ok: false,
      error: 'The proposed rule does not achieve its own claimed fix (target check failed against the grounded expected parse).',
      errors: target.issues.slice(0, 12),
      warnings,
      analysis,
    };
  }

  // -- 4. SHADOW: the whole golden corpus must stay at 100% ------------------
  const corpus = input.corpus || [];
  const regressions: { file: string; issues: string[] }[] = [];
  for (const entry of corpus) {
    try {
      const doc = parseFn(entry.text);
      const ruled = applyMinedRules(doc, [{ ...rule, status: 'live' }]);
      const res = gradeParse(ruled, entry.gt);
      if (res.issues.length > 0) regressions.push({ file: entry.name, issues: res.issues.slice(0, 6) });
    } catch (e: any) {
      regressions.push({ file: entry.name, issues: [`shadow parse crashed: ${e?.message || e}`] });
    }
  }
  if (regressions.length > 0) {
    return {
      ok: false,
      error: `The rule regresses ${regressions.length} golden exam(s) — rejected by the corpus shadow run.`,
      warnings,
      analysis,
      targetPassed,
      targetIssues: [],
      shadow: { corpusFiles: corpus.length, regressions: regressions.slice(0, 8) },
    };
  }

  // -- 5. PROMOTE ------------------------------------------------------------
  const minCorpus = input.minCorpusForLive ?? DEFAULT_MIN_CORPUS_FOR_LIVE;
  let status: MinedRuleStatus;
  if (corpus.length >= minCorpus) {
    status = 'live';
  } else {
    status = 'shadow';
    warnings.push(`Corpus coverage is only ${corpus.length} file(s) (< ${minCorpus}). The rule cannot be proven safe — it stays in 'shadow' and will NOT apply until the corpus covers its layout family or a human promotes it.`);
  }

  const finalRule: MinedRule = {
    ...rule,
    status,
    stats: { corpusFiles: corpus.length, regressions: 0, targetFixed: true },
    reports: [{
      ranAt: now,
      corpusFiles: corpus.length,
      regressions: [],
      targetPassed: true,
      targetIssues: [],
    }],
  };

  return {
    ok: true,
    warnings,
    analysis,
    status,
    rule: finalRule,
    targetPassed: true,
    targetIssues: [],
    shadow: { corpusFiles: corpus.length, regressions: [] },
  };
}

// ---------------------------------------------------------------------------
// Store helpers (dedupe / merge) — pure; persistence lives in the server layer
// ---------------------------------------------------------------------------

export function mergeMinedRules(existing: MinedRule[], incoming: MinedRule): { rules: MinedRule[]; deduped: boolean } {
  const idx = existing.findIndex((r) => r.id === incoming.id);
  if (idx >= 0) {
    // Same condition+action hash: refresh provenance, keep the human decision.
    const next = [...existing];
    next[idx] = {
      ...incoming,
      status: existing[idx].status === 'live' ? 'live' : incoming.status,
      reports: [...(incoming.reports || []), ...(existing[idx].reports || [])].slice(0, 3),
    };
    return { rules: next, deduped: true };
  }
  if (existing.length >= MAX_RULES) {
    throw new Error(`Mined-rule store is full (${MAX_RULES}). Retire unused rules first.`);
  }
  return { rules: [...existing, incoming], deduped: false };
}
