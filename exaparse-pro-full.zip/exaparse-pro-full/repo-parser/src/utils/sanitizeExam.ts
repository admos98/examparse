import {
  ExamDocument,
  ExamHeader,
  ExamOption,
  ExamSection,
  ExamImage,
  JevJudgement,
  ParseVerdict,
  ParsingAnomaly,
  QuestionItem,
  QuestionType,
  ProvenanceRef,
  QuestionReceipt,
  ExtractionQualityReport,
  TrustSummary,
  ParseTraceSummary,
  ProducedAnswer,
  AnswerMediation,
  AnswerFlowReceipt,
  LessonAttribution,
  DifficultyScore,
  AnswerKeyWarning,
} from '../types/exam';

/**
 * Defensive normalizer for ExamDocument data coming from untrusted sources:
 *  - JSON backup imports (old versions / foreign tools / hand-edited files)
 *  - IndexedDB rows persisted by earlier app versions with a different schema
 *  - AI / network responses merged back into state
 *
 * A malformed document (e.g. missing `header`) used to white-screen the whole
 * app the moment any screen read `exam.header.courseName`. Every document that
 * passes through `sanitizeExam` is guaranteed to be structurally complete, so
 * render code can keep direct property access.
 */

const VALID_QUESTION_TYPES: ReadonlySet<string> = new Set<QuestionType>([
  'multiple_choice', 'cloze_item', 'word_bank_fill', 'fill_blank', 'matching',
  'true_false', 'short_answer', 'long_answer_essay', 'unscramble',
  'form_in_parentheses', 'combine_sentences', 'active_passive', 'error_correction',
  'letter_reorder', 'inline_choice', 'dialogue_response', 'odd_one_out',
  'phonetic_pronunciation', 'sentence_ordering', 'picture_description',
  'translation', 'definition_matching', 'numerical_calculation',
]);

const VALID_MAJOR_CATEGORIES: ReadonlySet<string> = new Set([
  'Listening', 'Vocabulary', 'Grammar', 'Writing', 'Reading', 'General',
]);

const VALID_ANOMALY_SEVERITIES: ReadonlySet<string> = new Set(['warning', 'info', 'error']);

const VALID_PARSE_STAGES: ReadonlySet<string> = new Set([
  'stage1_offline_unsolved', 'stage2_ai_solved',
]);

const VALID_PARENT_CONTEXT_TYPES: ReadonlySet<string> = new Set([
  'word_bank', 'cloze_passage', 'reading_passage', 'matching_table',
  'image_prompt', 'dialogue_context', 'listening_audio', 'none',
]);

const VALID_ANSWER_METHODS: ReadonlySet<string> = new Set(['heuristic', 'ai', 'cache', 'human', 'official']);

// M2 answer flow whitelist guards (the silent-drop lesson: a missing whitelist
// entry here makes the field vanish on EVERY save/update round-trip).
function sanitizeProducedAnswer(raw: unknown): ProducedAnswer | undefined {
  if (!isRecord(raw)) return undefined;
  const value = str(raw.value);
  const source = str(raw.source).trim();
  const provenance = str(raw.provenance).trim();
  if (!value) return undefined;
  if (!['r1', 'r3'].includes(source)) return undefined;
  if (!['ai-draft', 'jev-verified-draft'].includes(provenance)) return undefined;
  return {
    value,
    source: source as ProducedAnswer['source'],
    provenance: provenance as ProducedAnswer['provenance'],
    jevVerified: provenance === 'jev-verified-draft',
    producedAt: str(raw.producedAt).trim() || new Date().toISOString(),
    model: str(raw.model).trim().slice(0, 120) || undefined,
  };
}

function sanitizeMediation(raw: unknown): AnswerMediation | undefined {
  if (!isRecord(raw)) return undefined;
  const status = str(raw.status).trim();
  if (!['pending', 'resolved-ai', 'resolved-jev', 'resolved-human'].includes(status)) return undefined;
  return {
    aiAnswer: str(raw.aiAnswer),
    jevAnswer: str(raw.jevAnswer).trim() || undefined,
    status: status as AnswerMediation['status'],
    humanValue: str(raw.humanValue).trim() || undefined,
    decidedAt: str(raw.decidedAt).trim() || undefined,
  };
}

const VALID_IN_BOOK: ReadonlySet<string> = new Set(['in-book', 'mixed', 'out-of-book']);
const VALID_COGNITIVE: ReadonlySet<string> = new Set(['recall', 'comprehension', 'application']);

function sanitizeAttribution(raw: unknown): LessonAttribution | undefined {
  if (!isRecord(raw)) return undefined;
  const inBook = str(raw.inBook).trim();
  const cognitive = str(raw.cognitive).trim();
  const out: LessonAttribution = {
    lesson1: str(raw.lesson1).trim().slice(0, 80) || undefined,
    lesson2: str(raw.lesson2).trim().slice(0, 80) || undefined,
    inBook: VALID_IN_BOOK.has(inBook) ? (inBook as LessonAttribution['inBook']) : undefined,
    cognitive: VALID_COGNITIVE.has(cognitive) ? (cognitive as LessonAttribution['cognitive']) : undefined,
    supportFlag: bool(raw.supportFlag),
    digestVersion: str(raw.digestVersion).trim().slice(0, 40) || undefined,
    attributedAt: str(raw.attributedAt).trim() || undefined,
    model: str(raw.model).trim().slice(0, 120) || undefined,
  };
  return out.lesson1 || out.inBook || out.cognitive ? out : undefined;
}

function sanitizeDifficulty(raw: unknown): DifficultyScore | undefined {
  if (!isRecord(raw)) return undefined;
  const score = num(raw.score, -1);
  const band = str(raw.band).trim();
  if (score < 0 || score > 100 || !['easy', 'medium', 'hard'].includes(band)) return undefined;
  return {
    score: Math.round(score),
    band: band as DifficultyScore['band'],
    factors: asRecordArray(raw.factors).slice(0, 10).map((f) => ({
      id: str(f.id).trim().slice(0, 20),
      label: str(f.label).trim().slice(0, 60),
      points: num(f.points, 0),
    })),
    weightsVersion: str(raw.weightsVersion).trim().slice(0, 20) || 'w1',
    computedAt: str(raw.computedAt).trim() || new Date().toISOString(),
  };
}

// ---------- coercion helpers (never throw) ----------

const str = (v: unknown, fallback = ''): string =>
  typeof v === 'string' ? v : typeof v === 'number' || typeof v === 'boolean' ? String(v) : fallback;

const num = (v: unknown, fallback = 0): number => {
  const n = typeof v === 'number' ? v : parseFloat(String(v ?? ''));
  return Number.isFinite(n) ? n : fallback;
};

const bool = (v: unknown, fallback = false): boolean =>
  typeof v === 'boolean' ? v : fallback;

const strArray = (v: unknown): string[] =>
  Array.isArray(v) ? v.map((item) => str(item)).filter((s) => s.length > 0) : [];

const isRecord = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v);

const asRecordArray = (v: unknown): Record<string, unknown>[] =>
  Array.isArray(v) ? v.filter(isRecord) : [];

let counter = 0;
const genId = (prefix: string): string =>
  `${prefix}-${Date.now().toString(36)}-${(counter++).toString(36)}-${Math.random().toString(36).slice(2, 6)}`;

// ---------- per-part normalizers ----------

function sanitizeHeader(raw: unknown, filename: string): ExamHeader {
  const h = isRecord(raw) ? raw : {};
  const courseName = str(h.courseName).trim();
  const schoolName = str(h.schoolName).trim();
  return {
    courseName: courseName || filename || 'Unnamed exam',
    teacherName: str(h.teacherName).trim() || undefined,
    durationMinutes: num(h.durationMinutes, 0),
    examDate: str(h.examDate),
    schoolName,
    district: str(h.district),
    gradeAndMajor: str(h.gradeAndMajor),
    pageCount: num(h.pageCount, 1),
    grade: str(h.grade).trim() || undefined,
    term: str(h.term).trim() || undefined,
    examName: str(h.examName).trim() || undefined,
  };
}

function sanitizeOption(raw: unknown, idx: number): ExamOption {
  const o = isRecord(raw) ? raw : {};
  return {
    id: str(o.id).trim() || String.fromCharCode(97 + (idx % 26)), // 'a', 'b', ...
    text: str(o.text),
  };
}

function sanitizeProvenance(raw: unknown): ProvenanceRef | undefined {
  if (!isRecord(raw)) return undefined;
  const src = str(raw.source).trim();
  if (!['pdf_text', 'ocr', 'docx', 'text'].includes(src)) return undefined;
  const bboxRaw = isRecord(raw.bbox) ? raw.bbox : null;
  const bbox =
    bboxRaw && [bboxRaw.x, bboxRaw.y, bboxRaw.w, bboxRaw.h].every((n) => typeof n === 'number' && Number.isFinite(n))
      ? { x: bboxRaw.x as number, y: bboxRaw.y as number, w: bboxRaw.w as number, h: bboxRaw.h as number }
      : undefined;
  const coordSpace = str(raw.coordSpace).trim();
  return {
    source: src as ProvenanceRef['source'],
    page: typeof raw.page === 'number' && Number.isFinite(raw.page) ? raw.page : undefined,
    bbox,
    coordSpace: coordSpace === 'pdf' || coordSpace === 'pixel' ? coordSpace : undefined,
    pageHeight: typeof raw.pageHeight === 'number' ? raw.pageHeight : undefined,
    pageWidth: typeof raw.pageWidth === 'number' ? raw.pageWidth : undefined,
    lineStart: typeof raw.lineStart === 'number' ? raw.lineStart : undefined,
    lineEnd: typeof raw.lineEnd === 'number' ? raw.lineEnd : undefined,
    ocrConfidence: typeof raw.ocrConfidence === 'number' ? raw.ocrConfidence : undefined,
  };
}

function sanitizeReceipt(raw: unknown): QuestionReceipt | undefined {
  if (!isRecord(raw)) return undefined;
  const lineStart = num(raw.lineStart, -1);
  const lineEnd = num(raw.lineEnd, -1);
  if (lineStart < 0 || lineEnd < lineStart) return undefined;
  const ruleChain = strArray(raw.ruleChain);
  const alternates = asRecordArray(raw.alternates).map((a) => ({
    kind: str(a.kind),
    ruleId: str(a.ruleId),
    reason: str(a.reason),
  }));
  return {
    lineStart,
    lineEnd,
    ruleChain,
    alternates: alternates.length > 0 ? alternates : undefined,
    ruleConfidence: Math.max(0, Math.min(100, num(raw.ruleConfidence, 0))),
  };
}

function sanitizeJev(raw: unknown): JevJudgement | undefined {
  if (!isRecord(raw)) return undefined;
  const verdict = str(raw.verdict).trim();
  if (!['correct', 'incorrect', 'uncertain'].includes(verdict)) return undefined;
  const backend = str(raw.backend).trim();
  const pCorrect = typeof raw.pCorrect === 'number' && raw.pCorrect >= 0 && raw.pCorrect <= 1 ? raw.pCorrect : undefined;
  const quality = typeof raw.quality === 'number' && raw.quality >= 0 && Number.isFinite(raw.quality) ? raw.quality : undefined;
  const probabilities = isRecord(raw.probabilities)
    ? Object.fromEntries(
        Object.entries(raw.probabilities)
          .filter(([, v]) => typeof v === 'number' && Number.isFinite(v))
          .slice(0, 64),
      )
    : undefined;
  return {
    category: str(raw.category).trim() || undefined,
    skillArea: str(raw.skillArea).trim() || undefined,
    pCorrect,
    quality,
    qualityConfidence: typeof raw.qualityConfidence === 'number' ? raw.qualityConfidence : undefined,
    verdict: verdict as JevJudgement['verdict'],
    judgedAt: str(raw.judgedAt).trim() || new Date().toISOString(),
    model: str(raw.model).trim() || 'unknown',
    backend: backend === 'jev' ? 'jev' : 'llm-fallback',
    fingerprint: str(raw.fingerprint).trim() || undefined,
    cached: bool(raw.cached),
    probabilities: probabilities && Object.keys(probabilities).length > 0 ? (probabilities as Record<string, number>) : undefined,
  };
}

function sanitizeParseVerdict(raw: unknown): ParseVerdict | undefined {
  if (!isRecord(raw)) return undefined;
  const verdict = str(raw.verdict).trim();
  if (!['accepted', 'flagged', 'unverified'].includes(verdict)) return undefined;
  const backend = str(raw.backend).trim();
  return {
    typeOk: bool(raw.typeOk),
    separationOk: bool(raw.separationOk),
    metadataOk: bool(raw.metadataOk),
    verdict: verdict as ParseVerdict['verdict'],
    note: str(raw.note).trim() || undefined,
    suggestedType: str(raw.suggestedType).trim() || undefined,
    humanReviewed: bool(raw.humanReviewed),
    checkedAt: str(raw.checkedAt).trim() || new Date().toISOString(),
    model: str(raw.model).trim() || 'unknown',
    backend: backend === 'jev' ? 'jev' : 'llm-fallback',
    fingerprint: str(raw.fingerprint).trim() || undefined,
    cached: bool(raw.cached),
  };
}

function sanitizeQuestion(raw: unknown, sectionRowId: string, idx: number): QuestionItem {
  const q = isRecord(raw) ? raw : {};
  const rawType = str(q.type).trim();

  const options = asRecordArray(q.options).map((o, i) => sanitizeOption(o, i));
  const matchingPairs = asRecordArray(q.matchingPairs).map((p) => ({
    leftNumber: (typeof p.leftNumber === 'number' ? p.leftNumber : str(p.leftNumber)) as number | string,
    leftText: str(p.leftText),
    rightKey: str(p.rightKey).trim() || undefined,
    rightText: str(p.rightText).trim() || undefined,
  }));

  const anomalies = strArray(q.anomalies);

  return {
    id: str(q.id).trim() || genId(`q-${sectionRowId.toLowerCase()}-${idx + 1}`),
    number: typeof q.number === 'number' && Number.isFinite(q.number) ? q.number : str(q.number, String(idx + 1)),
    displayNumber: str(q.displayNumber).trim() || String(q.number ?? idx + 1),
    originalNumber: typeof q.originalNumber !== 'undefined' ? (q.originalNumber as number | string) : undefined,
    sectionRowId: str(q.sectionRowId).trim() || sectionRowId,
    sectionName: str(q.sectionName).trim() || 'General',
    type: (VALID_QUESTION_TYPES.has(rawType) ? rawType : 'short_answer') as QuestionType,
    typeEnName: str(q.typeEnName).trim() || undefined,
    typeFaName: str(q.typeFaName).trim() || undefined,
    stem: str(q.stem),
    persianInstruction: str(q.persianInstruction).trim() || undefined,
    englishInstruction: str(q.englishInstruction).trim() || undefined,
    options: options.length > 0 ? options : undefined,
    correctAnswer: typeof q.correctAnswer === 'string' ? q.correctAnswer : str(q.correctAnswer),
    mark: num(q.mark, 1),
    parentContextType: (VALID_PARENT_CONTEXT_TYPES.has(str(q.parentContextType).trim())
      ? str(q.parentContextType).trim()
      : undefined) as QuestionItem['parentContextType'],
    parentContextTitle: str(q.parentContextTitle).trim() || undefined,
    parentContextText: str(q.parentContextText).trim() || undefined,
    wordBankWords: strArray(q.wordBankWords).length > 0 ? strArray(q.wordBankWords) : undefined,
    // Task subtype ('dictation', ...) — advisory metadata, whitelist or it
    // silently vanishes on every save/update round-trip (the lesson that
    // produced this sanitizer).
    taskType: str(q.taskType).trim() || undefined,
    matchingPairs: matchingPairs.length > 0 ? matchingPairs : undefined,
    matchingDistractors: strArray(q.matchingDistractors).length > 0 ? strArray(q.matchingDistractors) : undefined,
    hasImage: bool(q.hasImage),
    imageUrl: str(q.imageUrl).trim() || undefined,
    imageFileName: str(q.imageFileName).trim() || undefined,
    imageCaption: str(q.imageCaption).trim() || undefined,
    anomalies: anomalies.length > 0 ? anomalies : undefined,
    reviewed: bool(q.reviewed),
    // Two-phase Jev flag (unchecked / awaiting image alt) — whitelist or the
    // flag silently vanishes on every save/update round-trip.
    imgPending: bool(q.imgPending),
    provenance: sanitizeProvenance(q.provenance),
    receipt: sanitizeReceipt(q.receipt),
    jev: sanitizeJev(q.jev),
    parseVerdict: sanitizeParseVerdict(q.parseVerdict),
    trustLevel:
      ['verified', 'single', 'contested'].includes(str(q.trustLevel).trim())
        ? (str(q.trustLevel).trim() as QuestionItem['trustLevel'])
        : undefined,
    answerMeta: isRecord(q.answerMeta) && VALID_ANSWER_METHODS.has(str(q.answerMeta.method).trim())
      ? {
          method: str(q.answerMeta.method).trim() as 'heuristic' | 'ai' | 'cache' | 'human' | 'official',
          confidence: typeof q.answerMeta.confidence === 'number' ? q.answerMeta.confidence : undefined,
        }
      : undefined,
    // M2 answer flow (draft + mediation) — whitelisted or silently dropped.
    answer: sanitizeProducedAnswer(q.answer),
    answerMediation: sanitizeMediation(q.answerMediation),
    // M3 attribution + difficulty — whitelisted or silently dropped.
    attribution: sanitizeAttribution(q.attribution),
    difficulty: sanitizeDifficulty(q.difficulty),
  };
}

function sanitizeSection(raw: unknown, idx: number): ExamSection {
  const s = isRecord(raw) ? raw : {};
  const rowId = str(s.rowId).trim() || String.fromCharCode(65 + (idx % 26)); // 'A', 'B', ...
  const category = str(s.majorCategory).trim();

  const questions = asRecordArray(s.questions).map((q, i) => sanitizeQuestion(q, rowId, i));

  const matchingColumnsRaw = isRecord(s.matchingColumns) ? s.matchingColumns : null;
  const columnA = matchingColumnsRaw ? asRecordArray(matchingColumnsRaw.columnA) : [];
  const columnB = matchingColumnsRaw ? asRecordArray(matchingColumnsRaw.columnB) : [];

  // Mined-template hints (advisory evidence) — whitelist or they silently
  // vanish on every save/update round-trip (same lesson as the receipts).
  const templateHints = asRecordArray(s.templateHints)
    .slice(0, 8)
    .map((h) => ({
      templateId: str(h.templateId).trim().slice(0, 40),
      suggestsType: str(h.suggestsType).trim().slice(0, 40),
      suggestsCategory: str(h.suggestsCategory).trim().slice(0, 20) || undefined,
      score: num(h.score, 0),
    }))
    .filter((h) => h.templateId && h.suggestsType);

  return {
    rowId,
    majorCategory: (VALID_MAJOR_CATEGORIES.has(category) ? category : 'General') as ExamSection['majorCategory'],
    title: str(s.title).trim() || undefined,
    persianInstruction: str(s.persianInstruction).trim() || undefined,
    englishInstruction: str(s.englishInstruction).trim() || undefined,
    markTotal: num(s.markTotal, questions.reduce((sum, q) => sum + q.mark, 0)),
    questions,
    hasWordBank: bool(s.hasWordBank),
    wordBank: strArray(s.wordBank).length > 0 ? strArray(s.wordBank) : undefined,
    hasPassage: bool(s.hasPassage),
    passageTitle: str(s.passageTitle).trim() || undefined,
    passageText: str(s.passageText).trim() || undefined,
    matchingColumns:
      columnA.length > 0 && columnB.length > 0
        ? {
            columnA: columnA.map((c, i) => ({
              id: (typeof c.id === 'number' || typeof c.id === 'string' ? c.id : i + 1) as string | number,
              text: str(c.text),
            })),
            columnB: columnB.map((c, i) => ({
              id: str(c.id).trim() || String(i + 1),
              text: str(c.text),
            })),
          }
        : undefined,
    templateHints: templateHints.length > 0 ? templateHints : undefined,
  };
}

function sanitizeAnomaly(raw: unknown, idx: number): ParsingAnomaly {
  const a = isRecord(raw) ? raw : {};
  const severity = str(a.severity).trim();
  return {
    id: str(a.id).trim() || genId(`anomaly-${idx + 1}`),
    severity: (VALID_ANOMALY_SEVERITIES.has(severity) ? severity : 'warning') as ParsingAnomaly['severity'],
    sectionRowId: str(a.sectionRowId).trim() || '-',
    questionNumber: typeof a.questionNumber === 'number' || typeof a.questionNumber === 'string' ? a.questionNumber : undefined,
    title: str(a.title).trim() || 'Unnamed anomaly',
    description: str(a.description),
    suggestedFix: str(a.suggestedFix),
    isResolved: bool(a.isResolved),
  };
}

// ---------- top-level normalizer ----------

export function sanitizeExam(raw: unknown, index = 0): ExamDocument {
  const d = isRecord(raw) ? raw : {};
  const filename = str(d.filename).trim() || `imported-exam-${index + 1}`;
  const sections = asRecordArray(d.sections).map((s, i) => sanitizeSection(s, i));
  const anomalies = asRecordArray(d.anomalies).map((a, i) => sanitizeAnomaly(a, i));

  const totalQuestions = num(d.totalQuestions, sections.reduce((sum, s) => sum + s.questions.length, 0));
  const totalMarks = num(
    d.totalMarks,
    sections.reduce((sum, s) => sum + s.markTotal, 0),
  );

  let confidenceScore = num(d.confidenceScore, 0);
  if (confidenceScore < 0) confidenceScore = 0;
  if (confidenceScore > 100) confidenceScore = 100;

  const parseStage = str(d.parseStage).trim();

  // Trust-architecture fields (best-effort pass-through with shape guards)
  const sourceFile = d.sourceFile instanceof Blob ? d.sourceFile : undefined;
  const invariants = isRecord(d.invariants) && Array.isArray(d.invariants.violations) ? (d.invariants as unknown as ExamDocument['invariants']) : undefined;
  const consensus = isRecord(d.consensus) && typeof d.consensus.agreementRate === 'number' ? (d.consensus as unknown as ExamDocument['consensus']) : undefined;
  const aiUsage = isRecord(d.aiUsage) && typeof d.aiUsage.totalTokens === 'number' ? (d.aiUsage as unknown as ExamDocument['aiUsage']) : undefined;
  const review = isRecord(d.review) && Array.isArray(d.review.changes) ? (d.review as unknown as ExamDocument['review']) : undefined;

  // Bulletproofing-round fields (#6/#9/#10/#20)
  const extraction = isRecord(d.extraction) && typeof d.extraction.score === 'number'
    ? (d.extraction as unknown as ExtractionQualityReport)
    : undefined;
  const trust = isRecord(d.trust) && typeof d.trust.verifiedPct === 'number'
    ? (d.trust as unknown as TrustSummary)
    : undefined;
  const parseTrace = isRecord(d.parseTrace) && Array.isArray(d.parseTrace.lines)
    ? ({
        lines: (d.parseTrace.lines as unknown[]).map((l) => str(l)).slice(0, 4000),
        rules: asRecordArray(d.parseTrace.rules).map((r) => ({
          id: str(r.id),
          name: str(r.name),
          kind: (str(r.kind).trim() || 'other') as ParseTraceSummary['rules'][number]['kind'],
          hits: num(r.hits, 0),
          meanConfidence: num(r.meanConfidence, 0),
        })),
        fallbackUsed: bool(d.parseTrace.fallbackUsed),
      } as ParseTraceSummary)
    : undefined;
  const schemaVersion = typeof d.schemaVersion === 'number' && Number.isFinite(d.schemaVersion) ? d.schemaVersion : undefined;

  // Pass-through receipts (shape-guarded). NOTE: these MUST be whitelisted here —
  // a missing key silently drops the receipt on every save/update round-trip.
  const jevReceipt =
    isRecord(d.jevReceipt) && typeof d.jevReceipt.ranAt === 'string'
      ? (d.jevReceipt as unknown as ExamDocument['jevReceipt'])
      : undefined;
  const parseVerifyReceipt =
    isRecord(d.parseVerifyReceipt) && typeof d.parseVerifyReceipt.ranAt === 'string'
      ? (d.parseVerifyReceipt as unknown as ExamDocument['parseVerifyReceipt'])
      : undefined;
  // Picture OCR annotations (verification context only) — whitelist or the
  // notes silently vanish on every save/update round-trip.
  const pictureOcrNotes = strArray(d.pictureOcrNotes)
    .slice(0, 20)
    .map((n) => str(n).slice(0, 2000))
    .filter(Boolean);

  // Vision images (Idea 3) — shape-guarded whitelist, same round-trip lesson.
  const images = asRecordArray(d.images).slice(0, 60).map(sanitizeImage).filter(Boolean) as ExamImage[];
  const visionReceiptRaw = isRecord(d.visionReceipt) ? d.visionReceipt : null;
  const visionMode = visionReceiptRaw && ['alts', 'transcribe'].includes(str(visionReceiptRaw.mode).trim())
    ? (str(visionReceiptRaw.mode).trim() as 'alts' | 'transcribe')
    : null;
  const visionReceipt =
    visionReceiptRaw && visionMode && typeof visionReceiptRaw.ranAt === 'string'
      ? ({
          ranAt: str(visionReceiptRaw.ranAt),
          mode: visionMode,
          provider: str(visionReceiptRaw.provider).slice(0, 40),
          model: str(visionReceiptRaw.model).slice(0, 120) || 'unknown',
          sent: num(visionReceiptRaw.sent, 0),
          cacheHits: num(visionReceiptRaw.cacheHits, 0),
          calls: num(visionReceiptRaw.calls, 0),
          placed: num(visionReceiptRaw.placed, 0),
          needsReview: num(visionReceiptRaw.needsReview, 0),
          unplaced: num(visionReceiptRaw.unplaced, 0),
          promptTokens: num(visionReceiptRaw.promptTokens, 0),
          completionTokens: num(visionReceiptRaw.completionTokens, 0),
          totalTokens: num(visionReceiptRaw.totalTokens, 0),
          baselineTokens: typeof visionReceiptRaw.baselineTokens === 'number' ? visionReceiptRaw.baselineTokens : undefined,
          warnings: strArray(visionReceiptRaw.warnings).slice(0, 12),
          error: str(visionReceiptRaw.error).trim() || undefined,
        } as ExamDocument['visionReceipt'])
      : undefined;

  // M2 answer-flow receipt — whitelisted or silently dropped on round-trip.
  const answerFlowReceiptRaw = isRecord(d.answerFlowReceipt) ? d.answerFlowReceipt : null;
  const answerFlowReceipt =
    answerFlowReceiptRaw && typeof answerFlowReceiptRaw.ranAt === 'string'
      ? ({
          ranAt: str(answerFlowReceiptRaw.ranAt),
          model: str(answerFlowReceiptRaw.model).slice(0, 120) || 'unknown',
          r1Picks: num(answerFlowReceiptRaw.r1Picks, 0),
          r3Produced: num(answerFlowReceiptRaw.r3Produced, 0),
          r3Agreed: num(answerFlowReceiptRaw.r3Agreed, 0),
          r3Mediated: num(answerFlowReceiptRaw.r3Mediated, 0),
          cacheHits: num(answerFlowReceiptRaw.cacheHits, 0),
          producerCalls: num(answerFlowReceiptRaw.producerCalls, 0),
          criticCalls: num(answerFlowReceiptRaw.criticCalls, 0),
          promptTokens: num(answerFlowReceiptRaw.promptTokens, 0),
          completionTokens: num(answerFlowReceiptRaw.completionTokens, 0),
          totalTokens: num(answerFlowReceiptRaw.totalTokens, 0),
          warnings: strArray(answerFlowReceiptRaw.warnings).slice(0, 12),
        } as AnswerFlowReceipt)
      : undefined;
  const answerKeyOnFile = sanitizeAnswerKey(d.answerKeyOnFile);

  return {
    id: str(d.id).trim() || genId('exam'),
    filename,
    filesize: str(d.filesize).trim() || undefined,
    parsedAt: str(d.parsedAt).trim() || new Date().toISOString(),
    header: sanitizeHeader(d.header, filename),
    sections,
    totalQuestions,
    totalMarks,
    anomalies,
    confidenceScore,
    needsReview: bool(d.needsReview),
    validationFlags: strArray(d.validationFlags).length > 0 ? strArray(d.validationFlags) : undefined,
    parseStage: (VALID_PARSE_STAGES.has(parseStage)
      ? parseStage
      : 'stage1_offline_unsolved') as ExamDocument['parseStage'],
    solvedAt: str(d.solvedAt).trim() || undefined,
    isAiSolved: bool(d.isAiSolved),
    sourceFile,
    provenanceCoverage: typeof d.provenanceCoverage === 'number' && Number.isFinite(d.provenanceCoverage) ? d.provenanceCoverage : undefined,
    invariants,
    consensus,
    aiUsage,
    review,
    mirrorOf: str(d.mirrorOf).trim() || undefined,
    mirrorVariant: str(d.mirrorVariant).trim() || undefined,
    schemaVersion,
    extraction,
    trust,
    parseTrace,
    brainReport: sanitizeBrainReport(d.brainReport),
    jevReceipt,
    parseVerifyReceipt,
    pictureOcrNotes: pictureOcrNotes.length > 0 ? pictureOcrNotes : undefined,
    images: images.length > 0 ? images : undefined,
    visionReceipt,
    answerFlowReceipt,
    answerKeyOnFile,
  };
}

/** Layout-brain verdict (utils/brainBridge.ts) — size-capped defensive copy. */
function sanitizeBrainReport(raw: unknown): ExamDocument['brainReport'] {
  if (!isRecord(raw)) return undefined;
  const stats = isRecord(raw.stats) ? raw.stats : {};
  return {
    mode: raw.mode === 'confirmed' || raw.mode === 'abstained' ? raw.mode : 'partial',
    sections: num(raw.sections, 0),
    confirmed: num(raw.confirmed, 0),
    fallbacks: num(raw.fallbacks, 0),
    sumMarks: typeof raw.sumMarks === 'number' && Number.isFinite(raw.sumMarks) ? raw.sumMarks : 0,
    printedTotal:
      typeof raw.printedTotal === 'number' && Number.isFinite(raw.printedTotal) ? raw.printedTotal : undefined,
    notes: strArray(raw.notes).slice(0, 40),
    stats: {
      bodySize: num(stats.bodySize, 0),
      headerCount: num(stats.headerCount, 0),
      letterCount: num(stats.letterCount, 0),
      marksTables: num(stats.marksTables, 0),
      sumOfMarks: num(stats.sumOfMarks, 0),
      printedTotal:
        typeof stats.printedTotal === 'number' && Number.isFinite(stats.printedTotal) ? stats.printedTotal : undefined,
    },
  };
}

/** Printed-key report (utils/answerKey.ts) — size-capped defensive copy. */
function sanitizeAnswerKey(raw: unknown): ExamDocument['answerKeyOnFile'] {
  if (!isRecord(raw) || raw.detected !== true) return undefined;
  const entries = asRecordArray(raw.entries)
    .slice(0, 200)
    .map((e) => ({
      number: num(e.number, 0),
      label: str(e.label).slice(0, 24),
      optionIndex: typeof e.optionIndex === 'number' && Number.isFinite(e.optionIndex) ? e.optionIndex : undefined,
      optionText: str(e.optionText).slice(0, 400) || undefined,
    }));
  const warnings = asRecordArray(raw.warnings)
    .slice(0, 100)
    .map((w) => ({
      type: str(w.type) as AnswerKeyWarning['type'],
      message: str(w.message).slice(0, 300),
      questionNumber: typeof w.questionNumber === 'number' && Number.isFinite(w.questionNumber) ? w.questionNumber : undefined,
    }));
  return {
    detected: true,
    source: 'on-file',
    via: raw.via === 'pattern' ? 'pattern' : 'banner',
    removedQuestions: num(raw.removedQuestions, 0),
    entries,
    applied: num(raw.applied, 0),
    warnings,
    appliedAt: str(raw.appliedAt).trim() || new Date().toISOString(),
  };
}

function sanitizeImage(raw: unknown): ExamImage | null {
  if (!isRecord(raw)) return null;
  const origin = str(raw.origin).trim();
  if (!['docx_media', 'pdf_embedded', 'page'].includes(origin)) return null;
  const status = str(raw.placementStatus).trim();
  const kind = str(raw.kind).trim();
  return {
    id: str(raw.id).trim().slice(0, 40) || genId('img'),
    contentHash: str(raw.contentHash).trim().slice(0, 80),
    origin: origin as ExamImage['origin'],
    page: typeof raw.page === 'number' && Number.isFinite(raw.page) ? raw.page : undefined,
    anchorIndex: typeof raw.anchorIndex === 'number' && Number.isFinite(raw.anchorIndex) ? raw.anchorIndex : undefined,
    bbox: isRecord(raw.bbox)
      ? {
          x: num(raw.bbox.x, 0),
          y: num(raw.bbox.y, 0),
          w: num(raw.bbox.w, 0),
          h: num(raw.bbox.h, 0),
        }
      : undefined,
    contextText: str(raw.contextText).slice(0, 400) || undefined,
    embeddedAlt: str(raw.embeddedAlt).slice(0, 200) || undefined,
    thumbnail: str(raw.thumbnail).startsWith('data:image/') ? str(raw.thumbnail).slice(0, 20000) : undefined,
    alt: str(raw.alt).slice(0, 1200) || undefined,
    kind: ['text', 'photo', 'diagram', 'unknown'].includes(kind) ? (kind as ExamImage['kind']) : undefined,
    confidence: typeof raw.confidence === 'number' && raw.confidence >= 0 && raw.confidence <= 1 ? raw.confidence : undefined,
    questionId: str(raw.questionId).trim().slice(0, 80) || undefined,
    placementConfidence:
      typeof raw.placementConfidence === 'number' && raw.placementConfidence >= 0 && raw.placementConfidence <= 1
        ? raw.placementConfidence
        : undefined,
    placementStatus: ['auto', 'review', 'manual', 'unplaced'].includes(status)
      ? (status as ExamImage['placementStatus'])
      : undefined,
    cached: bool(raw.cached),
    reviewed: bool(raw.reviewed),
    error: str(raw.error).slice(0, 300) || undefined,
    model: str(raw.model).slice(0, 120) || undefined,
  };
}

/**
 * Sanitize a list of documents (JSON import / storage load).
 * Non-object entries are dropped rather than crashing the app.
 */
export function sanitizeExamList(raw: unknown): ExamDocument[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter(isRecord)
    .map((item, idx) => {
      try {
        return sanitizeExam(item, idx);
      } catch (e) {
        console.warn('sanitizeExamList: dropped malformed exam entry', e);
        return null;
      }
    })
    .filter((e): e is ExamDocument => e !== null);
}
