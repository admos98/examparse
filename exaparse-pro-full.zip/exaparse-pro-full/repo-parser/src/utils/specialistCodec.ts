/**
 * specialistCodec — W1 of the SPECIALIST architecture: the SEMANTIC CODEC.
 *
 * Maps one exam line into the closed domain alphabet:
 *   ROLE    (14 classes — header_subject, row_opener, mark_token, ...)
 *   SUBJECT (9 classes — vocabulary, grammar, listening, ...)
 *
 * Two int8-quantized softmax heads over hashed char n-grams (FNV-1a, 2048
 * buckets; 1-3 grams + whole words) + 11 geometric features. This is the
 * component that READS: unlike the deterministic patterns it distills, it
 * stays calibrated on OCR-mangled / garbled text ("V0cabulary", reversed
 * glyph storage, confused digits) where regexes fail.
 *
 * 100% local, zero dependencies, microseconds per line. Fail-safe: if the
 * weights blob is missing/corrupt, codecReady() is false and callers fall
 * back to deterministic behavior (the S26 pattern).
 */
import { CODEC_WEIGHTS } from './specialistCodecWeights';

export const CODEC_ROLES = [...CODEC_WEIGHTS.roles] as string[];
export const CODEC_SUBJECTS = [...CODEC_WEIGHTS.subjects] as string[];
export const CODEC_BUCKETS = CODEC_WEIGHTS.buckets;
export const CODEC_NUM_FEATS = CODEC_WEIGHTS.numFeats;

export interface CodecFeats {
  size: number;
  bold: boolean;
  bbox: number[]; // [x0, y0, x1, y1]
  pageW: number;
  pageH: number;
  bodySize: number;
}

export interface CodecResult {
  role: string;
  roleP: number;
  subject: string;
  subjectP: number;
}

export interface CodecModel {
  roles: string[];
  subjects: string[];
  roleW: Int8Array[]; // per class row over buckets
  roleWScale: number[];
  roleNumW: Float32Array; // classes * numFeats
  roleB: Float32Array;
  subjW: Int8Array[];
  subjWScale: number[];
  subjNumW: Float32Array;
  subjB: Float32Array;
}

// ------------------------------------------------------------- base64 (pure)

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
function b64ToBytes(s: string): Uint8Array {
  const len = (s.length * 3) >> 2;
  const out = new Uint8Array(s.endsWith('==') ? len - 2 : s.endsWith('=') ? len - 1 : len);
  let buf = 0, bits = 0, p = 0;
  for (const ch of s) {
    const v = B64.indexOf(ch);
    if (v < 0) continue;
    buf = (buf << 6) | v;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      out[p++] = (buf >> bits) & 0xff;
    }
  }
  return out;
}

// ------------------------------------------------------------------- loading

let cached: CodecModel | null | undefined;

/**
 * Validate + decode a weights-like object. Exported for the fail-safe unit
 * tests: corrupt/truncated blobs must return null, never throw.
 */
export function codecValidate(w: unknown): CodecModel | null {
  try {
    const v = w as any;
    if (!v || v.version !== 1) throw new Error('version');
    if (typeof v.buckets !== 'number' || v.buckets <= 0) throw new Error('buckets');
    if (!Array.isArray(v.roles) || !Array.isArray(v.subjects)) throw new Error('classes');
    if (!Array.isArray(v.roleW) || v.roleW.length !== v.roles.length) throw new Error('roleW');
    if (!Array.isArray(v.subjW) || v.subjW.length !== v.subjects.length) throw new Error('subjW');
    if (!Array.isArray(v.roleWScale) || v.roleWScale.length !== v.roles.length) throw new Error('roleScale');
    if (!Array.isArray(v.subjWScale) || v.subjWScale.length !== v.subjects.length) throw new Error('subjScale');
    const decodeRows = (rows: string[]): Int8Array[] =>
      rows.map((r) => new Int8Array(b64ToBytes(String(r)).buffer));
    const f32 = (b64: string, n: number): Float32Array => {
      const bytes = b64ToBytes(String(b64));
      if (bytes.length !== n * 4) throw new Error('f32 len');
      return new Float32Array(bytes.buffer);
    };
    const NF = v.numFeats;
    const m: CodecModel = {
      roles: v.roles, subjects: v.subjects,
      roleW: decodeRows(v.roleW),
      roleWScale: v.roleWScale,
      roleNumW: f32(v.roleNumW, v.roles.length * NF),
      roleB: Float32Array.from(v.roleB),
      subjW: decodeRows(v.subjW),
      subjWScale: v.subjWScale,
      subjNumW: f32(v.subjNumW, v.subjects.length * NF),
      subjB: Float32Array.from(v.subjB),
    };
    for (const row of [...m.roleW, ...m.subjW]) if (row.length !== v.buckets) throw new Error('row len');
    if (!m.roles.length || !m.subjects.length) throw new Error('empty classes');
    return m;
  } catch {
    return null;
  }
}

/** Validated model, or null when weights are missing/corrupt (fail-safe). */
export function codecReady(): CodecModel | null {
  if (cached !== undefined) return cached;
  cached = codecValidate(CODEC_WEIGHTS);
  return cached;
}

/** Test hook: drop the cached model (next codecReady() re-validates). */
export function codecReset(): void {
  cached = undefined;
}

// ----------------------------------------------------------------- features

function fnv1a(s: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

export function foldForCodec(s: string): string {
  return s
    .replace(/\u064A/g, '\u06CC')
    .replace(/\u0643/g, '\u06A9')
    .replace(/[\u200c\u200f\u200e\uFEFF]/g, '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

/** char 1-3 grams + whole words -> bucket counts (mirror of the trainer). */
export function ngramBuckets(folded: string, buckets: number): Map<number, number> {
  const t = `^ ${folded} $`;
  const counts = new Map<number, number>();
  const bump = (h: number) => {
    const b = h % buckets;
    counts.set(b, Math.min((counts.get(b) ?? 0) + 1, 3));
  };
  for (let n = 1; n <= 3; n++) {
    for (let i = 0; i + n <= t.length; i++) bump(fnv1a(t.slice(i, i + n)));
  }
  for (const w of folded.split(' ').filter(Boolean)) if (w.length <= 18) bump(fnv1a('w:' + w));
  return counts;
}

/** Geometric features — MUST mirror scripts/specialist_labels.mts featsOf
 *  (drift is guarded by scripts/specialist_stress.ts). */
export function computeFeats(text: string, size: number, bold: boolean, bbox: number[], pageW: number, pageH: number, bodySize: number): number[] {
  const sizeRatio = Math.min(size / (bodySize || size || 12), 3) / 3;
  const xLeft = pageW ? Math.min(Math.max(bbox[0] / pageW, 0), 1) : 0;
  const yTop = pageH ? Math.min(Math.max(bbox[1] / pageH, 0), 1) : 0;
  const lenChars = Math.min(text.length, 60) / 60;
  const words = Math.min(text.split(/\s+/).filter(Boolean).length, 12) / 12;
  const hasDigit = /\d/.test(text) ? 1 : 0;
  const hasPersian = /[\u0600-\u06FF]/.test(text) ? 1 : 0;
  const veryShort = text.length <= 3 ? 1 : 0;
  const endColon = /[:\u061B]$/.test(text) ? 1 : 0;
  const startsLetterDot = /^[A-Za-z\u0627\u0628\u067E][.)\]-]\s/.test(text) ? 1 : 0;
  return [sizeRatio, bold ? 1 : 0, xLeft, yTop, lenChars, words, hasDigit, hasPersian, veryShort, endColon, startsLetterDot];
}

// ---------------------------------------------------------------- inference

function softmaxBest(
  W: Int8Array[], scales: number[], numW: Float32Array, b: Float32Array,
  buckets: Map<number, number>, feats: number[], classes: number, NF: number,
): { idx: number; p: number } {
  const z = new Float64Array(classes);
  let max = -Infinity;
  for (let c = 0; c < classes; c++) {
    const row = W[c];
    const scale = scales[c];
    let acc = b[c];
    for (const [bk, v] of buckets) acc += row[bk] * scale * v;
    const noff = c * NF;
    for (let f = 0; f < NF; f++) acc += numW[noff + f] * feats[f];
    z[c] = acc;
    if (acc > max) max = acc;
  }
  let sum = 0;
  for (let c = 0; c < classes; c++) { z[c] = Math.exp(z[c] - max); sum += z[c]; }
  let bi = 0, bp = -1;
  for (let c = 0; c < classes; c++) {
    const p = z[c] / sum;
    if (p > bp) { bp = p; bi = c; }
  }
  return { idx: bi, p: bp };
}

/**
 * Classify one line. Returns null when the model is disabled (fail-safe —
 * callers fall back to deterministic perception).
 */
export function codecClassify(text: string, f: CodecFeats): CodecResult | null {
  const m = codecReady();
  if (!m) return null;
  const folded = foldForCodec(text);
  const buckets = ngramBuckets(folded, CODEC_BUCKETS);
  const feats = computeFeats(text, f.size, f.bold, f.bbox, f.pageW, f.pageH, f.bodySize);
  const NF = CODEC_NUM_FEATS;
  const r = softmaxBest(m.roleW, m.roleWScale, m.roleNumW, m.roleB, buckets, feats, m.roles.length, NF);
  const s = softmaxBest(m.subjW, m.subjWScale, m.subjNumW, m.subjB, buckets, feats, m.subjects.length, NF);
  return { role: m.roles[r.idx], roleP: r.p, subject: m.subjects[s.idx], subjectP: s.p };
}
