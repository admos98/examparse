/**
 * specialistStructure — W2 of the SPECIALIST architecture: the STRUCTURE
 * TRANSFORMER runtime (forward-only).
 *
 * A causal decoder over codec-symbol tokens (role x subject x sizeBucket x
 * bold) predicting per-line STRUCTURAL EVENTS: continue | section_start |
 * row_start | key_start | total | noise. This is the in-context component:
 * it conditions on the document so far, so per-document conventions
 * ("sections numbered 1..18", "letters restart per part", key sheets) shape
 * its predictions — the LLM behavior the deterministic patterns lack.
 *
 * 100% local, pure TS, int8-quantized weights (~100k parameters, 139KB
 * source), microseconds-to-milliseconds per window. Fail-safe: corrupt
 * weights -> structureReady() is null and callers fall back to the
 * deterministic brain (the S26 pattern). The runtime forward is pinned to
 * the trainer's quantized reference (canonProbs, asserted by
 * scripts/specstruct_eval.mts within 1e-3).
 */
import { STRUCT_WEIGHTS } from './specialistStructureWeights';

export const STRUCT_EVENTS = [...STRUCT_WEIGHTS.events] as string[];

export interface StructModel {
  E: Float64Array; P: Float64Array;
  lnInG: Float64Array; lnInB: Float64Array;
  layers: {
    Wq: Float64Array; bq: Float64Array; Wk: Float64Array; bk: Float64Array;
    Wv: Float64Array; bv: Float64Array; Wo: Float64Array; bo: Float64Array;
    W1: Float64Array; b1: Float64Array; W2: Float64Array; b2: Float64Array;
    ln1g: Float64Array; ln1b: Float64Array; ln2g: Float64Array; ln2b: Float64Array;
  }[];
  Wh: Float64Array; bh: Float64Array;
  D: number; L: number; H: number; HD: number; FF: number; CTX: number;
  N_EVENTS: number; VOCAB: number; PAD: number; BOS: number;
}

// ------------------------------------------------------------- base64 (pure)

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
function b64ToBytes(s: string): Uint8Array {
  const len = (s.length * 3) >> 2;
  const out = new Uint8Array(s.endsWith('==') ? len - 2 : s.endsWith('=') ? len - 1 : len);
  let buf = 0, bits = 0, p = 0;
  for (const ch of s) {
    const v = B64.indexOf(ch);
    if (v < 0) continue;
    buf = (buf << 6) | v;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      out[p++] = (buf >> bits) & 0xff;
    }
  }
  return out;
}

function deq(t: { data: string; scale: number }): Float64Array {
  const bytes = b64ToBytes(t.data);
  const i8 = new Int8Array(bytes.buffer, bytes.byteOffset, bytes.length);
  return Float64Array.from(i8, (v) => v * t.scale);
}
function f32(b64: string): Float64Array {
  const bytes = b64ToBytes(b64);
  return Float64Array.from(new Float32Array(bytes.buffer, bytes.byteOffset, bytes.length / 4));
}

// ------------------------------------------------------------------- loading

let cached: StructModel | null | undefined;

/** Validate + decode a weights-like object; null on anything corrupt. */
export function structureValidate(w: unknown): StructModel | null {
  try {
    const v = w as any;
    if (!v || v.version !== 1) throw new Error('version');
    const D = v.dModel, L = v.nLayers, H = v.nHeads, FF = v.ffn, CTX = v.ctx;
    if (!D || !L || !H || !FF || !CTX) throw new Error('dims');
    if (!Array.isArray(v.events) || !Array.isArray(v.layers) || v.layers.length !== L) throw new Error('layers');
    const m: StructModel = {
      E: deq(v.E), P: deq(v.P),
      lnInG: f32(v.lnInG), lnInB: f32(v.lnInB),
      layers: v.layers.map((l: any) => ({
        Wq: deq(l.Wq), bq: f32(l.bq), Wk: deq(l.Wk), bk: f32(l.bk),
        Wv: deq(l.Wv), bv: f32(l.bv), Wo: deq(l.Wo), bo: f32(l.bo),
        W1: deq(l.W1), b1: f32(l.b1), W2: deq(l.W2), b2: f32(l.b2),
        ln1g: f32(l.ln1g), ln1b: f32(l.ln1b), ln2g: f32(l.ln2g), ln2b: f32(l.ln2b),
      })),
      Wh: deq(v.Wh), bh: f32(v.bh),
      D, L, H, HD: D / H, FF, CTX,
      N_EVENTS: v.events.length, VOCAB: v.vocab, PAD: v.pad, BOS: v.bos,
    };
    if (m.E.length !== m.VOCAB * D || m.P.length !== CTX * D) throw new Error('emb dims');
    if (m.Wh.length !== D * m.N_EVENTS) throw new Error('head dims');
    return m;
  } catch {
    return null;
  }
}

/** Validated model, or null when weights are missing/corrupt (fail-safe). */
export function structureReady(): StructModel | null {
  if (cached !== undefined) return cached;
  cached = structureValidate(STRUCT_WEIGHTS);
  return cached;
}

export function structureReset(): void {
  cached = undefined;
}

/** token composition — MUST mirror scripts/specialist_net.mts encodeToken */
export function encodeToken(roleIdx: number, subjIdx: number, sizeBucket: number, bold: boolean): number {
  return ((roleIdx * 9 + subjIdx) * 5 + sizeBucket) * 2 + (bold ? 1 : 0);
}

// ------------------------------------------------------------------- forward

function layerNorm(x: Float64Array, T: number, g: Float64Array, b: Float64Array, D: number): Float64Array {
  const out = new Float64Array(T * D);
  for (let i = 0; i < T; i++) {
    const off = i * D;
    let mu = 0;
    for (let d = 0; d < D; d++) mu += x[off + d];
    mu /= D;
    let varr = 0;
    for (let d = 0; d < D; d++) { const dv = x[off + d] - mu; varr += dv * dv; }
    const std = Math.sqrt(varr / D + 1e-5);
    for (let d = 0; d < D; d++) out[off + d] = ((x[off + d] - mu) / std) * g[d] + b[d];
  }
  return out;
}

function forwardLogits(m: StructModel, tokens: readonly number[]): Float64Array {
  const T = tokens.length, D = m.D;
  let cur: Float64Array<ArrayBufferLike> = new Float64Array(T * D);
  for (let i = 0; i < T; i++) {
    const tok = tokens[i];
    if (tok === m.PAD) continue;
    for (let d = 0; d < D; d++) cur[i * D + d] = m.E[tok * D + d] + m.P[i * D + d];
  }
  cur = layerNorm(cur, T, m.lnInG, m.lnInB, D);
  for (let l = 0; l < m.L; l++) {
    const L = m.layers[l];
    const q = new Float64Array(T * D), k = new Float64Array(T * D), v = new Float64Array(T * D);
    for (let i = 0; i < T; i++) {
      if (tokens[i] === m.PAD) continue;
      for (let d = 0; d < D; d++) {
        let sq = L.bq[d], sk = L.bk[d], sv = L.bv[d];
        for (let e = 0; e < D; e++) {
          const xv = cur[i * D + e];
          sq += xv * L.Wq[e * D + d];
          sk += xv * L.Wk[e * D + d];
          sv += xv * L.Wv[e * D + d];
        }
        q[i * D + d] = sq; k[i * D + d] = sk; v[i * D + d] = sv;
      }
    }
    const attnOut = new Float64Array(T * D);
    const scale = 1 / Math.sqrt(m.HD);
    for (let h = 0; h < m.H; h++) {
      const hoff = h * m.HD;
      for (let i = 0; i < T; i++) {
        if (tokens[i] === m.PAD) continue;
        let max = -Infinity;
        const row: number[] = [];
        for (let j = 0; j <= i; j++) {
          if (tokens[j] === m.PAD) { row[j] = 0; continue; }
          let s = 0;
          for (let d = 0; d < m.HD; d++) s += q[i * D + hoff + d] * k[j * D + hoff + d];
          row[j] = s * scale;
          if (row[j] > max) max = row[j];
        }
        let sum = 0;
        for (let j = 0; j <= i; j++) if (tokens[j] !== m.PAD) { row[j] = Math.exp(row[j] - max); sum += row[j]; }
        for (let d = 0; d < m.HD; d++) {
          let acc = 0;
          for (let j = 0; j <= i; j++) if (tokens[j] !== m.PAD) acc += (row[j] / sum) * v[j * D + hoff + d];
          attnOut[i * D + hoff + d] = acc;
        }
      }
    }
    const proj = new Float64Array(T * D);
    for (let i = 0; i < T; i++) {
      if (tokens[i] === m.PAD) continue;
      for (let d = 0; d < D; d++) {
        let acc = L.bo[d];
        for (let e = 0; e < D; e++) acc += attnOut[i * D + e] * L.Wo[e * D + d];
        proj[i * D + d] = acc;
      }
    }
    const s1 = new Float64Array(T * D);
    for (let i = 0; i < T * D; i++) s1[i] = cur[i] + proj[i];
    const y1 = layerNorm(s1, T, L.ln1g, L.ln1b, D);
    const ffnOut = new Float64Array(T * D);
    for (let i = 0; i < T; i++) {
      if (tokens[i] === m.PAD) continue;
      for (let f = 0; f < m.FF; f++) {
        let acc = L.b1[f];
        for (let d = 0; d < D; d++) acc += y1[i * D + d] * L.W1[d * m.FF + f];
        if (acc > 0) {
          for (let d = 0; d < D; d++) ffnOut[i * D + d] += acc * L.W2[f * D + d];
        }
      }
      for (let d = 0; d < D; d++) ffnOut[i * D + d] += L.b2[d];
    }
    const s2 = new Float64Array(T * D);
    for (let i = 0; i < T * D; i++) s2[i] = y1[i] + ffnOut[i];
    cur = layerNorm(s2, T, L.ln2g, L.ln2b, D);
  }
  const logits = new Float64Array(T * m.N_EVENTS);
  for (let i = 0; i < T; i++) {
    if (tokens[i] === m.PAD) continue;
    for (let e = 0; e < m.N_EVENTS; e++) {
      let acc = m.bh[e];
      for (let d = 0; d < D; d++) acc += cur[i * D + d] * m.Wh[d * m.N_EVENTS + e];
      logits[i * m.N_EVENTS + e] = acc;
    }
  }
  return logits;
}

export interface StructureResult {
  /** per input line: argmax event index + its probability */
  events: { event: number; p: number }[];
  /** full averaged probability distributions per line (drift checks, receipts) */
  probs: number[][];
}

/**
 * Predict structural events for a token sequence. Sequences longer than the
 * training context are processed in sliding windows (BOS-anchored, 50% overlap)
 * with averaged probabilities. Returns null when the model is disabled.
 */
export function structureEvents(tokens: readonly number[]): StructureResult | null {
  const m = structureReady();
  if (!m) return null;
  const n = tokens.length;
  if (!n) return { events: [], probs: [] };
  const probs: Float64Array = new Float64Array(n * m.N_EVENTS);
  const weight = new Float64Array(n);
  const CTXm1 = m.CTX - 1;
  for (let start = 0; start < n; start += Math.max(CTXm1 >> 1, 1)) {
    const slice = tokens.slice(start, start + CTXm1);
    const win = [m.BOS, ...slice, ...new Array(Math.max(CTXm1 - slice.length, 0)).fill(m.PAD)];
    const logits = forwardLogits(m, win);
    for (let i = 0; i < slice.length; i++) {
      const gi = start + i;
      if (gi >= n) break;
      const off = (i + 1) * m.N_EVENTS;
      let max = -Infinity;
      for (let e = 0; e < m.N_EVENTS; e++) if (logits[off + e] > max) max = logits[off + e];
      let sum = 0;
      const sm = new Float64Array(m.N_EVENTS);
      for (let e = 0; e < m.N_EVENTS; e++) { sm[e] = Math.exp(logits[off + e] - max); sum += sm[e]; }
      for (let e = 0; e < m.N_EVENTS; e++) probs[gi * m.N_EVENTS + e] += sm[e] / sum;
      weight[gi] += 1;
    }
    if (start + CTXm1 >= n) break;
  }
  const events: { event: number; p: number }[] = [];
  const probsOut: number[][] = [];
  for (let i = 0; i < n; i++) {
    let bi = 0, bv = -1;
    const w = weight[i] || 1;
    const dist: number[] = [];
    for (let e = 0; e < m.N_EVENTS; e++) {
      const p = probs[i * m.N_EVENTS + e] / w;
      dist.push(p);
      if (p > bv) { bv = p; bi = e; }
    }
    events.push({ event: bi, p: bv });
    probsOut.push(dist);
  }
  return { events, probs: probsOut };
}
