import { ExamDocument } from '../types/exam';
import { ProviderConfig, DEFAULT_PROVIDER_CONFIG, JevConfig, DEFAULT_JEV_CONFIG, VisionConfig, DEFAULT_VISION_CONFIG } from '../types/settings';
import { sanitizeExam, sanitizeExamList } from './sanitizeExam';
import { MOTAHARI_STAGE1_OFFLINE, BUSHEHR_STAGE1_OFFLINE } from '../data/offlineSampleData';
import { MOTAHARI_GRADE9_EXAM, BUSHEHR_GRADE12_EXAM } from '../data/sampleExamData';

/**
 * Strip fields that cannot survive JSON serialization (e.g. the original file
 * Blob) before writing to localStorage or exporting JSON backups.
 */
export function stripHeavyFields(exam: ExamDocument): ExamDocument {
  const { sourceFile, ...rest } = exam;
  return rest as ExamDocument;
}

const DB_NAME = 'ExaParseStorage';
const DB_VERSION = 1;
const EXAMS_STORE = 'exams';
const SETTINGS_STORE = 'settings';
const SETTINGS_KEY = 'provider_config';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      return reject(new Error('IndexedDB not supported'));
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = (e) => {
      const db = (e.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(EXAMS_STORE)) {
        db.createObjectStore(EXAMS_STORE, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(SETTINGS_STORE)) {
        db.createObjectStore(SETTINGS_STORE);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Load all saved exams from IndexedDB (with localStorage fallback).
 * If empty on first boot, seeds with the initial sample exams.
 */
export async function loadExams(): Promise<ExamDocument[]> {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const tx = db.transaction(EXAMS_STORE, 'readonly');
      const store = tx.objectStore(EXAMS_STORE);
      const req = store.getAll();
      req.onsuccess = () => {
        const results = sanitizeExamList(req.result);
        if (results.length > 0) {
          resolve(results);
        } else {
          // Seed initial samples
          const defaultExams: ExamDocument[] = [
            MOTAHARI_STAGE1_OFFLINE,
            MOTAHARI_GRADE9_EXAM,
            BUSHEHR_STAGE1_OFFLINE,
            BUSHEHR_GRADE12_EXAM,
          ];
          saveExams(defaultExams).catch(() => {});
          resolve(defaultExams);
        }
      };
      req.onerror = () => {
        resolve(loadExamsFromLocalStorage());
      };
    });
  } catch (err) {
    return loadExamsFromLocalStorage();
  }
}

function loadExamsFromLocalStorage(): ExamDocument[] {
  try {
    const data = localStorage.getItem('exaparse_exams');
    if (data) {
      const parsed = JSON.parse(data);
      const sanitized = sanitizeExamList(parsed);
      if (sanitized.length > 0) {
        return sanitized;
      }
    }
  } catch (e) {
    console.warn('Failed to load exams from localStorage', e);
  }
  return [
    MOTAHARI_STAGE1_OFFLINE,
    MOTAHARI_GRADE9_EXAM,
    BUSHEHR_STAGE1_OFFLINE,
    BUSHEHR_GRADE12_EXAM,
  ];
}

/**
 * Save all exams in IndexedDB and localStorage
 */
export async function saveExams(exams: ExamDocument[]): Promise<void> {
  // Sync to localStorage (Blob sourceFile cannot be JSON-serialized — strip it)
  try {
    localStorage.setItem('exaparse_exams', JSON.stringify(exams.map(stripHeavyFields)));
  } catch (e) {
    console.warn('localStorage quota exceeded or unavailable', e);
  }

  try {
    const db = await openDB();
    const tx = db.transaction(EXAMS_STORE, 'readwrite');
    const store = tx.objectStore(EXAMS_STORE);
    store.clear();
    for (const exam of exams) {
      store.put(exam);
    }
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('Failed to save to IndexedDB', err);
  }
}

/**
 * Save or update single exam
 */
export async function saveExam(exam: ExamDocument): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction(EXAMS_STORE, 'readwrite');
    const store = tx.objectStore(EXAMS_STORE);
    store.put(exam);
  } catch (e) {
    console.warn('IndexedDB put error', e);
  }

  // Also update in localStorage (strip the source-file Blob first)
  try {
    const current = loadExamsFromLocalStorage();
    const existingIndex = current.findIndex((e) => e.id === exam.id);
    if (existingIndex >= 0) {
      current[existingIndex] = stripHeavyFields(exam);
    } else {
      current.unshift(stripHeavyFields(exam));
    }
    localStorage.setItem('exaparse_exams', JSON.stringify(current));
  } catch (e) {
    // ignore
  }
}

/**
 * Delete an exam by ID
 */
export async function deleteExam(id: string): Promise<void> {
  try {
    const db = await openDB();
    const tx = db.transaction(EXAMS_STORE, 'readwrite');
    const store = tx.objectStore(EXAMS_STORE);
    store.delete(id);
  } catch (e) {
    console.warn('IndexedDB delete error', e);
  }

  try {
    const current = loadExamsFromLocalStorage();
    const filtered = current.filter((e) => e.id !== id);
    localStorage.setItem('exaparse_exams', JSON.stringify(filtered));
  } catch (e) {
    // ignore
  }
}

/**
 * Load provider settings
 */
export async function loadSettings(): Promise<ProviderConfig> {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const tx = db.transaction(SETTINGS_STORE, 'readonly');
      const store = tx.objectStore(SETTINGS_STORE);
      const req = store.get(SETTINGS_KEY);
      req.onsuccess = () => {
        if (req.result) {
          resolve({ ...DEFAULT_PROVIDER_CONFIG, ...req.result });
        } else {
          resolve(loadSettingsFromLocalStorage());
        }
      };
      req.onerror = () => resolve(loadSettingsFromLocalStorage());
    });
  } catch (err) {
    return loadSettingsFromLocalStorage();
  }
}

function loadSettingsFromLocalStorage(): ProviderConfig {
  try {
    const val = localStorage.getItem('exaparse_provider_config');
    if (val) {
      return { ...DEFAULT_PROVIDER_CONFIG, ...JSON.parse(val) };
    }
  } catch (e) {
    // ignore
  }
  return DEFAULT_PROVIDER_CONFIG;
}

/**
 * Save provider settings
 */
export async function saveSettings(settings: ProviderConfig): Promise<void> {
  try {
    localStorage.setItem('exaparse_provider_config', JSON.stringify(settings));
  } catch (e) {
    // ignore
  }

  try {
    const db = await openDB();
    const tx = db.transaction(SETTINGS_STORE, 'readwrite');
    const store = tx.objectStore(SETTINGS_STORE);
    store.put(settings, SETTINGS_KEY);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IndexedDB saveSettings error', err);
  }
}

/**
 * Jev judge settings (separate key — optional feature, backward compatible).
 * localStorage primary (same pattern as provider config), IndexedDB ignored:
 * the key is small and must survive without schema migrations.
 */
const JEV_SETTINGS_KEY = 'exaparse_jev_config';

export function loadJevConfig(): JevConfig {
  try {
    const val = localStorage.getItem(JEV_SETTINGS_KEY);
    if (val) {
      return { ...DEFAULT_JEV_CONFIG, ...JSON.parse(val) };
    }
  } catch {
    // ignore
  }
  return DEFAULT_JEV_CONFIG;
}

export function saveJevConfig(config: JevConfig): void {
  try {
    localStorage.setItem(JEV_SETTINGS_KEY, JSON.stringify(config));
  } catch {
    // ignore quota errors
  }
}

/**
 * Vision (image understanding) settings — same pattern as the Jev config:
 * localStorage primary, small, must survive without schema migrations.
 * NOTE: no API key lives here — vision reuses the provider key sent per-request.
 */
const VISION_SETTINGS_KEY = 'exaparse_vision_config';

export function loadVisionConfig(): VisionConfig {
  try {
    const val = localStorage.getItem(VISION_SETTINGS_KEY);
    if (val) {
      return { ...DEFAULT_VISION_CONFIG, ...JSON.parse(val) };
    }
  } catch {
    // ignore
  }
  return DEFAULT_VISION_CONFIG;
}

export function saveVisionConfig(config: VisionConfig): void {
  try {
    localStorage.setItem(VISION_SETTINGS_KEY, JSON.stringify(config));
  } catch {
    // ignore quota errors
  }
}

/**
 * Export full exam library as formatted JSON string
 */
export function exportLibraryJson(exams: ExamDocument[]): string {
  const payload = {
    app: 'ExaParse Pro',
    version: '2.1.0',
    exportedAt: new Date().toISOString(),
    totalExams: exams.length,
    exams: exams.map(stripHeavyFields),
  };
  return JSON.stringify(payload, null, 2);
}

/**
 * Import exams from JSON string
 */
export function importLibraryJson(jsonStr: string): ExamDocument[] {
  const parsed = JSON.parse(jsonStr);
  let importedExams: ExamDocument[] = [];
  if (Array.isArray(parsed)) {
    importedExams = parsed;
  } else if (parsed && Array.isArray(parsed.exams)) {
    importedExams = parsed.exams;
  } else if (parsed && parsed.id && parsed.sections) {
    importedExams = [parsed];
  } else {
    throw new Error('Invalid JSON format: Expected ExamDocument or array of exams.');
  }

  // Normalize every entry defensively: old backups or foreign tools may omit
  // `header` / `sections` fields that the UI dereferences directly.
  const sanitized = sanitizeExamList(importedExams);
  if (sanitized.length === 0 && importedExams.length > 0) {
    throw new Error('No valid exam documents could be parsed from this file.');
  }

  // Ensure unique IDs
  return sanitized.map((doc, idx) => ({
    ...doc,
    id: doc.id ? `${doc.id}-imported-${idx}` : `exam-${Date.now()}-${idx}`,
  }));
}
