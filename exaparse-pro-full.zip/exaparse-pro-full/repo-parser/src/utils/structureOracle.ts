/**
 * structureOracle.ts — W2 STRUCTURE TRANSFORMER, runtime (shipped).
 *
 * The Specialist architecture's second stage: a tiny causal decoder over the
 * W1 semantic codec's symbol stream that predicts the next STRUCTURAL EVENT
 * per line (SEC / ROW / MARK / KEY / TOTAL / PASS / CONT), then decodes
 * those events into a proposed sectioning — a full BrainResult the existing
 * bridge gate can judge with the SAME verification the layout brain's own
 * proposals face (coverage >= 60%, marks closure, full confirmation).
 *
 * Charter wiring (unchanged by this module):
 *   - NETWORK PROPOSES, JEV DISPOSES: this module never drives a parse by
 *     itself; brainStep only offers its output to bridgeBrainResult when the
 *     deterministic brain's own drive gate refused. Worst case = status quo.
 *   - Zero open-world surface: events come from a closed alphabet; every
 *     mark value, letter, subject and total is read deterministically from
 *     line text. The network only says WHERE, never WHAT.
 *   - S26 fail-safe: any weight-decode failure throws OracleUnavailable;
 *     callers fall back to current behavior.
 */
import { Buffer } from 'node:buffer';
import {
  STRUCTURE_CFG,
  STRUCTURE_THRESHOLDS,
  STRUCTURE_TENSORS,
} from './structureWeights';
import { runCodec, SUBJECTS, type CodecDocResult } from './semanticCodec';
import { geomSummaryToken, normText } from './codecFeatures';
import {
  type BrainDoc,
  type BrainResult,
  type BrainSection,
  type BrainRow,
  type BrainLine,
  matchSubject,
  toLatinDigits,
  isRowLetterToken,
  letterRank,
} from './layoutBrain';

export class OracleUnavailable extends Error {}

// ---------------------------------------------------------------- weights
type TensorMap = Map<string, { rows: number; cols: number; p: Float32Array }>;
let TM: TensorMap | null = null;

function loadTensors(): TensorMap {
  if (TM) return TM;
  const map: TensorMap = new Map();
  for (const t of STRUCTURE_TENSORS) {
    const raw = Buffer.from(t.d, 'base64');
    if (raw.length !== t.r * t.c)
      throw new OracleUnavailable(`oracle weights: ${t.n} length ${raw.length} != ${t.r * t.c}`);
    const q = new Int8Array(raw.buffer, raw.byteOffset, raw.length);
    const p = new Float32Array(t.r * t.c);
    for (let i = 0; i < p.length; i++) p[i] = q[i] * t.s;
    map.set(t.n, { rows: t.r, cols: t.c, p });
  }
  const need = ['Er', 'Es', 'Ei', 'Eg', 'P', 'lnL', 'We', 'be', 'Ws', 'bs'];
  for (const n of need) if (!map.has(n)) throw new OracleUnavailable(`oracle weights: missing ${n}`);
  for (let l = 0; l < STRUCTURE_CFG.layers; l++)
    for (const n of ['lnA', 'Wq', 'bq', 'Wk', 'bk', 'Wv', 'bv', 'Wo', 'bo', 'lnF', 'W1', 'b1', 'W2', 'b2'])
      if (!map.has(`L${l}.${n}`)) throw new OracleUnavailable(`oracle weights: missing L${l}.${n}`);
  TM = map;
  return map;
}

const EV_IDX = { CONT: 0, SEC: 1, ROW: 2, MARK: 3, KEY: 4, TOTAL: 5, PASS: 6 } as const;

function hashG(tok: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < tok.length; i++) {
    h ^= tok.charCodeAt(i);
    h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
  }
  return h % 64;
}

// ------------------------------------------------------------- transformer
/**
 * Causal forward over one window of the symbol stream. Every intermediate
 * gets its own named buffer (no aliasing — the lesson from the trainer).
 * Writes event probabilities into probs[Tn x nEv].
 */
function forwardWindow(m: TensorMap, w: WinInputs, probs: Float32Array): void {
  const { D, heads, ff, layers, nEv } = STRUCTURE_CFG;
  const dh = D / heads;
  const Tn = w.role.length;
  const g = (n: string) => m.get(n)!.p;

  // buffers
  const x = new Float32Array(Tn * D);
  const a1 = new Float32Array(Tn * D);
  const Q = new Float32Array(Tn * D);
  const K = new Float32Array(Tn * D);
  const V = new Float32Array(Tn * D);
  const O = new Float32Array(Tn * D);
  const att = new Float32Array(Tn * D);
  const h1 = new Float32Array(Tn * D);
  const a2 = new Float32Array(Tn * D);
  const f1 = new Float32Array(Tn * ff);
  const f2 = new Float32Array(Tn * D);
  const h2 = new Float32Array(Tn * D);
  const hf = new Float32Array(Tn * D);
  const logits = new Float32Array(Tn * nEv);

  // embeddings
  const Er = g('Er'), Es = g('Es'), Ei = g('Ei'), Eg = g('Eg'), P = g('P');
  for (let t = 0; t < Tn; t++) {
    const ro = w.role[t] * D, so = w.subj[t] * D, io = w.instr[t] * D, go = w.geom[t] * D;
    for (let k = 0; k < D; k++)
      x[t * D + k] = Er[ro + k] + Es[so + k] + Ei[io + k] + Eg[go + k] + P[t * D + k];
  }

  const lin = (inp: Float32Array, W: Float32Array, b: Float32Array, out: Float32Array, I: number, N: number) => {
    for (let t = 0; t < Tn; t++) {
      for (let n = 0; n < N; n++) out[t * N + n] = b[n];
      for (let i = 0; i < I; i++) {
        const v = inp[t * I + i];
        if (v === 0) continue;
        const wOff = i * N;
        for (let n = 0; n < N; n++) out[t * N + n] += v * W[wOff + n];
      }
    }
  };
  const lnFwd = (inp: Float32Array, out: Float32Array, lnT: Float32Array) => {
    for (let t = 0; t < Tn; t++) {
      const o = t * D;
      let mu = 0;
      for (let k = 0; k < D; k++) mu += inp[o + k];
      mu /= D;
      let va = 0;
      for (let k = 0; k < D; k++) {
        const dv = inp[o + k] - mu;
        va += dv * dv;
      }
      const rs = 1 / Math.sqrt(va / D + 1e-5);
      for (let k = 0; k < D; k++) out[o + k] = (inp[o + k] - mu) * rs * lnT[k] + lnT[D + k];
    }
  };

  let stream: Float32Array = x;
  for (let l = 0; l < layers; l++) {
    lnFwd(stream, a1, g(`L${l}.lnA`));
    lin(a1, g(`L${l}.Wq`), g(`L${l}.bq`), Q, D, D);
    lin(a1, g(`L${l}.Wk`), g(`L${l}.bk`), K, D, D);
    lin(a1, g(`L${l}.Wv`), g(`L${l}.bv`), V, D, D);
    const scale = 1 / Math.sqrt(dh);
    for (let hh = 0; hh < heads; hh++) {
      const hq = hh * dh;
      for (let t = 0; t < Tn; t++) {
        const scores = new Array<number>(t + 1);
        let mx = -Infinity;
        for (let u = 0; u <= t; u++) {
          let dot = 0;
          for (let k = 0; k < dh; k++) dot += Q[t * D + hq + k] * K[u * D + hq + k];
          scores[u] = dot * scale;
          if (scores[u] > mx) mx = scores[u];
        }
        let sum = 0;
        for (let u = 0; u <= t; u++) {
          scores[u] = Math.exp(scores[u] - mx);
          sum += scores[u];
        }
        for (let k = 0; k < dh; k++) {
          let acc = 0;
          for (let u = 0; u <= t; u++) acc += (scores[u] / sum) * V[u * D + hq + k];
          O[t * D + hq + k] = acc;
        }
      }
    }
    lin(O, g(`L${l}.Wo`), g(`L${l}.bo`), att, D, D);
    for (let i = 0; i < Tn * D; i++) h1[i] = stream[i] + att[i];
    lnFwd(h1, a2, g(`L${l}.lnF`));
    lin(a2, g(`L${l}.W1`), g(`L${l}.b1`), f1, D, ff);
    for (let i = 0; i < Tn * ff; i++) f1[i] = f1[i] > 0 ? f1[i] : 0;
    lin(f1, g(`L${l}.W2`), g(`L${l}.b2`), f2, ff, D);
    for (let i = 0; i < Tn * D; i++) h2[i] = h1[i] + f2[i];
    stream = h2;
  }

  lnFwd(stream, hf, g('lnL'));
  lin(hf, g('We'), g('be'), logits, D, nEv);

  for (let t = 0; t < Tn; t++) {
    let mx = -Infinity;
    for (let k = 0; k < nEv; k++) mx = Math.max(mx, logits[t * nEv + k]);
    let sum = 0;
    for (let k = 0; k < nEv; k++) sum += Math.exp(logits[t * nEv + k] - mx);
    for (let k = 0; k < nEv; k++) probs[t * nEv + k] = Math.exp(logits[t * nEv + k] - mx) / sum;
  }
}

interface WinInputs {
  role: Int32Array;
  subj: Int32Array;
  instr: Int32Array;
  geom: Int32Array;
}

/** Sliding-window event probabilities over the whole doc (CTX stride, no
 *  overlap — the trainer evaluated the same way; positions deep in a long
 *  window keep their full left context). */
function docEventProbs(m: TensorMap, codec: CodecDocResult, lines: BrainLine[]): { probs: Float32Array; nEv: number } {
  const n = lines.length;
  const nEv = STRUCTURE_CFG.nEv;
  const ctx = STRUCTURE_CFG.ctx;
  const probs = new Float32Array(n * nEv);
  const pool = new Map<number, Float32Array>();
  for (let start = 0; start < n; start += ctx) {
    const len = Math.min(ctx, n - start);
    if (len < 2 && start > 0) break;
    const role = new Int32Array(len);
    const subj = new Int32Array(len);
    const instr = new Int32Array(len);
    const geom = new Int32Array(len);
    for (let i = 0; i < len; i++) {
      const cl = codec.lines[start + i];
      role[i] = cl.role;
      subj[i] = cl.subj;
      instr[i] = cl.instr;
      geom[i] = hashG(geomSummaryToken(codec.geoms[start + i], normText(lines[start + i].text)));
    }
    let p = pool.get(len);
    if (!p) {
      p = new Float32Array(len * nEv);
      pool.set(len, p);
    }
    forwardWindow(m, { role, subj, instr, geom }, p);
    probs.set(p.subarray(0, len * nEv), start * nEv);
  }
  return { probs, nEv };
}

// ------------------------------------------------------------------ decode
function parseMarkValue(t: string): number | undefined {
  const s = toLatinDigits(t).replace(/[^\d.]/g, '');
  const mT = s.match(/^(\d{1,2})(?:\.(\d{1,2}))?$/);
  if (!mT) return undefined;
  const v = parseFloat(mT[1] + (mT[2] !== undefined ? '.' + mT[2] : ''));
  return isFinite(v) ? v : undefined;
}

/** Printed row identity of an opener line: Persian/Latin letter or bare digit. */
function openerLetter(t: string): string | undefined {
  const normed = toLatinDigits(t).trim();
  const mLetter = normed.match(/^\(?([A-Za-z\u0600-\u06FF]{1,3})[).:ـ]?(?:\s|$)/);
  if (mLetter && isRowLetterToken(mLetter[1])) return mLetter[1];
  const mNum = normed.match(/^(\d{1,2})[).\-:]?\s*$/);
  if (mNum) return mNum[1];
  return undefined;
}

function printedTotalOf(t: string): number | undefined {
  const normed = toLatinDigits(t);
  const rev = normed.split('').reverse().join('');
  if (!/جمع|total/i.test(normed) && !/جمع|total/i.test(rev)) return undefined;
  const nums = normed.match(/\d+(?:\.\d+)?/g);
  if (!nums || nums.length === 0) return undefined;
  const v = parseFloat(nums[nums.length - 1]);
  return isFinite(v) ? v : undefined;
}

export interface OracleOutcome {
  result: BrainResult;
  pSecMean: number;
  eventsFired: number;
}

/**
 * Deterministic sanity veto on the oracle's PROPOSED structure — the same
 * physics a layout-brain proposal must survive, applied to the network's.
 * The event stream may only become a sectioning if:
 *   1. it proposes >= 2 sections (a one-section "parse" is not a parse);
 *   2. every section carries >= 2 lines of content;
 *   3. within every section the printed row identities form a rank-
 *      continuous ladder in ONE alphabet (Latin / Persian / numeric) —
 *      bounded forward skips allowed, regressions and alphabet switches
 *      vetoed (the answer-key signature the brain already refuses);
 *   4. marks close against the printed total when one is detected
 *      (|sum - printed| <= 2 — identical to the bridge drive gate).
 * Anything else -> the proposal is refused and the oracle abstains.
 */
export function oracleStructureSane(
  result: BrainResult,
  printedTotal?: number,
): { ok: boolean; why: string } {
  const sections = result.sections;
  if (sections.length < 2) return { ok: false, why: `only ${sections.length} section(s)` };
  for (const s of sections) {
    if (s.lines.length < 2) return { ok: false, why: `section "${(s.headerText ?? '').slice(0, 30)}" has ${s.lines.length} line(s)` };
    // ladder continuity over this section's rows, per alphabet run
    let prevRank = -1;
    let prevAlpha = '';
    for (const r of s.rows) {
      const id = r.letter;
      const isNum = /^\d{1,2}$/.test(id);
      const alpha = isNum ? 'n' : /[A-Za-z]/.test(id) ? 'l' : 'p';
      const rank = isNum ? parseInt(id, 10) : letterRank(id.toUpperCase() === id.toLowerCase() ? id : id);
      if (rank === undefined) return { ok: false, why: `row "${id}" unrankable` };
      if (alpha !== prevAlpha) {
        if (prevAlpha !== '')
          return { ok: false, why: `alphabet switch at "${id}" in "${(s.headerText ?? '').slice(0, 30)}"` };
        prevAlpha = alpha;
        prevRank = rank;
        continue;
      }
      const d = rank - prevRank;
      if (d < 0) return { ok: false, why: `row ladder regresses at "${id}" in "${(s.headerText ?? '').slice(0, 30)}"` };
      if (d > 3) return { ok: false, why: `row ladder skips ${d} at "${id}" in "${(s.headerText ?? '').slice(0, 30)}"` };
      prevRank = rank;
    }
  }
  // duplicate-cycle veto (double-printed sheets): consecutive sections whose
  // (opening letter, length) signatures repeat at ANY offset — the second
  // print's tail may be truncated by a key sheet, so the repeat need not be
  // exact or adjacent. >=2 consecutive matches veto (the deterministic brain
  // refuses double prints and the oracle may not resurrect them).
  const sigs = sections.map((s) => `${s.rows[0]?.letter ?? (s.headerText ?? '').slice(0, 12)}#${s.lines.length}`);
  const n = sigs.length;
  for (let i = 0; i < n; i++) {
    for (let L = 2; i + L < n; L++) {
      const maxJ = Math.min(L, n - i - L);
      let match = 0;
      for (let j = 0; j < maxJ; j++) {
        if (sigs[i + j] === sigs[i + L + j]) match++;
        else break;
      }
      if (match >= 2)
        return { ok: false, why: `duplicate cycle (offset ${L}, ${match} sections repeat) at ${i} (double-printed sheet?)` };
    }
    // L=1 needs >=3 consecutive repeats to veto (two real sections can
    // legitimately share letter+length by coincidence)
    if (i + 3 <= n && sigs[i] === sigs[i + 1] && sigs[i] === sigs[i + 2])
      return { ok: false, why: `triple-repeated section signature at ${i} (double-printed sheet?)` };
  }
  if (printedTotal !== undefined && printedTotal > 0) {
    let sum = 0;
    for (const s of sections) for (const r of s.rows) sum += r.mark ?? 0;
    sum = Math.round(sum * 100) / 100;
    if (Math.abs(sum - printedTotal) > 2)
      return { ok: false, why: `marks ${sum} do not close on printed total ${printedTotal}` };
  }
  return { ok: true, why: '' };
}

/**
 * Build the oracle's proposed sectioning. Throws nothing — returns null on
 * any per-file obstruction the caller should survive. `brain` provides the
 * deterministic fallbacks: key boundary, printed total, body size.
 */
export function buildOracleProposal(
  doc: BrainDoc,
  brain: { lines: BrainLine[]; keyBoundary?: { page: number; y: number; text: string }; printedTotal?: number; bodySize: number },
): OracleOutcome | null {
  let m: TensorMap;
  try {
    m = loadTensors();
  } catch {
    return null; // S26: weights unreadable — oracle absent
  }
  if (!brain.lines.length) return null;

  let codec: CodecDocResult;
  try {
    codec = runCodec(doc, brain.lines);
  } catch {
    return null; // S26: codec unavailable — oracle absent
  }

  const { probs, nEv } = docEventProbs(m, codec, brain.lines);
  const tSec = STRUCTURE_THRESHOLDS.SEC ?? 0.5;
  const tRow = STRUCTURE_THRESHOLDS.ROW ?? 0.5;
  const tMark = STRUCTURE_THRESHOLDS.MARK ?? 0.5;
  const tKey = STRUCTURE_THRESHOLDS.KEY ?? 0.5;
  const tTotal = STRUCTURE_THRESHOLDS.TOTAL ?? 0.5;

  const lines = brain.lines;
  const sections: BrainSection[] = [];
  let cur: BrainSection | null = null;
  let curRow: BrainRow | null = null;
  let eventsFired = 0;
  let pSum = 0;
  let pCount = 0;
  let keyBoundary = brain.keyBoundary ? { ...brain.keyBoundary } : undefined;

  const pushSection = () => {
    if (!cur) return;
    if (cur.rows.length && cur.lines.length) sections.push(cur);
    else if (cur.lines.length >= 3) sections.push(cur); // rowless but real content
    cur = null;
    curRow = null;
  };

  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    const t = normText(l.text);
    const p = (k: number) => probs[i * nEv + k];

    // deterministic total lines are metadata either way
    const totalV = printedTotalOf(t);

    if (keyBoundary === undefined && p(EV_IDX.KEY) > tKey && brain.keyBoundary === undefined) {
      keyBoundary = { page: l.page, y: l.bbox[1], text: l.text.slice(0, 60) };
    }

    if (p(EV_IDX.SEC) > tSec) {
      eventsFired++;
      pSum += p(EV_IDX.SEC);
      pCount++;
      pushSection();
      const subject = matchSubject(l.text) ?? (codec.lines[i].pSubj > 0.6 ? SUBJECTS[codec.lines[i].subj] : undefined);
      cur = {
        index: sections.length,
        pageStart: l.page,
        pageEnd: l.page,
        headerText: l.text.trim().slice(0, 120),
        subject: subject && subject !== 'none' ? subject : undefined,
        boundaryKind: 'header',
        lines: [l],
        rows: [],
        evidence: { header: true, letter: false, mark: false, table: false, rules: false, ladder: 0, boxes: 0 },
        confidence: Math.min(0.95, Math.max(0.5, p(EV_IDX.SEC))),
        confirmed: true,
        notes: [`oracle: SEC p=${p(EV_IDX.SEC).toFixed(2)}${subject ? ` subject=${subject}` : ''}`],
      };
      curRow = null;
      continue;
    }

    if (cur === null) continue; // content before the first section start: uncovered

    cur.pageEnd = Math.max(cur.pageEnd, l.page);
    cur.lines.push(l);

    if (p(EV_IDX.ROW) > tRow) {
      const letter = openerLetter(t);
      if (letter !== undefined) {
        eventsFired++;
        pSum += p(EV_IDX.ROW);
        pCount++;
        const row: BrainRow = {
          letter,
          headerText: l.text.trim().slice(0, 160),
          lineStart: i,
          lineEnd: i,
          confidence: Math.min(0.95, Math.max(0.45, p(EV_IDX.ROW))),
          lines: [l],
        };
        cur.rows.push(row);
        curRow = row;
        if (cur.evidence.ladder === 0) {
          const rank = letterRank(letter.toUpperCase() === letter.toLowerCase() ? letter.toUpperCase() : letter);
          if (rank !== undefined) cur.evidence.ladder = 1;
        }
        if (/^\d{1,2}$/.test(letter)) cur.evidence.numeric = cur.evidence.numeric ?? parseInt(letter, 10);
        cur.evidence.letter = true;
        continue;
      }
    }

    if (p(EV_IDX.MARK) > tMark) {
      const mv = parseMarkValue(t);
      if (mv !== undefined && mv > 0 && mv <= 20) {
        eventsFired++;
        pSum += p(EV_IDX.MARK);
        pCount++;
        if (curRow && curRow.mark === undefined) curRow.mark = mv;
        else if (!curRow) cur.evidence.mark = true;
        continue;
      }
    }

    if (totalV !== undefined) {
      cur.notes.push(`oracle: total line ${totalV}`);
      continue;
    }

    // content line: rides with the current row (or section)
    if (curRow) {
      (curRow.lines ?? (curRow.lines = [])).push(l);
      curRow.lineEnd = i;
    }
  }
  pushSection();

  if (sections.length === 0) return null;

  // marks closure inputs: sum of row marks; printed total from deterministic
  // TOTAL lines (preferred) or the brain's own stats
  let sumMarks = 0;
  for (const s of sections)
    for (const r of s.rows) sumMarks += r.mark ?? 0;
  sumMarks = Math.round(sumMarks * 100) / 100;

  const result: BrainResult = {
    file: 'oracle',
    sections,
    fallbacks: [],
    lines,
    keyBoundary,
    notes: [],
    stats: {
      bodySize: brain.bodySize,
      headerCount: sections.length,
      letterCount: sections.reduce((a, s) => a + s.rows.length, 0),
      marksTables: 0,
      sumOfMarks: sumMarks,
      printedTotal: brain.printedTotal,
    },
  };
  return { result, pSecMean: pCount ? pSum / pCount : 0, eventsFired };
}

void EV_IDX;
