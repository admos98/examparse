import { ExamDocument, ExamHeader } from '../types/exam';

/**
 * Surface filter (decision D4) — privacy posture for PERSONAL metadata.
 *
 * The parser may still EXTRACT school/teacher/date fields (extraction and the
 * strict graders are untouched — zero gate impact), but these fields never
 * SURFACE unless the user explicitly opts in via Settings:
 *
 *   filtered by default (showFullHeaderFields = false):
 *     - UI display (exam header bars, library cards, dashboards, viewer)
 *     - AI provider payloads (judge sheet state exam{} — the model does not
 *       need to know which school produced the sheet to verify its parse)
 *     - every exporter output (JSON / XLSX / CSV / docx / HTML)
 *     - training-log rows, correction memory, serializer text round-trips
 *
 *   kept (never filtered): grade, courseName/lesson, durationMinutes, term,
 *   gradeAndMajor, examName, pageCount — the fields the whole attribution
 *   flow (grade resolver, difficulty, term-coverage) is built on.
 *
 * filterHeader() also runs a conservative denylist scrub over the remaining
 * header strings: label-style student/teacher lines and bare 10-digit
 * national-ID numbers that sometimes leak INTO courseName/gradeAndMajor on
 * messy papers. Deterministic, pure, no network.
 */

export interface SurfaceFilterSettings {
  /** Power-user toggle (Settings): show full header fields everywhere. Default OFF. */
  showFullHeaderFields: boolean;
}

export const DEFAULT_SURFACE_FILTER_SETTINGS: SurfaceFilterSettings = {
  showFullHeaderFields: false,
};

const STORAGE_KEY = 'exaparse.surfaceFilter.v1';

/** The header fields stripped from every surface by default (D4). */
export const SURFACE_PII_HEADER_FIELDS = [
  'teacherName',
  'schoolName',
  'district',
  'examDate',
] as const;

// ---------- tiny pub-sub store (React binds via useSyncExternalStore) ----------

let cache: SurfaceFilterSettings | null = null;
const listeners = new Set<() => void>();

function readStore(): SurfaceFilterSettings {
  if (cache) return cache;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      cache = {
        showFullHeaderFields: parsed?.showFullHeaderFields === true,
      };
      return cache;
    }
  } catch {
    /* private-mode / quota — defaults are the safe posture anyway */
  }
  cache = { ...DEFAULT_SURFACE_FILTER_SETTINGS };
  return cache;
}

export function getSurfaceFilterSettings(): SurfaceFilterSettings {
  return readStore();
}

export function setSurfaceFilterSettings(next: SurfaceFilterSettings): void {
  cache = { showFullHeaderFields: next.showFullHeaderFields === true };
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cache));
  } catch {
    /* ignore quota errors — in-memory posture still applies this session */
  }
  listeners.forEach((fn) => fn());
}

export function subscribeSurfaceFilter(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

// ---------- denylist scrubbing (residual free-text leakage) ----------

/**
 * Label-style PII lines commonly printed on Iranian exam papers. These leak
 * into courseName/gradeAndMajor/instructions on messy scans. Label is kept,
 * value replaced with a placeholder — deterministic, no false "name" hits.
 */
const PII_LABEL_RE =
  /(نام و نام خانوادگ[یي]|نام خانوادگ[یي]|نام دانش\s*[آا]موز|نام دانشجو|نام دبیر|نام آموزشگاه|کد ملی|شناسه ملی|کد آموزشگاه)\s*[:：=\-]\s*\S[^\n]{0,60}/g;

/** Bare 10-digit national-ID numbers (Iranian kode melli is exactly 10 digits).
 *  MATCHING ONLY — the replacement is checksum-gated (see scrubPiiText): a
 *  random 10-digit form/barcode number that fails the Iranian mod-11 check
 *  passes through untouched, killing the old false-positive class. */
const NATIONAL_ID_RE = /(?<![0-9۰-۹٠-٩])[0-9۰-۹٠-٩]{10}(?![0-9۰-۹٠-٩])/g;

// ---------- phone numbers (Iranian formats, Persian + Latin digits) ----------

const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';

/** Normalize Persian/Arabic-Indic digits to Latin (matching + checksum only —
 *  the scrubbed replacement is the same '—' placeholder either way). */
export function normalizeDigits(s: string): string {
  return s.replace(/[۰-۹٠-٩]/g, (d) => {
    const fa = FA_DIGITS.indexOf(d);
    if (fa >= 0) return String(fa);
    return String(AR_DIGITS.indexOf(d));
  });
}

/** Digit class covering Latin, Persian and Arabic-Indic numerals. */
const D = '0-9۰-۹٠-٩';
/** Optional separator inside a printed number: space, dash, dot. */
const SEP = '[\\s.\-–—]?';

/** Iranian mobile: 09xxxxxxxxx — 09 + 9 digits, groups may be separated
 *  (09121234567 / 0912 123 4567 / 0912-1234567 / all-Persian forms). The
 *  09 prefix accepts BOTH digit alphabets (0 or ۰, 9 or ۹). */
const MOBILE_RE = new RegExp(
  `(?<![${D}])[0۰][9۹][${D}]{2}(?:${SEP}[${D}]{3}${SEP}[${D}]{4}|[${D}]{7})(?![${D}])`,
  'g',
);

/** Iranian landline: 0[1-8] + 9 more digits (area code + 8-digit local) —
 *  02112345678 / 021 1234 5678 / Persian-digit forms. Mobile (09…) excluded
 *  by the second-digit class; 8-digit locals without the area code are NOT
 *  matched (too collision-prone with marks/years). */
const LANDLINE_RE = new RegExp(
  `(?<![${D}])[0۰][1-8۱-۸][${D}](?:${SEP}[${D}]{4}${SEP}[${D}]{4}|[${D}]{8})(?![${D}])`,
  'g',
);

/** Labeled phone/fax lines in either language: label kept, value replaced
 *  (catches short extensions and odd formats the bare patterns skip). */
const PHONE_LABEL_RE = new RegExp(
  `(تلفن|همراه|موبایل|شماره\\s*تماس|تماس|فکس|\\bphone\\b|\\btel\\.?\\b|\\bmobile\\b|\\bfax\\b|\\bcontact\\b)` +
    `\\s*[:：=\\-]?\\s*(?:\\+?9?8?)?[${D}](?:[${D}]|${SEP}){6,16}`,
  'gim',
);

/**
 * Iranian national-ID checksum (mod 11) over the NORMALIZED 10 digits —
 * exported for the gate. Uniform repdigit strings (0000000000, 1111111111…)
 * are rejected outright; they checksum as valid but are never real IDs.
 */
export function isValidIranianNationalId(raw10: string): boolean {
  const digits = normalizeDigits(raw10);
  if (!/^[0-9]{10}$/.test(digits)) return false;
  if (/^(\d)\1{9}$/.test(digits)) return false;
  const d = digits.split('').map(Number);
  let sum = 0;
  for (let i = 0; i < 9; i++) sum += d[i] * (10 - i);
  const r = sum % 11;
  const check = r < 2 ? r : 11 - r;
  return check === d[9];
}

/** Line-start English label forms on bilingual papers. */
const EN_LABEL_RE = /^((?:student|teacher|pupil)\s+name|name\s*&?\s*surname|national\s+(?:id|code))\s*[:：\-]\s*\S[^\n]{0,60}/gim;

export function scrubPiiText(text: string): string {
  if (!text) return text;
  return text
    .replace(PII_LABEL_RE, '$1: —')
    .replace(EN_LABEL_RE, '$1: —')
    .replace(PHONE_LABEL_RE, '$1: —')
    .replace(MOBILE_RE, '—')
    .replace(LANDLINE_RE, '—')
    // Bare 10-digit runs: only a VALID Iranian national-ID checksum gets
    // masked — legitimate 10-digit form/barcode numbers survive untouched.
    .replace(NATIONAL_ID_RE, (m) => (isValidIranianNationalId(m) ? '—' : m));
}

// ---------- header filtering ----------

/**
 * PII-free view of an ExamHeader. Pure: never mutates the input (the stored
 * document keeps its extracted fields — extraction untouched, surfaces only).
 */
export function filterHeader(header: ExamHeader): ExamHeader {
  return {
    ...header,
    teacherName: undefined,
    schoolName: '',
    district: '',
    examDate: '',
    courseName: scrubPiiText(header.courseName || ''),
    gradeAndMajor: scrubPiiText(header.gradeAndMajor || ''),
    grade: header.grade ? scrubPiiText(header.grade) : undefined,
    term: header.term ? scrubPiiText(header.term) : undefined,
    examName: header.examName ? scrubPiiText(header.examName) : undefined,
  };
}

/**
 * Full-document surface view: identical to `doc` except the header is
 * filtered. Shallow copy — sections/questions are shared by reference, so
 * this is allocation-cheap and safe to call per render.
 */
export function surfaceDocument(doc: ExamDocument): ExamDocument {
  return { ...doc, header: filterHeader(doc.header) };
}

/**
 * The header view a given surface should display/ship: filtered unless the
 * power-user toggle is on. Central choke point for every consumer.
 */
export function surfaceHeader(header: ExamHeader): ExamHeader {
  return getSurfaceFilterSettings().showFullHeaderFields
    ? header
    : filterHeader(header);
}

export function surfaceDoc(doc: ExamDocument): ExamDocument {
  return getSurfaceFilterSettings().showFullHeaderFields
    ? doc
    : surfaceDocument(doc);
}
