/**
 * Lossless canonical text layer (#2 of the bulletproofing round).
 *
 * Every regex in the parser should match CANONICAL text, never raw OCR/PDF
 * soup. Canonicalization unifies the visually-identical Persian/Arabic glyph
 * chaos (ي/ی, ك/ک, ۰-۹/٠-٩, tatweel, diacritics, bidi control marks) into one
 * deterministic form — and keeps an INDEX MAP back to the original string so
 * provenance can point at the exact original character when needed.
 *
 * Lossless means: canonicalize(raw).text never loses information — it only
 * rewrites characters that are visually or semantically equivalent, strips
 * invisible control characters, and collapses runs of whitespace.
 */

/** Invisible/bidi control characters that poison regex matching. */
const BIDI_CONTROL = /[\u200B\u200E\u200F\u202A-\u202E\u2066-\u2069\uFEFF\u00AD]/g;
/** Arabic diacritics (harakat) + Quranic annotation marks. */
const DIACRITICS = /[\u064B-\u0652\u0670\u06D6-\u06ED\u0640]/g;

export interface CanonicalText {
  /** Canonical string — what every parser regex should run against. */
  text: string;
  /**
   * map[i] = index in the ORIGINAL string of canonical character i.
   * map.length === text.length (whitespace runs map to their first char).
   */
  map: number[];
  /** Character classes that were rewritten (for the parse receipt). */
  rewrites: { arabicYehKaf: number; easternDigits: number; bidiStripped: number; diacritics: number; presentationForms: number };
}

/** Single-character canonical rewrites: visual equivalents only. */
const CHAR_MAP: Record<string, string> = {
  // Arabic Yeh -> Persian Yeh, Arabic Kaf -> Persian Kaf
  '\u064A': '\u06CC',
  '\u0643': '\u06A9',
  // Arabic-only letters that never appear in modern Persian orthography
  '\u0649': '\u06CC', // Alef maksura -> Yeh
  '\u0629': '\u0647', // Teh marbuta -> Heh
  '\u0640': '',       // Tatweel/kashida: pure stretch, no meaning
  // Presentation-form lookalikes that leak out of bad PDF text layers
  '\uFB8E': '\u06A9',
  '\uFB92': '\u06A9',
  '\uFBFC': '\u06CC',
  '\uFBFE': '\u06CC',
  '\uFB56': '\u067E',
  '\uFB7A': '\u0686',
  '\uFB92\u200C': '\u06A9',
};

/** Eastern-Arabic digits -> ASCII. Persian (۰-۹ U+06F0..) and Arabic-Indic (٠-٩ U+0660..). */
function digitToAscii(ch: string): string | null {
  const code = ch.charCodeAt(0);
  if (code >= 0x06f0 && code <= 0x06f9) return String(code - 0x06f0);
  if (code >= 0x0660 && code <= 0x0669) return String(code - 0x0660);
  // Extended Arabic-Indic (Persian variant used in some old fonts)
  if (code >= 0x06F0 && code <= 0x06F9) return String(code - 0x06F0);
  return null;
}

/**
 * Canonicalize raw text. Deterministic: same input -> byte-identical output.
 */
export function canonicalize(raw: string): CanonicalText {
  const rewrites = { arabicYehKaf: 0, easternDigits: 0, bidiStripped: 0, diacritics: 0, presentationForms: 0 };
  if (!raw) return { text: '', map: [], rewrites };

  const map: number[] = [];
  let out = '';

  for (let i = 0; i < raw.length; i++) {
    let ch = raw[i];

    // 1. Drop bidi / zero-width control characters entirely.
    if (/[\u200B\u200E\u200F\u202A-\u202E\u2066-\u2069\uFEFF\u00AD]/.test(ch)) {
      rewrites.bidiStripped++;
      continue;
    }

    // 1.5 Arabic PRESENTATION FORMS (U+FB50-FDFF / U+FE70-FEFF) -> base
    // letters via NFKC. Kanoon/medu PDF text layers emit ALL Persian as
    // presentation-form glyphs; every Persian cue regex in the question layer
    // (instructions, category keywords, matching/form tasks) matches the
    // standard U+0600-U+06FF range and was DEAD on those files — the single
    // largest systematic accuracy class (autopsy-20: qtype 35% + category
    // 14%). Fold BEFORE the CHAR_MAP so an Arabic-form fold result (ي/ك) still
    // normalizes to its Persian letter. Ligatures (ﻻ) expand to 2 chars; the
    // index map pushes the source index for every produced char.
    const code = ch.codePointAt(0) ?? 0;
    if ((code >= 0xfb50 && code <= 0xfdff) || (code >= 0xfe70 && code <= 0xfeff)) {
      const folded = ch.normalize('NFKC');
      if (folded !== ch) {
        rewrites.presentationForms++;
        for (const fc of folded) {
          out += fc;
          map.push(i);
        }
        continue;
      }
    }

    // 2. Single-char equivalence map (yeh/kaf/etc).
    const mapped = CHAR_MAP[ch];
    if (mapped !== undefined) {
      if (mapped === '') {
        rewrites.diacritics++; // tatweel removal
        continue;
      }
      if (ch !== mapped) rewrites.arabicYehKaf++;
      ch = mapped;
    }

    // 3. Eastern digits -> ASCII.
    const digit = digitToAscii(ch);
    if (digit !== null) {
      rewrites.easternDigits++;
      ch = digit;
    }

    // 4. Diacritics (harakat) — visually attached but regex-invisible.
    if (/[\u064B-\u0652\u0670\u06D6-\u06ED]/.test(ch)) {
      rewrites.diacritics++;
      continue;
    }

    // 5. Normalize exotic whitespace to plain space.
    if (ch === '\u00A0' || ch === '\u2007' || ch === '\u202F' || ch === '\u3000') {
      ch = ' ';
    }

    out += ch;
    map.push(i);
  }

  // 6. Collapse whitespace runs (spaces/tabs) to one space, tracking indices.
  let collapsed = '';
  const collapsedMap: number[] = [];
  for (let i = 0; i < out.length; i++) {
    const ch = out[i];
    if (ch === ' ' || ch === '\t' || ch === '\r') {
      // Preserve newlines (structural!), collapse space/tabs.
      const prev = collapsed[collapsed.length - 1];
      if (prev === ' ') continue; // already collapsed
      collapsed += ' ';
      collapsedMap.push(map[i]);
      continue;
    }
    collapsed += ch;
    collapsedMap.push(map[i]);
  }

  return { text: collapsed, map: collapsedMap, rewrites };
}

/** Map a canonical index back to the original string index. */
export function originalIndex(canon: CanonicalText, canonicalIdx: number): number {
  if (canonicalIdx < 0 || canonicalIdx >= canon.map.length) return canonicalIdx;
  return canon.map[canonicalIdx];
}

/**
 * Deterministic 32-bit FNV-1a hash — used for stable document ids so the same
 * file always parses to the same id (no Date.now() inside the parse path).
 */
export function fnv1a32(input: string): string {
  let hash = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i);
    // 32-bit FNV prime multiply (Math.imul keeps it in int32)
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(36);
}
