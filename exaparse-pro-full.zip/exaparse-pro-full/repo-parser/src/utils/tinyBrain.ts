/**
 * tinyBrain.ts — the LEARNED layer of the layout brain (Wave G6).
 *
 * The G2-G5 brain decided confidence with hand-tuned additive bonuses
 * (baseFor: header +0.35, letter +0.15, ...). This module replaces that
 * single-point judgment with a TINY trained model over the SAME structural
 * evidence — the "lightweight MoE" the user asked for:
 *
 *   perceive (hand-coded, unchanged)  ->  FEATURES (28 structural signals,
 *   soft-scaled instead of binarized)  ->  logistic model + Platt calibration
 *   ->  calibrated p(section is real)  ->  arbiter verdict vs the hand score.
 *
 * Design contracts:
 *  - TINY: 28 weights + 2 calibration scalars, a few KB, microseconds to run,
 *    zero dependencies (pure TS, no runtime, no wasm, no network).
 *  - LOCAL: trained offline by scripts/tinybrain_train.mts on the corpus +
 *    synthetic negatives (+ optional dev-only teacher labels); inference is
 *    bundled — nothing ever leaves the machine.
 *  - ROBUST: the hand score remains a GUARD. The model only owns the
 *    disagreement tails (upgrade a too-conservative hand refusal when it is
 *    very sure; downgrade a hand confirmation that smells like furniture when
 *    it is very sure). In the agreement band the hand verdict stands, so on-
 *    distribution behavior is stable and every gate stays deterministic.
 *  - HONEST: every model action appends a receipt note ("ml upgrade/downgrade/
 *    mild-dissent ..."), so uncertainty is surfaced, never hidden.
 *  - FAIL-SAFE: missing/corrupt weights -> getTinyWeights() returns null ->
 *    applyTinyVerdict falls back to the exact hand behavior (byte-identical).
 */

import type { BrainSection } from './layoutBrain';
import { TINY_BRAIN_WEIGHTS } from './tinyBrainWeights';

// ---------------------------------------------------------------- context

/** Document-level stats the feature extractor normalizes against. */
export interface TinyBrainDocCtx {
  bodySize: number;
  pageCount: number;
  contentLines: number;
}

// ---------------------------------------------------------------- features

/**
 * Feature vector layout. ORDER IS CONTRACT: the shipped weights vector maps
 * 1:1 onto this list (validated at load — a mismatch disables the model).
 */
export const TINY_FEATURES = [
  'bias',
  // boundary-kind one-hot (physical separators vs text events)
  'kind_rule',
  'kind_matching',
  'kind_content',
  'kind_other',
  // raw evidence flags (perception, unchanged)
  'ev_header',
  'ev_letter',
  'ev_mark',
  'ev_table',
  'ev_rules',
  'ev_numeric',
  // signal agreement (the fusion charter: independent signals agreeing)
  'subject_known',
  'header_subject_agree',
  'letter_mark_agree',
  // soft-scaled strengths (what the hand scorer binarized)
  'ladder_scaled',
  'boxes_scaled',
  'rows_scaled',
  'lines_scaled',
  // degenerate shapes
  'empty',
  'long_body',
  // header print style (size jump + boldness, soft)
  'size_jump',
  'bold_head',
  // marks texture
  'rows_with_marks',
  'mark_implausible',
  // sequence cross-checks (letter ladder state)
  'seq_ok',
  'seq_skip',
  'seq_regress',
  // document position (last-page furniture is likelier)
  'page_pos',
] as const;

export const TINY_FEATURE_COUNT = TINY_FEATURES.length;

/**
 * Extract the feature vector for one brain section/candidate. Everything
 * comes from the evidence receipt the perception already gathered — the
 * model adds no new perception, it only LEARNS THE WEIGHTS of the fusion.
 */
export function extractTinyFeatures(s: BrainSection, ctx: TinyBrainDocCtx): number[] {
  const ev = s.evidence;
  const f: number[] = new Array(TINY_FEATURE_COUNT).fill(0);
  let i = 0;
  f[i++] = 1; // bias
  // boundary kind one-hot
  if (s.boundaryKind === 'rule') f[i + 0] = 1;
  else if (s.boundaryKind === 'matching') f[i + 1] = 1;
  else if (s.boundaryKind === 'content') f[i + 2] = 1;
  else f[i + 3] = 1;
  i += 4;
  // evidence flags
  f[i++] = ev.header ? 1 : 0;
  f[i++] = ev.letter ? 1 : 0;
  f[i++] = ev.mark ? 1 : 0;
  f[i++] = ev.table ? 1 : 0;
  f[i++] = ev.rules ? 1 : 0;
  f[i++] = ev.numeric !== undefined ? 1 : 0;
  // agreement
  f[i++] = s.subject ? 1 : 0;
  f[i++] = ev.header && s.subject ? 1 : 0;
  f[i++] = ev.letter && ev.mark ? 1 : 0;
  // soft strengths
  f[i++] = Math.min(1, ev.ladder / 5);
  f[i++] = Math.min(1, ev.boxes / 6);
  f[i++] = Math.min(1, s.rows.length / 10);
  f[i++] = Math.min(1, Math.log(1 + s.lines.length) / Math.log(40));
  // degenerate shapes
  f[i++] = s.lines.length === 0 ? 1 : 0;
  f[i++] = s.lines.length >= 8 ? 1 : 0;
  // header print style — how BIG the first line prints vs the doc body
  const headSize = s.lines[0]?.size ?? ctx.bodySize ?? 12;
  const body = ctx.bodySize > 0 ? ctx.bodySize : headSize;
  f[i++] = Math.max(0, Math.min(2, (headSize / body - 1) / 0.6));
  f[i++] = s.lines[0]?.bold ? 1 : 0;
  // marks texture
  f[i++] = s.rows.length ? s.rows.filter((r) => r.mark !== undefined).length / s.rows.length : 0;
  f[i++] = s.rows.some((r) => (r.mark ?? 0) > 8) ? 1 : 0;
  // sequence state (cheap string probes on the receipts the VERIFY pass wrote)
  const joined = s.notes.join(' ');
  f[i++] = joined.includes('sequence ok') ? 1 : 0;
  f[i++] = joined.includes('letter skip') ? 1 : 0;
  f[i++] = joined.includes('letter regression') ? 1 : 0;
  // document position
  f[i++] = ctx.pageCount > 1 ? Math.min(1, Math.max(0, s.pageStart)) / (ctx.pageCount - 1) : 0;
  return f;
}

// ---------------------------------------------------------------- weights

/** Trained weights shape (written by scripts/tinybrain_train.mts). */
export interface TinyWeights {
  version: number;
  /** Trained-on receipt (provenance — the model must be auditable). */
  trainedAt: string;
  trainer: string;
  dataset: { positives: number; negatives: number; files: number; teacherLabels: number };
  metrics: { cvAccuracy: number; cvAuc: number; commitThresholdAccuracy: number };
  features: string[];
  w: number[];
  b: number;
  /** Platt calibration: p = sigmoid(A * sigmoid(w·x + b) + B). */
  plattA: number;
  plattB: number;
  thresholds: {
    /** p at/above which a section is confirmed (the G2 charter threshold). */
    commit: number;
    /** model-vs-hand arbiter band: upgrade hand refusals above this. */
    upgradeAbove: number;
    /** downgrade hand confirmations below this (furniture risk). */
    downgradeBelow: number;
  };
}

let weightsCache: TinyWeights | null | undefined;

/**
 * Load + validate the shipped weights once. Returns null when the model is
 * disabled (placeholder) or the weights are corrupt/mismatched — the caller
 * then behaves EXACTLY like the pre-G6 hand brain (fail-safe by contract).
 */
export function getTinyWeights(): TinyWeights | null {
  if (weightsCache !== undefined) return weightsCache;
  try {
    const w = TINY_BRAIN_WEIGHTS as TinyWeights | null;
    if (!w) {
      weightsCache = null;
      return null;
    }
    const ok =
      w.version === 1 &&
      Array.isArray(w.features) &&
      Array.isArray(w.w) &&
      w.features.length === TINY_FEATURE_COUNT &&
      w.w.length === TINY_FEATURE_COUNT &&
      w.features.every((name, k) => name === TINY_FEATURES[k]) &&
      w.w.every((x) => Number.isFinite(x)) &&
      Number.isFinite(w.b) &&
      Number.isFinite(w.plattA) &&
      Number.isFinite(w.plattB) &&
      Number.isFinite(w.thresholds?.commit) &&
      Number.isFinite(w.thresholds?.upgradeAbove) &&
      Number.isFinite(w.thresholds?.downgradeBelow);
    weightsCache = ok ? w : null;
    if (!ok) console.warn('[tinyBrain] shipped weights failed validation — model disabled (hand scorer active)');
  } catch {
    weightsCache = null;
    console.warn('[tinyBrain] weights unavailable — model disabled (hand scorer active)');
  }
  return weightsCache;
}

/** Test/dev hook: forget the cached weights (stress suite corrupt-weights case). */
export function __resetTinyWeightsCache(): void {
  weightsCache = undefined;
}

// ---------------------------------------------------------------- inference

const sigmoid = (z: number): number => 1 / (1 + Math.exp(-Math.max(-30, Math.min(30, z))));

export interface TinyScore {
  /** Calibrated probability that this candidate is a REAL section boundary. */
  p: number;
  /** Uncalibrated logistic output (training/Platt diagnostics). */
  raw: number;
}

/** One forward pass. Returns null when the model is disabled. */
export function tinyBrainScore(s: BrainSection, ctx: TinyBrainDocCtx): TinyScore | null {
  const w = getTinyWeights();
  if (!w) return null;
  const f = extractTinyFeatures(s, ctx);
  let z = w.b;
  for (let k = 0; k < f.length; k++) z += w.w[k] * f[k];
  const raw = sigmoid(z);
  return { p: sigmoid(w.plattA * raw + w.plattB), raw };
}

// ---------------------------------------------------------------- arbiter

/**
 * The G6 verdict rule — model + hand score, cross-checked:
 *
 *   hand says NO  and model is VERY SURE (p >= upgradeAbove)  -> confirm + note
 *   hand says YES and model is VERY SURE it is junk (p < downgradeBelow)
 *                                                             -> refuse + note
 *   otherwise (agreement or mild dissent)                     -> hand verdict,
 *                                                model opinion recorded
 *
 * The hand scorer stays the guard so on-distribution behavior (the 55-case
 * stress contract, the pinned 100%s, the strict gates) is stable; the model
 * owns the tails where hand heuristics generalize worst — NEW exam layouts.
 */
export function applyTinyVerdict(
  s: BrainSection,
  handC: number,
  ctx: TinyBrainDocCtx,
  enabled: boolean
): void {
  const clamp95 = (x: number) => Math.max(0, Math.min(0.95, x));
  const w = enabled ? getTinyWeights() : null;
  if (!w) {
    s.confidence = clamp95(handC);
    s.confirmed = s.confidence >= 0.7;
    return;
  }
  const sc = tinyBrainScore(s, ctx);
  if (!sc) {
    s.confidence = clamp95(handC);
    s.confirmed = s.confidence >= 0.7;
    return;
  }
  const p = sc.p;
  const handConfirmed = handC >= w.thresholds.commit;
  const modelConfirmed = p >= w.thresholds.commit;
  // Physical-structure guard on the downgrade tail: a PERCEIVED table, a
  // letter+mark co-occurrence, or a subject keyword is evidence from a
  // different signal tier. The model's corpus prior ("bare matching tables
  // usually defer to a letter ladder") is doc-context-dependent — exactly
  // what a candidate-level feature cannot see — so the model may veto only
  // GENERIC textures (bare header/rule with thin content = furniture).
  // Cross-tier overrides require cross-tier agreement (the G2 charter).
  const physicalStructure = !!s.evidence.table || (!!s.evidence.letter && !!s.evidence.mark) || !!s.subject;
  if (!handConfirmed && p >= w.thresholds.upgradeAbove) {
    // the model rescues a section the hand bonuses under-valued (unusual but
    // coherent evidence combinations — exactly what a learned weight vector
    // can see and a fixed additive rule cannot)
    s.confidence = clamp95(p);
    s.confirmed = true;
    s.notes.push(
      `ml upgrade (model p=${p.toFixed(2)} vs rule ${handC.toFixed(2)}) — coherent evidence combination`
    );
  } else if (handConfirmed && p < w.thresholds.downgradeBelow && !physicalStructure) {
    // the model smells furniture: strong hand bonuses but a feature texture
    // that in training meant junk (tiny content, no agreeing signals)
    s.confidence = clamp95(p);
    s.confirmed = false;
    s.notes.push(
      `ml downgrade (model p=${p.toFixed(2)} vs rule ${handC.toFixed(2)}) — furniture-risk evidence texture`
    );
  } else {
    // agreement band: the hand verdict stands (deterministic gates), the
    // calibrated opinion is recorded either way
    s.confidence = clamp95(handC);
    if (modelConfirmed !== handConfirmed) {
      s.notes.push(
        `ml mild-dissent (model p=${p.toFixed(2)} vs rule ${handC.toFixed(2)}) — hand verdict kept`
      );
    }
    s.confirmed = s.confidence >= 0.7;
  }
}
