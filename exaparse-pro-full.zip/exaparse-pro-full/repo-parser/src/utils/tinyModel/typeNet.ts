/**
 * typeNet.ts — TypeNet inference: the tiny trained model in the exam parser's
 * brain.
 *
 * WHAT IT IS
 *   A fasttext-style micro-classifier trained on the project's own labeled
 *   corpora (82 hand-built GTs) + a synthetic exam corpus generated through
 *   THIS SAME parse path (scripts/gen_synth_exams.py ->
 *   dump_tinymodel_data.mts). Hashed character n-grams (2..4) + hashed word
 *   tokens/bigrams + structural stem features -> ONE shared sparse feature
 *   layer -> TWO softmax heads: question TYPE (22 classes) and section
 *   CATEGORY (8 classes). ~140k sparse parameters, < 2MB as JSON, zero
 *   runtime dependencies, microsecond inference, fully local and auditable.
 *
 * FEATURE PARITY CONTRACT
 *   The featurizer below is byte-identical with scripts/train_tinymodel.py:
 *   same NFKC + Persian ya/kaf folding, same A-Z lowercasing, same whitespace
 *   collapse, same FNV-1a over UNICODE CODE POINTS (not UTF-16 units), same
 *   code-point n-gram slicing, same 'M:%.1f' mark formatting, same structural
 *   regexes. scripts/verify_tinymodel.mts pins this parity in the npm gate
 *   via scratch/tiny-model/selfcheck.json.
 *
 * ADOPTION POLICY (measured, not guessed)
 *   The model NEVER overrides the hand cue tables blindly. Retyping happens
 *   only for classes whose leave-one-file-out CV precision cleared the
 *   0.75 floor (weights.adoptAllow), at confidence >= tau and margin
 *   (p_top - p_engine) >= margin. Category adoption fires only on 'General'
 *   sections (the engine's honest abstention) with calibrated confidence.
 *   Every adoption leaves a receipt — the original decision is preserved.
 */
import weights from './model-weights.json';

const NORMS: Record<number, string> = { 0x064a: '\u06cc', 0x0643: '\u06a9' }; // Arabic ya/kaf -> Persian

export function normalizeText(s: string): string {
  let t = (s || '').normalize('NFKC');
  let out = '';
  for (const ch of t) {
    const cp = ch.codePointAt(0) as number;
    out += NORMS[cp] ?? (cp >= 0x41 && cp <= 0x5a ? String.fromCharCode(cp + 32) : ch);
  }
  return out.split(/\s+/).filter((x) => x !== '').join(' ');
}

export function composeFields(fa: string, en: string, stem: string, title: string, opts: string, bankText: string, ctxText: string, sibs: string): string {
  return [fa, en, stem, title, opts, bankText, ctxText, sibs].map(normalizeText).join(' | ');
}

/** FNV-1a 32-bit over unicode code points — identical to Python in the trainer. */
export function fnv1a32(text: string): number {
  let h = 2166136261;
  for (const ch of text) {
    h ^= ch.codePointAt(0) as number;
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h >>> 0;
}

const BLANK_RE = /\.{2,}|…+/g;
const DIGIT_RE = /\d/g;

export interface TypeNetInput {
  fa: string; en: string; stem: string; title: string; opts: string;
  bankText: string; ctxText: string; sibs: string;
  mark: number; ctx: string; flags: string[];
  engineType?: string;
}

/** Sparse feature map bucket -> count (duplicates kept, exactly like training). */
export function featurize(q: TypeNetInput): Map<number, number> {
  const text = composeFields(q.fa, q.en, q.stem, q.title, q.opts, q.bankText, q.ctxText, q.sibs);
  const cps = Array.from(text);
  const L = cps.length;
  const feats = new Map<number, number>();
  const bump = (b: number) => feats.set(b, (feats.get(b) ?? 0) + 1);
  for (let n = 2; n <= 4; n++) {
    for (let i = 0; i + n <= L; i++) {
      bump(fnv1a32(cps.slice(i, i + n).join('')) % weights.buckets);
    }
  }
  const ntext = text; // tokens come from the same composed, normalized text
  const toks = ntext.split(' ');
  if (toks.length > 120) toks.length = 120;
  for (let i = 0; i < toks.length; i++) {
    if (toks[i]) {
      bump(fnv1a32('W:' + toks[i]) % weights.buckets);
      if (i + 1 < toks.length && toks[i + 1]) bump(fnv1a32('W2:' + toks[i] + ' ' + toks[i + 1]) % weights.buckets);
    }
  }
  const st = normalizeText(q.stem);
  const blanks = (st.match(BLANK_RE) || []).length;
  const parens = (st.match(/\(/g) || []).length;
  const digits = (st.match(DIGIT_RE) || []).length;
  if (st.includes('/')) bump(fnv1a32('S:slash') % weights.buckets);
  bump(fnv1a32('S:bl:' + Math.min(9, blanks)) % weights.buckets);
  bump(fnv1a32('S:pa:' + Math.min(9, parens)) % weights.buckets);
  bump(fnv1a32('S:dg:' + Math.min(9, digits)) % weights.buckets);
  for (const f of q.flags || []) bump(fnv1a32('F:' + f) % weights.buckets);
  bump(fnv1a32('M:' + (Math.round((q.mark || 0) * 10) / 10).toFixed(1)) % weights.buckets);
  bump(fnv1a32('C:' + (q.ctx || 'none')) % weights.buckets);
  return feats;
}

// ---- model tables (built once, lazily) ----
const T = weights.types.length;
const typeW = new Map<number, Map<number, number>>();
for (let k = 0; k < weights.typeRow.length; k++) {
  const b = weights.typeRow[k];
  let row = typeW.get(b);
  if (!row) { row = new Map<number, number>(); typeW.set(b, row); }
  row.set(weights.typeCol[k], weights.typeVal[k]);
}
const catW = new Map<number, Map<number, number>>();
for (let k = 0; k < weights.catRow.length; k++) {
  const b = weights.catRow[k];
  let row = catW.get(b);
  if (!row) { row = new Map<number, number>(); catW.set(b, row); }
  row.set(weights.catCol[k], weights.catVal[k]);
}

function softmaxScores(feats: Map<number, number>, W: Map<number, Map<number, number>>, bias: number[], C: number): number[] {
  const scores = bias.slice();
  for (const [b, cnt] of feats) {
    const row = W.get(b);
    if (!row) continue;
    for (let c = 0; c < C; c++) {
      const w = row.get(c);
      if (w) scores[c] += w * cnt;
    }
  }
  let max = -Infinity;
  for (const s of scores) if (s > max) max = s;
  let sum = 0;
  for (let c = 0; c < C; c++) { scores[c] = Math.exp(scores[c] - max); sum += scores[c]; }
  for (let c = 0; c < C; c++) scores[c] /= sum;
  return scores;
}

export interface TypeNetVerdict {
  predType: string;
  p: number;
  pEngine: number;
  predCat: string;
  pCat: number;
}

export function inferType(q: TypeNetInput): TypeNetVerdict {
  const feats = featurize(q);
  const pts = softmaxScores(feats, typeW, weights.typeB as number[], T);
  let ti = 0;
  for (let c = 1; c < T; c++) if (pts[c] > pts[ti]) ti = c;
  const pc = softmaxScores(feats, catW, weights.catB as number[], weights.cats.length);
  let ci = 0;
  for (let c = 1; c < weights.cats.length; c++) if (pc[c] > pc[ci]) ci = c;
  return {
    predType: weights.types[ti],
    p: pts[ti],
    pEngine: (weights.types as string[]).indexOf(q.engineType ?? '') >= 0 ? pts[(weights.types as string[]).indexOf(q.engineType ?? '')] : 0,
    predCat: weights.cats[ci],
    pCat: pc[ci],
  };
}

/** Categories the ExamSection.majorCategory contract allows. */
export const ADOPTABLE_CATS = new Set(['Listening', 'Vocabulary', 'Grammar', 'Writing', 'Reading']);

export interface TypeNetDecision {
  retypeTo?: string;
  retypeFrom?: string;
  catTo?: string;
  verdict: TypeNetVerdict;
}

/**
 * The measured adoption policy (see file header): retype only DIRECTED
 * engine->model pairs whose CV precision cleared 0.75 at n>=4
 * (weights.adoptPairs — six of the eight shipped pairs measured precision
 * 1.00) or whitelisted classes at n>=8 (weights.adoptAllow), always at
 * confidence >= tau with margin (p_top - p_engine) >= margin. Category
 * adoption measured net-negative at every threshold and is SUPPRESSED
 * (weights.catAdopt=false) — it stays dead until a retrain clears the bar.
 */
export function decide(q: TypeNetInput & { engineType?: string }, engineCat?: string): TypeNetDecision {
  const v = inferType(q);
  const d: TypeNetDecision = { verdict: v };
  const pairs = (weights.adoptPairs ?? []) as string[][];
  const pairOk = pairs.some(([a, b]) => a === q.engineType && b === v.predType);
  const classOk = ((weights.adoptAllow ?? []) as string[]).includes(v.predType);
  if (
    q.engineType && v.predType !== q.engineType &&
    (pairOk || classOk) &&
    v.p >= (weights.tau as number) &&
    v.p - v.pEngine >= (weights.margin as number)
  ) {
    d.retypeTo = v.predType;
    d.retypeFrom = q.engineType;
  }
  if ((weights.catAdopt as boolean) && engineCat === 'General' && ADOPTABLE_CATS.has(v.predCat) && v.predCat !== 'General' && v.pCat >= (weights.catTau as number)) {
    d.catTo = v.predCat;
  }
  return d;
}

/** Test hook for the parity gate. */
export function selfTest(): { compose: string; hashes: [number, number][]; fnv: Record<string, number> } {
  const q: TypeNetInput = {
    fa: 'داخل پرانتز صحیح', en: 'Choose the correct option', stem: 'He ....... to school every day.',
    title: 'Vocabulary', opts: 'goes ¦ went ¦ go ¦ gone', bankText: '', ctxText: '', sibs: '',
    mark: 1, ctx: 'none', flags: ['options'],
  };
  const feats = featurize(q);
  const hashes = Array.from(feats.entries()).sort((a, b) => a[0] - b[0]) as [number, number][];
  return {
    compose: composeFields(q.fa, q.en, q.stem, q.title, q.opts, q.bankText, q.ctxText, q.sibs),
    hashes,
    fnv: { a: fnv1a32('a'), 'He ': fnv1a32('He '), 'W2:a b': fnv1a32('W2:a b') },
  };
}
