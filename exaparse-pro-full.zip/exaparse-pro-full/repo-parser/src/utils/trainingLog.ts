import { BBox, ExamDocument, ExamSection, QuestionItem } from '../types/exam';
import { normalizeForFingerprint } from './answerCache';
import { getSurfaceFilterSettings } from './surfaceFilter';

/**
 * JSONL training-log exporter ("the json thing").
 *
 * Append-only, one compact JSON object per line, UTF-8 — one line per
 * VERIFIED-CORRECT question, ready for instruction tuning / dataset use.
 *
 * The gate is explicit and configurable: a line is emitted ONLY when the
 * answer is trustworthy —
 *   • Jev verdict 'correct' with pCorrect >= threshold, OR
 *   • human-approved (answerMeta.method === 'human').
 * Uncertain, contested, and unsolved questions are NEVER logged.
 *
 * Determinism & de-duplication: every line is keyed by a content fingerprint
 * of (stem + options + correctAnswer), so re-exporting the library never
 * produces duplicate training rows, and `loggedAt` derives from the judging /
 * review timestamps instead of wall-clock time so re-exports are byte-stable.
 *
 * 100% offline — no AI is needed to export.
 */

export type TrainingLineVariant = 'messages' | 'instruction';

export type TrainingGate = 'jev_or_human' | 'human_only';

export interface TrainingLogOptions {
  /** Line schema variant (default: chat 'messages'). */
  variant: TrainingLineVariant;
  /** Trust gate (default: Jev-correct OR human-approved). */
  gate: TrainingGate;
  /** Jev acceptance threshold for the gate (default 0.9, mirrors JevConfig). */
  threshold: number;
}

export const DEFAULT_TRAINING_OPTIONS: TrainingLogOptions = {
  variant: 'messages',
  gate: 'jev_or_human',
  threshold: 0.9,
};

/** The stable system prompt used for the 'messages' variant. */
export const TRAINING_SYSTEM_PROMPT =
  'You are an exam solver. Given an exam question with its options or word bank and any passage context, output only the correct answer, nothing else.';

// ---------- gate ----------

export type TrainingSource = 'jev' | 'human';

interface GateDecision {
  worthy: boolean;
  source?: TrainingSource;
  reason?: string;
}

function gateQuestion(q: QuestionItem, opts: TrainingLogOptions): GateDecision {
  const stem = (q.stem || '').trim();
  const answer = (q.correctAnswer || '').trim();
  if (!stem) return { worthy: false, reason: 'empty stem' };
  if (!answer) return { worthy: false, reason: 'unsolved' };
  if (q.trustLevel === 'contested') return { worthy: false, reason: 'contested' };

  if (q.answerMeta?.method === 'human') {
    return { worthy: true, source: 'human' };
  }
  if (opts.gate === 'human_only') {
    return { worthy: false, reason: 'gate=human_only and answer was not human-approved' };
  }
  if (q.jev?.verdict === 'correct' && typeof q.jev.pCorrect === 'number' && q.jev.pCorrect >= opts.threshold) {
    return { worthy: true, source: 'jev' };
  }
  return { worthy: false, reason: 'not verified-correct (no Jev confirmation below threshold / uncertain / human gate)' };
}

/** Would this question be exported to the training log? (UI counts use this.) */
export function isTrainingWorthy(q: QuestionItem, opts: Partial<TrainingLogOptions> = {}): boolean {
  return gateQuestion(q, { ...DEFAULT_TRAINING_OPTIONS, ...opts }).worthy;
}

// ---------- fingerprint ----------

/**
 * Content fingerprint of the training tuple (stem + options + correctAnswer).
 * Uses the same Persian-aware normalization as the answer cache, so
 * ي/ی and ك/ک variants dedupe correctly.
 */
export function trainingFingerprint(q: Pick<QuestionItem, 'stem' | 'options' | 'correctAnswer'>): string {
  const raw = [
    normalizeForFingerprint(q.stem || ''),
    (q.options || []).map((o) => normalizeForFingerprint(o.text)).join('|'),
    normalizeForFingerprint(q.correctAnswer || ''),
  ].join('::');
  let h = 5381;
  for (let i = 0; i < raw.length; i++) {
    h = ((h << 5) + h + raw.charCodeAt(i)) | 0;
  }
  return `tl:${(h >>> 0).toString(36)}`;
}

// ---------- line construction ----------

/** Flatten a question's answering context into the user turn. */
export function buildTrainingInput(doc: ExamDocument, sec: ExamSection, q: QuestionItem): string {
  const parts: string[] = [];
  if (q.parentContextText || sec.passageText) {
    parts.push(`Passage: ${(q.parentContextText || sec.passageText || '').trim()}`);
  }
  if (q.wordBankWords && q.wordBankWords.length > 0) {
    parts.push(`Word bank: ${q.wordBankWords.join(', ')}`);
  }
  parts.push(q.stem.trim());
  if (q.options && q.options.length > 0) {
    parts.push(q.options.map((o) => `${o.id}) ${o.text.trim()}`).join('\n'));
  }
  if (q.type === 'true_false') {
    parts.push('(True/False)');
  }
  return parts.join('\n');
}

function provenanceBlock(q: QuestionItem): { page?: number; bbox?: BBox } | undefined {
  if (!q.provenance) return undefined;
  const out: { page?: number; bbox?: BBox } = {};
  if (typeof q.provenance.page === 'number') out.page = q.provenance.page;
  if (q.provenance.bbox) out.bbox = q.provenance.bbox;
  return Object.keys(out).length > 0 ? out : undefined;
}

/** Deterministic loggedAt: judge/review time when present, else the parse time. */
function loggedAtOf(doc: ExamDocument, q: QuestionItem): string {
  if (q.jev?.judgedAt) return q.jev.judgedAt;
  const approved = doc.review?.changes?.find(
    (c) => c.questionId === q.id && c.status === 'approved' && c.decidedAt,
  );
  if (approved?.decidedAt) return approved.decidedAt;
  return doc.parsedAt || '';
}

export function buildTrainingLine(
  doc: ExamDocument,
  sec: ExamSection,
  q: QuestionItem,
  source: TrainingSource,
  opts: TrainingLogOptions,
): Record<string, unknown> {
  const input = buildTrainingInput(doc, sec, q);
  const answer = (q.correctAnswer || '').trim();

  const meta: Record<string, unknown> = {
    examId: doc.id,
    section: sec.rowId,
    questionNumber: q.displayNumber,
    type: q.type,
    jevCategory: q.jev?.category || undefined,
    skillArea: q.jev?.skillArea || undefined,
    pCorrect: typeof q.jev?.pCorrect === 'number' ? q.jev.pCorrect : undefined,
    trustLevel: q.trustLevel || undefined,
    source,
    grade: doc.header?.grade || doc.header?.gradeAndMajor || undefined,
    term: doc.header?.term || undefined,
    // Surface filter (D4): the training dataset never carries school identity.
    schoolName: getSurfaceFilterSettings().showFullHeaderFields
      ? doc.header?.schoolName || undefined
      : undefined,
    mark: q.mark,
    provenance: provenanceBlock(q),
    loggedAt: loggedAtOf(doc, q),
    fingerprint: trainingFingerprint(q),
  };

  if (opts.variant === 'instruction') {
    return { instruction: TRAINING_SYSTEM_PROMPT, input, output: answer, meta };
  }

  return {
    messages: [
      { role: 'system', content: TRAINING_SYSTEM_PROMPT },
      { role: 'user', content: input },
      { role: 'assistant', content: answer },
    ],
    meta,
  };
}

// ---------- collection (deterministic, de-duplicated) ----------

export interface TrainingCollection {
  /** Compact JSON lines, ready to join with '\n'. */
  lines: string[];
  /** Question keys accepted by the gate (per exam, for UI counts). */
  accepted: number;
  /** Questions rejected by the gate. */
  rejected: number;
  /** Duplicates dropped by fingerprint (second and later occurrences). */
  duplicates: number;
}

export function collectTrainingLines(documents: ExamDocument[], opts: Partial<TrainingLogOptions> = {}): TrainingCollection {
  const options: TrainingLogOptions = { ...DEFAULT_TRAINING_OPTIONS, ...opts };
  const seen = new Set<string>();
  const lines: string[] = [];
  let accepted = 0;
  let rejected = 0;
  let duplicates = 0;

  // Deterministic order: documents as given, sections by rowId, questions by
  // display number (numeric when possible) — the same library always yields
  // the same file.
  for (const doc of documents) {
    const sections = [...(doc.sections || [])].sort((a, b) => a.rowId.localeCompare(b.rowId));
    for (const sec of sections) {
      const questions = [...(sec.questions || [])].sort((a, b) => {
        const na = parseFloat(String(a.displayNumber));
        const nb = parseFloat(String(b.displayNumber));
        if (Number.isFinite(na) && Number.isFinite(nb) && na !== nb) return na - nb;
        return String(a.displayNumber).localeCompare(String(b.displayNumber));
      });
      for (const q of questions) {
        const decision = gateQuestion(q, options);
        if (!decision.worthy || !decision.source) {
          rejected++;
          continue;
        }
        const fp = trainingFingerprint(q);
        if (seen.has(fp)) {
          duplicates++;
          continue;
        }
        seen.add(fp);
        const line = buildTrainingLine(doc, sec, q, decision.source, options);
        lines.push(JSON.stringify(line)); // compact: one JSON object per line
        accepted++;
      }
    }
  }

  return { lines, accepted, rejected, duplicates };
}

/** The ready-to-download JSONL string (no trailing newline). */
export function buildTrainingJsonl(documents: ExamDocument[], opts: Partial<TrainingLogOptions> = {}): string {
  return collectTrainingLines(documents, opts).lines.join('\n');
}

/** Count of verified-correct questions ready for the training log (UI). */
export function countTrainingReady(documents: ExamDocument[], opts: Partial<TrainingLogOptions> = {}): number {
  const options: TrainingLogOptions = { ...DEFAULT_TRAINING_OPTIONS, ...opts };
  let n = 0;
  for (const doc of documents) {
    for (const sec of doc.sections || []) {
      for (const q of sec.questions || []) {
        if (isTrainingWorthy(q, options)) n++;
      }
    }
  }
  return n;
}
