import {
  ConsensusReport,
  ExamDocument,
  InvariantReport,
  ParsingAnomaly,
  QuestionItem,
  TrustSummary,
} from '../types/exam';

/**
 * Trust Engine (#9) — the single source of truth for "how much can you trust
 * this question".
 *
 * Every question gets exactly one of three truth levels:
 *
 *   🟢 verified   — physical provenance exists AND no error-level invariant
 *                   violation touches it AND (when a consensus report exists)
 *                   its extraction path agreed with the second opinion.
 *   🟡 single     — parsed from one source only: no provenance, low OCR
 *                   confidence, or only soft (warning/info) findings.
 *   🔴 contested  — an error-level invariant violation, an unresolved error
 *                   anomaly, a consensus disagreement, or a structurally
 *                   impossible shape.
 *
 * The engine also merges every finding source (invariants, anomalies,
 * consensus, OCR confidence) into ONE human-language findings list (#11) with
 * paired fix actions (#12) so the UI never has to merge sources itself.
 */

export type TrustLevel = 'verified' | 'single' | 'contested';

export interface UnifiedFinding {
  id: string;
  severity: 'error' | 'warning' | 'info';
  /** Human sentence — no codes, no jargon (#11). */
  message: string;
  /** What it means in one more sentence (optional). */
  detail?: string;
  sectionRowId?: string;
  questionId?: string;
  questionNumber?: string;
  /** One-click resolutions (#12 Fix Cards). */
  actions: { label: string; kind: 'auto_fix' | 'resolve_anomaly' | 'adjudicate' | 'open_question' | 'rejudge'; ref: string }[];
  source: 'invariant' | 'anomaly' | 'consensus' | 'ocr' | 'extraction' | 'jev' | 'verify' | 'template';
}

export interface TrustComputation {
  summary: TrustSummary;
  /** Map questionId -> reason codes that decided its level. */
  reasons: Map<string, string[]>;
  findings: UnifiedFinding[];
}

function qLabel(q: QuestionItem): string {
  return `Question ${q.displayNumber}`;
}

/** Consensus path key for a question, matching consensus.ts: '<rowId>/<displayNumber>'. */
function consensusPath(q: QuestionItem): string {
  return `${q.sectionRowId}/${q.displayNumber}`;
}

export function computeTrust(
  doc: ExamDocument,
  opts: { invariants?: InvariantReport; consensus?: ConsensusReport; anomalies?: ParsingAnomaly[] } = {},
): TrustComputation {
  const invariants = opts.invariants || doc.invariants;
  const consensus = opts.consensus || doc.consensus;
  const anomalies = opts.anomalies || doc.anomalies;

  const reasons = new Map<string, string[]>();
  const findings: UnifiedFinding[] = [];
  const pushReason = (qid: string, reason: string) => {
    const arr = reasons.get(qid) || [];
    arr.push(reason);
    reasons.set(qid, arr);
  };

  // ---- Index error-level invariant violations by question ----
  const errorInv = new Map<string, string[]>();
  const warnInv = new Map<string, string[]>();
  if (invariants) {
    for (const v of invariants.violations) {
      if (v.isFixed) continue;
      const bucket = v.severity === 'error' ? errorInv : warnInv;
      if (v.questionId) {
        const arr = bucket.get(v.questionId) || [];
        arr.push(v.message);
        bucket.set(v.questionId, arr);
      }
      // Section-level violations (marks, sequence) dampen every question of
      // the section to at most "single", and become findings.
      findings.push({
        id: `inv-${v.id}`,
        severity: v.severity,
        message: v.message,
        detail: v.suggestedFix,
        sectionRowId: v.sectionRowId,
        questionId: v.questionId,
        actions: v.autoFix && !v.isFixed
          ? [{ label: fixLabel(v.autoFix), kind: 'auto_fix', ref: v.id }]
          : v.questionId
            ? [{ label: 'Open question', kind: 'open_question', ref: v.questionId }]
            : [],
        source: 'invariant',
      });
    }
  }

  // ---- Unresolved anomalies by question ----
  const errorAnom = new Map<string, string[]>();
  if (Array.isArray(anomalies)) {
    for (const a of anomalies) {
      if (a.isResolved) continue;
      if (a.severity === 'error' && a.questionNumber !== undefined) {
        // anomalies reference question numbers per section
        for (const sec of doc.sections) {
          if (sec.rowId !== a.sectionRowId) continue;
          for (const q of sec.questions) {
            if (String(q.number) === String(a.questionNumber) || q.displayNumber === String(a.questionNumber)) {
              const arr = errorAnom.get(q.id) || [];
              arr.push(a.description || a.title);
              errorAnom.set(q.id, arr);
            }
          }
        }
      }
      findings.push({
        id: `anom-${a.id}`,
        severity: a.severity === 'error' ? 'error' : a.severity,
        message: a.description || a.title,
        detail: a.suggestedFix,
        sectionRowId: a.sectionRowId,
        actions: [
          { label: 'Mark as handled', kind: 'resolve_anomaly', ref: a.id },
          ...(a.questionNumber !== undefined
            ? [{ label: 'Open question', kind: 'open_question' as const, ref: `${a.sectionRowId}/${a.questionNumber}` }]
            : []),
        ],
        source: 'anomaly',
      });
    }
  }

  // ---- Consensus disagreements ----
  const disagree = new Map<string, { a: string; b: string; similarity: number }>();
  if (consensus) {
    for (const c of consensus.checks) {
      if (!c.agree) disagree.set(c.path, { a: c.a, b: c.b, similarity: c.similarity });
    }
  }

  // ---- Per-question truth level ----
  let verified = 0;
  let single = 0;
  let contested = 0;
  let total = 0;

  for (const sec of doc.sections) {
    for (const q of sec.questions) {
      total++;
      const rs: string[] = [];

      // ---- Jev parse verification (consensus gate over the parse itself) ----
      // The user-approved flow: parser-true ∧ JEV-true → safe; ANY disagreement
      // (either side, any axis) → must be checked by a human or re-checked by AI.
      if (q.parseVerdict?.verdict === 'flagged' && !q.parseVerdict.humanReviewed) {
        rs.push(`Jev parse verification flagged it (${q.parseVerdict.note || 'disagreement'})`);
        findings.push({
          id: `verify-${q.id}`,
          severity: 'error',
          message: `${qLabel(q)}: the Jev parse verification disagrees with the parser.`,
          detail: `Flagged axes: ${q.parseVerdict.note || 'unknown'}. The parse (type, separation, metadata) needs your validation or an AI re-check before this question can be trusted. Nothing was changed automatically.`,
          sectionRowId: sec.rowId,
          questionId: q.id,
          questionNumber: q.displayNumber,
          actions: [{ label: 'Open question', kind: 'open_question', ref: q.id }],
          source: 'verify',
        });
      }

      if (errorInv.has(q.id)) {
        rs.push(`invariant error: ${errorInv.get(q.id)![0]}`);
      }
      if (errorAnom.has(q.id)) {
        rs.push(`parse error: ${errorAnom.get(q.id)![0]}`);
      }
      const cd = disagree.get(consensusPath(q));
      if (cd) {
        // NOTE: applyTrust() re-derives levels from these reason STRINGS — the
        // predicate there MUST match this wording. Keep them in sync.
        rs.push(`consensus disagreement: the two extraction paths read this line differently (${Math.round(cd.similarity * 100)}% overlap)`);
        findings.push({
          id: `cons-${consensusPath(q)}`,
          severity: 'error',
          message: `${qLabel(q)}: the two independent extraction paths disagree on this line.`,
          detail: `Path A read: "${cd.a.slice(0, 70)}" — Path B read: "${cd.b.slice(0, 70)}". One of them mis-read the scan.`,
          sectionRowId: sec.rowId,
          questionId: q.id,
          questionNumber: q.displayNumber,
          actions: [{ label: 'Open question', kind: 'open_question', ref: q.id }],
          source: 'consensus',
        });
      }
      if (q.options && q.type === 'multiple_choice' && q.options.length > 5) {
        rs.push('impossible option count (structural)');
      }

      // ---- Jev judge verdicts (judge-only protocol) ----
      // 'incorrect' is a hard signal: a calibrated second opinion rejects the
      // proposed answer → contested with a Re-judge / Open question fix pair.
      if (q.jev?.verdict === 'incorrect') {
        rs.push(`Jev judge rejects the answer (P(correct)=${q.jev.pCorrect !== undefined ? q.jev.pCorrect.toFixed(2) : '?'})`);
        findings.push({
          id: `jev-${q.id}`,
          severity: 'error',
          message: `${qLabel(q)}: the Jev judge believes the marked answer is wrong (confidence ${q.jev.pCorrect !== undefined ? Math.round((1 - q.jev.pCorrect) * 100) : '?'}%).`,
          detail: 'Jev only evaluates — it never rewrites. Re-judge it, open the question, or approve/fix the answer yourself.',
          sectionRowId: sec.rowId,
          questionId: q.id,
          questionNumber: q.displayNumber,
          actions: [
            { label: 'Re-judge', kind: 'rejudge', ref: q.id },
            { label: 'Open question', kind: 'open_question', ref: q.id },
          ],
          source: 'jev',
        });
      }

      const hardContested = rs.length > 0;

      if (!hardContested) {
        // Soft signals only push down to "single".
        if (!q.provenance) rs.push('no physical provenance (source line not found)');
        if (q.parseVerdict?.verdict === 'unverified' && !q.parseVerdict.humanReviewed) {
          // JEV returned NO verdict (judge omission / transport failure).
          // Fail-safe: no consensus = no auto-accept. Soft (no disagreement
          // signal), but it must be visible — an invisible unverified question
          // would silently look as trusted as a verified one.
          rs.push(`Jev parse verification unverified (${q.parseVerdict.note || 'no verdict returned'})`);
          findings.push({
            id: `verify-${q.id}`,
            severity: 'warning',
            message: `${qLabel(q)}: the Jev parse verification returned no verdict for this question.`,
            detail: 'Fail-safe: no consensus means no auto-accept. Re-run parse verification or review this question by hand. Nothing was changed automatically.',
            sectionRowId: sec.rowId,
            questionId: q.id,
            questionNumber: q.displayNumber,
            actions: [{ label: 'Open question', kind: 'open_question', ref: q.id }],
            source: 'verify',
          });
        }
        if (q.provenance?.ocrConfidence !== undefined && q.provenance.ocrConfidence < 60) {
          rs.push(`low OCR confidence (${Math.round(q.provenance.ocrConfidence)}%)`);
        }
        if (warnInv.has(q.id)) rs.push(`soft structural warning: ${warnInv.get(q.id)![0]}`);
        if (q.type === 'multiple_choice' && (!q.options || q.options.length < 2)) {
          rs.push('MCQ with fewer than two options');
        }
        if (q.jev?.verdict === 'uncertain') {
          rs.push(`Jev judge is unsure (P(correct)=${q.jev.pCorrect !== undefined ? q.jev.pCorrect.toFixed(2) : '?'})`);
          findings.push({
            id: `jev-${q.id}`,
            severity: 'warning',
            message: `${qLabel(q)}: the Jev judge could not decide if the marked answer is right (P=${q.jev.pCorrect !== undefined ? q.jev.pCorrect.toFixed(2) : '?'}).`,
            detail: 'Mid-band confidence. Escalated to the 3-vote adjudicator when auto-escalation is on; still reviewable by hand.',
            sectionRowId: sec.rowId,
            questionId: q.id,
            questionNumber: q.displayNumber,
            actions: [
              { label: 'Re-judge', kind: 'rejudge', ref: q.id },
              { label: 'Open question', kind: 'open_question', ref: q.id },
            ],
            source: 'jev',
          });
        }

        // Verified strengthening: a provenance-backed, invariant-clean question
        // whose answer a calibrated judge CONFIRMS (P >= 0.9) earns the second
        // opinion it was missing — soft doubts no longer hold it at "single".
        // (No reason is recorded: an empty reason list maps to 'verified'.)
        const jevConfirmed = q.jev?.verdict === 'correct' && q.jev.pCorrect !== undefined && q.jev.pCorrect >= 0.9;
        if (jevConfirmed && q.provenance) {
          rs.length = 0;
        }

        // Consensus gate (parse verification): JEV confirmed type + separation +
        // metadata against the raw source. That independent confirmation IS the
        // second opinion — it clears 'no physical provenance' and soft structural
        // warnings, but never hard errors and never low-OCR-confidence (the judge
        // read the same extracted bytes, so pixel-level doubt must stay).
        if (q.parseVerdict?.verdict === 'accepted') {
          for (let i = rs.length - 1; i >= 0; i--) {
            const r = rs[i];
            if (!r.includes('OCR') && !r.includes('Jev judge is unsure')) rs.splice(i, 1);
          }
        }
      }

      const level: TrustLevel = hardContested ? 'contested' : rs.length > 0 ? 'single' : 'verified';
      if (level === 'verified') verified++;
      else if (level === 'single') single++;
      else contested++;
      if (rs.length > 0) pushReason(q.id, rs.join('; '));
    }
  }

  // OCR-line-level findings: provenance lines with poor confidence that are
  // NOT already covered by question-level findings.
  for (const sec of doc.sections) {
    for (const q of sec.questions) {
      const conf = q.provenance?.ocrConfidence;
      if (conf !== undefined && conf < 45 && !reasons.get(q.id)?.some((r) => r.includes('OCR'))) {
        findings.push({
          id: `ocr-${q.id}`,
          severity: 'warning',
          message: `${qLabel(q)} was read from a low-confidence region of the scan (${Math.round(conf)}% OCR confidence).`,
          detail: 'The recognizer was unsure about these pixels. Double-check numbers, names and option letters.',
          sectionRowId: sec.rowId,
          questionId: q.id,
          questionNumber: q.displayNumber,
          actions: [{ label: 'Open question', kind: 'open_question', ref: q.id }],
          source: 'ocr',
        });
      }
    }
  }

  // Low EQS as a document-level finding.
  if (doc.extraction && doc.extraction.verdict === 'poor') {
    findings.unshift({
      id: 'eqs-doc',
      severity: 'warning',
      message: `The text extraction quality of this file is poor (score ${doc.extraction.score}/100).`,
      detail: doc.extraction.reasons.join(' ') || undefined,
      actions: [{ label: 'Re-parse with the other strategy', kind: 'adjudicate', ref: 'reparse' }],
      source: 'extraction',
    });
  }

  // ---- Template evidence (Idea 2) — advisory, NEVER a trust demotion ----
  // Mined section templates contribute soft evidence only. A strong-shape
  // section whose template votes for a different type than the parser stamped
  // becomes an info finding (warning only when the parser was least sure —
  // a 'General' category — and the evidence is strong). Templates never move
  // truth chips: same shape, many possible types — that is their contract.
  for (const sec of doc.sections) {
    const hints = sec.templateHints;
    if (!hints || hints.length === 0) continue;
    const top = hints[0];
    const parsedTypes = new Set(sec.questions.map((q) => q.type));
    if (parsedTypes.has(top.suggestsType as QuestionItem['type'])) continue;
    const strong = top.score >= 0.8 && sec.majorCategory === 'General';
    findings.push({
      id: `tpl-${sec.rowId}`,
      severity: strong ? 'warning' : 'info',
      message: `Section ${sec.rowId}: the mined layout templates suggest these are usually "${top.suggestsType}" questions (evidence ${(top.score * 100).toFixed(0)}%), but they are parsed as ${[...parsedTypes].join(', ')}.`,
      detail: 'Template evidence is advisory — the same shape can serve several question types, so nothing was changed. Open a question to review, or mine a rule if this layout is systematically misread.',
      sectionRowId: sec.rowId,
      actions: [{ label: 'Open question', kind: 'open_question', ref: sec.questions[0]?.id || sec.rowId }],
      source: 'template',
    });
  }

  const summary: TrustSummary = {
    computedAt: new Date().toISOString(),
    verified,
    single,
    contested,
    total,
    verifiedPct: total > 0 ? Math.round((verified / total) * 1000) / 10 : 0,
  };

  return { summary, reasons, findings };
}

function fixLabel(autoFix: string): string {
  switch (autoFix) {
    case 'renumber': return 'Fix numbering';
    case 'recalc_marks': return 'Recalculate marks';
    case 'clear_invalid_answer': return 'Clear invalid answer';
    case 'snap_mark': return 'Snap mark to standard';
    default: return 'Auto-fix';
  }
}

/**
 * Stamp trust levels onto the question objects (for chips in the UI) and the
 * summary onto the document. Returns a NEW document; does not mutate.
 */
export function applyTrust(doc: ExamDocument, computation?: TrustComputation): ExamDocument {
  const comp = computation || computeTrust(doc);
  const reasonsById = comp.reasons;
  const next: ExamDocument = {
    ...doc,
    trust: comp.summary,
    sections: doc.sections.map((sec) => ({
      ...sec,
      questions: sec.questions.map((q) => {
        const rs = reasonsById.get(q.id);
        const level: TrustLevel = !rs
          ? 'verified'
          : rs.some(
              (r) =>
                r.startsWith('invariant error') ||
                r.startsWith('parse error') ||
                // MUST match the consensus reason string pushed in computeTrust.
                r.startsWith('consensus disagreement:') ||
                r.includes('impossible option count') ||
                r.startsWith('Jev judge rejects') ||
                // Precise on purpose: only the FLAGGED wording contests.
                // 'Jev parse verification unverified (…)' is a SOFT signal and
                // must keep mapping to 'single' (fail-safe visibility without
                // claiming an actual disagreement).
                r.startsWith('Jev parse verification flagged'),
            )
            ? 'contested'
            : 'single';
        return {
          ...q,
          trustLevel: level,
          // Stash reasons on the receipt-adjacent field for the explain popover.
          ...(rs ? {} : {}),
        } as QuestionItem;
      }),
    })),
  };
  return next;
}
