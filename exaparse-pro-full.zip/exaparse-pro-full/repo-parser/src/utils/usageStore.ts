import { AIUsageReceipt, ExamDocument } from '../types/exam';
import { kvGet, kvSet } from './localStore';

/**
 * AI receipts (#7) + the downward metric (#11).
 *
 * Every solve writes an immutable receipt. The store keeps:
 *  - all-time totals (tokens, baseline, saved %, cache/heuristic/ai split)
 *  - monthly snapshots of the AI intervention rate — the number that should
 *    fall month over month as the deterministic engine absorbs the AI's job.
 */

const ALLTIME_KEY = 'usage:alltime';
const MONTHLY_KEY = 'usage:monthly';

export interface AllTimeUsage {
  requests: number;
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  baselineTokens: number;
  heuristicSolved: number;
  cacheHits: number;
  aiSolved: number;
  examsSolved: number;
  // --- Jev judge totals (judge-only protocol) ---
  judgeCalls: number;
  judgeQuestions: number;
  judgeCacheHits: number;
  judgeTokens: number;
  judgeEscalated: number;
}

export interface MonthlySnapshot {
  month: string; // 'YYYY-MM'
  totalTokens: number;
  baselineTokens: number;
  interventionRate: number; // % of solved answers that needed AI
}

const EMPTY_ALLTIME: AllTimeUsage = {
  requests: 0,
  promptTokens: 0,
  completionTokens: 0,
  totalTokens: 0,
  baselineTokens: 0,
  heuristicSolved: 0,
  cacheHits: 0,
  aiSolved: 0,
  examsSolved: 0,
  judgeCalls: 0,
  judgeQuestions: 0,
  judgeCacheHits: 0,
  judgeTokens: 0,
  judgeEscalated: 0,
};

export async function getAllTimeUsage(): Promise<AllTimeUsage> {
  return { ...EMPTY_ALLTIME, ...((await kvGet<AllTimeUsage>(ALLTIME_KEY)) || {}) };
}

/** Record one solve receipt into all-time totals + monthly snapshot. */
export async function recordSolveReceipt(receipt: AIUsageReceipt): Promise<void> {
  const allTime = await getAllTimeUsage();
  allTime.requests += receipt.requests || 1;
  allTime.promptTokens += receipt.promptTokens || 0;
  allTime.completionTokens += receipt.completionTokens || 0;
  allTime.totalTokens += receipt.totalTokens || 0;
  allTime.baselineTokens += receipt.baselineTokens || 0;
  allTime.heuristicSolved += receipt.heuristicSolved || 0;
  allTime.cacheHits += receipt.cacheHits || 0;
  allTime.aiSolved += receipt.aiSolved || 0;
  allTime.examsSolved += 1;
  await kvSet(ALLTIME_KEY, allTime);

  // Monthly snapshot with current intervention rate
  const month = new Date().toISOString().slice(0, 7);
  const monthly = await getMonthlySnapshots();
  const total = receipt.heuristicSolved + receipt.cacheHits + receipt.aiSolved;
  const rate = total > 0 ? Math.round((receipt.aiSolved / total) * 1000) / 10 : 0;
  const existing = monthly.find((m) => m.month === month);
  if (existing) {
    const prevTotal = Math.max(1, existing.totalTokens);
    existing.totalTokens += receipt.totalTokens || 0;
    existing.baselineTokens += receipt.baselineTokens || 0;
    // Weighted rolling average of the intervention rate
    existing.interventionRate = Math.round(((existing.interventionRate * prevTotal + rate * (receipt.totalTokens || 1)) / (prevTotal + (receipt.totalTokens || 1))) * 10) / 10;
  } else {
    monthly.push({ month, totalTokens: receipt.totalTokens || 0, baselineTokens: receipt.baselineTokens || 0, interventionRate: rate });
  }
  if (monthly.length > 24) monthly.splice(0, monthly.length - 24);
  await kvSet(MONTHLY_KEY, monthly);
}

export async function getMonthlySnapshots(): Promise<MonthlySnapshot[]> {
  const list = await kvGet<MonthlySnapshot[]>(MONTHLY_KEY);
  return Array.isArray(list) ? list : [];
}

/**
 * Record one Jev judging pass (the efficiency evidence line:
 * "Judged 63 questions in 3 Jev calls"). Cheap by construction —
 * cache hits are recorded so the all-time graph shows the number falling.
 */
export async function recordJudgeReceipt(stats: {
  judged: number;
  cacheHits: number;
  calls: number;
  totalTokens: number;
  escalated: number;
}): Promise<void> {
  const allTime = await getAllTimeUsage();
  allTime.judgeCalls += stats.calls || 0;
  allTime.judgeQuestions += stats.judged || 0;
  allTime.judgeCacheHits += stats.cacheHits || 0;
  allTime.judgeTokens += stats.totalTokens || 0;
  allTime.judgeEscalated += stats.escalated || 0;
  await kvSet(ALLTIME_KEY, allTime);
}

export function allTimeSavedPct(allTime: AllTimeUsage): number {
  return allTime.baselineTokens > 0
    ? Math.max(0, Math.round((1 - allTime.totalTokens / allTime.baselineTokens) * 1000) / 10)
    : 0;
}

/**
 * AI intervention rate across the whole library: of all questions that HAVE an
 * answer, what share was solved by the AI (vs. heuristic/cache/human)?
 */
export function computeInterventionRate(docs: ExamDocument[]): number {
  let ai = 0;
  let total = 0;
  for (const doc of docs) {
    for (const sec of doc.sections || []) {
      for (const q of sec.questions || []) {
        if (!q.correctAnswer || !q.correctAnswer.trim()) continue;
        total++;
        if (q.answerMeta?.method === 'ai') ai++;
      }
    }
  }
  return total > 0 ? Math.round((ai / total) * 1000) / 10 : 0;
}
