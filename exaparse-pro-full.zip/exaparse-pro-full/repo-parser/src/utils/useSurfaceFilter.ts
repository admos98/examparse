import { useSyncExternalStore } from 'react';
import {
  getSurfaceFilterSettings,
  subscribeSurfaceFilter,
  SurfaceFilterSettings,
} from './surfaceFilter';

/**
 * React binding for the surface-filter store (decision D4). Components call
 * `const sf = useSurfaceFilter()` and render `sf.showFullHeaderFields`
 * -aware header values (usually via `surfaceHeader(doc.header)`).
 */
export function useSurfaceFilter(): SurfaceFilterSettings {
  return useSyncExternalStore(subscribeSurfaceFilter, getSurfaceFilterSettings);
}
