import { ExamDocument, ExamImage } from '../types/exam';
import { ExtractedImage, positionalConfidence } from './visionImages';
import { FIGURE_MARKER_RE, isImageDependent, needsImageAlt, imagePendingQuestionIds } from './imagePending';

// Re-exported so the whole app has ONE import site for the two-phase predicates
// (the implementations live in ./imagePending — dependency-free and shared with
// parseVerifier; keeping one copy is the drift-bug lesson).
export { FIGURE_MARKER_RE, isImageDependent, needsImageAlt, imagePendingQuestionIds };

/**
 * Vision alt pipeline — placement, application.
 *
 * Hard rules implemented here:
 *  • Image→question placement is POSITION-driven (docx anchor line order /
 *    pdf bbox vs question provenance). Keyword overlap is a LAST-RESORT
 *    tiebreaker only, and always lands in the review queue, never auto-placed.
 *  • Low-confidence placements are surfaced for review, NOT silently committed.
 *  • The parse is never silently rewritten: alts attach as imageCaption +
 *    parentContext evidence; stems stay untouched.
 */

// ---------------------------------------------------------------------------
// Placement (pure, deterministic, testable)
// ---------------------------------------------------------------------------

export interface PlacementCandidate {
  imageId: string;
  questionId?: string;
  confidence: number;
  how: 'position' | 'keyword' | 'none';
}

interface QuestionPosition {
  id: string;
  lineStart?: number;
  lineEnd?: number;
  page?: number;
  bbox?: { x: number; y: number; w: number; h: number };
  keywords: string;
}

function questionPositions(doc: ExamDocument): QuestionPosition[] {
  const out: QuestionPosition[] = [];
  for (const sec of doc.sections) {
    for (const q of sec.questions) {
      out.push({
        id: q.id,
        lineStart: q.provenance?.lineStart,
        lineEnd: q.provenance?.lineEnd,
        page: q.provenance?.page,
        bbox: q.provenance?.bbox,
        keywords: normalizeForMatch(q.stem),
      });
    }
  }
  return out;
}

function normalizeForMatch(text: string): string {
  return (text || '')
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function keywordOverlap(a: string, b: string): number {
  if (!a || !b) return 0;
  const sa = new Set(a.split(' ').filter((w) => w.length > 2));
  const sb = new Set(b.split(' ').filter((w) => w.length > 2));
  if (sa.size === 0 || sb.size === 0) return 0;
  let inter = 0;
  for (const w of sa) if (sb.has(w)) inter++;
  return inter / Math.min(sa.size, sb.size);
}

/**
 * Place extracted images onto questions by POSITION.
 *
 * docx: images arrive with anchorIndex = the source line their anchor maps to.
 * pdf: images arrive with page + bbox in PDF space; questions carry the same
 *      geometry in provenance. Owner = the question whose vertical range
 *      contains the image top (or the nearest preceding question on the page).
 *
 * Keyword overlap runs ONLY when positional evidence is absent, and its
 * confidence is capped below every auto-place threshold → review queue.
 */
export function placeImages(
  doc: ExamDocument,
  images: ExtractedImage[],
  opts: { keywordContexts?: Record<string, string> } = {},
): Map<string, PlacementCandidate> {
  const out = new Map<string, PlacementCandidate>();
  const positions = questionPositions(doc).sort((a, b) => {
    const pa = a.page ?? 1;
    const pb = b.page ?? 1;
    if (pa !== pb) return pa - pb;
    return (a.lineStart ?? 0) - (b.lineStart ?? 0);
  });

  for (const img of images) {
    if (img.origin === 'pdf_embedded' && img.bbox && img.page) {
      // ---- PDF: vertical containment on the same page ----
      const samePage = positions.filter((p) => p.page === img.page && p.bbox);
      const imgTop = img.bbox.y + img.bbox.h; // y-up space: top edge = y + h
      const containing = samePage.find((p) => {
        const b = p.bbox!;
        const top = Math.max(b.y, b.y + b.h);
        const bottom = Math.min(b.y, b.y + b.h);
        return imgTop <= top && imgTop >= bottom - 6;
      });
      if (containing) {
        out.set(img.id, { imageId: img.id, questionId: containing.id, confidence: 0.95, how: 'position' });
        continue;
      }
      // nearest question STARTING above the image on this page
      const preceding = samePage
        .filter((p) => Math.max(p.bbox!.y, p.bbox!.y + p.bbox!.h) >= imgTop - 4)
        .sort(
          (a, b) =>
            Math.abs(Math.max(a.bbox!.y, a.bbox!.y + a.bbox!.h) - imgTop) -
            Math.abs(Math.max(b.bbox!.y, b.bbox!.y + b.bbox!.h) - imgTop),
        )[0];
      if (preceding) {
        const pageH = doc.sections
          .flatMap((s) => s.questions)
          .find((q) => q.id === preceding.id)?.provenance?.pageHeight;
        const gap = Math.abs(Math.max(preceding.bbox!.y, preceding.bbox!.y + preceding.bbox!.h) - imgTop);
        const gapFrac = pageH ? gap / pageH : gap / 800;
        out.set(img.id, {
          imageId: img.id,
          questionId: preceding.id,
          confidence: Math.max(0.35, 0.9 - gapFrac * 1.6),
          how: 'position',
        });
        continue;
      }
      const kw = keywordFallback(img, positions, opts.keywordContexts);
      out.set(img.id, kw);
      continue;
    }

    // ---- docx: anchor line order ----
    if (img.anchorIndex !== undefined) {
      const pos = img.anchorIndex;
      const started = positions.filter((p) => p.lineStart !== undefined && (p.lineStart as number) <= pos);
      const owner = started[started.length - 1];
      if (owner) {
        const nextStart = positions
          .filter((p) => p.lineStart !== undefined && (p.lineStart as number) > pos)
          .sort((a, b) => (a.lineStart as number) - (b.lineStart as number))[0];
        const conf = positionalConfidence(
          pos,
          { lineStart: owner.lineStart, lineEnd: owner.lineEnd },
          nextStart?.lineStart,
        );
        out.set(img.id, { imageId: img.id, questionId: owner.id, confidence: conf, how: 'position' });
        continue;
      }
    }
    const kw = keywordFallback(img, positions, opts.keywordContexts);
    out.set(img.id, kw);
  }
  return out;
}

function keywordFallback(
  img: ExtractedImage,
  positions: QuestionPosition[],
  contexts?: Record<string, string>,
): PlacementCandidate {
  const ctx = normalizeForMatch(contexts?.[img.id] || img.contextText || '');
  let best: { id: string; score: number } | null = null;
  for (const p of positions) {
    const score = keywordOverlap(ctx, p.keywords);
    if (score > 0 && (!best || score > best.score)) best = { id: p.id, score };
  }
  if (best && best.score >= 0.34) {
    // Keyword evidence is weak by nature — capped BELOW every auto threshold.
    return { imageId: img.id, questionId: best.id, confidence: Math.min(0.5, best.score * 0.7), how: 'keyword' };
  }
  return { imageId: img.id, confidence: 0, how: 'none' };
}

// ---------------------------------------------------------------------------
// Response parsing (provider output → per-image results)
// ---------------------------------------------------------------------------

export interface VisionAltResult {
  alt: string;
  kind: 'text' | 'photo' | 'diagram' | 'unknown';
  confidence: number;
}

const VALID_KINDS = new Set(['text', 'photo', 'diagram', 'unknown']);

/**
 * Extract index-keyed alt results from model output. Tolerates prose wrapping
 * and fence decoration (the model was told to answer {"images": {...}} but the
 * parse must survive real-world shapes). Unknown ids are IGNORED, never guessed.
 */
export function parseAltResults(
  parsed: any,
  expectedIds: string[],
): { results: Map<string, VisionAltResult>; warnings: string[] } {
  const warnings: string[] = [];
  const results = new Map<string, VisionAltResult>();
  const bag: any =
    parsed && typeof parsed === 'object'
      ? parsed.images && typeof parsed.images === 'object'
        ? parsed.images
        : parsed
      : {};
  const expected = new Set(expectedIds);
  for (const [id, raw] of Object.entries<any>(bag)) {
    if (!expected.has(id)) continue;
    if (!raw || typeof raw !== 'object') continue;
    const alt = String(raw.alt ?? raw.description ?? raw.transcription ?? '').trim();
    if (!alt) {
      warnings.push(`Vision returned an empty alt for ${id} — left for review.`);
      continue;
    }
    const kindRaw = String(raw.kind ?? 'unknown').toLowerCase();
    const confidence = typeof raw.confidence === 'number' && raw.confidence >= 0 && raw.confidence <= 1 ? raw.confidence : 0.75;
    results.set(id, {
      alt: alt.slice(0, 1200),
      kind: (VALID_KINDS.has(kindRaw) ? kindRaw : 'unknown') as VisionAltResult['kind'],
      confidence,
    });
  }
  for (const id of expectedIds) {
    if (!results.has(id)) warnings.push(`No vision result for ${id} — left for review.`);
  }
  return { results, warnings };
}

/** Build the batched alt-generation user prompt (index-keyed JSON contract). */
export function buildAltPrompt(
  items: { id: string; contextText?: string; embeddedAlt?: string }[],
): string {
  const lines = items.map((it) => {
    const ctx = it.contextText ? ` Nearby exam text: "${it.contextText.slice(0, 160)}".` : '';
    const alt0 = it.embeddedAlt ? ` The document names it: "${it.embeddedAlt.slice(0, 80)}".` : '';
    return `- ${it.id}:${ctx}${alt0}`;
  });
  return (
    'These are images embedded in one school exam paper. For EACH image, answer:\n' +
    '- If it contains text (a labeled diagram, a sign, a table, a sentence): transcribe that text verbatim, in reading order.\n' +
    '- Otherwise: give a one-line factual description (what it shows).\n' +
    'Keep every answer under 40 words. Persian/English text stays in its original language.\n\n' +
    'Answer with RAW JSON ONLY, keyed by image id:\n' +
    '{"images": {"img_1": {"alt": "...", "kind": "text|photo|diagram", "confidence": 0.0-1.0}}}\n\n' +
    'Images:\n' +
    lines.join('\n')
  );
}

// ---------------------------------------------------------------------------
// Document application (immutable)
// ---------------------------------------------------------------------------

export interface ApplyVisionOptions {
  placementThreshold: number;
  /** Force placement decisions (e.g. human override) for these image ids. */
  overrides?: Map<string, { questionId?: string; status: ExamImage['placementStatus'] }>;
}

export interface ApplyVisionOutcome {
  doc: ExamDocument;
  placed: number;
  needsReview: number;
  unplaced: number;
}

/**
 * Merge extraction + vision results into the document WITHOUT mutating the
 * input: doc.images, per-question image fields, and the imgPending flags.
 * Auto-placement only at/above the threshold; everything else is queued.
 */
export function applyVisionToDoc(
  doc: ExamDocument,
  images: ExamImage[],
  opts: ApplyVisionOptions,
): ApplyVisionOutcome {
  const placements = new Map(doc.images?.map((i) => [i.id, i]) || []);
  for (const img of images) placements.set(img.id, img);
  const merged = [...placements.values()];

  // Which question each placed image belongs to (auto + manual + review-accepted)
  const byQuestion = new Map<string, ExamImage[]>();
  let placed = 0;
  let needsReview = 0;
  let unplaced = 0;

  const threshold = opts.placementThreshold;
  for (const img of merged) {
    const override = opts.overrides?.get(img.id);
    if (override) {
      img.questionId = override.questionId;
      img.placementStatus = override.status;
      if (override.status === 'manual') img.reviewed = true;
    } else if (!img.placementStatus || img.placementStatus === 'unplaced') {
      const cand = img.placementConfidence;
      if (img.questionId && cand !== undefined && cand >= threshold) {
        img.placementStatus = 'auto';
      } else if (img.questionId) {
        img.placementStatus = 'review';
      } else {
        img.placementStatus = 'unplaced';
      }
    }
    if (img.placementStatus === 'auto' || img.placementStatus === 'manual') placed++;
    else if (img.placementStatus === 'review') needsReview++;
    else unplaced++;
    // ONLY committed placements (auto/manual) attach alts to questions.
    // 'review' images must NOT leak their alt into the question — that is
    // exactly the "silently committed guess" the brief forbids.
    if (img.questionId && (img.placementStatus === 'auto' || img.placementStatus === 'manual')) {
      const arr = byQuestion.get(img.questionId) || [];
      arr.push(img);
      byQuestion.set(img.questionId, arr);
    }
  }

  const doc2: ExamDocument = {
    ...doc,
    sections: doc.sections.map((sec) => ({
      ...sec,
      questions: sec.questions.map((q) => {
        const mine = byQuestion.get(q.id);
        // A question TARGETED by any image (even a review-status one) is waiting
        // on that image's alt: it stays imgPending until the human commits.
        const targeted = merged.some((i) => i.questionId === q.id);
        const isImg = isImageDependent(q);
        if (!mine && !targeted && !isImg) {
          // No image relevance anymore (e.g. the human rejected a placement):
          // clear a stale pending flag instead of leaving it behind forever.
          return q.imgPending ? { ...q, imgPending: false } : q;
        }
        const primary = mine && mine.length > 0 ? mine[0] : undefined;
        const caption =
          mine && mine.length > 0
            ? mine
                .map((m) => m.alt)
                .filter((a): a is string => !!a && !!a.trim())
                .join(' | ')
            : undefined;
        return {
          ...q,
          hasImage: isImg || !!mine || targeted,
          imageFileName: primary ? primary.id : q.imageFileName,
          imageCaption: caption && caption.trim() ? caption.trim() : q.imageCaption,
          parentContextType:
            mine && mine.length > 0 ? ('image_prompt' as const) : q.parentContextType,
          parentContextTitle: mine && mine.length > 0 ? 'Image content (vision)' : q.parentContextTitle,
          parentContextText: caption && caption.trim() ? caption.trim() : q.parentContextText,
          // Alt is in → the two-phase flag clears; no alt yet → stays pending.
          imgPending: caption && caption.trim() ? false : isImg || targeted,
        };
      }),
    })),
    images: merged,
  };

  return { doc: doc2, placed, needsReview, unplaced };
}
