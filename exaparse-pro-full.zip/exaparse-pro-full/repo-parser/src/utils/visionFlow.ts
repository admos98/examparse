import { ExamDocument, ExamImage, VisionReceipt } from '../types/exam';
import { ProviderConfig, VisionConfig } from '../types/settings';
import { visionCacheKey, visionCacheGet, visionCachePut, VisionPurpose } from './imageCache';
import {
  ExtractedImage,
  extractDocxImages,
  extractPdfEmbeddedImages,
  prepImagePayload,
  prepPageForVision,
  countPages,
  classifyImagePixels,
} from './visionImages';
import { placeImages, applyVisionToDoc, parseAltResults, buildAltPrompt } from './visionAlts';

/**
 * Client-side vision flows (Idea 3). OPT-IN by construction — these run ONLY
 * when the user presses "Generate image alts" / "Vision re-transcribe".
 *
 * Path A: extract embedded images → content-hash cache lookup → resize/compress
 *         (resolution-aware) → ONE batched /api/vision-batch call (index-keyed)
 *         → position-based placement → human-reviewable alts on the document.
 * Path B: render each scanned page → content-hash cache → ONE call PER PAGE
 *         (verbatim reading-order transcription with [FIGURE near Qn] markers)
 *         → the transcript re-parses through the OFFLINE parser (no solve).
 *
 * Fail-safe contract (same as the rest of the app): throw-free, every failure
 * returns { ok:false, error }, the parse is never silently rewritten, and a
 * cached image NEVER produces a wire call.
 */

export interface VisionFlowResult {
  ok: boolean;
  error?: string;
  doc?: ExamDocument;
  receipt?: VisionReceipt;
  warnings: string[];
}

export interface AltGenerationStats {
  extracted: number;
  cacheHits: number;
  sent: number;
  placed: number;
  needsReview: number;
  unplaced: number;
  calls: number;
}

const MAX_EXTRACTION_IMAGES = 20;
const THUMBNAIL_PX = 140;

export function isLikelyScan(doc: ExamDocument): boolean {
  const st = doc.extraction?.strategy;
  if (st === 'render_and_ocr') return true;
  return doc.parseTrace?.lines ? false : doc.sourceFile ? /scan|image/i.test(doc.filename) : false;
}

export function isImageFile(doc: ExamDocument): boolean {
  return /\.(png|jpe?g|webp|bmp|tiff)$/i.test(doc.filename) || (doc.extraction?.strategy ?? '') === 'camera_photo';
}

/** Which vision flows make sense for this document (button visibility). */
export function visionCapabilities(doc: ExamDocument): { alts: boolean; transcribe: boolean } {
  const name = (doc.filename || '').toLowerCase();
  const hasSource = !!doc.sourceFile;
  const transcribe = hasSource && (name.endsWith('.pdf') || isImageFile(doc) || isLikelyScan(doc));
  const alts = hasSource && name.endsWith('.docx');
  return { alts, transcribe };
}

// ---------------------------------------------------------------------------
// Path A — batched alt generation for embedded images
// ---------------------------------------------------------------------------

export async function extractImagesForDoc(
  doc: ExamDocument,
  onProgress?: (note: string, pct?: number) => void,
): Promise<{ images: ExtractedImage[]; warnings: string[]; error?: string }> {
  if (!doc.sourceFile) return { images: [], warnings: [], error: 'The original file is not available (re-parse the exam first).' };
  const name = (doc.filename || '').toLowerCase();
  onProgress?.('Reading the original file...', 8);
  const buf = await doc.sourceFile.arrayBuffer();
  if (name.endsWith('.docx')) {
    const res = await extractDocxImages(buf, { maxImages: MAX_EXTRACTION_IMAGES });
    return { images: res.images, warnings: res.warnings };
  }
  if (name.endsWith('.pdf')) {
    onProgress?.('Scanning the PDF for embedded images...', 20);
    const res = await extractPdfEmbeddedImages(buf, { maxImages: MAX_EXTRACTION_IMAGES });
    return { images: res.images, warnings: res.warnings };
  }
  return { images: [], warnings: [], error: 'This source type carries no extractable embedded images. Use the scanned-page transcription flow instead.' };
}

/** Merge extracted images into the doc's image list, reusing stable ids by content hash. */
function mergeWithExisting(doc: ExamDocument, extracted: ExtractedImage[]): ExamImage[] {
  const existing = new Map((doc.images || []).map((i) => [i.contentHash, i]));
  let next = 0;
  const out: ExamImage[] = [];
  for (const ex of extracted) {
    const prior = existing.get(ex.contentHash);
    if (prior) {
      // Keep the vision result (alt/kind/confidence/review state); refresh position evidence.
      out.push({
        ...prior,
        origin: ex.origin,
        page: ex.page,
        anchorIndex: ex.anchorIndex,
        bbox: ex.bbox,
        contextText: ex.contextText ?? prior.contextText,
        embeddedAlt: ex.embeddedAlt ?? prior.embeddedAlt,
        thumbnail: prior.thumbnail,
      });
    } else {
      next++;
      out.push({
        id: `img-${next}`,
        contentHash: ex.contentHash,
        origin: ex.origin,
        page: ex.page,
        anchorIndex: ex.anchorIndex,
        bbox: ex.bbox,
        contextText: ex.contextText,
        embeddedAlt: ex.embeddedAlt,
      });
    }
  }
  return out;
}

export async function runAltGeneration(
  doc: ExamDocument,
  opts: { providerConfig?: ProviderConfig; visionConfig: VisionConfig; onProgress?: (note: string, pct?: number) => void },
): Promise<VisionFlowResult & { stats?: AltGenerationStats }> {
  const warnings: string[] = [];
  const onProgress = opts.onProgress;
  const model = opts.visionConfig.model;

  try {
    // ---- 1. Extract (deterministic, 0 tokens) ----
    const extraction = await extractImagesForDoc(doc, onProgress);
    warnings.push(...extraction.warnings);
    if (extraction.error) return { ok: false, error: extraction.error, warnings };
    const extracted = extraction.images;
    if (extracted.length === 0) {
      return { ok: false, error: 'No embedded pictures were found in this file — nothing to describe.', warnings };
    }

    // ---- 2. Stable ids: reuse any prior vision results by content hash ----
    const images = mergeWithExisting(doc, extracted);
    const byId = new Map(images.map((i) => [i.id, i]));

    // ---- 3. Content-hash cache: hits never touch the wire ----
    onProgress?.('Checking the local vision cache...', 25);
    const needFetch: ExamImage[] = [];
    let cacheHits = 0;
    for (const img of images) {
      if (img.alt && img.alt.trim()) {
        continue; // already have a (human-approved or prior) result for this image
      }
      const hit = await visionCacheGet(visionCacheKey(img.contentHash, 'alts', model));
      if (hit) {
        img.alt = hit.alt;
        img.kind = hit.kind;
        img.confidence = hit.confidence;
        img.cached = true;
        img.model = hit.model;
        cacheHits++;
      } else {
        needFetch.push(img);
      }
    }

    const receipt: VisionReceipt = {
      ranAt: new Date().toISOString(),
      mode: 'alts',
      provider: opts.providerConfig?.provider || opts.visionConfig.provider,
      model,
      sent: 0,
      cacheHits,
      calls: 0,
      placed: 0,
      needsReview: 0,
      unplaced: 0,
      promptTokens: 0,
      completionTokens: 0,
      totalTokens: 0,
      warnings: [],
    };

    // ---- 4. Prepare + send ONLY the misses (batched; caps respected) ----
    if (needFetch.length > 0) {
      if (!opts.providerConfig) {
        return { ok: false, error: 'No AI provider configured. Set the vision provider in Settings first.', warnings };
      }
      onProgress?.(`Preparing ${needFetch.length} image(s) for the vision call...`, 40);
      const payloadFor = new Map<string, { id: string; mimeType: string; data: string; approxTokens: number }>();
      let payloadBytes = 0;

      for (const img of needFetch) {
        const ex = extracted.find((e) => e.contentHash === img.contentHash);
        if (!ex) continue;
        // Classify on a tiny downsample to route resolution: gentle for
        // text-bearing images, aggressive for photos.
        const kind = await quickClassify(ex);
        img.kind = kind === 'text' ? 'text' : kind;
        const targetPx = kind === 'photo' ? opts.visionConfig.photoImagePx : opts.visionConfig.textImagePx;
        const prepped = await prepImagePayload(ex.bytes, {
          targetPx,
          quality: kind === 'photo' ? Math.min(opts.visionConfig.jpegQuality, 0.65) : opts.visionConfig.jpegQuality,
          thumbnailPx: THUMBNAIL_PX,
        });
        if (!prepped) {
          img.error = 'The image could not be decoded for the vision call.';
          warnings.push(`Image ${img.id} could not be prepared — skipped.`);
          continue;
        }
        img.thumbnail = prepped.thumbnail;
        const approxTokens = Math.ceil(prepped.base64.length / 4);
        if (payloadFor.size >= opts.visionConfig.maxImagesPerCall || payloadBytes + prepped.base64.length > opts.visionConfig.maxPayloadBytes) {
          continue; // cap reached — the remaining images stay for the next run
        }
        payloadBytes += prepped.base64.length;
        payloadFor.set(img.id, { id: img.id, mimeType: 'image/jpeg', data: prepped.base64, approxTokens });
      }

      const items = [...payloadFor.values()];
      if (items.length > 0) {
        receipt.baselineTokens = items.reduce((s, i) => s + i.approxTokens + 80, 0);
        onProgress?.(`ONE batched vision call for ${items.length} image(s)...`, 60);
        const res = await fetch('/api/vision-batch', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            mode: 'alts',
            images: items.map(({ id, mimeType, data }) => ({ id, mimeType, data })),
            instruction: buildAltPrompt(
              items.map((it) => {
                const img = byId.get(it.id)!;
                return { id: it.id, contextText: img.contextText, embeddedAlt: img.embeddedAlt };
              }),
            ),
            providerConfig: opts.providerConfig,
          }),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.ok) {
          return { ok: false, error: data.error || `Vision call failed (HTTP ${res.status}).`, warnings };
        }
        receipt.calls = 1;
        receipt.sent = items.length;
        receipt.promptTokens = data.usage?.promptTokens || 0;
        receipt.completionTokens = data.usage?.completionTokens || 0;
        receipt.totalTokens = data.usage?.totalTokens || 0;
        receipt.model = data.model || model;

        const { results, warnings: parseWarnings } = parseAltResults(data.parsed, items.map((i) => i.id));
        warnings.push(...parseWarnings);
        for (const [id, r] of results) {
          const img = byId.get(id);
          if (!img) continue;
          img.alt = r.alt;
          img.kind = r.kind;
          img.confidence = r.confidence;
          img.cached = false;
          img.model = receipt.model;
          img.error = undefined;
          await visionCachePut(visionCacheKey(img.contentHash, 'alts', receipt.model), {
            alt: r.alt,
            kind: r.kind,
            confidence: r.confidence,
            model: receipt.model,
            ts: Date.now(),
          });
        }
        const missing = items.filter((i) => !byId.get(i.id)?.alt);
        if (missing.length > 0) {
          warnings.push(`${missing.length} image(s) returned no usable alt — they stay in the review panel.`);
        }
      }
    }

    // ---- 5. Position-based placement + immutable application ----
    onProgress?.('Placing images by position...', 85);
    const contextOf = (img: ExamImage) => img.contextText || '';
    const placements = placeImages(
      doc,
      images.map(
        (img): ExtractedImage => ({
          id: img.id,
          contentHash: img.contentHash,
          origin: img.origin === 'page' ? 'docx_media' : img.origin,
          mimeType: 'image/jpeg',
          bytes: new ArrayBuffer(0),
          width: 0,
          height: 0,
          page: img.page,
          anchorIndex: img.anchorIndex,
          bbox: img.bbox,
          contextText: contextOf(img),
          embeddedAlt: img.embeddedAlt,
        }),
      ),
    );
    for (const img of images) {
      const p = placements.get(img.id);
      if (!p) continue;
      if (img.placementStatus === 'manual' || img.placementStatus === 'review') {
        // A human decision (or an already-queued review) is never downgraded.
        continue;
      }
      img.questionId = p.questionId;
      img.placementConfidence = p.confidence;
    }

    const outcome = applyVisionToDoc(doc, images, { placementThreshold: opts.visionConfig.placementThreshold });
    receipt.placed = outcome.placed;
    receipt.needsReview = outcome.needsReview;
    receipt.unplaced = outcome.unplaced;
    if (warnings.length) receipt.warnings = warnings.slice(0, 12);

    onProgress?.('Done', 100);
    return {
      ok: true,
      doc: outcome.doc,
      receipt,
      warnings,
      stats: {
        extracted: extracted.length,
        cacheHits,
        sent: receipt.sent,
        placed: outcome.placed,
        needsReview: outcome.needsReview,
        unplaced: outcome.unplaced,
        calls: receipt.calls,
      },
    };
  } catch (e: any) {
    return { ok: false, error: e?.message || 'Vision alt generation failed.', warnings };
  }
}

/** Classify via raw pixels (works for docx bytes + decoded pdf images in the browser). */
async function quickClassify(ex: ExtractedImage): Promise<'text' | 'photo'> {
  try {
    if (typeof document === 'undefined' || typeof createImageBitmap !== 'function') return 'text';
    const bitmap = await createImageBitmap(new Blob([ex.bytes]));
    const s = Math.min(1, 96 / Math.max(bitmap.width, bitmap.height));
    const w = Math.max(1, Math.round(bitmap.width * s));
    const h = Math.max(1, Math.round(bitmap.height * s));
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return 'text';
    ctx.drawImage(bitmap, 0, 0, w, h);
    const { data } = ctx.getImageData(0, 0, w, h);
    return classifyImagePixels({ data, width: w, height: h });
  } catch {
    return 'text';
  }
}

// ---------------------------------------------------------------------------
// Path B — scanned-page transcription (Persian via vision; tesseract stays the
// offline English fallback and the automatic OFFLINE parse path)
// ---------------------------------------------------------------------------

export interface TranscribedPage {
  page: number;
  text: string;
  cached: boolean;
}

export async function runPageTranscription(
  doc: ExamDocument,
  opts: { providerConfig?: ProviderConfig; visionConfig: VisionConfig; onProgress?: (note: string, pct?: number) => void },
): Promise<VisionFlowResult & { pages?: TranscribedPage[] }> {
  const warnings: string[] = [];
  const onProgress = opts.onProgress;
  const model = opts.visionConfig.model;
  try {
    if (!doc.sourceFile) return { ok: false, error: 'The original file is not available (re-parse the exam first).', warnings };
    if (!opts.providerConfig) {
      return { ok: false, error: 'No AI provider configured. Vision transcription needs a vision-capable provider (see Settings).', warnings };
    }
    const pageCount = Math.min(await countPages(doc.sourceFile), 12);
    if (pageCount === 0) return { ok: false, error: 'The document has no pages.', warnings };

    const pages: TranscribedPage[] = [];
    const receipt: VisionReceipt = {
      ranAt: new Date().toISOString(),
      mode: 'transcribe',
      provider: opts.providerConfig.provider,
      model,
      sent: 0,
      cacheHits: 0,
      calls: 0,
      placed: 0,
      needsReview: 0,
      unplaced: 0,
      promptTokens: 0,
      completionTokens: 0,
      totalTokens: 0,
      warnings: [],
    };

    for (let p = 1; p <= pageCount; p++) {
      onProgress?.(`Rendering page ${p}/${pageCount}...`, Math.round(((p - 1) / pageCount) * 40));
      const prepped = await prepPageForVision(doc.sourceFile, p, opts.visionConfig.pageRenderScale);
      if (!prepped) {
        warnings.push(`Page ${p} could not be rendered — skipped.`);
        continue;
      }
      // Content-hash cache: a re-run NEVER re-bills a page.
      const key = visionCacheKey(prepped.contentHash, 'transcribe' as VisionPurpose, model);
      const hit = await visionCacheGet(key);
      if (hit) {
        pages.push({ page: p, text: hit.alt, cached: true });
        receipt.cacheHits++;
        onProgress?.(`Page ${p}: cached transcript (0 tokens)`, Math.round((p / pageCount) * 90));
        continue;
      }
      onProgress?.(`Transcribing page ${p}/${pageCount} with vision (one call per page)...`, Math.round(((p - 1) / pageCount) * 40) + 40 / pageCount);
      const res = await fetch('/api/vision-batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'transcribe',
          images: [{ id: `page-${p}`, mimeType: 'image/jpeg', data: prepped.base64 }],
          instruction: undefined,
          providerConfig: opts.providerConfig,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.ok) {
        warnings.push(`Page ${p} transcription failed: ${data.error || `HTTP ${res.status}`}`);
        continue;
      }
      receipt.calls++;
      receipt.sent++;
      receipt.promptTokens += data.usage?.promptTokens || 0;
      receipt.completionTokens += data.usage?.completionTokens || 0;
      receipt.totalTokens += data.usage?.totalTokens || 0;
      receipt.model = data.model || model;
      const text = String(data.rawText || '').trim();
      if (text) {
        pages.push({ page: p, text, cached: false });
        await visionCachePut(key, {
          alt: text.slice(0, 20000),
          kind: 'text',
          confidence: 0.9,
          model: receipt.model,
          ts: Date.now(),
        });
      } else {
        warnings.push(`Page ${p} returned an empty transcript.`);
      }
    }

    if (pages.length === 0) {
      return { ok: false, error: warnings[0] || 'No page produced a transcript.', warnings, receipt };
    }
    onProgress?.('Transcription complete', 100);
    return { ok: true, pages, receipt, warnings };
  } catch (e: any) {
    return { ok: false, error: e?.message || 'Vision transcription failed.', warnings };
  }
}
