import JSZip from 'jszip';
import * as pdfjsLib from 'pdfjs-dist';
import { BBox } from '../types/exam';
import { hashBytes } from './imageCache';

/**
 * Vision image extraction & preparation (Idea 3 — Path A).
 *
 * Path A (digital docs): pull every embedded picture out of the source file
 * WITH deterministic position evidence, so image→question placement is driven
 * by POSITION (docx drawing-anchor order / pdf image bbox vs text geometry),
 * never by keyword overlap alone.
 *
 * Design rules:
 *  • Fail-soft by construction: one unreadable image never blocks the batch.
 *  • Bounded: a media-heavy file cannot stall the flow (caps + size sanity).
 *  • "Read the document around the bytes first": docx wp:docPr alt text and
 *    the surrounding paragraph text are captured as context BEFORE any AI call.
 *  • Pure helpers (classification, geometry) are DOM-free so the gate can test
 *    them in node; anything touching canvas/pdfjs is browser-only and guarded.
 */

export interface ExtractedImage {
  /** Provisional id (img-1, img-2, ...) in document order — renumbered only if a caller merges. */
  id: string;
  /** Content hash of the ORIGINAL bytes (docx media) or decoded pixels (pdf). */
  contentHash: string;
  origin: 'docx_media' | 'pdf_embedded';
  mimeType: string;
  /** Original bytes when available (docx). PDF images arrive as JPEG-encoded decodes. */
  bytes: ArrayBuffer;
  width: number;
  height: number;
  page?: number;
  /** docx: line index the anchor paragraph maps to; pdf: global reading-order rank. */
  anchorIndex?: number;
  /** pdf: image bbox in PDF text-space (y up from bottom). */
  bbox?: BBox;
  /** Text immediately around the image in the source (placement + prompt context). */
  contextText?: string;
  /** Alt text stored IN THE FILE (docx wp:docPr descr / v:shape alt). */
  embeddedAlt?: string;
}

export interface ExtractionBundle {
  images: ExtractedImage[];
  warnings: string[];
}

const DOCX_MEDIA_RE = /^word\/media\/.+\.(png|jpe?g|gif|bmp|webp)$/i;
const MIN_IMAGE_EDGE = 24; // bullets, separators, decorative lines
const MAX_DOCX_IMAGE_BYTES = 12 * 1024 * 1024;

/** Long-edge cap for a full scanned page sent to vision (Persian legibility). */
export const VISION_PAGE_MAX_EDGE = 1600;

// ---------------------------------------------------------------------------
// Pure helpers (node-testable — no DOM)
// ---------------------------------------------------------------------------

/** Target dims keeping aspect ratio so the long edge = target. */
export function shrinkDims(
  width: number,
  height: number,
  target: number,
): { width: number; height: number } {
  const long = Math.max(width, height);
  if (long <= target || long === 0) return { width: width, height: height };
  const s = target / long;
  return { width: Math.max(1, Math.round(width * s)), height: Math.max(1, Math.round(height * s)) };
}

/**
 * Text-vs-photo router (drives resolution + prompt + compression).
 * Pure pixel heuristic on a small downsample:
 *   text/diagram-like = lots of near-white background, few colors, low chroma
 *   photo-like        = colorful, many unique colors, low white fraction
 * Deterministic, no ML, ~ms cost.
 */
export function classifyImagePixels(img: {
  data: Uint8ClampedArray | number[];
  width: number;
  height: number;
}): 'text' | 'photo' {
  const { data, width, height } = img;
  const n = Math.min(data.length / 4, 20000);
  if (!n || width === 0 || height === 0) return 'unknown' as unknown as 'text' | 'photo';

  const step = Math.max(1, Math.floor((width * height) / n));
  let white = 0;
  let colorful = 0;
  let total = 0;
  const palette = new Set<number>();

  for (let p = 0; p + 3 < data.length && total < n; p += 4 * step, total++) {
    const r = data[p];
    const g = data[p + 1];
    const b = data[p + 2];
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    if (min > 225 && max - min < 24) white++;
    const chroma = max - min;
    if (chroma > 40) colorful++;
    palette.add(((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4));
    if (palette.size > 512) break; // photos blow past this instantly
  }

  const whiteFrac = white / Math.max(1, total);
  const colorfulFrac = colorful / Math.max(1, total);
  const manyColors = palette.size > 64;

  // Diagrams/screenshots (text-bearing): mostly white, restrained palette.
  if (whiteFrac >= 0.35 && colorfulFrac < 0.14 && !manyColors) return 'text';
  // Anything else with heavy color variety is a photo.
  if (colorfulFrac >= 0.18 || (manyColors && whiteFrac < 0.3)) return 'photo';
  // Low-chroma, low-white but few colors: charts/graph paper → treat as diagram/text.
  return 'text';
}

/** Positional confidence decay: full inside the question's own lines, then decays. */
export function positionalConfidence(
  posIndex: number,
  questionRange: { lineStart?: number; lineEnd?: number } | undefined,
  nextQuestionStart: number | undefined,
): number {
  if (!questionRange || questionRange.lineStart === undefined) return 0.3;
  const { lineStart, lineEnd } = questionRange;
  if (lineEnd !== undefined && posIndex >= lineStart && posIndex <= lineEnd) return 0.95;
  if (posIndex >= lineStart && (nextQuestionStart === undefined || posIndex < nextQuestionStart)) {
    // Inside the question's "territory" but past its own text: strong if close.
    const gap = posIndex - lineStart;
    return Math.max(0.55, 0.9 - gap * 0.05);
  }
  return 0.3;
}

// ---------------------------------------------------------------------------
// DOCX embedded images (drawing anchors in document stream order)
// ---------------------------------------------------------------------------

interface DocxAnchor {
  rId: string;
  alt?: string;
  linePos: number; // count of non-empty paragraphs strictly before this paragraph
  paragraphText: string;
}

/**
 * Scan word/document.xml in order: every paragraph's text (non-empty → occupies
 * one line, matching extractTextFromDocx's line derivation) and every drawing
 * anchor (r:embed / r:id) with its wp:docPr descr (the file's own alt text).
 */
function scanDocxAnchors(docXml: string): DocxAnchor[] {
  const anchors: DocxAnchor[] = [];
  const pRe = /<w:p(?:\s[^>]*)?>([\s\S]*?)<\/w:p>|<w:p(?:\s[^>]*)?\/>/g;
  let m: RegExpExecArray | null;
  let linePos = 0;
  while ((m = pRe.exec(docXml)) !== null) {
    const pXml = m[0];
    const text = (pXml.match(/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g) || [])
      .map((t) => t.replace(/<[^>]+>/g, ''))
      .join('')
      .trim();
    const drawingRe = /<w:drawing[\s\S]*?<\/w:drawing>|<w:pict[\s\S]*?<\/w:pict>/g;
    let d: RegExpExecArray | null;
    const found: DocxAnchor[] = [];
    while ((d = drawingRe.exec(pXml)) !== null) {
      const dXml = d[0];
      const rid = (dXml.match(/r:(?:embed|id|link)="([^"]+)"/) || [])[1];
      const alt =
        (dXml.match(/<wp:docPr[^>]*\sdescr="([^"]*)"/) || [])[1] ||
        (dXml.match(/<wp:docPr[^>]*\sname="([^"]*)"/) || [])[1] ||
        (dXml.match(/<v:shape[^>]*\salt="([^"]*)"/) || [])[1] ||
        undefined;
      if (rid) {
        found.push({
          rId: rid,
          alt: alt ? alt.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').trim() : undefined,
          linePos,
          paragraphText: text,
        });
      }
    }
    anchors.push(...found);
    if (text) linePos++;
  }
  return anchors;
}

/** Extract embedded pictures from a .docx with position evidence. Browser+node safe (JSZip only). */
export async function extractDocxImages(
  data: ArrayBuffer,
  opts: { maxImages?: number } = {},
): Promise<ExtractionBundle> {
  const warnings: string[] = [];
  const maxImages = opts.maxImages ?? 20;
  const out: ExtractedImage[] = [];
  try {
    const zip = await JSZip.loadAsync(data);
    const docXmlFile = zip.file('word/document.xml');
    if (!docXmlFile) return { images: [], warnings: ['word/document.xml missing — no images extracted.'] };

    // rId -> media path
    const rels: Map<string, string> = new Map();
    const relsFile = zip.file('word/_rels/document.xml.rels');
    if (relsFile) {
      const relsXml = await relsFile.async('text');
      const relRe = /<Relationship\s[^>]*Id="([^"]+)"[^>]*Target="([^"]+)"[^>]*\/>/g;
      let r: RegExpExecArray | null;
      while ((r = relRe.exec(relsXml)) !== null) {
        if (/image/i.test(r[2]) || /media\//i.test(r[2])) rels.set(r[1], r[2].replace(/^\//, '').replace(/^word\//, 'word/'));
      }
    }

    const docXml = await docXmlFile.async('text');
    const anchors = scanDocxAnchors(docXml);

    for (const a of anchors) {
      if (out.length >= maxImages) {
        warnings.push(`Document has more than ${maxImages} embedded images — only the first ${maxImages} were processed.`);
        break;
      }
      const relTarget = rels.get(a.rId);
      if (!relTarget) {
        warnings.push(`Image anchor "${a.rId}" has no media relationship — skipped.`);
        continue;
      }
      const path = relTarget.startsWith('word/') ? relTarget : `word/${relTarget}`;
      const entry = zip.file(path);
      if (!entry) {
        warnings.push(`Media file ${path} not found in the archive — skipped.`);
        continue;
      }
      if (DOCX_MEDIA_RE.test(path) === false) continue; // wmf/emf etc. are not decodable here
      try {
        const buf = await entry.async('arraybuffer');
        if (buf.byteLength > MAX_DOCX_IMAGE_BYTES) {
          warnings.push(`Embedded image ${path} is unusually large (${(buf.byteLength / 1048576).toFixed(1)} MB) — skipped.`);
          continue;
        }
        const dims = await peekImageDims(buf).catch(() => ({ width: 0, height: 0 }));
        if (dims.width && (dims.width < MIN_IMAGE_EDGE || dims.height < MIN_IMAGE_EDGE)) continue; // decorative
        const contentHash = await hashBytes(buf);
        out.push({
          id: `img-${out.length + 1}`,
          contentHash,
          origin: 'docx_media',
          mimeType: mimeFromPath(path),
          bytes: buf,
          width: dims.width,
          height: dims.height,
          page: 1,
          anchorIndex: a.linePos,
          contextText: a.paragraphText ? a.paragraphText.slice(0, 300) : undefined,
          embeddedAlt: a.alt,
        });
      } catch (e: any) {
        warnings.push(`Embedded image ${path} could not be read: ${e?.message || e}`);
      }
    }
  } catch (e: any) {
    warnings.push(`DOCX image extraction failed (fail-soft): ${e?.message || e}`);
  }
  return { images: out, warnings };
}

function mimeFromPath(path: string): string {
  const lower = path.toLowerCase();
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.gif')) return 'image/gif';
  if (lower.endsWith('.bmp')) return 'image/bmp';
  if (lower.endsWith('.webp')) return 'image/webp';
  return 'image/jpeg';
}

// ---------------------------------------------------------------------------
// PDF embedded images (pdfjs image XObjects with bbox evidence)
// ---------------------------------------------------------------------------

/** Peek PNG/JPEG dimensions from header bytes (no canvas, node-safe). */
export async function peekImageDims(buf: ArrayBuffer): Promise<{ width: number; height: number }> {
  const b = new Uint8Array(buf);
  // PNG: 8-byte signature, IHDR at offset 16 (width) / 20 (height), big-endian
  if (b.length > 24 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) {
    const view = new DataView(buf);
    return { width: view.getUint32(16), height: view.getUint32(20) };
  }
  // JPEG: scan segments for SOF0..SOF3
  if (b.length > 4 && b[0] === 0xff && b[1] === 0xd8) {
    let i = 2;
    while (i + 9 < b.length) {
      if (b[i] !== 0xff) { i++; continue; }
      const marker = b[i + 1];
      const len = (b[i + 2] << 8) | b[i + 3];
      if (marker >= 0xc0 && marker <= 0xc3 && len >= 7) {
        return { height: (b[i + 5] << 8) | b[i + 6], width: (b[i + 7] << 8) | b[i + 8] };
      }
      i += 2 + Math.max(2, len);
    }
  }
  // GIF: 6-byte signature + LE dims
  if (b.length > 10 && b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46) {
    return { width: b[6] | (b[7] << 8), height: b[8] | (b[9] << 8) };
  }
  return { width: 0, height: 0 };
}

/** Multiply two 2D affine matrices [a,b,c,d,e,f] (pdf space, y up). */
function mul(m1: number[], m2: number[]): number[] {
  return [
    m1[0] * m2[0] + m1[2] * m2[1],
    m1[1] * m2[0] + m1[3] * m2[1],
    m1[0] * m2[2] + m1[2] * m2[3],
    m1[1] * m2[2] + m1[3] * m2[3],
    m1[0] * m2[4] + m1[2] * m2[5] + m1[4],
    m1[1] * m2[4] + m1[3] * m2[5] + m1[5],
  ];
}

function apply(m: number[], x: number, y: number): { x: number; y: number } {
  return { x: m[0] * x + m[2] * y + m[4], y: m[1] * x + m[3] * y + m[5] };
}

interface PdfImageObject {
  data?: Uint8ClampedArray | Uint8Array;
  width?: number;
  height?: number;
  kind?: number;
}

/** Decode a pdfjs image object into RGBA pixels (kinds 1/2/3). */
function decodePdfPixels(img: PdfImageObject): { rgba: Uint8ClampedArray; width: number; height: number } | null {
  const w = img.width || 0;
  const h = img.height || 0;
  const data = img.data;
  if (!w || !h || !data || data.length < w * h) return null;
  const rgba = new Uint8ClampedArray(w * h * 4);
  const kind = img.kind ?? 3;
  if (kind === 3 || data.length === w * h * 4) {
    rgba.set(data.subarray(0, w * h * 4));
  } else if (kind === 2 || data.length === w * h * 3) {
    for (let i = 0, s = 0, t = 0; i < w * h; i++, s += 3, t += 4) {
      rgba[t] = data[s];
      rgba[t + 1] = data[s + 1];
      rgba[t + 2] = data[s + 2];
      rgba[t + 3] = 255;
    }
  } else if (kind === 1 || data.length === Math.ceil((w * h) / 8)) {
    // 1bpp grayscale, rows padded to byte boundaries
    const rowBytes = Math.ceil(w / 8);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const bit = (data[y * rowBytes + (x >> 3)] >> (7 - (x & 7))) & 1;
        const v = bit ? 0 : 255; // 1bpp in pdfjs: 0 = black? actually bit=1 → black in most scans
        const t = (y * w + x) * 4;
        rgba[t] = v;
        rgba[t + 1] = v;
        rgba[t + 2] = v;
        rgba[t + 3] = 255;
      }
    }
  } else {
    return null;
  }
  return { rgba, width: w, height: h };
}

/**
 * Pull embedded raster images out of a (digital) PDF with bbox evidence.
 * Uses the operator list so the bbox comes from the actual CTM at paint time
 * (position-driven placement). Repeated XObjects (headers/logos) are deduped.
 * Browser-only (pdfjs render pipeline); node callers must not route here.
 */
export async function extractPdfEmbeddedImages(
  data: ArrayBuffer,
  opts: { maxImages?: number; contextLines?: { page: number; text: string; y?: number }[] } = {},
): Promise<ExtractionBundle> {
  const warnings: string[] = [];
  const out: ExtractedImage[] = [];
  const maxImages = opts.maxImages ?? 20;
  try {
    const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(data), useSystemFonts: true });
    const pdf = await loadingTask.promise;
    const seenNames = new Set<string>();
    let readingRank = 0;

    for (let pageNo = 1; pageNo <= pdf.numPages && out.length < maxImages; pageNo++) {
      const page = await pdf.getPage(pageNo);
      const ops = await page.getOperatorList();
      let ctm = [1, 0, 0, 1, 0, 0];
      const objs = (page as any).objs;

      for (let i = 0; i < ops.fnArray.length && out.length < maxImages; i++) {
        const fn = ops.fnArray[i];
        const args = ops.argsArray[i];
        if (fn === pdfjsLib.OPS.transform) {
          try {
            const m = args as number[];
            ctm = mul(ctm, m);
          } catch {
            // keep previous ctm
          }
          continue;
        }

        const isImage = fn === pdfjsLib.OPS.paintImageXObject;
        const isInline = fn === pdfjsLib.OPS.paintInlineImageXObject;
        if (!isImage && !isInline) continue;

        const paintCtm = ctm.slice();
        let raw: PdfImageObject | null = null;
        let xobjName = '';
        try {
          if (isInline) {
            raw = args[0] as PdfImageObject;
            xobjName = `inline-p${pageNo}-${i}`;
          } else {
            xobjName = String(args[0]);
            if (seenNames.has(xobjName)) continue; // repeated header/logo image
            raw = await new Promise<PdfImageObject | null>((resolve) => {
              const timer = setTimeout(() => resolve(null), 3000);
              try {
                objs.get(xobjName, (obj: PdfImageObject) => {
                  clearTimeout(timer);
                  resolve(obj || null);
                });
              } catch {
                clearTimeout(timer);
                try {
                  resolve((objs.get(xobjName) as PdfImageObject) || null);
                } catch {
                  clearTimeout(timer);
                  resolve(null);
                }
              }
            });
          }
        } catch {
          raw = null;
        }
        seenNames.add(xobjName);

        const decoded = raw ? decodePdfPixels(raw) : null;
        if (!decoded) continue;
        if (decoded.width < MIN_IMAGE_EDGE || decoded.height < MIN_IMAGE_EDGE) continue;

        // bbox = CTM applied to the unit square the image fills
        const c0 = apply(paintCtm, 0, 0);
        const c1 = apply(paintCtm, 1, 0);
        const c2 = apply(paintCtm, 0, 1);
        const c3 = apply(paintCtm, 1, 1);
        const xs = [c0.x, c1.x, c2.x, c3.x];
        const ys = [c0.y, c1.y, c2.y, c3.y];
        const bbox: BBox = {
          x: Math.min(...xs),
          y: Math.min(...ys),
          w: Math.abs(Math.max(...xs) - Math.min(...xs)),
          h: Math.abs(Math.max(...ys) - Math.min(...ys)),
        };

        // Encode to JPEG (browser canvas) — the payload + hash basis
        const encoded = await encodeRgbaToJpeg(decoded.rgba, decoded.width, decoded.height, 0.92).catch(() => null);
        if (!encoded) {
          warnings.push(`PDF image on page ${pageNo} could not be encoded — skipped.`);
          continue;
        }
        const contentHash = await hashBytes(encoded.bytes);

        // Context: nearest text above the image on the same page (from the parse trace)
        const contextText = nearestContext(opts.contextLines, pageNo, bbox);

        out.push({
          id: `img-${out.length + 1}`,
          contentHash,
          origin: 'pdf_embedded',
          mimeType: 'image/jpeg',
          bytes: encoded.bytes,
          width: decoded.width,
          height: decoded.height,
          page: pageNo,
          anchorIndex: readingRank++,
          bbox,
          contextText,
        });
      }
      try {
        page.cleanup();
      } catch {
        // ignore
      }
    }
  } catch (e: any) {
    warnings.push(`PDF image extraction failed (fail-soft): ${e?.message || e}`);
  }
  return { images: out, warnings };
}

function nearestContext(
  lines: { page: number; text: string; y?: number }[] | undefined,
  page: number,
  bbox: BBox,
): string | undefined {
  if (!lines || lines.length === 0) return undefined;
  const candidates = lines.filter((l) => l.page === page && l.text && l.y !== undefined);
  if (candidates.length === 0) return lines.filter((l) => l.page === page).map((l) => l.text).join(' ').slice(0, 300) || undefined;
  const imgTop = bbox.y + bbox.h;
  const above = candidates
    .filter((l) => (l.y as number) >= imgTop - 120 && (l.y as number) <= imgTop + 12)
    .sort((a, b) => Math.abs((a.y as number) - imgTop) - Math.abs((b.y as number) - imgTop))
    .slice(0, 3)
    .map((l) => l.text);
  return above.join(' ').slice(0, 300) || undefined;
}

// ---------------------------------------------------------------------------
// Pixel → canvas → JPEG encode/resize (browser-only, guarded)
// ---------------------------------------------------------------------------

async function encodeRgbaToJpeg(
  rgba: Uint8ClampedArray,
  width: number,
  height: number,
  quality: number,
): Promise<{ bytes: ArrayBuffer; base64: string } | null> {
  if (typeof document === 'undefined') return null;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;
  // Copy into a fresh ArrayBuffer-backed array (ImageData typing requirement).
  ctx.putImageData(new ImageData(new Uint8ClampedArray(rgba), width, height), 0, 0);
  return canvasToJpeg(canvas, quality);
}

export function canvasToJpeg(
  canvas: HTMLCanvasElement,
  quality: number,
): { bytes: ArrayBuffer; base64: string } | null {
  const dataUrl = canvas.toDataURL('image/jpeg', quality);
  const base64 = dataUrl.split(',')[1];
  if (!base64) return null;
  const bin = atob(base64);
  const bytes = new ArrayBuffer(bin.length);
  const view = new Uint8Array(bytes);
  for (let i = 0; i < bin.length; i++) view[i] = bin.charCodeAt(i);
  return { bytes, base64 };
}

/**
 * Prepare one image payload for the wire: decode → resize (long edge = target)
 * → JPEG → base64 + tiny thumbnail for the review UI. Text-bearing images keep
 * the gentle target so small labels stay legible; photos take the aggressive one.
 */
export async function prepImagePayload(
  bytes: ArrayBuffer,
  opts: { targetPx: number; quality: number; thumbnailPx?: number },
): Promise<{ base64: string; mimeType: 'image/jpeg'; contentHash?: string; thumbnail?: string; width: number; height: number } | null> {
  if (typeof document === 'undefined' || typeof createImageBitmap !== 'function') return null;
  try {
    const bitmap = await createImageBitmap(new Blob([bytes]));
    const target = shrinkDims(bitmap.width, bitmap.height, opts.targetPx);
    const canvas = document.createElement('canvas');
    canvas.width = target.width;
    canvas.height = target.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(bitmap, 0, 0, target.width, target.height);
    const jpeg = canvasToJpeg(canvas, opts.quality);
    if (!jpeg) return null;

    let thumbnail: string | undefined;
    if (opts.thumbnailPx) {
      const t = shrinkDims(bitmap.width, bitmap.height, opts.thumbnailPx);
      const tCanvas = document.createElement('canvas');
      tCanvas.width = t.width;
      tCanvas.height = t.height;
      const tCtx = tCanvas.getContext('2d');
      if (tCtx) {
        tCtx.fillStyle = '#ffffff';
        tCtx.fillRect(0, 0, tCanvas.width, tCanvas.height);
        tCtx.drawImage(bitmap, 0, 0, t.width, t.height);
        thumbnail = tCanvas.toDataURL('image/jpeg', 0.6);
      }
    }
    return { base64: jpeg.base64, mimeType: 'image/jpeg', thumbnail, width: target.width, height: target.height };
  } catch {
    return null;
  }
}

/**
 * Path B prep: render page N of the source (PDF page or image file) and pack
 * it for the transcription call. Hash covers the RENDERED JPEG so a changed
 * render scale legitimately re-extracts.
 */
export async function prepPageForVision(
  sourceFile: Blob,
  pageNo: number,
  renderScale: number,
): Promise<{ base64: string; contentHash: string; width: number; height: number; page: number } | null> {
  if (typeof document === 'undefined') return null;
  try {
    const { renderSourcePage } = await import('./pageRenderer');
    const rendered = await renderSourcePage(sourceFile, pageNo);
    const target = shrinkDims(rendered.width, rendered.height, VISION_PAGE_MAX_EDGE);
    const canvas = document.createElement('canvas');
    canvas.width = target.width;
    canvas.height = target.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(rendered.canvas, 0, 0, target.width, target.height);
    const jpeg = canvasToJpeg(canvas, 0.78);
    if (!jpeg) return null;
    const contentHash = await hashBytes(jpeg.bytes);
    return { base64: jpeg.base64, contentHash, width: target.width, height: target.height, page: pageNo };
  } catch {
    return null;
  }
}

export async function countPages(sourceFile: Blob): Promise<number> {
  try {
    const { countSourcePages } = await import('./pageRenderer');
    return await countSourcePages(sourceFile);
  } catch {
    return 1;
  }
}
