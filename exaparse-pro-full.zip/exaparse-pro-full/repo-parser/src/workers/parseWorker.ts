import { parseExamRawText, ParseOptions } from '../utils/parserEngine';
import { buildBrainPreSplit } from '../utils/parsePipeline';

/**
 * Off-main-thread parse worker (#5/#17). Vite bundles this via
 * `new Worker(new URL('./parseWorker.ts', import.meta.url), { type: 'module' })`.
 *
 * The layout-brain step runs HERE too (same shared helper as the main
 * pipeline): geometry-evidenced section blocks go in as `preSplit`, and the
 * brain report rides back to the main thread for the trust pipeline to attach.
 */
self.onmessage = (e: MessageEvent) => {
  const { rawText, filename, options, brainDoc, brainMode } = (e.data || {}) as {
    rawText: string;
    filename: string;
    options?: ParseOptions;
    brainDoc?: import('../utils/layoutBrain').BrainDoc;
    brainMode?: 'advisory' | 'drive';
  };
  try {
    const { preSplit, report } = buildBrainPreSplit(brainDoc, brainMode ?? 'drive');
    const doc = parseExamRawText(rawText, filename, options, preSplit);
    (self as any).postMessage({ ok: true, doc, brainReport: report });
  } catch (err: any) {
    (self as any).postMessage({ ok: false, error: err && err.message ? err.message : String(err) });
  }
};
