# -*- coding: utf-8 -*-
"""Adjudication pass 3 on MY hand-built GT + one document repair.

1. mock-02 DOC REPAIR: the fix_spec_order.py rownum-table reorder mangled the
   marks table (section A's بارم printed as '1' + a stray '2' cell). The
   hand-authored GT says A=2.5, so the document must print 2.5 and carry no
   stray cell. Repairing MY renderer bug, not the GT.
2. mock-02 GT: dialogue-completion inline choices (ریز مکالمه) follow the
   corpus convention = fill hints on fill_blank rows, category General
   (کلاس_هشتم_مستمر C). My authoring said inline_choice/Vocabulary.
3. mock-06 GT: the document restarts its question numbering twice (C: 1-2…
   F: 7-8, then G: 1-3… J: 8-11). The corpus convention preserves printed
   restarts (kelas-hashom-momtamer H=[1], I=[1-4]) — my authoring renumbered
   globally and double-used 5. Fix to the printed reading.
4. mock-10 GT: word-choice (گزینه) sections are Vocabulary in the corpus
   (11/11 inline_choice sections) — my authoring said General for section E.
"""
import json
import shutil
import sys

sys.path.insert(0, '/home/z/my-project/scripts')
import os

from mocklib import MOCKS_DIR, emit_gt, render_docx
from mock_specs_a import SPECS_A
from mock_specs_b import SPECS_B

by_file = {s['file']: s for s in SPECS_A + SPECS_B}

# --- 1+2. mock-02 -----------------------------------------------------------
m2 = by_file['mock-02-hashthom-mostamar.docx']
assert m2['body_lines'][0] == '1', m2['body_lines'][0]
m2['body_lines'][0] = '2.5'
assert m2['body_lines'][8] == '2', m2['body_lines'][8]
del m2['body_lines'][8]
for sec in m2['gt']['sections']:
    if sec['id'] == 'C':
        for q in sec['qs']:
            if q.get('t') == 'inline_choice':
                q['t'] = 'fill_blank'
        sec['cat'] = 'General'
src = render_docx(m2, os.path.join('/home/z/my-project/samples/mocks-src', m2['file']))
shutil.copy(src, os.path.join(MOCKS_DIR, m2['file']))
print('mock-02 doc repaired + re-rendered')

# --- 3. mock-06 -------------------------------------------------------------
m6 = by_file['mock-06-nohom-ocr.pdf']
want = {'C': [1, 2], 'D': [3, 4], 'E': [5, 6], 'F': [7, 8],
        'G': [1, 2, 3], 'H': [4, 5], 'I': [6, 7], 'J': [8, 9, 10, 11]}
for sec in m6['gt']['sections']:
    if sec['id'] in want:
        for q in sec['qs']:
            if q.get('stem') is not None:
                continue  # spot-check row
            q['n'] = want[sec['id']]
print('mock-06 GT numbering -> printed restarts')

# --- 4. mock-10 -------------------------------------------------------------
m10 = by_file['mock-10-motabegh-extra.docx']
for sec in m10['gt']['sections']:
    if sec['id'] == 'E':
        sec['cat'] = 'Vocabulary'
print('mock-10 E cat -> Vocabulary')

# Re-emit GT for the three files.
for key in ('mock-02-hashthom-mostamar.docx', 'mock-06-nohom-ocr.pdf', 'mock-10-motabegh-extra.docx'):
    path, stats = emit_gt(by_file[key])
    print(f"re-emitted {os.path.basename(path)} marks={stats['marks_total']} qs={stats['questions']}")
