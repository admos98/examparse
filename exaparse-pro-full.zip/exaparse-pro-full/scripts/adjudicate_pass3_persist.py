# -*- coding: utf-8 -*-
"""Adjudication pass 3 (persistent): apply the hand-GT corrections to the
SPEC FILES on disk (mock_specs_a.py / mock_specs_b.py), then re-emit GTs.

The earlier pass mutated specs in memory only, so the M6 re-emit for the
I-category fix resurrected the stale numbering. Spec files are the single
source of truth; this script makes the corrections stick.

Corrections (each cross-checked against the corpus family conventions):
1. M6 numbering: the engine renumbers continuously across the printed
   restarts — A 1-2, B 3-5, C 6-7 … J 21-24 (24 questions, no duplicate 5).
   (Kelas-hashom-style restarts keep their printed numbers; M6's F-T debris
   rows are answer-cell artifacts, so the human reading renumbers.)
2. M6 I cat General -> Vocabulary (word-choice sections 11/11 Vocabulary).
3. M10 E cat General -> Vocabulary (same convention).
4. M1 A: unnumbered dialogue turns are ALL questions, short_answer
   (zaban-haftom-nobat-avval sec 7 + 9th-1-3 D convention).
5. M2 C: dialogue-completion inline choice hints are fill_blank + General
   (kelas-hashom-momtamer C convention).
"""
import pprint
import re
import sys

sys.path.insert(0, '/home/z/my-project/scripts')
import importlib

import mocklib  # noqa: E402

# Load current specs, mutate, write back, then re-import fresh.
import mock_specs_a  # noqa: E402
import mock_specs_b  # noqa: E402

by_file = {s['file']: s for s in mock_specs_a.SPECS_A + mock_specs_b.SPECS_B}

# --- M6: preserve printed restart numbering ---------------------------------
# The engine (and the corpus convention — kelas-hashom-momtamer keeps H=[1])
# preserves the printed numbers across the doc's two restarts: the "F T"
# prefixes are answer-cell debris; the 1-/2- that follow are the real
# printed numbers. A=[1,2] B=[3,4,5] C=[1,2] D=[3,4] E=[5,6] F=[7,8]
# G=[1,2,3] H=[4,5] I=[6,7] J=[8,9,10,11].
want_m6 = {'C': [1, 2], 'D': [3, 4], 'E': [5, 6], 'F': [7, 8],
           'G': [1, 2, 3], 'H': [4, 5], 'I': [6, 7], 'J': [8, 9, 10, 11]}
m6 = by_file['mock-06-nohom-ocr.pdf']
for sec in m6['gt']['sections']:
    if sec['id'] in want_m6:
        for q in sec['qs']:
            if isinstance(q.get('stem'), str):
                # spot-check row: renumber with the section's first question
                q['n'] = want_m6[sec['id']][0]
                continue
            q['n'] = want_m6[sec['id']]
    if sec['id'] == 'I':
        sec['cat'] = 'Vocabulary'

# --- M10: E category --------------------------------------------------------
m10 = by_file['mock-10-motabegh-extra.docx']
for sec in m10['gt']['sections']:
    if sec['id'] == 'E':
        sec['cat'] = 'Vocabulary'

# --- M1: A section = all dialogue turns, short_answer -----------------------
m1 = by_file['mock-01-haftom-payani.docx']
for sec in m1['gt']['sections']:
    if sec['id'] == 'A':
        sec['qs'] = [{'n': [1, 2, 3, 4], 't': 'short_answer'}]

# --- M7: dictation completion (املا ناقص) = short_answer --------------------
# (engelisi-9-momtamer-yek sec 1 convention: short_answer with "Gen…ro….s")
m7 = by_file['mock-07-alefba.docx']
for sec in m7['gt']['sections']:
    if sec['id'] == 'الف':
        for q in sec['qs']:
            if q.get('t') == 'fill_blank':
                q['t'] = 'short_answer'

# --- M11: trailing "(1 نمره)" in stem spot-checks is a mark cell ------------
m11 = by_file['mock-11-nemreh-dakheli.pdf']
for sec in m11['gt']['sections']:
    for q in sec['qs']:
        if isinstance(q.get('stem'), str) and '(1 نمره' in q['stem']:
            q['stem'] = q['stem'].replace(' (1 نمره)', '').replace('(1 نمره)', '').strip()

# --- M2: C section = fill_blank / General -----------------------------------
m2 = by_file['mock-02-hashthom-mostamar.docx']
for sec in m2['gt']['sections']:
    if sec['id'] == 'C':
        for q in sec['qs']:
            if q.get('t') == 'inline_choice':
                q['t'] = 'fill_blank'
        sec['cat'] = 'General'


def write_back(path, var_name, specs):
    with open(path, 'w', encoding='utf-8') as f:
        f.write('# -*- coding: utf-8 -*-\n')
        f.write(f'"""Mock specs (auto-normalized by fix_spec_order.py; GT corrected by adjudicate_pass3_persist.py)."""\n\n')
        f.write(f"H7 = '{chr(0x2026) * 3}'  # blank ellipsis used across specs\n\n")
        f.write(f'{var_name} = ' + pprint.pformat(specs, width=100, sort_dicts=False) + '\n')


write_back('/home/z/my-project/scripts/mock_specs_a.py', 'SPECS_A', mock_specs_a.SPECS_A)
write_back('/home/z/my-project/scripts/mock_specs_b.py', 'SPECS_B', mock_specs_b.SPECS_B)
print('spec files updated on disk')

# Re-import fresh and re-emit the touched GTs.
for mod in ('mock_specs_a', 'mock_specs_b'):
    importlib.reload(sys.modules[mod])
fresh = {s['file']: s for s in sys.modules['mock_specs_a'].SPECS_A + sys.modules['mock_specs_b'].SPECS_B}
for key in ('mock-01-haftom-payani.docx', 'mock-02-hashthom-mostamar.docx', 'mock-07-alefba.docx', 'mock-11-nemreh-dakheli.pdf',
            'mock-06-nohom-ocr.pdf', 'mock-10-motabegh-extra.docx'):
    path, stats = mocklib.emit_gt(fresh[key])
    print(f"re-emitted {path.split('/')[-1]} marks={stats['marks_total']} qs={stats['questions']}")
