/**
 * End-to-end test for the /api/enhance-exam answer mapping fix.
 *
 * Spins up a mock OpenAI-compatible provider that returns an answers list where
 * BOTH sections have a question numbered 1 (with distinct ids and distinct answers).
 * Before the fix, the naive `answersList.find(a => a.id === q.id || String(a.number) === String(q.number))`
 * matched by NUMBER first, so Section B's Q1 wrongly received Section A's answer.
 * After the fix, id matching wins and the number fallback only applies when unambiguous.
 */
import http from 'http';

const MOCK_PORT = 9997;

const aiReply = JSON.stringify({
  examName: 'Mock Exam',
  answers: [
    { id: 'q-A-1-0', number: 1, correctAnswer: 'a' },
    { id: 'q-B-1-0', number: 1, correctAnswer: 'c' },
    // number-only entry (no id) → should apply ONLY to the one unambiguous Q2
    { number: 2, correctAnswer: 'd' },
  ],
});

const mock = http
  .createServer((req, res) => {
    if (req.url?.endsWith('/chat/completions')) {
      let body = '';
      req.on('data', (c) => (body += c));
      req.on('end', () => {
        res.setHeader('Content-Type', 'application/json');
        res.end(
          JSON.stringify({
            model: 'mock-model',
            choices: [{ message: { content: aiReply } }],
          }),
        );
      });
    } else {
      res.statusCode = 404;
      res.end('{}');
    }
  })
  .listen(MOCK_PORT);

const exam = {
  header: { courseName: 'C', schoolName: 'S', gradeAndMajor: 'G' },
  confidenceScore: 90,
  anomalies: [],
  sections: [
    {
      rowId: 'A',
      majorCategory: 'General',
      markTotal: 1,
      questions: [
        { id: 'q-A-1-0', number: 1, displayNumber: '1', sectionRowId: 'A', type: 'short_answer', stem: 'A stem', mark: 0.5 },
        { id: 'q-A-2-1', number: 2, displayNumber: '2', sectionRowId: 'A', type: 'short_answer', stem: 'A stem 2', mark: 0.5 },
      ],
    },
    {
      rowId: 'B',
      majorCategory: 'General',
      markTotal: 1,
      questions: [
        { id: 'q-B-1-0', number: 1, displayNumber: '1', sectionRowId: 'B', type: 'short_answer', stem: 'B stem', mark: 0.5 },
        { id: 'q-B-3-1', number: 3, displayNumber: '3', sectionRowId: 'B', type: 'short_answer', stem: 'B stem 3', mark: 0.5 },
      ],
    },
  ],
};

async function main() {
  await new Promise((r) => setTimeout(r, 300));
  const res = await fetch('http://localhost:3000/api/enhance-exam', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      exam,
      providerConfig: {
        provider: 'custom',
        baseURL: `http://localhost:${MOCK_PORT}/v1`,
        apiKey: 'mock-key',
        model: 'mock-model',
        temperature: 0.2,
        maxTokens: 512,
      },
    }),
  });

  const data = await res.json();
  mock.close();

  if (!res.ok || !data?.document) {
    console.error('REQUEST FAILED:', res.status, data);
    process.exit(1);
  }

  const qs = Object.fromEntries(
    data.document.sections.flatMap((s: any) => s.questions.map((q: any) => [q.id, q.correctAnswer])),
  );

  let failures = 0;
  const check = (id: string, expected: string, msg: string) => {
    const ok = qs[id] === expected;
    console.log(`  ${ok ? 'PASS' : 'FAIL'}: ${msg} (got "${qs[id]}", want "${expected}")`);
    if (!ok) failures++;
  };

  check('q-A-1-0', 'a', 'Section A Q1 keeps its own answer (id match)');
  check('q-B-1-0', 'c', 'Section B Q1 keeps its own answer — NOT contaminated by Section A (was the bug)');
  check('q-A-2-1', 'd', 'Ambiguity-free number fallback applies to Q2 (only one Q2 in exam)');
  check('q-B-3-1', undefined as unknown as string, 'Q3 untouched (no answer provided)');

  console.log(failures === 0 ? 'ANSWER-MAPPING TEST PASSED' : `${failures} ANSWER-MAPPING CHECK(S) FAILED`);
  process.exit(failures === 0 ? 0 : 1);
}

main();
