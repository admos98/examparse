# -*- coding: utf-8 -*-
"""fix-30 round 2: dual-prefix guard + debug strip + verbs + renumber flag."""
import io, sys

p = '/home/z/my-project/repo-parser/src/utils/parserEngine.ts'
s = io.open(p, encoding='utf-8').read()

def rep(old, new, tag, count=1):
    global s
    n = s.count(old)
    if n < count:
        print(f'FAIL [{tag}]: {n}x')
        sys.exit(1)
    s = s.replace(old, new, count)
    print(f'ok [{tag}]')

# 0. strip leftover debug lines (raw strings: backslashes literal)
rep(
    r"""    if (process.env.EXAPARSE_DEBUG_RENUM) console.log('RENUM seed', seed.rawNumber, JSON.stringify((seed.rawContent || '').slice(0, 70)));
    const cm = (seed.rawContent || '').match(/(?<![\d.\u2026_])(\d{1,3})(?!\d)\s*(?:[-–—.]?\s*)?(?:\.{2,}|…+|_{2,})/);
    if (process.env.EXAPARSE_DEBUG_RENUM && seed.rawNumber === 34) console.log('RENUM seed34 cm=', cm && cm[1], 'at', cm && cm.index);""",
    r"""    const cm = (seed.rawContent || '').match(/(?<![\d.\u2026_])(\d{1,3})(?!\d)\s*(?:[-–—.]?\s*)?(?:\.{2,}|…+|_{2,})/);""",
    'strip-debug',
)

rep(
    r"      /^(?:Choose|Fill in|Read|Match|Write|Make|Unscramble|Complete|Listen|Answer|Look at)/i.test(l) ||",
    r"      /^(?:Choose|Fill in|Read|Match|Write|Make|Unscramble|Complete|Listen|Answer|Look at|Combine|Put|Find|According)/i.test(l) ||",
    'english-inst-verbs',
)

rep(
    r"""      if (n >= 1 && n <= 150 && n !== seed.rawNumber && !seeds.some((x) => x.rawNumber === n)) {
        seed.rawNumber = n;
      }""",
    r"""      if (n >= 1 && n <= 150 && n !== seed.rawNumber && !seeds.some((x) => x.rawNumber === n)) {
        seed.rawNumber = n;
        (seed as Seed & { __renumbered?: boolean }).__renumbered = true;
      }""",
    'renumber-flag',
)

rep(
    r"""    const dualPrefixMatch = rawContent.match(/^(\d+)[\.\)]\s+([^\n]*)/);
    if (dualPrefixMatch) {
      const secondNum = parseInt(dualPrefixMatch[1], 10);
      originalNumber = rawNumber;
      if (options.normalizeNumbering) {""",
    r"""    const dualPrefixMatch = rawContent.match(/^(\d+)[\.\)]\s+([^\n]*)/);
    // A seed renumbered from its own printed blank slot ("44………….. ( corevdis )")
    // carries the answer-slot numbering — the leading "58." is copied-in debris
    // and must not win. Same for a SMALLER second index ("27. 18. …"): the outer
    // printed number is the exam's real sequence, the inner one is debris.
    const renumbered = (seed as Seed & { __renumbered?: boolean }).__renumbered === true;
    if (dualPrefixMatch && !renumbered) {
      const secondNum = parseInt(dualPrefixMatch[1], 10);
      originalNumber = rawNumber;
      if (options.normalizeNumbering && secondNum >= rawNumber) {""",
    'dual-prefix-guard',
)

io.open(p, 'w', encoding='utf-8').write(s)
print('ALL APPLIED')
