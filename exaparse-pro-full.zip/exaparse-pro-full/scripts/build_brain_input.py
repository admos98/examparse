#!/usr/bin/env python3
"""Build the layout brain's single input file per exam PDF.

Merges two extraction worlds into one JSON per exam:
  - PyMuPDF geometry  : scratch/geo-qu2/<stem>.json (hlines, rects, ruled
                        tables with cells, pymupdf textlines w/ size+bold)
  - pdftotext -bbox-layout : logical line grouping with word bboxes
The brain's `lines` array = pdftotext lines (structure-clean: letters,
numbers, Latin headers) ENRICHED with font size + bold from the best
vertically-overlapping PyMuPDF line. Unconsumed PyMuPDF lines are kept
(dedupe by y+prefix) so pdftotext drops never lose content.
Output: scratch/brain-qu2/<stem>.json
"""
import fitz, json, os, sys, glob, subprocess
import xml.etree.ElementTree as ET
from collections import Counter

GEO = "/home/z/my-project/repo-parser/scratch/geo-qu2"
OUT = "/home/z/my-project/repo-parser/scratch/brain-qu2"
QU2 = "/home/z/my-project/samples/qu2"
XLNS = "{http://www.w3.org/1999/xhtml}"

def r1(v): return round(float(v), 1)

def pdftotext_lines(path):
    """-> list per page of {text, bbox} logical-line groups."""
    proc = subprocess.run(["pdftotext", "-bbox-layout", path, "-"],
                          capture_output=True, text=True, timeout=120)
    if proc.returncode != 0:
        return []
    try:
        root = ET.fromstring(proc.stdout)
    except ET.ParseError:
        # some files emit stray control chars; strip and retry once
        clean = "".join(ch for ch in proc.stdout if ch >= " " or ch in "\n\r\t")
        try:
            root = ET.fromstring(clean)
        except ET.ParseError:
            return []
    pages = []
    for pg in root.iter(XLNS + "page"):
        lines = []
        for ln in pg.iter(XLNS + "line"):
            words = ln.findall(XLNS + "word")
            if not words:
                continue
            text = " ".join((w.text or "").strip() for w in words if (w.text or "").strip())
            if not text:
                continue
            bbox = [r1(min(float(w.get("xMin")) for w in words)),
                    r1(min(float(w.get("yMin")) for w in words)),
                    r1(max(float(w.get("xMax")) for w in words)),
                    r1(max(float(w.get("yMax")) for w in words))]
            lines.append({"text": text[:300], "bbox": bbox})
        pages.append(lines)
    return pages

def vy_overlap(a, b):
    y0 = max(a[1], b[1]); y1 = min(a[3], b[3])
    h = min(a[3] - a[1], b[3] - b[1])
    return max(0.0, (y1 - y0) / h) if h > 0 else 0.0

def hx_overlap(a, b):
    x0 = max(a[0], b[0]); x1 = min(a[2], b[2])
    w = min(a[2] - a[0], b[2] - b[0])
    return max(0.0, (x1 - x0) / w) if w > 0 else 0.0

def build(stem):
    geo_path = os.path.join(GEO, stem + ".json")
    pdf_path = os.path.join(QU2, stem + ".pdf")
    with open(geo_path, encoding="utf-8") as fh:
        geo = json.load(fh)
    pt_pages = pdftotext_lines(pdf_path)
    out_pages = []
    for pi, gpage in enumerate(geo["pages"]):
        pt_lines = pt_pages[pi] if pi < len(pt_pages) else []
        mlines = gpage.get("textlines", [])
        used = [False] * len(mlines)
        merged = []
        for L in pt_lines:
            best, bi, bs = None, -1, 0.0
            for mi, M in enumerate(mlines):
                if used[mi]:
                    continue
                s = vy_overlap(L["bbox"], M["bbox"]) * (0.3 + 0.7 * hx_overlap(L["bbox"], M["bbox"]))
                if s > bs:
                    bs, bi, best = s, mi, M
            size, bold = 12.0, False
            if best is not None and bs > 0.05:
                used[bi] = True
                size, bold = best["size"], bool(best.get("bold"))
            else:
                # proximity fallback: nearest PyMuPDF line center within 7pt
                cy = (L["bbox"][1] + L["bbox"][3]) / 2
                cx = (L["bbox"][0] + L["bbox"][2]) / 2
                near, nd = None, 1e9
                for mi, M in enumerate(mlines):
                    if used[mi]:
                        continue
                    my = (M["bbox"][1] + M["bbox"][3]) / 2
                    mx = (M["bbox"][0] + M["bbox"][2]) / 2
                    d = abs(my - cy) + (0 if abs(mx - cx) < 200 else 50)
                    if d < nd:
                        nd, near = d, M
                if near is not None and nd < 7:
                    size, bold = near["size"], bool(near.get("bold"))
            merged.append({"text": L["text"], "size": r1(size), "bold": bold,
                           "bbox": L["bbox"], "src": "pt"})
        # keep unconsumed pymupdf lines (things pdftotext dropped)
        for mi, M in enumerate(mlines):
            if used[mi]:
                continue
            t = (M.get("text") or "").strip()
            if not t:
                continue
            merged.append({"text": t[:300], "size": r1(M.get("size", 12.0)),
                           "bold": bool(M.get("bold")), "bbox": M["bbox"], "src": "fitz"})
        # dedupe: same rounded y + same 14-char prefix
        seen = set()
        dedup = []
        for L in merged:
            key = (round(L["bbox"][1] / 2), L["text"][:14])
            if key in seen:
                continue
            seen.add(key)
            dedup.append(L)
        dedup.sort(key=lambda L: (L["bbox"][1], L["bbox"][0]))
        out_pages.append({
            "width": gpage["width"], "height": gpage["height"],
            "hlines": gpage.get("hlines", []),
            "rects": gpage.get("rects", []),
            "tables": gpage.get("tables", []),
            "lines": dedup,
        })
    return {"file": stem + ".pdf", "pages": out_pages}

def main():
    os.makedirs(OUT, exist_ok=True)
    stems = sys.argv[1:] or [os.path.splitext(os.path.basename(p))[0]
                             for p in sorted(glob.glob(os.path.join(QU2, "*.pdf")))]
    ok = 0
    for stem in stems:
        try:
            data = build(stem)
            with open(os.path.join(OUT, stem + ".json"), "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False, separators=(",", ":"))
            nl = sum(len(p["lines"]) for p in data["pages"])
            nt = sum(len(p["tables"]) for p in data["pages"])
            print(f"{stem:32s} pages={len(data['pages']):2d} lines={nl:4d} tables={nt:2d}")
            ok += 1
        except Exception as e:
            print(f"{stem:32s} ERROR {e}")
    print(f"\nbuilt {ok}/{len(stems)} -> {OUT}")

if __name__ == "__main__":
    main()
