#!/usr/bin/env python3
"""Build curriculum-digest-v2.json from OFFICIAL textbook maps (chap.sch.ir
1405-1406 student books) + the user's v1 keyword strings.

Per lesson: official title, function, grammar (from the book's own Map pages),
reading passage (Vision), official vocab seeds, and the v1 keywords.
Also: grade aliases for the app's grade resolver + digestVersion hash.
"""
import json, hashlib

BASE = "/home/z/my-project/scratch/curriculum"
v1 = json.load(open(f"{BASE}/curriculum-digest-v1.json", encoding="utf-8"))

# ---------------- official map data (read from the books themselves) ----------
MAPS = {
 "english_7th_grade": {
  "book": "Prospect 1", "code": "C710", "pages": 88,
  "lessons": {
   "L1_My_Name": {"title": "My Name", "function": "Introducing yourself; Greeting",
    "grammar": ["Verb 'be': I am / My name is ...", "What's your name? / What's your first name?", "Greeting formulas: Hello, Hi, Good morning/afternoon, How are you?"],
    "vocab": ["boy", "girl", "man", "woman", "friend", "classmate", "first name", "last name"]},
   "L2_My_Classmates": {"title": "My Classmates", "function": "Asking someone's name; Introducing others",
    "grammar": ["Demonstratives: This is my friend ... / Who's that (boy)?", "Pronouns he/she with 'be': He's my friend", "Nice to meet you (, too).", "Possessive adjectives: my/your"],
    "vocab": ["new", "welcome", "card", "library card", "school"]},
   "L3_My_Age": {"title": "My Age", "function": "Talking about your age; Talking about dates",
    "grammar": ["'be' with age: How old are you? I'm ... years old.", "It's my birthday (today). / Happy birthday!", "When's your birthday? (It's) in (Bahman)."],
    "vocab": ["age", "birthday", "months of the year", "numbers 1 to 31", "date", "happy birthday"]},
   "L4_My_Family": {"title": "My Family", "function": "Talking about your family",
    "grammar": ["Possessive adjectives: my/your/his/her", "Indefinite article a/an with jobs: He's a (mechanic).", "How old is your (father)? / What's your father's job?"],
    "vocab": ["family", "mother", "father", "sister", "brother", "uncle", "aunt", "grandmother", "grandfather", "job", "mechanic", "doctor", "nurse", "housewife", "teacher", "dentist", "pilot", "driver", "shopkeeper", "picture", "numbers 1 to 100"]},
   "L5_My_Appearance": {"title": "My Appearance", "function": "Talking about appearance",
    "grammar": ["Adjectives for description: tall, short, young, old", "Present continuous: He's wearing (a gray suit).", "Which one is (Ladan)? / He's the (tall man)."],
    "vocab": ["tall", "short", "young", "old", "suit", "shirt", "jacket", "trousers", "pants", "manteau", "scarf", "chador", "shoes", "gloves", "black", "white", "red", "blue", "yellow", "green", "brown", "gray", "orange", "pink", "wear"]},
   "L6_My_House": {"title": "My House", "function": "Talking about where people are; Talking about what people are doing",
    "grammar": ["Present continuous: I'm/They're (cooking lunch). He/She is (studying).", "Where are you/they? Where's he/she?", "Is he/she in the (garage)? Yes, he/she is."],
    "vocab": ["house", "room", "bedroom", "kitchen", "living room", "garage", "office", "lunch", "hand", "cook", "wash", "watch", "play", "read", "study", "work", "come", "fix", "call"]},
   "L7_My_Address": {"title": "My Address", "function": "Talking about your address/phone number; Telling the time",
    "grammar": ["What's (your) address? / Where do (you) live?", "What's (your) telephone number?", "What time is it? / What time (is) he going? (at/around 5 o'clock, a.m./p.m.)"],
    "vocab": ["address", "home", "street", "telephone", "phone number", "mobile", "cell phone", "call", "go", "live", "visit", "time", "a.m.", "p.m.", "o'clock", "evening"]},
   "L8_My_Favorite_Food": {"title": "My Favorite Food", "function": "Talking about your favorite food",
    "grammar": ["What's your favorite food/drink?", "What do you like to eat/drink?", "feel + adjective: feel hungry/thirsty; like + noun"],
    "vocab": ["food", "drink", "hungry", "thirsty", "favorite", "bread", "rice", "kebab", "chicken", "salad", "fruit", "juice", "orange", "dates", "cake", "milk", "tea", "water", "jelly", "quince", "coconut", "zucchini", "feel", "like", "enough"]},
  }},
 "english_8th_grade": {
  "book": "Prospect 2", "code": "C810", "pages": None,
  "lessons": {
   "L1_My_Nationality": {"title": "My Nationality", "function": "Talking about Nationalities",
    "grammar": ["'be' questions: Are you from Iran? Are you Iranian? Where are you from?", "Yes/No short answers with 'be': Yes, I am. No, I'm not.", "Countries and nationalities"],
    "vocab": ["country", "countries", "nationality", "Iranian", "Iran", "Persian Gulf", "Caspian Sea", "continent"]},
   "L2_My_Week": {"title": "My Week", "function": "Talking about Daily Activities",
    "grammar": ["Present simple: I go to school. / When do you study English?", "Prepositions of time: on Monday mornings, every Wednesday afternoon", "Days in a week / time of day: sunrise, noon, midnight"],
    "vocab": ["daily activities", "days in a week", "weekday", "weekend", "sunrise", "sunset", "midday", "noon", "midnight", "go shopping", "visit relatives", "study lessons", "relax", "stay", "gym"]},
   "L3_My_Shopping": {"title": "My Shopping / My Abilities", "function": "Talking about Abilities",
    "grammar": ["Modal 'can' for ability: Can you ride a bicycle? Yes, I can. No, I can't.", "be good at + noun/-ing: Are you good at drawing?", "Who can play tennis?"],
    "vocab": ["abilities", "ride a bicycle", "play tennis", "make a cake", "draw", "drawing", "take photos", "swim", "run", "type", "speak", "read", "good at"]},
   "L4_My_Health": {"title": "My Health", "function": "Talking about Health Problems; Giving Health Advice",
    "grammar": ["should / shouldn't for advice", "have + health problem: I have a headache / the flu / a toothache.", "Why don't you go to the dentist? (suggestions)", "What's wrong?"],
    "vocab": ["health problems", "headache", "backache", "toothache", "stomachache", "sore throat", "fever", "earache", "flu", "cough", "patient", "medicine", "drugstore", "dentist", "rest", "quiet", "sneeze"]},
   "L5_My_City": {"title": "My City", "function": "Talking about a Place",
    "grammar": ["there is / there are (+ any): Is there a metro system? Are there any museums?", "What's Isfahan like? It's a big city.", "It's very famous for its ...", "Where is ...? It's in the center of Iran."],
    "vocab": ["places in a city", "geographical directions", "park", "hospital", "bank", "museum", "mosque", "cinema", "zoo", "stadium", "boulevard", "restaurant", "palace", "bridge", "shrine", "building", "church", "capital", "tourist", "downtown", "metro", "train station", "bus station", "airport", "center", "famous", "special", "clean", "old", "north", "south", "east", "west"]},
   "L6_My_Village": {"title": "My Village", "function": "Talking about a Place; Talking about Weather",
    "grammar": ["What's the weather like in ...? It's sunny.", "Is it cold in winter? Yes, it is. / No, it isn't.", "'It is' + weather adjectives; seasons"],
    "vocab": ["village", "countryside", "mountain village", "field", "hill", "mountain", "river", "tree", "flower", "sunflower", "animal", "cow", "cattle", "hen", "horse", "raise", "plow", "tractor", "weather", "thermometer", "wind", "rain", "spring", "summer", "fall", "winter", "warm", "cold", "hot", "dry", "icy", "rainy", "sunny", "snowy"]},
   "L7_My_Hobbies": {"title": "My Hobbies", "function": "Talking about Hobbies; Talking about Free Time Activities",
    "grammar": ["Gerunds after like/love/enjoy: Yes, listening to stories on the radio.", "Present simple + adverbs of frequency: I usually go shopping.", "What do you do in your free time? How about ...?"],
    "vocab": ["hobbies", "free time", "free-time activities", "poem", "magazine", "horse riding", "reading", "playing computer games", "watching movies", "walking in the park", "skiing", "fishing", "shopping", "gardening", "browsing the internet", "listening to the radio", "sports news", "enjoy", "usually", "sometimes"]},
  }},
 "english_9th_grade": {
  "book": "Prospect 3", "code": "C910", "pages": None,
  "lessons": {
   "L1_Personality": {"title": "Personality", "function": "Talking about Personality",
    "grammar": ["Simple Present Tense (to be)", "Contraction of verbs: He's not shy. = He isn't shy.", "What's your friend like?"],
    "vocab": ["personality", "shy", "angry", "brave", "careless", "cruel", "rude", "nervous", "quiet", "funny", "selfish", "neat", "kind", "clever", "patient", "hard-working", "careful", "talkative", "pleasant", "lazy", "helpful", "generous", "friendly", "polite", "serious", "upset", "best friend"]},
   "L2_Travel": {"title": "Travel", "function": "Talking about Travel",
    "grammar": ["Present Continuous Tense: Are you visiting Tehran? Who is speaking English now?", "Possessive ('s and of)", "I'm interested in ..., How about you?"],
    "vocab": ["travel", "trip", "ticket", "passport", "check in", "timetable", "take off", "land", "exchange money", "fill out the form", "book a hotel", "pack for a trip", "receptionist", "reservation", "board the plane", "voyage", "weigh the baggage", "baggage reclaim", "tourist", "guide book", "gift shop", "map", "suitable", "possible"]},
   "L3_Festivals_and_Ceremonies": {"title": "Festivals and Ceremonies", "function": "Talking about Festivals and Ceremonies",
    "grammar": ["Simple Present Tense (do/does): Do you buy new clothes for the new year? Does he recite the Holy Quran?", "Possessive Adjectives"],
    "vocab": ["festivals", "ceremonies", "Nowruz", "Norooz", "Yalda", "Eid", "celebrate", "national anthem", "ceremony", "fireworks", "poems of Hafez", "religious holidays", "military parade", "Haft Seen table", "New Year", "gold fish", "Muslim", "national", "international"]},
   "L4_Services": {"title": "Services", "function": "Talking about Services",
    "grammar": ["Wh- Questions: What's her job? What time does it open?", "Adverbs of Frequency: often, never, usually"],
    "vocab": ["public services", "make lunch", "bake a cake", "set the table", "clear the table", "emergency", "ATM", "take out money", "get on/off a bus", "hire a taxi", "open an account", "put out fire", "post office", "fire station", "firefighter", "ER", "stamp", "envelope", "postcard", "send an e-mail", "gas station", "e-ticket", "charity", "donate blood", "voluntary work", "shift", "break"]},
   "L5_Media": {"title": "Media", "function": "Talking about Media",
    "grammar": ["Past Tense (Regular): Did the girls listen to the radio? Yes, they did.", "Past Tense of 'to be': Who watched the movie last night?"],
    "vocab": ["media", "send an e-mail", "receive an e-mail", "update a blog", "online course", "connect to the internet", "download", "TV program", "information technology", "IT", "computer", "radio", "newspaper", "surf", "website", "text a message", "antivirus", "quiz show", "TV channels", "war movie", "interview", "newsstand", "movie", "cartoon", "comedy", "event", "report", "attend", "yesterday"]},
   "L6_Health_and_Injuries": {"title": "Health and Injuries", "function": "Talking about Health and Injuries",
    "grammar": ["Past Tense (Irregular): Did Mina have an accident?", "Object Pronouns: me, him, her, them"],
    "vocab": ["health", "injuries", "first aid", "hurt", "broken", "accident", "wound", "feel sick", "ambulance", "injury", "car crash", "heart attack", "break one's leg", "cut one's finger", "burn one's hand", "twist one's ankle", "hit one's head", "fall down", "bleed", "bleeding", "scar", "bruise", "black eye", "plaster", "cast", "take care", "knee", "ankle", "happen", "plan"]},
  }},
 "english_10th_grade": {
  "book": "Vision 1", "code": "C110230", "pages": None,
  "lessons": {
   "L1_Saving_Nature": {"title": "Saving Nature", "function": "Talking about nature, endangered animals and protection",
    "grammar": ["Future tense with 'will' (See also: be going to)", "Nouns: singular & plural, noun markers"],
    "reading": "Endangered Animals",
    "writingFocus": "Nouns (singular and plural types, noun markers)",
    "vocab": ["environment", "nature", "pollution", "protect", "forest", "endangered", "natural resources", "wildlife", "die out", "extinct", "injure", "hunt", "hunter", "save", "take care of", "destroy", "habitat", "jungle", "plain", "national park", "cut down trees", "increase", "decrease", "voluntary work", "leopard", "cheetah", "zebra", "goat", "whale", "panda", "elephant", "duck", "wolf", "alive", "living thing", "earth"]},
   "L2_Wonders_of_Creation": {"title": "Wonders of Creation", "function": "Describing the natural world and God's creation",
    "grammar": ["Adjectives: comparative and superlative (kinds, spelling hints, place)", "See also: comparison forms"],
    "reading": "A Wonderful Liquid",
    "writingFocus": "Adjectives (kinds, spelling hints, place of adjectives)",
    "vocab": ["creation", "wonders", "creatures", "biology", "planet", "orbit", "observatory", "moon", "cell", "organ", "blood", "microbe", "liquid", "power", "powerful", "defend", "carry", "collect", "compare", "wooden", "soldier", "attack", "fight", "among", "area", "nationality", "of course", "in fact", "actually", "against", "abroad"]},
   "L3_The_Value_of_Knowledge": {"title": "The Value of Knowledge", "function": "Talking about knowledge, science and famous scholars",
    "grammar": ["Past Progressive (narrating a story)", "See also: reflexive/self pronouns (myself, yourself, himself)", "Action and state verbs; simple and continuous verbs"],
    "reading": "No Pain, No Gain",
    "writingFocus": "Verbs (action and state, simple and continuous)",
    "vocab": ["knowledge", "learning", "science", "education", "wisdom", "discovery", "scholars", "value", "scientist", "researcher", "research", "thinker", "inventor", "invent", "invention", "discover", "experiment", "laboratory", "observe", "solve", "develop", "belief", "believe", "translate", "translator", "publish", "skill", "express", "emotion", "thought", "idea", "sense", "medicine", "antibiotic", "penicillin", "quit", "give up", "pass away", "seek", "success", "successful", "fortunately", "prophet", "cradle", "grave", "emphasis", "no pain no gain", "myself", "yourself", "himself"]},
   "L4_Traveling_the_World": {"title": "Traveling the World", "function": "Talking about travel, tourism and cultures",
    "grammar": ["Modals: obligations and necessities (asking about obligations and necessities)", "See also: prepositions", "Adverbs: how to make -ly adverbs, irregular adverbs"],
    "reading": "Iran: A True Paradise",
    "writingFocus": "Adverbs (-ly adverbs, irregular adverbs)",
    "vocab": ["travel", "countries", "cultures", "tourism", "journey", "sightseeing", "foreign", "trip", "tour", "tourist", "traveler", "pilgrim", "destination", "attraction", "attract", "vacation", "ticket", "passport", "baggage", "luggage", "check in", "hotel", "plane", "airplane", "train", "ship", "boat", "balloon", "helicopter", "bicycle", "nation", "international", "local", "domestic", "hospitable", "polite", "famous", "souvenir", "historical site", "holy shrine", "desert", "camera", "map"]},
  }},
 "english_11th_grade": {
  "book": "Vision 2", "code": "C111230", "pages": None,
  "lessons": {
   "L1_Understanding_People": {"title": "Understanding People", "function": "Talking about languages, communication and understanding people",
    "grammar": ["Countable and Uncountable Nouns (See also: numbers)", "Simple sentences (writing focus)"],
    "reading": "Languages of the World",
    "writingFocus": "Simple Sentences",
    "vocab": ["understanding people", "relationships", "communication", "feelings", "emotions", "empathy", "character", "behavior", "scanning", "foreigner", "foreign", "native speaker", "spoken", "live language", "population", "percent", "century", "communicate", "respect", "interview", "explain", "explanation", "imagine", "exist", "disappear", "means", "meet the needs of", "physical", "smart", "region", "farming region", "receive", "therefore", "surprising", "borrow", "look for", "synonyms"]},
   "L2_A_Healthy_Lifestyle": {"title": "A Healthy Lifestyle", "function": "Talking about health, lifestyle and wellbeing",
    "grammar": ["Present Perfect (talking about past experiences) (See also: phrasal verbs)", "Gerunds (writing focus)"],
    "reading": "Having a Healthier and Longer Life",
    "writingFocus": "Gerunds",
    "vocab": ["health", "healthy lifestyle", "diet", "exercise", "sleep", "physical health", "emotional health", "longer life", "wellbeing", "skimming", "unhealthy", "blood pressure", "heartbeat", "measure", "height", "weight", "gain weight", "family health history", "illness", "disease", "heart attack", "risk", "habit", "quit", "hurt oneself", "prevent", "effective", "live longer", "busy lifestyle", "daily exercise", "stress", "relax", "balanced", "prefixes and suffixes"]},
   "L3_Art_and_Culture": {"title": "Art and Culture", "function": "Talking about art, culture and handicrafts",
    "grammar": ["Conditional Type I (talking about conditions and future results) (See also: past participles)"],
    "reading": "Art, Culture and Society",
    "writingFocus": "Reference words",
    "vocab": ["art", "culture", "music", "painting", "heritage", "artists", "handicrafts", "calligraphy", "traditional art", "reference words", "cultural", "artistic", "artwork", "practice art", "handicraft", "hand-made product", "weave", "rug", "carpet", "silk", "pottery", "tile", "calligraphic", "decorative", "creative", "creativity", "imagination", "skillful", "appreciate", "value", "diversity", "identity", "humankind", "society", "sociable", "reflect", "unique", "vast", "economy", "prize", "introduce", "proud", "fortunate", "collection", "antonyms"]},
  }},
 "english_12th_grade": {
  "book": "Vision 3", "code": "C112230", "pages": None,
  "lessons": {
   "L1_Sense_of_Appreciation": {"title": "Sense of Appreciation", "function": "Talking about appreciation, gratitude and respecting parents",
    "grammar": ["Passive Voice (See also: tag questions)", "Compound sentences (writing focus)"],
    "reading": "Respect Your Parents",
    "writingFocus": "Compound Sentences",
    "vocab": ["appreciation", "gratitude", "thankfulness", "parenting", "family", "respect", "honor", "kindness", "parents", "love", "appreciate", "emotion", "express", "forgive", "generous", "loving", "lovingly", "hug", "kiss", "take care", "feed", "elderly", "teenager", "bilingual", "technology", "smartphone", "diary", "ethics", "cruel", "strength", "reply", "orally", "aloud", "hard of hearing", "burst into tears", "spare no pains", "handle", "distinguished", "diploma", "collocations", "for instance", "on the other hand"]},
   "L2_Look_It_Up": {"title": "Look It Up!", "function": "Talking about dictionaries and research skills",
    "grammar": ["Relative Clauses (See also: Conditional sentences Type II)", "Paragraph (writing focus)"],
    "reading": "How to Use a Dictionary",
    "writingFocus": "Paragraph",
    "vocab": ["dictionary", "look it up", "reference", "research", "information", "encyclopedia", "sources", "compile", "define", "abbreviation", "pocket dictionary", "learner's dictionary", "entry", "term", "synonym", "antonym", "definition", "biography", "volume", "introduction", "arrangement", "alphabetical", "highlight", "stand for", "figure out", "convert", "technical", "section", "level", "treasure", "magnifying glass", "telescope", "invisible", "essential", "allow", "avoid", "monolingual", "app", "World Wide Web", "hardworking", "crop", "endanger", "immediate", "generally", "primarily", "whereas", "word part families"]},
   "L3_Renewable_Energy": {"title": "Renewable Energy", "function": "Talking about energy, technology and the environment",
    "grammar": ["Passive Voice with Modals (See also: Past perfect tense)", "Talking about an activity before another activity in the past (past perfect)"],
    "reading": "Earth for Our Children",
    "writingFocus": "Proverbs",
    "vocab": ["renewable energy", "solar", "wind", "energy resources", "environment", "technology", "electricity", "fossil fuels", "sustainable", "power", "clean energy", "fuel", "oil", "resource", "solar power", "solar system", "blow", "tide", "kinetic energy", "pollute", "pollution", "reduce", "consume", "require", "necessary", "replace", "harm", "charge", "outlet", "LED light bulb", "store", "forever", "variety", "practical", "voluntary", "Nobel Prize", "demand", "increase", "decrease", "planet", "thus", "client", "proverbs"]},
  }},
}

GRADE_ALIASES = {
 "english_7th_grade": ["7", "7th", "grade 7", "grade7", "seventh", "\u0647\u0641\u062a\u0645", "\u067e\u0627\u06cc\u0647 \u0647\u0641\u062a\u0645", "\u0627\u0648\u0644 \u0645\u062a\u0648\u0633\u0637\u0647 \u0627\u0648\u0644", "\u0645\u062a\u0648\u0633\u0637\u0647 \u0627\u0648\u0644", "prospect 1"],
 "english_8th_grade": ["8", "8th", "grade 8", "grade8", "eighth", "\u0647\u0634\u062a\u0645", "\u067e\u0627\u06cc\u0647 \u0647\u0634\u062a\u0645", "\u062f\u0648\u0645 \u0645\u062a\u0648\u0633\u0637\u0647 \u0627\u0648\u0644", "\u0645\u062a\u0648\u0633\u0637\u0647 \u0627\u0648\u0644", "prospect 2"],
 "english_9th_grade": ["9", "9th", "grade 9", "grade9", "ninth", "\u0646\u0647\u0645", "\u067e\u0627\u06cc\u0647 \u0646\u0647\u0645", "\u0633\u0648\u0645 \u0645\u062a\u0648\u0633\u0637\u0647 \u0627\u0648\u0644", "\u0645\u062a\u0648\u0633\u0637\u0647 \u0627\u0648\u0644", "prospect 3"],
 "english_10th_grade": ["10", "10th", "grade 10", "grade10", "tenth", "\u062f\u0647\u0645", "\u067e\u0627\u06cc\u0647 \u062f\u0647\u0645", "\u0627\u0648\u0644 \u0645\u062a\u0648\u0633\u0637\u0647 \u062f\u0648\u0645", "\u0645\u062a\u0648\u0633\u0637\u0647 \u062f\u0648\u0645", "vision 1"],
 "english_11th_grade": ["11", "11th", "grade 11", "grade11", "eleventh", "\u06cc\u0627\u0632\u062f\u0647\u0645", "\u067e\u0627\u06cc\u0647 \u06cc\u0627\u0632\u062f\u0647\u0645", "\u062f\u0648\u0645 \u0645\u062a\u0648\u0633\u0637\u0647 \u062f\u0648\u0645", "\u0645\u062a\u0648\u0633\u0637\u0647 \u062f\u0648\u0645", "vision 2"],
 "english_12th_grade": ["12", "12th", "grade 12", "grade12", "twelfth", "\u062f\u0648\u0627\u0632\u062f\u0647\u0645", "\u067e\u0627\u06cc\u0647 \u062f\u0648\u0627\u0632\u062f\u0647\u0645", "\u0633\u0648\u0645 \u0645\u062a\u0648\u0633\u0637\u0647 \u062f\u0648\u0645", "\u0645\u062a\u0648\u0633\u0637\u0647 \u062f\u0648\u0645", "vision 3"],
}

def bounded(s, n):
    return s if len(s) <= n else s[: n - 1].rstrip() + "\u2026"

out = {"_provenance": "", "_format": "", "grades": {}}
for gkey, gmap in MAPS.items():
    g1 = v1.get(gkey, {})
    lessons_out = {}
    for lid, spec in gmap["lessons"].items():
        kw = g1.get("lessons", {}).get(lid, "")
        # compose the Jev Choice description: function + grammar + official keywords
        parts = [f"{spec['title']} \u2014 {spec['function']}", "Grammar: " + "; ".join(spec["grammar"])]
        if spec.get("reading"):
            parts.append(f"Reading: {spec['reading']}")
        desc = " | ".join(parts)
        if kw:
            desc += " | " + kw
        lessons_out[lid] = {
            "title": spec["title"],
            "function": spec["function"],
            "grammar": spec["grammar"],
            **({"reading": spec["reading"]} if spec.get("reading") else {}),
            **({"writingFocus": spec["writingFocus"]} if spec.get("writingFocus") else {}),
            "vocabOfficial": spec["vocab"],
            **({"keywords": kw} if kw else {}),
            "choiceDescription": bounded(desc, 1400),
        }
    out["grades"][gkey] = {
        "book": gmap["book"],
        "bookCode": gmap["code"],
        "lessonCount": len(lessons_out),
        "aliases": GRADE_ALIASES[gkey],
        "lessons": lessons_out,
    }

out["_format"] = ("ExaParse Pro curriculum digest v2. grades.<key>.lessons.<L#> per lesson: "
 "title/function/grammar/reading/writingFocus/vocabOfficial/keywords + composed "
 "choiceDescription for Jev Choice option descriptions. grades.<key>.aliases feeds "
 "the grade resolver. digestVersion = sha256 of this file's grade content.")
out["_provenance"] = ("Lesson titles, functions, grammar and reading passages read "
 "directly from the official Map of Prospect/Vision pages of the 1405-1406 print "
 "student books downloaded from chap.sch.ir (C710, C810, C910, C110230, C111230, "
 "C112230). Keyword strings inherited from user's v1 digest (classtop.ir / "
 "b-amooz sourced). Vision 1 has 4 lessons, Vision 2/3 and Prospect 3 have 6/3/3 "
 "as printed. Grammar for Prospect 1-2 is the book's key-language/function "
 "syllabus (the series teaches functions, not rule labels, in grades 7-8).")

# digestVersion from the grade content
payload = json.dumps(out["grades"], ensure_ascii=False, sort_keys=True)
out["version"] = 2
out["digestVersion"] = hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]

dst = "/home/z/my-project/download/curriculum-digest-v2.json"
json.dump(out, open(dst, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
json.dump(out, open(f"{BASE}/curriculum-digest-v2.json", "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)

import os
print("wrote", dst, os.path.getsize(dst), "bytes; digestVersion", out["digestVersion"])
for g, d in out["grades"].items():
    lens = [len(l["choiceDescription"]) for l in d["lessons"].values()]
    print(f"  {g} ({d['book']}): {d['lessonCount']} lessons, desc chars min/max = {min(lens)}/{max(lens)}")
