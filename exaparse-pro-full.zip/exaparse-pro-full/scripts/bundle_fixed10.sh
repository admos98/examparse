#!/bin/bash
# Bundle parser-jev-fixed10.zip — fixed version + rule mining + templates + full gate.
# Layout mirrors the workspace 1:1 so a fresh restore = unzip at project root.
set -euo pipefail

ROOT=/home/z/my-project
STAGE=$ROOT/scratch/stage-fixed10
OUT=$ROOT/download/parser-jev-fixed10.zip

rm -rf "$STAGE"
mkdir -p "$STAGE"

# --- repo-parser: full source, no node_modules / dist / .git ---
mkdir -p "$STAGE/repo-parser"
(cd "$ROOT/repo-parser" && tar cf - \
  --exclude='./node_modules' --exclude='./dist' --exclude='./server.js' \
  --exclude='./.git' --exclude='./.vite' \
  src scripts scripts-batch data server.ts package.json package-lock.json bun.lock \
  vite.config.ts tsconfig.json index.html .env.example metadata.json \
  JEV_NOTES.md .gitignore) | tar xf - -C "$STAGE/repo-parser"

# --- gate suites + runners (live in ../scripts in the workspace) ---
mkdir -p "$STAGE/scripts/golden"
cp "$ROOT/scripts/verifyFixes.ts" \
   "$ROOT/scripts/verifyFeatures.ts" \
   "$ROOT/scripts/verifyJev.ts" \
   "$ROOT/scripts/test_parseVerifier.mts" \
   "$ROOT/scripts/verifyMining.ts" \
   "$ROOT/scripts/goldenCorpus.ts" \
   "$ROOT/scripts/run_mock_grade.sh" \
   "$ROOT/scripts/mock-provider.js" \
   "$ROOT/scripts/e2e-verify.sh" \
   "$STAGE/scripts/"
cp "$ROOT/scripts/golden/fixtures.ts" "$STAGE/scripts/golden/"

# --- corpora + hand-built ground truth + extracted texts (grader inputs) ---
mkdir -p "$STAGE/samples" "$STAGE/scratch"
cp -r "$ROOT/samples/mocks" "$STAGE/samples/mocks"
cp -r "$ROOT/scratch/gt"       "$STAGE/scratch/gt"
cp -r "$ROOT/scratch/gt-mocks" "$STAGE/scratch/gt-mocks"
cp -r "$ROOT/scratch/texts"       "$STAGE/scratch/texts"
cp -r "$ROOT/scratch/texts-mocks" "$STAGE/scratch/texts-mocks"

# --- BUNDLE.md ---
cat > "$STAGE/BUNDLE.md" <<'EOF'
# ExaParse Pro — parser-jev-fixed10

Fixed version of the Persian/English school-exam parser (Vite + React 19 + TS +
Express, port 3000): JEV parse-verification flow, ALL bug-hunt fixes, plus the
NEW rule-mining + mined-template system (Ideas 1+2) and the complete
verification gate.

## What is inside (mirrors the workspace 1:1 — unzip at project root)

- `repo-parser/`        the application (src, server, scripts, scripts-batch, data)
- `scripts/`            verification suites + mock grader runner + mock provider
- `samples/mocks/`      20 hand-built mock exams (layout-family sweep)
- `scratch/gt/`         30 hand-built golden ground-truth files
- `scratch/gt-mocks/`   20 hand-built mock ground-truth files
- `scratch/texts*/`     extracted texts so the grader runs immediately

## NEW in fixed10 — rule mining (Idea 1) + mined templates (Idea 2)

- Rule mining: ONE AI call proposes a corrective rule + expected parse. The
  proposal is validated against a constrained DSL (whitelisted types and
  categories, ReDoS-guarded regexes, scoped conditions only), GROUNDED in the
  raw document (ids + question numbers must literally appear — no
  self-fulfilling graders), target-checked, then shadow-run over the whole
  50-exam golden corpus. Any single regression rejects it. Full corpus green
  -> the rule auto-promotes to live; thin coverage -> it stays in shadow and
  never applies. A human can retire any rule in one click (Exam Doctor ->
  Mined rules). Mined rules live in repo-parser/data/mined-rules.json
  (starts empty = pure deterministic behavior).
- Mined templates: 46 structural section templates mined deterministically
  from the corpus. They contribute ADVISORY evidence only (section hints +
  info-level findings) — they never stamp types and never demote trust.
  Mined rules can scope themselves by template family (the two ideas share
  one vocabulary).
- The strict grader applies live mined rules, so a bad future rule import
  fails `npm run verify` instead of passing silently.

## Verify gate (single command)

    cd repo-parser
    npm install
    npm run verify

The gate chains: tsc lint -> verifyFixes (27) -> verifyFeatures (17) ->
verifyJev (20) -> parseVerifier (76) -> verifyMining (31) -> goldenCorpus
fixtures (252) -> strict 30-exam grade -> strict 20-mock grade. The grader is
strict: any FAIL, any SKIP, or an empty ground-truth dir exits non-zero.

## Shipped gate results (2026-09-29)

- verifyFixes 27/27, verifyFeatures 17/17, verifyJev 20/20,
  parseVerifier 76/76, verifyMining 31/31, goldenCorpus 252/252
- 30-exam strict grade: 30/30 files at 100%
- 20-mock strict grade: 20/20 files at 100%

## Key commits

- 687ca71 feat(mining): AI rule mining gated by the corpus + mined template layer
- 43c4c94 chore(gate): strict grader exit codes + 20-mock suite wired into verify
- 146d16b feat(jev-flow): robustness pass
- 6732a24 fix(verdict-round): JSON extraction, term false positive,
  error-correction wording, RTL native rowIds

## Run

    cd repo-parser
    npm run dev      # http://localhost:3000

Offline parsing works without keys. AI features (enhance / judge / mine)
need a configured provider (Settings, or `.env` — see `.env.example`).
EOF

# --- zip ---
rm -f "$OUT"
(cd "$STAGE" && zip -q -r "$OUT" .)
echo "---- manifest ----"
unzip -l "$OUT" | tail -3
echo "---- sha256 ----"
sha256sum "$OUT"
