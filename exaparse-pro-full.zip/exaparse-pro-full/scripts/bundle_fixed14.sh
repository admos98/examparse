#!/bin/bash
# Bundle parser-jev-fixed14.zip — fixed13 + RELIABILITY & PRINTED-KEY WAVE:
# AI wire timeouts + bounded 429/5xx backoff, phone-number PII scrub with
# checksum-gated national IDs, and the answer-key-on-file mode (a printed key
# becomes metadata + official answers; AI answer production is skipped).
# Layout mirrors the workspace 1:1 so a fresh restore = unzip at project root.
set -euo pipefail

ROOT=/home/z/my-project
STAGE=$ROOT/scratch/stage-fixed14
OUT=$ROOT/download/parser-jev-fixed14.zip

rm -rf "$STAGE"
mkdir -p "$STAGE"

# --- repo-parser: full source, no node_modules / dist / .git ---
mkdir -p "$STAGE/repo-parser"
(cd "$ROOT/repo-parser" && tar cf - \
  --exclude='./node_modules' --exclude='./dist' --exclude='./server.js' \
  --exclude='./.git' --exclude='./.vite' \
  src scripts scripts-batch data server.ts package.json package-lock.json bun.lock \
  vite.config.ts tsconfig.json index.html .env.example metadata.json \
  JEV_NOTES.md .gitignore) | tar xf - -C "$STAGE/repo-parser"

# --- gate suites + runners (live in ../scripts in the workspace) ---
mkdir -p "$STAGE/scripts/golden"
cp "$ROOT/scripts/verifyFixes.ts" \
   "$ROOT/scripts/verifyFeatures.ts" \
   "$ROOT/scripts/verifyJev.ts" \
   "$ROOT/scripts/test_parseVerifier.mts" \
   "$ROOT/scripts/verifyMining.ts" \
   "$ROOT/scripts/verifyVision.mts" \
   "$ROOT/scripts/verifySurfaceFilter.ts" \
   "$ROOT/scripts/verifyAnswerFlow.mts" \
   "$ROOT/scripts/verifyCurriculum.mts" \
   "$ROOT/scripts/verifyCalibration.mts" \
   "$ROOT/scripts/verifyAiWire.mts" \
   "$ROOT/scripts/verifyKeyFile.mts" \
   "$ROOT/scripts/goldenCorpus.ts" \
   "$ROOT/scripts/run_mock_grade.sh" \
   "$ROOT/scripts/mock-provider.js" \
   "$ROOT/scripts/e2e-verify.sh" \
   "$STAGE/scripts/"
cp "$ROOT/scripts/golden/fixtures.ts" "$STAGE/scripts/golden/"

# --- change note ---
cp "$ROOT/download/IMPLEMENTATION_PLAN.md" "$STAGE/IMPLEMENTATION_PLAN.md"
cp "$ROOT/download/curriculum-digest-v2.json" "$STAGE/curriculum-digest-v2.json"

# --- corpora + hand-built ground truth + extracted texts (grader inputs) ---
mkdir -p "$STAGE/samples" "$STAGE/scratch"
cp -r "$ROOT/samples/mocks" "$STAGE/samples/mocks"
cp -r "$ROOT/scratch/gt"       "$STAGE/scratch/gt"
cp -r "$ROOT/scratch/gt-mocks" "$STAGE/scratch/gt-mocks"
cp -r "$ROOT/scratch/texts"       "$STAGE/scratch/texts"
cp -r "$ROOT/scratch/texts-mocks" "$STAGE/scratch/texts-mocks"

# --- BUNDLE.md ---
cat > "$STAGE/BUNDLE.md" <<'EOF'
# ExaParse Pro — parser-jev-fixed14

Fixed version of the Persian/English school-exam parser (Vite + React 19 + TS +
Express, port 3000): the offline-first parse pipeline, JEV parse verification,
rule mining + mined templates, the image understanding pipeline, the agreed
COMPLETE FLOW (M1-M4) — answer production with a producer-critic last call,
lesson/difficulty attribution from the book-sourced curriculum digest, the
privacy surface filter, the measured calibration gate, full out-of-the-box
portability, and NOW the reliability + printed-key wave.

## What is inside (mirrors the workspace 1:1 — unzip at project root)

- `repo-parser/`        the application (src, server, scripts, scripts-batch, data)
- `scripts/`            verification suites + mock grader runner + mock provider
- `samples/mocks/`      20 hand-built mock exams (layout-family sweep)
- `scratch/gt/`         30 hand-built golden ground-truth files
- `scratch/gt-mocks/`   20 hand-built mock ground-truth files
- `scratch/texts*/`     extracted texts so the grader runs immediately
- `IMPLEMENTATION_PLAN.md`  the locked plan (decisions D1-D5 + calibration gate §6)
- `curriculum-digest-v2.json`  the book-verified digest (digestVersion 39d0f83741c3c616)

## NEW in fixed14 — reliability hardening + answer key on file

- NO MORE HANGS: every AI wire call (Gemini SDK branch AND OpenAI-compatible
  branch) carries an AbortController with a configurable timeout
  (providerConfig.timeoutMs > env AI_TIMEOUT_MS > 120s default). A provider
  that never responds aborts with "timed out after Ns" instead of stalling
  the verify/answer/vision flow forever. The /api/models list gets a 15s cap.
- BOUNDED RETRY: 429/5xx and retryable network faults retry IN PLACE with
  exponential backoff (1s base doubling, 30s cap) honoring the provider's
  Retry-After hint — then the existing A/B/C empty-output ladder still runs.
  400/401/403/404 are NEVER retried (the diagnosis stays exact); diagnostic
  pings (maxAttempts: 1) keep their single-shot contract.
- PHONE PII: the surface filter now scrubs Iranian mobile (09...) and
  landline (0[1-8]...) numbers in Latin AND Persian digits, grouped or
  plain, plus labeled phone/fax lines (label kept, value gone).
- SMARTER NATIONAL-ID SCRUB: the bare 10-digit rule is CHECKSUM-GATED
  (Iranian mod-11 + repdigit guard) — real IDs are masked, barcode/form
  numbers pass through untouched (false-positive class eliminated).
- ANSWER KEY ON FILE: sheets that print their own key (پاسخنامه/کلید) get
  the key DETECTED (banner or trailing pair-row run), its rows REMOVED from
  the question list (metadata, never phantom questions), every entry MAPPED
  onto the right question by its PRINTED number, and answers applied with
  OFFICIAL provenance — above human and every AI draft. Mismatches become
  named warnings (orphan / ambiguous / invalid-option / duplicate /
  skipped-existing / uncovered); nothing is guessed.
- KEY MODE FLOW: with a key applied, the answer flow SKIPS AI answer
  production entirely (no a: picks, no R3 producer-critic — zero answer
  tokens). Jev still verifies question separation + metadata, difficulty /
  attribution metrics run as usual, and the key mapping validation IS the
  "did the app point the right answer at the right question" check.

## NEW in fixed13 — out-of-the-box portability

- Every data path now derives from the workspace root (the directory that
  contains repo-parser/, scripts/, scratch/, samples/), never from an absolute
  machine path. `npm run verify` works on any machine straight after
  `npm install` — nothing outside the unzipped folder is touched.
- The strict grader (grade.mts), the batch extractor, rule mining's shadow
  corpus (server + verifyMining suite), mineTemplates, run_mock_grade.sh, the
  mocks npm script and .env.example all resolve from their own file locations
  (see repo-parser/scripts-batch/wsPaths.mts for the layout contract). Every
  default stays env-overridable (GT_DIR, TEXT_DIR, CORPUS_DIR, ...).
- Side benefit: verifyMining's corpus-backed freshness + identity checks now
  actually RUN out-of-the-box (the bundle ships scratch/gt + texts) instead of
  silently skipping on machines without the workspace's absolute paths.

## M1-M4 — the complete flow (shipped in fixed12)

- M1 Surface filter (D4): school/teacher/district/exam-date are extracted for
  parsing but NEVER surface — hidden in the UI, stripped from AI payloads,
  every export, the training log and the serializer round-trip. Settings
  power-user toggle is the single opt-in. Zero grader impact (extraction untouched).
- M2 Answer flow: deterministic bucket routing (A candidate-set / B free-text /
  C image-deferred); R1 answers bucket A via the a: Choice axis over the item's
  OWN options inside the existing judge call; R3 producer-critic (text LLM
  produces short answers, Jev independently checks; agreement = jev-verified
  draft, disagreement = BOTH answers queued for human mediation). Provenance
  chain official > human > jev-verified-draft > ai-draft > heuristic; drafts
  NEVER silently commit; essays are never machine-answered.
- M3 Curriculum integration: the book-verified digest rides ONE grade per call
  (~0.6-1.1K tokens); l1/l2 lesson span + b in-book + c cognitive attribution
  Choices; deterministic keyword cross-check flags zero-support lesson picks;
  difficulty = pure client-side calculator over the signals with configurable
  weights (re-tuning re-scores the library without re-billing AI).
- M4 Orchestration + Final Review: one "Verify & Answer" button runs the
  staged flow; the Final Review grid is the single surface where everything
  lands (provenance badges, mediation pairs side-by-side, difficulty chips,
  inline human edits); BULK accept is restricted by the calibration rules.
- Calibration gate (§6): auto-accept/bulk-accept switch on ONLY for categories
  (kind x cognitive) whose accuracy was MEASURED against hand-built golden
  answers (>= 0.95, min cell 20), version-bound to the exact
  digestVersion/weightsVersion/promptVersion tuple. With no report, nothing
  auto-accepts — the safe default.

## Verify gate (single command)

    cd repo-parser
    npm install
    npm run verify

The gate chains: tsc lint -> verifyFixes (27) -> verifyFeatures (17) ->
verifyJev (20) -> parseVerifier (85) -> verifyMining (31) -> verifyVision (48)
-> verifySurfaceFilter (40) -> verifyAnswerFlow (44) -> verifyCurriculum (47)
-> verifyCalibration (19) -> goldenCorpus fixtures (252) -> strict 30-exam
grade -> strict 20-mock grade. Strict: any FAIL/SKIP exits non-zero.
e2e (bash ../scripts/e2e-verify.sh) covers the server against 7 mock provider
shapes incl. the vision-batch contract (9 tests).

## Shipped gate results (2026-10-01)

- verifyFixes 27/27, verifyFeatures 17/17, verifyJev 20/20, parseVerifier 85/85,
  verifyMining 31/31, verifyVision 48/48, verifySurfaceFilter 51/51,
  verifyAnswerFlow 44/44, verifyCurriculum 47/47, verifyCalibration 19/19,
  verifyAiWire 27/27, verifyKeyFile 39/39, goldenCorpus 252/252
- 30-exam strict grade: 30/30 files at 100%
- 20-mock strict grade: 20/20 files at 100%
- Restore-proven: fresh unzip into an empty directory + npm ci + full verify
  EXIT=0, plus a negative test (GT dir renamed away) proving the grader reads
  ONLY the bundle's own data, never a machine path.

## Key commits

- d61405a feat(reliability): AI wire timeouts + bounded 429/5xx backoff;
  phone PII scrub; answer-key-on-file mode
- c45bd24 fix(portability): derive every data path from the workspace root
- a70d5fd feat(flow): M4 — staged answer flow, Final Review grid, calibration gate
- c5c99d3 feat(curriculum): M3 — digest asset, resolver, attribution axes, difficulty
- cd14402 feat(answers): M2 — bucket routing, a: axis, producer-critic, mediation
- 9aea0ec feat(privacy): M1 — surface filter + 40-check gate

## Run

    cd repo-parser
    npm run dev      # http://localhost:3000

Offline parsing works without keys. AI features (enhance / judge / mine /
vision / answer flow) need a configured provider (Settings, or `.env`).
EOF

# --- zip ---
rm -f "$OUT"
(cd "$STAGE" && zip -qr "$OUT" .)
echo "bundle: $OUT"
sha256sum "$OUT"
unzip -l "$OUT" | tail -1
