#!/bin/bash
# Bundle parser-jev-fixed17.zip — fixed15 + THE BUILD-15 REAL-EXAM WAVE:
# a real 10th-grade English final (14050319px3c5v1338.pdf) shipped five
# Stage-1 defects despite aiTokens: 0. All five fixed + the exam is a
# permanent shipped regression gate (scripts/verifyRealExam.mts, 69 checks):
#   1. bidi-reversed Persian duration digits ("۶۰" extracted as "06",
#      value emitted before the label) -> header.durationMinutes 60;
#   2. dictation items 1-4 (دیکته) -> short_answer + taskType 'dictation';
#   3. hyphen-separated word bank ("Died out- entertainment- solve- plains")
#      -> exact candidates, trailing hyphens as separators, instruction
#      lines never become bank words;
#   4. the bank is SCOPED to the numbered items between the bank row and the
#      next task boundary ("Choose the best answer") — no more bank metadata
#      on MCQs/translation/form items (Jev's Choice candidates were poisoned);
#   5. row-level T/F markers (trailing "T F" and wrapped mid-stem) ->
#      true_false with True/False options, markers stripped from stems.
#   Plus: question 25 (bare-space number "25 I called…") is parsed again via
#   rule R21; the sheet's printed 31-39 numbering survives its own duplicate
#   "33" (renumber-on-duplicate now fires only on real reset runs).
# Layout mirrors the workspace 1:1 so a fresh restore = unzip at project root.
set -euo pipefail

ROOT=/home/z/my-project
STAGE=$ROOT/scratch/stage-fixed17
OUT=$ROOT/download/parser-jev-fixed17.zip

rm -rf "$STAGE"
mkdir -p "$STAGE"

# --- repo-parser: full source, no node_modules / dist / .git ---
mkdir -p "$STAGE/repo-parser"
(cd "$ROOT/repo-parser" && tar cf - \
  --exclude='./node_modules' --exclude='./dist' --exclude='./server.js' \
  --exclude='./.git' --exclude='./.vite' \
  src scripts scripts-batch data server.ts package.json package-lock.json bun.lock \
  vite.config.ts tsconfig.json index.html .env.example metadata.json \
  JEV_NOTES.md .gitignore) | tar xf - -C "$STAGE/repo-parser"

# --- gate suites + runners (live in ../scripts in the workspace) ---
mkdir -p "$STAGE/scripts/golden"
cp "$ROOT/scripts/verifyFixes.ts" \
   "$ROOT/scripts/verifyFeatures.ts" \
   "$ROOT/scripts/verifyJev.ts" \
   "$ROOT/scripts/test_parseVerifier.mts" \
   "$ROOT/scripts/verifyMining.ts" \
   "$ROOT/scripts/verifyVision.mts" \
   "$ROOT/scripts/verifySurfaceFilter.ts" \
   "$ROOT/scripts/verifyAnswerFlow.mts" \
   "$ROOT/scripts/verifyCurriculum.mts" \
   "$ROOT/scripts/verifyCalibration.mts" \
   "$ROOT/scripts/verifyAiWire.mts" \
   "$ROOT/scripts/verifyKeyFile.mts" \
   "$ROOT/scripts/verifyRealExam.mts" \
   "$ROOT/scripts/qu2report.mts" \
   "$ROOT/scripts/goldenCorpus.ts" \
   "$ROOT/scripts/run_mock_grade.sh" \
   "$ROOT/scripts/mock-provider.js" \
   "$ROOT/scripts/e2e-verify.sh" \
   "$STAGE/scripts/"
cp "$ROOT/scripts/golden/fixtures.ts" "$STAGE/scripts/golden/"

# --- change note ---
cp "$ROOT/download/IMPLEMENTATION_PLAN.md" "$STAGE/IMPLEMENTATION_PLAN.md"
cp "$ROOT/download/curriculum-digest-v2.json" "$STAGE/curriculum-digest-v2.json"

# --- corpora + hand-built ground truth + extracted texts (grader inputs) ---
mkdir -p "$STAGE/samples" "$STAGE/scratch"
cp -r "$ROOT/samples/mocks" "$STAGE/samples/mocks"
cp -r "$ROOT/scratch/gt"       "$STAGE/scratch/gt"
cp -r "$ROOT/scratch/gt-mocks" "$STAGE/scratch/gt-mocks"
cp -r "$ROOT/scratch/texts"       "$STAGE/scratch/texts"
cp -r "$ROOT/scratch/texts-mocks" "$STAGE/scratch/texts-mocks"
cp -r "$ROOT/scratch/gt-qu2"     "$STAGE/scratch/gt-qu2"
cp -r "$ROOT/scratch/texts-qu2"  "$STAGE/scratch/texts-qu2"
cp "$ROOT/scratch/qu2-classify.json" "$ROOT/scratch/qu2-deferred.json" "$STAGE/scratch/" 2>/dev/null || true

# --- BUNDLE.md ---
cat > "$STAGE/BUNDLE.md" <<'EOF'
# ExaParse Pro — parser-jev-fixed17

Fixed version of the Persian/English school-exam parser (Vite + React 19 + TS +
Express, port 3000): the offline-first parse pipeline, JEV parse verification,
rule mining + mined templates, the image understanding pipeline, the agreed
COMPLETE FLOW (M1-M4), full portability, the reliability + printed-key wave,
the build-14 review fixes, and NOW the build-15 REAL-EXAM regression wave.

## What is inside (mirrors the workspace 1:1 — unzip at project root)

- `repo-parser/`        the application (src, server, scripts, scripts-batch, data)
- `scripts/`            verification suites + mock grader runner + mock provider
- `samples/mocks/`      20 hand-built mock exams (layout-family sweep)
- `scratch/gt/`         30 hand-built golden ground-truth files
- `scratch/gt-mocks/`   20 hand-built mock ground-truth files
- `scratch/texts*/`     extracted texts incl. the REAL-EXAM fixture
                        (real_14050319.pdf.txt) so every grader runs immediately
- `IMPLEMENTATION_PLAN.md`  the locked plan (decisions D1-D5 + calibration gate §6)
- `curriculum-digest-v2.json`  the book-verified digest (digestVersion 39d0f83741c3c616)

## NEW in fixed17 — the build-15 real-exam fixes (14050319px3c5v1338.pdf)

A real 10th-grade English final shipped FIVE Stage-1 defects despite
aiTokens: 0 — every one of them deterministic, every one now fixed and
covered by a NEW permanent gate: scripts/verifyRealExam.mts (69 checks,
wired into `npm run verify`).

- BIDI DURATION (#bidi-duration): the printed header "مدت آزمون: ۶۰ دقیقه"
  was parsed as 6 minutes — extractors walk RTL header rows in VISUAL order,
  so the digits arrive REVERSED ("06"), sometimes with the value BEFORE the
  label. A zero-led multi-digit run (Persian durations are never typeset
  "06") is now read back in logical order, Persian/Arabic-Indic digits are
  normalized, and a visual-order fallback picks the digit run nearest the
  دقیقه/minutes marker (a date on the same line loses). Genuine values
  (60/90/45/120) pass untouched. header.durationMinutes === 60.
- DICTATION TASK (#dictation): items 1-4 (دیکته, partial-word dashes like
  "p—ram---ds") are short_answer with taskType 'dictation' — never
  word_bank_fill, zero bank metadata. The dictation stamp is ZONE-GUARDED so
  it only covers the task zone before the bank row.
- EXACT WORD BANK (#hyphen-bank): "Died out- entertainment- solve- plains"
  is one bank row — trailing hyphens are SEPARATORS, "Died out" is one
  phrase. The old harvester shredded it into ["Died","out-","entertainment-",
  …] and swallowed the "Choose the best answer" instruction as bank words.
  Now: ["Died out","entertainment","solve","plains"], cue-gated.
- BANK SCOPING (#bank-scoping): the bank applies ONLY to the numbered items
  between the bank row and the next task boundary ("Choose the best
  answer"). MCQs, the translation item, the adjective-order item and the
  form tasks carry ZERO bank metadata — Jev's Choice candidates are no
  longer poisoned (wordBankWords used to ride on EVERY question).
- ROW-LEVEL TRUE/FALSE (#row-tf): statements printed with trailing T F
  columns — or wrapped mid-stem ("…the number  T  F / of these animals…") —
  become true_false with [{id:'true'},{id:'false'}] options; the marker run
  is stripped from the stem. q41/42/45/46/47 fixed.
- BARE-SPACE QUESTION NUMBERS (rule R21): "25 I called ali while he--------
  video game.( play)" has NO separator after the number — the whole item
  used to vanish into question 24. Fill-DNA guards keep wrapped prose from
  spawning phantom questions.
- PRINTED NUMBERING SURVIVES SHEET TYPOS: duplicate printed numbers used to
  trigger a full sequential renumber, erasing the printed 31-39 of the
  Writing section. Renumbering now fires only on real reset runs; the
  sheet's own duplicate "33" (two distinct questions) is kept faithfully and
  the SEQ_NUMBER invariant reports it as a warning (distinct stems) instead
  of a parser-error.

## Count note (evidence-backed)

The sheet's PHYSICAL question count is 47 and its UNIQUE printed numbers
are 46: question 25 IS printed on the sheet (page 2) and the sheet PRINTS
"33" TWICE (page 2; both are distinct real questions — dropping one to
force a count would be silent data loss). verifyRealExam pins BOTH: 47
physical items, 46 unique printed numbers, question 5 never invented.

## NEW in fixed15 — the build-14 review fixes

- BLOCKER FIXED — OFFICIAL MCQ ANSWERS ARE OPTION IDs: the printed-key mapper
  stored the option TEXT ("correctAnswer = \"is\""), violating the app-wide MCQ
  contract (correctAnswer must be the option ID 'a'..'d'). That broke the
  correct-option highlight, Moodle/answer-key exports, mirror/autosolver, and
  made every keyed MCQ fail the ANSWER_VALID invariant. Now the option ID is
  stored and the printed text is preserved on the key report (optionText).
- NATIVE JEV WIRE HARDENED: callNativeJev used raw fetch() — no timeout, only
  429/529 retries. Now every attempt carries an AbortController (timeoutMs >
  env AI_TIMEOUT_MS > 120s), timeouts are NEVER retried and diagnosed exactly,
  429/500/502/503/504/529 retry in place with bounded exponential backoff
  honoring Retry-After, transport faults recover, and 400/401/403/404 stay
  fatal. The "every AI wire call is hardened" claim now covers all three
  paths (Gemini SDK, OpenAI-compatible, native Jev) — verifyAiWire 41 checks.
- CROSS-PLATFORM ONE-COMMAND GATE: npm scripts no longer use Unix-only
  `VAR=x cmd` prefixes. The 20-mock phase runs via scripts-batch/mocks.mts,
  `clean` uses node fs.rmSync. `npm install && npm run verify` works on
  Windows/macOS/Linux alike.
- SHRINK-PROOF REGRESSION LINE: the grader enforces GT_MIN_FILES — golden.mts
  pins 30, mocks.mts pins 20 — and a verifyFixes check locks the whole
  contract. Negative-tested (env prefix, absolute literal, renamed GT file).

## NEW in fixed14 — reliability hardening + answer key on file

- NO MORE HANGS: every AI wire call (Gemini SDK AND OpenAI-compatible
  branches) carries an AbortController with a configurable timeout.
- BOUNDED RETRY: 429/5xx + retryable network faults retry IN PLACE with
  exponential backoff honoring Retry-After; 400/401/403/404 are NEVER retried.
- PHONE PII: Iranian mobile/landline numbers scrubbed in Latin AND Persian
  digits; national-ID scrub is CHECKSUM-GATED (barcodes pass through).
- ANSWER KEY ON FILE: sheets that print their own key get it DETECTED, its
  rows REMOVED from the question list, every entry MAPPED by printed number,
  answers applied with OFFICIAL provenance; the answer flow SKIPS AI answer
  production (zero answer tokens); Jev still verifies separation + metadata.

## Verify gate (single command, cross-platform)

    cd repo-parser
    npm install
    npm run verify

The gate chains: tsc lint -> verifyFixes (29) -> verifyFeatures (17) ->
verifyJev (20) -> parseVerifier (85) -> verifyMining (31) -> verifyVision (48)
-> verifySurfaceFilter (51) -> verifyAnswerFlow (44) -> verifyCurriculum (47)
-> verifyCalibration (19) -> verifyAiWire (41) -> verifyKeyFile (43) ->
verifyRealExam (69, the real 10th-grade final) -> goldenCorpus fixtures (252)
-> strict 30-exam grade (corpus PINNED at 30) -> strict 20-mock grade (PINNED
at 20). Strict: any FAIL/SKIP/shrink exits non-zero.
e2e (bash ../scripts/e2e-verify.sh) covers the server against 7 mock provider
shapes incl. the vision-batch contract (9 tests).

## Shipped gate results (2026-10-01)

- verifyFixes 29/29, verifyFeatures 17/17, verifyJev 20/20, parseVerifier 85/85,
  verifyMining 31/31, verifyVision 48/48, verifySurfaceFilter 51/51,
  verifyAnswerFlow 44/44, verifyCurriculum 47/47, verifyCalibration 19/19,
  verifyAiWire 41/41, verifyKeyFile 43/43, verifyRealExam 69/69,
  goldenCorpus 252/252
- 30-exam strict grade: 30/30 files at 100% (pin: min 30 enforced)
- 20-mock strict grade: 20/20 files at 100% (pin: min 20 enforced)
- e2e: 9/9
- Negative test: the pre-fix duration bug re-injected -> verifyRealExam FAILs
  with named diagnoses; restored -> green again.

## Run

    cd repo-parser
    npm run dev      # http://localhost:3000

Offline parsing works without keys. AI features (enhance / judge / mine /
vision / answer flow) need a configured provider (Settings, or `.env`).
EOF

# --- zip ---
rm -f "$OUT"
(cd "$STAGE" && zip -qr "$OUT" .)
echo "bundle: $OUT"
sha256sum "$OUT"
unzip -l "$OUT" | tail -1
