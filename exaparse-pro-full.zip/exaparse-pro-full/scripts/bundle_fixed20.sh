#!/bin/bash
# Bundle parser-jev-fixed20.zip — fixed19 + THE QU2 ACCURACY WAVES (4a/4b/5):
# a real 10th-grade English final (14050319px3c5v1338.pdf) shipped five
# Stage-1 defects despite aiTokens: 0. All five fixed + the exam is a
# permanent shipped regression gate (scripts/verifyRealExam.mts, 69 checks):
#   1. bidi-reversed Persian duration digits ("۶۰" extracted as "06",
#      value emitted before the label) -> header.durationMinutes 60;
#   2. dictation items 1-4 (دیکته) -> short_answer + taskType 'dictation';
#   3. hyphen-separated word bank ("Died out- entertainment- solve- plains")
#      -> exact candidates, trailing hyphens as separators, instruction
#      lines never become bank words;
#   4. the bank is SCOPED to the numbered items between the bank row and the
#      next task boundary ("Choose the best answer") — no more bank metadata
#      on MCQs/translation/form items (Jev's Choice candidates were poisoned);
#   5. row-level T/F markers (trailing "T F" and wrapped mid-stem) ->
#      true_false with True/False options, markers stripped from stems.
#   Plus: question 25 (bare-space number "25 I called…") is parsed again via
#   rule R21; the sheet's printed 31-39 numbering survives its own duplicate
#   "33" (renumber-on-duplicate now fires only on real reset runs).
# Layout mirrors the workspace 1:1 so a fresh restore = unzip at project root.
set -euo pipefail

ROOT=/home/z/my-project
STAGE=$ROOT/scratch/stage-fixed20
OUT=$ROOT/download/parser-jev-fixed20.zip

rm -rf "$STAGE"
mkdir -p "$STAGE"

# --- repo-parser: full source, no node_modules / dist / .git ---
mkdir -p "$STAGE/repo-parser"
(cd "$ROOT/repo-parser" && tar cf - \
  --exclude='./node_modules' --exclude='./dist' --exclude='./server.js' \
  --exclude='./.git' --exclude='./.vite' \
  src scripts scripts-batch data server.ts package.json package-lock.json bun.lock \
  vite.config.ts tsconfig.json index.html .env.example metadata.json \
  JEV_NOTES.md .gitignore) | tar xf - -C "$STAGE/repo-parser"

# --- gate suites + runners (live in ../scripts in the workspace) ---
mkdir -p "$STAGE/scripts/golden"
cp "$ROOT/scripts/verifyFixes.ts" \
   "$ROOT/scripts/verifyFeatures.ts" \
   "$ROOT/scripts/verifyJev.ts" \
   "$ROOT/scripts/test_parseVerifier.mts" \
   "$ROOT/scripts/verifyMining.ts" \
   "$ROOT/scripts/verifyVision.mts" \
   "$ROOT/scripts/verifySurfaceFilter.ts" \
   "$ROOT/scripts/verifyAnswerFlow.mts" \
   "$ROOT/scripts/verifyCurriculum.mts" \
   "$ROOT/scripts/verifyCalibration.mts" \
   "$ROOT/scripts/verifyAiWire.mts" \
   "$ROOT/scripts/verifyKeyFile.mts" \
   "$ROOT/scripts/verifyRealExam.mts" \
   "$ROOT/scripts/qu2report.mts" \
   "$ROOT/scripts/goldenCorpus.ts" \
   "$ROOT/scripts/run_mock_grade.sh" \
   "$ROOT/scripts/mock-provider.js" \
   "$ROOT/scripts/e2e-verify.sh" \
   "$STAGE/scripts/"
cp "$ROOT/scripts/golden/fixtures.ts" "$STAGE/scripts/golden/"

# --- change note ---
cp "$ROOT/download/IMPLEMENTATION_PLAN.md" "$STAGE/IMPLEMENTATION_PLAN.md"
cp "$ROOT/download/curriculum-digest-v2.json" "$STAGE/curriculum-digest-v2.json"

# --- corpora + hand-built ground truth + extracted texts (grader inputs) ---
mkdir -p "$STAGE/samples" "$STAGE/scratch"
cp -r "$ROOT/samples/mocks" "$STAGE/samples/mocks"
cp -r "$ROOT/scratch/gt"       "$STAGE/scratch/gt"
cp -r "$ROOT/scratch/gt-mocks" "$STAGE/scratch/gt-mocks"
cp -r "$ROOT/scratch/texts"       "$STAGE/scratch/texts"
cp -r "$ROOT/scratch/texts-mocks" "$STAGE/scratch/texts-mocks"
cp -r "$ROOT/scratch/gt-qu2"     "$STAGE/scratch/gt-qu2"
cp -r "$ROOT/scratch/gt-qu2-pinned" "$STAGE/scratch/gt-qu2-pinned"
cp -r "$ROOT/scratch/texts-qu2"  "$STAGE/scratch/texts-qu2"
cp "$ROOT/scratch/qu2-classify.json" "$ROOT/scratch/qu2-deferred.json" "$STAGE/scratch/" 2>/dev/null || true

# --- BUNDLE.md ---
cat > "$STAGE/BUNDLE.md" <<'EOF'
# ExaParse Pro — parser-jev-fixed20

Fixed version of the Persian/English school-exam parser (Vite + React 19 + TS +
Express, port 3000): the offline-first parse pipeline, JEV parse verification,
rule mining + mined templates, the image understanding pipeline, the agreed
COMPLETE FLOW (M1-M4), full portability, the reliability + printed-key wave,
the build-14 review fixes, and NOW the build-15 REAL-EXAM regression wave.

## What is inside (mirrors the workspace 1:1 — unzip at project root)

- `repo-parser/`        the application (src, server, scripts, scripts-batch, data)
- `scripts/`            verification suites + mock grader runner + mock provider
- `samples/mocks/`      20 hand-built mock exams (layout-family sweep)
- `scratch/gt/`         30 hand-built golden ground-truth files
- `scratch/gt-mocks/`   20 hand-built mock ground-truth files
- `scratch/texts*/`     extracted texts incl. the REAL-EXAM fixture
                        (real_14050319.pdf.txt) so every grader runs immediately
- `IMPLEMENTATION_PLAN.md`  the locked plan (decisions D1-D5 + calibration gate §6)
- `curriculum-digest-v2.json`  the book-verified digest (digestVersion 39d0f83741c3c616)

## NEW in fixed20 — the qu2 accuracy waves (every file that reaches exactly
100% joins the PERMANENT strict gate)

Six of the 32 hand-graded qu2 corpus files now score EXACTLY 100% and are
pinned forever: scripts-batch/qu2golden.mts freezes their GT into
scratch/gt-qu2-pinned and gates "6/6 at 100%" inside `npm run verify`
(GT_MIN_FILES=6). The full gate: 30/30 golden + 20/20 mocks + 6/6 pinned
qu2 + the qu2 scorecard (report) + 47/47 corpus accounting.

- PINNED FILES: 13991009pq89w65173 (59q), 14050401pm57p5s814 (67q),
  14050320p8214n5896 (44q), 14040822pc4i517871 (47q),
  14050320p43266n364 (29q), 14050319p566h5f982 (26q).
- WAVE 4a/4b: bare-marker sections splitter (digit ladder 1-3 + letter
  ladder A-R as OPENING markers, trailing mark cells, printed-label carry
  pin); slot-row split; Kanoon hybrid rows (N. imperative rungs, named
  rows, unnumbered-imperative row synthesis); BEFORE/AFTER mark-layout
  fingerprint; inline-merged matching colB; 2-marker answer-row split.
- WAVE 5 (pc4i517871): page-furniture mark guard (a bare number hugging
  the kanoon-ir footer / PAGE marker or followed by student-header fields
  is a PAGE NUMBER, never a بارم cell); fused-imperative mark fallback
  ("1 Choose the best answer." IS the row mark); Roman part-header carry
  ("III. Grammar"/"IV. Writing" inherit to banner-less rows — printed
  part statements outrank genre remaps); blank-run passage ownership
  (>=2 inline blanks -> the run collector owns the passage, the prose
  single-line shortcut stands down); inline-blank stem lookup is
  space-tolerant ("( 38 )" matches "(38)"); duplicate printed row ids
  (the sheet repeats "D") are graded occurrence-by-occurrence.
- WAVE 5 (p43266n364): fused-opener numbered-rows splitter (row digit
  FUSED to the Persian instruction, implicit digitless row 1,
  opener-to-opener blocking, "N نمره" cells as marks, strict
  ladder+mark+question guards); opener-digit strip; printed-contract
  categories (شکل صحیح/داخل پرانتز -> Grammar, اولین حرف -> Vocabulary);
  first-letter dictation DNA accepts THREE spaced dashes; numbered
  answer-space row normalizer; scattered-number inline-choice builder.
- WAVE 5 (p566h5f982): radif-opens marks-table walk (the MIRRORED rhythm:
  the ردیف digit OPENS its row, the بارم digit closes it, the letter
  identity is fused to the first content line — strict validation, runs
  only when the mark-opens machine fails); "given words" -> Vocabulary,
  "preposition" -> Grammar; matching branch recognizes "Match the
  definitions/words/sentences/items/phrases" (pictures deliberately
  excluded — p8214 pins multiple_choice for picture rows); matching +
  General -> Vocabulary; inline-choice slash parts up to three words.
- E2E teacher-flow fixes ride along: honest Stage-2 flags (no AI-Solved
  claim without a key and without answers actually filled) and React
  updater purity (side effects moved out of setDocuments).
## NEW in fixed15 — the build-14 review fixes

- BLOCKER FIXED — OFFICIAL MCQ ANSWERS ARE OPTION IDs: the printed-key mapper
  stored the option TEXT ("correctAnswer = \"is\""), violating the app-wide MCQ
  contract (correctAnswer must be the option ID 'a'..'d'). That broke the
  correct-option highlight, Moodle/answer-key exports, mirror/autosolver, and
  made every keyed MCQ fail the ANSWER_VALID invariant. Now the option ID is
  stored and the printed text is preserved on the key report (optionText).
- NATIVE JEV WIRE HARDENED: callNativeJev used raw fetch() — no timeout, only
  429/529 retries. Now every attempt carries an AbortController (timeoutMs >
  env AI_TIMEOUT_MS > 120s), timeouts are NEVER retried and diagnosed exactly,
  429/500/502/503/504/529 retry in place with bounded exponential backoff
  honoring Retry-After, transport faults recover, and 400/401/403/404 stay
  fatal. The "every AI wire call is hardened" claim now covers all three
  paths (Gemini SDK, OpenAI-compatible, native Jev) — verifyAiWire 41 checks.
- CROSS-PLATFORM ONE-COMMAND GATE: npm scripts no longer use Unix-only
  `VAR=x cmd` prefixes. The 20-mock phase runs via scripts-batch/mocks.mts,
  `clean` uses node fs.rmSync. `npm install && npm run verify` works on
  Windows/macOS/Linux alike.
- SHRINK-PROOF REGRESSION LINE: the grader enforces GT_MIN_FILES — golden.mts
  pins 30, mocks.mts pins 20 — and a verifyFixes check locks the whole
  contract. Negative-tested (env prefix, absolute literal, renamed GT file).

## NEW in fixed14 — reliability hardening + answer key on file

- NO MORE HANGS: every AI wire call (Gemini SDK AND OpenAI-compatible
  branches) carries an AbortController with a configurable timeout.
- BOUNDED RETRY: 429/5xx + retryable network faults retry IN PLACE with
  exponential backoff honoring Retry-After; 400/401/403/404 are NEVER retried.
- PHONE PII: Iranian mobile/landline numbers scrubbed in Latin AND Persian
  digits; national-ID scrub is CHECKSUM-GATED (barcodes pass through).
- ANSWER KEY ON FILE: sheets that print their own key get it DETECTED, its
  rows REMOVED from the question list, every entry MAPPED by printed number,
  answers applied with OFFICIAL provenance; the answer flow SKIPS AI answer
  production (zero answer tokens); Jev still verifies separation + metadata.

## Verify gate (single command, cross-platform)

    cd repo-parser
    npm install
    npm run verify

The gate chains: tsc lint -> verifyFixes (29) -> verifyFeatures (17) ->
verifyJev (20) -> parseVerifier (85) -> verifyMining (31) -> verifyVision (48)
-> verifySurfaceFilter (51) -> verifyAnswerFlow (44) -> verifyCurriculum (47)
-> verifyCalibration (19) -> verifyAiWire (41) -> verifyKeyFile (43) ->
verifyRealExam (69, the real 10th-grade final) -> goldenCorpus fixtures (252)
-> strict 30-exam grade (corpus PINNED at 30) -> strict 20-mock grade (PINNED
at 20). Strict: any FAIL/SKIP/shrink exits non-zero.
e2e (bash ../scripts/e2e-verify.sh) covers the server against 7 mock provider
shapes incl. the vision-batch contract (9 tests).

## Shipped gate results (2026-10-01)

- verifyFixes 29/29, verifyFeatures 17/17, verifyJev 20/20, parseVerifier 85/85,
  verifyMining 31/31, verifyVision 48/48, verifySurfaceFilter 51/51,
  verifyAnswerFlow 44/44, verifyCurriculum 47/47, verifyCalibration 19/19,
  verifyAiWire 41/41, verifyKeyFile 43/43, verifyRealExam 69/69,
  goldenCorpus 252/252
- 30-exam strict grade: 30/30 files at 100% (pin: min 30 enforced)
- 20-mock strict grade: 20/20 files at 100% (pin: min 20 enforced)
- e2e: 9/9
- Negative test: the pre-fix duration bug re-injected -> verifyRealExam FAILs
  with named diagnoses; restored -> green again.

## Run

    cd repo-parser
    npm run dev      # http://localhost:3000

Offline parsing works without keys. AI features (enhance / judge / mine /
vision / answer flow) need a configured provider (Settings, or `.env`).
EOF

# --- zip ---
rm -f "$OUT"
(cd "$STAGE" && zip -qr "$OUT" .)
echo "bundle: $OUT"
sha256sum "$OUT"
unzip -l "$OUT" | tail -1
