#!/bin/bash
# Bundle parser-jev-fixed22.zip — fixed21 + WAVE G4: THE LAYOUT BRAIN IS WIRED.
# The evidence-fusion sectioning brain (Wave G2/G3) now runs END-TO-END inside
# the app: the PDF extractor builds app-domain geometry (pdf.js v6 text-line
# grouping + bold font resolution + operator-list rules/rects), the brain
# perceives/fuses/verifies boundaries, and the bridge translates its verdict
# into the engine's exact block interface with FULL coverage + uncertainty
# receipts. Ships ADVISORY by default (verdicts + uncertainty surfaced, the
# battle-tested text splitters parse; worst case = status quo) with an
# explicit "Layout brain drives" opt-in toggle in the Parse screen.
# Persian row letters (الف/ب/پ...), Persian marks tables, alphabet switches,
# Persian MCQ option runs, malformed-input caps: stress suite 42/42.
# Gate: 30/30 golden + 20/20 mocks + 6/6 pinned qu2 + scorecard + 47/47
# accounting — npm run verify EXIT=0 (verify shell, unchanged).
# Layout mirrors the workspace 1:1 so a fresh restore = unzip at project root.
set -euo pipefail

ROOT=/home/z/my-project
STAGE=$ROOT/scratch/stage-fixed22
OUT=$ROOT/download/parser-jev-fixed22.zip

rm -rf "$STAGE"
mkdir -p "$STAGE"

# --- repo-parser: full source, no node_modules / dist / .git ---
mkdir -p "$STAGE/repo-parser"
(cd "$ROOT/repo-parser" && tar cf - \
  --exclude='./node_modules' --exclude='./dist' --exclude='./server.js' \
  --exclude='./.git' --exclude='./.vite' \
  --exclude='./scratch/brain-qu2' --exclude='./scratch/geo-qu2' \
  --exclude='./scratch/layout-probe' --exclude='./scratch/stage-*' \
  src scripts scripts-batch data server.ts package.json package-lock.json bun.lock \
  vite.config.ts tsconfig.json index.html .env.example metadata.json \
  JEV_NOTES.md .gitignore) | tar xf - -C "$STAGE/repo-parser"

# the pdftotext-sidecar brain report (historical G3 corpus posture)
mkdir -p "$STAGE/repo-parser/scratch/brain-qu2"
cp "$ROOT/repo-parser/scratch/brain-qu2/report.json" "$STAGE/repo-parser/scratch/brain-qu2/report.json" 2>/dev/null || true
# the APP-DOMAIN harness sidecars (pdf.js geometry + texts) + layout probe report
cp -r "$ROOT/repo-parser/scratch/brain-app-qu2" "$STAGE/repo-parser/scratch/brain-app-qu2"
mkdir -p "$STAGE/repo-parser/scratch/layout-probe"
cp "$ROOT/repo-parser/scratch/layout-probe/report.json" "$STAGE/repo-parser/scratch/layout-probe/report.json" 2>/dev/null || true

# --- gate suites + runners (live in ../scripts in the workspace) ---
cp -r "$ROOT/scripts" "$STAGE/scripts"
rm -f "$STAGE"/scripts/bundle_fixed*.sh

# --- change note ---
cp "$ROOT/download/IMPLEMENTATION_PLAN.md" "$STAGE/IMPLEMENTATION_PLAN.md"
cp "$ROOT/download/curriculum-digest-v2.json" "$STAGE/curriculum-digest-v2.json"

# --- corpora + hand-built ground truth + extracted texts (grader inputs) ---
mkdir -p "$STAGE/samples" "$STAGE/scratch"
cp -r "$ROOT/samples/mocks" "$STAGE/samples/mocks"
cp -r "$ROOT/scratch/gt"       "$STAGE/scratch/gt"
cp -r "$ROOT/scratch/gt-mocks" "$STAGE/scratch/gt-mocks"
cp -r "$ROOT/scratch/texts"       "$STAGE/scratch/texts"
cp -r "$ROOT/scratch/texts-mocks" "$STAGE/scratch/texts-mocks"
cp -r "$ROOT/scratch/gt-qu2"     "$STAGE/scratch/gt-qu2"
cp -r "$ROOT/scratch/gt-qu2-pinned" "$STAGE/scratch/gt-qu2-pinned"
cp -r "$ROOT/scratch/texts-qu2"  "$STAGE/scratch/texts-qu2"
cp "$ROOT/scratch/qu2-classify.json" "$ROOT/scratch/qu2-deferred.json" "$STAGE/scratch/" 2>/dev/null || true

# --- BUNDLE.md ---
cat > "$STAGE/BUNDLE.md" <<'EOF'
# ExaParse Pro — parser-jev-fixed22

Fixed version of the Persian/English school-exam parser (Vite + React 19 + TS +
Express, port 3000): the offline-first parse pipeline, JEV parse verification,
rule mining + mined templates, the image understanding pipeline, the COMPLETE
FLOW (M1-M6), full portability, the printed-key + reliability waves, the
build-15 real-exam regression wave, the qu2 accuracy waves (6 files pinned at
exactly 100%), and NOW the LAYOUT BRAIN wired end-to-end (Wave G4).

## What is inside (mirrors the workspace 1:1 — unzip at project root)

- `repo-parser/`        the application (src, server, scripts, scripts-batch, data)
- `scripts/`            verification suites + grader runners + the layout
                        feasibility/geometry tools (layout_probe.py,
                        extract_geometry.py, build_brain_input.py)
- `samples/mocks/`      20 hand-built mock exams (layout-family sweep)
- `scratch/gt/`         30 hand-built golden ground-truth files
- `scratch/gt-mocks/`   20 hand-built mock ground-truth files
- `scratch/texts*/`     extracted texts so every grader runs immediately
- `scratch/gt-qu2/`     32 hand-built qu2 ground truths (+ pinned copies)
- `repo-parser/scratch/brain-app-qu2/`  APP-DOMAIN geometry sidecars for the
                        whole 47-file qu2 corpus (pdf.js lines+bold+rules+rects
                        and the matching raw texts) — the bridge report runs
                        offline against these
- `IMPLEMENTATION_PLAN.md`  the locked plan
- `curriculum-digest-v2.json`  the book-verified digest

## NEW in fixed22 — the layout brain is WIRED (Wave G4)

The evidence-fusion sectioning brain (G2: perceive tables/rules/boxes/font
headers/letters/marks; G3: cross-checked fusion + confidence-gated commit +
per-section evidence receipts) now runs inside the app, not just offline:

- APP-DOMAIN GEOMETRY: the PDF extractor's pdf.js pass builds the brain's
  input in the SAME pass that builds the text — line grouping identical to
  the extracted text, bold resolved through the font objects (heavy Persian
  face names included), horizontal rules + boxes decoded from the v6
  operator list (stroked segments AND thin filled rects; polygons via bbox).
- BRAIN BRIDGE (src/utils/brainBridge.ts): BrainResult -> the engine's exact
  RawSectionBlock interface. Per-row blocks when rows carry their own lines
  (the graded shape), section blocks otherwise; residual lines ride with the
  nearest row; EVERY content line lands in exactly one block (the prelude
  above the first boundary included); the printed answer-key boundary is cut
  from the blocks (key = metadata); rowIds are the PRINTED letters verbatim
  (per-part restarts keep their duplicates).
- UNCERTAINTY, FLAGGED NOT HIDDEN: every block carries a brain receipt
  (confidence, boundary kind, evidence notes); unconfirmed separations raise
  "Uncertain section boundary (layout)" anomalies; doc.brainReport (mode,
  confirmed/sections, sumMarks vs printedTotal, audit notes) rides on the
  document and shows in the parse journey.
- SHIP POSTURE (evidence-driven): the brain ships ADVISORY — it perceives,
  verifies and reports, while the battle-tested text splitters parse. The
  app-domain corpus report (scripts/brain_bridge_report.mts) measures the
  wired path honestly (2 files better, 19 worse, 11 ties today); "Layout
  brain drives" is an explicit ParseScreen toggle (worker path included).
  The brain becomes the default splitter only when the report shows it
  winning corpus-wide — worst case = status quo, by construction.
- PERSIAN LAYOUT FAMILIES (generalization hardening): Persian row letters
  (الف ب پ ت...) flow through one rank-based letter algebra (sequences,
  regression/key discrimination, mirrored-table sorting, marks-table letter
  cells, fused openers, forward skips like الف ب ج د); Persian MCQ option
  runs (ب/ج/د/ه) are suppressed as options; Latin<->Persian alphabet
  switches RESET the sequence expectation instead of fabricating key drops.
- STRIP-ROW CONTENT RECOVERY: marks-table rows (letter+mark index strips)
  recover their body content by matching the row's printed opener among the
  section's lines — the marks table is an index, the body opens later.
- HARDENING: geometry sidecars are validated + capped (pages/lines/shapes —
  scan noise ~10^5 shapes/page cannot hang or poison a parse); malformed
  inputs throw into the caller's fallback; brain failures log to the black
  box and fall back to the text splitters, never break a parse.
- STRESS: scripts/brain_stress.ts now 42/42 (15 Latin layout families +
  Persian rows/marks tables/option runs/alphabet switches + malformed docs).
- APP-DOMAIN HARNESS: scripts/brain_app_extract.mts rebuilds the whole
  corpus's geometry with the SAME pdf.js code path the browser runs, and
  scripts/brain_bridge_report.mts grades the wired path against the qu2 GTs
  (the honest, shipped-pipeline measurement).

## Carried from fixed21 — the layout brain (G1-G3)

- Layout probe over the 47-file qu2 corpus: ruled section tables 32/47,
  font-size headers 32/47, horizontal rules 41/47, boxes 41/47, any geometry
  42/47, plain-text-only 0/47 — the corpus is geometry-rich; text heuristics
  were solving layout problems blindfolded.
- src/utils/layoutBrain.ts: perceive -> fuse -> verify -> commit with
  cross-checked evidence (letter-sequence continuity, mark plausibility,
  mark-sum vs printed total, header/letter agreement, rule corroboration);
  answer-key tables dropped via letter regression; duplicate-sheet ladders
  demoted with sticky flags; kanoon strip-above-header ownership.
- 15 synthetic layout families (28 assertions) — the generality net.

## Verify gate (single command, cross-platform)

    cd repo-parser
    npm install
    npm run verify

Gate: tsc lint -> the feature suites (fixes/features/jev/parseVerifier/mining/
vision/surfaceFilter/answerFlow/curriculum/calibration/aiWire/keyFile/
realExam) -> goldenCorpus -> strict 30-exam grade -> strict 20-mock grade ->
20-mock suite -> 6/6 pinned qu2 -> qu2 scorecard + 47/47 accounting.
Strict: any FAIL/SKIP/shrink exits non-zero.
Auxiliary (non-gating): npx tsx scripts/brain_stress.ts (42/42),
npx tsx scripts/brain_bridge_report.mts (wired-path corpus report).

## Shipped gate results (2026-10-03)

- npm run verify EXIT=0: 30/30 golden + 20/20 mocks + 6/6 pinned qu2 at 100%
  (scorecard 6/32) + 47/47 corpus accounting.
- brain_stress 42/42.
EOF

# --- zip ---
cd "$STAGE"
rm -f "$OUT"
zip -qr "$OUT" .
cd "$ROOT"
echo "== bundle built: $OUT"
sha256sum "$OUT"
unzip -l "$OUT" | tail -2
