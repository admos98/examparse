#!/bin/bash
# Bundle parser-jev-fixed23.zip — fixed22 + WAVE G5: THE BRAIN WINS CORPUS-WIDE
# AND DRIVES BY DEFAULT. The user read the G4 honest report (drive mode 2
# better / 19 worse / 11 ties) as "the brain is bad" — this wave fixed every
# failure family: NFKC footer/continuation furniture perception, margin
# page-number vs بارم discrimination, NUMERIC RADIF openers ("8 Grammar" fused
# anchors, ladder-checked bare integers, content-line identity adoption),
# keyword-header attachment, dialogue-speaker ("A: ...") guard, unruled
# marks-strip pair resolution (the ردیف ladder column is dropped, the بارم
# column is kept), and duplicate-printed-sheet cycle detection. The bridge now
# emits in strict document order with numeric rowIds and a DRIVE GATE (full
# confirmation + coverage>=60% + marks closure). The engine parses brain blocks
# through canonical-slice parity so content-derived typing can never drift
# from the text splitters.
# Corpus (app-domain bridge report): 1 better / 0 worse / 31 ties — average
# brain 19.8% vs text 18.8%, SIX files at exactly 100% via the brain path.
# Worst case = status quo by the gate; abstentions carry the reason.
# Stress suite 55/55. Gate: 30/30 golden + 20/20 mocks + 6/6 pinned qu2 +
# scorecard + 47/47 accounting — npm run verify EXIT=0 (verify shell unchanged).
# Layout mirrors the workspace 1:1 so a fresh restore = unzip at project root.
set -euo pipefail

ROOT=/home/z/my-project
STAGE=$ROOT/scratch/stage-fixed23
OUT=$ROOT/download/parser-jev-fixed23.zip

rm -rf "$STAGE"
mkdir -p "$STAGE"

# --- repo-parser: full source, no node_modules / dist / .git ---
mkdir -p "$STAGE/repo-parser"
(cd "$ROOT/repo-parser" && tar cf - \
  --exclude='./node_modules' --exclude='./dist' --exclude='./server.js' \
  --exclude='./.git' --exclude='./.vite' \
  --exclude='./scratch/brain-qu2' --exclude='./scratch/geo-qu2' \
  --exclude='./scratch/layout-probe' --exclude='./scratch/stage-*' \
  src scripts scripts-batch data server.ts package.json package-lock.json bun.lock \
  vite.config.ts tsconfig.json index.html .env.example metadata.json \
  JEV_NOTES.md .gitignore) | tar xf - -C "$STAGE/repo-parser"

# the pdftotext-sidecar brain report (historical G3 corpus posture)
mkdir -p "$STAGE/repo-parser/scratch/brain-qu2"
cp "$ROOT/repo-parser/scratch/brain-qu2/report.json" "$STAGE/repo-parser/scratch/brain-qu2/report.json" 2>/dev/null || true
# the APP-DOMAIN harness sidecars (pdf.js geometry + texts) + layout probe report
cp -r "$ROOT/repo-parser/scratch/brain-app-qu2" "$STAGE/repo-parser/scratch/brain-app-qu2"
mkdir -p "$STAGE/repo-parser/scratch/layout-probe"
cp "$ROOT/repo-parser/scratch/layout-probe/report.json" "$STAGE/repo-parser/scratch/layout-probe/report.json" 2>/dev/null || true

# --- gate suites + runners (live in ../scripts in the workspace) ---
cp -r "$ROOT/scripts" "$STAGE/scripts"
rm -f "$STAGE"/scripts/bundle_fixed*.sh

# --- change note ---
cp "$ROOT/download/IMPLEMENTATION_PLAN.md" "$STAGE/IMPLEMENTATION_PLAN.md"
cp "$ROOT/download/curriculum-digest-v2.json" "$STAGE/curriculum-digest-v2.json"

# --- corpora + hand-built ground truth + extracted texts (grader inputs) ---
mkdir -p "$STAGE/samples" "$STAGE/scratch"
cp -r "$ROOT/samples/mocks" "$STAGE/samples/mocks"
cp -r "$ROOT/scratch/gt"       "$STAGE/scratch/gt"
cp -r "$ROOT/scratch/gt-mocks" "$STAGE/scratch/gt-mocks"
cp -r "$ROOT/scratch/texts"       "$STAGE/scratch/texts"
cp -r "$ROOT/scratch/texts-mocks" "$STAGE/scratch/texts-mocks"
cp -r "$ROOT/scratch/gt-qu2"     "$STAGE/scratch/gt-qu2"
cp -r "$ROOT/scratch/gt-qu2-pinned" "$STAGE/scratch/gt-qu2-pinned"
cp -r "$ROOT/scratch/texts-qu2"  "$STAGE/scratch/texts-qu2"
cp "$ROOT/scratch/qu2-classify.json" "$ROOT/scratch/qu2-deferred.json" "$STAGE/scratch/" 2>/dev/null || true

# --- BUNDLE.md ---
cat > "$STAGE/BUNDLE.md" <<'EOF'
# ExaParse Pro — parser-jev-fixed23

Fixed version of the Persian/English school-exam parser (Vite + React 19 + TS +
Express, port 3000): the offline-first parse pipeline, JEV parse verification,
rule mining + mined templates, the image understanding pipeline, the COMPLETE
FLOW (M1-M6), full portability, the printed-key + reliability waves, the
build-15 real-exam regression wave, the qu2 accuracy waves (6 files pinned at
exactly 100%), the LAYOUT BRAIN wired end-to-end (G4), and NOW the brain
WINNING corpus-wide and DRIVING BY DEFAULT under its verification gate (G5).

## What is inside (mirrors the workspace 1:1 — unzip at project root)

- `repo-parser/`        the application (src, server, scripts, scripts-batch, data)
- `scripts/`            verification suites + grader runners + the layout
                        feasibility/geometry tools (layout_probe.py,
                        extract_geometry.py, build_brain_input.py)
- `samples/mocks/`      20 hand-built mock exams (layout-family sweep)
- `scratch/gt/`         30 hand-built golden ground-truth files
- `scratch/gt-mocks/`   20 hand-built mock ground-truth files
- `scratch/texts*/`     extracted texts so every grader runs immediately
- `scratch/gt-qu2/`     32 hand-built qu2 ground truths (+ pinned copies)
- `repo-parser/scratch/brain-app-qu2/`  APP-DOMAIN geometry sidecars for the
                        whole 47-file qu2 corpus (pdf.js lines+bold+rules+rects
                        and the matching raw texts) — the bridge report runs
                        offline against these
- `IMPLEMENTATION_PLAN.md`  the locked plan
- `curriculum-digest-v2.json`  the book-verified digest

## NEW in fixed23 — the brain drives by default (Wave G5)

The G4 honest measurement (drive mode 2 better / 19 worse / 11 ties) named the
gaps; G5 closed them family by family — every fix is a PRINCIPLED rule over
signal combinations, not a corpus-fitted one-off:

- FURNITURE PERCEPTION: NFKC-folds Arabic presentation forms so assessment-
  center footers (مرکز سنجش و پایش...) and continuation markers («ادامه ي
  سوالات...») are furniture in both storage orders. A footer rule can never
  again be a "confirmed section" driving a parse.
- PAGE NUMBERS vs BAROM: a bare digit line in the top/bottom margin is a page
  number — never a mark, never an opener (p566's marks 1..7 were page numbers).
- NUMERIC RADIF GENRE: fused "N Subject" openers ("8 Grammar", "12 درک مطلب")
  anchor a numeric section ladder; bare bold integers join only while they
  continue it; a section whose first content line opens with the advancing
  ladder number adopts that identity; the bridge emits the printed number as
  the rowId. The numeric-paper genre is no longer blind to the brain.
- KEYWORD-HEADER ATTACHMENT: a short keyword-only line printed just above an
  opener labels THAT section (subject adopted, line moved — never stolen from
  a header event, never duplicated).
- DIALOGUE GUARD: "A: ... / B: ..." transcript speakers (letter+colon) are
  never row openers.
- UNRULED MARKS STRIPS: two bare-mark columns bracketing the content per row —
  the column whose values form the strict 1..N ladder is the ردیف index and is
  dropped; the other column is the بارم and pairs to the rows (p566: marks now
  exact, sumMarks 15 = printed total).
- DUPLICATE-CYCLE DETECTION: a double-printed sheet repeats its opening
  (subject|first-row) cycle with question numbers restarting — the repeated
  tail is flagged and demoted (p4tk9v2803 abstains honestly instead of
  double-parsing).
- DOCUMENT-ORDER BRIDGE: one walk over the brain's lines — confirmed sections
  emit at their first line, uncovered lines become General runs IN PLACE
  (pm57's Listening is no longer appended past R); strip-index digits are
  trimmed at block leading edges; rowIds fall back to the numeric identity.
- DRIVE GATE (worst case = status quo, by construction): the brain drives only
  when EVERY section is confirmed AND confirmed sections cover >=60% of the
  content lines AND the extracted marks close on the printed total (when one
  is printed). Every refusal pushes its reason into the report notes.
- CANONICAL-SLICE PARITY (engine): brain blocks decide BOUNDARIES; the content
  is the exact canonical-text slice between the located starts (probes run
  through the same canonicalize + OCR-normalize pipeline; the key-sheet
  boundary caps the tail). Opener-letter prefix and category inference now
  behave identically to the text splitters, so content-derived typing can
  never drift. Unconfirmed runs whose questions are all junk (bare URLs) drop
  out with a flagged anomaly instead of phantom sections.
- DEFAULT FLIPPED (the charter's condition — winning corpus-wide — is met):
  buildBrainPreSplit defaults to 'drive' in the pipeline, the worker and the
  UI; "Layout brain drives" on the Parse screen is now the opt-OUT. Advisory
  mode remains one untick away.

## Carried from fixed22 — the layout brain wired (G4) / fixed21 (G2-G3)

- App-domain geometry in the SAME pdf.js pass that builds the text (line
  grouping identical, bold via font objects incl. heavy Persian faces, rules +
  rects decoded from the v6 operator list with a v5 fallback).
- Evidence-fusion brain: perceive tables/rules/boxes/font headers/letters/
  marks -> cross-checked fusion (letter-sequence continuity, mark plausibility,
  mark-sum vs printed total, header/letter agreement, rule corroboration) ->
  confidence-gated commit with per-section evidence receipts; answer-key tables
  dropped via letter regression; kanoon strip-above-header ownership.
- Persian layout families: rank-based row-letter algebra (الف ب پ...), Persian
  marks-table letter cells, Persian MCQ option-run suppression, alphabet
  switches reset the sequence expectation; strip-row content recovery (the
  marks table is an index, the body opens later).
- Geometry sidecars validated + capped (scan noise ~10^5 shapes/page cannot
  hang or poison a parse); brain failures log to the black box and fall back
  to the text splitters, never break a parse.

## Verify gate (single command, cross-platform)

    cd repo-parser
    npm install
    npm run verify

Gate: tsc lint -> the feature suites (fixes/features/jev/parseVerifier/mining/
vision/surfaceFilter/answerFlow/curriculum/calibration/aiWire/keyFile/
realExam) -> goldenCorpus -> strict 30-exam grade -> strict 20-mock grade ->
20-mock suite -> 6/6 pinned qu2 -> qu2 scorecard + 47/47 accounting.
Strict: any FAIL/SKIP/shrink exits non-zero.
Auxiliary (non-gating): npx tsx scripts/brain_stress.ts (55/55),
npx tsx scripts/brain_bridge_report.mts (wired-path corpus report — the brain
drives by default; 1 better / 0 worse / 31 ties, avg 19.8% vs 18.8%).

## Shipped gate results (2026-10-03)

- npm run verify EXIT=0: 30/30 golden + 20/20 mocks + 6/6 pinned qu2 at 100%
  (scorecard 6/32) + 47/47 corpus accounting.
- brain_stress 55/55.
- brain_bridge_report: brain-better 1 / text-better 0 / ties 31; corpus average
  brain-wired 19.8% vs text-only 18.8%; 6 files at exactly 100% via the brain.
EOF

# --- zip ---
cd "$STAGE"
rm -f "$OUT"
zip -qr "$OUT" .
cd "$ROOT"
echo "== bundle built: $OUT"
sha256sum "$OUT"
unzip -l "$OUT" | tail -2
