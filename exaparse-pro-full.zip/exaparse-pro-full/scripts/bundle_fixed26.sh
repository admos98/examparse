#!/bin/bash
# Bundle parser-jev-fixed26.zip — THE ASSEMBLY WAVE (fix-11): the corpus
# plateau root-caused and fixed at the cause. The engine's structural
# assembly was gated by cosmetic text shapes, not by exam structure:
#   1. Persian bare-letter anchors matched only (الف|هـ|[بجدهو]) — every
#      Persian ladder past د (پ ت ث چ ح خ …) was invisible; sheets parsed as
#      4 sections instead of 10 (65o69 -76.5%). Now: FULL Persian alphabet +
#      dual-sequence ladder guard (Latin/abjad seqKey OR Persian alphabetical
#      ordinal, advance 1..3, start at A/الف, repeats kept). 65o69 -> +42.9.
#   2. کانون key sheets repeat the exam verbatim with answers filled, no
#      banner: subject-banner key signature (solo banner + >=3 DENSE numbered
#      answer rows, >=2 number tokens/line, no blank markers incl. dashes,
#      cut floored at 10%) + identical header-cycle cut (>=5 headers, tail ==
#      previous k verbatim, cut at the SECOND cycle). pt7kkv -131.6 -> -68.4;
#      2657j6465 -22.7 -> +39.5 (was parsing 22 sections = 2x11).
#   3. radif phantom rungs (bidi cell duplication: "1/Listening/2/...") split
#      a row into an empty label block + a double-content block — every later
#      row landed one section late. Narrow empty-row merge (<=2 non-blank
#      lines, question-less, successor opens with an instruction). pc8er
#      25.8 -> 47.5. Content-plausible chain scoring in collectRadifLadder.
#   4. instruction-blocks dropped the pre-first-label region: t7kkv's
#      Listening (q1-14) vanished when the extractor lost its banner. The
#      leading region is now kept as a section (id = inferred subject when
#      unique, else 'A'), strictly AFTER the >=4 gate so it can never steal a
#      lettered paper (pw1387 gate-order bug caught by the corpus, fixed).
# Corpus (32 GT'd non-OCR qu2 files): 20.3% -> 29.7% avg, negative scorers
# 9 -> 7, 6/32 pinned at exactly 100% (untouched). Gate: 30/30 golden +
# 20/20 mocks + 6/6 pinned qu2 + all verify stages — npm run verify EXIT=0.
# Layout mirrors the workspace 1:1 so a fresh restore = unzip at project root.
set -euo pipefail

ROOT=/home/z/my-project
STAGE=$ROOT/scratch/stage-fixed26
OUT=$ROOT/download/parser-jev-fixed26.zip

rm -rf "$STAGE"
mkdir -p "$STAGE"

# --- repo-parser: full source, no node_modules / dist / .git ---
mkdir -p "$STAGE/repo-parser"
(cd "$ROOT/repo-parser" && tar cf - \
  --exclude='./node_modules' --exclude='./dist' --exclude='./server.js' \
  --exclude='./.git' --exclude='./.vite' \
  --exclude='./scratch/brain-qu2' --exclude='./scratch/geo-qu2' \
  --exclude='./scratch/layout-probe' --exclude='./scratch/stage-*' \
  src scripts scripts-batch data server.ts package.json package-lock.json bun.lock \
  vite.config.ts tsconfig.json index.html .env.example metadata.json \
  JEV_NOTES.md .gitignore) | tar xf - -C "$STAGE/repo-parser"

# W1/W2 Specialist artifacts: distilled training labels + training logs
# (labels live at the WORKSPACE scratch root, not inside the package)
mkdir -p "$STAGE/repo-parser/scratch/w1w2"
cp "$ROOT/scratch/w1w2/labeled.json" "$STAGE/repo-parser/scratch/w1w2/labeled.json"
cp "$ROOT/scratch/w1w2/"*.log "$STAGE/repo-parser/scratch/w1w2/" 2>/dev/null || true

# the pdftotext-sidecar brain report (historical G3 corpus posture) + the
# geometry sidecars the W1/W2 eval + retrains read (PKG_ROOT/scratch/brain-qu2)
mkdir -p "$STAGE/repo-parser/scratch/brain-qu2"
cp "$ROOT/repo-parser/scratch/brain-qu2/report.json" "$STAGE/repo-parser/scratch/brain-qu2/report.json" 2>/dev/null || true
cp "$ROOT/repo-parser/scratch/brain-qu2/"*.json "$STAGE/repo-parser/scratch/brain-qu2/" 2>/dev/null || true
# the APP-DOMAIN harness sidecars (pdf.js geometry + texts) + layout probe report
cp -r "$ROOT/repo-parser/scratch/brain-app-qu2" "$STAGE/repo-parser/scratch/brain-app-qu2"
mkdir -p "$STAGE/repo-parser/scratch/layout-probe"
cp "$ROOT/repo-parser/scratch/layout-probe/report.json" "$STAGE/repo-parser/scratch/layout-probe/report.json" 2>/dev/null || true

# --- gate suites + runners (live in ../scripts in the workspace) ---
cp -r "$ROOT/scripts" "$STAGE/scripts"
rm -f "$STAGE"/scripts/bundle_fixed*.sh

# --- change note ---
cp "$ROOT/download/IMPLEMENTATION_PLAN.md" "$STAGE/IMPLEMENTATION_PLAN.md"
cp "$ROOT/download/curriculum-digest-v2.json" "$STAGE/curriculum-digest-v2.json"

# --- corpora + hand-built ground truth + extracted texts (grader inputs) ---
mkdir -p "$STAGE/samples" "$STAGE/scratch"
cp -r "$ROOT/samples/mocks" "$STAGE/samples/mocks"
cp -r "$ROOT/scratch/gt"       "$STAGE/scratch/gt"
cp -r "$ROOT/scratch/gt-mocks" "$STAGE/scratch/gt-mocks"
cp -r "$ROOT/scratch/texts"       "$STAGE/scratch/texts"
cp -r "$ROOT/scratch/texts-mocks" "$STAGE/scratch/texts-mocks"
cp -r "$ROOT/scratch/gt-qu2"     "$STAGE/scratch/gt-qu2"
cp -r "$ROOT/scratch/gt-qu2-pinned" "$STAGE/scratch/gt-qu2-pinned"
cp -r "$ROOT/scratch/texts-qu2"  "$STAGE/scratch/texts-qu2"
cp "$ROOT/scratch/qu2-classify.json" "$ROOT/scratch/qu2-deferred.json" "$STAGE/scratch/" 2>/dev/null || true

# --- BUNDLE.md ---
cat > "$STAGE/BUNDLE.md" <<'EOF'
# ExaParse Pro — parser-jev-fixed26

Fixed version of the Persian/English school-exam parser (Vite + React 19 + TS +
Express, port 3000): the offline-first parse pipeline, JEV parse verification,
rule mining + mined templates, the image understanding pipeline, the COMPLETE
FLOW (M1-M6), full portability, the printed-key + reliability waves, the
build-15 real-exam regression wave, the qu2 accuracy waves (6 files pinned at
exactly 100%), the layout brain winning corpus-wide and driving by default
(G5), and NOW the W1+W2 SPECIALIST STACK: the trained semantic codec + the
trained structure transformer, integrated behind the JEV constitution (G6-W2).

## NEW in fixed26 — the assembly wave (fix-11)

The measured answer to "what are we doing wrong": structural ASSEMBLY, gated
by cosmetic text shapes. Four deterministic fixes inside the single pipeline,
each A/B'd on the 32-file GT harness:

- FULL PERSIAN ALPHABET ANCHORS: bare solo rungs پ ت ث چ ح خ … were invisible
  (a hardcoded 7-letter whitelist) — every Persian ladder past د amputated.
  The ladder guard now accepts an advance on either the abjad-6 Latin key
  (الف ب ج د ه و = A..F) or the full Persian alphabetical ordinal
  (الف ب پ ت ث ج … = 1..32), keeping strays out via the same step rules.
- KEY-SHEET CUTS (2 new signatures): the کانون answer key repeats the exam
  VERBATIM with answers filled — caught by (a) subject banners followed by
  dense short numbered answer rows (>=2 number tokens per line — real exam
  rows carry exactly one) and (b) an identical >=5-header letter-cycle
  repeated in order. Cuts are floored at 10% into the text (a key FOLLOWS
  the body).
- RADIF PHANTOM-RUNG MERGE: bidi cell duplication plants a rung right after
  a row's subject label, splitting it into an empty label block + a block
  holding two rows' questions. The measured phantom shape folds forward
  (short, question-less, successor opens with an instruction).
- LEADING-REGION SECTION: a first section whose banner never extracted kept
  its questions in the parse (id = inferred subject when unique, else 'A'),
  strictly after the >=4 gate so it can never steal lettered papers.

Measured corpus (fail_dissect, 32 GT'd non-OCR qu2 files): 20.3% -> 29.7%
average, negative scorers 9 -> 7, the 6 pinned 100% files untouched.
Gate: 30/30 golden + 20/20 mocks + 6/6 pinned qu2 + all verify stages,
npm run verify EXIT=0.

## What is inside (mirrors the workspace 1:1 — unzip at project root)

- `repo-parser/`        the application (src, server, scripts, scripts-batch, data)
- `scripts/`            verification suites + grader runners + the layout
                        feasibility/geometry tools (layout_probe.py,
                        extract_geometry.py, build_brain_input.py)
- `samples/mocks/`      20 hand-built mock exams (layout-family sweep)
- `scratch/gt/`         30 hand-built golden ground-truth files
- `scratch/gt-mocks/`   20 hand-built mock ground-truth files
- `scratch/texts*/`     extracted texts so every grader runs immediately
- `scratch/gt-qu2/`     32 hand-built qu2 ground truths (+ pinned copies)
- `repo-parser/scratch/brain-app-qu2/`  APP-DOMAIN geometry sidecars for the
                        whole 47-file qu2 corpus (pdf.js lines+bold+rules+rects
                        and the matching raw texts) — the bridge report runs
                        offline against these
- `IMPLEMENTATION_PLAN.md`  the locked plan
- `curriculum-digest-v2.json`  the book-verified digest

## NEW in fixed25 — fix-10: measured roots, permanent disposal (charter-clean)

The honest measurement campaign answered "what percent today, and on what
exactly": the 32 gradable non-OCR qu2 files averaged 7.9%, with 10 negative
scorers. fail_textpath.mts (new harness) proved the decisive fact: the brain
drive path is better than the plain text path on ZERO files and
catastrophically worse on 2 (p28932i821: confirmed-drive -340% vs text-path
+43.5%). The corpus failures are text-path failures; the brain adds no
measured value today and occasionally destroys files the text path handles.

- UNIVERSAL DUAL-RUN DISPOSAL (parseExamRawText): ANY preSplit — the layout
  brain's confirmed drive blocks OR a W1+W2 oracle proposal — is now parsed
  BOTH ways (deterministic text path + preSplit path) and the invariant
  physics picks the winner (strictly fewer violations; ties keep the text
  path; a receipt lands in validationFlags with the provenance label).
  Drive became a PROPOSAL; JEV disposes. The brain can never again make a
  parse worse than the path it tried to replace — worst case = status quo,
  now by construction on the whole corpus, not just oracle files.
- BARM GLYPH REPAIR (snapBarmValue): some qu2 PDFs carry a broken ToUnicode
  CMap mapping the Persian FIVE digit (۵) to "1" — every printed 1.5 بارم
  cell extracts as the impossible "1.1". Iranian marks are quarter multiples,
  so a trailing .1 is always corruption: snapBarmValue (x.1 -> x.5) is wired
  into all three identical parseMark cell readers (kanoon, radif ladder
  collector, radif splitter) at one choke point; question numbers and
  section ids never pass through it.
- MEASURED A/B DISCIPLINE: a third candidate (radif phantom-tail-rung
  demotion) was implemented, measured NET-NEGATIVE on the grader (p91294's
  junk tail block occupies GT section 20's ladder slot) and reverted — the
  A/B reasoning is preserved as a code comment so it is never re-tried blind.
- CORPUS EFFECT (32 GT'd non-OCR files): average 7.9% -> 20.3%, negative
  scorers 10 -> 9 (p28932i -340 -> +43.5, p8yp4 2.9 -> 6.5, pkhn2 -37.9 ->
  -27.6); 6/32 still at exactly 100%; w1w2_eval still better 1 / worse 0 /
  tie 31 (oracle drove 1 parse, -131.6 -> -75.0).
- Remaining named roots (next waves): lettered-sheet boundary assembly
  (over/under-split -> the q.count/q.number/STRUCT families) and
  instruction-driven q.type/category confusions on mixed sub-task sections;
  then W1/W2 retraining on the grown GT set.

## Carried from fixed24 — W1+W2 Specialist stack, trained and integrated

The Specialist architecture is NOT a shrunken LLM: it factorizes the language
of exams into a tiny learned codec and a tiny learned structure model, and the
deterministic JEV physics stays the sole authority. (In fixed25 the JEV
disposal below extends from oracle-only to ANY preSplit — see NEW in fixed25.)

- W1 SEMANTIC CODEC (shipped weights, ~248KB int8): char-level classifier
  mapping every line into a closed structural alphabet — ROLE(12) x SUBJECT(9)
  x INSTRUCTION(10) over hashed char-n-gram + geometry features. Trained on
  18,583 labeled lines from the 47-file corpus: file-grouped CV 88.65% role
  accuracy. Zero open-world surface: it can only PICK symbols, never invent.
- W2 STRUCTURE TRANSFORMER (shipped weights, 103KB int8, 79K params): causal
  decoder (2 pre-LN blocks, D=64, 2 heads, ctx=72) over the codec symbol
  stream predicting the next STRUCTURAL EVENT per line (SEC/ROW/MARK/KEY/
  TOTAL/PASS). Trained pure-TypeScript: gradcheck-gated, file-grouped CV
  98.0% held-out event accuracy, per-class F1 SEC 1.00 / ROW 1.00 / MARK
  0.99 / KEY 0.96 / TOTAL 1.00 / PASS 0.85, per-class thresholds swept.
  Training-side fixes that made it learn at all (all documented in code):
  the pooled-backward-workspace dQ/dK/dV cross-batch contamination (the
  whole collapse), per-window CONT-mass rebalancing, stratified event-window
  sampling, and frozen embeddings (probe-proven: the mapping is linear in
  the symbol embeddings).
- JEV DISPOSAL (the constitution, unchanged): the oracle proposes only where
  the deterministic brain's drive gate refuses, its proposal must survive
  oracleStructureSane (>=2 real sections, rank-continuous row ladders per
  alphabet, alphabet-switch ban, marks closure vs the printed total, an
  offset-tolerant duplicate-cycle veto for double-printed sheets), and the
  engine DUAL-RUNS text-path vs oracle-path keeping the parse with fewer
  invariant violations (ties keep the text path). Receipts everywhere;
  worst case = status quo, by construction.
- Corpus A/B (32 GT files): better 1 / worse 0 / tie 31, average 6.80% ->
  8.57%; the oracle drove exactly 1 parse (-131.6% -> -75.0%).
- ONE PIPELINE: geometry+text -> layout brain -> (drive | oracle proposal ->
  sanity veto -> dual-run invariants) -> parserEngine -> JEV. Stages, never
  parallel approaches; the teacher AI stays dev-side (selectable provider).

## Carried from fixed23 — the brain drives by default (Wave G5)

The G4 honest measurement (drive mode 2 better / 19 worse / 11 ties) named the
gaps; G5 closed them family by family — every fix is a PRINCIPLED rule over
signal combinations, not a corpus-fitted one-off:

- FURNITURE PERCEPTION: NFKC-folds Arabic presentation forms so assessment-
  center footers (مرکز سنجش و پایش...) and continuation markers («ادامه ي
  سوالات...») are furniture in both storage orders. A footer rule can never
  again be a "confirmed section" driving a parse.
- PAGE NUMBERS vs BAROM: a bare digit line in the top/bottom margin is a page
  number — never a mark, never an opener (p566's marks 1..7 were page numbers).
- NUMERIC RADIF GENRE: fused "N Subject" openers ("8 Grammar", "12 درک مطلب")
  anchor a numeric section ladder; bare bold integers join only while they
  continue it; a section whose first content line opens with the advancing
  ladder number adopts that identity; the bridge emits the printed number as
  the rowId. The numeric-paper genre is no longer blind to the brain.
- KEYWORD-HEADER ATTACHMENT: a short keyword-only line printed just above an
  opener labels THAT section (subject adopted, line moved — never stolen from
  a header event, never duplicated).
- DIALOGUE GUARD: "A: ... / B: ..." transcript speakers (letter+colon) are
  never row openers.
- UNRULED MARKS STRIPS: two bare-mark columns bracketing the content per row —
  the column whose values form the strict 1..N ladder is the ردیف index and is
  dropped; the other column is the بارم and pairs to the rows (p566: marks now
  exact, sumMarks 15 = printed total).
- DUPLICATE-CYCLE DETECTION: a double-printed sheet repeats its opening
  (subject|first-row) cycle with question numbers restarting — the repeated
  tail is flagged and demoted (p4tk9v2803 abstains honestly instead of
  double-parsing).
- DOCUMENT-ORDER BRIDGE: one walk over the brain's lines — confirmed sections
  emit at their first line, uncovered lines become General runs IN PLACE
  (pm57's Listening is no longer appended past R); strip-index digits are
  trimmed at block leading edges; rowIds fall back to the numeric identity.
- DRIVE GATE (worst case = status quo, by construction): the brain drives only
  when EVERY section is confirmed AND confirmed sections cover >=60% of the
  content lines AND the extracted marks close on the printed total (when one
  is printed). Every refusal pushes its reason into the report notes.
- CANONICAL-SLICE PARITY (engine): brain blocks decide BOUNDARIES; the content
  is the exact canonical-text slice between the located starts (probes run
  through the same canonicalize + OCR-normalize pipeline; the key-sheet
  boundary caps the tail). Opener-letter prefix and category inference now
  behave identically to the text splitters, so content-derived typing can
  never drift. Unconfirmed runs whose questions are all junk (bare URLs) drop
  out with a flagged anomaly instead of phantom sections.
- DEFAULT FLIPPED (the charter's condition — winning corpus-wide — is met):
  buildBrainPreSplit defaults to 'drive' in the pipeline, the worker and the
  UI; "Layout brain drives" on the Parse screen is now the opt-OUT. Advisory
  mode remains one untick away.

## Carried from fixed22 — the layout brain wired (G4) / fixed21 (G2-G3)

- App-domain geometry in the SAME pdf.js pass that builds the text (line
  grouping identical, bold via font objects incl. heavy Persian faces, rules +
  rects decoded from the v6 operator list with a v5 fallback).
- Evidence-fusion brain: perceive tables/rules/boxes/font headers/letters/
  marks -> cross-checked fusion (letter-sequence continuity, mark plausibility,
  mark-sum vs printed total, header/letter agreement, rule corroboration) ->
  confidence-gated commit with per-section evidence receipts; answer-key tables
  dropped via letter regression; kanoon strip-above-header ownership.
- Persian layout families: rank-based row-letter algebra (الف ب پ...), Persian
  marks-table letter cells, Persian MCQ option-run suppression, alphabet
  switches reset the sequence expectation; strip-row content recovery (the
  marks table is an index, the body opens later).
- Geometry sidecars validated + capped (scan noise ~10^5 shapes/page cannot
  hang or poison a parse); brain failures log to the black box and fall back
  to the text splitters, never break a parse.

## Verify gate (single command, cross-platform)

    cd repo-parser
    npm install
    npm run verify

Gate: tsc lint -> the feature suites (fixes/features/jev/parseVerifier/mining/
vision/surfaceFilter/answerFlow/curriculum/calibration/aiWire/keyFile/
realExam) -> goldenCorpus -> strict 30-exam grade -> strict 20-mock grade ->
20-mock suite -> 6/6 pinned qu2 -> qu2 scorecard + 47/47 accounting.
Strict: any FAIL/SKIP/shrink exits non-zero.
Auxiliary (non-gating): npx tsx scripts/brain_stress.ts (55/55),
npx tsx scripts/brain_bridge_report.mts (wired-path corpus report),
npx tsx scripts-batch/w1w2_eval.mts (W1+W2 oracle A/B over the 32 GT files:
better 1 / worse 0 / tie 31). W1/W2 retrain (dev-side, needs the corpus +
scratch/brain-qu2 sidecars): scripts-batch/codec_train.mts then
scripts-batch/structure_train.mts (budgeted, resumable).

## Shipped gate results (2026-10-04)

- npm run verify EXIT=0: 30/30 golden + 20/20 mocks + 6/6 pinned qu2 at 100%
  (scorecard 6/32) + 47/47 corpus accounting.
- brain_stress 55/55.
- w1w2_eval: better 1 / worse 0 / tie 31; W1 CV role 88.65%, W2 CV events
  98.0%; weights shipped in src/utils (codecWeights.ts, structureWeights.ts).
- Honest non-OCR accuracy state (fix-10): 32 GT'd qu2 files average 20.3%
  (was 7.9% before this wave), 6 files pinned at exactly 100%, 9 negative
  scorers remaining — the 90% campaign continues on the named text-path
  roots (boundary assembly, instruction typing).
EOF

# --- zip ---
cd "$STAGE"
rm -f "$OUT"
zip -qr "$OUT" .
cd "$ROOT"
echo "== bundle built: $OUT"
sha256sum "$OUT"
unzip -l "$OUT" | tail -2
