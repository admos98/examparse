#!/bin/bash
# Bundle parser-jev-fixed9.zip — the fixed version + the full verification gate.
# Layout mirrors the workspace 1:1 so a fresh restore = unzip at project root.
set -euo pipefail

ROOT=/home/z/my-project
STAGE=$ROOT/scratch/stage-fixed9
OUT=$ROOT/download/parser-jev-fixed9.zip

rm -rf "$STAGE"
mkdir -p "$STAGE"

# --- repo-parser: full source, no node_modules / dist / .git ---
mkdir -p "$STAGE/repo-parser"
(cd "$ROOT/repo-parser" && tar cf - \
  --exclude='./node_modules' --exclude='./dist' --exclude='./server.js' \
  --exclude='./.git' --exclude='./.vite' \
  src scripts-batch server.ts package.json package-lock.json bun.lock \
  vite.config.ts tsconfig.json index.html .env.example metadata.json \
  JEV_NOTES.md .gitignore) | tar xf - -C "$STAGE/repo-parser"

# --- gate suites + runners (live in ../scripts in the workspace) ---
mkdir -p "$STAGE/scripts/golden"
cp "$ROOT/scripts/verifyFixes.ts" \
   "$ROOT/scripts/verifyFeatures.ts" \
   "$ROOT/scripts/verifyJev.ts" \
   "$ROOT/scripts/test_parseVerifier.mts" \
   "$ROOT/scripts/goldenCorpus.ts" \
   "$ROOT/scripts/run_mock_grade.sh" \
   "$ROOT/scripts/mock-provider.js" \
   "$ROOT/scripts/e2e-verify.sh" \
   "$STAGE/scripts/"
cp "$ROOT/scripts/golden/fixtures.ts" "$STAGE/scripts/golden/"

# --- corpora + hand-built ground truth + extracted texts (grader inputs) ---
mkdir -p "$STAGE/samples" "$STAGE/scratch"
cp -r "$ROOT/samples/mocks" "$STAGE/samples/mocks"
cp -r "$ROOT/scratch/gt"       "$STAGE/scratch/gt"
cp -r "$ROOT/scratch/gt-mocks" "$STAGE/scratch/gt-mocks"
cp -r "$ROOT/scratch/texts"       "$STAGE/scratch/texts"
cp -r "$ROOT/scratch/texts-mocks" "$STAGE/scratch/texts-mocks"

# --- BUNDLE.md ---
cat > "$STAGE/BUNDLE.md" <<'EOF'
# ExaParse Pro — parser-jev-fixed9

Fixed version of the Persian/English school-exam parser (Vite + React 19 + TS +
Express, port 3000), including the JEV parse-verification flow, all bug-hunt
fixes, and the complete verification gate.

## What is inside (mirrors the workspace 1:1 — unzip at project root)

- `repo-parser/`        the application (src, server, scripts-batch graders)
- `scripts/`            verification suites + mock grader runner + mock provider
- `samples/mocks/`      20 hand-built mock exams (layout-family sweep)
- `scratch/gt/`         30 hand-built golden ground-truth files
- `scratch/gt-mocks/`   20 hand-built mock ground-truth files
- `scratch/texts*/`     extracted texts so the grader runs immediately

## Verify gate (single command)

    cd repo-parser
    npm install
    npm run verify

The gate chains: tsc lint -> verifyFixes (27) -> verifyFeatures (17) ->
verifyJev (20) -> parseVerifier (76) -> goldenCorpus fixtures (252) ->
strict 30-exam grade -> strict 20-mock grade. The grader is strict: any FAIL,
any SKIP, or an empty ground-truth dir exits non-zero, so a regression can
never pass silently.

## Shipped gate results (2026-09-29)

- verifyFixes 27/27, verifyFeatures 17/17, verifyJev 20/20,
  parseVerifier 76/76, goldenCorpus 252/252
- 30-exam strict grade: 30/30 files at 100%
- 20-mock strict grade: 20/20 files at 100%
- negative test: empty GT dir -> GRADER FAIL exit 1 (gate proven able to fail)

## Key commits

- 6732a24 fix(verdict-round): prose-wrapped JSON extraction, term false
  positive, error-correction wording, RTL native rowIds
- 146d16b feat(jev-flow): robustness pass — truthful bank metadata, unverified
  queue, picture OCR annotations
- 43c4c94 chore(gate): strict grader exit codes + 20-mock suite wired into
  npm run verify

## Run

    cd repo-parser
    npm run dev      # http://localhost:3000

Set provider keys via `.env` (see `.env.example`). Everything offline works
without keys; AI features (enhance / judge) need a configured provider.
EOF

# --- zip ---
rm -f "$OUT"
(cd "$STAGE" && zip -q -r "$OUT" .)
echo "---- manifest ----"
unzip -l "$OUT" | tail -3
echo "---- sha256 ----"
sha256sum "$OUT"
