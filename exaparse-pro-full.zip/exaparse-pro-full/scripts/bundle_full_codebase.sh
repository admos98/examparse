#!/bin/bash
# Bundle parser-jev-full-codebase.zip — THE FULL CODE BASE, MODELS CODE AND ALL,
# NO HUGE DATA FILES. Delta vs fixed24: (a) the dev-only teacher/train/eval
# model code now SHIPS (user: "ship me the full code base, with the models code
# and all"), (b) all derived/derived-huge data dirs are EXCLUDED (user: "no huge
# data files to download, i would create the data myself if needed") —
# samples/qu2 PDFs (64M), scratch/geo-qu2 (8.2M), scratch/brain-qu2 per-file
# outputs (8.7M), scratch/brain-app-qu2 (3.1M) — with REGEN.md + rebuild-data.sh
# to recreate every byte of it from code. The strict gate data (hand-built GTs,
# extracted grader texts, 20 mock PDFs — ~2.4MB raw) still ships so
# `npm run verify` is green out of the box.
set -euo pipefail

ROOT=/home/z/my-project
STAGE=$ROOT/scratch/stage-full-codebase
OUT=$ROOT/download/parser-jev-full-codebase.zip

rm -rf "$STAGE"
mkdir -p "$STAGE"

# --- repo-parser: full source + models code, no node_modules / dist / .git ---
mkdir -p "$STAGE/repo-parser"
(cd "$ROOT/repo-parser" && tar cf - \
  --exclude='./node_modules' --exclude='./dist' --exclude='./server.js' \
  --exclude='./.git' --exclude='./.vite' \
  --exclude='./scratch' \
  src scripts scripts-batch data server.ts package.json package-lock.json bun.lock \
  vite.config.ts tsconfig.json index.html .env.example metadata.json \
  JEV_NOTES.md .gitignore) | tar xf - -C "$STAGE/repo-parser"

# --- MODEL CODE INCLUSION PROOF: the learned-brain stack must ship ---
for f in src/utils/tinyBrain.ts src/utils/tinyBrainWeights.ts src/utils/layoutBrain.ts \
         src/utils/brainBridge.ts scripts/tinybrain_train.mts \
         scripts/tinybrain_teacher.mts scripts/tinybrain_eval.mts; do
  [ -f "$STAGE/repo-parser/$f" ] || { echo "FATAL: model code missing: $f" >&2; exit 1; }
done
# ...and the teacher stays a DEV TOOL: nothing in the shipped app imports it
if rg -l "tinybrain_teacher" "$STAGE/repo-parser/src" >/dev/null 2>&1; then
  echo "FATAL: src references the dev-only teacher" >&2; exit 1
fi

# --- tiny provenance artifacts (KB-scale, auditability) ---
mkdir -p "$STAGE/repo-parser/scratch/brain-qu2" "$STAGE/repo-parser/scratch/tinybrain" \
         "$STAGE/repo-parser/scratch/layout-probe"
cp "$ROOT/repo-parser/scratch/brain-qu2/report.json" "$STAGE/repo-parser/scratch/brain-qu2/report.json" 2>/dev/null || true
cp "$ROOT/repo-parser/scratch/tinybrain/train-report.json" "$STAGE/repo-parser/scratch/tinybrain/train-report.json" 2>/dev/null || true
cp "$ROOT/repo-parser/scratch/layout-probe/report.json" "$STAGE/repo-parser/scratch/layout-probe/report.json" 2>/dev/null || true

# --- workspace scripts: verification suites + python geometry/training tools ---
cp -r "$ROOT/scripts" "$STAGE/scripts"
rm -f "$STAGE"/scripts/bundle_fixed*.sh "$STAGE"/scripts/bundle_full_codebase.sh

# --- gate corpora + hand-built ground truth + grader texts (small, ships) ---
mkdir -p "$STAGE/samples" "$STAGE/scratch"
cp -r "$ROOT/samples/mocks" "$STAGE/samples/mocks"
cp -r "$ROOT/scratch/gt"           "$STAGE/scratch/gt"
cp -r "$ROOT/scratch/gt-mocks"     "$STAGE/scratch/gt-mocks"
cp -r "$ROOT/scratch/texts"        "$STAGE/scratch/texts"
cp -r "$ROOT/scratch/texts-mocks"  "$STAGE/scratch/texts-mocks"
cp -r "$ROOT/scratch/gt-qu2"       "$STAGE/scratch/gt-qu2"
cp -r "$ROOT/scratch/gt-qu2-pinned" "$STAGE/scratch/gt-qu2-pinned"
cp -r "$ROOT/scratch/texts-qu2"    "$STAGE/scratch/texts-qu2"
cp "$ROOT/scratch/qu2-classify.json" "$ROOT/scratch/qu2-deferred.json" "$STAGE/scratch/" 2>/dev/null || true

cp "$ROOT/download/IMPLEMENTATION_PLAN.md" "$STAGE/IMPLEMENTATION_PLAN.md"
cp "$ROOT/download/curriculum-digest-v2.json" "$STAGE/curriculum-digest-v2.json"

# --- REGEN.md: recreate every excluded dataset from code ---
cat > "$STAGE/REGEN.md" <<'EOF'
# REGEN — rebuild all data from code (no big data ships)

Everything huge was deliberately left out. Recreate any of it with the code
that is in this bundle:

| Excluded | Size | Rebuild with |
|---|---|---|
| `samples/qu2/` (exam PDF corpus) | 64M | your PDFs — drop them in |
| `repo-parser/scratch/geo-qu2/` (PyMuPDF geometry) | 8.2M | step A2 |
| `repo-parser/scratch/brain-app-qu2/` (+texts) | 3.1M | step A1 |
| `repo-parser/scratch/brain-qu2/` per-file outputs | 8.7M | step A4 |

What DOES ship: all hand-built ground truths, the 20 mock-exam PDFs and the
extracted grader texts (~2.4MB total) — `npm run verify` is green immediately.

## Steps

    # 0) install once
    cd repo-parser && npm install

    # A1) app-domain geometry sidecars for ANY pdf folder (same code path the
    #     browser runs: pdf.js text grouping + operator-list shapes)
    mkdir -p ../samples/qu2 && cp /path/to/your/exams/*.pdf ../samples/qu2/
    npx tsx scripts/brain_app_extract.mts ../samples/qu2
    #    -> scratch/brain-app-qu2/<stem>.json + scratch/brain-app-qu2/texts/<stem>.txt

    # A2) (optional, dev) PyMuPDF geometry + layout probe — needs python3 + pymupdf
    pip install pymupdf
    python3 ../scripts/extract_geometry.py ../samples/qu2 ../repo-parser/scratch/geo-qu2
    python3 ../scripts/layout_probe.py  ../samples/qu2 ../repo-parser/scratch/layout-probe/report.json

    # A3) re-train the tiny model on the (re)built sidecars
    npx tsx scripts/tinybrain_train.mts
    #    -> rewrites src/utils/tinyBrainWeights.ts + scratch/tinybrain/train-report.json

    # A4) brain candidate/section dumps + behavioral eval + corpus posture
    npx tsx scripts/tinybrain_eval.mts
    npx tsx scripts/brain_bridge_report.mts
    npx tsx scripts/brain_corpus.ts

    # A5) OPTIONAL teacher labels (dev-only, YOUR key, never baked in):
    TEACHER_PROVIDER=gemini GEMINI_API_KEY=... npx tsx scripts/tinybrain_teacher.mts
    #    providers: gemini | openai | openrouter | vercel | ollama | custom
    #    ollama = fully local teacher; labels merge into the next training at 3x weight

    # then prove it:
    npm run verify                      # strict gate, no data needed beyond what ships
    npx tsx scripts/brain_stress.ts     # 61/61 synthetic layout assertions

Ground truths for a NEW corpus are hand-built (see scratch/gt-qu2/*.json for the
format) — the grader (scripts-batch/qu2golden.mts) reads GT_DIR +
texts sidecars; start with 2-3 files and promote per the protocol in
IMPLEMENTATION_PLAN.md.
EOF

# --- rebuild-data.sh: one-shot helper for the common path ---
cat > "$STAGE/rebuild-data.sh" <<'EOF'
#!/bin/bash
# One-shot data rebuild for the shipped code base (see REGEN.md for details).
set -euo pipefail
cd "$(dirname "$0")/repo-parser"
[ -d node_modules ] || npm install
PDF_DIR="${1:-../samples/qu2}"
mkdir -p "$PDF_DIR"
echo "== building app-domain sidecars from $PDF_DIR"
npx tsx scripts/brain_app_extract.mts "$PDF_DIR"
echo "== re-training the tiny model"
npx tsx scripts/tinybrain_train.mts
echo "== behavioral eval + corpus report"
npx tsx scripts/tinybrain_eval.mts || true
npx tsx scripts/brain_bridge_report.mts || true
echo "== done. strict gate check: npm run verify"
EOF
chmod +x "$STAGE/rebuild-data.sh"

# --- MODEL_NOTES.md: the boost roadmap (tiny model -> true tiny LLM) ---
cat > "$STAGE/MODEL_NOTES.md" <<'EOF'
# MODEL_NOTES — the brain today, and the road to a true (tiny) LLM

## What ships now (and why it is already "LLM-adjacent")

- `src/utils/layoutBrain.ts` — deterministic perception: ruled tables, font-size
  headers, horizontal rules, boxes, letter/number ladders, marks (بارم), printed
  totals/answer-key boundaries; fuse -> verify -> commit with evidence receipts.
- `src/utils/tinyBrain.ts` + `tinyBrainWeights.ts` — the LEARNED layer: a
  28-feature logistic model + Platt calibration (4KB, pure TS, microseconds).
  It was distilled from the corpus-proven hand fusion (625 labeled candidates,
  file-grouped 5-fold CV: accuracy 86.9%, AUC 0.933) and arbitrates the
  disagreement tails; cross-tier evidence can never be downgraded by it alone.
- Training: `scripts/tinybrain_train.mts` (distillation + synthetic anchors +
  optional teacher labels at 3x). Teacher (dev-only):
  `scripts/tinybrain_teacher.mts` — uses the SAME selectable-provider system as
  the app (gemini/openai/openrouter/vercel/ollama/custom, YOUR key from env,
  ollama = local). The teacher is a dev-side labeling tool, not a runtime
  dependency: inference in the shipped app is 100% local.

## The honest ceiling of a 28-parameter model

It can arbitrate evidence scores; it cannot READ. Header-vs-sentence
disambiguation ("Vocabulary" as a section title vs the word inside a sentence),
Persian fused openers, semantic section typing — these are decided by hand
patterns today. That is exactly what a tiny LLM head can absorb.

## Boost path 1 — layout-token transformer (the true "LLM-ization", stays tiny)

Serialize each page into a TOKEN STREAM and train a tiny decoder-only
transformer — the same architecture class as an LLM, just small:

- Vocabulary: quantized geometry tokens — font-size bucket, bold flag, x/y grid
  cell, rule/box/table events, and wordpieces of the line text.
- Model: 4–6 layers, d_model 128–256, 3–15M params (~5–30MB Q8; a pure-TS
  matmul loop handles <=5M params at ms/section; ONNX Runtime Web / WebGPU for
  the bigger ones, in the existing browser pipeline).
- Task: next-token prediction (pretraining) + a boundary/role tag head
  (header | row-opener | mark | content | furniture | key-row).
- DATA ENGINE (the actual unlock): `scripts/brain_stress.ts` already generates
  synthetic layout families programmatically — scale that generator to 10k+
  synthetic exams with known boundaries, and use the teacher to label the
  ambiguous band of YOUR corpus (active learning: label only 0.35–0.85
  confidence, which is what tinybrain_teacher.mts already selects).
- Keep the arbiter contract: the transformer replaces the linear head, the
  deterministic perception and drive gate stay — worst case = status quo.

## Boost path 2 — distill a pretrained micro-LLM (fastest to "true LLM")

- Base model (open weights): Qwen2.5-0.5B-Instruct, SmolLM2-360M/135M, or
  gemma-2-2b — a real pretrained LLM.
- SFT (LoRA, a few GPU-hours or CPU-feasible at 135M): input = the geometry
  sidecar JSON (the SAME format scratch/brain-app-qu2 ships), target = the
  final sections/rows JSON (RawSectionBlock shape). The teacher completes/
  normalizes labels; the student imitates. This is standard teacher-student
  distillation — your teacher-provider loop is already wired for it.
- Serve locally: quantize Q4/Q8 via llama.cpp; in-browser via wllama/WebLLM;
  constrain decoding with a JSON grammar (GBNF / json-schema) so the model can
  ONLY emit valid section structures — malformed output becomes impossible, not
  unlikely.
- Cost control: 0.5B Q4 ~= 350MB — ship it as an OPTIONAL on-demand download
  (or via the user's own Ollama), never bundled. The 4KB linear model stays the
  default; the LLM becomes the "max accuracy" mode.

## Boost path 3 — keep the hybrid split of labor (the real secret)

Geometry math (bboxes, rules, table cells) stays deterministic — an LLM is
worse AND slower at exact coordinates. The neural part reads and arbitrates:
header vs sentence, fused Persian openers, semantic typing, junk/furniture
detection. LLM as the semantic brain over the geometric skeleton — not the
geometry detector.

## Forever-loop improvements (any path)

- Every user correction (`src/utils/correctionMemory.ts`) becomes a training
  pair; re-run tinybrain_train.mts periodically.
- Self-consistency: sample k=5 at T=0.8, majority-vote boundaries, keep the
  Platt-calibrated abstention for disagreements.
- Feature upgrades for the linear model (cheap wins now): relative geometry
  (distance to nearest rule/table above), line-cluster embeddings, page-column
  context.
- Contrastive layout pretraining: mask a region, predict its role — free
  supervision from the synthetic generator.
- Guardrails stay fixed: brain_stress.ts (61 assertions), the arbiter contract,
  the drive gate (full confirmation + coverage + marks closure), and
  brain_bridge_report.mts as the corpus regression net.

## The SPECIALIST architecture (chosen direction — NOT a shrunken LLM)

User goal: LLM capabilities + JEV-grade exactness + specialized + tiny.
Do not distill a generic LLM — REMOVE what makes LLMs big. An LLM spends
~99% of its parameters re-learning what words mean; this domain needs only
~200 concepts. So factorize language into a codec and spend the parameters
on STRUCTURE:

1. SEMANTIC CODEC (front-end, 0.3-0.8MB) — a char-level classifier mapping
   every line into a closed ~200-symbol domain alphabet:
   SUBJECT(Vocabulary|Grammar|Listening|...), ROLE(Header|RowOpener|Mark|
   Stem|Option|Furniture|KeyRow|Passage), INSTRUCTION(fill-in|match|mcq|
   cloze|true-false|define|write...), + geometry tokens (size bucket, bold,
   x/y cell, rule/box/table events). Persian + English. Trained from the
   sidecars + pinned GTs + teacher labels.
2. STRUCTURE TRANSFORMER (2-6M params, int8, 2-6MB) — a causal decoder over
   that stream predicting the next structural event (section start, subject,
   row letter, mark, key boundary). THIS is where LLM capabilities live at
   1/100th the size: in-context adaptation (conditions on the document so
   far: "sections numbered 1..18", "letters restart per part"), sequence
   generation with constrained decoding, k-sample voting + calibrated
   abstention.
3. MOE-LITE ROUTER (~0.2MB) — a document-level router over layout families
   (kanoon strip | numeric radif | ruled-table genre | scan genre | key
   sheet), each with a small expert head. Routing receipts stay visible.
   This is the "very light weight MoE" vision, now learned.
4. JEV CONSTITUTION UNCHANGED — the network PROPOSES, deterministic JEV
   DISPOSES: marks closure, letter-ladder continuity, evidence receipts,
   drive gate, stress suite. Hand scorer + model dual-run; disagreements
   are receipted and resolved conservatively (G6 arbiter contract,
   generalized).

Budget: codec 0.3-0.8MB + transformer 2-6MB + router 0.2MB ~= 3-7MB total,
ms-level CPU inference, 100% exam-specific bytes, zero open-world
hallucination surface. It cannot chat and does not know trivia — by design.

Build order (each wave gated): W1 codec + line-role eval on the 47 sidecars
(labels from pinned GTs + brain receipts) -> W2 structure transformer trained
pure-TS (tinybrain_train pattern), shipped as a TS weights blob behind the
same arbiter slot (S26 fail-safe: corrupt weights = current behavior)
-> W3 MoE-lite router + family heads -> W4 ONNX/WebGPU only if profiling
demands it. Every seam already exists in the app: BrainDoc input, arbiter
slot, synthetic generator, teacher loop, correctionMemory, stress suite.
EOF

# --- BUNDLE.md ---
cat > "$STAGE/BUNDLE.md" <<'EOF'
# ExaParse Pro — parser-jev-full-codebase

The FULL code base of the Persian/English school-exam parser (Vite + React 19 +
TS + Express, port 3000) — models code and all — with NO huge data files.
Unzips at project root, mirroring the original workspace 1:1.

## What is inside

- `repo-parser/`            the application: src (incl. the COMPLETE learned
                            brain stack), server, scripts, scripts-batch, data
    - src/utils/layoutBrain.ts      perception -> fusion -> verification brain
    - src/utils/tinyBrain.ts        learned arbiter (28-feature logistic + Platt)
    - src/utils/tinyBrainWeights.ts trained weights (4KB, ships in-app)
    - src/utils/brainBridge.ts      brain -> RawSectionBlock bridge (drive gate)
    - scripts/tinybrain_train.mts   the trainer (dev-side)
    - scripts/tinybrain_teacher.mts DEV-ONLY teacher labeling through the
                            selectable-provider system (YOUR key via env;
                            ollama = local; nothing imports it at runtime)
    - scripts/tinybrain_eval.mts    model/hand behavioral delta + veto probe
    - scripts/brain_stress.ts       61-assertion synthetic layout suite
- `scripts/`                verification suites + graders + python geometry
                            tools (layout_probe.py, extract_geometry.py,
                            build_brain_input.py)
- `samples/mocks/`          20 hand-built mock exams (gate data)
- `scratch/gt*`, `scratch/texts*`   hand-built ground truths + grader texts
- `repo-parser/scratch/tinybrain/train-report.json`   training provenance
- `REGEN.md` / `rebuild-data.sh`    rebuild ALL excluded data from code
- `MODEL_NOTES.md`          the tiny-model -> true-tiny-LLM boost roadmap
- `IMPLEMENTATION_PLAN.md`, `curriculum-digest-v2.json`

## What is NOT inside (by design — rebuild via REGEN.md)

- `samples/qu2/` exam PDFs (64M), `scratch/geo-qu2` (8.2M), `scratch/brain-qu2`
  per-file outputs (8.7M), `scratch/brain-app-qu2` sidecars (3.1M).

## Architecture in one paragraph

Deterministic layout perception (tables, font-size headers, rules, boxes,
letters/numbers, marks) -> evidence FUSION with cross-checks -> a LEARNED,
Platt-calibrated arbiter (the tiny model) over the disagreement tails ->
commit only under the drive gate (full confirmation + coverage >= 60% +
marks closure); otherwise abstain to the proven text splitters with the
reason flagged. Every section carries evidence receipts; every refusal
carries its reason; metadata extraction runs last. The app is LOCAL-FIRST:
parsing + brain are fully offline; remote AI exists only when YOU configure
a provider in Settings (gemini | openai | openrouter | vercel | ollama |
custom — your key), and the dev-only teacher uses that same provider system
from the command line, never at runtime.

## NEW in this bundle — SPECIALIST W1+W2 (the codec and the structure model)

The "tiny model, LLM capabilities, JEV accuracy" architecture is now REAL and
shipped (receipt-only this wave; the deterministic brain still drives):

- W1 SEMANTIC CODEC — src/utils/specialistCodec.ts + specialistCodecWeights.ts
  (65KB): per-line classifier into the closed domain alphabet (14 roles x 9
  subjects), int8 softmax heads over hashed char n-grams + 11 geometric
  features. Distilled from the deterministic perception over the corpus +
  synthetic anchors with graded OCR-style corruption. Distillation fidelity
  97.6% (weak-label CV 90-91%); THE new capability: mangled-text role
  stability 84% ("V0cabulary" -> header_subject at p=1.00) where regexes
  fail. Trainer: scripts/specodec_train.mts; eval: scripts/specodec_eval.mts.
- W2 STRUCTURE TRANSFORMER — src/utils/specialistStructure.ts +
  specialistStructureWeights.ts (140KB): a causal decoder (d=48, 2 layers,
  4 heads, FFN 96, ctx 64, ~101k params) over codec-symbol tokens predicting
  per-line structural events. Trained on codec-PREDICTED tokens (realistic
  pipeline conditions): held-out event accuracy 98.3%, section_start F1
  0.75/row_start F1 0.80 (phase A), full-fit 99.7%/0.97/0.97; mangled
  boundary stability ~90%; runtime-vs-trainer reference drift 5e-6.
  Gradient-checked backward (per-tensor finite-diff probes,
  scripts/specnet_gradcheck.mts). Trainer: scripts/specstruct_train.mts
  (two-phase, checkpointed); eval: scripts/specstruct_eval.mts.
- FAIL-SAFE CONTRACT: both models validate their weight blobs and disable to
  byte-identical deterministic behavior on anything corrupt (stress
  S28-S33, scripts/specialist_stress.ts — green alongside brain_stress 61/61).
- The strict gate is untouched: npm run verify EXIT=0 (30/30 golden + 20/20
  mocks + 6/6 pinned qu2 at 100%, 47/47 accounting).

## Verify gate (single command)

    cd repo-parser
    npm install
    npm run verify

Gate: tsc lint -> 12 feature suites -> goldenCorpus -> strict 30-exam grade ->
strict 20-mock grade -> 20-mock suite -> 6/6 pinned qu2 at 100% -> qu2
scorecard + 47/47 accounting. Strict: any FAIL/SKIP/shrink exits non-zero.
Auxiliary (need regen for corpus inputs): brain_stress (61/61, synthetic —
works immediately), tinybrain_eval, brain_bridge_report.

## Shipped gate results (2026-10-04)

- npm run verify EXIT=0: 30/30 golden + 20/20 mocks + 6/6 pinned qu2 at 100%
  (pq89 59/59, pm57 67/67, pc4i 47/47, p566 26/26, p43266 29/29, p8214 44/44),
  scorecard 6/32, 47/47 corpus accounting.
- brain_stress 61/61 with the model live; tinybrain_eval: 0 drive-posture
  changes, learned furniture veto active; bridge report: brain 1 better /
  0 worse / 31 ties, 6 files at exactly 100%.
EOF

# --- zip ---
cd "$STAGE"
rm -f "$OUT"
zip -qr "$OUT" .
cd "$ROOT"
echo "== bundle built: $OUT"
sha256sum "$OUT"
unzip -l "$OUT" | tail -2
