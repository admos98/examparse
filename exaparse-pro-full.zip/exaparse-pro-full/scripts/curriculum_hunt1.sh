#!/bin/bash
# Round 1: locate authoritative sources for Prospect 1-3 / Vision 1-3
# (official PDFs + per-lesson grammar/vocab lists). Saves JSON per query.
set -u
OUT=/home/z/my-project/scratch/curriculum/search
mkdir -p "$OUT"

run() {
  local id="$1"; local q="$2"
  echo "== $id =="
  z-ai function -n web_search -a "{\"query\": \"$q\", \"num\": 8}" -o "$OUT/$id.json" 2>&1 | tail -1
}

run q01_official_p1 "کتاب زبان انگلیسی هفتم Prospect 1 pdf chap.sch.ir دانلود"
run q02_official_v1 "کتاب زبان انگلیسی دهم Vision 1 pdf chap.sch.ir"
run q03_lessons_p1 "Prospect 1 English grade 7 lessons list My Name My Classmates vocabulary grammar"
run q04_lessons_p2 "Prospect 2 English grade 8 lessons list My Nationality My Week grammar"
run q05_lessons_p3 "Prospect 3 English grade 9 lessons list Personality Travel Media grammar"
run q06_lessons_v1 "Vision 1 English grade 10 lessons list Saving Nature Wonders of Creation"
run q07_lessons_v2 "Vision 2 English grade 11 lessons Understanding People Healthy Lifestyle Art Culture"
run q08_lessons_v3 "Vision 3 English grade 12 lessons Sense of Appreciation Look It Up Renewable Energy"
run q09_grammar_p1 "گرامر زبان انگلیسی هفتم Prospect 1 درس به درس"
run q10_grammar_p2 "گرامر زبان انگلیسی هشتم Prospect 2 درس به درس"
run q11_grammar_p3 "گرامر زبان انگلیسی نهم Prospect 3 درس به درس"
run q12_grammar_v1 "گرامر زبان انگلیسی دهم Vision 1 درس به درس"
run q13_grammar_v2v3 "گرامر زبان انگلیسی یازدهم Vision 2 دوازدهم Vision 3 درس به درس"
run q14_vocab_p1 "لغات کتاب زبان انگلیسی هفتم Prospect 1 درس به درس واژگان"
run q15_vocab_v1 "vocabulary list Vision 1 lesson 1 Saving Nature words"
echo "DONE"
