#!/bin/bash
# Round 2: query chap.sch.ir catalog (plain http) for the six English course
# books, collect book-page links.
set -u
OUT=/home/z/my-project/scratch/curriculum/chap
mkdir -p "$OUT"
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

declare -A Q=(
  [g7]="%D8%A7%D9%86%DA%AF%D9%84%DB%8C%D8%B3%DB%8C%20%D9%87%D9%81%D8%AA%D9%85"          # انگلیسی هفتم
  [g8]="%D8%A7%D9%86%DA%AF%D9%84%DB%8C%D8%B3%DB%8C%20%D9%87%D8%B4%D8%AA%D9%85"          # انگلیسی هشتم
  [g9]="%D8%A7%D9%86%DA%AF%D9%84%DB%8C%D8%B3%DB%8C%20%D9%86%D9%87%D9%85"                # انگلیسی نهم
  [g10]="%D8%A7%D9%86%DA%AF%D9%84%DB%8C%D8%B3%DB%8C%20%DB%B1"                            # انگلیسی ۱
  [g11]="%D8%A7%D9%86%DA%AF%D9%84%DB%8C%D8%B3%DB%8C%20%DB%B2"                            # انگلیسی ۲
  [g12]="%D8%A7%D9%86%DA%AF%D9%84%DB%8C%D8%B3%DB%8C%20%DB%B3"                            # انگلیسی ۳
)

for k in g7 g8 g9 g10 g11 g12; do
  curl -sk -m 30 -A "$UA" -o "$OUT/search_$k.html" \
    -w "search_$k -> %{http_code} size:%{size_download}\n" \
    "http://www.chap.sch.ir/search?keys=${Q[$k]}"
  # harvest book links
  grep -oE '/books/[0-9]+' "$OUT/search_$k.html" 2>/dev/null | sort -u > "$OUT/links_$k.txt" || true
  echo "  links: $(wc -l < "$OUT/links_$k.txt" 2>/dev/null || echo 0)"
  sleep 1
done
echo DONE
