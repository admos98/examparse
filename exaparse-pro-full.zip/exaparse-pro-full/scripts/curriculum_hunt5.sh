#!/bin/bash
# Round 5: targeted searches for direct book-page/PDF URLs (with retry on 429).
set -u
OUT=/home/z/my-project/scratch/curriculum/search
mkdir -p "$OUT"

run() {
  local id="$1"; local q="$2"; local tries=0
  while [ $tries -lt 3 ]; do
    if z-ai function -n web_search -a "{\"query\": \"$q\", \"num\": 8}" -o "$OUT/$id.json" 2>/dev/null; then
      echo "== $id OK"; return 0
    fi
    tries=$((tries+1)); echo "== $id retry $tries (rate-limited)"; sleep 12
  done
  echo "== $id FAILED"
}

run r01_site_p1 "site:chap.sch.ir انگلیسی هفتم Prospect"
run r02_direct_p1 "دانلود pdf کتاب زبان انگلیسی هفتم Prospect 1"
run r03_direct_v1 "دانلود pdf کتاب زبان انگلیسی دهم Vision 1 چاپ و نشر"
run r04_bookpage "chap.sch.ir books انگلیسی Prospect Vision کد کتاب"
run r05_grammar_g7 "زبان انگلیسی هفتم گرامر درس 1 درس 2 درس 3 وب اموز"
run r06_grammar_g10 "زبان انگلیسی دهم گرامر درس اول دوم سوم Vision 1"
sleep 2
echo DONE
