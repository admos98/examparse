#!/bin/bash
# Round 7: find per-lesson grammar/vocab summary pages for all six grades.
set -u
OUT=/home/z/my-project/scratch/curriculum/search

run() {
  local id="$1"; local q="$2"; local tries=0
  while [ $tries -lt 3 ]; do
    if z-ai function -n web_search -a "{\"query\": \"$q\", \"num\": 8}" -o "$OUT/$id.json" 2>/dev/null; then echo "== $id OK"; return 0; fi
    tries=$((tries+1)); sleep 14
  done
  echo "== $id FAILED"
}

run s07_g7_gram "گرامر درس به درس زبان انگلیسی هفتم Prospect 1 خلاصه"
sleep 8
run s08_g8_gram "گرامر درس به درس زبان انگلیسی هشتم Prospect 2 خلاصه"
sleep 8
run s09_g9_gram "گرامر درس به درس زبان انگلیسی نهم Prospect 3"
sleep 8
run s10_g10_gram "گرامر درس به درس زبان انگلیسی دهم Vision 1 درس اول تا سوم"
sleep 8
run s11_g11_gram "گرامر زبان انگلیسی یازدهم Vision 2 درس اول دوم سوم"
sleep 8
run s12_g12_gram "گرامر زبان انگلیسی دوازدهم Vision 3 درس اول دوم سوم"
sleep 8
run s13_vocab_all "لغات زبان انگلیسی دهم یازدهم دوازدهم درس به درس Vision واژگان"
sleep 8
run s14_lessons_titles "فهرست درس های کتاب زبان انگلیسی هفتم هشتم نهم دهم Prospect Vision عنوان درس"
echo DONE
