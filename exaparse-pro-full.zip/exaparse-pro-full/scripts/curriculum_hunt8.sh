#!/bin/bash
# Round 8: DDG per-grade grammar-summary page discovery.
set -u
OUT=/home/z/my-project/scratch/curriculum
mkdir -p "$OUT/ddg"

declare -A Q=(
  [g7]="%D8%AE%D9%84%D8%A7%D8%B5%D9%87+%DA%AF%D8%B1%D8%A7%D9%85%D8%B1+%D8%B2%D8%A8%D8%A7%D9%86+%D8%A7%D9%86%DA%AF%D9%84%DB%8C%D8%B3%DB%8C+%D9%87%D9%81%D8%AA%D9%85+%D8%AF%D8%B1%D8%B3+1+%D8%AA%D8%A7+8"
  [g8]="%D8%AE%D9%84%D8%A7%D8%B5%D9%87+%DA%AF%D8%B1%D8%A7%D9%85%D8%B1+%D8%B2%D8%A8%D8%A7%D9%86+%D8%A7%D9%86%DA%AF%D9%84%DB%8C%D8%B3%DB%8C+%D9%87%D8%B4%D8%AA%D9%85+%D8%AF%D8%B1%D8%B3+1+%D8%AA%D8%A7+7"
  [g9]="%D8%AE%D9%84%D8%A7%D8%B5%D9%87+%DA%AF%D8%B1%D8%A7%D9%85%D8%B1+%D8%B2%D8%A8%D8%A7%D9%86+%D8%A7%D9%86%DA%AF%D9%84%DB%8C%D8%B3%DB%8C+%D9%86%D9%87%D9%85+%D8%AF%D8%B1%D8%B3+1+%D8%AA%D8%A7+6"
  [g10]="%D8%AE%D9%84%D8%A7%D8%B5%D9%87+%DA%AF%D8%B1%D8%A7%D9%85%D8%B1+%D8%B2%D8%A8%D8%A7%D9%86+%D8%A7%D9%86%DA%AF%D9%84%DB%8C%D8%B3%DB%8C+%D8%AF%D9%87%D9%85+%D8%AF%D8%B1%D8%B3+1+%D8%AA%D8%A7+3"
  [g11]="%D8%AE%D9%84%D8%A7%D8%B5%D9%87+%DA%AF%D8%B1%D8%A7%D9%85%D8%B1+%D8%B2%D8%A8%D8%A7%D9%86+%D8%A7%D9%86%DA%AF%D9%84%DB%8C%D8%B3%DB%8C+%DB%8C%D8%A7%D8%B2%D8%AF%D9%87%D9%85+%D8%AF%D8%B1%D8%B3+1+%D8%AA%D8%A7+3"
  [g12]="%D8%AE%D9%84%D8%A7%D8%B5%D9%87+%DA%AF%D8%B1%D8%A7%D9%85%D8%B1+%D8%B2%D8%A8%D8%A7%D9%86+%D8%A7%D9%86%AF%DA%AF%D9%84%DB%8C%D8%B3%DB%8C+%D8%AF%D9%88%D8%A7%D8%B2%D8%AF%D9%87%D9%85+%D8%AF%D8%B1%D8%B3+1+%D8%AA%D8%A7+3"
)

for k in g7 g8 g9 g10 g11 g12; do
  curl -sk -m 25 -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" \
    "https://html.duckduckgo.com/html/?q=${Q[$k]}" -o "$OUT/ddg/$k.html" -w "$k -> %{http_code} size:%{size_download}\n"
  sleep 4
done
echo "--- extract result URLs ---"
python3 - <<'EOF'
import re, urllib.parse, glob, os
for f in sorted(glob.glob('/home/z/my-project/scratch/curriculum/ddg/g*.html')):
    k = os.path.basename(f)[:-5]
    h = open(f, encoding='utf-8', errors='ignore').read()
    urls = []
    for m in re.finditer(r'uddg=([^&]+)', h):
        u = urllib.parse.unquote(m.group(1))
        if u not in urls: urls.append(u)
    print(f"== {k} ==")
    for u in urls[:8]: print('  ', u[:120])
EOF
