#!/bin/bash
# Round 9: slow-paced retry of the six official book pages on chap.sch.ir.
set -u
OUT=/home/z/my-project/scratch/curriculum/chap
BK=/home/z/my-project/scratch/curriculum/books
UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15"
declare -A B=( [g7]=14204 [g8]=14225 [g9]=14245 [g10]=14265 [g11]=14327 [g12]=14372 )
ok=0
for k in g7 g8 g9 g10 g11 g12; do
  id=${B[$k]}
  curl -sk -m 30 --retry 2 --retry-delay 8 -A "$UA" \
    -H "Accept: text/html,application/xhtml+xml" -H "Accept-Language: fa,en" \
    "http://www.chap.sch.ir/books/$id" -o "$OUT/bookpage_$k.html"
  sz=$(stat -c%s "$OUT/bookpage_$k.html" 2>/dev/null || echo 0)
  pdf=$(grep -oE 'href="[^"]*lbooks/[^"]*\.pdf"' "$OUT/bookpage_$k.html" 2>/dev/null | head -1 | sed 's/href="//;s/"$//')
  echo "$k ($id): page=${sz}B pdf=${pdf:-NONE}"
  if [ -n "$pdf" ]; then
    ok=$((ok+1))
    curl -sk -m 180 -A "$UA" -o "$BK/$k.pdf" -w "  DL: %{http_code} %{size_download}B\n" "$pdf"
    sleep 6
  fi
  sleep 7
done
echo "pages_ok=$ok"
