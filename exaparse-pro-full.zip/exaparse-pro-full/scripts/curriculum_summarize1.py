#!/usr/bin/env python3
"""Summarize round-1 search results: top hits per query."""
import json, glob, os

OUT = "/home/z/my-project/scratch/curriculum/search"
for f in sorted(glob.glob(os.path.join(OUT, "*.json"))):
    qid = os.path.basename(f).replace(".json", "")
    try:
        data = json.load(open(f))
    except Exception as e:
        print(f"== {qid}: UNREADABLE ({e})")
        continue
    # CLI output shape: either a list or wrapped object
    items = data if isinstance(data, list) else data.get("data") or data.get("result") or []
    if not isinstance(items, list):
        print(f"== {qid}: unexpected shape {type(items)} keys={list(data)[:8] if isinstance(data, dict) else '?'}")
        continue
    print(f"\n== {qid} ({len(items)} hits) ==")
    for it in items[:6]:
        name = (it.get("name") or "")[:90]
        url = it.get("url") or ""
        snip = (it.get("snippet") or "").replace("\n", " ")[:140]
        print(f"  - {name}\n    {url}\n    {snip}")
