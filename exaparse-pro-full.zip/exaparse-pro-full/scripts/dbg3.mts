const BLANK_RUN = new RegExp('(----|(?:\\.\\s+){2,}\\.|\\.{3,}|_{3,}|…|(?:[\\u2013\\u2014-]\\s+){3,}[\\u2013\\u2014-])');
const stem = 'They have to speak louder, because their grandmother is hard of h - - - - - -.';
console.log('BLANK_RUN spaced-dash:', BLANK_RUN.test(stem));
const raw = JSON.stringify(stem);
console.log(raw);
