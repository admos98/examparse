import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/13991009pq89w65173.pdf.txt', 'utf8');
const doc = parseExamRawText(text, 'f.pdf', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
const s7 = doc.sections.find(s => s.rowId === '7')!;
for (const q of s7.questions) console.log(q.number, q.type, JSON.stringify(q.stem.slice(0, 80)));
const s6 = doc.sections.find(s => s.rowId === '6')!;
console.log('row6 markTotal:', s6.markTotal, 'headerLine:', JSON.stringify(s6.headerLine?.slice(0, 40)));
