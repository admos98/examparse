import fs from 'node:fs';
import path from 'node:path';
import { findKeySheetBoundary, longestLetterHeaderLadder } from '../repo-parser/src/utils/parserEngine';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';
const p = path.join(WS_ROOT, 'samples', 'qu', 'زبان هفتم نوبت اول.docx');
// docx needs extraction — use the cached text from the mocks/golden runner if present
const textDirs = [path.join(WS_ROOT, 'scratch', 'texts'), path.join(WS_ROOT, 'repo-parser', 'scratch', 'texts')];
for (const d of textDirs) {
  if (fs.existsSync(d)) {
    const hit = fs.readdirSync(d).find((f) => f.includes('هفتم نوبت اول') && f.endsWith('.txt'));
    if (hit) {
      const text = fs.readFileSync(path.join(d, hit), 'utf8');
      console.log('text from', d, 'lines', text.split('\n').length);
      const cut = findKeySheetBoundary(text);
      console.log('keyCut at line', cut >= 0 ? text.slice(0, cut).split('\n').length - 1 : -1);
      console.log('letterLadder', longestLetterHeaderLadder(text.split(/\r?\n/)));
      const doc = parseExamRawText(text, hit, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
      for (const s of doc.sections) console.log(`  [${s.rowId}] ${s.majorCategory} mark=${s.markTotal} qs=${s.questions.map((q) => q.number + ':' + q.type).join(' ')}`);
      break;
    }
  }
}
