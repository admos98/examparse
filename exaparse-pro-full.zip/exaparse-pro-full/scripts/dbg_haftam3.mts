import fs from 'node:fs';
import path from 'node:path';
import { extractTextFromDocx } from '../repo-parser/src/utils/fileExtractor';
import { splitRadifNumberedSections } from '../repo-parser/src/utils/parserEngine';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';
const p = path.join(WS_ROOT, 'samples', 'qu', 'زبان هفتم نوبت اول.docx');
const text = await extractTextFromDocx(fs.readFileSync(p).buffer as ArrayBuffer);
const r = splitRadifNumberedSections(text);
if (!r) { console.log('radif: null'); } else {
  for (const b of r) console.log(`[${b.rowId}] mark=${b.mark} first="${b.headerLine.slice(0, 50)}"`);
}
// what bare numbers exist?
const lines = text.split(/\r?\n/);
lines.forEach((l, i) => { const t = l.trim(); if (/^\d{1,2}(\s+\d{1,2})?$/.test(t)) console.log('standalone:', i, JSON.stringify(t)); if (/^\d{1,2}\s+[^\.\):]/.test(t) && !/^\d{1,2}\s+[a-z]/.test(t)) console.log('inline?  :', i, JSON.stringify(t.slice(0, 40))); });
