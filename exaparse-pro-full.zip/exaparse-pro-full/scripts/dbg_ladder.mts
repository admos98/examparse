import fs from 'node:fs';
import path from 'node:path';
import { findKeySheetBoundary } from '../repo-parser/src/utils/parserEngine';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';
for (const f of ['14040316pkc61q4341','14040203p28932i821']) {
  const text = fs.readFileSync(path.join(WS_ROOT, 'scratch', 'texts-qu2', f + '.pdf.txt'), 'utf8');
  const cut = findKeySheetBoundary(text);
  const scan = cut >= 0 ? text.slice(0, cut) : text;
  const lines = scan.split(/\r?\n/);
  const isNum = (l: string) => /^\.?\d{1,2}(?:\s*\/\s*\d{1,2})?(?:[.,]\d{1,2})?$/.test(l.trim());
  const pm = (s: string) => { const t = s.trim(); let m = t.match(/^(\d{1,2})\s*\/\s*(\d{1,2})$/); if (m) return parseFloat(m[2] + '.' + m[1]); m = t.match(/^(\d{1,2})(?:[.,](\d{1,2}))?$/); return m ? parseFloat(m[1] + (m[2] ? '.' + m[2] : '')) : null; };
  const near = (i: number) => { for (let k = Math.max(0,i-2); k <= Math.min(lines.length-1,i+2); k++) if (/صفحه\s+\d+\s+از|^\d+\s*\|\s*P/i.test(lines[k].normalize('NFKC'))) return true; return false; };
  const cands: {line:number; ord:number}[] = [];
  lines.forEach((l, i) => { const t = l.trim(); if (isNum(t)) { const v = pm(t); if (v !== null && Number.isInteger(v) && v >= 1 && v <= 30 && !near(i)) cands.push({line:i, ord:v}); } });
  // LIS
  const bl = cands.map(()=>1), pv = cands.map(()=>-1);
  for (let i=0;i<cands.length;i++) for (let j=0;j<i;j++) if (cands[j].ord < cands[i].ord && bl[j]+1 > bl[i]) { bl[i]=bl[j]+1; pv[i]=j; }
  let tail=0; for (let i=1;i<cands.length;i++) if (bl[i]>bl[tail]) tail=i;
  const lad: number[] = []; for (let i=tail;i>=0;i=pv[i]) lad.unshift(i);
  console.log('==', f, 'ladder len', lad.length);
  console.log(lad.map((i) => `${cands[i].ord}@${cands[i].line}`).join(' '));
}
