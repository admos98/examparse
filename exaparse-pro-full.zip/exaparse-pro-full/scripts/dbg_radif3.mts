import fs from 'node:fs';
import path from 'node:path';
import { findKeySheetBoundary } from '../repo-parser/src/utils/parserEngine';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';
for (const f of ['14040316pkc61q4341','14031114p93s775186','14020228p91294y667','14040203p28932i821']) {
  const text = fs.readFileSync(path.join(WS_ROOT, 'scratch', 'texts-qu2', f + '.pdf.txt'), 'utf8');
  const cut = findKeySheetBoundary(text);
  const scan = cut >= 0 ? text.slice(0, cut) : text;
  const lines = scan.split(/\r?\n/);
  console.log('==', f, '| scanLines:', lines.length, '(cut line', cut >= 0 ? scan.slice(0, cut).split('\n').length - 1 : -1, ')');
  lines.slice(0, 22).forEach((l, i) => console.log(`   ${i}: "${l.trim().slice(0, 60)}"`));
  const standalone = lines.map((l, i) => [i, l.trim()] as const).filter(([, t]) => /^\.?\d{1,2}(?:\s*\/\s*\d{1,2})?(?:[.,]\d{1,2})?$/.test(t));
  console.log('   standalone:', standalone.map(([i, t]) => `${i}:${t}`).join(' '));
}
