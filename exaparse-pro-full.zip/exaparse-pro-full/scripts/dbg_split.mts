import fs from 'node:fs';
import path from 'node:path';
import { findKeySheetBoundary } from '../repo-parser/src/utils/parserEngine';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';
// replicate gates of splitRadifNumberedSections quickly
const files = ['13991009pq89w65173','14020228p53x7md884','14031006pg3866x690','14040316pkc61q4341','14050319p65o69r989','14050320p43266n364','14050401pkhn2yd527','14040131paq214l942','14031114p93s775186','14020406p4t7882699'];
for (const f of files) {
  const text = fs.readFileSync(path.join(WS_ROOT, 'scratch', 'texts-qu2', f + '.pdf.txt'), 'utf8');
  const cut = findKeySheetBoundary(text);
  const scan = cut >= 0 ? text.slice(0, cut) : text;
  const lines = scan.split(/\r?\n/);
  const head = lines.slice(0, 20).map((l) => l.normalize('NFKC').trim());
  const banded = head.some((l) => l === 'ردیف') && head.some((l) => l === 'نمره' || l === 'بارم' || /نمره|بارم/.test(l));
  console.log(f, '| keyCut:', cut >= 0 ? scan.slice(0,cut).split('\n').length-1 : '-', '| banded:', banded, '| head5:', JSON.stringify(head.slice(0,6)));
}
