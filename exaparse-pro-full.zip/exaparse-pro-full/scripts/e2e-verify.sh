#!/usr/bin/env bash
# e2e-verify.sh — 7 tests against the REAL ExaParse server + 6 mock providers.
# Recreated from behavioral spec (original lost in workspace wipe).
set -u
cd "$(dirname "$0")/../repo-parser"   # repo root (explicit; avoids the `cd X && cmd &` trap)

REPO="$(pwd)"
PASS=0; FAIL=0
say()  { printf '\n%s\n' "$*"; }

cleanup() {
  pkill -f "repo-parser/server.ts" 2>/dev/null
  pkill -f "mock-provider.js" 2>/dev/null
  for p in 3000 4601 4602 4603 4604 4605 4607 4608 4609; do fuser -k ${p}/tcp 2>/dev/null >/dev/null; done
}
trap cleanup EXIT
cleanup; sleep 1

mkprovider() { # $1 = mock port
  printf '{"provider":"custom","model":"mock-model","apiKey":"test-key","baseURL":"http://127.0.0.1:%s/v1","temperature":0.2,"maxTokens":1000}' "$1"
}
mkexam() { # $1 = "one" | "two"
  python3 - "$1" <<'PYEOF'
import json, sys
def q(i, n):
    return {"id": i, "number": n, "type": "multiple_choice",
            "stem": f"Choose the correct option for {i}.", "mark": 1,
            "options": [{"id": "a", "text": "opt-a"}, {"id": "b", "text": "opt-b"}]}
if sys.argv[1] == "two":
    exam = {"header": {"courseName": "Mock"}, "sections": [
        {"rowId": "A", "majorCategory": "grammar", "title": "Section A", "questions": [q("q1", 1)]},
        {"rowId": "B", "majorCategory": "vocabulary", "title": "Section B", "questions": [q("qB1", 1)]}],
        "totalQuestions": 2, "totalMarks": 2}
else:
    exam = {"header": {"courseName": "Mock"}, "sections": [
        {"rowId": "A", "majorCategory": "grammar", "title": "Section A",
         "questions": [{"id": "q1", "number": 1, "type": "multiple_choice",
                        "stem": "She ___ to school every day.", "mark": 1,
                        "options": [{"id": "a", "text": "goes"}, {"id": "b", "text": "go"}]}]}],
        "totalQuestions": 1, "totalMarks": 1}
print(json.dumps(exam))
PYEOF
}
enhance() { # $1=examJson $2=port -> prints response body
  python3 -c '
import json,sys
print(json.dumps({"exam":json.loads(sys.argv[1]),"providerConfig":json.loads(sys.argv[2])}))' \
    "$1" "$(mkprovider "$2")" \
  | curl -s --max-time 90 -X POST http://127.0.0.1:3000/api/enhance-exam -H 'Content-Type: application/json' -d @-
}

check() { # $1=name $2=0/1
  if [ "$2" = "1" ]; then PASS=$((PASS+1)); echo "  PASS: $1"; else FAIL=$((FAIL+1)); echo "  FAIL: $1"; fi
}

say "=== starting mocks (4601 empty-first, 4602 parts, 4603 always-empty, 4604 sse, 4605 ping-sse, 4607 raw-empty)"
node "$REPO/../scripts/mock-provider.js" 4601 empty-first   >/tmp/mock1.log 2>&1 &
node "$REPO/../scripts/mock-provider.js" 4602 parts         >/tmp/mock2.log 2>&1 &
node "$REPO/../scripts/mock-provider.js" 4603 always-empty  >/tmp/mock3.log 2>&1 &
node "$REPO/../scripts/mock-provider.js" 4604 sse           >/tmp/mock4.log 2>&1 &
node "$REPO/../scripts/mock-provider.js" 4605 ping-sse      >/tmp/mock5.log 2>&1 &
node "$REPO/../scripts/mock-provider.js" 4607 raw-empty     >/tmp/mock7.log 2>&1 &

say "=== starting real server on :3000"
npx tsx "$REPO/server.ts" >/tmp/server_e2e.log 2>&1 &
for _ in $(seq 1 40); do curl -s -o /dev/null --max-time 2 http://127.0.0.1:3000/ && break; sleep 0.5; done
curl -s -o /dev/null --max-time 2 http://127.0.0.1:3000/ || { echo "SERVER DID NOT START"; tail -20 /tmp/server_e2e.log; exit 1; }
echo "server up"

EXAM1="$(mkexam one)"; EXAM2="$(mkexam two)"

say "TEST 1: empty-first (user's exact bug: 200 OK + empty + finish stop) -> recover on B, honest usage"
B1=$(enhance "$EXAM1" 4601)
R1=$(python3 -c "
import json,sys
try: d=json.loads(sys.argv[1])
except: print(0); raise SystemExit
q=d.get('document',{}).get('sections',[{}])[0].get('questions',[{}])[0]
print(int(d.get('success') is True and d.get('aiSolved')==1 and q.get('correctAnswer')=='a' and d.get('usage',{}).get('totalTokens')==1860))" "$B1")
check "recovered on B + q1='a' + usage 1860 (900 burned + 960 useful)" "$R1"

say "TEST 2: array-of-parts provider -> read natively on attempt A"
B2=$(enhance "$EXAM1" 4602)
R2=$(python3 -c "
import json,sys
d=json.loads(sys.argv[1])
print(int(d.get('aiSolved')==1 and d.get('usage',{}).get('totalTokens')==960))" "$B2")
check "q1='a' on attempt A + usage 960" "$R2"

say "TEST 3: always-empty worst case -> clean failure, deterministic kept, no crash"
B3=$(enhance "$EXAM1" 4603)
R3=$(python3 -c "
import json,sys
d=json.loads(sys.argv[1])
w=' '.join(d.get('warnings',[]))
q=d.get('document',{}).get('sections',[{}])[0].get('questions',[{}])[0]
print(int(d.get('success') is True and d.get('aiSolved')==0 and 'AI was unreachable' in w and q.get('correctAnswer','')==''))" "$B3")
check "success:true, aiSolved:0, unreachable warning, q1 stays empty" "$R3"

say "TEST 4: SSE-on-non-stream provider -> recovered on attempt A, usage 1260"
B4=$(enhance "$EXAM1" 4604)
R4=$(python3 -c "
import json,sys
d=json.loads(sys.argv[1])
print(int(d.get('aiSolved')==1 and d.get('usage',{}).get('totalTokens')==1260))" "$B4")
check "q1='a' + usage 1200in/60out" "$R4"

say "TEST 5: raw-empty provider (200 OK, 0-byte body) -> cause names the empty body"
B5=$(enhance "$EXAM1" 4607)
R5=$(python3 -c "
import json,sys
d=json.loads(sys.argv[1])
w=' '.join(d.get('warnings',[]))
print(int(d.get('success') is True and 'empty body (0 bytes)' in w))" "$B5")
check "success:true + warning contains 'empty body (0 bytes)'" "$R5"

say "TEST 6: /api/test-provider ping against SSE gateway must be ONE wire attempt"
P6=$(curl -s --max-time 60 -X POST http://127.0.0.1:3000/api/test-provider -H 'Content-Type: application/json' \
  -d "{\"providerConfig\":$(mkprovider 4605)}")
H6=$(curl -s http://127.0.0.1:4605/hits)
R6=$(python3 -c "
import json,sys
d=json.loads(sys.argv[1]); h=json.loads(sys.argv[2])
print(int(d.get('ok') is True and h.get('hits')==1))" "$P6" "$H6")
check "ping ok:true + exactly 1 wire attempt on the mock" "$R6"

say "TEST 7: merge matches by ID only — same number in another section must NOT be answered"
B7=$(enhance "$EXAM2" 4602)
R7=$(python3 -c "
import json,sys
d=json.loads(sys.argv[1])
secs=d.get('document',{}).get('sections',[])
a=secs[0]['questions'][0].get('correctAnswer','')
b=secs[1]['questions'][0].get('correctAnswer','')
print(int(a=='a' and b==''))" "$B7")
check "q1(section A)='a' but qB1(same number, section B)=''" "$R7"

say "TEST 8: parse verification rides /api/judge — noul verdicts returned, flag case gets p=0.1, ONE wire call"
node "$REPO/../scripts/mock-provider.js" 4608 verify >/tmp/mock8.log 2>&1 &
for _ in $(seq 1 20); do curl -s -o /dev/null --max-time 2 http://127.0.0.1:4608/hits && break; sleep 0.25; done
VJ=$(python3 - <<PYEOF
import json
state = {
  "exam": {"course": "Mock", "grade": "12"},
  "sheet": {"sections": [{"id": "A", "category": "Vocabulary", "wordBank": ["w1", "w2"], "questions": [
      {"id": "q1", "number": "1", "type": "word_bank_fill", "mark": 1, "stem": "air ...... is bad.", "usesWordBank": True}]}]},
  "source": "raw source text line 1\nraw source text line 2",
}
questions = {
  "h:header": {"type": "noul", "instructions": "header ok?", "criteria": {"true": "y", "false": "n"}},
  "t:q1": {"type": "noul", "instructions": "type ok?", "criteria": {"true": "y", "false": "n"}},
  "s:q1": {"type": "noul", "instructions": "separation ok?", "criteria": {"true": "y", "false": "n"}},
  "m:q1": {"type": "noul", "instructions": "metadata ok?", "criteria": {"true": "y", "false": "n"}},
  "t:q2-flag": {"type": "noul", "instructions": "type ok?", "criteria": {"true": "y", "false": "n"}},
}
print(json.dumps({"state": state, "questions": questions, "jevConfig": {"enabled": False},
                  "providerConfig": $(mkprovider 4608)}))
PYEOF
)
B8=$(echo "$VJ" | curl -s --max-time 90 -X POST http://127.0.0.1:3000/api/judge -H 'Content-Type: application/json' -d @-)
H8=$(curl -s http://127.0.0.1:4608/hits)
R8=$(python3 -c "
import json,sys
d=json.loads(sys.argv[1]); h=json.loads(sys.argv[2])
a=d.get('answers',{})
p_ok  = a.get('t:q1',{}).get('p') == 0.97
p_bad = a.get('t:q2-flag',{}).get('p') == 0.1
print(int(d.get('success') is True and d.get('backend')=='llm-fallback' and p_ok and p_bad and h.get('hits')==1))" "$B8" "$H8")
check "judge returns calibrated nouls (0.97 ok / 0.1 flagged) in exactly 1 wire call" "$R8"

say "TEST 9: /api/vision-batch — index-keyed alts from the mock vision provider, guards hold, ONE wire call"
node "$REPO/../scripts/mock-provider.js" 4609 vision >/tmp/mock9.log 2>&1 &
for _ in $(seq 1 20); do curl -s -o /dev/null --max-time 2 http://127.0.0.1:4609/hits && break; sleep 0.25; done
IMG1=$(printf 'A' | base64); IMG2=$(printf 'B' | base64)
VB=$(python3 -c "
import json,sys
print(json.dumps({'mode':'alts','images':[{'id':'img_1','mimeType':'image/jpeg','data':'$IMG1'},{'id':'img_2','mimeType':'image/jpeg','data':'$IMG2'}],'instruction':'describe','providerConfig':$(mkprovider 4609)}))" )
B9=$(echo "$VB" | curl -s --max-time 90 -X POST http://127.0.0.1:3000/api/vision-batch -H 'Content-Type: application/json' -d @-)
H9=$(curl -s http://127.0.0.1:4609/hits)
G9=$(curl -s -o /dev/null -w '%{http_code}' --max-time 20 -X POST "http://127.0.0.1:3000/api/vision-batch?apiKey=leak" -H 'Content-Type: application/json' -d '{}')
R9=$(python3 -c "
import json,sys
d=json.loads(sys.argv[1]); h=json.loads(sys.argv[2]); guard=int(sys.argv[3])
imgs=d.get('parsed',{}).get('images',{}) if isinstance(d.get('parsed'),dict) else {}
ok_imgs = 'img_1' in imgs and 'img_2' in imgs and imgs.get('img_1',{}).get('alt','').startswith('mock transcription')
print(int(d.get('ok') is True and d.get('usage',{}).get('totalTokens',0)>0 and ok_imgs and h.get('hits')==1 and guard==400))" "$B9" "$H9" "$G9")
check "vision-batch: index-keyed alts for BOTH ids + usage + key-in-URL 400 + exactly 1 wire call" "$R9"

say ""
echo "=== e2e done: $PASS passed, $FAIL failed ==="
[ "$FAIL" = "0" ] || exit 1
