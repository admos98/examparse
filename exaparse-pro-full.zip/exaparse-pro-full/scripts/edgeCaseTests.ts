/**
 * Edge-case regression tests for the parser fixes:
 * 1. All-0.5 explicit marks are NOT re-divided (markIsExplicit).
 * 2. Bare trailing numbers in headers ("Audio 2", "Part 1") are NOT mistaken for section marks.
 * 3. Teacher header extraction works with plain whitespace ("نام دبیر: ...").
 * 4. Question ids are globally unique even with duplicate section letters.
 * 5. cleanAndParseJson recovers fenced/prose-wrapped/trailing-comma JSON.
 */
import { parseExamRawText } from '../parser-repo/src/utils/parserEngine';
import { cleanAndParseJson } from '../parser-repo/src/server/aiProvider';

let failures = 0;
function assert(cond: boolean, msg: string) {
  if (cond) {
    console.log(`  PASS: ${msg}`);
  } else {
    failures++;
    console.error(`  FAIL: ${msg}`);
  }
}

// --- Test 1: explicit 0.5 marks kept, section total = sum of explicit marks ---
console.log('TEST 1: explicit 0.5-mark questions');
const t1 = parseExamRawText(
  `A) Choose the correct answer. (2 marks)
1. She ..... a teacher. (0.5)
a) is b) are c) am d) be
2. They ..... students. (0.5)
a) is b) are c) am d) be
3. He ..... at home. (0.5)
a) is b) are c) am d) be
4. We ..... here. (0.5)
a) is b) are c) am d) be`,
  't1.txt',
);
const t1marks = t1.sections[0].questions.map((q) => q.mark);
assert(t1marks.every((m) => m === 0.5), `every question keeps explicit 0.5 mark (got ${t1marks.join(',')})`);
assert(t1.sections[0].markTotal === 2, `section markTotal equals explicit sum 2.0 (got ${t1.sections[0].markTotal})`);

// --- Test 2: "Audio 2" header is not read as a 2-mark section ---
console.log('TEST 2: bare trailing numbers in headers');
const t2 = parseExamRawText(
  `A) Audio 2
1. Listen and answer. What is her name?
2. Listen and answer. Where does she live?`,
  't2.txt',
);
assert(t2.sections[0].markTotal === 1, `"Audio 2" header does not set section mark to 2 (got ${t2.sections[0].markTotal}; default 1 per question expected)`);
assert(t2.sections[0].questions.length === 2, 'both questions parsed');

// --- Test 3: teacher header with plain spaces ---
console.log('TEST 3: teacher header extraction');
const t3 = parseExamRawText(
  `نام درس: زبان انگلیسی
نام دبیر: احمدی
تاریخ آزمون: 1403/10/15
A) Choose the best answer. (2 marks)
1. Test stem one
a) x b) y c) z d) w
2. Test stem two
a) x b) y c) z d) w`,
  't3.txt',
);
assert(typeof t3.header.teacherName === 'string' && t3.header.teacherName.includes('احمدی'), `teacherName extracted (got ${t3.header.teacherName})`);

// --- Test 4: unique question ids with duplicate section letters ---
console.log('TEST 4: unique question ids');
const t4 = parseExamRawText(
  `A) Choose. (1 mark)
1. First stem
a) p b) q
A) Choose more. (1 mark)
1. Second stem
a) r b) s`,
  't4.txt',
);
const ids = t4.sections.flatMap((s) => s.questions.map((q) => q.id));
assert(new Set(ids).size === ids.length && ids.length > 0, `all ${ids.length} question ids unique: ${ids.join(', ')}`);
const ids2 = Array.from(new Set(Array(50).fill(0).map(() => `exam-${Date.now()}`)));
void ids2;

// --- Test 5: cleanAndParseJson recovery ---
console.log('TEST 5: robust AI JSON parsing');
assert(cleanAndParseJson('```json\n{"a": 1}\n```').a === 1, 'fenced JSON parsed');
assert(cleanAndParseJson('Sure! Here is the JSON: {"a": {"b": [1,2,],},} hope it helps!').a.b.length === 2, 'prose-wrapped + trailing commas recovered');
assert(cleanAndParseJson('{\n  "answer": "it\\u2019s fine",\n}').answer.length > 0, 'smart quotes + trailing comma recovered');

let threw = false;
try {
  cleanAndParseJson('this is not json at all');
} catch {
  threw = true;
}
assert(threw, 'non-JSON garbage throws a clear error');

console.log(failures === 0 ? '\nALL EDGE-CASE TESTS PASSED' : `\n${failures} TEST(S) FAILED`);
process.exit(failures === 0 ? 0 : 1);
