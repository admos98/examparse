#!/usr/bin/env python3
"""Geometry extractor for the layout-first cascade (Wave G1).

Per PDF -> one JSON: pages with
  hlines    : horizontal rules (from line items + thin rects), x/y/width
  rects     : all rectangles (boxes, frames, table borders)
  tables    : ruled tables (PyMuPDF find_tables, lines strategy)
              with cell bboxes + cell text matrix
  textlines : aggregated text lines (text, max font size, bold, bbox)
  images    : image bboxes
Output: <out>/<stem>.json  (one file per PDF, compact)
"""
import fitz, json, os, sys, glob

IN = sys.argv[1] if len(sys.argv) > 1 else "/home/z/my-project/samples/qu2"
OUT = sys.argv[2] if len(sys.argv) > 2 else "/home/z/my-project/repo-parser/scratch/geo-qu2"

def r1(v): return round(float(v), 1)

def extract(path):
    doc = fitz.open(path)
    pages = []
    for page in doc:
        pw, ph = r1(page.rect.width), r1(page.rect.height)
        hlines, rects = [], []
        for d in page.get_drawings():
            try:
                for item in d["items"]:
                    op = item[0]
                    if op == "l":
                        p1, p2 = item[1], item[2]
                        if abs(p1.y - p2.y) <= 1.5:
                            hlines.append([r1(min(p1.x, p2.x)), r1(p1.y), r1(abs(p2.x - p1.x))])
                    elif op == "re":
                        rr = item[1]
                        rects.append([r1(rr.x0), r1(rr.y0), r1(rr.x1), r1(rr.y1)])
                        if rr.height <= 2.0 and rr.width >= 20:
                            hlines.append([r1(rr.x0), r1(rr.y0), r1(rr.width)])
            except Exception:
                continue
        tables = []
        try:
            tf = page.find_tables()
            for t in (tf.tables or []):
                R, C = t.row_count or 0, t.col_count or 0
                if R < 1 or C < 1:
                    continue
                cell_bboxes = [[r1(v) for v in cell] for cell in (t.cells or [])]
                matrix = []
                try:
                    matrix = t.extract() or []
                except Exception:
                    pass
                texts = []
                for row in matrix:
                    texts.append([("" if c is None else str(c).strip()[:300]) for c in row])
                tables.append({
                    "bbox": [r1(v) for v in t.bbox],
                    "rows": R, "cols": C,
                    "cellBboxes": cell_bboxes,
                    "cellTexts": texts,
                })
        except Exception:
            pass
        textlines = []
        try:
            td = page.get_text("dict")
            for b in td.get("blocks", []):
                if b.get("type") != 0:
                    continue
                for l in b.get("lines", []):
                    spans = [s for s in l.get("spans", []) if s.get("text", "").strip()]
                    if not spans:
                        continue
                    text = "".join(s["text"] for s in spans).strip()
                    if not text:
                        continue
                    textlines.append({
                        "text": text[:300],
                        "size": r1(max(s["size"] for s in spans)),
                        "bold": bool(any(s.get("flags", 0) & 16 for s in spans)),
                        "bbox": [r1(v) for v in l["bbox"]],
                    })
        except Exception:
            pass
        images = []
        for im in page.get_images(full=True):
            try:
                images.append([r1(v) for v in page.get_image_bbox(im)])
            except Exception:
                pass
        pages.append({"width": pw, "height": ph, "hlines": hlines, "rects": rects,
                      "tables": tables, "textlines": textlines, "images": images})
    doc.close()
    return {"file": os.path.basename(path), "pages": pages}

def main():
    os.makedirs(OUT, exist_ok=True)
    files = sorted(glob.glob(os.path.join(IN, "*.pdf")))
    ok = err = 0
    for f in files:
        stem = os.path.splitext(os.path.basename(f))[0]
        try:
            data = extract(f)
            with open(os.path.join(OUT, stem + ".json"), "w", encoding="utf-8") as fh:
                json.dump(data, fh, ensure_ascii=False, separators=(",", ":"))
            ntab = sum(len(p["tables"]) for p in data["pages"])
            nlin = sum(len(p["textlines"]) for p in data["pages"])
            nhl = sum(len(p["hlines"]) for p in data["pages"])
            print(f"{stem:32s} pg={len(data['pages']):2d} tbl={ntab:2d} lines={nlin:4d} hlines={nhl:4d}")
            ok += 1
        except Exception as e:
            print(f"{stem:32s} ERROR {e}")
            err += 1
    print(f"\nextracted {ok}/{ok+err} -> {OUT}")

if __name__ == "__main__":
    main()
