# -*- coding: utf-8 -*-
"""Adjudication pass 1: fix MY spec authoring to match the corpus families
I intended to clone (mark/content/letter ordering), not the engine.

- M1, M2 (marks-table clones):  [row#, content..., letter, mark] -> [mark, content..., letter]
- M3, M6, M8, M10 (lettered blocks): [letter, mark, content...] -> [mark, content..., letter]
- M4 (head-anchored clone): insert the 'row mark' table-header anchor line.
M5, M7, M9, M11, M12 stay untouched (genuinely novel variants).
"""
import pprint
import re
import sys

sys.path.insert(0, '/home/z/my-project/scripts')

MARK_RE = re.compile(r'^\(\s*[\d/]+\s*\u0646\u0645\u0631\u0647\s*\($|^\(?[\d.]+\)?$')
LETTER_RE = re.compile(r'^[A-J]$')


def is_letter(l):
    return bool(LETTER_RE.fullmatch(l.strip()))


def is_mark(l):
    s = l.strip()
    return bool(re.fullmatch(r'\(\s*[\d/]+\s*\u0646\u0645\u0631\u0647\s*\(', s)) or bool(re.fullmatch(r'[\d.]+', s))


def fix_letter_mark_first(spec):
    """[letter, mark, content...] -> [mark, content..., letter]"""
    lines = spec['body_lines']
    out = []
    i = 0
    n = len(lines)
    while i < n:
        if is_letter(lines[i]) and i + 1 < n and is_mark(lines[i + 1]):
            letter, mark = lines[i], lines[i + 1]
            j = i + 2
            content = []
            while j < n and not (is_letter(lines[j]) and j + 1 < n and is_mark(lines[j + 1])):
                content.append(lines[j])
                j += 1
            out.extend([mark, *content, letter])
            i = j
        else:
            out.append(lines[i])
            i += 1
    spec['body_lines'] = out


def fix_rownum_table(spec):
    """[row#, content..., letter, mark] -> [mark, content..., letter]"""
    lines = spec['body_lines']
    head, rest = lines[:3], lines[3:]   # بارم / سوالات / ردیف
    out = []
    i = 0
    n = len(rest)
    while i < n:
        if re.fullmatch(r'[\d.]+', rest[i].strip()):
            rownum = rest[i]
            j = i + 1
            content = []
            # content until letter line
            while j < n and not is_letter(rest[j]):
                content.append(rest[j])
                j += 1
            letter = rest[j]
            mark = rest[j + 1]
            assert is_mark(mark), f'unexpected: {letter!r} {mark!r}'
            out.extend([mark, *content, letter])
            i = j + 2
        else:
            out.append(rest[i])
            i += 1
    spec['body_lines'] = head + out


def write_back(path, var_name, specs):
    with open(path, 'w', encoding='utf-8') as f:
        f.write('# -*- coding: utf-8 -*-\n')
        f.write(f'"""Mock specs (auto-normalized by fix_spec_order.py)."""\n\n')
        f.write(f'H7 = \'{H7}\'  # blank ellipsis used across specs\n\n')
        f.write(f'{var_name} = ' + pprint.pformat(specs, width=100, sort_dicts=False) + '\n')


H7 = '\u2026' * 3

from mock_specs_a import SPECS_A  # noqa: E402
from mock_specs_b import SPECS_B  # noqa: E402

if __name__ == '__main__':
    by_file = {s['file']: s for s in SPECS_A + SPECS_B}

    for f in ['mock-01-haftom-payani.docx', 'mock-02-hashthom-mostamar.docx']:
        fix_rownum_table(by_file[f])
        print(f"fixed rownum-table order: {f}")

    for f in ['mock-03-nohom-mostamar.pdf', 'mock-06-nohom-ocr.pdf',
              'mock-08-gozine-farsi.pdf', 'mock-10-motabegh-extra.docx']:
        fix_letter_mark_first(by_file[f])
        print(f"fixed letter-block order: {f}")

    # M4: restore the marks-table header anchor line the family carries
    m4 = by_file['mock-04-dahom-head.pdf']
    if m4['body_lines'][0] != 'row mark':
        m4['body_lines'].insert(0, 'row mark')
        print("inserted 'row mark' anchor: mock-04-dahom-head.pdf")

    # write back normalized specs
    write_back('/home/z/my-project/scripts/mock_specs_a.py', 'SPECS_A', SPECS_A)
    write_back('/home/z/my-project/scripts/mock_specs_b.py', 'SPECS_B', SPECS_B)
    print('spec files rewritten (bodies normalized; GT untouched)')
