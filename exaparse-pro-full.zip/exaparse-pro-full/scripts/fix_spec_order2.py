# -*- coding: utf-8 -*-
"""Adjudication pass 2 (final baseline prep):
1. M2 A: fill_blank -> short_answer  (corpus picture-word family convention)
2. M5: normalize body order to [mark, content..., letter] so the numPr test
   is isolated (ordering bug was masking it)
3. M6 GT A q2: fill_blank -> form_in_parentheses  (the '( go )' cue wins)
"""
import sys
sys.path.insert(0, '/home/z/my-project/scripts')

from fix_spec_order import fix_letter_mark_first, write_back, SPECS_A, SPECS_B

by_file = {s['file']: s for s in SPECS_A + SPECS_B}

# --- 1. M2 A type correction ---
m2 = by_file['mock-02-hashthom-mostamar.docx']
a = m2['gt']['sections'][0]
assert a['id'] == 'A' and a['qs'][0]['t'] == 'fill_blank'
a['qs'][0]['t'] = 'short_answer'
print('1. M2 A -> short_answer')

# --- 2. M5 body order normalization (keeps numpr_idxs semantics: the
#        question-line indexes shift by the same rule) ---
m5 = by_file['mock-05-yazdahom-numpr.docx']
old_body = m5['body_lines']
old_numpr = set(m5['numpr_idxs'])
fix_letter_mark_first(m5)          # [letter, mark, content...] -> [mark, content..., letter]
new_body = m5['body_lines']
# remap numpr indexes: for each old index i (a question line), find its new index
# by tracking the moved lines. The transform moves letter/mark around content
# blocks; simplest reliable way: match by exact line identity is unsafe (dupes),
# so rebuild numpr from the known question lines count pattern instead.
# The 21 numPr lines are the only lines that were numPr'd; recompute their new
# positions with an index mapping walk (stable for unique-enough bodies).
used = set()
new_idx = []
for oi in sorted(old_numpr):
    line = old_body[oi]
    start = 0 if oi == 0 else oi
    # find first unused matching position in new_body
    for k in range(len(new_body)):
        if k in used:
            continue
        if new_body[k] == line:
            new_idx.append(k)
            used.add(k)
            break
    else:
        raise SystemExit(f'cannot remap numpr idx {oi}: {line!r}')
m5['numpr_idxs'] = sorted(new_idx)
assert len(m5['numpr_idxs']) == 21
print('2. M5 body normalized; numpr idxs remapped:', m5['numpr_idxs'][:8], '...')

# --- 3. M6 GT A q2 correction ---
m6 = by_file['mock-06-nohom-ocr.pdf']
secA = m6['gt']['sections'][0]
assert secA['id'] == 'A'
secA['qs'] = [{'n': 1, 't': 'fill_blank'}, {'n': 2, 't': 'form_in_parentheses'}]
print('3. M6 A q2 -> form_in_parentheses')

write_back('/home/z/my-project/scripts/mock_specs_a.py', 'SPECS_A', SPECS_A)
write_back('/home/z/my-project/scripts/mock_specs_b.py', 'SPECS_B', SPECS_B)
print('specs written back')
