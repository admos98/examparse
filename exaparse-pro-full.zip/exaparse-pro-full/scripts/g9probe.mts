import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';

const name = process.argv[2] ?? 'انگلیسی_9_مستمر_یک.docx.txt';
const dir = process.argv[3] ?? 'texts';
const text = fs.readFileSync(path.join(WS_ROOT, 'scratch', dir, name), 'utf8');
const doc = parseExamRawText(text, name, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
for (const s of doc.sections) {
  const marks = s.questions.slice(0, 6).map((q) => q.mark ?? '-');
  const types: Record<string, number> = {};
  for (const q of s.questions) types[q.type] = (types[q.type] ?? 0) + 1;
  console.log(
    `sec id=${s.rowId} cat=${s.category ?? '-'} nq=${s.questions.length} marks=[${marks}] total=${s.totalMarks ?? '-'} types=${JSON.stringify(types)}`
  );
  console.log(`   title=${JSON.stringify((s.title ?? '').slice(0, 60))} instr=${JSON.stringify((s.instruction ?? '').slice(0, 50))}`);
}
console.log('totalMarks(doc)=', doc.totalMarks ?? '-');
