#!/usr/bin/env python3
"""
gen_synth_exams.py — synthetic exam-section generator for TypeNet.

WHY
  2.5k real labeled questions taught a linear model file conventions, not
  semantics (adoption precision ~0). The fix: UNLIMITED on-distribution
  training data. This generator re-renders REAL instruction phrasings
  (harvested from the labeled corpus, label-preserving) with freshly
  generated English/Persian content per question type, emitting one
  mini-exam (text + GT json) per section. The text goes through the SAME
  parseExamRawText path as real data (dump_tinymodel_data.mts with
  SYNTH_* env overrides), so feature parity is guaranteed by construction.

OUTPUT
  scratch/tiny-model/synth/texts/*.txt
  scratch/tiny-model/synth/gt/*.json
"""
import json
import os
import random
import re
import unicodedata

random.seed(20260703)

OUT = '/home/z/my-project/scratch/tiny-model/synth'
REAL = '/home/z/my-project/scratch/tiny-model/dataset.json'

# ------------------------------------------------------------------ banks ---
VERBS = ['go', 'eat', 'write', 'read', 'play', 'study', 'help', 'make', 'take', 'give',
         'come', 'see', 'buy', 'send', 'open', 'close', 'clean', 'cook', 'walk', 'drive',
         'teach', 'learn', 'speak', 'listen', 'watch', 'visit', 'travel', 'work', 'rest', 'call']
NOUNS = ['book', 'school', 'garden', 'mother', 'friend', 'city', 'water', 'bread', 'window', 'teacher',
         'morning', 'night', 'family', 'letter', 'question', 'answer', 'picture', 'story', 'movie', 'road']
ADJS = ['happy', 'tall', 'quick', 'careful', 'busy', 'kind', 'new', 'old', 'good', 'bad',
        'easy', 'hard', 'clean', 'small', 'large', 'long', 'short', 'cold', 'warm', 'bright']
PLACES = ['to school', 'to the park', 'home', 'to the library', 'to the shop', 'to the office',
          'to the hospital', 'to the farm', 'to the bank', 'to the station']
NAMES = ['Ali', 'Sara', 'Reza', 'Maryam', 'John', 'Nima', 'Hana', 'David', 'Sima', 'Omid']
FA_WORDS = ['کتاب', 'مدرسه', 'دوستی', 'خانواده', 'شهر', 'صبح', 'شب', 'معلم', 'دانش آموز', 'کلاس',
            'زنگ تفریح', 'کتابخانه', 'هوای امروز', 'تعطیلات', 'ورزش', 'سلامتی', 'دوستان', 'کوهستان']
FA_SENT = [
    'او هر روز به مدرسه می رود.',
    'من کتاب هایم را مرتب کردم.',
    'آن ها دیروز به سفر رفتند.',
    'ما در حال حاضر درس می خوانیم.',
    'او یک نامه به دوستش نوشت.',
    'هوای امروز بسیار خوب است.',
    'دانش آموزان در کلاس هستند.',
    'من صبح ها پیاده روی می کنم.',
    'او برای امتحان درس می خواند.',
    'ما آخر هفته به پارک رفتیم.',
]

BLANKS = ['………', '……….', '……..', '…….', '--------', '________', '………']
NMARKS = ['{n}. ', '{n}) ', '{n} - ']
LETTERS = 'ABCDEFGHIJKL'

def eng_sentence(verb=None):
    v = verb or random.choice(VERBS)
    n = random.choice(NAMES)
    p = random.choice(PLACES)
    shape = random.choice([
        f'{n} {v}s {p} every day.',
        f'{n} {v}ed {p} yesterday.',
        f'{n} is {v}ing {p} now.',
        f'{n} will {v} {p} tomorrow.',
        f'Did {n} {v} {p} last week?',
        f'{n} does not {v} {p} at night.',
    ])
    return shape

def fa_sentence():
    return random.choice(FA_SENT)

def harmonize(s):
    # mirror the mild presentation-form artifacts real extraction shows
    if random.random() < 0.12:
        s = s.replace('ا', 'ا')
    return s

# phrase pools per type: harvested real instructions + hand extensions.
# Persian pools carry the label semantics; English mirrors them.
POOLS = {
    'multiple_choice': [
        'به نظر شما کدام گزینه صحیح است؟ جواب صحیح را انتخاب کنید',
        'مکالمه زیر را با گزینه های داده شده کامل کنید ( یک گزینه اضافه است )',
        'Choose the correct option',
        'Choose the best option',
        'Read the conversation and choose the correct answer',
        'گزینه صحیح را از بین گزینه های داده شده انتخاب نمایید',
    ],
    'true_false': [
        'با توجه به متن جمله های صحیح و غلط را مشخص کنید (صحیح/غلط)',
        'درستی یا نادرستی جمله های زیر را با توجه به متن مشخص کنید',
        'Read the passage and write (True) or (False)',
        'Decide whether the following sentences are true or false',
        'جمله های زیر را با توجه به متن بخوانید و درست بودن یا نادرست بودن آن ها را مشخص نمایید',
    ],
    'fill_blank': [
        'جملات زیر را با استفاده از دانش زبانی خود کامل کنید',
        'جای خالی را با کلمه مناسب پر کنید',
        'جاهای خالی را با دانستن های خود کامل نمایید',
        'Complete the following sentences with your own knowledge',
        'Fill in the blanks with the correct words',
        'جملات زیر را کامل کنید',
    ],
    'word_bank_fill': [
        'با استفاده از کلمات داده شده جاهای خالی را پر کنید ( یک کلمه اضافه است )',
        'با استفاده از کلمات داخل جعبه جاهای خالی را پر کنید',
        'Fill in the blanks with the given words. (There is one extra word)',
        'Use the words in the box to complete the sentences',
        'کلمات داده شده را در جاهای خالی قرار دهید',
    ],
    'short_answer': [
        'به سوالات زیر پاسخ کوتاه بدهید',
        'به سوالات زیر پاسخ کامل بدهید',
        'Answer the following questions',
        'Answer these questions in short',
        'پاسخ سوالات زیر را بنویسید',
    ],
    'matching': [
        'با توجه به اطلاعات ستون A ستون B را کامل کنید ( یک مورد در ستون B اضافه است )',
        'ستون A را به ستون B وصل کنید',
        'Match column A with column B. (There is one extra option)',
        'Match the items in column A with the suitable items in column B',
        'مطالب ستون A را با ستون B مطابقت دهید',
    ],
    'form_in_parentheses': [
        'شکل صحیح کلمه داخل پرانتز را در جای خالی بنویسید',
        'با نوشتن شکل صحیح کلمات داخل پرانتز جملات را کامل کنید',
        'Write the correct form of the verbs in parentheses',
        'Put in the correct form of the word given in parentheses',
        'شکل صحیح فعل داخل پرانتز را بنویسید',
    ],
    'unscramble': [
        'جملات به هم ریخته زیر را مرتب کنید',
        'کلمات به هم ریخته را مرتب کرده و جمله بسازید',
        'Rearrange the following words to make a correct sentence',
        'Put the words in the correct order',
        'جملات زیر را با توجه به کلمات داده شده مرتب نمایید',
    ],
    'error_correction': [
        'در هر جمله یک قسمت اشتباه است آن را پیدا کرده و شکل صحیح را بنویسید',
        'زیر کلمه اشتباه خط بکشید و شکل صحیح آن را بنویسید',
        'Each sentence has one mistake. Underline it and write the correct form',
        'Find the mistake in each sentence and correct it',
        'جملات زیر اشتباه هستند آن ها را اصلاح کنید',
    ],
    'inline_choice': [
        'شکل صحیح را از داخل پرانتز انتخاب کنید',
        'کلمه صحیح داخل پرانتز را انتخاب نمایید',
        'Choose the correct word from inside the parentheses',
        'Select the right word in parentheses',
    ],
    'cloze_item': [
        'متن زیر را با گزینه های داده شده کامل کنید',
        'Complete the following passage with the given options',
        'متن ناقص زیر را کامل کنید',
    ],
    'odd_one_out': [
        'کلمه ناهماهنگ با سایر کلمات را مشخص کنید',
        'در هر گروه یک کلمه با سایرین متفاوت است آن را پیدا کنید',
        'Which word is different from the others?',
        'Cross out the odd word in each group',
    ],
    'combine_sentences': [
        'دو جمله را با استفاده از کلمات ربط به هم وصل کنید',
        'Combine the following sentences using the words given',
        'جملات زیر را با استفاده از ضمیر موصولی ترکیب کنید',
    ],
    'active_passive': [
        'جملات زیر را به مجهول تغییر دهید',
        'Change the following active sentences into passive',
        'شکل مجهول جملات زیر را بنویسید',
    ],
    'sentence_ordering': [
        'جملات زیر را به ترتیب مناسب مرتب کنید و یک پاراگراف بسازید',
        'Put the following sentences in the correct order to make a paragraph',
    ],
    'letter_reorder': [
        'حروف به هم ریخته را مرتب کنید تا کلمه صحیح ساخته شود',
        'Unscramble the letters to make a word',
    ],
    'phonetic_pronunciation': [
        'تلفظ کدام کلمه با بقیه متفاوت است',
        'Which word has a different final sound?',
        'کدام کلمه از نظر تلفظ با بقیه متفاوت است',
    ],
    'translation': [
        'جملات زیر را به فارسی ترجمه کنید',
        'Translate the following sentences into Persian',
    ],
    'picture_description': [
        'با توجه به تصویر به سوال پاسخ دهید',
        'Answer the question according to the picture',
    ],
    'dialogue_response': [
        'مکالمه زیر را کامل کنید',
        'Complete the following dialogue',
        'پاسخ مناسب برای مکالمه زیر را بنویسید',
    ],
    'long_answer_essay': [
        'درباره موضوع زیر چند جمله بنویسید',
        'Write a short paragraph about the given topic',
        'در مورد موضوع زیر پاراگرافی بنویسید',
    ],
}
CAT_FOR_TYPE = {
    'multiple_choice': ['Vocabulary', 'Grammar'], 'true_false': ['Listening', 'Reading'],
    'fill_blank': ['Grammar', 'Vocabulary', 'Listening'], 'word_bank_fill': ['Vocabulary'],
    'short_answer': ['Reading', 'Listening', 'Writing'], 'matching': ['Vocabulary', 'Reading'],
    'form_in_parentheses': ['Grammar'], 'unscramble': ['Grammar'], 'error_correction': ['Grammar', 'Writing'],
    'inline_choice': ['Grammar'], 'cloze_item': ['Reading', 'Grammar'], 'odd_one_out': ['Vocabulary'],
    'combine_sentences': ['Writing', 'Grammar'], 'active_passive': ['Grammar'],
    'sentence_ordering': ['Writing', 'Reading'], 'letter_reorder': ['Vocabulary'],
    'phonetic_pronunciation': ['Pronunciation', 'Vocabulary'], 'translation': ['Writing'],
    'picture_description': ['Writing', 'Vocabulary'], 'dialogue_response': ['Speaking', 'Listening'],
    'long_answer_essay': ['Writing'],
}

def harvest_real_phrases():
    """Type -> set of real instruction signatures (label-preserving reuse)."""
    ds = json.load(open(REAL, encoding='utf-8'))
    pools = {}
    for s in ds['samples']:
        if not s.get('aligned'):
            continue
        sig = (s['fa'].strip()[:120], s['en'].strip()[:120])
        if not (sig[0] or sig[1]):
            continue
        pools.setdefault(s['gtType'], set()).add(sig)
    out = {}
    for t, sigs in pools.items():
        out[t] = sorted(sigs)
    return out

REAL_POOLS = harvest_real_phrases()
print(f"harvested real instruction signatures: " + ', '.join(f'{k}:{len(v)}' for k, v in sorted(REAL_POOLS.items())))

def pick_instruction(t):
    pool = []
    if t in REAL_POOLS:
        pool.extend(REAL_POOLS[t])
    for p in POOLS.get(t, []):
        pool.append((p, ''))
    if not pool:
        return ''
    fa, en = random.choice(pool)
    # paraphrase jitter: sometimes swap in a hand pool phrase too
    if random.random() < 0.3 and POOLS.get(t):
        p2 = random.choice(POOLS[t])
        if random.random() < 0.5:
            fa = p2 if fa == '' else fa
        else:
            en = p2 if en == '' else en
    return fa, en

# --------------------------------------------------------------- renderers ---
def q_options(n_opts=4):
    letters = ['a', 'b', 'c', 'd', 'e'][:n_opts]
    sep = random.choice([' ', '  '])
    return sep.join(f'{l}) {random.choice(ADJS if random.random() < 0.4 else NOUNS)}' for l in letters)

def render_questions(t, n, start):
    """Return list of question text lines for type t."""
    out = []
    for i in range(start, start + n):
        pre = random.choice(NMARKS).format(n=i)
        if t == 'multiple_choice':
            stem = pre + eng_sentence().rstrip('.') + '.'
            opts = q_options(random.choice([3, 4, 4, 4]))
            if random.random() < 0.6:
                out.append(stem + ' ' + opts)
            else:
                out.append(stem)
                out.append(opts)
        elif t == 'true_false':
            out.append(pre + eng_sentence())
        elif t == 'fill_blank':
            body = eng_sentence()
            words = body.split(' ')
            k = random.randrange(1, max(2, min(4, len(words) - 2)))
            k = min(k, max(1, len(words) - 2))
            pos = random.randrange(1, len(words) - 1)
            for j in random.sample(range(1, len(words) - 1), k):
                words[j] = random.choice(BLANKS)
            out.append(pre + ' '.join(words))
        elif t == 'short_answer':
            out.append(pre + random.choice([
                f'Where does {random.choice(NAMES)} live?',
                f'What does {random.choice(NAMES)} do every morning?',
                f'Why is {random.choice(NAMES)} happy today?',
                f'When did {random.choice(NAMES)} visit {random.choice(PLACES[3:])}?',
                f'How many {random.choice(NOUNS)}s are there in the picture?',
            ]))
        elif t == 'word_bank_fill':
            body = eng_sentence()
            pos = random.randrange(2, len(body.split()) - 1)
            ws = body.split(' ')
            ws[pos] = random.choice(BLANKS)
            out.append(pre + ' '.join(ws))
        elif t == 'matching':
            left = f'{i}. {random.choice(NOUNS)}'
            right = f"{random.choice(LETTERS.lower())}) {random.choice(ADJS)} {random.choice(NOUNS)}"
            out.append(left)
            out.append(right)
        elif t == 'form_in_parentheses':
            v = random.choice(VERBS)
            body = eng_sentence(v).replace(f' {v}s ', f' {BLANKS} ').replace(f' {v}ed ', f' {BLANKS} ')
            out.append(pre + body + f' ({v})')
        elif t == 'unscramble':
            ws = eng_sentence().rstrip('.').split(' ')
            random.shuffle(ws)
            out.append(pre + ' - '.join(ws))
        elif t == 'error_correction':
            v = random.choice(VERBS)
            out.append(pre + f'{random.choice(NAMES)} {v}s to {random.choice(PLACES)} yesterday.')
        elif t == 'inline_choice':
            v1, v2 = random.sample(VERBS, 2)
            out.append(pre + eng_sentence().rstrip('.') + f' ({v1}s / {v2}s).')
        elif t == 'cloze_item':
            out.append(pre + random.choice(BLANKS) + ' ' + fa_sentence() if random.random() < 0.3 else pre + random.choice(BLANKS))
        elif t == 'odd_one_out':
            three = random.sample(ADJS, 3)
            odd = random.choice(NOUNS)
            ws = three + [odd]
            random.shuffle(ws)
            out.append(pre + ', '.join(ws))
        elif t == 'combine_sentences':
            out.append(pre + f'{random.choice(NAMES)} is kind. He helps everyone. (who)')
        elif t == 'active_passive':
            out.append(pre + f'They clean the {random.choice(NOUNS)} every day.')
        elif t == 'sentence_ordering':
            out.append(pre + '[ 1 ] Then he eats breakfast. [ ] He wakes up early. [ ] He goes to work.')
        elif t == 'letter_reorder':
            w = random.choice(NOUNS)
            sc = list(w)
            random.shuffle(sc)
            out.append(pre + ' - '.join(sc))
        elif t == 'phonetic_pronunciation':
            out.append(pre + f'{random.choice(["books", "maps", "boys", "cats"])} / {random.choice(["s", "z"])} /')
        elif t == 'translation':
            out.append(pre + eng_sentence())
        elif t == 'picture_description':
            out.append(pre + f'What can you see in the picture? ({random.choice(NOUNS)})')
        elif t == 'dialogue_response':
            out.append(pre + f'{random.choice(NAMES)}: How are you today? {random.choice(NAMES)}: {BLANKS[0]}')
        elif t == 'long_answer_essay':
            out.append(pre + random.choice(['My best friend', 'My school', 'A rainy day', 'My favorite sport']))
        else:
            out.append(pre + eng_sentence())
    return out

def render_section(idx_letter, cat, t, n, start, fa, en, mark_total):
    lines = []
    header = f'{idx_letter}) {cat} ({mark_total} نمره)' if random.random() < 0.5 else f'{idx_letter}- {cat} - ({mark_total} نمره)'
    lines.append(header)
    inst = []
    if fa:
        inst.append(harmonize(fa))
    if en:
        inst.append(en)
    for ins in inst:
        lines.append(ins + ('.' if not ins.endswith('.') else ''))
    lines.extend(render_questions(t, n, start))
    return lines

def main():
    os.makedirs(os.path.join(OUT, 'texts'), exist_ok=True)
    os.makedirs(os.path.join(OUT, 'gt'), exist_ok=True)
    types = [t for t in POOLS if t in CAT_FOR_TYPE]
    N_EXAMS = 1400
    global_q = 1
    made = 0
    for e in range(N_EXAMS):
        n_sections = random.randint(3, 7)
        sections = []
        qlines = []
        start = global_q
        # furniture
        furniture = [
            'بسمه تعالی', 'تاریخ: ' + f'{random.randint(1,30):02d}/{random.randint(1,12):02d}/140{random.randint(0,4)}',
            'دبیرستان نمونه دولتی ' + random.choice(['شهید مطهری', 'علامه طباطبایی', 'فرزانگان']),
            'مدت امتحان: ' + str(random.choice([60, 70, 80, 90])) + ' دقیقه',
        ]
        header_lines = random.sample(furniture, random.randint(2, 4)) + ['نام و نام خانوادگی: ' + '.' * random.randint(8, 20),
                                                                        'کلاس: ' + random.choice(['دهم', 'یازدهم', 'دوازدهم']) + '  درس: زبان انگلیسی']
        for si in range(n_sections):
            t = random.choice(types)
            n = random.randint(3, 10)
            cat = random.choice(CAT_FOR_TYPE.get(t, ['General']))
            fa, en = pick_instruction(t)
            mark_total = random.choice([1, 1.5, 2, 2, 2.5, 3, 4])
            sec_lines = render_section(LETTERS[si % len(LETTERS)], cat, t, n, start, fa, en, mark_total)
            qlines.extend(sec_lines)
            if random.random() < 0.4:
                qlines.append('--------------------------------------------------------------------------------')
            qs = [{'n': list(range(start, start + n)), 't': t}]
            sections.append({'id': LETTERS[si % len(LETTERS)], 'cat': cat, 'mark': mark_total, 'qs': qs})
            start += n
        text = '\n'.join(header_lines) + '\n\n' + '\n'.join(qlines) + '\n'
        fname = f'synth_{e:05d}.txt'
        with open(os.path.join(OUT, 'texts', fname.replace('.txt', '.pdf.txt')), 'w', encoding='utf-8') as f:
            f.write(text)
        gt = {'file': fname.replace('.txt', '.pdf'), 'header': {'courseName': 'زبان انگلیسی'}, 'totalMarks': sum(s['mark'] for s in sections), 'sections': sections}
        with open(os.path.join(OUT, 'gt', fname.replace('.txt', '.json')), 'w', encoding='utf-8') as f:
            json.dump(gt, f, ensure_ascii=False)
        global_q = start + random.choice([0, 0, 1])  # mostly continuous, occasionally restart
        made += 1
    print(f'generated {made} synthetic exams -> {OUT}')

if __name__ == '__main__':
    main()
