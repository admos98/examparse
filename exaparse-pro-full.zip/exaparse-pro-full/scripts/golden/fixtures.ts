/**
 * Golden Corpus fixtures (#1).
 *
 * Each fixture is a realistic exam text (Persian headers, Iranian school
 * formats, OCR noise) plus hand-verified EXPECTATIONS. The replay gate runs
 * every fixture through the parser on every build and prints per-file
 * accuracy — accuracy can only go up from here.
 *
 * Adding a new real-world format: copy a fixture block, paste the raw text,
 * write the expectations by hand (open the parsed result to read off the
 * values), and it becomes a permanent regression test.
 */

export interface FixtureExpectation {
  totalQuestions: number;
  sections: { rowId: string; count: number }[];
  /** Spot checks on specific questions. */
  spotChecks: {
    sectionRowId: string;
    number: number;
    type?: string;
    stemIncludes?: string;
    optionCount?: number;
    mark?: number;
    hasReceipt?: boolean;
  }[];
  /** When true the rule-table trace must NOT be flagged as fallback. */
  ruleTableShouldWork?: boolean;
}

export interface GoldenFixture {
  name: string;
  description: string;
  text: string;
  expect: FixtureExpectation;
}

export const GOLDEN_FIXTURES: GoldenFixture[] = [
  {
    name: 'grade9-mcq-wordbank',
    description: 'Grade 9 English: Persian header, MCQ section + word bank fill section',
    text: `نام درس: زبان انگلیسی
نام مدرسه: دبیرستان شهید مطهری
مدت آزمون: 60 دقیقه
پایه هفتم

A) Choose the correct answer. (2)

1. The sun ........ in the east.
a) rise
b) rises
c) rising
d) rose

2. My father ........ a car last week.
a) buy
b) buys
c) bought
d) buying

B) Fill in the blanks with the words given. (2)

[careful, pollution, healthy, exercise, dangerous]

3. Air ........ is bad for our health.
4. Eat fruit and vegetables to stay ........
5. ........ makes your body strong.`,
    expect: {
      totalQuestions: 5,
      sections: [
        { rowId: 'A', count: 2 },
        { rowId: 'B', count: 3 },
      ],
      spotChecks: [
        { sectionRowId: 'A', number: 1, type: 'multiple_choice', stemIncludes: 'sun', optionCount: 4 },
        { sectionRowId: 'A', number: 2, stemIncludes: 'father', optionCount: 4 },
        { sectionRowId: 'B', number: 3, stemIncludes: 'Air' },
        { sectionRowId: 'B', number: 4, stemIncludes: 'vegetables' },
      ],
      ruleTableShouldWork: true,
    },
  },
  {
    name: 'persian-options',
    description: 'MCQs with Persian option markers (الف ب ج د) and Persian numerals',
    text: `نام درس: عربی
مدت آزمون: 45 دقیقه

الف) گزینه صحیح را انتخاب کنید. (1)

1. ................ به مدرسه رفت.
الف) علی
ب) علی و حسن
ج) حسن
د) آنها

2. کتاب .............. روی میز است.
الف) آن
ب) این
ج) آنها
د) ما`,
    expect: {
      // The engine preserves Persian section letters as rowIds (fix-7:
      // الف/ب/... are real markers in Iranian exams and must not be remapped
      // to Latin). Hand-verified against the 50-paper corpus behavior.
      totalQuestions: 2,
      sections: [{ rowId: 'الف', count: 2 }],
      spotChecks: [
        { sectionRowId: 'الف', number: 1, optionCount: 4 },
        { sectionRowId: 'الف', number: 2, optionCount: 4 },
      ],
      ruleTableShouldWork: true,
    },
  },
  {
    name: 'ocr-noise-scanned',
    description: 'Messy OCR output: glued markers, l.→1. confusion, noise lines, page marker',
    text: `Page 1
---
l. Acat is ........ animal.
a)an
b) a
c) the
d) ----

2.Thesunis hot.
a) very
b) much
c) many
d) more

| B) Fill in the blanks with the words given. 2

goto school go school goes

3. I ........ to school every day.
4. We ........ to school by bus.`,
    expect: {
      totalQuestions: 4,
      sections: [
        { rowId: 'A', count: 2 },
        { rowId: 'B', count: 2 },
      ],
      spotChecks: [
        { sectionRowId: 'A', number: 1, stemIncludes: 'cat', optionCount: 4 },
        { sectionRowId: 'A', number: 2, stemIncludes: 'sun' },
        { sectionRowId: 'B', number: 3 },
      ],
    },
  },
  {
    name: 'cloze-and-marks',
    description: 'Cloze passage with numbered blanks + explicit per-question marks',
    text: `C) Cloze Test. Read the following passage and fill in the blanks. (3)

Cloze Passage (C)
The internet is one of the most important inventions of the modern age. It has changed the way we live, work and communicate with each other around the world.

21. The internet has changed the way we ........
a) live
b) sleep
c) walk (1)

22. The passage is about the ........
a) internet
b) radio
c) newspaper (1)

D) Vocabulary. (2)

23. She ........ her homework before dinner. (0.5)
24. They ........ football on Fridays. (0.5)`,
    expect: {
      totalQuestions: 4,
      sections: [
        { rowId: 'C', count: 2 },
        { rowId: 'D', count: 2 },
      ],
      spotChecks: [
        { sectionRowId: 'C', number: 21, stemIncludes: 'internet' },
        { sectionRowId: 'D', number: 23, mark: 0.5 },
      ],
    },
  },
  {
    name: 'dual-numbering',
    description: 'Dual page/question numbering "34. 58." + true/false section',
    text: `E) Grammar. (2)

34. 58. The teacher ........ us English since last year.
a) teaches
b) has taught
c) taught
d) teaching

35. 59. Open your books ......... page twenty.
a) in
b) at
c) on
d) to

F) True or False. (1)

60. The Earth goes around the Sun. True / False
61. Water boils at 50 degrees. True / False`,
    expect: {
      totalQuestions: 4,
      sections: [
        { rowId: 'E', count: 2 },
        { rowId: 'F', count: 2 },
      ],
      spotChecks: [
        { sectionRowId: 'E', number: 58, stemIncludes: 'teacher' },
        { sectionRowId: 'F', number: 60, type: 'true_false' },
      ],
    },
  },
  {
    name: 'inline-choice',
    description: 'Inline choices and form-in-parentheses',
    text: `G) Grammar. (2)

30. My brother ........( don't / doesn't ) like fast food.
31. Ali ........ to music every night. (listen)
32. They ........ football now. (play)`,
    expect: {
      totalQuestions: 3,
      sections: [{ rowId: 'G', count: 3 }],
      spotChecks: [
        { sectionRowId: 'G', number: 30, optionCount: 2 },
        { sectionRowId: 'G', number: 31, type: 'form_in_parentheses' },
      ],
    },
  },
];
