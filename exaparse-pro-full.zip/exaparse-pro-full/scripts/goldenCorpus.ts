/**
 * Golden Corpus Replay Gate (#1) + Round-trip & Fuzz suite (#4).
 *
 *   1. REPLAY      — every fixture is parsed and compared to hand-verified
 *                    expectations. Per-fixture accuracy is printed; any
 *                    regression fails the build.
 *   2. DETERMINISM — parsing the same text twice must give the same id and
 *                    the same structural fingerprint (#5).
 *   3. IDEMPOTENCE — serialize(parse(t)) re-parsed must equal parse(t) (#4).
 *   4. FUZZ        — mutated inputs must either parse consistently or RAISE
 *                    a flag. A silent mis-parse (wrong question count with a
 *                    clean report) is the cardinal sin and fails the build.
 *
 * Run: npx tsx scripts/goldenCorpus.ts   (or: npm run corpus)
 */

import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
import { serializeExamToText, structuralFingerprint, diffStructures } from '../repo-parser/src/utils/examSerializer';
import { computeTrust } from '../repo-parser/src/utils/trustEngine';
import { GOLDEN_FIXTURES, GoldenFixture } from './golden/fixtures';
import { ExamDocument } from '../repo-parser/src/types/exam';

// ---------------------------------------------------------------------------
// Deterministic PRNG for reproducible fuzzing
// ---------------------------------------------------------------------------

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface FuzzMutation {
  name: string;
  apply: (lines: string[], rnd: () => number) => string[];
}

const MUTATIONS: FuzzMutation[] = [
  {
    name: 'line-swap',
    apply: (lines, rnd) => {
      const next = [...lines];
      if (next.length < 3) return next;
      const i = Math.floor(rnd() * (next.length - 2));
      [next[i], next[i + 1]] = [next[i + 1], next[i]];
      return next;
    },
  },
  {
    name: 'line-delete',
    apply: (lines, rnd) => {
      if (lines.length < 4) return lines;
      const i = Math.floor(rnd() * lines.length);
      return lines.filter((_, k) => k !== i);
    },
  },
  {
    name: 'line-duplicate',
    apply: (lines, rnd) => {
      const i = Math.floor(rnd() * lines.length);
      const next = [...lines];
      next.splice(i, 0, lines[i]);
      return next;
    },
  },
  {
    name: 'bidi-injection',
    apply: (lines) => lines.map((l) => (l.length > 5 ? '\u200F' + l + '\u200E' : l)),
  },
  {
    name: 'eastern-digits',
    apply: (lines) =>
      lines.map((l) =>
        l.replace(/\d/g, (d) => String.fromCharCode(0x06f0 + parseInt(d, 10))),
      ),
  },
  {
    name: 'space-collapse',
    apply: (lines) => lines.map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean),
  },
];

// ---------------------------------------------------------------------------

interface FixtureResult {
  name: string;
  checks: number;
  passed: number;
  failures: string[];
  doc: ExamDocument;
}

function checkOne(desc: string, cond: boolean, failures: string[]): void {
  if (!cond) failures.push(desc);
}

function replayFixture(fixture: GoldenFixture): FixtureResult {
  const failures: string[] = [];
  let checks = 0;
  const passed = () => checks++;

  const doc = parseExamRawText(fixture.text, `${fixture.name}.txt`);
  passed(); // parse itself completed

  // 1. total questions
  checks++;
  if (doc.totalQuestions !== fixture.expect.totalQuestions) {
    failures.push(`totalQuestions: expected ${fixture.expect.totalQuestions}, got ${doc.totalQuestions}`);
  } else passed();

  // 2. section counts
  for (const secExp of fixture.expect.sections) {
    checks++;
    const sec = doc.sections.find((s) => s.rowId === secExp.rowId);
    if (!sec) {
      failures.push(`section ${secExp.rowId}: missing (have ${doc.sections.map((s) => s.rowId).join(',')})`);
    } else if (sec.questions.length !== secExp.count) {
      failures.push(`section ${secExp.rowId}: expected ${secExp.count} questions, got ${sec.questions.length}`);
    } else passed();
  }

  // 3. spot checks
  for (const spot of fixture.expect.spotChecks) {
    const sec = doc.sections.find((s) => s.rowId === spot.sectionRowId);
    const q = sec?.questions.find((x) => Number(x.number) === spot.number);
    checks++;
    if (!q) {
      failures.push(`spot ${spot.sectionRowId}/${spot.number}: question not found`);
      continue;
    }
    passed();
    if (spot.type) {
      checks++;
      if (q.type !== spot.type) failures.push(`spot ${spot.number}: type expected ${spot.type}, got ${q.type}`);
      else passed();
    }
    if (spot.stemIncludes) {
      checks++;
      const stemNorm = (q.stem || '').toLowerCase().replace(/\s+/g, ' ');
      if (!stemNorm.includes(spot.stemIncludes.toLowerCase())) {
        failures.push(`spot ${spot.number}: stem "${q.stem?.slice(0, 60)}" lacks "${spot.stemIncludes}"`);
      } else passed();
    }
    if (spot.optionCount !== undefined) {
      checks++;
      if ((q.options?.length || 0) !== spot.optionCount) {
        failures.push(`spot ${spot.number}: options expected ${spot.optionCount}, got ${q.options?.length || 0}`);
      } else passed();
    }
    if (spot.mark !== undefined) {
      checks++;
      if (Math.abs(q.mark - spot.mark) > 0.001) failures.push(`spot ${spot.number}: mark expected ${spot.mark}, got ${q.mark}`);
      else passed();
    }
    if (spot.hasReceipt) {
      checks++;
      if (!q.receipt) failures.push(`spot ${spot.number}: missing parse receipt`);
      else passed();
    }
  }

  // 4. rule table engagement
  if (fixture.expect.ruleTableShouldWork) {
    checks++;
    if (doc.parseTrace?.fallbackUsed) {
      failures.push('rule table fell back to the legacy scanner (trace.fallbackUsed=true)');
    } else passed();
  }

  // 5. receipts exist for rule-table parses
  checks++;
  const withReceipt = doc.sections.flatMap((s) => s.questions).filter((q) => q.receipt).length;
  if (!doc.parseTrace?.fallbackUsed && withReceipt === 0 && doc.totalQuestions > 0) {
    failures.push(`no receipts on any question (rule-table path)`);
  } else passed();

  // 6. trust computable
  try {
    const trust = computeTrust(doc);
    checks++;
    if (trust.summary.total !== doc.totalQuestions) {
      failures.push(`trust total ${trust.summary.total} != questions ${doc.totalQuestions}`);
    } else passed();
  } catch (e: any) {
    checks++;
    failures.push(`trust computation threw: ${e?.message}`);
  }

  return { name: fixture.name, checks, passed: checks - failures.length, failures, doc };
}

function runDeterminism(fixture: GoldenFixture, doc: ExamDocument): string[] {
  const failures: string[] = [];
  const again = parseExamRawText(fixture.text, `${fixture.name}.txt`);
  if (again.id !== doc.id) failures.push(`determinism: id differs between runs (${doc.id} vs ${again.id})`);
  if (structuralFingerprint(again) !== structuralFingerprint(doc)) failures.push('determinism: structural fingerprint differs between runs');
  return failures;
}

function runIdempotence(fixture: GoldenFixture, doc: ExamDocument): string[] {
  const failures: string[] = [];
  if (doc.totalQuestions === 0) return failures; // nothing to round-trip
  const serialized = serializeExamToText(doc);
  const reparsed = parseExamRawText(serialized, `${fixture.name}-roundtrip.txt`);
  const diffs = diffStructures(doc, reparsed);
  if (diffs.length > 0) {
    failures.push(`round-trip diverged: ${diffs[0]}${diffs.length > 1 ? ` (+${diffs.length - 1} more)` : ''}`);
  }
  return failures;
}

function runFuzz(fixture: GoldenFixture, doc: ExamDocument): string[] {
  const failures: string[] = [];
  const rnd = mulberry32(42);
  const originalLines = fixture.text.split(/\r?\n/);

  for (const mutation of MUTATIONS) {
    for (let trial = 0; trial < 3; trial++) {
      const mutatedLines = mutation.apply(originalLines, rnd);
      const mutatedText = mutatedLines.join('\n');
      let mutant: ExamDocument | null = null;
      try {
        mutant = parseExamRawText(mutatedText, `${fixture.name}-fuzz.txt`);
      } catch (e: any) {
        failures.push(`fuzz[${mutation.name}#${trial}]: parser THREW — ${e?.message}`);
        continue;
      }
      if (!mutant) {
        failures.push(`fuzz[${mutation.name}#${trial}]: parser returned null`);
        continue;
      }

      // The cardinal sin: silent mis-parse. If the question count moved, the
      // parser MUST have raised a flag (needsReview, error/warning anomaly,
      // or a validation flag).
      // EXCEPTION: 'line-delete' can legitimately remove a question — the
      // parser cannot flag what it never saw. Every information-preserving
      // mutation (swap/duplicate/bidi/digits/space) must hold the line.
      const countMoved = Math.abs(mutant.totalQuestions - doc.totalQuestions) > 0;
      const flaggable = mutation.name !== 'line-delete';
      const flagged =
        mutant.needsReview === true ||
        (mutant.anomalies || []).some((a) => !a.isResolved && a.severity !== 'info') ||
        (mutant.validationFlags || []).length > 0;
      if (countMoved && flaggable && !flagged) {
        failures.push(
          `fuzz[${mutation.name}#${trial}]: SILENT MIS-PARSE — questions ${doc.totalQuestions} -> ${mutant.totalQuestions} with no flags`,
        );
      }
    }
  }
  return failures;
}

// ---------------------------------------------------------------------------

async function main() {
  console.log('═'.repeat(78));
  console.log(' GOLDEN CORPUS REPLAY GATE — ExaParse Pro bulletproofing round');
  console.log('═'.repeat(78));

  let totalChecks = 0;
  let totalPassed = 0;
  const allFailures: string[] = [];

  for (const fixture of GOLDEN_FIXTURES) {
    const res = replayFixture(fixture);
    const detFail = runDeterminism(fixture, res.doc);
    const idemFail = runIdempotence(fixture, res.doc);
    const fuzzFail = runFuzz(fixture, res.doc);
    const failures = [...res.failures, ...detFail, ...idemFail, ...fuzzFail];

    const trust = computeTrust(res.doc);
    const checks = res.checks + detFail.length * 0 + 2 + 6 * 3; // approx display value
    totalChecks += res.checks + 2 + 18;
    totalPassed += res.passed + 2 + 18 - (detFail.length + idemFail.length + fuzzFail.length);
    allFailures.push(...failures.map((f) => `[${fixture.name}] ${f}`));

    const pct = Math.round((res.passed / Math.max(res.checks, 1)) * 100);
    const status = failures.length === 0 ? 'PASS' : 'FAIL';
    console.log(
      `${status}  ${fixture.name.padEnd(22)} structure ${String(pct).padStart(3)}%  ` +
        `Q=${res.doc.totalQuestions}  id=${res.doc.id.slice(5, 15)}  ` +
        `trust=${trust.summary.verified}/${trust.summary.total} verified  ` +
        `det/idem/fuzz=${detFail.length}/${idemFail.length}/${fuzzFail.length} problems`,
    );
    if (fixture.description) console.log(`      ${fixture.description}`);
    for (const f of failures) console.log(`      ✗ ${f}`);
  }

  console.log('─'.repeat(78));
  console.log(` Fixtures: ${GOLDEN_FIXTURES.length}   Checks passed: ${totalPassed}/${totalChecks}`);
  if (allFailures.length > 0) {
    console.log(`\n ❌ ${allFailures.length} FAILURE(S):`);
    for (const f of allFailures) console.log(`   - ${f}`);
    process.exit(1);
  } else {
    console.log('\n ✅ ALL GREEN — accuracy is monotonic. No regressions, no silent mis-parses.');
  }
}

main().catch((e) => {
  console.error('Golden corpus runner crashed:', e);
  process.exit(1);
});
