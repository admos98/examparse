#!/usr/bin/env python3
"""GT-assist: structural skeleton of an extracted exam text for hand GT building."""
import re, sys, json, os

TEXT_DIR = '/home/z/my-project/scratch/texts-qu2'

def is_qstart(line):
    m = re.match(r'^\s*(\d{1,3})\s*[\.\)]\s*(\S.*)$', line)
    if m:
        return int(m.group(1)), m.group(2)
    m = re.match(r'^\s*(\d{1,3})\s\s+(\S.*)$', line)  # number + 2+ spaces, no dot
    if m:
        return int(m.group(1)), m.group(2)
    return None

def skeleton(name):
    src = os.path.join(TEXT_DIR, name + '.txt')
    if not os.path.exists(src):
        src = os.path.join(TEXT_DIR, name + '.pdf.txt')
    t = open(src, encoding='utf-8').read()
    lines = t.split('\n')
    out = []
    out.append(f'##### {name} ({len(lines)} lines)')
    # header: first 8 non-empty lines
    ne = [(i, l) for i, l in enumerate(lines, 1) if l.strip()]
    out.append('-- HEADER (first 8):')
    for i, l in ne[:8]:
        out.append(f'{i:4d}| {l[:150]}')
    key_at = None
    for i, l in enumerate(lines, 1):
        if 'راهنمای تصحیح' in l or 'راﻫﻨﻤﺎی ﺗﺼﺤﯿﺢ' in l:
            key_at = i
            break
    out.append(f'-- KEY REGION: {"line " + str(key_at) if key_at else "none"}')
    # isolated numbers (possible marks / page numbers)
    out.append('-- ISOLATED NUMBERS:')
    for i, l in enumerate(lines, 1):
        s = l.strip()
        if re.fullmatch(r'\d{1,3}(\s*/\s*\d{1,3})?', s) and key_at is None or \
           (re.fullmatch(r'\d{1,3}(\s*/\s*\d{1,3})?', s) and key_at is not None and i < key_at):
            out.append(f'{i:4d}| [{s}]')
    # section row candidates: number + optional category word
    out.append('-- SECTION ROW CANDIDATES:')
    for i, l in enumerate(lines, 1):
        if key_at is not None and i >= key_at:
            break
        s = l.strip()
        m = re.match(r'^(\d{1,2})\s+(.*)$', s)
        if m and len(s) < 90:
            body = m.group(2)
            if re.search(r'Listening|Vocabul|Gramm|Reading|Writ|ocabul|istening|rammar|eading|riting', body, re.I):
                out.append(f'{i:4d}| ROW? {s}')
    # question starts
    out.append('-- QUESTIONS:')
    prev_num = 0
    for i, l in enumerate(lines, 1):
        if key_at is not None and i >= key_at:
            break
        s = l.strip()
        if not s:
            continue
        qs = is_qstart(l)
        if qs:
            num, body = qs
            cues = []
            if re.search(r'\ba[\)\.]\s|b[\)\.]\s|c[\)\.]\s|d[\)\.]\s|\ba\s\.\s|\(\s*a\s*\)', s): cues.append('OPT')
            if re.search(r'True\s*b|True\s*/\s*False|a\)\s*True|\(\s*a\s*\)\s*True', s, re.I): cues.append('TF')
            if '……' in s or '....' in s or '---' in s: cues.append('BLANK')
            if re.search(r'\(\s*\w+\s*\)\s*$|\(\s*\w+\s*\)\s*[\.…]', s): cues.append('PAREN')
            flag = f" <<{','.join(cues)}" if cues else ''
            out.append(f'{i:4d}| q{num}{flag}: {body[:100]}')
    # key region content (first 25 lines)
    if key_at:
        out.append('-- KEY CONTENT (first 25):')
        cnt = 0
        for i, l in enumerate(lines[key_at:], key_at):
            if l.strip():
                out.append(f'{i:4d}| {l[:130]}')
                cnt += 1
                if cnt >= 25:
                    break
    return '\n'.join(out)

if __name__ == '__main__':
    names = sys.argv[1:]
    if not names:
        cls = json.load(open('/home/z/my-project/scratch/qu2-classify.json'))
        names = cls['real']
    for n in names:
        print(skeleton(n))
        print()
