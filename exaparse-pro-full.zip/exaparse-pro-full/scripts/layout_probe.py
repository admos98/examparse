#!/usr/bin/env python3
"""Layout-cascade feasibility probe over the qu2 exam corpus.

Measures, per PDF, the raw geometric signals the proposed layout-first
cascade would rely on (user proposal: tables first, then font-size
headers, then half/full rules, then boxes; text heuristics last):

  T0  text layer: absent (scan) / garbled-suspect (CMap)
  T1  ruled tables (find_tables, strategy=lines) usable as section separators
      - section_table : few cells (<=24) with substantial text (>=300 chars)
      - grid_table    : many small cells (MCQ bubble grids etc.)
  T2  font-size clusters: lines printed LARGER than the body mode size
      T2b             : printed subject-keyword headers (same size)
  T3  horizontal rules (full-width / half-width)
  T4  boxes / rects (frames, word boxes, matching layouts)
  T5  none of the above -> plain text (current engine territory)

Output: JSON report + printed coverage table.
"""
import fitz, json, os, glob, sys
from collections import Counter

CORPUS = sys.argv[1] if len(sys.argv) > 1 else "/home/z/my-project/repo-parser/samples/qu2"
OUT = sys.argv[2] if len(sys.argv) > 2 else "/home/z/my-project/repo-parser/scratch/layout-probe/report.json"

PERSIAN_RANGES = (('\u0600', '\u06FF'), ('\uFB50', '\uFDFF'), ('\uFE70', '\uFEFF'))

def is_persian(ch):
    return any(lo <= ch <= hi for lo, hi in PERSIAN_RANGES)

KEYWORDS = ['واژگان', 'دستور', 'مکالمه', 'شنیداری', 'گفتاری', 'درک مطلب',
            'نوشتاری', 'نوشتار', 'تلفظ', 'قواعد', 'لغت',
            'Vocabulary', 'Grammar', 'Listening', 'Speaking', 'Reading',
            'Writing', 'Pronunciation', 'Conversation', 'Language Function']

def analyze(path):
    r = {"file": os.path.basename(path), "size_kb": round(os.path.getsize(path) / 1024)}
    try:
        doc = fitz.open(path)
    except Exception as e:
        r["error"] = str(e)
        return r
    if doc.needs_pass:
        r["error"] = "encrypted"
        doc.close()
        return r
    r["pages"] = doc.page_count
    text_chars = persian_chars = 0
    size_hist = Counter()
    bold_chars = 0
    full_rules = half_rules = 0
    rects = curves = drawings_total = 0
    section_tables = grid_tables = 0
    section_table_chars = 0
    images = 0
    header_lines = []          # (size, bold, text) of short lines
    keyword_lines = 0
    strong_cue_lines = 0       # keyword header lines that are ALSO big or bold
    for page in doc:
        try:
            images += len(page.get_images(full=True))
            dr = page.get_drawings()
            drawings_total += len(dr)
            pw = page.rect.width or 595
            for d in dr:
                for item in d["items"]:
                    op = item[0]
                    if op == "l":
                        p1, p2 = item[1], item[2]
                        if abs(p1.y - p2.y) <= 1.5:
                            ln = abs(p2.x - p1.x)
                            if ln >= 0.5 * pw: full_rules += 1
                            elif ln >= 0.2 * pw: half_rules += 1
                    elif op == "re":
                        rr = item[1]
                        rects += 1
                        if rr.height <= 2.0:
                            if rr.width >= 0.5 * pw: full_rules += 1
                            elif rr.width >= 0.2 * pw: half_rules += 1
                    elif op == "c":
                        curves += 1
            # ruled tables (PyMuPDF "lines" strategy default)
            try:
                tf = page.find_tables()
                for t in (tf.tables or []):
                    rc, cc = t.row_count or 0, t.col_count or 0
                    if rc < 1 or cc < 1:
                        continue
                    cells = rc * cc
                    chars = 0
                    try:
                        ext = t.extract()
                        for row in ext:
                            for c in row:
                                if c: chars += len(str(c).strip())
                    except Exception:
                        pass
                    if 2 <= cells <= 24 and chars >= 300:
                        section_tables += 1
                        section_table_chars += chars
                    elif cells > 8:
                        grid_tables += 1
            except Exception:
                pass
            # text spans
            td = page.get_text("dict")
            for b in td.get("blocks", []):
                if b.get("type") != 0:
                    continue
                for l in b.get("lines", []):
                    spans = [s for s in l.get("spans", []) if s.get("text", "").strip()]
                    if not spans:
                        continue
                    line_text = "".join(s["text"] for s in spans).strip()
                    text_chars += len(line_text)
                    persian_chars += sum(1 for ch in line_text if is_persian(ch))
                    mx = max(s["size"] for s in spans)
                    bold = any(s.get("flags", 0) & 16 for s in spans)
                    for s in spans:
                        t = s["text"].strip()
                        if t:
                            size_hist[round(s["size"], 1)] += len(t)
                            if s.get("flags", 0) & 16:
                                bold_chars += len(t)
                    if len(line_text) <= 60:
                        header_lines.append((round(mx, 1), bold, line_text))
                        low = line_text
                        if any(k in low for k in KEYWORDS):
                            keyword_lines += 1
                            if bold or mx >= (max(size_hist.items(), key=lambda kv: kv[1])[0] if size_hist else 0) * 1.1:
                                strong_cue_lines += 1
        except Exception:
            continue
    total = sum(size_hist.values()) or 1
    sig_sizes = {sz: c for sz, c in size_hist.items() if c >= 0.01 * total}
    body_mode = max(size_hist.items(), key=lambda kv: kv[1])[0] if size_hist else 0
    big = [(sz, bo, tx) for (sz, bo, tx) in header_lines if body_mode and sz >= body_mode * 1.12]
    r.update({
        "text_chars": text_chars,
        "persian_ratio": round(persian_chars / text_chars, 3) if text_chars else 0.0,
        "images": images,
        "drawings": drawings_total,
        "rects": rects,
        "curves": curves,
        "full_rules": full_rules,
        "half_rules": half_rules,
        "section_tables": section_tables,
        "section_table_chars": section_table_chars,
        "grid_tables": grid_tables,
        "distinct_sizes": len(sig_sizes),
        "top_sizes": sorted(sig_sizes.items(), key=lambda kv: -kv[1])[:4],
        "body_size": body_mode,
        "bigfont_short_lines": len(big),
        "sample_big_lines": [tx[:38] for _, _, tx in big[:5]],
        "keyword_header_lines": keyword_lines,
        "strong_cue_lines": strong_cue_lines,
        "bold_ratio": round(bold_chars / total, 3) if total else 0.0,
    })
    r["has_text_layer"] = text_chars >= 100
    r["garbled_suspect"] = r["has_text_layer"] and r["persian_ratio"] < 0.03
    r["t1_table"] = section_tables >= 1
    r["t2_fontsize"] = r["distinct_sizes"] >= 3 and len(big) >= 3
    r["t2b_keywords"] = keyword_lines >= 2
    r["t3_rules"] = (full_rules + half_rules) >= 2
    r["t4_boxes"] = rects >= 6
    if not r["has_text_layer"]:
        r["tier"] = "T0_scan"
    elif r["garbled_suspect"]:
        r["tier"] = "T0_garbled?"
    elif r["t1_table"]:
        r["tier"] = "T1_table"
    elif r["t2_fontsize"]:
        r["tier"] = "T2_font"
    elif r["t2b_keywords"]:
        r["tier"] = "T2b_kw"
    elif r["t3_rules"]:
        r["tier"] = "T3_rules"
    elif r["t4_boxes"]:
        r["tier"] = "T4_boxes"
    else:
        r["tier"] = "T5_plain"
    doc.close()
    return r

def main():
    files = sorted(glob.glob(os.path.join(CORPUS, "*.pdf")))
    results = [analyze(f) for f in files]
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump(results, fh, ensure_ascii=False, indent=1)
    n = len(results)
    tiers = Counter(x.get("tier", "?") for x in results)
    print(f"PROBE: {n} PDFs from {CORPUS}\n")
    for t in ["T0_scan", "T0_garbled?", "T1_table", "T2_font", "T2b_kw", "T3_rules", "T4_boxes", "T5_plain"]:
        c = tiers.get(t, 0)
        if c:
            print(f"  {t:12s} {c:3d}  {'#' * c}")
    print(f"\n{'file':<34s} {'tier':<10s} {'pg':>3s} {'chars':>6s} {'fa%':>4s} {'sTbl':>4s} {'gTbl':>4s} {'sz':>2s} {'big':>3s} {'kw':>3s} {'FR':>3s} {'HR':>3s} {'rect':>4s} {'img':>3s}")
    for x in results:
        print(f"{x['file'][:34]:<34s} {x.get('tier', '?'):<10s} {x.get('pages', 0):>3d} {x.get('text_chars', 0):>6d} "
              f"{int(x.get('persian_ratio', 0) * 100):>3d}% {x.get('section_tables', 0):>4d} {x.get('grid_tables', 0):>4d} "
              f"{x.get('distinct_sizes', 0):>2d} {x.get('bigfont_short_lines', 0):>3d} {x.get('keyword_header_lines', 0):>3d} "
              f"{x.get('full_rules', 0):>3d} {x.get('half_rules', 0):>3d} {x.get('rects', 0):>4d} {x.get('images', 0):>3d}")
    def cov(k):
        return sum(1 for x in results if x.get(k))
    print(f"\nSIGNAL COVERAGE (files where each tier would fire):")
    print(f"  T1 ruled section-tables      {cov('t1_table'):>2d}/{n}")
    print(f"  T2 font-size headers         {cov('t2_fontsize'):>2d}/{n}")
    print(f"  T2b keyword headers          {cov('t2b_keywords'):>2d}/{n}")
    print(f"  T3 horizontal rules          {cov('t3_rules'):>2d}/{n}")
    print(f"  T4 boxes/rects               {cov('t4_boxes'):>2d}/{n}")
    geo = sum(1 for x in results if x.get("t1_table") or x.get("t2_fontsize") or x.get("t3_rules") or x.get("t4_boxes"))
    kw_only = sum(1 for x in results if not (x.get("t1_table") or x.get("t2_fontsize") or x.get("t3_rules") or x.get("t4_boxes")) and x.get("t2b_keywords"))
    plain = sum(1 for x in results if x.get("tier") == "T5_plain")
    scans = tiers.get("T0_scan", 0)
    garb = tiers.get("T0_garbled?", 0)
    print(f"\n  geometry-rich (T1-T4 fire)   {geo}/{n}")
    print(f"  keyword-only cue             {kw_only}/{n}")
    print(f"  plain text (T5, old engine)  {plain}/{n}")
    print(f"  no text layer (vision)       {scans}/{n}")
    print(f"  garbled-suspect              {garb}/{n}")
    print(f"\nreport: {OUT}")

if __name__ == "__main__":
    main()
