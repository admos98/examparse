# -*- coding: utf-8 -*-
"""Build wave-3 mocks (M17-M20) and emit hand GT."""
import sys

sys.path.insert(0, '/home/z/my-project/scripts')

from mocklib import build_all          # noqa: E402
from mock_specs_d import SPECS_D       # noqa: E402

if __name__ == '__main__':
    build_all(SPECS_D)
    print('\nWave-3 mocks built. GT -> /home/z/my-project/scratch/gt-mocks')
