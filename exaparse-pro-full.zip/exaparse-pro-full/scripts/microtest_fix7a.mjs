// Micro-test of the fix-7a choose-branch logic on the real M1-I stem
const stem = 'I …………… a student. ( am – is – are )';
const gm = stem.match(/\(([^()\n]{2,90})\)\s*$/m);
console.log('gm:', gm && gm[1]);
if (gm) {
  const parts = gm[1].split(/\s+[–—]\s+/).map((p) => p.trim()).filter(Boolean);
  console.log('parts:', parts, 'len ok:', parts.length >= 3 && parts.length <= 4);
  console.log('words ok:', parts.every((p) => /^[A-Za-z\u00C0-\u024F'’\-]+(?:\s+[A-Za-z\u00C0-\u024F'’\-]+){0,2}$/.test(p)));
  console.log('blank ok:', /\.{3,}|…+|_{3,}/.test(stem.slice(0, gm.index)));
}
const instr = 'Section I: گزینه صحیح را انتخاب کنید. گزینه صحیح را انتخاب کنید.';
console.log('isChoose:', /گزینه\s*(?:صحیح|درست|مناسب)\s*(?:را\s*)?انتخاب|درون\s*پرانتز\s*گزینه|choose\s+the\s+correct/i.test(instr));
console.log('isError:', /نادرست\s*را\s*پیدا|اشتباه[\s\S]{0,24}را\s*پیدا|کلمه\s*(?:نادرست|غلط)\s*را\s*پیدا|find\s+the\s+(?:error|mistake)/i.test(instr));
console.log('isTF:', /درست\s*(?:یا|\/|و)\s*(?:نادرست|غلط)|صحیح\s*(?:یا|\/)\s*غلط|true\s*(?:or|\/)\s*false|t\s*\/\s*f/i.test(instr));
