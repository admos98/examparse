// Mock OpenAI-compatible judge: proves the /api/judge fallback contract
// end-to-end without external credentials.
import http from 'http';

const answers = {
  'c:q1': { type: 'noul', p: 0.96 },
  'k:q1': { type: 'choice', choice: 'multiple_choice' },
  's:q1': { type: 'choice', choice: 'Grammar' },
  'q:q1': { type: 'score', score: 2.5 },
  ping: { type: 'noul', p: 0.99 },
};

const server = http.createServer((req, res) => {
  if (req.method === 'POST' && req.url?.includes('/chat/completions')) {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      const wanted = JSON.parse(body).messages.at(-1).content;
      const qids = JSON.parse(wanted).questions ? Object.keys(JSON.parse(wanted).questions) : ['ping'];
      const out = Object.fromEntries(qids.filter((k) => answers[k]).map((k) => [k, answers[k]]));
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(
        JSON.stringify({
          choices: [{ message: { content: JSON.stringify({ answers: out }) }, finish_reason: 'stop' }],
          usage: { prompt_tokens: 120, completion_tokens: 40, total_tokens: 160 },
          model: 'mock-judge',
        }),
      );
    });
    return;
  }
  res.writeHead(404).end();
});

server.listen(9911, () => console.log('mock judge on 9911'));
