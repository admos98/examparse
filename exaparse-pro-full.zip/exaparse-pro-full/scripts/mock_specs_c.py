# -*- coding: utf-8 -*-
"""Wave-2 mock specs (M13-M16): genres the first 12 mocks do not cover.

- M13 translation + paragraph sentence-ordering + cloze option grid
- M14 Persian matching + صحیح/غلط answer cells + word formation (suffixes)
- M15 two-column mixed layout (extraction merges column pairs on one line)
- M16 lettered sub-parts restarting numbers + letter_reorder spelling + essay

Each spec carries its own hand-authored GT (authoring pass 4). The engine
parses the rendered documents cold; GT is written from the documents'
intended human reading, never from engine output.
"""
H7 = '…' * 3

SPECS_C = [
    # ---------------- M13 -----------------------------------------------------
    {
        'file': 'mock-13-tarjome-tartib.docx',
        'to_pdf': False,
        'header_lines': [
            'بسمه تعالی',
            'امتحان هماهنگ زبان انگلیسی پایه نهم',
            'دبیرستان علامه جعفری قم',
            'مدت آزمون: 50 دقیقه',
            'نام و نام خانوادگی:',
            'تاریخ آزمون: 19 / 02 / 1403',
        ],
        'body_lines': [
            '1.5',
            'جملات زیر را به فارسی روان ترجمه کنید.',
            '1- my brother is a pilot and he flies planes.',
            '……………………………………',
            '2- we traveled to shiraz by train last week.',
            '……………………………………',
            'A',
            '2',
            'جملات زیر را با فعل داده شده به زمان گذشته تبدیل کنید.',
            '3- they go to the mosque every friday.',
            '4- she buys bread from the bakery.',
            '5- I eat breakfast at seven.',
            'B',
            '1.5',
            'جملات زیر را مرتب کنید تا یک پاراگراف منطقی تشکیل شود.',
            '6- finally, we drank tea and went home.',
            '7- first, we walked to the park near our house.',
            '8- then, we played football with our friends.',
            '9- after that, we ate sandwiches under a tree.',
            'C',
            '2',
            'متن زیر را بخوانید و برای هر جای خالی گزینه صحیح را انتخاب کنید.',
            'ali is a taxi driver. he works ten hours every day and knows the city well. yesterday a tourist wanted to visit the old bazaar, so ali drove him there and told him about its long history. the tourist was happy and paid him extra.',
            '10 a. interested b. wonderful c. difficult d. beautiful',
            '11 a. driver b. teacher c. farmer d. doctor',
            '12 a. history b. kitchen c. flower d. window',
            'D',
            'موفق باشید',
        ],
        'gt': {
            'file': 'mock-13-tarjome-tartib.docx',
            'header': {'courseName': 'زبان انگلیسی', 'schoolName': 'دبیرستان علامه جعفری قم',
                       'district': '', 'durationMinutes': 50, 'examDate': '1403/02/19', 'grade': 'نهم'},
            'totalMarks': 7,
            'sections': [
                {'id': 'A', 'cat': 'General', 'mark': 1.5, 'qs': [{'n': [1, 2], 't': 'short_answer'}]},
                {'id': 'B', 'cat': 'General', 'mark': 2, 'qs': [{'n': [3, 4, 5], 't': 'short_answer'}]},
                {'id': 'C', 'cat': 'Writing', 'mark': 1.5, 'qs': [{'n': [6, 7, 8, 9], 't': 'sentence_ordering'}]},
                {'id': 'D', 'cat': 'Reading', 'mark': 2, 'qs': [{'n': [10, 11, 12], 't': 'multiple_choice'}]},
            ],
        },
    },
    # ---------------- M14 -----------------------------------------------------
    {
        'file': 'mock-14-farsi-motabegh.docx',
        'to_pdf': False,
        'header_lines': [
            'بسمه تعالی',
            'آزمون زبان انگلیسی پایه هشتم',
            'دبیرستان فرزانگان اصفهان',
            'مدت آزمون: 45 دقیقه',
        ],
        'body_lines': [
            '2',
            'ستون A را به ستون B وصل کنید. یک مورد اضافه است.',
            '1- someone who teaches students        الف. معلم',
            '2- a place where you buy bread        ب. نانوایی',
            '3- not expensive        ج. ارزان',
            '4- someone who flies planes        د. خلبان',
            'ه. بیمارستان',
            'A',
            '1.5',
            'با توجه به متن در مقابل جملات صحیح را با T و غلط را با F مشخص کنید.',
            'last summer we went to the north of iran. the weather was cool and it rained every afternoon. we stayed in a small wooden house near the forest and listened to the birds every morning.',
            '5- the weather in the north was hot.        T / F',
            '6- they stayed near a lake.        T / F',
            '7- it rained every afternoon.        T / F',
            'B',
            '1.5',
            'شکل صحیح کلمه داخل پرانتز را در جای خالی بنویسید.',
            '8- he is a very …………… person. (care)',
            '9- smoking is …………… for your health. (harm)',
            '10- it was …………… of you to leave the door open. (care)',
            'C',
            'موفق باشید',
        ],
        'gt': {
            'file': 'mock-14-farsi-motabegh.docx',
            'header': {'courseName': 'زبان انگلیسی', 'schoolName': 'دبیرستان فرزانگان اصفهان',
                       'district': '', 'durationMinutes': 45, 'examDate': '', 'grade': 'هشتم'},
            'totalMarks': 5,
            'sections': [
                {'id': 'A', 'cat': 'Vocabulary', 'mark': 2, 'qs': [{'n': [1, 2, 3, 4], 't': 'matching'}]},
                {'id': 'B', 'cat': 'Reading', 'mark': 1.5, 'qs': [{'n': [5, 6, 7], 't': 'true_false'}]},
                {'id': 'C', 'cat': 'Vocabulary', 'mark': 1.5, 'qs': [{'n': [8, 9, 10], 't': 'form_in_parentheses'}]},
            ],
        },
    },
    # ---------------- M15 -----------------------------------------------------
    {
        'file': 'mock-15-do-sotun.pdf',
        'to_pdf': True,
        'header_lines': [
            'بسمه تعالی',
            'امتحان زبان انگلیسی پایه دهم',
            'دبیرستان شهید بهشتی کرج',
            'مدت آزمون: 60 دقیقه',
        ],
        'body_lines': [
            '2.5',
            'به سوالات زیر پاسخ کوتاه بدهید.',
            '1- where do you usually do your homework?        3- what did you eat for breakfast?',
            '2- how often do you go to the library?        4- who is your best friend?',
            'A',
            '2',
            'در هر سوال گزینه صحیح را انتخاب کنید.',
            '5- my sister …………… to music every night.        a) listens        b) listen        c) listened',
            '6- we …………… our grandparents next friday.        a) visit        b) will visit        c) visited',
            'B',
            '1.5',
            'شکل صحیح فعل داخل پرانتز را بنویسید.',
            '7- my father …………… the car every sunday. (wash)',
            '8- they …………… football when I called them. (play)',
            'C',
            'موفق باشید',
        ],
        'gt': {
            'file': 'mock-15-do-sotun.pdf',
            'header': {'courseName': 'زبان انگلیسی', 'schoolName': 'دبیرستان شهید بهشتی کرج',
                       'district': '', 'durationMinutes': 60, 'examDate': '', 'grade': 'دهم'},
            'totalMarks': 6,
            'sections': [
                {'id': 'A', 'cat': 'General', 'mark': 2.5, 'qs': [{'n': [1, 2, 3, 4], 't': 'short_answer'}]},
                {'id': 'B', 'cat': 'Vocabulary', 'mark': 2, 'qs': [{'n': [5, 6], 't': 'multiple_choice'}]},
                {'id': 'C', 'cat': 'Grammar', 'mark': 1.5, 'qs': [{'n': [7, 8], 't': 'form_in_parentheses'}]},
            ],
        },
    },
    # ---------------- M16 -----------------------------------------------------
    {
        'file': 'mock-16-emla-ghalte.docx',
        'to_pdf': False,
        'header_lines': [
            'بسمه تعالی',
            'امتحان نوبت اول زبان انگلیسی پایه هفتم',
            'دبیرستان اندیشه یزد',
            'مدت آزمون: 40 دقیقه',
        ],
        'body_lines': [
            '2',
            'حروف به هم ریخته را مرتب کنید تا کلمه درست ساخته شود.',
            '1- ( p a p y h )        ………………',
            '2- ( o r w d )        ………………',
            '3- ( t a c h e r h e )        ………………',
            'A',
            '2',
            'شکل صحیح فعل داخل پرانتز را بنویسید.',
            '4- my mother …………… dinner every evening. (cook)',
            '5- look! the children …………… in the yard. (play)',
            '6- they …………… to school on mondays. (go)',
            '7- she …………… her homework now. (do)',
            'B',
            '3',
            'انشا: در مورد موضوع زیر یک بند بنویسید. (حداقل 40 کلمه)',
            '8- write about your best friend. what does he or she look like? what do you do together?',
            'C',
            'موفق باشید',
        ],
        'gt': {
            'file': 'mock-16-emla-ghalte.docx',
            'header': {'courseName': 'زبان انگلیسی', 'schoolName': 'دبیرستان اندیشه یزد',
                       'district': '', 'durationMinutes': 40, 'examDate': '', 'grade': 'هفتم'},
            'totalMarks': 7,
            'sections': [
                {'id': 'A', 'cat': 'Vocabulary', 'mark': 2, 'qs': [{'n': [1, 2, 3], 't': 'letter_reorder'}]},
                {'id': 'B', 'cat': 'Grammar', 'mark': 2, 'qs': [{'n': [4, 5], 't': 'form_in_parentheses'},
                                                                {'n': [6, 7], 't': 'form_in_parentheses'}]},
                {'id': 'C', 'cat': 'Writing', 'mark': 3, 'qs': [{'n': 8, 't': 'long_answer_essay'}]},
            ],
        },
    },
]
