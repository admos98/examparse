# -*- coding: utf-8 -*-
"""Helpers to build mock Iranian English exam docx/pdf files + hand ground truth.

Ground truth is authored FROM THE SPEC (single source of truth), never from
engine output, so the stress test stays honest. The spec's `lines` list is the
exact document text; the GT sections describe the intended structure.
"""
import json
import os
import re
import shutil
import subprocess
import zipfile

from docx import Document
from docx.shared import Pt

MOCKS_DIR = '/home/z/my-project/samples/mocks'
SRC_DIR = '/home/z/my-project/samples/mocks-src'
GT_DIR = '/home/z/my-project/scratch/gt-mocks'


def _set_rtl(p):
    # RTL paragraph property (visual only; extraction reads text runs)
    pPr = p._p.get_or_add_pPr()
    bidi = pPr.makeelement('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}bidi', {})
    pPr.append(bidi)


def render_docx(spec, out_path):
    """Render spec['header_lines'] + spec['body_lines'] as plain paragraphs.

    spec['numpr_idxs']: indexes into body_lines to mark as auto-numbered list
    items (w:numPr). Those lines must NOT contain their literal "N- " prefix.
    """
    doc = Document()
    style = doc.styles['Normal']
    style.font.name = 'Calibri'
    style.font.size = Pt(11)

    for ln in spec.get('header_lines', []):
        p = doc.add_paragraph(ln)
        _set_rtl(p)

    numpr = set(spec.get('numpr_idxs', []))
    for i, ln in enumerate(spec['body_lines']):
        p = doc.add_paragraph(ln)
        if i in numpr:
            pPr = p._p.get_or_add_pPr()
            numPr = pPr.makeelement('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}numPr', {})
            ilvl = pPr.makeelement('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}ilvl',
                                   {'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val': '0'})
            numId = pPr.makeelement('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}numId',
                                    {'{http://schemas.openxmlformats.org/wordprocessingml/2006/main}val': '1'})
            numPr.append(ilvl)
            numPr.append(numId)
            pPr.insert(0, numPr)

    doc.save(out_path)

    if numpr:
        inject_numbering(out_path)
    return out_path


NUMBERING_XML = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:abstractNum w:abstractNumId="0">
<w:multiLevelType w:val="singleLevel"/>
<w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="decimal"/>
<w:lvlText w:val="%1-"/><w:lvlJc w:val="left"/></w:lvl>
</w:abstractNum>
<w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>
</w:numbering>'''


def inject_numbering(docx_path):
    """Add word/numbering.xml + rels + content-type override (python-docx
    templates ship without a numbering part)."""
    tmp = docx_path + '.tmp'
    with zipfile.ZipFile(docx_path, 'r') as zin:
        names = zin.namelist()
        data = {n: zin.read(n) for n in names}
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as zout:
        replaced = False
        for n in names:
            if n == 'word/numbering.xml':
                zout.writestr(n, NUMBERING_XML)  # replace template part
                replaced = True
            else:
                zout.writestr(n, data[n])
        if not replaced:
            zout.writestr('word/numbering.xml', NUMBERING_XML)
        # content-type override only when the part is new
        ct = data['[Content_Types].xml'].decode('utf-8')
        if 'numbering+xml' not in ct:
            ct = ct.replace('</Types>',
                            '<Override PartName="/word/numbering.xml" '
                            'ContentType="application/vnd.openxmlformats-officedocument.'
                            'wordprocessingml.numbering+xml"/></Types>')
            zout.writestr('[Content_Types].xml', ct)
        # 3) relationship
        rels = data['word/_rels/document.xml.rels'].decode('utf-8')
        if 'numbering.xml' not in rels:
            m = re.findall(r'Id="rId(\d+)"', rels)
            rid = 'rId' + str(max([int(x) for x in m]) + 1 if m else 1)
            rels = rels.replace('</Relationships>',
                                f'<Relationship Id="{rid}" '
                                'Type="http://schemas.openxmlformats.org/officeDocument/2006/'
                                'relationships/numbering" Target="numbering.xml"/></Relationships>')
            zout.writestr('word/_rels/document.xml.rels', rels)
    shutil.move(tmp, docx_path)


def convert_pdf(docx_path, outdir):
    """docx -> pdf via LibreOffice headless."""
    subprocess.run(
        ['soffice', '--headless', '--convert-to', 'pdf', '--outdir', outdir, docx_path],
        check=True, capture_output=True, timeout=180)
    pdf = os.path.join(outdir, os.path.splitext(os.path.basename(docx_path))[0] + '.pdf')
    assert os.path.exists(pdf), f'pdf not produced: {pdf}'
    return pdf


def validate_gt(gt):
    """Sanity-check the hand-authored GT: marks sum, question sequences."""
    total = 0.0
    nq = 0
    seqs = []
    for s in gt['sections']:
        total += s['mark']
        for q in s['qs']:
            if q.get('stem') is not None and not isinstance(q.get('n'), list):
                pass
            if q.get('stem') is not None:
                continue  # spot-check entry, not a question row (grader semantics)
            nums = q['n'] if isinstance(q['n'], list) else [q['n']]
            nq += len(nums)
            seqs.extend(nums)
    total = round(total, 3)
    assert abs(total - gt['totalMarks']) < 0.011, \
        f"{gt['file']}: section marks sum {total} != totalMarks {gt['totalMarks']}"
    if seqs != sorted(seqs):
        print(f"  WARN {gt['file']}: question numbers not monotonic (by design?)")
    return {'marks_total': total, 'questions': nq}


def emit_gt(spec):
    gt = spec['gt']
    gt.setdefault('file', spec['file'])
    stats = validate_gt(gt)
    os.makedirs(GT_DIR, exist_ok=True)
    path = os.path.join(GT_DIR, gt['file'].replace('.pdf', '.json').replace('.docx', '.json'))
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(gt, f, ensure_ascii=False, indent=1)
    return path, stats


def build_all(specs):
    """Render docx, convert to pdf where asked, emit GT. pdf-only mocks keep
    only the pdf in MOCKS_DIR (docx source preserved in SRC_DIR)."""
    os.makedirs(MOCKS_DIR, exist_ok=True)
    os.makedirs(SRC_DIR, exist_ok=True)
    report = []
    for spec in specs:
        name = spec['file']
        src_docx = os.path.join(SRC_DIR, name.replace('.pdf', '.docx'))
        render_docx(spec, src_docx)
        if spec.get('to_pdf'):
            convert_pdf(src_docx, MOCKS_DIR)  # docx source stays in SRC_DIR
            final = os.path.join(MOCKS_DIR, name)
            assert os.path.exists(final), f'missing {final}'
        else:
            final = os.path.join(MOCKS_DIR, name)
            shutil.copy(src_docx, final)
        gt_path, stats = emit_gt(spec)
        report.append((name, stats))
        print(f"built {name}  marks={stats['marks_total']} qs={stats['questions']}  gt={os.path.basename(gt_path)}")
    return report
