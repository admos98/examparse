#!/usr/bin/env python3
"""NEGATIVE TEST injector: re-introduces the pre-fix duration bug (raw parseInt,
no bidi repair, no visual-order fallback) into parserEngine.ts. The real-exam
gate MUST fail. Restores the file afterwards."""
import shutil
import subprocess
import sys

P = '/home/z/my-project/repo-parser/src/utils/parserEngine.ts'
BAK = '/tmp/parserEngine.bak'

GOOD = '''  let durationMinutes = 0;
  if (durationMatch) {
    durationMinutes = parseDurationValue(durationMatch);
  }
  if (!durationMinutes) {'''

BAD = '''  let durationMinutes = 0;
  if (durationMatch) {
    const num = parseInt(durationMatch.replace(/\\D/g, ''), 10);
    if (!isNaN(num) && num > 0 && num < 300) durationMinutes = num;
  }
  if (false) {'''

s = open(P, encoding='utf-8').read()
assert GOOD in s, 'expected fixed duration block not found'
open(P, 'w', encoding='utf-8').write(s.replace(GOOD, BAD, 1))
print('regression injected (repair + fallback disabled)')

r = subprocess.run(
    ['npx', 'tsx', '../scripts/verifyRealExam.mts'],
    cwd='/home/z/my-project/repo-parser', capture_output=True, text=True,
)
tail = (r.stdout + r.stderr).strip().splitlines()
for line in tail[-6:]:
    print('  gate:', line)
ok_injected = r.returncode != 0
print('NEGATIVE TEST:', 'PASS (gate failed as required)' if ok_injected else 'FAIL (gate stayed green — gate is blind!)')

shutil.copy(BAK, P)
r2 = subprocess.run(
    ['npx', 'tsx', '../scripts/verifyRealExam.mts'],
    cwd='/home/z/my-project/repo-parser', capture_output=True, text=True,
)
print('restored + re-run:', 'green again' if r2.returncode == 0 else 'STILL RED — INVESTIGATE')
sys.exit(0 if ok_injected and r2.returncode == 0 else 1)
