#!/usr/bin/env python3
"""
patch_digest_v21.py — Double-check pass over curriculum-digest-v2.json.

Ground truth: official 1405-1406 student books (chap.sch.ir) — map pages AND
lesson pages (text/ extracts). Fixes found by the verification audit:
  F1 g8 L3: title was "My Shopping / My Abilities" (v1-inherited mislabel);
            official = "My Abilities". Key renamed, shopping keyword noise
            stripped (zero shopping content in the lesson — verified).
  F2 g10 L4: keywords missing (v1 key spelled L4_Travelling_the_World vs
            v2 L4_Traveling_the_World so the merge skipped it). Restored.
  F3 g11 L3: writingFocus "Reference words" -> "Infinitives" ("Recognizing
            Reference Words" is the reading strategy, now stored properly).
  F4 g12 L3: writingFocus "Proverbs" -> "Supporting & Concluding Sentences"
            ("Proverbs" is the Vocabulary Development focus, now stored).
  F5 g10 L2: grammar de-conflated to map truth ("Adjectives (See also:
            comparative and superlative adjectives)").
  F6 g7 L8:  function gains "Making suggestions"; grammar gains the
            suggestion forms (verified in lesson pages).
Added (lesson parts that v1/v2 did not include — verified from maps):
  P1  sounds (Sounds & Letters)         P2  pronunciation (Spelling & Pron.)
  P3  melody (Language Melody)          V1  conversation/listeningSpeaking/pronunciation
  V2  + readingStrategy/vocabDevelopment V3 conversation/listeningSpeaking/
        readingStrategy/vocabDevelopment (V3 has no pronunciation part)
  grade-level lessonParts documentation for all six books.
choiceDescription rebuilt for every lesson; digestVersion recomputed
(sha256 of json.dumps(grades, sort_keys=True)[:16] — same method as builder).
"""
import json, hashlib

BASE = "/home/z/my-project/scratch/curriculum"
SRC = f"{BASE}/curriculum-digest-v2.json"

d = json.load(open(SRC, encoding="utf-8"))
G = d["grades"]

# ---------------------------------------------------------------- fixes
# F1: grade 8 L3 — official title is "My Abilities"
g8 = G["english_8th_grade"]["lessons"]
old = g8.pop("L3_My_Shopping")
noise = {"shopping", "prices", "how much", "clothes", "items", "buy", "cost",
         "store"}
kws = [k.strip() for k in old["keywords"].split(",")]
kws = [k for k in kws if k.lower() not in noise]
kws = ["abilities"] + [k for k in kws if k.lower() != "ability"]
new = dict(old)
new["title"] = "My Abilities"
new["keywords"] = ", ".join(kws)
g8["L3_My_Abilities"] = new

# F2: grade 10 L4 — restore v1 keywords (key was L4_Travelling_the_World)
v1 = json.load(open(f"{BASE}/curriculum-digest-v1.json", encoding="utf-8"))
v1_kw = v1["english_10th_grade"]["lessons"]["L4_Travelling_the_World"]
G["english_10th_grade"]["lessons"]["L4_Traveling_the_World"]["keywords"] = v1_kw

# F3: grade 11 L3 — writing is Infinitives; reference words = reading strategy
v2l3 = G["english_11th_grade"]["lessons"]["L3_Art_and_Culture"]
v2l3["writingFocus"] = "Infinitives"
v2l3["readingStrategy"] = "Recognizing Reference Words"

# F4: grade 12 L3 — writing is Supporting & Concluding Sentences; proverbs = vocab dev
v3l3 = G["english_12th_grade"]["lessons"]["L3_Renewable_Energy"]
v3l3["writingFocus"] = "Supporting & Concluding Sentences"
v3l3["vocabDevelopment"] = "Proverbs"

# F5: grade 10 L2 — grammar per map (comparative/superlative is "see also")
G["english_10th_grade"]["lessons"]["L2_Wonders_of_Creation"]["grammar"] = [
    "Adjectives (See also: comparative and superlative adjectives)"]

# F6: grade 7 L8 — suggestions confirmed in lesson pages
p1l8 = G["english_7th_grade"]["lessons"]["L8_My_Favorite_Food"]
p1l8["function"] = "Talking about your favorite food; Making suggestions"
p1l8["grammar"] = p1l8["grammar"] + [
    "Suggestions: Let's have/take something to eat/drink. / How about some (cakes and milk)? / I'd like some (cakes and milk)."]

# ------------------------------------------------- missing lesson parts
P1_SOUNDS = {"L1_My_Name": "Aa Kk Mm", "L2_My_Classmates": "Ee Bb Pp",
             "L3_My_Age": "Ii Tt Nn", "L4_My_Family": "Uu Ss Gg",
             "L5_My_Appearance": "Dd Ll Rr", "L6_My_House": "Ff Vv Ww",
             "L7_My_Address": "Oo Hh Xx Yy", "L8_My_Favorite_Food": "Cc Jj Qq Zz"}
P2_PRON = {"L1_My_Nationality": "ch, sh, fr, sp, br", "L2_My_Week": "st, ee, ay",
           "L3_My_Abilities": "oo, ll, pl, sw", "L4_My_Health": "ch, ea",
           "L5_My_City": "th, ph, que, wh", "L6_My_Village": "th, fl, tr",
           "L7_My_Hobbies": "ing, ow, ou"}
P3_MELODY = {"L1_Personality": "Falling intonation (to be statements)",
             "L2_Travel": "Rising intonation (to be questions)",
             "L3_Festivals_and_Ceremonies": "Rising intonation (do/does questions)",
             "L4_Services": "Falling intonation (wh questions)",
             "L5_Media": "Rising intonation (surprises)",
             "L6_Health_and_Injuries": "Review (melodies of lessons 1-5)"}
V1 = {"L1_Saving_Nature": ("Visiting the Museum of Nature and Wildlife",
                           "Talking about Schedules/Plans", "Falling Intonation"),
      "L2_Wonders_of_Creation": ("Visiting Iranian National Observatory",
                                  "Asking about Details", "Rising Intonation"),
      "L3_The_Value_of_Knowledge": ("Talking about Famous Iranian Scientists",
                                    "Narrating a Story", "Emphatic Stress"),
      "L4_Traveling_the_World": ("Finding a Good Tourist Destination",
                                 "Asking about Obligations and Necessities",
                                 "Rising Intonation")}
V2 = {"L1_Understanding_People": ("Talking about Languages",
                                  "Shopping, Asking and Answering about Prices and Numbers",
                                  "Teen Numbers and Ten Numbers", "Scanning", "Synonyms"),
      "L2_A_Healthy_Lifestyle": ("Talking about Lifestyle",
                                 "Talking about Past Experiences",
                                 "(Emergencies) Phrasal Verbs", "Skimming",
                                 "Prefixes and Suffixes"),
      "L3_Art_and_Culture": ("Shopping Handicrafts",
                             "Talking about Conditions and Future Results",
                             "Intonation of Conditional Sentences",
                             "Recognizing Reference Words", "Antonyms")}
V3 = {"L1_Sense_of_Appreciation": ("Talking about a Great Person",
                                   "Eliciting Agreement and Signaling Uncertainty",
                                   "Question generation", "Collocations"),
      "L2_Look_It_Up": ("Talking about Dictionaries",
                        "Talking about Imaginary Situations", "Highlighting",
                        "Word Part Families"),
      "L3_Renewable_Energy": ("Talking about Wind Turbines",
                              "Talking about an Activity before another Activity in the Past",
                              "Note taking", "Proverbs")}

for k, v in P1_SOUNDS.items():
    G["english_7th_grade"]["lessons"][k]["sounds"] = v
for k, v in P2_PRON.items():
    G["english_8th_grade"]["lessons"][k]["pronunciation"] = v
for k, v in P3_MELODY.items():
    G["english_9th_grade"]["lessons"][k]["melody"] = v
for k, (conv, ls, pron) in V1.items():
    L = G["english_10th_grade"]["lessons"][k]
    L["conversation"], L["listeningSpeaking"], L["pronunciation"] = conv, ls, pron
for k, (conv, ls, pron, strat, vdev) in V2.items():
    L = G["english_11th_grade"]["lessons"][k]
    L["conversation"], L["listeningSpeaking"], L["pronunciation"] = conv, ls, pron
    L["readingStrategy"], L["vocabDevelopment"] = strat, vdev
for k, (conv, ls, strat, vdev) in V3.items():
    L = G["english_12th_grade"]["lessons"][k]
    L["conversation"], L["listeningSpeaking"] = conv, ls
    L["readingStrategy"], L["vocabDevelopment"] = strat, vdev

# grade-level lessonParts documentation (verified from lesson pages/maps)
G["english_7th_grade"]["lessonParts"] = [
    "Welcome (pre-book classroom language)", "Conversation", "Practice 1/2",
    "Sounds and Letters", "Talk to Your Teacher", "Listening and Reading",
    "Speaking and Writing", "Your Conversation",
    "Review 1 (L1-2), Review 2 (L3-4), Review 3 (L5-6), Review 4 (L7-8)",
    "Photo Dictionary"]
G["english_8th_grade"]["lessonParts"] = [
    "Conversation", "Practice 1/2/3", "Spelling and Pronunciation",
    "Talk To Your Teacher!", "Listening and Writing",
    "Reading, Speaking and Writing",
    "Review 1 (L1-2), Review 2 (L3-4), Review 3 (L5-7)", "Photo Dictionary"]
G["english_9th_grade"]["lessonParts"] = [
    "Conversation", "Practice 1/2/3", "Language Melody", "Talk to Your Teacher",
    "Listening, Reading and Writing", "Reading, Speaking, Listening and Writing",
    "Review 1 (L1-2), Review 2 (L3-4), Review 3 (L5-6)"]
for gk in ("english_10th_grade", "english_11th_grade", "english_12th_grade"):
    G[gk]["lessonParts"] = [
        "Get Ready", "Conversation", "New Words & Expressions",
        "Reading + Reading Comprehension", "Grammar (+ See Also)",
        "Listening & Speaking", "Writing", "What You Learned (in-lesson review)"]
G["english_10th_grade"]["lessonParts"].append("Pronunciation")
G["english_11th_grade"]["lessonParts"].append("Pronunciation")
G["english_11th_grade"]["lessonParts"].append("Vocabulary Development + Reading Strategy")
G["english_12th_grade"]["lessonParts"].append("Vocabulary Development + Reading Strategy")

# ------------------------------------------------- choiceDescription rebuild
def build_desc(L, book):
    segs = [f"{L['title']} — {L['function']}"]
    if L.get("grammar"):
        segs.append("Grammar: " + "; ".join(L["grammar"]))
    if book == "Prospect 1" and L.get("sounds"):
        segs.append("Sounds & Letters: " + L["sounds"])
    if book == "Prospect 2" and L.get("pronunciation"):
        segs.append("Spelling & Pronunciation: " + L["pronunciation"])
    if book == "Prospect 3" and L.get("melody"):
        segs.append("Language Melody: " + L["melody"])
    if L.get("pronunciation") and book.startswith("Vision"):
        segs.append("Pronunciation: " + L["pronunciation"])
    if L.get("listeningSpeaking"):
        segs.append("L&S: " + L["listeningSpeaking"])
    if L.get("reading"):
        segs.append("Reading: " + L["reading"])
    if L.get("keywords"):
        segs.append(L["keywords"])
    return " | ".join(segs)

for gk, gd in G.items():
    for lk, L in gd["lessons"].items():
        L["choiceDescription"] = build_desc(L, gd["book"])

# ------------------------------------------------- provenance + hash
d["_provenance"] = (
    "Ground truth: official 1405-1406 student books from chap.sch.ir (C710, C810, "
    "C910, C110230, C111230, C112230) — Map pages AND lesson pages. Double-check "
    "audit corrections (2026-09-30): g8 L3 official title is 'My Abilities' (the "
    "'My Shopping' label inherited from v1 does not exist in the book; shopping "
    "keywords stripped, shopping content belongs to L2/L7 topics); g10 L4 keywords "
    "restored (v1 key spelled 'Travelling' so the first merge missed them); g11 L3 "
    "writingFocus is 'Infinitives' (reference words = reading strategy); g12 L3 "
    "writingFocus is 'Supporting & Concluding Sentences' (proverbs = vocabulary "
    "development); g10 L2 grammar aligned to map; g7 L8 suggestions added. "
    "New per-lesson parts added from official maps: P1 Sounds & Letters, P2 "
    "Spelling & Pronunciation, P3 Language Melody, Vision conversation/ Listening & "
    "Speaking/ Pronunciation (V1, V2) / readingStrategy + vocabularyDevelopment "
    "(V2, V3; Vision 3 has no pronunciation part). Grade-level lessonParts "
    "document every book section (Welcome/Reviews/Photo Dictionary etc). "
    "Keywords inherited from user's v1 digest except where the audit proved them "
    "foreign to the lesson. Vision 1 has 4 lessons as printed.")

payload = json.dumps(d["grades"], ensure_ascii=False, sort_keys=True)
d["version"] = 2
d["digestVersion"] = hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]

dst = "/home/z/my-project/download/curriculum-digest-v2.json"
json.dump(d, open(dst, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
json.dump(d, open(f"{BASE}/curriculum-digest-v2.json", "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)

# ------------------------------------------------- audit table
import os
print("wrote", dst, os.path.getsize(dst), "bytes; digestVersion", d["digestVersion"])
print()
print(f"{'grade':<20}{'book':<11}{'L':>2}  fields-per-lesson")
for gk, gd in d["grades"].items():
    n = len(gd["lessons"])
    fieldsets = {tuple(sorted(L.keys())) for L in gd["lessons"].values()}
    print(f"{gk:<20}{gd['book']:<11}{n:>2}  {len(fieldsets)} distinct field sets")
    for lk, L in gd["lessons"].items():
        missing = []
        for req in ("title", "function", "grammar", "vocabOfficial", "keywords",
                    "choiceDescription"):
            if req not in L or not L[req]:
                missing.append(req)
        if missing:
            print("   !! ", lk, "missing", missing)
print()
# keyword sanity: every lesson has keywords; g10 L4 has keywords now
assert G["english_10th_grade"]["lessons"]["L4_Traveling_the_World"]["keywords"]
assert "L3_My_Shopping" not in G["english_8th_grade"]["lessons"]
assert G["english_11th_grade"]["lessons"]["L3_Art_and_Culture"]["writingFocus"] == "Infinitives"
assert G["english_12th_grade"]["lessons"]["L3_Renewable_Energy"]["writingFocus"] == "Supporting & Concluding Sentences"
print("ALL ASSERTIONS PASSED")
