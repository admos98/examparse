#!/usr/bin/env python3
"""Peek a geometry JSON: tables (cell text), big-font lines, rule positions.
Usage: peek_geo.py <stem> [page0..] """
import json, sys, os
from collections import Counter

GEO = "/home/z/my-project/repo-parser/scratch/geo-qu2"
stem = sys.argv[1]
pages_filter = set(int(a) for a in sys.argv[2:]) if len(sys.argv) > 2 else None

with open(os.path.join(GEO, stem + ".json"), encoding="utf-8") as fh:
    data = json.load(fh)

sizes = Counter()
for p in data["pages"]:
    for l in p["textlines"]:
        sizes[l["size"]] += len(l["text"])
body = sizes.most_common(1)[0][0] if sizes else 0
print(f"{stem}: {len(data['pages'])} pages, body size={body}")

for pi, p in enumerate(data["pages"]):
    if pages_filter and pi not in pages_filter:
        continue
    big = [l for l in p["textlines"] if l["size"] >= body * 1.15 and l["text"].strip()]
    tabs = p["tables"]
    if not big and not tabs:
        continue
    print(f"\n== page {pi+1} (w={p['width']} h={p['height']}) tables={len(tabs)} biglines={len(big)}")
    for l in big[:14]:
        mark = "B" if l["bold"] else " "
        print(f"   [{mark}{l['size']:>4.1f}] {l['text'][:70]}")
    for ti, t in enumerate(tabs):
        if t["rows"] * t["cols"] > 60:
            print(f"   table#{ti}: {t['rows']}x{t['cols']} (grid, skipped)")
            continue
        print(f"   table#{ti}: {t['rows']}x{t['cols']} bbox={[round(v) for v in t['bbox']]}")
        for ri, row in enumerate(t["cellTexts"][:8]):
            cells = [c[:34] for c in row if c]
            if cells:
                print(f"      r{ri}: {' | '.join(cells)[:110]}")
