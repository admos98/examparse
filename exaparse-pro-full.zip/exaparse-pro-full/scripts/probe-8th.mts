
import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
const targets: [string, string, number[]][] = [
  ['انگلیسی_8_مستمر_دو.docx', '2', [10]],
  ['انگلیسی_8_مستمر_یک.docx', '2', [6]],
  ['انگلیسی_8_نوبت_اول.docx', 'B', [13]],
];
for (const [f, rid, nums] of targets) {
  const text = fs.readFileSync(`/home/z/my-project/scratch/texts/${f}.txt`, 'utf8');
  const exam: any = parseExamRawText(text, f);
  const s = exam.sections.find((x: any) => x.rowId === rid);
  if (!s) { console.log(f, 'no section', rid); continue; }
  for (const q of s.questions.filter((q: any) => nums.includes(q.number)))
    console.log(f, `q${q.number} [${q.type}]`, JSON.stringify((q.stem||'').slice(0,90)));
}
