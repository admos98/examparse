import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14050320p8214n5896.pdf.txt', 'utf8');
const exam: any = parseExamRawText(text, 'p8214');
const lis = exam.sections.find((s:any)=>s.rowId==='Listening');
console.log('n:', lis.questions.length);
for (const q of lis.questions) console.log(`q${q.number} [${q.type}] ${JSON.stringify(q.stem)}`);
