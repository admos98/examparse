import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';

const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14050320p43266n364.pdf.txt', 'utf8');
const exam: any = parseExamRawText(text, 'p43266');

console.log('totalMarks:', exam.totalMarks);
for (const s of exam.sections) {
  const nums = (s.questions || []).map((q: any) => q.number);
  console.log(
    `${s.rowId} major=${s.majorCategory} markTotal=${s.markTotal} n=${nums.length} nums=[${nums.join(',')}]`,
  );
  for (const q of s.questions.slice(0, 3)) {
    console.log(`   q${q.number} [${q.type}] ${JSON.stringify((q.stem || '').slice(0, 70))}`);
  }
}
