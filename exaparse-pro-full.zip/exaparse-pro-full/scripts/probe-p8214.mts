import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14050320p8214n5896.pdf.txt', 'utf8');
const exam: any = parseExamRawText(text, 'p8214');
for (const s of exam.sections) {
  console.log(`sec ${s.rowId}: cat=${s.majorCategory} marks=${s.markTotal} n=${s.questions.length} nums=[${s.questions.map((q:any)=>q.number).join(',')}]`);
}
const s1 = exam.sections[0];
console.log('sec1 markTotal:', s1.markTotal);
for (const q of s1.questions) console.log(`  q${q.number} mark=${q.mark} [${q.type}] stem=${JSON.stringify((q.stem||'').slice(0,30))} rc=${JSON.stringify(q.receipt?.ruleChain)}`);
const s5 = exam.sections.find((s:any)=>s.rowId==='5');
for (const q of s5.questions) console.log(`sec5 q${q.number} [${q.type}] ${JSON.stringify((q.stem||'').slice(0,40))} rc=${JSON.stringify(q.receipt?.ruleChain)}`);
const s7 = exam.sections.find((s:any)=>s.rowId==='7');
for (const q of s7.questions) console.log(`sec7 q${q.number} [${q.type}] ${JSON.stringify((q.stem||'').slice(0,40))}`);
const s10 = exam.sections.find((s:any)=>s.rowId==='Change');
for (const q of s10.questions) console.log(`sec10 q${q.number} [${q.type}] ${JSON.stringify((q.stem||'').slice(0,50))}`);
const lis = exam.sections.find((s:any)=>s.rowId==='Listening');
for (const q of lis.questions) console.log(`LIS q${q.number} [${q.type}] ${JSON.stringify((q.stem||'').slice(0,45))}`);
console.log('p8214 q1 full:', JSON.stringify(exam.sections[0].questions[0], null, 0).slice(0, 420));
const s9 = exam.sections.find((s:any)=>s.rowId==='9');
for (const q of s9.questions) console.log(`sec9 q${q.number} [${q.type}] ${JSON.stringify((q.stem||'').slice(0,40))}`);
const pr = exam.sections.find((s:any)=>s.rowId==='Pronunciatin');
for (const q of pr.questions) console.log(`PR q${q.number} [${q.type}] ${JSON.stringify((q.stem||'').slice(0,40))}`);
const s2 = exam.sections.find((s:any)=>s.rowId==='2');
console.log('sec2 types:', s2.questions.map((q:any)=>q.type).join(','));
console.log('PR instr:', JSON.stringify(pr.persianInstruction), JSON.stringify(pr.englishInstruction), JSON.stringify(pr.title));
console.log('PR types:', pr.questions.map((q:any)=>q.type).join(','));
