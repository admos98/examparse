import fs from 'node:fs';
const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14050320p8214n5896.pdf.txt', 'utf8');
const lines = text.split(/\r?\n/);
lines.forEach((l, i) => { if (i < 60 && l.trim()) console.log(i, JSON.stringify(l.trim().slice(0,70))); });
