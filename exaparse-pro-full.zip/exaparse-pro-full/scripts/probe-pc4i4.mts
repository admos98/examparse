import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';

const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14050319p566h5f982.pdf.txt', 'utf8');
const exam: any = parseExamRawText(text, 'p566');

console.log('totalMarks:', exam.totalMarks);
for (const s of exam.sections) {
  const nums = (s.questions || []).map((q: any) => q.number);
  console.log(
    `${s.rowId} major=${s.majorCategory} markTotal=${s.markTotal} n=${nums.length} nums=[${nums.join(',')}]`,
  );
}
