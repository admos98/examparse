import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';

const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14050319p566h5f982.pdf.txt', 'utf8');
const exam: any = parseExamRawText(text, 'pc4i');

// Detailed dump of L and neighbors K, M
for (const id of ['J', 'K', 'L', 'M']) {
  const s = exam.sections.find((x: any) => x.rowId === id);
  if (!s) { console.log(`section ${id}: MISSING`); continue; }
  console.log(`\n=== ${id} cat=${s.category} markTotal=${s.markTotal} hasPassage=${s.hasPassage}`);
  if (s.passageText) console.log(`  passage: ${JSON.stringify(s.passageText.slice(0, 200))}`);
  if (s.instruction) console.log(`  instr: ${JSON.stringify(s.instruction.slice(0, 120))}`);
  for (const q of s.questions) {
    console.log(`  q${q.number} [${q.type}] marks=${q.marks ?? '-'} stem=${JSON.stringify((q.stem || '').slice(0, 90))}`);
  }
}
