import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';

const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14040822pc4i517871.pdf.txt', 'utf8');
const exam: any = parseExamRawText(text, 'pc4i');

const L = exam.sections.find((s: any) => s.rowId === 'L');
console.log('=== L full dump ===');
console.log('passageText:', JSON.stringify(L.passageText));
console.log('instruction:', JSON.stringify(L.instruction));
for (const q of L.questions) {
  console.log(`q${q.number} stem:`, JSON.stringify(q.stem));
}

// Raw byte check of the blank forms in the source text
console.log('\n=== raw lines with ( N ) forms ===');
for (const line of text.split('\n')) {
  if (/\(\s*\d{1,3}\s*\)/.test(line)) {
    console.log(JSON.stringify(line.slice(0, 110)));
  }
}
