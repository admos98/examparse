import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14050401pm57p5s814.pdf.txt', 'utf8');
const exam: any = parseExamRawText(text, 'pm57p5s814');
console.log('totalMarks:', exam.totalMarks);
for (const s of exam.sections) {
  const nums = (s.questions || []).map((q: any) => q.number);
  const types = [...new Set((s.questions || []).map((q: any) => q.type))];
  console.log(`sec ${s.id}: cat=${s.majorCategory} marks=${s.markTotal} n=${nums.length} nums=[${nums.slice(0,6).join(',')}${nums.length>6?'...':''}] types=${types.slice(0,3).join('/')}`);
}
