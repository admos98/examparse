import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14050401pm57p5s814.pdf.txt', 'utf8');
const exam: any = parseExamRawText(text, 'pm57p5s814');
for (const s of exam.sections) {
  console.log(`--- sec rowId=${JSON.stringify(s.rowId)} name=${JSON.stringify(s.sectionName)} cat=${s.majorCategory}`);
  console.log(`    marks=${s.markTotal} instr=${JSON.stringify((s.instructions||'').slice(0,60))}`);
  for (const q of (s.questions||[]).slice(0,3)) {
    console.log(`    q${q.number} [${q.type}] ${JSON.stringify((q.stemText||q.stem||'').slice(0,50))}`);
  }
}
