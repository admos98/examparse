import fs from 'node:fs';
import * as pe from '../repo-parser/src/utils/parserEngine';
const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14050401pm57p5s814.pdf.txt', 'utf8');
// Which internal splitter wins? Probe each exported one.
const anyPe = pe as any;
const names = Object.keys(anyPe).filter(k => /split|Radif|Kanoon|Instruction|Marks/i.test(k));
console.log('exported splitters:', names.join(', '));
for (const n of names) {
  try {
    const r = anyPe[n](text);
    if (Array.isArray(r)) console.log(`${n}: ${r.length} blocks, ids=${r.map((b:any)=>b.rowId??b.id).slice(0,8).join(',')}`);
    else console.log(`${n}: ${r === null ? 'null' : typeof r}`);
  } catch (e: any) { console.log(`${n}: ERR ${e.message}`); }
}
