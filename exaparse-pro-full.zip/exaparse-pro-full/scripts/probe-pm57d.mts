import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14050401pm57p5s814.pdf.txt', 'utf8');
const exam: any = parseExamRawText(text, 'pm57p5s814');
const s1 = exam.sections[0];
console.log('Section 1 questions:', s1.questions.map((q:any)=>`q${q.number}[${q.type}]`).join(' '));
console.log(JSON.stringify(s1.questions.slice(4).map((q:any)=>({n:q.number,t:q.type,stem:(q.stem||'').slice(0,60)})), null, 1));
const cloze = exam.sections.find((s:any)=>s.markTotal===5);
console.log('Cloze section:', JSON.stringify(cloze.questions.map((q:any)=>({n:q.number,t:q.type,stem:(q.stem||'').slice(0,70)})),null,1));
