import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14050401pm57p5s814.pdf.txt', 'utf8');
const exam: any = parseExamRawText(text, 'pm57p5s814');
for (const rid of ['3','D','N','R','A']) {
  const s = exam.sections.find((x:any)=>x.rowId===rid);
  console.log(`sec${rid}:`, s.questions.map((q:any)=>`${q.number}:${q.id.split('-').slice(2).join('-')}`).join(' '));
}
const b = exam.sections.find((x:any)=>x.rowId==='B');
console.log('secB q25:', JSON.stringify({t:b.questions[0].type, opts:b.questions[0].options, wb:b.questions[0].wordBankWords, pct:b.questions[0].parentContextType}, null, 0).slice(0,400));
