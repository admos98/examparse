import fs from 'node:fs';
import * as pe from '../repo-parser/src/utils/parserEngine';
// Re-run splitter pieces indirectly: use parseExamRawText but dump secD text via anomaly? 
// Simpler: replicate splitBareMarkerSections via exported? Not exported. Use the exam's section text instead.
const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14050401pm57p5s814.pdf.txt', 'utf8');
const exam: any = parseExamRawTextSafe();
function parseExamRawTextSafe(){ return (pe as any).parseExamRawText(text, 'pm57'); }
const d = exam.sections.find((s:any)=>s.rowId==='D');
console.log('D instr:', JSON.stringify((d.persianInstruction||'').slice(0,80)));
console.log('D q1 stem:', JSON.stringify(d.questions[0].stem.slice(0,200)));
