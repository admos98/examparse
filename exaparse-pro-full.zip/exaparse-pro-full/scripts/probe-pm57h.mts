import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14050401pm57p5s814.pdf.txt', 'utf8');
const exam: any = parseExamRawText(text, 'pm57');
for (const rid of ['L','M','P','R','A']) {
  const s = exam.sections.find((x:any)=>x.rowId===rid);
  console.log(`sec${rid} instr: ${JSON.stringify((s.persianInstruction||'').slice(0,60))} eng:${JSON.stringify((s.englishInstruction||'').slice(0,40))}`);
  for (const q of s.questions.filter((q:any)=>[62,63,70,76,79,80,81,82,21,22].includes(q.number)))
    console.log(`  q${q.number} [${q.type}] ${(q.stem||'').slice(0,70).replace(/\n/g,' | ')}`);
}
