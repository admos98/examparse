import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/13991009pq89w65173.pdf.txt', 'utf8');
const exam: any = parseExamRawText(text, 'pq89');
const s5 = exam.sections.find((s:any)=>s.rowId==='5');
for (const q of s5.questions) console.log(`  q${q.number} mark=${q.mark} [${q.type}] stem=${JSON.stringify((q.stem||'').slice(0,25))} id=${q.id}`);
console.log('markTotal:', s5.markTotal);
console.log('q15 full:', JSON.stringify(s5.questions[0], null, 0).slice(0, 500));
