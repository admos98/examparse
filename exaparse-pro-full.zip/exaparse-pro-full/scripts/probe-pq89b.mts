import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/13991009pq89w65173.pdf.txt', 'utf8');
const exam: any = parseExamRawText(text, 'pq89');
for (const s of exam.sections) console.log(`sec ${s.rowId}: marks=${s.markTotal} n=${s.questions.length} qmarks=[${s.questions.map((q:any)=>q.mark).join(',')}]`);
