import fs from 'node:fs';
import { runParsePipeline } from '../repo-parser/src/utils/parsePipeline';
const rawText = fs.readFileSync('/home/z/my-project/scratch/texts/real_14050319.pdf.txt', 'utf8');
const res: any = runParsePipeline({ rawText, filename: '14050319px3c5v1338.pdf' });
const flat = res.doc.sections.flatMap((s: any) => s.questions || []);
for (const q of flat.filter((q: any) => [41, 42, 45, 46, 47].includes(Number(q.number)))) {
  console.log(`q${q.number} [${q.type}] ${JSON.stringify((q.stem||'').slice(-70))}`);
}
