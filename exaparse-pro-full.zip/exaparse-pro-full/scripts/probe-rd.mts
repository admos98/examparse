import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14050320p8214n5896.pdf.txt', 'utf8');
const exam: any = parseExamRawText(text, 'p8214');
const rd = exam.sections.find((s:any)=>s.rowId==='Reading');
for (const q of rd.questions) console.log(`q${q.number} [${q.type}] ${JSON.stringify((q.stem||'').slice(-45))}`);
