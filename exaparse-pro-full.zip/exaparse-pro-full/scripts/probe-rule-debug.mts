import fs from 'node:fs';

const text = fs.readFileSync('/home/z/my-project/scratch/texts-qu2/14050320p43266n364.pdf.txt', 'utf8');
const lines = text.split(/\r?\n/);
const nfkc = (l: string) => l.normalize('NFKC');

const isRule = (l: string) => {
  const t = l.trim();
  return t.length >= 30 && /^[-_\u2013\u2014.…\s]+$/.test(t) && /[-_\u2013\u2014]{10,}|…{6,}/.test(t);
};
const openerDigit = (l: string): number | null => {
  const t = nfkc(l.trim());
  const m = t.match(/^(\d{1,2})\s*[.،,]?\s+[\u0600-\u06FF]/);
  return m ? parseInt(m[1], 10) : null;
};

const ruleAt: number[] = [];
for (let i = 0; i < lines.length; i++) if (isRule(lines[i])) ruleAt.push(i);
console.log('rules at lines:', ruleAt, 'total lines:', lines.length);

const regions: { start: number; end: number }[] = [];
regions.push({ start: 0, end: ruleAt[0] });
for (let i = 0; i < ruleAt.length - 1; i++) regions.push({ start: ruleAt[i] + 1, end: ruleAt[i + 1] });
regions.push({ start: ruleAt[ruleAt.length - 1] + 1, end: lines.length });
console.log('regions:', regions.length);

for (const reg of regions) {
  let openerAt = -1;
  for (let k = reg.start; k < reg.end; k++) {
    const t = lines[k].trim();
    if (!t) continue;
    const digitHere = openerDigit(lines[k]);
    if (digitHere !== null || /[\u0600-\u06FF]/.test(nfkc(t))) {
      if (
        /نام\s*و\s*نام|نام\s*دبیر|دبیرستان|دبستان|آموزش\s*و\s*پرورش|تاریخ|وقت\s*امتحان|ساعت\s*امتحان|شماره\s*صندلی|نوبت|پایه|صفحه|امضاء|مهر|به\s*عدد|به\s*حروف|دانلود|تخف|جایزه|تمرین|کانون/.test(nfkc(t)) &&
        !digitHere
      ) continue;
      if (digitHere === null && t.length < 20) continue;
      openerAt = k;
      break;
    }
  }
  console.log(
    `region [${reg.start},${reg.end}) opener=${openerAt}` +
      (openerAt >= 0 ? ` digit=${openerDigit(lines[openerAt])} line=${JSON.stringify(lines[openerAt].slice(0, 60))}` : ' NONE'),
  );
}
