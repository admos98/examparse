import fs from 'node:fs';
import path from 'node:path';
import { parseDurationFromRtlLine, parseDurationValue } from '../repo-parser/src/utils/parserEngine';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';
const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
for (const f of ['14050319p566h5f982.pdf.txt','14050320p43266n364.pdf.txt']) {
  const lines = fs.readFileSync(path.join(TEXT_DIR, f), 'utf8').split(/\r?\n/);
  console.log('== ' + f);
  lines.slice(0, 14).forEach((l, i) => { if (/امتحان|دقیقه|مدت|وقت/.test(l)) console.log(`  L${i}: "${l}" -> rtl=${parseDurationFromRtlLine(l)} val=${parseDurationValue(l)}`); });
}
