import fs from 'node:fs';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';

const [file] = process.argv.slice(2);
const text = fs.readFileSync(`/home/z/my-project/scratch/texts-qu2/${file}.txt`, 'utf8');
const doc = parseExamRawText(text, file + '.pdf', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
for (const s of doc.sections) {
  const qs = s.questions.map((q) => `${q.number}:${q.type.slice(0, 8)}`);
  console.log(`[${s.rowId}] ${s.majorCategory} mark=${s.markTotal} qs=${s.questions.length} | ${qs.slice(0, 14).join(' ')}${qs.length > 14 ? ' …' : ''}`);
}
console.log('header:', JSON.stringify(doc.header));
console.log('total:', doc.totalMarks);
