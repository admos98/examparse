/** Dump section bank metadata + question type details for qu2 files. */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';

const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
const file = process.argv[2];
const wantRow = process.argv[3];
const parsed = parseExamRawText(
  fs.readFileSync(path.join(TEXT_DIR, file + '.pdf.txt'), 'utf8'),
  file + '.pdf',
  { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true },
);
for (const s of parsed.sections) {
  if (wantRow && String(s.rowId).toLowerCase() !== wantRow.toLowerCase()) continue;
  console.log(`S#${s.rowId} cat=${s.majorCategory} markTotal=${s.markTotal} hasBank=${s.hasWordBank} bank=${JSON.stringify(s.wordBank)}`);
  for (const q of s.questions) {
    console.log(`   ${q.id} [#${q.number}] orig=${(q as any).originalNumber} ${q.type} mark=${q.mark} pctx=${q.parentContextType} wb=${q.wordBankWords ? q.wordBankWords.length : undefined} rc=${JSON.stringify((q as any).receipt?.ruleChain ?? null)} :: ${(q.stem || '').replace(/\s+/g, ' ').slice(0, 80)}`);
  }
}
