/** Dump parsed sections for qu2 files (diagnostic). */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';

const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
const file = process.argv[2];
const opts = {
  detectAnomalies: true,
  normalizeNumbering: true,
  linkClozePassages: true,
} as const;
const parsed = parseExamRawText(
  fs.readFileSync(path.join(TEXT_DIR, file + '.pdf.txt'), 'utf8'),
  file + '.pdf',
  opts,
);
console.log('duration:', parsed.durationMinutes, '| totalMarks:', parsed.totalMarks, '| sections:', parsed.sections.length);
for (const s of parsed.sections) {
  console.log(`S#${s.id ?? '?'} cat=${(s as any).category ?? (s as any).cat ?? '?'} mark=${(s as any).mark ?? '?'} n=${s.questions.length}`);
  for (const q of s.questions) {
    const stem = (q.questionText ?? q.stem ?? '').replace(/\s+/g, ' ').slice(0, 70);
    console.log(`   ${q.id} [#${(q as any).originalNumber ?? q.number ?? '?'}] ${(q as any).type ?? '?'} mark=${(q as any).mark ?? '?'} :: ${stem}`);
  }
}
