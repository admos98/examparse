import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';

const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
const files = process.argv.slice(2);
for (const f of files) {
  const text = fs.readFileSync(path.join(TEXT_DIR, f), 'utf8');
  const doc = parseExamRawText(text, f, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  console.log('==== ' + f);
  console.log('header:', JSON.stringify({ course: doc.header.courseName, dur: (doc.header as any).durationMinutes }));
  console.log('totalMarks:', doc.totalMarks);
  for (const s of doc.sections) {
    console.log(`  [${s.rowId}] ${s.majorCategory} mark=${s.markTotal} :: ${(s.title||'').slice(0,50)}`);
    console.log('     qs: ' + s.questions.map((q) => q.number + ':' + q.type).join(' '));
  }
}
