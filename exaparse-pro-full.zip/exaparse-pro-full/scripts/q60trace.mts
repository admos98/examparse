import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';
const text = fs.readFileSync(path.join(WS_ROOT, 'scratch', 'texts', '11th_first.pdf.txt'), 'utf8');
const doc = parseExamRawText(text, '11th_first.pdf', { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
for (const s of doc.sections) {
  for (const q of s.questions) {
    if ([60, 61].includes(q.number)) {
      console.log(JSON.stringify({ sec: s.rowId, n: q.number, type: q.type, stem: q.stem, opts: q.options?.length, receipt: q.receipt }, null, 1).slice(0, 800));
    }
  }
}
