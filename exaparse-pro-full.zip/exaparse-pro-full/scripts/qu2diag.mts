import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
import { gradeParse } from '../repo-parser/src/utils/goldenGrade';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-qu2');
const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
const filter = process.argv[2];
for (const f of fs.readdirSync(GT_DIR).filter((x) => x.endsWith('.json'))) {
  const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
  if (filter && !gt.file.includes(filter)) continue;
  const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
  const parsed = parseExamRawText(fs.readFileSync(textPath, 'utf8'), gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  const { issues } = gradeParse(parsed, gt);
  console.log('==== ' + gt.file);
  for (const i of issues.slice(0, 60)) console.log('   ' + i);
}
