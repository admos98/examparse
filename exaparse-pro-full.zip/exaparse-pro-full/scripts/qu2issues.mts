/**
 * qu2 accuracy-campaign issue dump — groups every grader issue per file so
 * root causes can be attacked in batches. Read-only; prints a compact table:
 *   file | score | issue-kind counts | first N issue messages
 * Usage: npx tsx scripts/qu2issues.mts [file-substring-filter]
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
import { gradeParse } from '../repo-parser/src/utils/goldenGrade';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';

const GT_DIR = path.join(WS_ROOT, 'scratch', 'gt-qu2');
const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
const filter = process.argv[2] || '';

const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json')).sort();
const kindCounts = new Map<string, number>();

for (const f of files) {
  const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
  if (filter && !gt.file.includes(filter)) continue;
  const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
  if (!fs.existsSync(textPath)) continue;
  const parsed = parseExamRawText(fs.readFileSync(textPath, 'utf8'), gt.file, {
    detectAnomalies: true,
    normalizeNumbering: true,
    linkClozePassages: true,
  });
  const { score, issues, total } = gradeParse(parsed, gt);
  console.log(`\n=== ${gt.file} — ${score.toFixed(1)}% (${total - issues.length}/${total}) ===`);
  for (const iss of issues.slice(0, 40)) {
    const kind = String((iss as any).kind ?? (iss as any).type ?? 'issue');
    kindCounts.set(kind, (kindCounts.get(kind) ?? 0) + 1);
    const msg = String((iss as any).message ?? JSON.stringify(iss)).slice(0, 220);
    console.log(`  [${kind}] ${msg}`);
  }
  if (issues.length > 40) console.log(`  … +${issues.length - 40} more`);
}

console.log('\n=== ISSUE KIND TOTALS ===');
for (const [k, n] of [...kindCounts.entries()].sort((a, b) => b[1] - a[1])) {
  console.log(`${String(n).padStart(4)}  ${k}`);
}
