/**
 * qu2 second-golden-pass scorecard (REPORT stage — non-gating).
 *
 * The second golden-sheet corpus lives in WS_ROOT/scratch/gt-qu2 (hand-built
 * ground truths) + scratch/texts-qu2 (deterministic pdfjs extractions). This
 * stage prints the generalization scorecard for every GT file so progress is
 * visible per run. It does NOT gate: qu2 is a pass IN PROGRESS — the strict
 * gate line (golden 30/30 + mocks 20/20) covers the shipped corpora, and qu2
 * files are promoted into a strict pinned runner only when they reach 100%.
 *
 * Classification of the full 47-file qu2 set (scratch/qu2-classify.json +
 * scratch/qu2-deferred.json): 37 files carry a real text layer, 10 are
 * image-only scans (watermark text only — OCR territory), and the deferred
 * list records garbled-font / audio-script files with reasons.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
import { gradeParse } from '../repo-parser/src/utils/goldenGrade';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';

const GT_DIR = process.env.QU2_GT_DIR ?? path.join(WS_ROOT, 'scratch', 'gt-qu2');
const TEXT_DIR = process.env.QU2_TEXT_DIR ?? path.join(WS_ROOT, 'scratch', 'texts-qu2');

function main() {
  if (!fs.existsSync(GT_DIR)) {
    console.log('(qu2 scorecard: no GT dir — skipped)');
    return;
  }
  const files = fs.readdirSync(GT_DIR).filter((f) => f.endsWith('.json'));
  let best = 0;
  for (const f of files) {
    const gt = JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8'));
    const textPath = path.join(TEXT_DIR, gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_') + '.txt');
    if (!fs.existsSync(textPath)) {
      console.log(`qu2 SKIP ${gt.file} (no text)`);
      continue;
    }
    const parsed = parseExamRawText(fs.readFileSync(textPath, 'utf8'), gt.file, {
      detectAnomalies: true,
      normalizeNumbering: true,
      linkClozePassages: true,
    });
    const { score, issues, total } = gradeParse(parsed, gt);
    const icon = issues.length === 0 ? 'PASS' : 'FAIL';
    if (issues.length === 0) best++;
    console.log(`qu2 ${icon} ${score.toFixed(1)}% (${total - issues.length}/${total}) ${gt.file} — ${issues.length} issue(s)`);
  }
  console.log(`qu2 scorecard: ${best}/${files.length} at 100% (report only — promotion to the strict gate happens file-by-file at 100%)`);
  // Full-corpus accounting: every one of the 47 qu2 files is either graded
  // here, or explicitly deferred with a reason — the denominator is never
  // silently shrunk (the GT_MIN_FILES lesson, applied to the second pass).
  const deferredPath = path.join(WS_ROOT, 'scratch', 'qu2-deferred.json');
  if (fs.existsSync(deferredPath)) {
    const d = JSON.parse(fs.readFileSync(deferredPath, 'utf8')) as {
      imageOnly: string[];
      notExams: { file: string; reason: string }[];
      structureDeferred: { file: string; reason: string }[];
    };
    const gtFiles = new Set(files.map((f) => (JSON.parse(fs.readFileSync(path.join(GT_DIR, f), 'utf8')) as { file: string }).file));
    const graded = gtFiles.size;
    const nonGradable = d.notExams.length + d.structureDeferred.length;
    const imageOnly = d.imageOnly.length;
    console.log(
      `qu2 corpus accounting: ${graded} GT-graded + ${nonGradable} non-gradable (audio/${d.notExams.length}, garbled-or-scrambled/${d.structureDeferred.length}) + ${imageOnly} image-only scans (deferred pending an OCR decision) = ${graded + nonGradable + imageOnly}/47 files`,
    );
  }
}

main();
