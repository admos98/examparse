#!/bin/bash
# Re-run mock batch extraction + strict grading. Usage: bash run_mock_grade.sh [label]
# pipefail so the grader's exit code survives tee/tail (strict mode exits 1 on any FAIL/SKIP).
#
# All paths derive from THIS script's location (scripts/ sits one level under
# the workspace/bundle root) — no absolute machine paths, so it runs
# out-of-the-box anywhere (layout contract: repo-parser/scripts-batch/wsPaths.mts).
set -e
set -o pipefail
LABEL="${1:-run}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WS_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
PKG="$WS_ROOT/repo-parser"

cd "$PKG"
CORPUS_DIR="$WS_ROOT/samples/mocks" \
OUT_TXT="$WS_ROOT/scratch/texts-mocks" \
OUT_JSON="$WS_ROOT/scratch/parsed-mocks" \
npx tsx scripts-batch/extract_all.mts 2>&1 | tail -2
GT_DIR="$WS_ROOT/scratch/gt-mocks" \
TEXT_DIR="$WS_ROOT/scratch/texts-mocks" \
npx tsx scripts-batch/grade.mts 2>&1 | tee "$WS_ROOT/scratch/mock-${LABEL}.txt" | tail -16
