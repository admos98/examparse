import fs from 'node:fs';
import path from 'node:path';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';

const [name, dir, wantId] = [process.argv[2], process.argv[3] ?? 'texts', process.argv[4]];
const text = fs.readFileSync(path.join(WS_ROOT, 'scratch', dir, name), 'utf8');
const doc = parseExamRawText(text, name, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
for (const s of doc.sections) {
  if (wantId && s.rowId !== wantId) continue;
  const wb = (s as unknown as { wordBank?: string[] }).wordBank;
  console.log(`sec ${s.rowId} cat=${s.category} hasWB=${(s as unknown as { hasWordBank?: boolean }).hasWordBank} wb=[${(wb ?? []).join('|')}]`);
  for (const q of s.questions.slice(0, 8)) {
    console.log(`   q${q.number} [${q.type}] ${JSON.stringify((q.stem ?? '').slice(0, 60))}`);
  }
}
