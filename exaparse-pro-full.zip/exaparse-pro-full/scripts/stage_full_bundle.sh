#!/bin/bash
# Stage the FULL ExaParse Pro codebase (app + ML/brain side + harness + gate data)
# into a single folder, excluding huge data (samples/qu2 PDF corpora, analysis
# dumps, node_modules, .git history) and secrets (.env).
set -e
ROOT=/home/z/my-project
STAGE=$ROOT/stage-full
rm -rf "$STAGE"
mkdir -p "$STAGE/exaparse-pro-full/repo-parser/scratch/brain-app-qu2"
mkdir -p "$STAGE/exaparse-pro-full/scratch"

# ── repo-parser: everything except node_modules, analysis dumps, old bundles ──
rsync -a \
  --exclude 'node_modules' \
  --exclude 'bundle_r6' --exclude 'bundle_r6.zip' --exclude 'bundle_r6.zip.sha256' \
  --exclude 'scratch' \
  "$ROOT/repo-parser/" "$STAGE/exaparse-pro-full/repo-parser/"

# brain-app texts (small, needed by probe scripts)
rsync -a "$ROOT/repo-parser/scratch/brain-app-qu2/texts" \
  "$STAGE/exaparse-pro-full/repo-parser/scratch/brain-app-qu2/"

# ── top-level harness scripts (verify chain, reports, builders) ──
rsync -a --exclude '*.log' "$ROOT/scripts/" "$STAGE/exaparse-pro-full/scripts/"

# ── gate data (small): GT, extracted texts, mock outputs ──
for d in gt gt-qu2 texts texts-qu2 texts-mocks parsed-mocks; do
  if [ -d "$ROOT/scratch/$d" ]; then
    rsync -a "$ROOT/scratch/$d" "$STAGE/exaparse-pro-full/scratch/"
  fi
done

# ── worklog + README ──
cp "$ROOT/worklog.md" "$STAGE/exaparse-pro-full/worklog.md"

cat > "$STAGE/exaparse-pro-full/README-BUNDLE.md" <<'MD'
# ExaParse Pro — full codebase bundle

Persian/English school-exam parser. Vite + React 19 + TypeScript frontend,
Express server (`repo-parser/server.ts`), parser engine + layout-brain/ML
adjudication layer in `repo-parser/src/utils/`, OCR workers in `src/workers/`,
harness + verify chain in `repo-parser/scripts*` and top-level `scripts/`.

## Layout (mirrors the dev workspace — paths resolve as-is)
- `repo-parser/`            the app: src (components/server/utils/workers/data/types),
                            scripts, scripts-batch, data (curriculum digest + mined
                            rules), configs, package.json + lock
- `repo-parser/scratch/brain-app-qu2/texts/`  extracted exam texts used by probes
- `scripts/`                top-level harness: goldenCorpus, qu2report,
                            brain_bridge_report, verifyFixes/verifyRealExam/…, GT builders
- `scratch/gt`, `gt-qu2`    ground-truth jsons (golden 30 + qu2 32 + mocks)
- `scratch/texts*`          extracted texts for the gate corpora
- `scratch/parsed-mocks`    committed mock parse outputs
- `worklog.md`              full wave-by-wave engineering log (R1..R7)

## Excluded (huge data / regenerable / secrets)
- `node_modules`            run `npm install` in `repo-parser/` (package-lock pinned)
- `.git` history, `samples/` + `qu2/` raw PDF corpora (~200MB)
- analysis dumps (brain-qu2, geo-qu2, specialist outputs), old bundles
- `.env` (contains DATABASE_URL) — create your own if the AI/DB wire is used

## Run
```
cd repo-parser
npm install
npm run verify    # gate: golden 30/30 + mocks 20/20 + pinned 6/6 + real-exam 69/69
npm run dev       # app on :3000 (per vite config; server.ts for the API)
```
Corpus report: `npx tsx scripts/brain_bridge_report.mts` from repo-parser/
(writes per-file text/brain scores; harness resolves WS_ROOT = the folder
containing `repo-parser/` + `scripts/` + `scratch/`).
MD

echo "=== staged ===" && du -sh "$STAGE/exaparse-pro-full" && find "$STAGE/exaparse-pro-full" -type f | wc -l
