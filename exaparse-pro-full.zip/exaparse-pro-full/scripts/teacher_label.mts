/**
 * teacher_label.mts — Wave M2 "TeacherNet": distill an LLM teacher into the
 * tiny local model.
 *
 * WHAT THIS IS
 *   The app's runtime is 100% local (TypeNet, <2MB, zero deps). This script is
 *   the OFFLINE build-time half of the loop: an LLM teacher (glm-4-plus via
 *   the local z-ai CLI) labels the REAL corpus — every engine-parsed section
 *   of every qu2 text dump — producing section categories + per-question
 *   types in strict JSON. Teacher labels are then quality-gated against the
 *   32 hand GTs (teacher_quality.mts) and only the reliable mass joins
 *   training (corpus 'teacher' in dump_tinymodel_data.mts).
 *
 * WHY
 *   TypeNet's M1 blocker was LABELS (82 hand GTs; CV precision did not
 *   transfer). The teacher labels all 47 real exams — including the 15 with
 *   NO GT at all — through the SAME parseExamRawText path the dump uses, so
 *   alignment holds by construction (labels reference engine rowIds and
 *   printed numbers, never guessed).
 *
 * RUN
 *   cd repo-parser && tsx ../scripts/teacher_label.mts
 *   Env: FORCE=1 re-labels everything; BUDGET=seconds (default 460) caps wall
 *   time per invocation (resumable — completed files are skipped); SMOKE=1
 *   processes only the first file; TEACHER_FILES=<comma list> restricts.
 */
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
import { WS_ROOT } from '../repo-parser/scripts-batch/wsPaths.mts';

const TEXT_DIR = path.join(WS_ROOT, 'scratch', 'texts-qu2');
const OUT_DIR = path.join(WS_ROOT, 'scratch', 'teacher-labels');
const RAW_DIR = path.join(OUT_DIR, 'raw');
const LAB_DIR = path.join(OUT_DIR, 'labels');
for (const d of [OUT_DIR, RAW_DIR, LAB_DIR]) fs.mkdirSync(d, { recursive: true });

const BUDGET_S = parseInt(process.env.BUDGET ?? '460', 10);
const FORCE = process.env.FORCE === '1';
const SMOKE = process.env.SMOKE === '1';
const t0 = Date.now();
const left = () => BUDGET_S - (Date.now() - t0) / 1000;

/** The exact class inventories of the tiny model (weights.types / weights.cats). */
const TYPES: Record<string, string> = {
  multiple_choice: '3-4 lettered options (A-D), choose the correct one',
  true_false: 'statement judged True or False',
  matching: 'two columns to match (definitions, pictures, sentence halves)',
  word_bank_fill: 'fill blank(s) using words given in a word bank',
  fill_blank: 'fill blank(s) with your OWN word(s), no word bank given',
  form_in_parentheses: 'verb/word given in parentheses must be put into the correct form',
  inline_choice: 'options embedded inside the sentence separated by slashes (go/goes/went)',
  cloze_item: 'numbered blanks inside a running passage/text',
  short_answer: 'wh-question answered in your own words (no options, no blank-fill)',
  error_correction: 'find and correct the mistake in each sentence',
  unscramble: 'rearrange scrambled words into a correct sentence',
  sentence_ordering: 'put sentences/paragraphs into the correct order',
  letter_reorder: 'rearrange letters to form words',
  combine_sentences: 'join two sentences (relative pronouns, conjunctions)',
  active_passive: 'transform active <-> passive voice',
  long_answer_essay: 'writing/composition task (paragraph, essay, email)',
  numerical_calculation: 'mathematical computation',
  odd_one_out: 'pick the word that does not belong',
  phonetic_pronunciation: 'pronunciation choice (how a sound is said)',
  picture_description: 'describe a picture or choose about pictures',
};
const CATS = ['Listening', 'Vocabulary', 'Grammar', 'Reading', 'Writing', 'General'];

const SYSTEM = `You are an expert exam annotator for Iranian high-school English exams (bilingual Persian/English; Persian text may appear REVERSED or garbled because of PDF text extraction — read through it confidently).
You label sections of an exam that a heuristic parser already segmented. For every section you give:
- "category": exactly one of ${CATS.join(' | ')}
- for EVERY numbered question in it, "type": exactly one of:
${Object.entries(TYPES).map(([k, v]) => `  ${k} = ${v}`).join('\n')}

Judgment rules (the heuristic parser's known weaknesses — use the MEANING of the task, not surface cues):
- A blank in a sentence with NO word bank = fill_blank; the same with a word bank printed above = word_bank_fill.
- A wh-question expecting a short written answer = short_answer (NOT fill_blank).
- A verb in parentheses after the blank = form_in_parentheses (NOT fill_blank).
- Slash-separated choices inside the sentence = inline_choice.
- Two columns to pair up = matching, even if the word "match" never appears.
- Reading-passage comprehension questions = category Reading.
- Questions referencing a conversation/audio/picture story usually belong to Listening.
- The exam's instruction lines (FA:/EN:) are the primary evidence for category.

Output ONLY minified JSON, no prose, no code fences:
{"sections":[{"id":"<id>","category":"<cat>","questions":[{"n":"<printed number exactly as shown>","type":"<type>"}]}]}`;

function renderSection(s: any): string {
  const lines: string[] = [];
  lines.push(`[SEC ${s.rowId}]`);
  const title = (s.title ?? '').trim();
  if (title) lines.push(`TITLE: ${title.slice(0, 120)}`);
  const fa = (s.persianInstruction ?? '').trim();
  if (fa) lines.push(`FA: ${fa.slice(0, 300)}`);
  const en = (s.englishInstruction ?? '').trim();
  if (en) lines.push(`EN: ${en.slice(0, 300)}`);
  if (s.hasWordBank && (s.wordBank ?? []).length > 0) lines.push(`BANK: ${(s.wordBank as string[]).join(' ¦ ').slice(0, 200)}`);
  if (s.hasPassage && s.passageText) lines.push(`PASSAGE: ${(s.passageText ?? '').slice(0, 350)}`);
  const qs = s.questions ?? [];
  if (qs.length === 0) {
    lines.push('(no numbered questions)');
  } else {
    for (const q of qs.slice(0, 18)) {
      const opts = (q.options ?? []).map((o: any) => o.text ?? '').filter(Boolean).slice(0, 4);
      let ln = `Q ${q.number}: ${(q.stem ?? '').slice(0, 150)}`;
      if (opts.length >= 2) ln += `  [opts: ${opts.join(' ¦ ').slice(0, 160)}]`;
      if (q.mark) ln += ` (${q.mark})`;
      lines.push(ln);
    }
    if (qs.length > 18) lines.push(`... (${qs.length - 18} more questions, numbers ${qs.slice(18).map((q: any) => q.number).join(',')})`);
  }
  return lines.join('\n');
}

function chunkSections(rendered: { id: string; text: string; chars: number }[], budget = 8500): { id: string; text: string }[][] {
  const chunks: { id: string; text: string }[][] = [];
  let cur: { id: string; text: string }[] = [];
  let size = 0;
  for (const r of rendered) {
    if (cur.length > 0 && size + r.chars > budget) {
      chunks.push(cur);
      cur = [];
      size = 0;
    }
    cur.push({ id: r.id, text: r.text });
    size += r.chars;
  }
  if (cur.length > 0) chunks.push(cur);
  return chunks;
}

function callZai(user: string, outRaw: string): string {
  execFileSync('z-ai', ['chat', '-p', user, '-s', SYSTEM, '-o', outRaw], { stdio: ['ignore', 'ignore', 'pipe'], timeout: 180_000 });
  const raw = JSON.parse(fs.readFileSync(outRaw, 'utf8'));
  return raw?.choices?.[0]?.message?.content ?? '';
}

function extractJson(content: string): any {
  let c = (content ?? '').trim();
  c = c.replace(/^```(?:json)?/i, '').replace(/```\s*$/, '').trim();
  const start = c.indexOf('{');
  const end = c.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('no JSON object found');
  return JSON.parse(c.slice(start, end + 1));
}

function validate(doc: any, engineById: Map<string, any>): { sections: any[]; droppedQ: number } {
  const sections: any[] = [];
  let droppedQ = 0;
  for (const sec of doc?.sections ?? []) {
    const es = engineById.get(String(sec?.id ?? ''));
    if (!es) continue;
    const engineNums = new Set((es.questions ?? []).map((q: any) => String(q.number)));
    const qs = [];
    for (const q of sec?.questions ?? []) {
      const n = String(q?.n ?? '');
      if (!engineNums.has(n)) { droppedQ++; continue; }
      if (!TYPES[q?.type]) { droppedQ++; continue; }
      qs.push({ n, type: q.type });
    }
    const cat = CATS.includes(sec?.category) ? sec.category : 'General';
    sections.push({ id: es.rowId, category: cat, questions: qs });
  }
  return { sections, droppedQ };
}

function main() {
  const restrict = process.env.TEACHER_FILES ? new Set(process.env.TEACHER_FILES.split(',')) : null;
  const stems = fs.readdirSync(TEXT_DIR).filter((f) => f.endsWith('.txt')).sort();
  let done = 0, skipped = 0, failed = 0, labeledQ = 0, droppedQ = 0;

  for (const stem of stems) {
    if (restrict && !restrict.has(stem)) continue;
    if (SMOKE && done >= 1) break;
    const outPath = path.join(LAB_DIR, stem);
    if (fs.existsSync(outPath) && !FORCE) { skipped++; continue; }
    if (left() < 45) { console.log(`BUDGET: stopping with ${left().toFixed(0)}s left (resumable)`); break; }

    const text = fs.readFileSync(path.join(TEXT_DIR, stem), 'utf8');
    if (text.length < 250) {
      fs.writeFileSync(outPath, JSON.stringify({ file: stem, sections: [], note: 'text-too-short (scan)' }, null, 1));
      skipped++;
      continue;
    }

    const doc = parseExamRawText(text, stem, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
    const secs = doc.sections ?? [];
    const engineById = new Map<string, any>();
    const rendered = secs.map((s: any) => {
      engineById.set(String(s.rowId), s);
      const t = renderSection(s);
      return { id: String(s.rowId), text: t, chars: t.length };
    });

    const allSections: any[] = [];
    let fileDropped = 0, fileErr = 0;
    const chunks = chunkSections(rendered);
    for (let ci = 0; ci < chunks.length; ci++) {
      const rawOut = path.join(RAW_DIR, stem.replace(/\.txt$/, `-${ci}.json`));
      const userMsg = `Exam file: ${stem}\nSections to label (the id after [SEC is what you echo back):\n\n` +
        chunks[ci].map((c) => c.text).join('\n\n');
      let doc2: any = null;
      for (let attempt = 1; attempt <= 4; attempt++) {
        try {
          const content = callZai(userMsg, rawOut);
          doc2 = extractJson(content);
          break;
        } catch (e: any) {
          fileErr++;
          const wait = 4 * attempt * attempt; // 4s, 16s, 36s — API bursts recover
          if (attempt === 4) { console.log(`  chunk ${ci} error: ${String(e?.message ?? e).slice(0, 140)}`); break; }
          execFileSync('sleep', [String(wait)]);
        }
      }
      if (!doc2) { console.log(`TEACHER FAIL ${stem} chunk ${ci}`); continue; }
      const v = validate(doc2, engineById);
      allSections.push(...v.sections);
      fileDropped += v.droppedQ;
    }

    const labeled = allSections.reduce((a, s) => a + s.questions.length, 0);
    labeledQ += labeled;
    droppedQ += fileDropped;
    if (allSections.length === 0 && secs.length > 0) {
      // leave NO output so the next resumable pass retries this file
      console.log(`teacher ${done + 1}: ${stem} RETRY-LATER (0/${secs.length} sections survived)`);
      failed++;
      continue;
    }
    fs.writeFileSync(outPath, JSON.stringify({ file: stem, sections: allSections }, null, 1));
    console.log(`teacher ${done + 1}: ${stem} secs=${allSections.length}/${secs.length} q=${labeled} dropped=${fileDropped} chunks=${chunks.length}`);
    done++;
  }
  console.log(`teacher pass: labeled=${done} skipped=${skipped} failedChunks=${failed} questions=${labeledQ} droppedQ=${droppedQ} (${((Date.now() - t0) / 1000).toFixed(0)}s)`);
}

main();
