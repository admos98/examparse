/**
 * test_parseVerifier.mts — unit tests for the Jev parse-verification flow
 * (consensus gate over the parse itself).
 *
 * Run: npx tsx scripts/test_parseVerifier.mts   (from repo-parser/)
 *
 * Covers:
 *   1. buildVerificationSheet — whole word bank in state, per-question metadata,
 *      raw source from the parse trace (with a faithful round-trip fallback).
 *   2. questionVerifyKey — stable for identical parse shapes, sensitive to any
 *      judged axis (stem/type/mark/bank/context).
 *   3. assembleVerdict — accept band / flag band / uncertain band / unverified.
 *   4. verifyParse end-to-end with a STUBBED /api/judge: one-call contract,
 *      strict answer validation, HTTP failure fail-safety, cache behavior.
 *   5. applyParseVerdicts — immutability of the parsed document.
 *   6. acceptParseVerdictByHuman — the human override path.
 *   7. Trust-engine integration — flagged → contested + 'verify' finding;
 *      accepted clears 'no physical provenance'.
 *   8. sanitizeExam — verdicts and receipts survive the storage round-trip
 *      (including the previously-dropped jevReceipt).
 */

import {
  buildVerificationSheet,
  buildVerifyQuestions,
  questionVerifyKey,
  assembleVerdict,
  verifyParse,
  applyParseVerdicts,
  acceptParseVerdictByHuman,
  flaggedQuestions,
  SheetQuestion,
  SheetSection,
} from '../repo-parser/src/utils/parseVerifier';
import { computeTrust, applyTrust } from '../repo-parser/src/utils/trustEngine';
import { sanitizeExam } from '../repo-parser/src/utils/sanitizeExam';
import { serializeExamToText } from '../repo-parser/src/utils/examSerializer';
import {
  ExamDocument,
  JevJudgeReceipt,
  ParseVerdict,
  ParseVerifyReceipt,
} from '../repo-parser/src/types/exam';
import { JevConfig } from '../repo-parser/src/types/settings';

let pass = 0;
let fail = 0;
function ok(name: string, cond: boolean, extra = '') {
  if (cond) {
    pass++;
    console.log('  ok ', name);
  } else {
    fail++;
    console.log('  FAIL', name, extra);
  }
}

// ---------- fixtures ----------

const CFG: JevConfig = {
  enabled: false,
  baseUrl: '',
  apiKey: '',
  model: 'mock-judge',
  threshold: 0.9,
  lowBand: 0.2,
  batchSize: 20,
  judgeQuality: false,
  autoEscalate: false,
};

function mkDoc(): ExamDocument {
  return sanitizeExam({
    id: 'test-doc',
    filename: 'test.docx',
    parsedAt: new Date().toISOString(),
    header: {
      courseName: 'زبان انگلیسی',
      schoolName: 'دبیرستان تست',
      gradeAndMajor: 'دوازدهم',
      durationMinutes: 60,
      examDate: '03/10/17',
      district: 'district x',
      pageCount: 1,
    },
    sections: [
      {
        rowId: 'A',
        majorCategory: 'Vocabulary',
        title: 'Section A',
        englishInstruction: 'fill in the blanks with the words given.',
        markTotal: 4,
        hasWordBank: true,
        wordBank: ['careful', 'pollution', 'healthy', 'exercise', 'dangerous'],
        questions: [
          {
            id: 'q1',
            number: 1,
            displayNumber: '1',
            sectionRowId: 'A',
            type: 'word_bank_fill',
            stem: 'air ...... is bad for our health.',
            mark: 1,
            wordBankWords: ['pollution'],
          },
          {
            id: 'q2',
            number: 2,
            displayNumber: '2',
            sectionRowId: 'A',
            type: 'multiple_choice',
            stem: 'she ...... to school every day.',
            mark: 0.5,
            options: [
              { id: 'a', text: 'goes' },
              { id: 'b', text: 'go' },
            ],
          },
        ],
      },
    ],
    totalQuestions: 2,
    totalMarks: 1.5,
    anomalies: [],
    confidenceScore: 90,
    parseTrace: { lines: ['header line', 'A) vocabulary (4)', '[careful, pollution, healthy, exercise, dangerous]', '1. air ...... is bad for our health.', '2. she ...... to school every day. a) goes b) go'], rules: [], fallbackUsed: false },
  });
}

const META = { checkedAt: '2026-01-01T00:00:00.000Z', model: 'mock-judge', backend: 'llm-fallback' as const };

// Node has no IndexedDB; give the kv layer its localStorage fallback so the
// verdict cache behaves exactly like in the browser (kvSet -> localStorage).
const kvMem = new Map<string, string>();
(globalThis as any).localStorage = {
  getItem: (k: string) => (kvMem.has(k) ? kvMem.get(k)! : null),
  setItem: (k: string, v: string) => void kvMem.set(k, v),
  removeItem: (k: string) => void kvMem.delete(k),
};
const kvClear = () => kvMem.clear();

// ---------- 1. buildVerificationSheet ----------

console.log('\n[1] buildVerificationSheet');
{
  const doc = mkDoc();
  const build = buildVerificationSheet(doc);
  ok('source comes from parse-trace lines', build.source.includes('A) vocabulary (4)') && build.source.startsWith('header line'));
  ok('not marked reconstructed when trace exists', build.sourceReconstructed === false);
  ok('question count', build.questionCount === 2);

  const secA = build.sheet.sections[0];
  ok('whole word bank shipped once in the section state', JSON.stringify(secA.wordBank) === JSON.stringify(['careful', 'pollution', 'healthy', 'exercise', 'dangerous']));

  const q1 = secA.questions[0];
  ok('bank membership in metadata', q1.usesWordBank === true && q1.wordBankWords?.[0] === 'pollution');
  const q2 = secA.questions[1];
  ok('options serialized as joined letters', q2.options === 'a) goes | b) go');
  // Updated by the verdict-round robustness pass: a section-level bank does
  // NOT make every question a bank consumer — telling the judge otherwise was
  // a metadata lie that manufactured false "mismatch" flags. Bank membership
  // is now per-question truth (q2 is an MCQ answered independently).
  ok('bank-less question no longer claims bank membership', q2.usesWordBank === false);

  const noTrace = mkDoc();
  noTrace.parseTrace = undefined;
  const build2 = buildVerificationSheet(noTrace);
  ok('fallback source is the round-trip serialization', build2.sourceReconstructed === true && build2.source.includes('نام درس'));
}

// ---------- 2. questionVerifyKey ----------

console.log('\n[2] questionVerifyKey');
{
  const doc = mkDoc();
  const build = buildVerificationSheet(doc);
  const sec = build.sheet.sections[0];
  const item = sec.questions[0];
  const k1 = questionVerifyKey(item, sec, build.header);
  const k2 = questionVerifyKey(item, sec, build.header);
  ok('stable for identical inputs', k1 === k2 && k1.startsWith('jv1:'));

  const stemChanged: SheetQuestion = { ...item, stem: 'water ...... is bad for our health.' };
  ok('sensitive to stem', questionVerifyKey(stemChanged, sec, build.header) !== k1);

  const markChanged: SheetQuestion = { ...item, mark: 2 };
  ok('sensitive to mark (metadata axis)', questionVerifyKey(markChanged, sec, build.header) !== k1);

  const bankChanged: SheetSection = { ...sec, wordBank: ['careful', 'pollution'] };
  ok('sensitive to section word bank', questionVerifyKey(item, bankChanged, build.header) !== k1);

  const typeChanged: SheetQuestion = { ...item, type: 'fill_blank' };
  ok('sensitive to type', questionVerifyKey(typeChanged, sec, build.header) !== k1);

  // Bug-regression: the metadata axis judges the question NUMBER — a
  // renumbered question must NOT be served a stale cached verdict.
  const numberChanged: SheetQuestion = { ...item, number: '7' };
  ok('sensitive to question number', questionVerifyKey(numberChanged, sec, build.header) !== k1);
}

// ---------- 3. assembleVerdict ----------

console.log('\n[3] assembleVerdict');
{
  const allGood = assembleVerdict({ type: 0.97, separation: 0.95, metadata: 0.99 }, CFG, META);
  ok('all axes high -> accepted', allGood.verdict === 'accepted' && allGood.typeOk && allGood.separationOk && allGood.metadataOk);

  const typeBad = assembleVerdict({ type: 0.1, separation: 0.95, metadata: 0.99 }, CFG, META);
  ok('one axis clearly false -> flagged', typeBad.verdict === 'flagged' && !typeBad.typeOk);
  ok('flag note names the axis', (typeBad.note || '').includes('type') && (typeBad.note || '').includes('0.10'));

  const mid = assembleVerdict({ type: 0.5, separation: 0.97, metadata: 0.97 }, CFG, META);
  ok('mid band -> flagged as uncertain', mid.verdict === 'flagged' && (mid.note || '').includes('uncertain'));

  const missingAll = assembleVerdict({}, CFG, META);
  ok('no axes -> unverified', missingAll.verdict === 'unverified');

  const missingOne = assembleVerdict({ type: 0.97, separation: 0.97 }, CFG, META);
  ok('one missing axis -> unverified (never silently accepted)', missingOne.verdict === 'unverified');
}

// ---------- 4. verifyParse with stubbed /api/judge ----------

console.log('\n[4] verifyParse (stubbed judge)');
type FetchStub = (url: string, init: any) => Promise<any>;
async function withFetch<T>(stub: FetchStub, fn: () => Promise<T>): Promise<T> {
  const original = globalThis.fetch;
  (globalThis as any).fetch = stub;
  try {
    return await fn();
  } finally {
    globalThis.fetch = original;
  }
}

function judgeResponse(answers: Record<string, any>, usage = { promptTokens: 100, completionTokens: 10, totalTokens: 110 }) {
  return new Response(
    JSON.stringify({ success: true, backend: 'llm-fallback', model: 'mock-judge', answers, usage, calls: 1, warnings: [] }),
    { status: 200, headers: { 'Content-Type': 'application/json' } },
  );
}

{
  const doc = mkDoc();
  let callCount = 0;
  let capturedBody: any = null;
  kvClear();

  const result = await withFetch(async (url, init) => {
    callCount++;
    capturedBody = JSON.parse(init.body);
    ok('single call goes to /api/judge', url === '/api/judge');
    return judgeResponse({
      'h:header': { type: 'noul', p: 0.99 },
      't:q1': { type: 'noul', p: 0.97 },
      's:q1': { type: 'noul', p: 0.98 },
      'm:q1': { type: 'noul', p: 0.96 },
      't:q2': { type: 'noul', p: 0.3 },
      's:q2': { type: 'noul', p: 0.97 },
      'm:q2': { type: 'noul', p: 0.97 },
    });
  }, () => verifyParse(doc, CFG, { provider: 'gemini', model: 'mock' }));

  ok('ONE call for the whole sheet', callCount === 1 && result.receipt?.calls === 1);
  ok('state carries sheet + raw source', !!capturedBody.state.sheet && typeof capturedBody.state.source === 'string' && capturedBody.state.source.includes('A) vocabulary'));
  ok('word bank shipped in the state (whole bank)', JSON.stringify(capturedBody.state.sheet.sections[0].wordBank).includes('dangerous'));
  // M2 contract: 3 nouls per question + header + ONE `a:` Choice per bucket-A
  // item (q1 word-bank fill with scoped words + q2 MCQ = 2 answer axes).
  ok('3 nouls per question + header + a: answer Choices (M2)', Object.keys(capturedBody.questions).length === 2 * 3 + 1 + 2);
  const aq1 = capturedBody.questions['a:q1'];
  const aq2 = capturedBody.questions['a:q2'];
  ok('a: axis is a Choice over the item candidates (M2)', aq1?.type === 'choice' && aq2?.type === 'choice');
  ok('a:q1 candidates = scoped bank word (index-keyed)', aq1?.criteria && aq1.criteria['1'] === 'pollution');
  ok('a:q2 candidates = own options a/b', aq2?.criteria?.a === 'goes' && aq2?.criteria?.b === 'go');
  ok('native disabled -> provider config forwarded', !!capturedBody.providerConfig);

  const r1 = result.verdicts.get('q1');
  const r2 = result.verdicts.get('q2');
  ok('q1 accepted (parser + Jev agree)', r1?.verdict === 'accepted');
  ok('q2 flagged on the type axis', r2?.verdict === 'flagged' && r2.typeOk === false && r2.separationOk === true);
  ok('receipt tally', result.receipt?.accepted === 1 && result.receipt?.flagged === 1 && result.receipt?.questionsChecked === 2);
  ok('usage metered', result.receipt?.totalTokens === 110);
}

{
  // M2: `a:` picks are collected as AI DRAFTS (never correctAnswer), cached
  // under the verdict fingerprint suffix, and off-criteria picks are dropped.
  kvClear();
  const doc = mkDoc();
  const result = await withFetch(async () => judgeResponse({
    't:q1': { type: 'noul', p: 0.97 }, 's:q1': { type: 'noul', p: 0.97 }, 'm:q1': { type: 'noul', p: 0.97 },
    't:q2': { type: 'noul', p: 0.97 }, 's:q2': { type: 'noul', p: 0.97 }, 'm:q2': { type: 'noul', p: 0.97 },
    'a:q1': { type: 'choice', choice: '1' },
    'a:q2': { type: 'choice', choice: 'b' },
    'a:qX': { type: 'choice', choice: 'zzz' },
  }), () => verifyParse(doc, CFG, { provider: 'gemini', model: 'mock' }));
  ok('a: picks collected (q1 pollution, q2 go)', result.answers.get('q1')?.value === 'pollution' && result.answers.get('q2')?.value === 'go');
  ok('a: pick keys carry the option label', result.answers.get('q2')?.key === 'b' && result.answers.get('q1')?.key === '1');
  ok('receipt counts produced answers', result.receipt?.answersProduced === 2);
  ok('picks are NOT applied to correctAnswer by the verifier', !doc.sections[0].questions[1].correctAnswer);
  // Second run: verdicts cached AND picks cached — 0 fresh questions.
  const second = await withFetch(async () => { throw new Error('should not be called'); }, () =>
    verifyParse(doc, CFG, { provider: 'gemini', model: 'mock' }));
  ok('second run serves picks from cache (0 tokens)', second.answers.get('q1')?.value === 'pollution' && second.receipt?.answersFromCache === 2);
  ok('second run makes no wire call (all cached)', second.receipt?.calls === 0);
}

{
  // Fail-safe: HTTP 500 -> no verdicts, ok=false, warnings, no throw.
  kvClear();
  const doc = mkDoc();
  const result = await withFetch(async () => new Response(JSON.stringify({ error: 'judge down' }), { status: 500 }), () =>
    verifyParse(doc, CFG, { provider: 'gemini', model: 'mock' }),
  );
  ok('HTTP failure -> ok:false with no verdicts', result.ok === false && result.verdicts.size === 0);
  ok('HTTP failure surfaces a warning', result.warnings.some((w) => w.includes('HTTP 500')));
  ok('HTTP failure carries an ERROR (caller gates on !ok, never on !ok&&error)', typeof result.error === 'string' && result.error.length > 0);
}

{
  // Fail-safe: malformed answers -> unverified, never accepted.
  kvClear();
  const doc = mkDoc();
  const result = await withFetch(async () => judgeResponse({ 't:q1': { type: 'noul', p: 'banana' }, 's:q1': { type: 'noul', p: 1.7 }, 'm:q1': { type: 'noul', p: 0.97 } }), () =>
    verifyParse(doc, CFG, { provider: 'gemini', model: 'mock' }),
  );
  const v = result.verdicts.get('q1');
  ok('malformed/missing verdicts -> unverified', v?.verdict === 'unverified');
  ok('q2 gets no verdict at all -> unverified', result.verdicts.get('q2')?.verdict === 'unverified');

  // Bug-regression: 'unverified' verdicts must NOT be cached — a second run
  // must go back to the judge (the cache must not permanently poison them).
  let calls2 = 0;
  await withFetch(async () => {
    calls2++;
    return judgeResponse({
      't:q1': { type: 'noul', p: 0.97 }, 's:q1': { type: 'noul', p: 0.97 }, 'm:q1': { type: 'noul', p: 0.97 },
      't:q2': { type: 'noul', p: 0.97 }, 's:q2': { type: 'noul', p: 0.97 }, 'm:q2': { type: 'noul', p: 0.97 },
    });
  }, () => verifyParse(doc, CFG, { provider: 'gemini' }));
  ok('unverified verdicts were not cached (re-verified on the next run)', calls2 === 1);
}

{
  // Cache: fresh run = 1 call; a forced re-check then sends ONLY the forced
  // question because the rest are served from the (localStorage) cache.
  kvClear();
  const doc = mkDoc();
  let calls = 0;
  let capturedBody2: any = null;
  await withFetch(async () => {
    calls++;
    return judgeResponse({
      't:q1': { type: 'noul', p: 0.97 }, 's:q1': { type: 'noul', p: 0.97 }, 'm:q1': { type: 'noul', p: 0.97 },
      't:q2': { type: 'noul', p: 0.97 }, 's:q2': { type: 'noul', p: 0.97 }, 'm:q2': { type: 'noul', p: 0.97 },
    });
  }, () => verifyParse(doc, CFG, { provider: 'gemini' }));

  // kvSet now persists via the localStorage fallback, so run 2 reuses q2's
  // verdict (0 tokens) and only q1 rides in the forced call.
  ok('first run made exactly one call', calls === 1);

  const forced = await withFetch(async (url, init) => {
    calls++;
    capturedBody2 = JSON.parse(init.body);
    return judgeResponse({ 't:q1': { type: 'noul', p: 0.97 }, 's:q1': { type: 'noul', p: 0.97 }, 'm:q1': { type: 'noul', p: 0.97 } });
  }, () => verifyParse(doc, CFG, { provider: 'gemini' }, { forceIds: new Set(['q1']) }));
  const askedIds = Object.keys(capturedBody2.questions)
    .filter((k: string) => /^[tsm]:/.test(k))
    .map((k: string) => k.split(':')[1]);
  ok(
    'forced re-verify sends ONLY the requested question (+ shared header noul)',
    calls === 2 && askedIds.length === 3 && askedIds.every((id: string) => id === 'q1'),
  );
}

// ---------- 5. applyParseVerdicts immutability ----------

console.log('\n[5] applyParseVerdicts');
{
  const doc = mkDoc();
  const before = JSON.stringify(doc.sections[0].questions[0]);
  const verdicts = new Map<string, ParseVerdict>([
    ['q1', { typeOk: true, separationOk: true, metadataOk: true, verdict: 'accepted', checkedAt: META.checkedAt, model: 'm', backend: 'jev' }],
  ]);
  const receipt: ParseVerifyReceipt = {
    ranAt: META.checkedAt, backend: 'jev', model: 'm', questionsChecked: 1, cacheHits: 0, calls: 1,
    accepted: 1, flagged: 0, unverified: 0, promptTokens: 0, completionTokens: 0, totalTokens: 0, sourceChars: 10,
  };
  const next = applyParseVerdicts(doc, verdicts, receipt);
  ok('original document untouched', JSON.stringify(doc.sections[0].questions[0]) === before && (doc as any).parseVerifyReceipt === undefined);
  ok('verdict stamped on the right question', next.sections[0].questions[0].parseVerdict?.verdict === 'accepted');
  ok('receipt attached', next.parseVerifyReceipt?.questionsChecked === 1);
}

// ---------- 6. human override ----------

console.log('\n[6] acceptParseVerdictByHuman');
{
  const doc = mkDoc();
  const flagged: ParseVerdict = { typeOk: false, separationOk: true, metadataOk: true, verdict: 'flagged', note: 'type (p=0.10)', checkedAt: META.checkedAt, model: 'm', backend: 'jev' };
  const stamped = applyParseVerdicts(doc, new Map([['q1', flagged]]));
  ok('flaggedQuestions lists it before the override', flaggedQuestions(stamped).length === 1);
  const accepted = acceptParseVerdictByHuman(stamped, 'q1');
  const v = accepted.sections[0].questions[0].parseVerdict!;
  ok('human override -> accepted + humanReviewed', v.verdict === 'accepted' && v.humanReviewed === true);
  ok('queue empties after the override', flaggedQuestions(accepted).length === 0);
}

// ---------- 7. trust-engine integration ----------

console.log('\n[7] trustEngine integration');
{
  const doc = mkDoc();
  const flagged: ParseVerdict = { typeOk: false, separationOk: true, metadataOk: true, verdict: 'flagged', note: 'type (p=0.10)', checkedAt: META.checkedAt, model: 'm', backend: 'jev' };
  const withFlag = applyTrust(applyParseVerdicts(doc, new Map([['q1', flagged]])));
  const comp = computeTrust(withFlag);
  const q1 = withFlag.sections[0].questions[0];
  ok('flagged verdict -> contested', q1.trustLevel === 'contested');
  ok('verify finding emitted', comp.findings.some((f) => f.source === 'verify' && f.questionId === 'q1' && f.severity === 'error'));

  const accepted: ParseVerdict = { typeOk: true, separationOk: true, metadataOk: true, verdict: 'accepted', checkedAt: META.checkedAt, model: 'm', backend: 'jev' };
  const withAccept = applyTrust(applyParseVerdicts(doc, new Map([['q1', accepted]])));
  const comp2 = computeTrust(withAccept);
  ok('accepted verdict clears "no provenance" -> verified', withAccept.sections[0].questions[0].trustLevel === 'verified');
  ok('no verify findings for accepted', !comp2.findings.some((f) => f.source === 'verify'));

  // Low OCR confidence must SURVIVE an accepted verdict (same-bytes circularity).
  const ocrDoc = mkDoc();
  ocrDoc.sections[0].questions[0].provenance = { source: 'ocr', ocrConfidence: 30 };
  const withOcr = applyTrust(applyParseVerdicts(ocrDoc, new Map([['q1', accepted]])));
  ok('low OCR confidence survives acceptance (fail-safe)', withOcr.sections[0].questions[0].trustLevel === 'single');
}

// ---------- 8. sanitizer round-trip ----------

console.log('\n[8] sanitizeExam round-trip');
{
  const doc = mkDoc();
  const verdict: ParseVerdict = { typeOk: true, separationOk: true, metadataOk: false, verdict: 'flagged', note: 'metadata (p=0.30)', checkedAt: META.checkedAt, model: 'm', backend: 'jev', fingerprint: 'jv1:abc' };
  const receipt: ParseVerifyReceipt = {
    ranAt: META.checkedAt, backend: 'jev', model: 'm', questionsChecked: 2, cacheHits: 1, calls: 1,
    accepted: 1, flagged: 1, unverified: 0, promptTokens: 10, completionTokens: 2, totalTokens: 12, sourceChars: 500,
  };
  const jevReceipt: JevJudgeReceipt = {
    ranAt: META.checkedAt, backend: 'jev', model: 'm', judged: 2, cacheHits: 0, skipped: 0, calls: 1,
    escalated: 0, promptTokens: 1, completionTokens: 1, totalTokens: 2, threshold: 0.9,
  };
  const stamped: any = applyParseVerdicts(doc, new Map([['q1', verdict]]), receipt);
  stamped.jevReceipt = jevReceipt;
  const round = sanitizeExam(JSON.parse(JSON.stringify(stamped)));
  ok('parseVerdict survives sanitize', round.sections[0].questions[0].parseVerdict?.verdict === 'flagged' && round.sections[0].questions[0].parseVerdict?.note?.includes('metadata'));
  ok('parseVerifyReceipt survives sanitize', round.parseVerifyReceipt?.totalTokens === 12);
  ok('jevReceipt survives sanitize (was silently dropped before this fix)', !!round.jevReceipt && round.jevReceipt.judged === 2);
  ok('invalid verdict shape is dropped, not crashed on', sanitizeExam({ ...doc, sections: [{ ...doc.sections[0], questions: [{ ...doc.sections[0].questions[0], parseVerdict: { verdict: 'banana' } }] }] }).sections[0].questions[0].parseVerdict === undefined);
}

// ---------- 9. computeTrust/applyTrust level consistency ----------

console.log('\n[9] trust levels stay consistent between compute and stamp');
{
  const doc = mkDoc();
  // Bug-regression: the consensus reason string did not match applyTrust's
  // predicate -> summary said 'contested' while the chip said 'single'.
  const withConsensus = {
    ...doc,
    consensus: {
      ranAt: META.checkedAt,
      method: 'ocr_psm3_vs_psm6',
      agreementRate: 50,
      disagreements: 1,
      checks: [{ path: 'A/1', a: 'path a read', b: 'path b read', agree: false, similarity: 0.4 }],
    },
  };
  const comp = computeTrust(withConsensus as any);
  const stamped = applyTrust(withConsensus as any);
  const summaryContested = comp.summary.contested === 1;
  const chipContested = stamped.sections[0].questions[0].trustLevel === 'contested';
  ok('computeTrust counts the disagreement contested', summaryContested);
  ok('applyTrust stamps the SAME question contested (was: single)', chipContested);
}

// ---------- 10. serializer faithfulness guards ----------

console.log('\n[10] serializer guards (round-trip hardening)');
{
  // (a) inline_choice whose option text is regex-hostile must not throw.
  const docA = sanitizeExam({
    id: 's-a', filename: 'a.txt', parsedAt: new Date().toISOString(),
    header: { courseName: 'c', schoolName: 's', gradeAndMajor: 'g', durationMinutes: 60, examDate: 'd', district: 'x', pageCount: 1 },
    sections: [{
      rowId: 'A', majorCategory: 'Grammar', markTotal: 1,
      questions: [{
        id: 'q1', number: 1, displayNumber: '1', sectionRowId: 'A', type: 'inline_choice', mark: 1,
        stem: 'he ...... TV every night.',
        options: [{ id: '1', text: '1) watch' }, { id: '2', text: '2) watches' }],
      }],
    }],
    totalQuestions: 1, totalMarks: 1, anomalies: [], confidenceScore: 90,
  });
  let serA = '';
  let threw = false;
  try { serA = serializeExamToText(docA); } catch { threw = true; }
  ok('regex-hostile inline options do not throw', !threw);
  ok('inline choices re-embedded', serA.includes('( 1) watch / 2) watches )'));

  // (b) a REAL short passage that contains every bank word must survive.
  const docB = sanitizeExam({
    id: 's-b', filename: 'b.txt', parsedAt: new Date().toISOString(),
    header: { courseName: 'c', schoolName: 's', gradeAndMajor: 'g', durationMinutes: 60, examDate: 'd', district: 'x', pageCount: 1 },
    sections: [{
      rowId: 'A', majorCategory: 'Vocabulary', markTotal: 1, hasWordBank: true,
      wordBank: ['is', 'are', 'am'],
      questions: [{
        id: 'q1', number: 1, displayNumber: '1', sectionRowId: 'A', type: 'fill_blank', mark: 1, stem: 'I ...... a student.',
      }],
    }],
    totalQuestions: 1, totalMarks: 1, anomalies: [], confidenceScore: 90,
  });
  docB.sections[0].hasPassage = true;
  docB.sections[0].passageText = 'I am a student. My sisters are nurses. My father is a teacher.';
  const serB = serializeExamToText(docB);
  ok('real passage containing bank words survives', serB.includes('My father is a teacher'));

  // (c) a real passage opening like the TITLE (no instruction) must survive.
  const docC = sanitizeExam({
    id: 's-c', filename: 'c.txt', parsedAt: new Date().toISOString(),
    header: { courseName: 'c', schoolName: 's', gradeAndMajor: 'g', durationMinutes: 60, examDate: 'd', district: 'x', pageCount: 1 },
    sections: [{
      rowId: 'A', majorCategory: 'Reading', markTotal: 1, title: 'My Family',
      questions: [{
        id: 'q1', number: 1, displayNumber: '1', sectionRowId: 'A', type: 'short_answer', mark: 1, stem: 'what is the passage about?',
      }],
    }],
    totalQuestions: 1, totalMarks: 1, anomalies: [], confidenceScore: 90,
  });
  docC.sections[0].hasPassage = true;
  docC.sections[0].passageText = 'My family is big. We live in Bushehr.\nMy mother is a nurse.';
  const serC = serializeExamToText(docC);
  ok('title-like passage first line is NOT stripped (no instruction to mirror)', serC.includes('My family is big'));

  // (d) a legitimate instruction using a)/b) markers (no letter repeats) survives.
  const docD = sanitizeExam({
    id: 's-d', filename: 'd.txt', parsedAt: new Date().toISOString(),
    header: { courseName: 'c', schoolName: 's', gradeAndMajor: 'g', durationMinutes: 60, examDate: 'd', district: 'x', pageCount: 1 },
    sections: [{
      rowId: 'A', majorCategory: 'Reading', markTotal: 2,
      title: 'Section A: Reading.',
      englishInstruction: 'Read the passage, then write a) if the statement is true or b) if it is false.',
      questions: [{ id: 'q1', number: 1, displayNumber: '1', sectionRowId: 'A', type: 'true_false', mark: 1, stem: 'x' }],
    }],
    totalQuestions: 1, totalMarks: 1, anomalies: [], confidenceScore: 90,
  });
  const serD = serializeExamToText(docD);
  ok('legit a)/b) instruction is not treated as pollution', serD.includes('write a) if the statement is true'));

  // (e) a POLLUTED instruction (repeated marker cycle) falls back to the title.
  const docE = sanitizeExam({
    id: 's-e', filename: 'e.txt', parsedAt: new Date().toISOString(),
    header: { courseName: 'c', schoolName: 's', gradeAndMajor: 'g', durationMinutes: 60, examDate: 'd', district: 'x', pageCount: 1 },
    sections: [{
      rowId: 'الف', majorCategory: 'Vocabulary', markTotal: 1,
      title: 'Section الف: گزینه صحیح را انتخاب کنید.',
      persianInstruction: 'الف) گزینه صحیح را انتخاب کنید. (1) الف) علی ب) علی و حسن ج) حسن د) آنها الف) آن ب) این ج) آنها د) ما',
      questions: [{ id: 'q1', number: 1, displayNumber: '1', sectionRowId: 'الف', type: 'multiple_choice', mark: 0.5, stem: '...... به مدرسه رفت.', options: [{ id: 'a', text: 'علی' }, { id: 'b', text: 'حسن' }] }],
    }],
    totalQuestions: 1, totalMarks: 1, anomalies: [], confidenceScore: 90,
  });
  const serE = serializeExamToText(docE);
  ok('polluted instruction falls back to the clean title', serE.includes('الف) گزینه صحیح را انتخاب کنید. (1)') && !serE.includes('ب) علی و حسن ج) حسن د) آنها الف) آن'));
}

// ---------------------------------------------------------------------------
// 9. Verdict-round robustness: truthful bank metadata, unverified questions in
//    the validation queue, picture-OCR annotations in the verification source.
// ---------------------------------------------------------------------------
console.log('\n-- 9. verdict-round robustness (bank metadata truth, unverified queue, picture OCR) --');
{
  const doc = mkDoc();
  const build = buildVerificationSheet(doc);
  const secA = build.sheet.sections[0];
  const q1 = secA.questions.find((q) => q.id === 'q1')!;
  const q2 = secA.questions.find((q) => q.id === 'q2')!;

  ok('bank question keeps usesWordBank=true', q1.usesWordBank === true);
  ok('non-bank question in a bank section is usesWordBank=false (was a metadata lie)', q2.usesWordBank === false);

  const typed = buildVerifyQuestions([{ item: q1, sec: secA }, { item: q2, sec: secA }], { headerCourse: 'x', headerGrade: 'y' });
  ok('metadata question for the bank item says it draws from the bank', String(typed['m:q1'].instructions).includes('draws from that bank'));
  ok('metadata question for the non-bank item says it does NOT draw', String(typed['m:q2'].instructions).includes('does NOT draw from it'));
}

{
  const doc = mkDoc();
  const unv: ParseVerdict = {
    typeOk: false, separationOk: false, metadataOk: false,
    verdict: 'unverified', note: 'No verdict was returned for this question.',
    checkedAt: new Date().toISOString(), model: 'm', backend: 'jev',
  };
  const unvDoc = applyParseVerdicts(doc, new Map([['q1', unv]]), null);
  const queue = flaggedQuestions(unvDoc);
  ok('unverified verdict lands in the validation queue (fail-safe)', queue.length === 1 && queue[0].q.id === 'q1');

  const comp = computeTrust(unvDoc);
  ok('unverified produces a warning finding (visible, fail-safe)', comp.findings.some((f) => f.id === 'verify-q1' && f.severity === 'warning'));
  const trusted = applyTrust(unvDoc);
  const q1t = trusted.sections[0].questions.find((q) => q.id === 'q1')!;
  ok('unverified maps to SOFT trust (single), not contested', q1t.trustLevel === 'single');

  ok('human-accepted unverified question leaves the queue', flaggedQuestions(acceptParseVerdictByHuman(unvDoc, 'q1')).length === 0);

  const fl: ParseVerdict = {
    typeOk: true, separationOk: false, metadataOk: true,
    verdict: 'flagged', note: 'separation (p=0.10)',
    checkedAt: new Date().toISOString(), model: 'm', backend: 'jev',
  };
  const flDoc = applyParseVerdicts(doc, new Map([['q1', fl]]), null);
  ok('flagged verdict still queues', flaggedQuestions(flDoc).some((e) => e.q.id === 'q1'));
  ok('flagged verdict still maps to contested', applyTrust(flDoc).sections[0].questions.find((q) => q.id === 'q1')!.trustLevel === 'contested');
  ok('flagged finding keeps error severity', computeTrust(flDoc).findings.some((f) => f.id === 'verify-q1' && f.severity === 'error'));
}

{
  const doc = mkDoc();
  const withPics = { ...doc, pictureOcrNotes: ['[picture 1 OCR] a woman is packing a lunchbox'] } as ExamDocument;
  const build = buildVerificationSheet(withPics);
  ok('picture OCR annotations ride in the verification source', build.source.includes('[picture OCR annotations') && build.source.includes('packing a lunchbox'));
  ok('picture annotations produce a construction warning', build.warnings.some((w) => w.includes('embedded-picture')));

  const clean = sanitizeExam(withPics);
  ok('picture OCR notes survive the sanitize round-trip', Array.isArray(clean.pictureOcrNotes) && clean.pictureOcrNotes[0]!.includes('packing a lunchbox'));
  ok('documents without picture notes stay clean', sanitizeExam(doc).pictureOcrNotes === undefined);
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail > 0 ? 1 : 0);
