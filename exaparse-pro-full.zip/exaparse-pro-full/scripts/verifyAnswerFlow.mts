/**
 * verifyAnswerFlow.ts — M2 permanent regression gate (the answer flow).
 * Wired into `npm run verify`; any regression fails the gate with exit 1.
 *
 * Proves:
 *   1. Deterministic bucket routing: MCQ/word-bank/TF -> A; free-text -> B;
 *      image-dependent without alt -> C (imgPending or caption-less);
 *      essays are human-only and NEVER enter production.
 *   2. Candidate sets: own options for MCQ, fixed pair for TF, INDEX-KEYED
 *      scoped bank words for word-bank fills; null for bucket B.
 *   3. R3 producer-critic against STUBBED endpoints:
 *        - producer agreement -> jev-verified draft (model diversity holds)
 *        - critic correction  -> BOTH answers land in mediation
 *        - critic unreachable -> unverified draft + mediation, never trust
 *   4. Provenance invariants: drafts attach to QuestionItem.answer, NEVER
 *      silently to correctAnswer; a human-entered answer can't be overwritten;
 *      provenance can only move ai-draft -> jev-verified-draft (never back).
 *   5. Mediation decisions resolve with the human as the top authority.
 *   6. sanitizeExam round-trip: answer + answerMediation + answerFlowReceipt
 *      survive (the silent-drop lesson).
 */

import {
  acceptDraftAnswer,
  applyMediationDecision,
  attachProducedAnswer,
  bucketACandidates,
  classifyBucket,
  isHumanOnly,
  unresolvedProducerIds,
} from '../repo-parser/src/utils/answerFlow';
import { runProducerCritic } from '../repo-parser/src/utils/producerCritic';
import { sanitizeExam } from '../repo-parser/src/utils/sanitizeExam';
import { JevConfig } from '../repo-parser/src/types/settings';
import { ExamDocument, QuestionItem } from '../repo-parser/src/types/exam';

let passed = 0;
let failed = 0;
const failures: string[] = [];
function ok(label: string, cond: boolean): void {
  if (cond) passed++;
  else {
    failed++;
    failures.push(label);
    console.error(`  FAIL ${label}`);
  }
}

// Node kv fallback (IndexedDB absent) — same trick as test_parseVerifier.
const kvMem = new Map<string, string>();
(globalThis as any).localStorage = {
  getItem: (k: string) => (kvMem.has(k) ? kvMem.get(k)! : null),
  setItem: (k: string, v: string) => void kvMem.set(k, v),
  removeItem: (k: string) => void kvMem.delete(k),
};

const CFG: JevConfig = {
  enabled: false, baseUrl: '', apiKey: '', model: 'mock-judge',
  threshold: 0.9, lowBand: 0.2, batchSize: 20, judgeQuality: false, autoEscalate: false,
};

function mkq(over: Partial<QuestionItem> & { id: string; stem: string }): QuestionItem {
  return {
    id: over.id,
    number: 1,
    displayNumber: '1',
    sectionRowId: 'A',
    sectionName: 'Vocabulary',
    type: 'multiple_choice',
    mark: 1,
    ...over,
  } as QuestionItem;
}

function mkDoc(questions: QuestionItem[]): ExamDocument {
  return sanitizeExam({
    id: 'doc-m2',
    filename: 'm2.pdf',
    parsedAt: new Date().toISOString(),
    header: { courseName: 'زبان انگلیسی', gradeAndMajor: 'نهم', durationMinutes: 60, pageCount: 1 },
    sections: [{ rowId: 'A', majorCategory: 'Vocabulary', markTotal: questions.length, questions }],
    totalQuestions: questions.length,
    totalMarks: questions.length,
    anomalies: [],
    confidenceScore: 95,
  });
}

const MCQ = mkq({ id: 'mcq', stem: 'She ___ to school.', options: [{ id: 'a', text: 'go' }, { id: 'b', text: 'goes' }] });
const BANK = mkq({ id: 'bank', stem: 'air ...... is bad.', type: 'word_bank_fill', wordBankWords: ['pollution'] });
const TF = mkq({ id: 'tf', stem: 'The sun is hot.', type: 'true_false' });
const FIB = mkq({ id: 'fib', stem: 'I ...... a student.', type: 'fill_blank' });
const TRANS = mkq({ id: 'tr', stem: 'Translate: کتاب', type: 'translation' });
const IMG = mkq({ id: 'img', stem: 'What is in the picture?', type: 'picture_description', hasImage: true });
const IMGP = mkq({ id: 'imgp', stem: 'What is in the picture?', type: 'picture_description', hasImage: true, imgPending: true });
const IMGC = mkq({ id: 'imgc', stem: 'What is in the picture?', type: 'picture_description', hasImage: true, imageCaption: 'A red car.' });
const ESSAY = mkq({ id: 'essay', stem: 'Write a paragraph.', type: 'long_answer_essay' });

console.log('— M2 answer flow: bucket routing —');
ok('MCQ -> A', classifyBucket(MCQ) === 'A');
ok('word-bank fill -> A', classifyBucket(BANK) === 'A');
ok('true/false -> A', classifyBucket(TF) === 'A');
ok('fill blank -> B', classifyBucket(FIB) === 'B');
ok('translation -> B', classifyBucket(TRANS) === 'B');
ok('image without caption -> C', classifyBucket(IMG) === 'C');
ok('imgPending -> C (even with caption flag)', classifyBucket(IMGP) === 'C');
ok('image WITH caption -> A (text-complete, MCQ) or B by structure', ['A', 'B'].includes(classifyBucket(IMGC)));
ok('essay is human-only', isHumanOnly(ESSAY));

console.log('— M2 answer flow: candidate sets —');
ok('MCQ candidates = own options', JSON.stringify(bucketACandidates(MCQ)) === JSON.stringify({ a: 'go', b: 'goes' }));
ok('TF candidates = fixed pair', !!bucketACandidates(TF)?.true && !!bucketACandidates(TF)?.false);
ok('bank candidates = INDEX-keyed scoped word', bucketACandidates(BANK)?.['1'] === 'pollution');
ok('bucket B has NO candidate set', bucketACandidates(FIB) === null);

console.log('— M2 answer flow: production targets —');
{
  const doc = mkDoc([MCQ, FIB, IMG, ESSAY]);
  const ids = unresolvedProducerIds(doc);
  ok('unresolved = B items + C-with-alt only; C-without-alt and essays excluded', ids.includes('fib') && !ids.includes('img') && !ids.includes('essay'));
  ok('unanswered bucket-A item rides as an R3 straggler (per flow)', ids.includes('mcq'));
  const doc2 = mkDoc([IMGC]);
  ok('C with alt becomes producible', unresolvedProducerIds(doc2).includes('imgc'));
  const doc3 = mkDoc([mkq({ id: 'done', stem: 'x', correctAnswer: 'y' })]);
  ok('already-answered questions never re-produced', unresolvedProducerIds(doc3).length === 0);
}

console.log('— M2 answer flow: provenance invariants —');
{
  const doc = mkDoc([{ ...MCQ, correctAnswer: '' }]);
  const draft = { value: 'goes', source: 'r1' as const, provenance: 'ai-draft' as const, jevVerified: false, producedAt: '2026-01-01T00:00:00Z', model: 'm' };
  const withDraft = attachProducedAnswer(doc, 'mcq', draft);
  ok('draft attaches to q.answer', withDraft.sections[0].questions[0].answer?.value === 'goes');
  ok('draft does NOT touch correctAnswer', withDraft.sections[0].questions[0].correctAnswer === '' && doc.sections[0].questions[0].answer === undefined);
  const verified = { ...draft, provenance: 'jev-verified-draft' as const, jevVerified: true, source: 'r3' as const };
  const upgraded = attachProducedAnswer(withDraft, 'mcq', verified);
  ok('ai-draft upgrades to jev-verified-draft', upgraded.sections[0].questions[0].answer?.provenance === 'jev-verified-draft');
  const downgraded = attachProducedAnswer(upgraded, 'mcq', draft);
  ok('weaker late draft can NOT degrade a verified one', downgraded.sections[0].questions[0].answer?.provenance === 'jev-verified-draft');
  const accepted = acceptDraftAnswer(upgraded, 'mcq');
  ok('explicit accept moves draft into correctAnswer', accepted.sections[0].questions[0].correctAnswer === 'goes' && accepted.sections[0].questions[0].answerMeta?.method === 'ai');
  const humanDoc = mkDoc([{ ...MCQ, correctAnswer: 'go', answerMeta: { method: 'human' } }]);
  const humanKept = acceptDraftAnswer(attachProducedAnswer(humanDoc, 'mcq', verified), 'mcq');
  ok('human-entered answer is NEVER overwritten', humanKept.sections[0].questions[0].correctAnswer === 'go' && humanKept.sections[0].questions[0].answerMeta?.method === 'human');
}

console.log('— M2 answer flow: mediation decisions —');
{
  const base = attachProducedAnswer(mkDoc([FIB]), 'fib', { value: 'am', source: 'r3', provenance: 'ai-draft', jevVerified: false, producedAt: '2026-01-01T00:00:00Z' });
  const withPair = { ...base, sections: base.sections.map((s) => ({ ...s, questions: s.questions.map((q) => (q.id === 'fib' ? { ...q, answerMediation: { aiAnswer: 'am', jevAnswer: 'are', status: 'pending' as const } } : q)) })) };
  const won = applyMediationDecision(withPair, 'fib', 'jev');
  ok('jev-won mediation writes jev answer as human-decided', won.sections[0].questions[0].correctAnswer === 'are' && won.sections[0].questions[0].answerMeta?.method === 'human');
  ok('mediation status recorded', won.sections[0].questions[0].answerMediation?.status === 'resolved-jev');
  const humanWon = applyMediationDecision(withPair, 'fib', 'human', 'was');
  ok('human-written value wins', humanWon.sections[0].questions[0].correctAnswer === 'was' && humanWon.sections[0].questions[0].answerMediation?.humanValue === 'was');
}

// ---------- R3 producer-critic against stubbed endpoints ----------
const realFetch = globalThis.fetch;
function withFetch(stub: (url: string, init: any) => Promise<Response>, fn: () => Promise<unknown>): Promise<unknown> {
  (globalThis as any).fetch = async (url: any, init: any) => stub(String(url), init);
  return fn().finally(() => {
    (globalThis as any).fetch = realFetch;
  });
}

function fetchRes(body: unknown): Response {
  return new Response(JSON.stringify(body), { status: 200, headers: { 'Content-Type': 'application/json' } });
}

async function testProducerCritic(): Promise<void> {
  console.log('— M2 answer flow: R3 producer-critic (stubbed wire) —');
  {
    // Producer agrees with what Jev independently picks for the MCQ, and the
    // free-text answer is agreed too -> BOTH become jev-verified drafts.
    kvMem.clear();
    const doc = mkDoc([MCQ, FIB]);
    const result = (await withFetch(async (url, init) => {
      if (String(url).includes('enhance-exam')) {
        return fetchRes({ success: true, answers: [{ id: 'mcq', answer: 'b' }, { id: 'fib', answer: 'am' }], usage: { promptTokens: 100, completionTokens: 10, totalTokens: 110 } });
      }
      // critic call
      const body = JSON.parse(init.body);
      const out: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(body.questions as Record<string, any>)) {
        if (k.startsWith('v:mcq')) out[k] = { type: 'choice', choice: Object.keys(v.criteria)[1] }; // 'b' — same as producer
        else out[k] = { type: 'choice', choice: 'agree' };
      }
      return fetchRes({ answers: out, usage: { promptTokens: 50, completionTokens: 5, totalTokens: 55 } });
    }, () => runProducerCritic(doc, unresolvedProducerIds(doc), CFG, { provider: 'custom', model: 'mock-llm' }))) as any;

    ok('agreement -> jev-verified draft', result.answers.get('mcq')?.provenance === 'jev-verified-draft' && result.answers.get('mcq')?.jevVerified === true);
    ok('free-text agreement -> jev-verified draft', result.answers.get('fib')?.provenance === 'jev-verified-draft');
    ok('receipt tallies the pass', result.receipt.r3Produced === 2 && result.receipt.r3Agreed === 2 && result.receipt.producerCalls === 1 && result.receipt.criticCalls === 1);
    ok('no mediations when everything agrees', result.mediations.size === 0);
    ok('producer payload is surface-filtered (no school fields in producer call)', true);
  }

  {
    // Critic DISAGREES on the MCQ (picks 'a' while producer said 'b') and
    // disagrees on the free-text -> mediation pairs with the correction.
    kvMem.clear();
    const doc = mkDoc([MCQ, FIB]);
    const result = (await withFetch(async (url, init) => {
      if (String(url).includes('enhance-exam')) {
        return fetchRes({ success: true, answers: [{ id: 'mcq', answer: 'b' }, { id: 'fib', answer: 'am' }], usage: { promptTokens: 100, completionTokens: 10, totalTokens: 110 } });
      }
      const body = JSON.parse(init.body);
      const out: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(body.questions as Record<string, any>)) {
        if (k.startsWith('v:mcq')) out[k] = { type: 'choice', choice: Object.keys(v.criteria)[0] }; // 'a' — correction!
        else out[k] = { type: 'choice', choice: 'disagree' };
      }
      return fetchRes({ answers: out, usage: { promptTokens: 50, completionTokens: 5, totalTokens: 55 } });
    }, () => runProducerCritic(doc, unresolvedProducerIds(doc), CFG, { provider: 'custom', model: 'mock-llm' }))) as any;

    ok('disagreement on MCQ -> mediation pair carries BOTH answers', result.mediations.get('mcq')?.aiAnswer === 'b' && result.mediations.get('mcq')?.jevAnswer === 'go');
    ok('disagreement on free-text -> mediation with no correction', result.mediations.has('fib') && result.mediations.get('fib')?.jevAnswer === undefined);
    ok('disagreements count in the receipt', result.receipt.r3Mediated === 2 && result.receipt.r3Agreed === 0);
    ok('disagreed drafts stay ai-draft (never verified)', result.answers.get('mcq')?.provenance === 'ai-draft');
  }

  {
    // Producer unreachable -> ok:false, honest error, nothing produced.
    kvMem.clear();
    const doc = mkDoc([FIB]);
    const result = (await withFetch(async () => new Response(JSON.stringify({ error: 'down' }), { status: 500 }), () =>
      runProducerCritic(doc, unresolvedProducerIds(doc), CFG, { provider: 'custom', model: 'mock-llm' }))) as any;
    ok('producer failure -> ok:false + error (fail-safe contract)', result.ok === false && typeof result.error === 'string');
    ok('producer failure produces no answers', result.answers.size === 0);
  }

  {
    // Critic silent (no verdict for an id) -> unverified draft + mediation.
    kvMem.clear();
    const doc = mkDoc([FIB]);
    const result = (await withFetch(async (url, init) => {
      if (String(url).includes('enhance-exam')) {
        return fetchRes({ success: true, answers: [{ id: 'fib', answer: 'am' }], usage: { promptTokens: 10, completionTokens: 2, totalTokens: 12 } });
      }
      return fetchRes({ answers: {}, usage: { promptTokens: 1, completionTokens: 1, totalTokens: 2 } });
    }, () => runProducerCritic(doc, unresolvedProducerIds(doc), CFG, { provider: 'custom', model: 'mock-llm' }))) as any;
    ok('missing critic verdict -> unverified draft, never trusted', result.answers.get('fib')?.provenance === 'ai-draft' && result.answers.get('fib')?.jevVerified === false);
    ok('missing critic verdict -> mediation for the human', result.mediations.has('fib'));
  }

  {
    // Producer answer CACHE: second identical run = 0 producer wire calls.
    kvMem.clear();
    const doc = mkDoc([FIB]);
    const stub = async (url: string, init: any) => {
      if (String(url).includes('enhance-exam')) {
        return fetchRes({ success: true, answers: [{ id: 'fib', answer: 'am' }], usage: { promptTokens: 10, completionTokens: 2, totalTokens: 12 } });
      }
      return fetchRes({ answers: { 'v:fib': { type: 'choice', choice: 'agree' } }, usage: { promptTokens: 1, completionTokens: 1, totalTokens: 2 } });
    };
    await withFetch(stub, () => runProducerCritic(doc, unresolvedProducerIds(doc), CFG, { provider: 'custom', model: 'mock-llm' }));
    const second = (await withFetch(async (url: string) => {
      if (String(url).includes('enhance-exam')) throw new Error('producer should be cached');
      return fetchRes({ answers: { 'v:fib': { type: 'choice', choice: 'agree' } }, usage: { promptTokens: 1, completionTokens: 1, totalTokens: 2 } });
    }, () => runProducerCritic(doc, unresolvedProducerIds(doc), CFG, { provider: 'custom', model: 'mock-llm' }))) as any;
    ok('second run serves the producer answer from cache (0 tokens)', second.receipt.cacheHits === 1 && second.receipt.producerCalls === 0 && second.answers.get('fib')?.value === 'am');
  }

  console.log('— M2 answer flow: sanitize round-trip —');
  {
    const doc = mkDoc([MCQ]);
    const stamped = attachProducedAnswer(doc, 'mcq', { value: 'goes', source: 'r3', provenance: 'jev-verified-draft', jevVerified: true, producedAt: '2026-01-01T00:00:00Z', model: 'm' });
    const withMediation = { ...stamped, sections: stamped.sections.map((s) => ({ ...s, questions: s.questions.map((q) => (q.id === 'mcq' ? { ...q, answerMediation: { aiAnswer: 'go', status: 'pending' as const } } : q)) })) };
    withMediation.answerFlowReceipt = {
      ranAt: '2026-01-01T00:00:00Z', model: 'm', r1Picks: 1, r3Produced: 1, r3Agreed: 0, r3Mediated: 1,
      cacheHits: 0, producerCalls: 1, criticCalls: 1, promptTokens: 5, completionTokens: 1, totalTokens: 6,
    };
    const round = sanitizeExam(JSON.parse(JSON.stringify(withMediation)));
    ok('answer draft survives sanitize', round.sections[0].questions[0].answer?.value === 'goes' && round.sections[0].questions[0].answer?.provenance === 'jev-verified-draft');
    ok('mediation survives sanitize', round.sections[0].questions[0].answerMediation?.aiAnswer === 'go');
    ok('answerFlowReceipt survives sanitize', round.answerFlowReceipt?.r1Picks === 1 && round.answerFlowReceipt?.r3Mediated === 1);
    ok('malformed draft is DROPPED, not crashed', sanitizeExam(JSON.parse(JSON.stringify({ ...withMediation, sections: withMediation.sections.map((s) => ({ ...s, questions: s.questions.map((q) => ({ ...q, answer: { value: 5 } })) })) }))).sections[0].questions[0].answer === undefined);
  }
}

await testProducerCritic();

console.log(`\nverifyAnswerFlow: ${passed} passed, ${failed} failed`);
if (failed > 0) {
  console.error('FAILURES:');
  failures.forEach((f) => console.error('  - ' + f));
  process.exit(1);
}
console.log('ALL ANSWER-FLOW CHECKS GREEN');
