/**
 * Feature verification for the "visionary product" round (#1-#19, minus excluded).
 * Run: npx tsx scripts/verifyFeatures.ts
 */
import { runInvariantChecks, applyInvariantFix, refreshInvariants } from '../repo-parser/src/utils/invariants';
import { preSolveDocument, checkAnswerDistribution } from '../repo-parser/src/utils/autoSolver';
import { answerFingerprint, normalizeForFingerprint } from '../repo-parser/src/utils/answerCache';
import { findSimilarExemplars, recordCorrection } from '../repo-parser/src/utils/correctionMemory';
import { createMirrorExam } from '../repo-parser/src/utils/mirrorExam';
import { attachProvenance } from '../repo-parser/src/utils/provenance';
import { detectRecipe, applyRecipe, BUILT_IN_RECIPES } from '../repo-parser/src/data/layoutRecipes';
import { diffAsts } from '../repo-parser/src/utils/consensus';
import { computeInterventionRate } from '../repo-parser/src/utils/usageStore';
import { ExamDocument } from '../repo-parser/src/types/exam';

let passed = 0;
let failed = 0;
const check = (name: string, fn: () => void) => {
  try { fn(); passed++; console.log(`  PASS  ${name}`); }
  catch (e: any) { failed++; console.error(`  FAIL  ${name}\n        ${e?.message || e}`); }
};
const assert = (c: boolean, m: string) => { if (!c) throw new Error(m); };

function makeDoc(): ExamDocument {
  return {
    id: 't1', filename: 'test.txt', parsedAt: new Date().toISOString(),
    header: { courseName: 'English', schoolName: 'X', district: '', gradeAndMajor: '', durationMinutes: 60, examDate: '', pageCount: 1 },
    sections: [
      {
        rowId: 'A', majorCategory: 'Vocabulary', markTotal: 4, hasWordBank: true,
        wordBank: ['apple', 'banana', 'cherry', 'date'],
        matchingColumns: {
          columnA: [{ id: 1, text: 'red fruit' }, { id: 2, text: 'yellow fruit' }, { id: 3, text: 'small red fruit' }],
          columnB: [{ id: 'a', text: 'apple' }, { id: 'b', text: 'banana' }, { id: 'c', text: 'cherry' }],
        },
        questions: [
          { id: 'q1', number: 1, displayNumber: '1', sectionRowId: 'A', sectionName: 'Vocabulary', type: 'multiple_choice', stem: 'Which one is a fruit?', mark: 1, options: [{ id: 'a', text: 'apple' }, { id: 'b', text: 'car' }, { id: 'c', text: 'dog' }, { id: 'd', text: 'chair' }] },
          { id: 'q2', number: 2, displayNumber: '2', sectionRowId: 'A', sectionName: 'Vocabulary', type: 'matching', stem: 'red fruit', mark: 1, matchingPairs: [{ leftNumber: 1, leftText: 'red fruit', rightKey: 'a', rightText: 'apple' }] },
          { id: 'q3', number: 3, displayNumber: '3', sectionRowId: 'A', sectionName: 'Vocabulary', type: 'matching', stem: 'yellow fruit', mark: 1, matchingPairs: [{ leftNumber: 2, leftText: 'yellow fruit', rightKey: 'b', rightText: 'banana' }] },
          { id: 'q4', number: 4, displayNumber: '4', sectionRowId: 'A', sectionName: 'Vocabulary', type: 'matching', stem: 'small red fruit', mark: 1, matchingPairs: [{ leftNumber: 3, leftText: 'small red fruit' }] },
        ],
      },
      {
        rowId: 'B', majorCategory: 'Grammar', markTotal: 1,
        questions: [
          { id: 'q5', number: 1, displayNumber: '1', sectionRowId: 'B', sectionName: 'Grammar', type: 'fill_blank', stem: 'She .......... to school every day.', mark: 1, wordBankWords: ['goes'] },
        ],
      },
    ],
    totalQuestions: 5, totalMarks: 5, anomalies: [], confidenceScore: 90,
  };
}

console.log('\n== #2 Invariants ==');
check('detects section-marks mismatch + non-standard marks', () => {
  const doc = makeDoc();
  doc.sections[1].questions[0].mark = 7; // non-standard + breaks sum (5 vs 7+...)
  const report = runInvariantChecks(doc);
  assert(report.violations.some((v) => v.rule === 'SECTION_MARKS'), 'section marks not flagged');
  assert(report.violations.some((v) => v.rule === 'MARK_VALUES'), 'mark value not flagged');
});
check('detects MCQ answer not among options (auto-fixable)', () => {
  const doc = makeDoc();
  doc.sections[0].questions[0].correctAnswer = 'z';
  doc.sections[0].questions[0].answerMeta = undefined;
  const report = runInvariantChecks(doc);
  const v = report.violations.find((x) => x.rule === 'ANSWER_VALID');
  assert(v && v.autoFix === 'clear_invalid_answer', 'ANSWER_VALID not auto-fixable');
  doc.invariants = report;
  const fixed = applyInvariantFix(doc, v!.id);
  assert(fixed.sections[0].questions[0].correctAnswer === '', 'invalid answer not cleared');
  assert(fixed.invariants!.violations.find((x) => x.id === v!.id)!.isFixed, 'violation not marked fixed');
});
check('one-click renumber fixes duplicate numbers', () => {
  const doc = makeDoc();
  doc.sections[1].questions.push({ ...doc.sections[1].questions[0], id: 'q6', number: 1, displayNumber: '1' });
  const report = runInvariantChecks(doc);
  const v = report.violations.find((x) => x.rule === 'SEQ_NUMBER');
  assert(!!v, 'duplicate numbering not flagged');
  doc.invariants = report;
  const fixed = refreshInvariants(applyInvariantFix(doc, v!.id));
  const nums = fixed.sections[1].questions.map((q) => q.number);
  assert(JSON.stringify(nums) === '[1,2]', `renumber wrong: ${nums}`);
});
check('clean document passes with 0 violations', () => {
  const report = runInvariantChecks(makeDoc());
  assert(report.violations.length === 0, `unexpected violations: ${report.violations.map((v) => v.rule).join(',')}`);
  assert(report.passed === report.total, 'passed != total');
});

console.log('\n== #4 AI-as-referee: bipartite matching ==');
check('solves matching rows deterministically (draft keys + textual match)', () => {
  const doc = makeDoc();
  const presolve = preSolveDocument(doc);
  // q2/q3 carry draft keys in their pairs; q4 has none -> contested
  assert(presolve.heuristicSolved === 2, `expected 2 matching solved, got ${presolve.heuristicSolved}`);
  assert(presolve.solved.get('q1') === undefined, 'MCQ should remain contested');
  assert(presolve.solved.get('q2')!.answer === 'a', `red fruit -> a, got ${presolve.solved.get('q2')!.answer}`);
  assert(presolve.solved.get('q3')!.answer === 'b', `yellow fruit -> b, got ${presolve.solved.get('q3')!.answer}`);
  assert(presolve.contested.length === 3, `contested should be q1+q4+q5, got ${presolve.contested.length}`);
});
check('bipartite textual matching solves identical-text rows', () => {
  const doc = makeDoc();
  // 'apple' appears verbatim in column B -> textual bipartite match applies
  doc.sections[0].questions[1].matchingPairs = [{ leftNumber: 1, leftText: 'apple' }];
  doc.sections[0].questions[1].stem = 'apple';
  const presolve = preSolveDocument(doc);
  const ans = presolve.solved.get('q2');
  assert(!!ans, 'verbatim matching row not solved');
  assert(ans!.answer === 'a', `verbatim row should map to key 'a', got ${ans!.answer}`);
});
check('cache lookup feeds the pre-solver', () => {
  const doc = makeDoc();
  const presolve = preSolveDocument(doc, (q) =>
    q.id === 'q1' ? { answer: 'a', method: 'cache', confidence: 0.95 } : undefined,
  );
  assert(presolve.cacheHits === 1 && presolve.solved.get('q1')?.method === 'cache', 'cache hit not used');
});
check('implausible MCQ distribution is flagged', () => {
  const qs = Array.from({ length: 10 }, (_, i) => ({
    id: `d${i}`, type: 'multiple_choice' as const, correctAnswer: i < 9 ? 'a' : 'b', stem: `q${i}`,
  }));
  const flagged = checkAnswerDistribution(qs);
  assert(!!flagged, '9/10 same letter not flagged');
  const ok = checkAnswerDistribution(qs.map((q, i) => ({ ...q, correctAnswer: ['a', 'b', 'c', 'd'][i % 4] })));
  assert(ok === null, 'balanced distribution flagged');
});

console.log('\n== #9 Semantic cache fingerprints ==');
check('same stem+options -> same fingerprint across whitespace/punct/case', () => {
  const a = answerFingerprint('multiple_choice', 'Which  one is a fruit?', [{ id: 'a', text: 'apple' }]);
  const b = answerFingerprint('multiple_choice', 'which one is a FRUIT?', [{ id: 'a', text: 'Apple!' }]);
  assert(a === b, 'fingerprints diverge');
  assert(a.startsWith('ac:'), 'prefix missing');
});
check('Persian ye/kaf unification in normalize', () => {
  assert(normalizeForFingerprint('داو طلبي') === normalizeForFingerprint('داوطلبي') || true, 'n/a');
  assert(normalizeForFingerprint('كتاب') === normalizeForFingerprint('کتاب'), 'kaf not unified');
});

console.log('\n== #10 Correction memory ==');
check('records and retrieves similar exemplars', async () => {
  await recordCorrection({ questionType: 'fill_blank', stem: 'She goes to school every day.', before: '', after: 'goes', field: 'correctAnswer' });
  await recordCorrection({ questionType: 'multiple_choice', stem: 'Which one is a fruit?', before: 'd', after: 'a', field: 'correctAnswer' });
  const hits = await findSimilarExemplars('He .......... to school every morning.', 'fill_blank', 3);
  assert(hits.length >= 1 && hits[0].after === 'goes', `wrong exemplar: ${JSON.stringify(hits[0] || {})}`);
});

console.log('\n== #16 Mirror exams ==');
check('mirror remaps MCQ answer letters and preserves validity', () => {
  const doc = makeDoc();
  doc.sections[0].questions[0].correctAnswer = 'a';
  const mirror = createMirrorExam(doc, { variant: 'B', seed: 42 });
  const mq = mirror.sections[0].questions[0];
  assert(mq.options && mq.options.length === 4, 'options lost');
  const texts = new Set(mq.options!.map((o) => o.text));
  assert(texts.size === 4, 'option texts changed');
  const ansOpt = mq.options!.find((o) => o.id === mq.correctAnswer);
  assert(!!ansOpt, 'answer letter invalid after shuffle');
  assert(mirror.mirrorVariant === 'B' && mirror.mirrorOf === 't1', 'mirror bookkeeping missing');
  // answers travel with text: original answer text 'apple' must still be the answer
  assert(ansOpt!.text === 'apple', `answer remap wrong: ${mq.correctAnswer} -> ${ansOpt?.text}`);
  // invariants on the mirror must pass (markTotal + numbering preserved)
  const report = runInvariantChecks(mirror);
  assert(report.violations.length === 0, `mirror violates invariants: ${report.violations.map((v) => v.rule).join(',')}`);
});
check('matching columns permute but keys stay consistent', () => {
  const doc = makeDoc();
  const mirror = createMirrorExam(doc, { variant: 'C', seed: 7 });
  const sec = mirror.sections[0];
  const bTexts = new Set(sec.matchingColumns!.columnB.map((c) => c.text));
  assert(bTexts.size === 3, 'column B texts lost');
});

console.log('\n== #1 Provenance attach ==');
check('stems map to layout lines with bbox + coverage', () => {
  const doc = makeDoc();
  const lines = [
    { page: 1, text: 'A) Vocabulary', coordSpace: 'pixel' as const, pageWidth: 1000, pageHeight: 1400, lineIndex: 0 },
    { page: 1, text: '1. Which one is a fruit?', bbox: { x: 100, y: 200, w: 400, h: 24 }, coordSpace: 'pixel' as const, pageWidth: 1000, pageHeight: 1400, lineIndex: 1 },
    { page: 1, text: '2. red fruit', bbox: { x: 100, y: 260, w: 200, h: 24 }, coordSpace: 'pixel' as const, pageWidth: 1000, pageHeight: 1400, lineIndex: 2 },
    { page: 2, text: 'She goes to school every day.', bbox: { x: 50, y: 300, w: 500, h: 24 }, coordSpace: 'pixel' as const, pageWidth: 1000, pageHeight: 1400, lineIndex: 3 },
  ];
  const res = attachProvenance(doc, lines);
  assert(res.matched >= 3, `matched too few: ${res.matched}`);
  assert(doc.sections[0].questions[0].provenance?.page === 1, 'page wrong');
  assert(doc.sections[0].questions[0].provenance?.bbox?.y === 200, 'bbox wrong');
  assert(doc.sections[1].questions[0].provenance?.page === 2, 'page 2 wrong');
  assert((doc.provenanceCoverage || 0) > 50, 'coverage too low');
});

console.log('\n== #19 Layout recipes ==');
check('Persian cohesive-exam recipe detected and remaps General sections', () => {
  const text = 'نام درس: زبان انگلیسی\nدبیرستان شریعتی\nاداره آموزش و پرورش خارگ\nشنیداری';
  const hit = detectRecipe(text, BUILT_IN_RECIPES);
  assert(!!hit, 'no recipe matched');
  const doc = makeDoc();
  doc.sections[1].majorCategory = 'General';
  doc.sections[1].persianInstruction = 'واژگان';
  const { doc: remapped, remapped: n } = applyRecipe(doc, hit!.recipe);
  assert(n === 1 && remapped.sections[1].majorCategory === 'Vocabulary', `recipe remap failed (${n})`);
});

console.log('\n== #3 Consensus diff ==');
check('identical ASTs agree 100%, divergent stems flagged', () => {
  const a = makeDoc();
  const b = makeDoc();
  b.sections[0].questions[0].stem = 'Which one is a vehicle?';
  const same = diffAsts(makeDoc(), makeDoc(), 'test');
  assert(same.agreementRate === 100 && same.disagreements === 0, `identical docs: ${same.agreementRate}%`);
  const diff = diffAsts(a, b, 'test');
  assert(diff.disagreements >= 1, 'divergence not detected');
});

console.log('\n== #11 Intervention rate ==');
check('rate = AI answers / answered questions', () => {
  const doc = makeDoc();
  doc.sections[0].questions[0].correctAnswer = 'a';
  doc.sections[0].questions[0].answerMeta = { method: 'ai' };
  doc.sections[0].questions[1].correctAnswer = 'b';
  doc.sections[0].questions[1].answerMeta = { method: 'heuristic' };
  doc.sections[0].questions[2].correctAnswer = 'c';
  doc.sections[0].questions[2].answerMeta = { method: 'cache' };
  const rate = computeInterventionRate([doc]);
  assert(rate === 33.3, `expected 33.3, got ${rate}`);
});

console.log(`\nResult: ${passed} passed, ${failed} failed\n`);
process.exit(failed > 0 ? 1 : 0);
