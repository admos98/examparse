/**
 * Verification suite for the Jev judge + JSONL training-log round:
 *  A. jevJudge pure logic (fingerprint, cascade verdicts, selection, apply)
 *  B. trustEngine integration (jev verdicts drive trust levels + findings)
 *  C. sanitizeExam jev guard
 *  D. trainingLog gate / dedupe / schema / determinism
 * Run with: npx tsx scripts/verifyJev.ts
 */
import { jevFingerprint, verdictFromP, selectJudgable, countJudgable, applyJudgements } from '../repo-parser/src/utils/jevJudge';
import { computeTrust, applyTrust } from '../repo-parser/src/utils/trustEngine';
import { sanitizeExam } from '../repo-parser/src/utils/sanitizeExam';
import {
  isTrainingWorthy,
  collectTrainingLines,
  buildTrainingJsonl,
  countTrainingReady,
  trainingFingerprint,
} from '../repo-parser/src/utils/trainingLog';
import { ExamDocument, JevJudgement, QuestionItem } from '../repo-parser/src/types/exam';
import { DEFAULT_JEV_CONFIG } from '../repo-parser/src/types/settings';

let passed = 0;
let failed = 0;

function check(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  PASS  ${name}`);
  } catch (e: any) {
    failed++;
    console.error(`  FAIL  ${name}\n        ${e?.message || e}`);
  }
}

function assert(cond: boolean, msg: string) {
  if (!cond) throw new Error(msg);
}

const JEV: JevJudgement = (over: Partial<JevJudgement>): JevJudgement => ({
  verdict: 'correct',
  judgedAt: '2026-09-27T12:00:00.000Z',
  model: 'typesafe/jev-1.13',
  backend: 'jev',
  pCorrect: 0.97,
  ...over,
});

function makeDoc(): ExamDocument {
  return sanitizeExam({
    id: 'jev-test-exam',
    filename: 'test.pdf',
    parsedAt: '2026-09-27T10:00:00.000Z',
    schemaVersion: 3,
    header: { courseName: 'زبان انگلیسی', schoolName: 'دبیرستان تست', gradeAndMajor: 'دوازدهم', durationMinutes: 60, examDate: '01/01/01', district: '-', pageCount: 1 },
    totalQuestions: 4,
    totalMarks: 4,
    anomalies: [],
    confidenceScore: 99,
    parseStage: 'stage2_ai_solved',
    sections: [
      {
        rowId: 'A',
        majorCategory: 'Vocabulary',
        markTotal: 4,
        questions: [
          { id: 'A-q1', number: 1, displayNumber: '1', sectionRowId: 'A', sectionName: 'Vocabulary', type: 'multiple_choice', stem: 'She ......... to school every day.', mark: 1, correctAnswer: 'a', options: [{ id: 'a', text: 'goes' }, { id: 'b', text: 'go' }, { id: 'c', text: 'going' }, { id: 'd', text: 'gone' }], provenance: { source: 'pdf_text', page: 1 } },
          { id: 'A-q2', number: 2, displayNumber: '2', sectionRowId: 'A', sectionName: 'Vocabulary', type: 'multiple_choice', stem: 'The sun ......... in the east.', mark: 1, correctAnswer: 'b', options: [{ id: 'a', text: 'rise' }, { id: 'b', text: 'rises' }, { id: 'c', text: 'rising' }, { id: 'd', text: 'risen' }] },
          { id: 'A-q3', number: 3, displayNumber: '3', sectionRowId: 'A', sectionName: 'Vocabulary', type: 'multiple_choice', stem: '', mark: 1, correctAnswer: 'a', options: [{ id: 'a', text: 'x' }, { id: 'b', text: 'y' }] },
          { id: 'A-q4', number: 4, displayNumber: '4', sectionRowId: 'A', sectionName: 'Vocabulary', type: 'multiple_choice', stem: 'Water boils at 100 °C.', mark: 1, correctAnswer: '', options: [{ id: 'a', text: 'yes' }, { id: 'b', text: 'no' }] },
        ],
      },
    ],
  }) as ExamDocument;
}

console.log('\n== A1. jevFingerprint: stable, Persian-normalized ==');

check('same tuple → same fingerprint; normalization unifies ye/kaf', () => {
  const q1 = { stem: 'او به مدرسه مي‌رود', options: [{ id: 'a', text: 'مدرسه' }], correctAnswer: 'a' };
  const q2 = { stem: 'او به مدرسه می‌رود', options: [{ id: 'a', text: 'مدرسه' }], correctAnswer: 'a' };
  assert(jevFingerprint(q1) === jevFingerprint(q2), 'ye/kaf variants should fingerprint equal');
});

check('changed answer → different fingerprint (cache invalidated)', () => {
  const a = { stem: 'x', options: [] as any[], correctAnswer: 'a' };
  const b = { stem: 'x', options: [] as any[], correctAnswer: 'b' };
  assert(jevFingerprint(a) !== jevFingerprint(b), 'answer change must change fingerprint');
});

console.log('\n== A2. Confidence cascade bands ==');

check('threshold band: p >= threshold → correct', () => {
  assert(verdictFromP(0.9, DEFAULT_JEV_CONFIG) === 'correct', '0.9 should be correct');
  assert(verdictFromP(0.99, DEFAULT_JEV_CONFIG) === 'correct', '0.99 should be correct');
});
check('low band: p <= lowBand → incorrect', () => {
  assert(verdictFromP(0.2, DEFAULT_JEV_CONFIG) === 'incorrect', '0.2 should be incorrect');
  assert(verdictFromP(0.05, DEFAULT_JEV_CONFIG) === 'incorrect', '0.05 should be incorrect');
});
check('mid band → uncertain (escalate)', () => {
  assert(verdictFromP(0.5, DEFAULT_JEV_CONFIG) === 'uncertain', '0.5 should be uncertain');
  assert(verdictFromP(0.85, DEFAULT_JEV_CONFIG) === 'uncertain', '0.85 should be uncertain');
});

console.log('\n== A3. Selection: only what matters ==');

check('empty stems and unsolved questions are skipped', () => {
  const doc = makeDoc();
  const sel = selectJudgable(doc);
  assert(sel.selected.length === 2, `expected 2 judgable (q1,q2), got ${sel.selected.length}`);
  assert(sel.skipped === 2, `expected 2 skipped, got ${sel.skipped}`);
  assert(countJudgable(doc) === 2, 'countJudgable mismatch');
});

check('selection prioritizes contested/single first', () => {
  const doc = makeDoc();
  doc.sections[0].questions[1].trustLevel = 'single';
  doc.sections[0].questions[0].trustLevel = 'verified';
  const sel = selectJudgable(doc);
  assert(sel.selected[0].id === 'A-q2', 'single-trust question should come first');
});

console.log('\n== A4. applyJudgements: immutable stamping ==');

check('returns NEW doc; answers untouched (judge-only)', () => {
  const doc = makeDoc();
  const judgements = new Map<string, JevJudgement>([['A-q1', JEV({})]]);
  const next = applyJudgements(doc, judgements);
  assert(next !== doc, 'must return a new document');
  assert(next.sections[0].questions[0].jev?.verdict === 'correct', 'verdict not stamped');
  assert(next.sections[0].questions[0].correctAnswer === 'a', 'Jev must NEVER change the answer');
  assert(doc.sections[0].questions[0].jev === undefined, 'original doc mutated');
});

console.log('\n== B. trustEngine integration ==');

check('jev correct + provenance-backed → verified (strengthened)', () => {
  const doc = makeDoc();
  const judged = applyJudgements(doc, new Map([['A-q1', JEV({ verdict: 'correct', pCorrect: 0.96 })]]));
  const comp = computeTrust(judged);
  const stamped = applyTrust(judged, comp);
  const level = stamped.sections[0].questions[0].trustLevel;
  assert(level === 'verified', `expected verified, got ${level}`);
  assert(comp.summary.verified >= 1, 'summary not updated');
});

check('jev correct + provenance-backed + LOW OCR soft doubt → still verified', () => {
  const doc = makeDoc();
  doc.sections[0].questions[0].provenance = { source: 'ocr', page: 1, ocrConfidence: 40 };
  const judged = applyJudgements(doc, new Map([['A-q1', JEV({ verdict: 'correct', pCorrect: 0.96 })]]));
  const stamped = applyTrust(judged, computeTrust(judged));
  assert(stamped.sections[0].questions[0].trustLevel === 'verified', 'second opinion should counterbalance soft doubt');
});

check('jev incorrect → contested + error finding with Re-judge action', () => {
  const doc = makeDoc();
  const judged = applyJudgements(doc, new Map([['A-q1', JEV({ verdict: 'incorrect', pCorrect: 0.05 })]]));
  const comp = computeTrust(judged);
  const stamped = applyTrust(judged, comp);
  assert(stamped.sections[0].questions[0].trustLevel === 'contested', 'jev incorrect must be contested');
  const f = comp.findings.find((x) => x.source === 'jev' && x.questionId === 'A-q1');
  assert(!!f, 'jev finding missing');
  assert(f!.actions.some((a) => a.kind === 'rejudge'), 'Re-judge action missing');
  assert(f!.actions.some((a) => a.kind === 'open_question'), 'Open question action missing');
});

check('jev uncertain → single + warning finding', () => {
  const doc = makeDoc();
  const judged = applyJudgements(doc, new Map([['A-q2', JEV({ verdict: 'uncertain', pCorrect: 0.55 })]]));
  const comp = computeTrust(judged);
  const stamped = applyTrust(judged, comp);
  assert(stamped.sections[0].questions[1].trustLevel === 'single', 'uncertain should demote to single');
  const f = comp.findings.find((x) => x.source === 'jev' && x.questionId === 'A-q2');
  assert(!!f && f!.severity === 'warning', 'uncertain should produce a warning finding');
});

console.log('\n== C. sanitizeExam jev guard ==');

check('malformed jev shapes are dropped, valid ones kept', () => {
  const raw: any = makeDoc();
  raw.sections[0].questions[0].jev = { verdict: 'HACKED', model: 'x' };
  raw.sections[0].questions[1].jev = { verdict: 'correct', pCorrect: 0.98, judgedAt: '2026-09-27T12:00:00Z', model: 'jev', backend: 'jev' };
  const safe = sanitizeExam(raw);
  assert(safe.sections[0].questions[0].jev === undefined, 'invalid verdict must be dropped');
  assert(safe.sections[0].questions[1].jev?.pCorrect === 0.98, 'valid jev must be kept');
  assert(safe.sections[0].questions[1].jev?.verdict === 'correct', 'verdict kept');
});

console.log('\n== D. trainingLog: gate / dedupe / schema / determinism ==');

check('gate: only jev-confirmed or human-approved pass', () => {
  const doc = makeDoc();
  const qs = doc.sections[0].questions;
  qs[0].jev = JEV({ verdict: 'correct', pCorrect: 0.98 });
  qs[1].jev = JEV({ verdict: 'uncertain', pCorrect: 0.55 });
  assert(isTrainingWorthy(qs[0]) === true, 'jev correct should pass');
  assert(isTrainingWorthy(qs[1]) === false, 'uncertain must NOT pass');
  assert(isTrainingWorthy(qs[2]) === false, 'empty stem must NOT pass');
  assert(isTrainingWorthy(qs[3]) === false, 'unsolved must NOT pass');
});

check('gate: human-approved passes even without jev', () => {
  const doc = makeDoc();
  const qs = doc.sections[0].questions;
  qs[1].answerMeta = { method: 'human' };
  assert(isTrainingWorthy(qs[1]) === true, 'human-approved should pass');
  assert(isTrainingWorthy(qs[1], { gate: 'human_only' }) === true, 'human_only keeps human');
  qs[1].answerMeta = { method: 'ai' };
  assert(isTrainingWorthy(qs[1], { gate: 'human_only' }) === false, 'human_only blocks non-human');
});

check('gate: contested trust level never logged', () => {
  const doc = makeDoc();
  const qs = doc.sections[0].questions;
  qs[0].jev = JEV({ verdict: 'correct', pCorrect: 0.99 });
  qs[0].trustLevel = 'contested';
  assert(isTrainingWorthy(qs[0]) === false, 'contested must NOT pass even with jev correct');
});

check('messages variant: valid chat schema with meta', () => {
  const doc = makeDoc();
  doc.sections[0].questions[0].jev = JEV({ verdict: 'correct', pCorrect: 0.98, category: 'multiple_choice' });
  const { lines } = collectTrainingLines([doc]);
  assert(lines.length === 1, `expected 1 line, got ${lines.length}`);
  const obj = JSON.parse(lines[0]);
  assert(Array.isArray(obj.messages) && obj.messages.length === 3, 'messages must have 3 turns');
  assert(obj.messages[0].role === 'system' && obj.messages[1].role === 'user' && obj.messages[2].role === 'assistant', 'role order wrong');
  assert(obj.messages[2].content === 'a', 'assistant turn must carry the verified answer');
  assert(obj.meta.examId === 'jev-test-exam', 'meta.examId missing');
  assert(obj.meta.source === 'jev', 'meta.source wrong');
  assert(obj.meta.pCorrect === 0.98, 'meta.pCorrect missing');
  assert(typeof obj.meta.loggedAt === 'string' && obj.meta.loggedAt.length > 0, 'loggedAt missing');
});

check('instruction variant: {instruction,input,output} schema', () => {
  const doc = makeDoc();
  doc.sections[0].questions[0].jev = JEV({});
  const { lines } = collectTrainingLines([doc], { variant: 'instruction' });
  const obj = JSON.parse(lines[0]);
  assert(obj.instruction && obj.input && obj.output === 'a', 'instruction schema wrong');
  assert(obj.input.includes('goes') || obj.input.includes('go)'), 'input should include options');
});

check('dedupe: identical tuples across exams produce ONE row', () => {
  const doc = makeDoc();
  doc.sections[0].questions[0].jev = JEV({});
  const doc2 = sanitizeExam(JSON.parse(JSON.stringify({ ...doc, id: 'exam-2' })));
  assert(trainingFingerprint(doc.sections[0].questions[0]) === trainingFingerprint(doc2.sections[0].questions[0]), 'fingerprints must match across exams');
  const { lines, duplicates } = collectTrainingLines([doc, doc2]);
  assert(lines.length === 1, `expected 1 deduped line, got ${lines.length}`);
  assert(duplicates === 1, 'duplicate not counted');
});

check('determinism: same library → byte-identical JSONL (no wall-clock)', () => {
  const doc = makeDoc();
  doc.sections[0].questions[0].jev = JEV({});
  doc.sections[0].questions[1].answerMeta = { method: 'human' };
  const a = buildTrainingJsonl([doc]);
  const b = buildTrainingJsonl([doc]);
  assert(a === b, 'two exports of the same library must be byte-identical');
  assert(!a.endsWith('\n'), 'no trailing newline');
  const rows = a.split('\n');
  for (const r of rows) JSON.parse(r); // every line is valid JSON — throws otherwise
  assert(rows.every((r) => !r.endsWith(',')), 'no trailing commas');
  assert(countTrainingReady([doc]) === 2, 'countTrainingReady mismatch');
});

console.log(`\n========================================`);
console.log(`verifyJev: ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
