/**
 * verifyKeyFile.mts — answer-key-on-file regression gate (printed-key mode).
 * Wired into `npm run verify`; any regression fails the gate with exit 1.
 *
 * Proves (against HAND-BUILT fixture documents — never AI-generated):
 *   1. Pair extraction: "1.الف 2.ب", "۱-۳", "5 صحیح / 6 غلط", Persian digits,
 *      digit labels with REQUIRED separators (a bare "10" never splits into
 *      a phantom pair), prose never matches.
 *   2. Detection: trailing key-like run (>= 3 without a banner, >= 1 with a
 *      پاسخنامه/کلید banner in stems, section titles, or parse-trace lines).
 *   3. SEPARATION: key rows are REMOVED from the question list (metadata,
 *      never questions) — empty sections drop, totals recompute, the INPUT
 *      document is never mutated.
 *   4. MAPPING + validation: official provenance application, option-index
 *      bounds, true/false mapping, orphan/ambiguous/duplicate/skipped-
 *      existing/uncovered warnings — nothing is ever silently guessed.
 *   5. Flow integration: printed-key docs route ZERO questions to the R3
 *      producer, and buildVerificationSheet's skipAnswerAxis mode strips the
 *      a: candidate axis (Jev verifies separation + metadata only).
 *   6. sanitizeExam round-trips the report; the parse pipeline detects and
 *      applies a printed key END-TO-END from raw sheet text.
 */

import { applyAnswerKey, extractKeyEntries, findKeyRegion, looksLikeKeyRow, normalizeKeyDigits } from '../repo-parser/src/utils/answerKey';
import { buildVerificationSheet } from '../repo-parser/src/utils/parseVerifier';
import { unresolvedProducerIds } from '../repo-parser/src/utils/answerFlow';
import { sanitizeExam } from '../repo-parser/src/utils/sanitizeExam';
import { runParsePipeline } from '../repo-parser/src/utils/parsePipeline';
import { runInvariantChecks } from '../repo-parser/src/utils/invariants';
import { ExamDocument, ExamHeader, ExamSection, QuestionType } from '../repo-parser/src/types/exam';

let passed = 0;
let failed = 0;
const failures: string[] = [];

function ok(label: string, cond: boolean): void {
  if (cond) {
    passed++;
  } else {
    failed++;
    failures.push(label);
    console.error(`  FAIL ${label}`);
  }
}

const HEADER: ExamHeader = {
  courseName: 'زبان انگلیسی',
  durationMinutes: 60,
  examDate: '',
  schoolName: '',
  district: '',
  gradeAndMajor: 'پایه هفتم',
  pageCount: 1,
};

const OPTS = ['am', 'is', 'are', 'be'];
/** The parser's REAL option-id contract (parserEngine: String.fromCharCode(97+i)):
 *  correctAnswer must be the option ID, never the option text — the exact
 *  regression this gate exists to catch (build-14 blocker: keys stored "is"). */
const OPT_IDS = ['a', 'b', 'c', 'd'];

function mcq(id: string, number: number, correctIdx?: number, type: QuestionType = 'multiple_choice'): any {
  return {
    id,
    number,
    displayNumber: String(number),
    sectionRowId: 'A',
    sectionName: 'Vocabulary',
    type,
    stem: `Item ${number} ......... blank.`,
    options: OPT_IDS.map((oid, i) => ({ id: oid, text: OPTS[i] })),
    mark: 1,
    ...(correctIdx !== undefined
      ? { correctAnswer: OPT_IDS[correctIdx], answerMeta: { method: 'human' as const } }
      : {}),
  };
}

function keyRow(id: string, printed: number, stem: string): any {
  // Junk questions the parser builds from printed key rows: bare label stems,
  // RENUMBERED question numbers, the PRINTED number only in the parse id.
  return {
    id,
    number: 100 + printed,
    displayNumber: String(100 + printed),
    sectionRowId: 'K',
    sectionName: 'General',
    type: 'short_answer',
    stem,
    mark: 0,
  };
}

function doc(sections: ExamSection[], extra: Partial<ExamDocument> = {}): ExamDocument {
  return {
    id: 'exam-keytest',
    filename: 'key-test.txt',
    parsedAt: new Date().toISOString(),
    header: HEADER,
    sections,
    totalQuestions: sections.reduce((s, x) => s + x.questions.length, 0),
    totalMarks: sections.reduce((s, x) => s + x.markTotal, 0),
    anomalies: [],
    confidenceScore: 90,
    ...extra,
  };
}

const sec = (rowId: string, questions: any[], title?: string): ExamSection =>
  ({ rowId, majorCategory: 'General', title, markTotal: questions.reduce((s, q) => s + (q.mark || 0), 0), questions } as ExamSection);

async function main() {
  console.log('== A. Pair extraction ==');

  const e1 = extractKeyEntries(['1.الف 2.ب 3.ج 4.د']);
  ok('word-label pairs with dots parse in order', e1.length === 4 && e1[0].label === 'الف' && e1[3].label === 'د');
  ok('option indexes are 0-based (الف=0 … د=3)', e1[0].optionIndex === 0 && e1[1].optionIndex === 1 && e1[2].optionIndex === 2 && e1[3].optionIndex === 3);

  const e2 = extractKeyEntries([normalizeKeyDigits('۱-۳'), normalizeKeyDigits('۲-الف')]);
  ok('Persian digits + digit labels parse (۱-۳ -> option 3)', e2[0].number === 1 && e2[0].label === '3' && e2[0].optionIndex === 2 && e2[1].number === 2 && e2[1].label === 'الف');

  const e3 = extractKeyEntries(['5 صحیح', '6 غلط']);
  ok('true/false labels parse', e3.length === 2 && e3[0].label === 'صحیح' && e3[1].label === 'غلط');

  ok('a bare number NEVER splits into a phantom pair', extractKeyEntries(['10']).length === 0 && extractKeyEntries(['12 سال']).length === 0);

  ok('prose lines yield no pairs', extractKeyEntries(['She goes to school every day.']).length === 0);

  ok('looksLikeKeyRow: pure pair rows yes, prose no', looksLikeKeyRow('1.الف 2.ب 3.ج') && looksLikeKeyRow('1-الف 2-ب 3-ج') && !looksLikeKeyRow('She goes to school') && !looksLikeKeyRow('ب'));

  console.log('== B. Detection ==');
  {
    const d = doc([
      sec('A', [mcq('q-A-1-0', 1), mcq('q-A-2-2', 2), mcq('q-A-3-4', 3)]),
      sec('K', [keyRow('q-K-1-9', 1, 'ب'), keyRow('q-K-2-10', 2, 'ج'), keyRow('q-K-3-11', 3, 'الف')]),
    ]);
    const region = findKeyRegion(d);
    ok('trailing run of 3 key rows detected (pattern, no banner)', !!region && region.via === 'pattern' && region.questions.length === 3);
    ok('printed numbers recovered from parse ids (renumber-proof)', !!region && region.questions.map((k) => k.printed).join(',') === '1,2,3');

    const dBanner = doc(
      [
        sec('A', [mcq('q-A-1-0', 1), mcq('q-A-2-2', 2)]),
        sec('K', [keyRow('q-K-1-9', 1, 'ب'), keyRow('q-K-2-10', 2, 'ج')], 'پاسخنامه'),
      ],
    );
    const regionBanner = findKeyRegion(dBanner);
    ok('short run + section-title banner detected (via banner)', !!regionBanner && regionBanner.via === 'banner' && regionBanner.questions.length === 2);

    const dTrace = doc([sec('A', [mcq('q-A-1-0', 1), keyRow('q-K-1-9', 1, 'ب')])], { parseTrace: { lines: ['کلید آزمون', '1. ب'], rules: [], fallbackUsed: false } } as any);
    const regionTrace = findKeyRegion(dTrace);
    ok('banner in parse-trace lines + run of 1 detected', !!regionTrace && regionTrace.via === 'banner');

    const dReal = doc([sec('A', [mcq('q-A-1-0', 1), mcq('q-A-2-2', 2)])]);
    ok('a sheet without key rows detects nothing', findKeyRegion(dReal) === null);

    const dShort = doc([sec('A', [mcq('q-A-1-0', 1), keyRow('q-K-1-9', 1, 'ب')])]);
    ok('a lone bare-label row WITHOUT any banner is ignored (conservative)', findKeyRegion(dShort) === null);
  }

  console.log('== C. Separation (metadata, never questions) ==');
  let appliedDoc: ExamDocument | null = null;
  let original: ExamDocument | null = null;
  {
    original = doc([
      sec('A', [mcq('q-A-1-0', 1), mcq('q-A-2-2', 2), mcq('q-A-3-4', 3)]),
      sec('K', [keyRow('q-K-1-9', 1, 'ب'), keyRow('q-K-2-10', 2, 'ج'), keyRow('q-K-3-11', 3, 'الف')]),
    ]);
    const res = applyAnswerKey(original);
    appliedDoc = res.doc;
    ok('key rows removed from the question list', res.report !== null && res.report.removedQuestions === 3 && res.doc.totalQuestions === 3);
    ok('emptied key section dropped', res.doc.sections.length === 1 && res.doc.sections[0].rowId === 'A');
    ok('input document never mutated', original.sections.length === 2 && original.totalQuestions === 6 && original.sections[0].questions.every((q) => !q.correctAnswer));
    ok('report carries entries + via pattern', res.report!.via === 'pattern' && res.report!.entries.length === 3);
  }

  console.log('== D. Mapping + validation (option-ID contract) ==');
  {
    const res = applyAnswerKey(original!);
    const qs = res.doc.sections[0].questions;
    ok('1.ب -> option id "b" with official provenance (NEVER the text "is")', qs[0].correctAnswer === 'b' && qs[0].answerMeta?.method === 'official');
    ok('2.ج -> option id "c" official', qs[1].correctAnswer === 'c' && qs[1].answerMeta?.method === 'official');
    ok('3.الف -> option id "a" official', qs[2].correctAnswer === 'a' && qs[2].answerMeta?.method === 'official');
    ok('printed option TEXT preserved in the report entries', res.report!.entries.map((e) => e.optionText).join(',') === 'is,are,am');
    ok('every applied answer is one of its question\'s option ids (MCQ contract)', qs.every((q) => (q.options || []).some((o) => o.id === q.correctAnswer)));
    ok('nothing applied is left as a draft', qs.every((q) => !q.answer));
  }
  {
    const d = doc([
      sec('A', [mcq('q-A-1-0', 1), { ...mcq('q-A-4-10', 4), options: OPT_IDS.slice(0, 3).map((oid, i) => ({ id: oid, text: OPTS[i] })) }]),
      sec('K', [keyRow('q-K-1-9', 1, 'ب'), keyRow('q-K-4-11', 4, 'د'), keyRow('q-K-9-12', 9, 'الف')]),
    ]);
    const res = applyAnswerKey(d);
    const types = res.report!.warnings.map((w) => w.type);
    ok('out-of-range option label -> invalid-option warning', types.includes('invalid-option'));
    ok('key number with no question -> orphan-entry warning', types.includes('orphan-entry'));
  }
  {
    const d = doc([
      sec('A', [mcq('q-A-1-0', 1)]),
      sec('B', [mcq('q-B-1-0', 1)]),
      sec('K', [keyRow('q-K-1-9', 1, 'ب')], 'پاسخنامه'),
    ]);
    const res = applyAnswerKey(d);
    ok('repeated question numbers are AMBIGUOUS, never guessed', res.report !== null && res.report.warnings.some((w) => w.type === 'ambiguous-number') && res.report.applied === 0);
  }
  {
    const d = doc([sec('A', [mcq('q-A-1-0', 1)]), sec('K', [keyRow('q-K-1-9', 1, 'الف'), keyRow('q-K-1-10', 1, 'ب')], 'پاسخنامه')]);
    const res = applyAnswerKey(d);
    ok('duplicate entries: first wins, warning raised', res.report!.warnings.some((w) => w.type === 'duplicate-entry') && res.doc.sections[0].questions[0].correctAnswer === 'a');
  }
  {
    const d = doc([sec('A', [mcq('q-A-1-0', 1, 2)]), sec('K', [keyRow('q-K-1-9', 1, 'الف')], 'پاسخنامه')]);
    const res = applyAnswerKey(d);
    ok('human-entered answers are NEVER overwritten by the key', res.report!.warnings.some((w) => w.type === 'skipped-existing') && res.doc.sections[0].questions[0].correctAnswer === 'c' && res.doc.sections[0].questions[0].answerMeta?.method === 'human');
  }
  {
    const tf = (id: string, number: number): any => ({
      id, number, displayNumber: String(number), sectionRowId: 'A', sectionName: 'Grammar',
      type: 'true_false', stem: `Statement ${number}.`, mark: 1,
    });
    const d = doc([sec('A', [tf('q-A-1-0', 1), tf('q-A-2-2', 2)]), sec('K', [keyRow('q-K-1-9', 1, 'صحیح'), keyRow('q-K-2-10', 2, 'غلط')], 'پاسخنامه')]);
    const res = applyAnswerKey(d);
    const qs = res.doc.sections[0].questions;
    ok('true/false keys map to true/false values', qs[0].correctAnswer === 'true' && qs[1].correctAnswer === 'false' && qs.every((q) => q.answerMeta?.method === 'official'));
  }
  {
    const d = doc([sec('A', [mcq('q-A-1-0', 1), { ...mcq('q-A-2-2', 2), type: 'short_answer' as QuestionType, options: undefined }]), sec('K', [keyRow('q-K-1-9', 1, 'ب'), keyRow('q-K-2-10', 2, 'الف')], 'پاسخنامه')]);
    const res = applyAnswerKey(d);
    ok('key label on a non-MCQ question -> unmapped-type warning', res.report!.warnings.some((w) => w.type === 'unmapped-type'));
  }
  {
    const d = doc([sec('A', [mcq('q-A-1-0', 1), mcq('q-A-2-2', 2)]), sec('K', [keyRow('q-K-1-9', 1, 'ب')], 'پاسخنامه')]);
    const res = applyAnswerKey(d);
    ok('uncovered MCQs summarized (1 without key entry)', res.report!.warnings.some((w) => w.type === 'uncovered-questions' && w.message.includes('1 MCQ')));
  }

  console.log('== E. Flow integration ==');
  {
    ok('printed-key doc routes ZERO questions to the R3 producer', appliedDoc !== null && unresolvedProducerIds(appliedDoc!).length === 0);
    const withFlag = buildVerificationSheet(appliedDoc!, { skipAnswerAxis: true });
    const withoutFlag = buildVerificationSheet(appliedDoc!);
    const flagged = withFlag.sheet.sections.flatMap((s) => s.questions);
    const unflagged = withoutFlag.sheet.sections.flatMap((s) => s.questions);
    ok('skipAnswerAxis strips the a: candidate axis (verify-only mode)', flagged.every((q) => !q.candidates) && unflagged.some((q) => !!q.candidates));
  }

  console.log('== F. Serialization + pipeline end-to-end ==');
  {
    const clean = sanitizeExam(appliedDoc!);
    ok('sanitizeExam round-trips the printed-key report', !!clean.answerKeyOnFile && clean.answerKeyOnFile.detected === true && clean.answerKeyOnFile.applied === 3 && clean.answerKeyOnFile.entries.length === 3);
    ok('sanitizeExam keeps official answerMeta', clean.sections[0].questions[0].answerMeta?.method === 'official');
  }
  {
    const text = `نام درس: زبان انگلیسی
مدت آزمون: 60 دقیقه
1. He ......... a student.
الف) am  ب) is  ج) are  د) be
2. They ......... teachers.
الف) is  ب) am  ج) are  د) be
3. Birds ......... fly.
الف) can  ب) am  ج) is  د) be
کلید آزمون
1. ب
2. ج
3. الف
4. د`;
    const res = runParsePipeline({ rawText: text, filename: 'with-key.txt' });
    ok('pipeline parses the sheet with a key successfully', res.ok);
    if (res.ok) {
      const k = res.doc.answerKeyOnFile;
      ok('pipeline detects the printed key end-to-end', !!k && k.detected && k.via === 'banner');
      ok('key rows NEVER become questions (5 parsed rows -> 3 questions)', res.doc.totalQuestions === 3);
      const qs = res.doc.sections.flatMap((s) => s.questions);
      ok('official answers land on the right questions as OPTION IDS', qs.find((q) => q.number === 1)?.correctAnswer === 'b' && qs.find((q) => q.number === 2)?.correctAnswer === 'c' && qs.find((q) => q.number === 3)?.correctAnswer === 'a');
      ok('pipeline doc has ZERO ANSWER_VALID violations (the build-14 blocker class)', runInvariantChecks(res.doc).violations.filter((v) => v.rule === 'ANSWER_VALID').length === 0);
      ok('every pipeline MCQ answer is one of its option ids', qs.filter((q) => q.type === 'multiple_choice').every((q) => (q.options || []).some((o) => o.id === q.correctAnswer)));
      ok('orphan key entry (4.د) surfaces as a warning', !!k && k.warnings.some((w) => w.type === 'orphan-entry' && w.questionNumber === 4));
      ok('R3 producer skipped for the fully-keyed pipeline doc', unresolvedProducerIds(res.doc).length === 0);
    }
  }

  console.log(`\nAnswer key on file: ${passed} passed, ${failed} failed`);
  if (failed > 0) {
    console.error(failures.map((f) => ` - ${f}`).join('\n'));
    process.exit(1);
  }
}

main();
