/**
 * Verification suite for Ideas 1+2 (rule mining + mined templates).
 *
 * Covers:
 *   A. Template layer: fingerprinting, evidence-only matching, deterministic
 *      mining, non-mutating hints, trust findings, sanitize round-trip.
 *   B. Rule miner: DSL validation, ReDoS guard, document-anchored grounding,
 *      target check, corpus shadow run, promotion status, transitions,
 *      merge/dedupe, pipeline integration (parsePipeline with preParsed).
 *   C. Freshness: the committed MINED_TEMPLATES match a fresh corpus mine
 *      (skipped with a warning when the corpus dirs are absent).
 *
 * Run: npx tsx scripts/verifyMining.ts   (no network, no AI, no fs writes)
 */
import {
  fingerprintSection,
  matchSectionTemplates,
  mineTemplates,
  applyTemplateHints,
  MinedSectionInput,
  SectionTemplate,
} from '../repo-parser/src/utils/sectionTemplates';
import {
  isSafeRegex,
  validateMinedRule,
  groundExpectedParse,
  applyMinedRules,
  transitionRule,
  mergeMinedRules,
  runMiningPipeline,
  configureMinedRules,
  getActiveMinedRules,
  MiningCorpusEntry,
  MinedRule,
} from '../repo-parser/src/utils/ruleMiner';
import { gradeParse, GoldenGT } from '../repo-parser/src/utils/goldenGrade';
import { computeTrust } from '../repo-parser/src/utils/trustEngine';
import { sanitizeExam } from '../repo-parser/src/utils/sanitizeExam';
import { runParsePipeline } from '../repo-parser/src/utils/parsePipeline';
import { parseExamRawText } from '../repo-parser/src/utils/parserEngine';
import { ExamDocument, ExamSection, QuestionItem } from '../repo-parser/src/types/exam';
import { MINED_TEMPLATES } from '../repo-parser/src/data/minedTemplates';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Workspace root from this file's location (scripts/ sits one level under it)
// — no absolute machine paths; corpus-backed checks run wherever the data
// exists and skip cleanly when it does not (portable-gate contract).
const WS_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

let passed = 0;
let failed = 0;

function check(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  PASS  ${name}`);
  } catch (e: any) {
    failed++;
    console.error(`  FAIL  ${name}\n        ${e?.message || e}`);
  }
}

function assert(cond: boolean, msg: string) {
  if (!cond) throw new Error(msg);
}

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

function mkQ(n: number, type: string, stem: string, mark = 1, options?: { id: string; text: string }[]): QuestionItem {
  return {
    id: `q-${n}`,
    number: n,
    displayNumber: String(n),
    sectionRowId: 'A',
    sectionName: 'General',
    type: type as QuestionItem['type'],
    stem,
    mark,
    ...(options ? { options } : {}),
  } as QuestionItem;
}

function mkSection(id: string, questions: QuestionItem[], extra: Partial<ExamSection> = {}): ExamSection {
  return {
    rowId: id,
    majorCategory: 'General',
    markTotal: questions.reduce((s, q) => s + q.mark, 0),
    questions,
    ...extra,
  };
}

function mkDoc(sections: ExamSection[]): ExamDocument {
  return {
    id: 'doc-test',
    filename: 'test.docx',
    parsedAt: new Date().toISOString(),
    header: { courseName: 'زبان انگلیسی', durationMinutes: 60, examDate: '03/10/17', schoolName: 'دبیرستان', district: 'x', gradeAndMajor: 'نهم', pageCount: 1 },
    sections,
    totalQuestions: sections.reduce((s, x) => s + x.questions.length, 0),
    totalMarks: sections.reduce((s, x) => s + x.markTotal, 0),
    anomalies: [],
    confidenceScore: 99,
  } as ExamDocument;
}

const mcqOptions = [
  { id: 'a', text: 'book' },
  { id: 'b', text: 'pen' },
  { id: 'c', text: 'door' },
  { id: 'd', text: 'wall' },
];

function fixtureDocA(): ExamDocument {
  return mkDoc([
    mkSection('A', [1, 2, 3, 4, 5].map((n) => mkQ(n, 'multiple_choice', `Choose the best answer ${n}.`, 1, mcqOptions))),
    mkSection('B', [6, 7, 8].map((n) => mkQ(n, 'short_answer', `Answer the question UNIQUE-MARKER-STRING ${n}.`, 2))),
  ]);
}

function gtFromDoc(doc: ExamDocument, overrides?: (sec: ExamSection) => { cat?: string; t?: string }): GoldenGT {
  return {
    file: doc.filename,
    header: {},
    totalMarks: doc.totalMarks,
    sections: doc.sections.map((sec) => {
      const o = overrides ? overrides(sec) : {};
      return {
        id: sec.rowId,
        cat: o.cat || sec.majorCategory,
        mark: sec.markTotal,
        qs: sec.questions.map((q) => ({ n: q.number as number, t: o.t || q.type })),
      };
    }),
  };
}

const RAW_A = 'A) Choose the best answer.\n1) a 2) b 3) c 4) d 5) e\nB) Answer the questions.\n6) 7) 8)';

/** Expected-parse DSL uses `questions`, not the GT `qs` key. */
function expectedFromDoc(doc: ExamDocument, overrides?: (sec: ExamSection) => { cat?: string; t?: string }): Record<string, unknown> {
  return {
    header: {},
    totalMarks: doc.totalMarks,
    sections: doc.sections.map((sec) => {
      const o = overrides ? overrides(sec) : {};
      return {
        id: sec.rowId,
        cat: o.cat || sec.majorCategory,
        mark: sec.markTotal,
        questions: sec.questions.map((q) => ({ n: q.number as number, t: o.t || q.type })),
      };
    }),
  };
}

// ---------------------------------------------------------------------------
// A. Template layer
// ---------------------------------------------------------------------------

console.log('\n== A1. Template fingerprinting + matching ==');

const bankedClozeSection = mkSection('الف', [1, 2, 3, 4].map((n) => mkQ(n, 'word_bank_fill', `Fill in the blank ${n}.`, 1)), {
  wordBank: ['go', 'eat', 'run', 'sleep'],
  hasWordBank: true,
  passageText: 'Every morning I (1) ___ to school. My friend (2) ___ bread.',
});

check('fingerprint detects banked cloze shape', () => {
  const fp = fingerprintSection(bankedClozeSection);
  assert(fp.hasBank === true, 'hasBank');
  assert(fp.hasPassage === true, 'hasPassage');
  assert(fp.hasInlineBlanks === true, 'hasInlineBlanks');
  assert(fp.markPattern === 'uniform' && fp.uniformMark === 1, 'marks');
});

check('fingerprint detects MCQ grid shape', () => {
  const fp = fingerprintSection(fixtureDocA().sections[0]);
  assert(fp.hasOptions === true, 'hasOptions');
  assert(fp.uniformOptionCount === true, 'uniformOptionCount');
  assert(fp.hasBank === false, 'no bank');
});

check('matching is evidence-only and deterministic', () => {
  const templates: SectionTemplate[] = [
    { id: 'tpl-x', suggestsType: 'word_bank_fill', constraints: { hasBank: true, hasPassage: true, hasInlineBlanks: true }, countRange: [2, 8], weight: 0.8, provenance: { minedFrom: ['a'], minedAt: 't', version: 1 } },
    // tpl-y matches the same section on its single wildcard-ish constraint —
    // precise multi-constraint evidence (tpl-x) must outrank it.
    { id: 'tpl-y', suggestsType: 'multiple_choice', constraints: { hasBank: true }, countRange: [1, 10], weight: 0.6, provenance: { minedFrom: ['b'], minedAt: 't', version: 1 } },
  ];
  const fp = fingerprintSection(bankedClozeSection);
  const m1 = matchSectionTemplates(fp, bankedClozeSection.questions.length, templates);
  const m2 = matchSectionTemplates(fp, bankedClozeSection.questions.length, templates);
  assert(JSON.stringify(m1) === JSON.stringify(m2), 'non-deterministic matching');
  assert(m1[0].templateId === 'tpl-x', `expected tpl-x first, got ${m1[0]?.templateId}`);
  assert(m1[0].score > m1[1]?.score, 'stronger evidence must outrank');
});

check('count range soft-constraint halves the score', () => {
  const templates: SectionTemplate[] = [
    { id: 'tpl-in', suggestsType: 'word_bank_fill', constraints: { hasBank: true }, countRange: [2, 8], weight: 0.8, provenance: { minedFrom: [], minedAt: 't', version: 1 } },
    { id: 'tpl-out', suggestsType: 'word_bank_fill', constraints: { hasBank: true }, countRange: [50, 60], weight: 0.8, provenance: { minedFrom: [], minedAt: 't', version: 1 } },
  ];
  const fp = fingerprintSection(bankedClozeSection);
  const m = matchSectionTemplates(fp, 4, templates);
  assert(m[0].templateId === 'tpl-in', 'in-range template must win');
});

console.log('\n== A2. Mining determinism + hint application ==');

const corpusSections: MinedSectionInput[] = [];
for (let i = 0; i < 5; i++) {
  corpusSections.push({
    file: `exam-${i}.docx`,
    section: mkSection('الف', [1, 2, 3].map((n) => mkQ(n, 'word_bank_fill', `Fill ${n}.`, 1)), { wordBank: ['a', 'b', 'c'], passageText: 'x (1) ___ y' }),
  });
}
for (let i = 0; i < 3; i++) {
  corpusSections.push({
    file: `mcq-${i}.docx`,
    section: mkSection('A', [1, 2, 3, 4].map((n) => mkQ(n, 'multiple_choice', `Choose ${n}.`, 1, mcqOptions))),
  });
}

check('mining is deterministic and drops singletons', () => {
  const t1 = mineTemplates(corpusSections, '2026-01-01T00:00:00Z');
  const t2 = mineTemplates(corpusSections, '2026-01-01T00:00:00Z');
  assert(JSON.stringify(t1) === JSON.stringify(t2), 'mining not deterministic');
  assert(t1.length >= 2, `expected >= 2 clusters, got ${t1.length}`);
  const wb = t1.find((t) => t.suggestsType === 'word_bank_fill');
  const mcq = t1.find((t) => t.suggestsType === 'multiple_choice');
  assert(!!wb && !!mcq, 'missing expected clusters');
  assert(wb!.provenance.minedFrom.length === 5, 'provenance files lost');
  const singleton = mineTemplates([{ file: 'one.docx', section: mkSection('A', [mkQ(1, 'true_false', 'True or false?', 1)]) }]);
  assert(singleton.length === 0, 'singleton cluster must not become a template');
});

check('applyTemplateHints never mutates and never stamps', () => {
  const doc = fixtureDocA();
  const before = JSON.stringify(doc);
  const templates = mineTemplates(corpusSections, '2026-01-01T00:00:00Z');
  const hinted = applyTemplateHints(doc, templates);
  assert(JSON.stringify(doc) === before, 'applyTemplateHints mutated the input');
  assert(hinted !== doc, 'expected a new document object');
  for (const sec of hinted.sections) {
    for (const q of sec.questions) {
      assert(q.type === (doc.sections.find((s) => s.rowId === sec.rowId)!.questions.find((x) => x.number === q.number)!.type), 'type changed by hints');
    }
  }
  const empty = applyTemplateHints(doc, []);
  assert(empty === doc, 'empty template list must be an identity');
});

check('trust engine: template disagreement is advisory (info/warning), never a demotion', () => {
  const doc = mkDoc([
    mkSection('A', [1, 2].map((n) => mkQ(n, 'short_answer', `Answer ${n}.`, 1)), {
      templateHints: [{ templateId: 'tpl-x', suggestsType: 'multiple_choice', suggestsCategory: 'Grammar', score: 0.9 }],
    }),
    mkSection('B', [3, 4].map((n) => mkQ(n, 'short_answer', `Answer ${n}.`, 1)), {
      majorCategory: 'Vocabulary',
      templateHints: [{ templateId: 'tpl-y', suggestsType: 'matching', score: 0.6 }],
    }),
    mkSection('C', [5].map((n) => mkQ(n, 'short_answer', `Answer ${n}.`, 1)), {
      templateHints: [{ templateId: 'tpl-z', suggestsType: 'short_answer', score: 0.9 }],
    }),
  ]);
  const comp = computeTrust(doc);
  const tplFindings = comp.findings.filter((f) => f.source === 'template');
  assert(tplFindings.length === 2, `expected 2 template findings, got ${tplFindings.length}`);
  assert(tplFindings.find((f) => f.id === 'tpl-A')?.severity === 'warning', 'strong+General must warn');
  assert(tplFindings.find((f) => f.id === 'tpl-B')?.severity === 'info', 'weak+typed must stay info');
  assert(!comp.findings.find((f) => f.id === 'tpl-C'), 'agreeing template must stay silent');
  // Advisory: no question was demoted BECAUSE of the template finding.
  const aTrust = doc.sections[0].questions.map((q) => q.id);
  assert(comp.reasons.get(aTrust[0]) === undefined || !comp.reasons.get(aTrust[0])!.some((r) => r.includes('template')), 'template evidence leaked into trust reasons');
});

check('sanitize round-trip keeps template hints', () => {
  const doc = fixtureDocA();
  (doc.sections[0] as ExamSection).templateHints = [{ templateId: 'tpl-9', suggestsType: 'multiple_choice', score: 0.77 }];
  const clean = sanitizeExam(JSON.parse(JSON.stringify(doc)), 0) as ExamDocument;
  assert(Array.isArray(clean.sections[0].templateHints), 'hints dropped by sanitizer');
  assert(clean.sections[0].templateHints![0].templateId === 'tpl-9', 'hint content corrupted');
});

// ---------------------------------------------------------------------------
// B. Rule miner
// ---------------------------------------------------------------------------

console.log('\n== B1. DSL validation + ReDoS guard ==');

check('valid rule passes validation with deterministic id', () => {
  const v1 = validateMinedRule({ condition: { sectionRowId: 'B' }, action: { setType: 'true_false' }, rationale: 'x' }, { minedBy: 'ai', createdAt: 't' });
  const v2 = validateMinedRule({ condition: { sectionRowId: 'B' }, action: { setType: 'true_false' }, rationale: 'y' }, { minedBy: 'ai', createdAt: 't2' });
  assert(v1.ok && v2.ok, 'valid rule rejected');
  assert(v1.rule!.id === v2.rule!.id, 'id must be content-addressed, not random');
  assert(v1.rule!.status === 'proposed', 'new rules start proposed');
});

check('unscoped / malformed / off-whitelist rules are rejected', () => {
  const cases: [unknown, string][] = [
    [{ condition: {}, action: { setType: 'matching' } }, 'unscoped condition'],
    [{ condition: { sectionRowId: 'B' }, action: {} }, 'empty action'],
    [{ condition: { sectionRowId: 'B' }, action: { setType: 'made_up_type' } }, 'unknown type'],
    [{ condition: { sectionRowId: 'B' }, action: { setCategory: 'Chemistry' } }, 'unknown category'],
    [{ condition: { sectionRowId: 'B' }, action: { setMark: -3 } }, 'negative mark'],
    [{ condition: { sectionRowId: 'B' }, action: { setMark: 999 } }, 'oversized mark'],
    [{ condition: { sectionRowId: 'B', questionNumbers: [0, 1] }, action: { setType: 'matching' } }, 'question number 0'],
  ];
  for (const [rule, label] of cases) {
    const v = validateMinedRule(rule, { minedBy: 'ai', createdAt: 't' });
    assert(!v.ok, `${label} should be rejected`);
  }
  // Over-long rationale is TRUNCATED, not rejected (slicing never wastes the
  // one billable call on cosmetics).
  const truncated = validateMinedRule(
    { condition: { sectionRowId: 'B' }, action: { setType: 'matching' }, rationale: 'x'.repeat(700) },
    { minedBy: 'ai', createdAt: 't' },
  );
  assert(truncated.ok && truncated.rule!.rationale!.length === 600, 'rationale not capped at 600');
});

check('ReDoS guard rejects nested quantifiers, caps length, still allows normal patterns', () => {
  assert(!isSafeRegex('(a+)+$').ok, '(a+)+ must be rejected');
  assert(!isSafeRegex('(a|aa)+$').ok, '(a|aa)+ must be rejected');
  assert(!isSafeRegex('x'.repeat(200)).ok, 'overlong pattern must be rejected');
  assert(!isSafeRegex('([').ok, 'invalid pattern must be rejected');
  assert(isSafeRegex('unique-marker').ok, 'plain words must pass');
  assert(isSafeRegex('^(?:find|correct)\\w*\\s+mistakes?').ok, 'realistic pattern must pass');
});

console.log('\n== B2. Grounding (self-fulfilling-grader guard) ==');

check('expected parse anchored in the document grounds fine', () => {
  const g = groundExpectedParse(
    { totalMarks: 11, sections: [{ id: 'A', cat: 'General', mark: 5, questions: [{ n: 1, t: 'multiple_choice' }, { n: 2, t: 'multiple_choice' }, { n: 3, t: 'multiple_choice' }, { n: 4, t: 'multiple_choice' }, { n: 5, t: 'multiple_choice' }] }, { id: 'B', cat: 'General', mark: 6, questions: [{ n: 6, t: 'short_answer' }, { n: 7, t: 'short_answer' }, { n: 8, t: 'short_answer' }] }] },
    RAW_A,
  );
  assert(g.ok, `valid expected parse rejected: ${g.errors.join('; ')}`);
});

check('fabricated question numbers are rejected (not in the document)', () => {
  const g = groundExpectedParse(
    { sections: [{ id: 'A', cat: 'General', mark: 5, questions: [{ n: 21, t: 'multiple_choice' }, { n: 22, t: 'multiple_choice' }, { n: 23, t: 'multiple_choice' }] }] },
    RAW_A,
  );
  assert(!g.ok, 'unanchored expected parse must be rejected');
  assert(g.errors.some((e) => e.includes('not grounded')), 'missing grounding reason');
});

check('mark arithmetic must add up', () => {
  const g = groundExpectedParse(
    { totalMarks: 99, sections: [{ id: 'A', cat: 'General', mark: 5, questions: [{ n: 1, t: 'multiple_choice' }] }] },
    RAW_A,
  );
  assert(!g.ok && g.errors.some((e) => e.includes('do not add up')), 'marks-sum violation missed');
});

check('Persian digits in the raw text anchor Persian-numbered expectations', () => {
  const g = groundExpectedParse(
    { sections: [{ id: 'الف', cat: 'Vocabulary', mark: 2, questions: [{ n: 1, t: 'word_bank_fill' }, { n: 2, t: 'word_bank_fill' }] }] },
    'الف) جاهای خالی\n۱) ...\n۲) ...',
  );
  assert(g.ok, `Persian-digit grounding failed: ${g.errors.join('; ')}`);
});

check('decreasing question numbers are rejected', () => {
  const g = groundExpectedParse(
    { sections: [{ id: 'A', cat: 'General', mark: 2, questions: [{ n: 5, t: 'multiple_choice' }, { n: 3, t: 'multiple_choice' }] }] },
    RAW_A,
  );
  assert(!g.ok && g.errors.some((e) => e.includes('strictly increasing')), 'monotonicity missed');
});

console.log('\n== B3. applyMinedRules (the mined layer) ==');

check('empty or non-live rule list is a perfect identity', () => {
  const doc = fixtureDocA();
  const out1 = applyMinedRules(doc, []);
  const out2 = applyMinedRules(doc, [{ ...validRule(), status: 'retired' }]);
  assert(out1 === doc && out2 === doc, 'identity broken');
});

check('live rule re-types and re-categorizes only inside its scope', () => {
  const doc = fixtureDocA();
  const rule: MinedRule = {
    ...validRule(),
    status: 'live',
    condition: { sectionRowId: 'B' },
    action: { setType: 'true_false', setCategory: 'Reading' },
  };
  const out = applyMinedRules(doc, [rule]);
  assert(out !== doc, 'expected a new document');
  assert(out.sections[1].questions.every((q) => q.type === 'true_false'), 'B not re-typed');
  assert(out.sections[1].majorCategory === 'Reading', 'B category not set');
  assert(out.sections[0].questions.every((q) => q.type === 'multiple_choice'), 'section A must be untouched');
  assert(doc.sections[1].questions[0].type === 'short_answer', 'INPUT WAS MUTATED');
});

check('questionNumbers and stemRegex scopes work; template-scope composes with hints', () => {
  const doc = fixtureDocA();
  const nums = applyMinedRules(doc, [{ ...validRule(), status: 'live', condition: { sectionRowId: 'A', questionNumbers: [2, 4] }, action: { setMark: 2 } }]);
  assert(nums.sections[0].questions[1].mark === 2 && nums.sections[0].questions[3].mark === 2, 'questionNumbers scope broken');
  assert(nums.sections[0].questions[0].mark === 1, 'out-of-scope mark changed');

  const stem = applyMinedRules(doc, [{ ...validRule(), status: 'live', condition: { stemRegex: 'UNIQUE-MARKER-STRING' }, action: { setType: 'true_false' } }]);
  assert(stem.sections[1].questions.every((q) => q.type === 'true_false'), 'stemRegex scope broken');
  assert(stem.sections[0].questions.every((q) => q.type === 'multiple_choice'), 'stemRegex bled into section A');

  const hintedDoc = applyTemplateHints(fixtureDocA(), [
    { id: 'tpl-h', suggestsType: 'multiple_choice', constraints: { hasOptions: true }, countRange: [1, 99], weight: 0.9, provenance: { minedFrom: [], minedAt: 't', version: 1 } },
  ]);
  const composed = applyMinedRules(hintedDoc, [{ ...validRule(), status: 'live', condition: { suggestsTypeFromTemplate: 'multiple_choice' }, action: { setCategory: 'Grammar' } }]);
  assert(composed.sections[0].majorCategory === 'Grammar', 'template-scoped condition did not fire');
  assert(composed.sections[1].majorCategory === 'General', 'template scope leaked to section B');
});

function validRule(): MinedRule {
  return validateMinedRule({ condition: { sectionRowId: 'B' }, action: { setType: 'true_false' } }, { minedBy: 'hand', createdAt: 't' }).rule!;
}

console.log('\n== B4. Pipeline gates (validate -> ground -> target -> shadow -> promote) ==');

const docA = fixtureDocA();
const stubParse = (text: string): ExamDocument => {
  if (text === RAW_A) return fixtureDocA();
  if (text.startsWith('CORPUS-')) {
    const i = parseInt(text.slice('CORPUS-'.length), 10);
    return mkDoc([mkSection('A', [1, 2, 3].map((n) => mkQ(n, i % 2 ? 'fill_blank' : 'short_answer', `Corpus question ${n}.`, 1)))] as ExamSection[]);
  }
  throw new Error('unexpected text');
};
const corpusOf = (n: number): MiningCorpusEntry[] =>
  Array.from({ length: n }, (_, i) => ({
    name: `corpus-${i}.docx`,
    text: `CORPUS-${i}`,
    gt: gtFromDoc(stubParse(`CORPUS-${i}`)),
  }));

check('gate 1: invalid proposals are rejected before any grading', () => {
  const r = runMiningPipeline({
    rawText: RAW_A,
    proposal: { rule: { condition: {}, action: { setType: 'nope' } }, expectedParse: {} },
    parseFn: stubParse,
    corpus: corpusOf(20),
  });
  assert(!r.ok && r.errors && r.errors.length > 0, 'invalid proposal not rejected');
});

check('gate 2: ungrounded expected parse is rejected (self-fulfilling guard)', () => {
  const r = runMiningPipeline({
    rawText: RAW_A,
    proposal: {
      rule: { condition: { sectionRowId: 'B' }, action: { setType: 'true_false' }, rationale: 'they are T/F' },
      expectedParse: { sections: [{ id: 'B', cat: 'General', mark: 6, questions: [{ n: 31, t: 'true_false' }] }] },
    },
    parseFn: stubParse,
    corpus: corpusOf(20),
  });
  assert(!r.ok && (r.errors || []).some((e) => e.includes('grounded')), 'ungrounded proposal slipped through');
});

check('gate 3: a rule that does not achieve its claimed fix is rejected', () => {
  const r = runMiningPipeline({
    rawText: RAW_A,
    proposal: {
      rule: { condition: { sectionRowId: 'B' }, action: { setType: 'true_false' } },
      // expectedParse claims multiple_choice but the rule sets true_false.
      expectedParse: expectedFromDoc(fixtureDocA(), (sec) => (sec.rowId === 'B' ? { t: 'multiple_choice' } : {})),
    },
    parseFn: stubParse,
    corpus: corpusOf(20),
  });
  assert(!r.ok && (r.error || '').includes('does not achieve'), 'target check missed the lie');
});

check('gate 4: a rule that regresses one golden exam is rejected with file names', () => {
  const wide = validateMinedRule({ condition: { sectionRowId: 'A' }, action: { setType: 'true_false' } }, { minedBy: 'ai', createdAt: 't' }).rule!;
  // The rule hits section A of every even corpus entry (fill_blank -> true_false).
  const r = runMiningPipeline({
    rawText: RAW_A,
    proposal: { rule: wide, expectedParse: expectedFromDoc(fixtureDocA(), (sec) => (sec.rowId === 'A' ? { t: 'true_false' } : {})) },
    parseFn: stubParse,
    corpus: corpusOf(20),
  });
  assert(!r.ok && (r.error || '').includes('regresses'), 'regressing rule accepted');
  assert((r.shadow?.regressions.length || 0) > 0, 'no regression files reported');
});

check('gate 5a: all green + full corpus -> rule auto-promotes to live', () => {
  const r = runMiningPipeline({
    rawText: RAW_A,
    proposal: {
      analysis: 'B is really true/false',
      rule: { condition: { sectionRowId: 'B', stemRegex: 'UNIQUE-MARKER-STRING' }, action: { setType: 'true_false' }, rationale: 'printed T/F grid' },
      expectedParse: expectedFromDoc(fixtureDocA(), (sec) => (sec.rowId === 'B' ? { t: 'true_false' } : {})),
    },
    parseFn: stubParse,
    corpus: corpusOf(20),
  });
  assert(r.ok && r.status === 'live' && r.rule, `expected live, got ${r.status}: ${r.error}`);
  assert(r.rule.stats?.targetFixed === true, 'stats missing');
  assert(r.shadow?.regressions.length === 0, 'shadow must be clean');
});

check('gate 5b: target green but NO corpus coverage -> stays in shadow, never live', () => {
  const r = runMiningPipeline({
    rawText: RAW_A,
    proposal: {
      rule: { condition: { sectionRowId: 'B', stemRegex: 'UNIQUE-MARKER-STRING' }, action: { setType: 'true_false' } },
      expectedParse: expectedFromDoc(fixtureDocA(), (sec) => (sec.rowId === 'B' ? { t: 'true_false' } : {})),
    },
    parseFn: stubParse,
    corpus: corpusOf(3),
  });
  assert(r.ok && r.status === 'shadow', `expected shadow, got ${r.status}`);
  assert(r.warnings.some((w) => w.includes('coverage')), 'missing coverage warning');
});

check('status transitions: human gate allows live->retired, forbids retired->live', () => {
  const rule = validRule();
  const t1 = transitionRule([{ ...rule, status: 'live' }], rule.id, 'retired');
  assert(t1.ok && t1.rules[0].status === 'retired', 'live->retired failed');
  const t2 = transitionRule([{ ...rule, status: 'retired' }], rule.id, 'live');
  assert(!t2.ok, 'resurrecting a retired rule must be illegal');
  const t3 = transitionRule([{ ...rule, status: 'proposed' }], rule.id, 'live');
  assert(!t3.ok, 'proposed->live must go through shadow');
});

check('mergeMinedRules dedupes by content id and keeps the human decision', () => {
  const rule = validRule();
  const first = mergeMinedRules([], { ...rule, status: 'live' });
  assert(first.rules.length === 1 && !first.deduped, 'first merge should insert');
  const again = mergeMinedRules(first.rules, { ...rule, status: 'shadow', reports: [{ ranAt: 't2', corpusFiles: 1, regressions: [], targetPassed: true, targetIssues: [] }] });
  assert(again.rules.length === 1 && again.deduped, 'dedupe failed');
  assert(again.rules[0].status === 'live', 'dedupe must keep the human decision (live)');
  assert(again.rules[0].reports?.length === 1, 'reports not merged');
});

console.log('\n== B5. parsePipeline integration (preParsed + rules + hints) ==');

check('pipeline applies live mined rules and template hints end-to-end', () => {
  const doc = fixtureDocA();
  const hinted = applyTemplateHints(doc, [
    { id: 'tpl-h', suggestsType: 'multiple_choice', constraints: { hasOptions: true }, countRange: [1, 99], weight: 0.9, provenance: { minedFrom: [], minedAt: 't', version: 1 } },
  ]);
  const rule: MinedRule = { ...validRule(), status: 'live', condition: { sectionRowId: 'B' }, action: { setType: 'true_false' } };
  const res = runParsePipeline({ rawText: RAW_A, filename: 'test.docx', preParsed: hinted, minedRules: [rule] });
  assert(res.ok, `pipeline failed: ${res.ok ? '' : res.error}`);
  assert(res.ok && res.doc.sections[1].questions.every((q) => q.type === 'true_false'), 'rule not applied in pipeline');
  assert(res.ok && res.doc.sections[0].templateHints !== undefined, 'template hints not attached in pipeline');
  const resClean = runParsePipeline({ rawText: RAW_A, filename: 'test.docx', preParsed: hinted });
  assert(resClean.ok && resClean.doc.sections[1].questions.every((q) => q.type === 'short_answer'), 'no-rule path must be identity');
});

check('configureMinedRules filters non-live rules module-wide', () => {
  const rule = validRule();
  configureMinedRules([{ ...rule, status: 'live' }, { ...rule, id: 'mr-x', status: 'retired' }]);
  assert(getActiveMinedRules().length === 1, 'non-live rule in active set');
  configureMinedRules([]);
  assert(getActiveMinedRules().length === 0, 'reset failed');
});

// ---------------------------------------------------------------------------
// C. Freshness of the committed mined templates + real-corpus identity
// ---------------------------------------------------------------------------

console.log('\n== C. Committed-template freshness ==');

const GT_DIRS = [
  path.join(WS_ROOT, 'scratch/parsed'),
  path.join(WS_ROOT, 'scratch/parsed-mocks'),
];
const haveCorpus = GT_DIRS.every((d) => fs.existsSync(d));

check(haveCorpus ? 'committed MINED_TEMPLATES match a fresh corpus mine' : 'SKIPPED (no corpus dirs) — committed templates not checked', () => {
  if (!haveCorpus) return; // portable gate: warn-only when corpus is absent
  const inputs: MinedSectionInput[] = [];
  for (const dir of GT_DIRS) {
    for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.json')).sort()) {
      const doc = JSON.parse(fs.readFileSync(`${dir}/${f}`, 'utf8'));
      for (const sec of doc.sections || []) inputs.push({ file: doc.filename || f, section: sec });
    }
  }
  const fresh = mineTemplates(inputs);
  const committed = JSON.parse(JSON.stringify(MINED_TEMPLATES));
  const stripTime = (t: SectionTemplate) => JSON.stringify({ ...t, provenance: { ...t.provenance, minedAt: '' } });
  assert(fresh.length === committed.length, `template count drift: fresh ${fresh.length} vs committed ${committed.length}`);
  for (let i = 0; i < fresh.length; i++) {
    assert(stripTime(fresh[i]) === stripTime(committed[i]), `template ${i} drifted — regenerate with scripts/mineTemplates.mts`);
  }
});

check('shared grading core agrees with the gate on a clean parse (identity with no rules)', () => {
  const gtDir = path.join(WS_ROOT, 'scratch/gt');
  if (!fs.existsSync(gtDir)) return;
  const f = fs.readdirSync(gtDir).find((x) => x.endsWith('.json'))!;
  const gt = JSON.parse(fs.readFileSync(`${gtDir}/${f}`, 'utf8')) as GoldenGT;
  const textDir = path.join(WS_ROOT, 'scratch/texts');
  if (!fs.existsSync(`${textDir}/${gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_')}.txt`)) return;
  const doc = parseExamRawText(fs.readFileSync(`${textDir}/${gt.file.replace(/[^\p{L}\p{N}.\-]+/gu, '_')}.txt`, 'utf8'), gt.file, { detectAnomalies: true, normalizeNumbering: true, linkClozePassages: true });
  const res = gradeParse(doc, gt);
  assert(res.issues.length === 0, `goldenGrade core diverged from the gate: ${res.issues.slice(0, 3).join('; ')}`);
});

// ---------------------------------------------------------------------------

console.log(`\nMining + templates: ${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
