/**
 * verifySurfaceFilter.ts — M1 permanent regression gate (decision D4).
 * Wired into `npm run verify`; any regression fails the gate with exit 1.
 *
 * Proves:
 *   1. filterHeader strips teacherName/schoolName/district/examDate while
 *      keeping grade, courseName, durationMinutes, term — and never mutates
 *      the stored document (extraction untouched).
 *   2. Denylist scrubbing: Persian/English label lines lose their VALUE,
 *      checksum-VALID 10-digit national IDs are masked (barcodes/form numbers
 *      survive), Iranian mobile + landline numbers are masked in Latin and
 *      Persian digits, labeled phone lines keep the label and lose the value.
 *   3. surfaceDocument is a cheap shallow copy (sections shared by ref).
 *   4. Settings store defaults to filtered and round-trips the toggle.
 *   5. Exporter output (clean JSON) carries no personal fields by default;
 *      the power-user toggle restores them (single choke point).
 *   6. Serializer round-trip text omits the school line by default.
 *   7. Jev verification sheet state ships NO school/date (the judge does
 *      not need the paper's identity — h:header checks course+grade only).
 *   8. Training-log rows never carry school identity by default.
 */

import {
  DEFAULT_SURFACE_FILTER_SETTINGS,
  filterHeader,
  getSurfaceFilterSettings,
  isValidIranianNationalId,
  scrubPiiText,
  setSurfaceFilterSettings,
  surfaceDocument,
  SURFACE_PII_HEADER_FIELDS,
} from '../repo-parser/src/utils/surfaceFilter';
import { serializeExamToText } from '../repo-parser/src/utils/examSerializer';
import { buildVerificationSheet } from '../repo-parser/src/utils/parseVerifier';
import { exportToCleanJson } from '../repo-parser/src/utils/exporter';
import { buildTrainingLine } from '../repo-parser/src/utils/trainingLog';
import { ExamDocument, ExamHeader, ExamSection, QuestionItem } from '../repo-parser/src/types/exam';

let passed = 0;
let failed = 0;
const failures: string[] = [];

function ok(label: string, cond: boolean): void {
  if (cond) {
    passed++;
  } else {
    failed++;
    failures.push(label);
    console.error(`  FAIL ${label}`);
  }
}

// ---------- fixture ----------
const fullHeader: ExamHeader = {
  courseName: 'زبان انگلیسی',
  teacherName: 'خانم رضایی',
  durationMinutes: 60,
  examDate: '03/10/17',
  schoolName: 'دبیرستان تست',
  district: 'منطقه دو بوشهر',
  gradeAndMajor: 'دوازدهم',
  pageCount: 1,
  grade: 'Grade 12',
  term: 'نوبت اول',
};

const q: QuestionItem = {
  id: 'q-a-1',
  number: 1,
  displayNumber: '1',
  sectionRowId: 'A',
  sectionName: 'Vocabulary',
  type: 'multiple_choice',
  stem: 'She --- to school every day.',
  options: [
    { id: 'a', text: 'go' },
    { id: 'b', text: 'goes' },
  ],
  correctAnswer: 'b',
  mark: 1,
  answerMeta: { method: 'human' },
};

const sec: ExamSection = {
  rowId: 'A',
  majorCategory: 'Vocabulary',
  markTotal: 1,
  questions: [q],
};

function makeDoc(): ExamDocument {
  return {
    id: 'ex-1',
    filename: 'test.pdf',
    parsedAt: '2026-09-30T00:00:00Z',
    header: { ...fullHeader },
    sections: [sec],
    totalQuestions: 1,
    totalMarks: 1,
    anomalies: [],
    confidenceScore: 95,
  };
}

// ---------- 0. reset store (node-safe: in-memory fallback) ----------
setSurfaceFilterSettings({ ...DEFAULT_SURFACE_FILTER_SETTINGS });

console.log('— M1 surface filter: header shape —');
const fh = filterHeader(fullHeader);
ok('teacherName stripped', fh.teacherName === undefined);
ok('schoolName stripped', fh.schoolName === '');
ok('district stripped', fh.district === '');
ok('examDate stripped', fh.examDate === '');
ok('courseName kept', fh.courseName === 'زبان انگلیسی');
ok('grade kept', fh.grade === 'Grade 12');
ok('durationMinutes kept', fh.durationMinutes === 60);
ok('term kept', fh.term === 'نوبت اول');
ok('gradeAndMajor kept', fh.gradeAndMajor === 'دوازدهم');
const before = JSON.stringify(fullHeader);
filterHeader(fullHeader);
ok('filterHeader never mutates the input', JSON.stringify(fullHeader) === before);
ok('PII field list is exactly the four D4 fields', SURFACE_PII_HEADER_FIELDS.join(',') === 'teacherName,schoolName,district,examDate');

console.log('— M1 surface filter: denylist scrubbing —');
ok('Persian student-name label scrubbed (label kept)',
   scrubPiiText('نام و نام خانوادگی: علی احمدی') === 'نام و نام خانوادگی: —');
ok('national-ID label scrubbed', scrubPiiText('کد ملی: 1234567890') === 'کد ملی: —');
ok('checksum-valid bare 10-digit national id masked', scrubPiiText('کد 1234567891 پایان') === 'کد — پایان');
ok('invalid-checksum 10-digit (barcode/form) NOT masked', scrubPiiText('کد 1234567890 پایان') === 'کد 1234567890 پایان');
ok('repdigit 10-digit NOT masked', scrubPiiText('0000000000') === '0000000000');
ok('Persian-digit valid national id masked', scrubPiiText('کد ۱۲۳۴۵۶۷۸۹۱ پایان') === 'کد — پایان');
ok('labeled mobile line keeps label, loses value', scrubPiiText('تماس 09121234567') === 'تماس: —');
ok('mobile grouped form masked', scrubPiiText('0912 123 4567') === '—');
ok('labeled landline line keeps label, loses value', scrubPiiText('تلفن 021 1234 5678') === 'تلفن: —');
ok('Persian-digit mobile masked', scrubPiiText('۰۹۱۲۱۲۳۴۵۶۷') === '—');
ok('labeled phone line keeps label, loses value', scrubPiiText('تلفن: 02112345678') === 'تلفن: —');
ok('legitimate small numbers untouched', scrubPiiText('سوال 10 از 40 - نمره 19.5') === 'سوال 10 از 40 - نمره 19.5');
ok('NID checksum unit: valid id accepted', isValidIranianNationalId('1234567891'));
ok('NID checksum unit: off-by-one check digit rejected', !isValidIranianNationalId('1234567890'));
ok('NID checksum unit: repdigits rejected', !isValidIranianNationalId('1111111111'));
ok('plain course name untouched', scrubPiiText('زبان انگلیسی نهم') === 'زبان انگلیسی نهم');
ok('English label scrubbed', /^Student Name: —$/.test(scrubPiiText('Student Name: Ali Ahmadi')));
ok('teacher leak inside courseName scrubbed by filterHeader',
   filterHeader({ ...fullHeader, courseName: 'زبان انگلیسی - نام دبیر: احمدی' }).courseName === 'زبان انگلیسی - نام دبیر: —');

console.log('— M1 surface filter: surfaceDocument —');
const doc = makeDoc();
const surf = surfaceDocument(doc);
ok('surface doc header filtered', surf.header.schoolName === '' && surf.header.examDate === '');
ok('sections shared by reference (cheap shallow copy)', surf.sections === doc.sections);
ok('original doc untouched', doc.header.schoolName === 'دبیرستان تست');

console.log('— M1 surface filter: settings store —');
ok('defaults to filtered', getSurfaceFilterSettings().showFullHeaderFields === false);

console.log('— M1 surface filter: exporter —');
const cleanDefault = exportToCleanJson(makeDoc());
ok('clean JSON export has no school by default', !cleanDefault.includes('دبیرستان تست'));
ok('clean JSON export has no district by default', !cleanDefault.includes('منطقه دو'));
ok('clean JSON export has no exam date by default', !cleanDefault.includes('03/10/17'));
ok('clean JSON export keeps course', cleanDefault.includes('زبان انگلیسی'));
ok('clean JSON export keeps grade', cleanDefault.includes('Grade 12'));
setSurfaceFilterSettings({ showFullHeaderFields: true });
const cleanFull = exportToCleanJson(makeDoc());
ok('power-user toggle restores school in exports', cleanFull.includes('دبیرستان تست'));
setSurfaceFilterSettings({ ...DEFAULT_SURFACE_FILTER_SETTINGS });
const cleanReset = exportToCleanJson(makeDoc());
ok('toggle off again → exports filtered again', !cleanReset.includes('دبیرستان تست'));

console.log('— M1 surface filter: serializer round-trip text —');
const serDefault = serializeExamToText(makeDoc());
ok('school line omitted by default', !serDefault.includes('نام مدرسه:'));
ok('course line kept', serDefault.includes('نام درس: زبان انگلیسی'));
setSurfaceFilterSettings({ showFullHeaderFields: true });
const serFull = serializeExamToText(makeDoc());
ok('power-user toggle restores school line', serFull.includes('نام مدرسه: دبیرستان تست'));
setSurfaceFilterSettings({ ...DEFAULT_SURFACE_FILTER_SETTINGS });

console.log('— M1 surface filter: Jev verification sheet state —');
const build = buildVerificationSheet(makeDoc());
ok('judge state header has no schoolName by default', (build.header as Record<string, unknown>).schoolName === undefined);
ok('judge state header has no examDate by default', (build.header as Record<string, unknown>).examDate === undefined);
ok('judge state header keeps courseName', (build.header as Record<string, unknown>).courseName === 'زبان انگلیسی');
ok('judge state header keeps grade/term/duration',
   !!(build.header as Record<string, unknown>).grade && !!(build.header as Record<string, unknown>).durationMinutes);
setSurfaceFilterSettings({ showFullHeaderFields: true });
const buildFull = buildVerificationSheet(makeDoc());
ok('power-user toggle can restore judge-state school (explicit opt-in)',
   (buildFull.header as Record<string, unknown>).schoolName === 'دبیرستان تست');
setSurfaceFilterSettings({ ...DEFAULT_SURFACE_FILTER_SETTINGS });

console.log('— M1 surface filter: training log —');
const line = buildTrainingLine(makeDoc(), sec, q, 'human', {});
const meta = (line as { meta?: Record<string, unknown> }).meta || {};
ok('training meta has no schoolName by default', meta.schoolName === undefined);
ok('training meta keeps grade', !!meta.grade);
setSurfaceFilterSettings({ showFullHeaderFields: true });
const lineFull = buildTrainingLine(makeDoc(), sec, q, 'human', {});
const metaFull = (lineFull as { meta?: Record<string, unknown> }).meta || {};
ok('power-user toggle restores training school field', metaFull.schoolName === 'دبیرستان تست');
setSurfaceFilterSettings({ ...DEFAULT_SURFACE_FILTER_SETTINGS });

console.log(`\nverifySurfaceFilter: ${passed} passed, ${failed} failed`);
if (failed > 0) {
  console.error('FAILURES:');
  failures.forEach((f) => console.error('  - ' + f));
  process.exit(1);
}
console.log('ALL SURFACE-FILTER CHECKS GREEN');
