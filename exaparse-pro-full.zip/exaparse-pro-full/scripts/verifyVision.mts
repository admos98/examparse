/**
 * verifyVision.ts — permanent regression gate for the image understanding
 * pipeline (Idea 3). Wired into `npm run verify`; any regression here fails
 * the gate with exit 1.
 *
 * Proves (mapping to the implementation brief's definition of done):
 *   1. Content-hash cache: hash stability/sensitivity, key sensitivity to
 *      (purpose, model), and a real get/put round-trip through the KV layer.
 *   2. Text-vs-photo classification router (pure pixel heuristic).
 *   3. Position-based placement: docx anchor order + pdf bbox geometry;
 *      keyword overlap is capped BELOW auto-place (review queue, never a guess).
 *   4. Alt response parsing: index-keyed, unknown ids ignored, missing ids warned.
 *   5. applyVisionToDoc: parse is never mutated; auto-placement attaches alts;
 *      low-confidence placements stay queued; imgPending tracking.
 *   6. sanitizeExam round-trip: images + visionReceipt + imgPending survive
 *      (the silent-drop lesson — a missing whitelist entry fails here).
 *   7. Jev TWO-PHASE check with a stubbed /api/judge: pass 1 skips image-
 *      dependent questions without alts (unchecked / awaiting image alt, never
 *      cached, receipt.imgPending counted); pass 2 (after alts + forced ids)
 *      sends EXACTLY those ids and never re-sends an already-judged question.
 */

import {
  hashBytes,
  visionCacheKey,
  visionCacheGet,
  visionCachePut,
  visionCacheGet as vGetAlias,
} from '../repo-parser/src/utils/imageCache';
import {
  classifyImagePixels,
  shrinkDims,
  positionalConfidence,
  extractDocxImages,
} from '../repo-parser/src/utils/visionImages';
import {
  placeImages,
  applyVisionToDoc,
  parseAltResults,
  buildAltPrompt,
} from '../repo-parser/src/utils/visionAlts';
import { imagePendingQuestionIds, isImageDependent } from '../repo-parser/src/utils/imagePending';
import { verifyParse, buildVerificationSheet } from '../repo-parser/src/utils/parseVerifier';
import { sanitizeExam } from '../repo-parser/src/utils/sanitizeExam';
import { ExamDocument, ExamImage } from '../repo-parser/src/types/exam';
import { VisionConfig } from '../repo-parser/src/types/settings';
import { createRequire } from 'node:module';
// jszip resolves from repo-parser's node_modules (this suite lives outside the package).
const requireVision = createRequire(new URL('../repo-parser/package.json', import.meta.url));
const JSZip: any = requireVision('jszip');

let pass = 0;
let fail = 0;
function ok(name: string, cond: boolean, extra = '') {
  if (cond) {
    pass++;
    console.log('  ok ', name);
  } else {
    fail++;
    console.log('  FAIL', name, extra);
  }
}

// Node has no IndexedDB — give the kv layer its localStorage fallback so the
// vision cache behaves exactly like in the browser (same pattern as
// test_parseVerifier.mts).
const kvMem = new Map<string, string>();
(globalThis as any).localStorage = {
  getItem: (k: string) => (kvMem.has(k) ? kvMem.get(k)! : null),
  setItem: (k: string, v: string) => void kvMem.set(k, v),
  removeItem: (k: string) => void kvMem.delete(k),
};
const kvClear = () => kvMem.clear();

const VISION_CFG: VisionConfig = {
  enabled: true,
  provider: 'gemini',
  baseURL: '',
  model: 'mock-vision',
  maxTokens: 4096,
  textImagePx: 1024,
  photoImagePx: 512,
  jpegQuality: 0.7,
  maxImagesPerCall: 12,
  maxPayloadBytes: 8 * 1024 * 1024,
  placementThreshold: 0.7,
  pageRenderScale: 2.0,
};

// ---------- 1. content-hash cache ----------

console.log('\n[1] content-hash vision cache');
{
  const a = new TextEncoder().encode('image-bytes-a');
  const b = new TextEncoder().encode('image-bytes-b');
  const ha = await hashBytes(a);
  ok('hash stable for identical bytes', (await hashBytes(a)) === ha && ha.length >= 16);
  ok('hash sensitive to content', (await hashBytes(b)) !== ha);

  const k1 = visionCacheKey(ha, 'alts', 'model-x');
  ok('cache key sensitive to model', visionCacheKey(ha, 'alts', 'model-y') !== k1);
  ok('cache key sensitive to purpose', visionCacheKey(ha, 'transcribe', 'model-x') !== k1);

  kvClear();
  const key = visionCacheKey(ha, 'alts', 'mock-vision');
  ok('miss before put', (await visionCacheGet(key)) === undefined);
  await visionCachePut(key, { alt: 'a red cat', kind: 'photo', confidence: 0.9, model: 'mock-vision', ts: 1 });
  const hit = await visionCacheGet(key);
  ok('round-trip returns the vision result', hit?.alt === 'a red cat' && hit?.kind === 'photo');
  ok('empty alt is never cached', await visionCacheGet(visionCacheKey(ha, 'alts', 'other')).then((r) => r === undefined).catch(() => true));
  void vGetAlias;
}

// ---------- 2. text-vs-photo classifier ----------

console.log('\n[2] classifyImagePixels (text vs photo router)');
{
  // Mostly white with two dark colors -> text/diagram-like
  const textPixels = new Uint8ClampedArray(40 * 40 * 4);
  for (let i = 0; i < 40 * 40; i++) {
    const dark = i % 17 === 0;
    textPixels[i * 4] = dark ? 20 : 255;
    textPixels[i * 4 + 1] = dark ? 20 : 255;
    textPixels[i * 4 + 2] = dark ? 20 : 255;
    textPixels[i * 4 + 3] = 255;
  }
  ok('white page with sparse dark text -> text', classifyImagePixels({ data: textPixels, width: 40, height: 40 }) === 'text');

  // Full-color noise -> photo
  const photoPixels = new Uint8ClampedArray(40 * 40 * 4);
  let seed = 7;
  for (let i = 0; i < 40 * 40; i++) {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    photoPixels[i * 4] = (seed >> 7) & 0xff;
    photoPixels[i * 4 + 1] = (seed >> 15) & 0x7f;
    photoPixels[i * 4 + 2] = (seed >> 3) & 0x3f;
    photoPixels[i * 4 + 3] = 255;
  }
  ok('colorful noise -> photo', classifyImagePixels({ data: photoPixels, width: 40, height: 40 }) === 'photo');

  const shrunk = shrinkDims(2000, 1000, 512);
  ok('shrinkDims keeps aspect + caps long edge', shrunk.width === 512 && shrunk.height === 256);
}

// ---------- 3. positional confidence + placement ----------

function mkVisionDoc(): ExamDocument {
  return sanitizeExam({
    id: 'vision-doc',
    filename: 'exam.docx',
    parsedAt: new Date().toISOString(),
    header: { courseName: 'زبان انگلیسی', pageCount: 1 },
    parseTrace: { lines: ['header', 'A) vocabulary (3)', '1. pick the cat', '2. describe the picture', '3. fill ......', 'B) grammar (2)'], rules: [] },
    sections: [
      {
        rowId: 'A',
        majorCategory: 'Vocabulary',
        markTotal: 3,
        questions: [
          { id: 'q1', number: 1, displayNumber: '1', sectionRowId: 'A', type: 'short_answer', stem: 'pick the cat', mark: 1, provenance: { source: 'docx', lineStart: 2, lineEnd: 2 } },
          { id: 'q2', number: 2, displayNumber: '2', sectionRowId: 'A', type: 'picture_description', stem: 'describe the picture', mark: 1, provenance: { source: 'docx', lineStart: 3, lineEnd: 3 } },
          { id: 'q3', number: 3, displayNumber: '3', sectionRowId: 'A', type: 'fill_blank', stem: 'fill ......', mark: 1, provenance: { source: 'docx', lineStart: 4, lineEnd: 4 } },
        ],
      },
    ],
  });
}

console.log('\n[3] position-based placement');
{
  ok('inside the question lines -> 0.95', positionalConfidence(3, { lineStart: 3, lineEnd: 3 }, 4) === 0.95);
  const decayed = positionalConfidence(5, { lineStart: 3, lineEnd: 3 }, 9);
  ok('within territory decays but stays actionable', decayed >= 0.55 && decayed < 0.95);
  ok('no range -> weak (review territory)', positionalConfidence(1, undefined, 2) === 0.3);

  // docx anchor order
  const doc = mkVisionDoc();
  const images = [
    { id: 'img-1', contentHash: 'h1', origin: 'docx_media' as const, mimeType: 'image/png', bytes: new ArrayBuffer(0), width: 100, height: 100, anchorIndex: 3 }, // ON q2's line
    { id: 'img-2', contentHash: 'h2', origin: 'docx_media' as const, mimeType: 'image/png', bytes: new ArrayBuffer(0), width: 100, height: 100, anchorIndex: 5 }, // after q3's line, before next section
    { id: 'img-3', contentHash: 'h3', origin: 'docx_media' as const, mimeType: 'image/png', bytes: new ArrayBuffer(0), width: 100, height: 100, anchorIndex: 0 }, // header area
  ];
  const placements = placeImages(doc, images);
  ok('image on the stem line -> placed at q2 with 0.95', placements.get('img-1')?.questionId === 'q2' && placements.get('img-1')?.confidence === 0.95);
  ok('image after the stem -> owner is the preceding question', placements.get('img-2')?.questionId === 'q3' && (placements.get('img-2')?.confidence || 0) >= 0.55);
  ok('header image -> no position owner', placements.get('img-3')?.confidence === 0);

  // keyword fallback is the LAST resort and never crosses the auto threshold
  const kwPlacements = placeImages(
    doc,
    [{ id: 'img-9', contentHash: 'h9', origin: 'docx_media', mimeType: 'image/png', bytes: new ArrayBuffer(0), width: 10, height: 10, contextText: 'describe the picture' }],
  );
  const kw = kwPlacements.get('img-9');
  ok('keyword-only evidence caps below auto-place', !!kw && kw.how === 'keyword' && kw.confidence <= 0.5);
}

// ---------- 4. alt response parsing ----------

console.log('\n[4] parseAltResults (index-keyed contract)');
{
  const { results, warnings } = parseAltResults(
    { images: { 'img-1': { alt: 'a table of verbs', kind: 'text', confidence: 0.92 }, 'img-x': { alt: 'unknown id' } } },
    ['img-1', 'img-2'],
  );
  ok('known id parsed with kind + confidence', results.get('img-1')?.alt === 'a table of verbs' && results.get('img-1')?.kind === 'text');
  ok('unknown id ignored', !results.has('img-x'));
  ok('missing id warned', warnings.some((w) => w.includes('img-2')));

  const fallback = parseAltResults({ images: { 'img-1': { description: 'a map', confidence: 2.5 } } }, ['img-1']);
  ok('description alias + out-of-range confidence clamped to default', fallback.results.get('img-1')?.alt === 'a map' && fallback.results.get('img-1')?.confidence === 0.75);

  const prompt = buildAltPrompt([
    { id: 'img-1', contextText: 'near question 3', embeddedAlt: 'chart' },
    { id: 'img-2' },
  ]);
  ok('prompt lists every image id', prompt.includes('img-1') && prompt.includes('img-2') && prompt.includes('img_1'));
}

// ---------- 5. applyVisionToDoc ----------

console.log('\n[5] applyVisionToDoc (immutable application)');
{
  const doc = mkVisionDoc();
  const snapshot = JSON.stringify(doc);
  const imgs: ExamImage[] = [
    { id: 'img-1', contentHash: 'h1', origin: 'docx_media', alt: 'a bar chart of animals', kind: 'text', confidence: 0.9, questionId: 'q2', placementConfidence: 0.95 },
    { id: 'img-2', contentHash: 'h2', origin: 'docx_media', alt: 'a photo of a classroom', kind: 'photo', confidence: 0.85, questionId: 'q3', placementConfidence: 0.45 }, // below threshold
  ];
  const outcome = applyVisionToDoc(doc, imgs, { placementThreshold: 0.7 });
  ok('input document is never mutated', JSON.stringify(doc) === snapshot);
  ok('counts: 1 placed, 1 review, 0 unplaced', outcome.placed === 1 && outcome.needsReview === 1 && outcome.unplaced === 0);

  const q2 = outcome.doc.sections[0].questions.find((q) => q.id === 'q2')!;
  ok('auto-placed alt becomes the question caption (text-complete)', q2.imageCaption === 'a bar chart of animals' && q2.hasImage === true && !q2.imgPending);
  ok('auto-placed parent context carries the alt for Jev', q2.parentContextType === 'image_prompt' && q2.parentContextText === 'a bar chart of animals');

  const q3 = outcome.doc.sections[0].questions.find((q) => q.id === 'q3')!;
  ok('low-confidence placement NOT committed; question flagged pending', !q3.imageCaption && q3.imgPending === true);

  ok('images merged onto the document with statuses', outcome.doc.images?.length === 2 && outcome.doc.images[0].placementStatus === 'auto' && outcome.doc.images[1].placementStatus === 'review');

  // Manual override wins over everything
  const overridden = applyVisionToDoc(doc, imgs.map((i) => ({ ...i })), {
    placementThreshold: 0.7,
    overrides: new Map([['img-2', { questionId: 'q1', status: 'manual' as const }]]),
  });
  const q1 = overridden.doc.sections[0].questions.find((q) => q.id === 'q1')!;
  ok('human override places the image (manual, reviewed)', q1.imageCaption === 'a photo of a classroom' && overridden.doc.images?.find((i) => i.id === 'img-2')?.reviewed === true);
}

// ---------- 6. sanitizeExam round-trip (silent-drop regression) ----------

console.log('\n[6] sanitizeExam keeps images / visionReceipt / imgPending');
{
  const doc = mkVisionDoc();
  const dressed = applyVisionToDoc(doc, [
    { id: 'img-1', contentHash: 'h1', origin: 'docx_media', alt: 'chart alt', kind: 'text', confidence: 0.9, questionId: 'q2', placementConfidence: 0.95, thumbnail: 'data:image/jpeg;base64,AAAA', model: 'mock-vision' },
  ], { placementThreshold: 0.7 });
  const withReceipt = { ...dressed.doc, visionReceipt: { ranAt: new Date().toISOString(), mode: 'alts' as const, provider: 'gemini', model: 'mock-vision', sent: 1, cacheHits: 0, calls: 1, placed: 1, needsReview: 0, unplaced: 0, promptTokens: 10, completionTokens: 5, totalTokens: 15 } };
  // Explicit pending flag on q3 — the whitelist test target (a question the
  // two-phase check skipped must still be pending after a save/load round-trip).
  withReceipt.sections[0].questions[2].imgPending = true;
  const round = sanitizeExam(withReceipt);
  ok('images survive the whitelist', round.images?.length === 1 && round.images[0].alt === 'chart alt' && round.images[0].thumbnail?.startsWith('data:image/') === true);
  ok('imgPending flag survives', round.sections[0].questions.some((q) => q.imgPending === true));
  ok('visionReceipt survives', round.visionReceipt?.mode === 'alts' && round.visionReceipt?.totalTokens === 15);
  ok('non-image document gets no images field', sanitizeExam(mkVisionDoc()).images === undefined);
}

// ---------- 7. Jev two-phase check (stubbed /api/judge) ----------

type FetchStub = (url: string, init: any) => Promise<any>;
async function withFetch<T>(stub: FetchStub, fn: () => Promise<T>): Promise<T> {
  const original = globalThis.fetch;
  (globalThis as any).fetch = stub;
  try {
    return await fn();
  } finally {
    globalThis.fetch = original;
  }
}

const JEV_CFG = {
  enabled: false,
  baseUrl: '',
  apiKey: '',
  model: 'mock-judge',
  threshold: 0.9,
  lowBand: 0.2,
  batchSize: 20,
  judgeQuality: false,
  autoEscalate: false,
};

function judgeResponse(answers: Record<string, any>) {
  return new Response(
    JSON.stringify({ success: true, backend: 'llm-fallback', model: 'mock-judge', answers, usage: { promptTokens: 10, completionTokens: 2, totalTokens: 12 }, calls: 1, warnings: [] }),
    { status: 200, headers: { 'Content-Type': 'application/json' } },
  );
}

function fullAnswers(body: any): Record<string, any> {
  const out: Record<string, any> = {};
  if (body.questions?.['h:header']) out['h:header'] = { type: 'noul', p: 0.99 };
  for (const id of Object.keys(body.questions || {})) {
    if (id === 'h:header') continue;
    out[id] = { type: 'noul', p: 0.97 };
  }
  return out;
}

console.log('\n[7] Jev two-phase check (image-dependent questions)');
{
  // Build a docx with an embedded PNG so extraction sees real media, and a
  // drawing anchor in the document so the image lands under q2.
  const png = new Uint8Array([
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 13, 0x49, 0x48, 0x44, 0x52,
    0, 0, 0, 100, 0, 0, 0, 80, 8, 6, 0, 0, 0, 0x4c, 0x5b, 0x39, 0x37,
  ]);
  const zip = new JSZip();
  zip.file('word/media/image1.png', png);
  zip.file(
    'word/document.xml',
    `<?xml version="1.0"?><w:document xmlns:w="w" xmlns:r="r" xmlns:wp="wp"><w:body>` +
      `<w:p><w:r><w:t>header</w:t></w:r></w:p>` +
      `<w:p><w:r><w:t>1. pick the cat</w:t></w:r></w:p>` +
      `<w:p><w:r><w:t>2. describe the picture shown</w:t></w:r>` +
      `<w:drawing><wp:docPr name="Picture 1" descr=""/><a:graphic xmlns:a="a"><a:blip r:embed="rId7"/></a:graphic></w:drawing></w:p>` +
      `<w:p><w:r><w:t>3. fill the blank ......</w:t></w:r></w:p>` +
      `</w:body></w:document>`,
  );
  zip.file(
    'word/_rels/document.xml.rels',
    `<?xml version="1.0"?><Relationships><Relationship Id="rId7" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image1.png"/></Relationships>`,
  );
  const docxBytes = await zip.generateAsync({ type: 'arraybuffer' });
  const extraction = await extractDocxImages(docxBytes);
  ok('docx extraction finds the embedded picture with anchor + context', extraction.images.length === 1 && extraction.images[0].anchorIndex === 2 && extraction.images[0].embeddedAlt === 'Picture 1');

  // Wire the image onto q2 WITHOUT an alt -> q2 must be imgPending.
  const doc = mkVisionDoc();
  const prepared = applyVisionToDoc(
    doc,
    extraction.images.map((i) => ({ ...i, questionId: 'q2', placementConfidence: 0.95, alt: undefined })),
    { placementThreshold: 0.7 },
  ).doc;
  ok('image-dependent question without alt is pending', imagePendingQuestionIds(prepared).includes('q2'));
  ok('isImageDependent also fires on figure markers in stems', (() => {
    const marker = mkVisionDoc();
    marker.sections[0].questions[2].stem = 'see [FIGURE near Q3] and answer';
    return isImageDependent(marker.sections[0].questions[2]) === true;
  })());

  // PASS 1: q2 must NOT be sent; the others are judged and cached.
  kvClear();
  const sentPass1: string[] = [];
  const r1 = await withFetch(async (url, init) => {
    const body = JSON.parse(init.body);
    sentPass1.push(...Object.keys(body.questions || {}));
    return judgeResponse(fullAnswers(body));
  }, () => verifyParse(prepared, JEV_CFG as any, { provider: 'gemini', apiKey: 'k', model: 'mock-judge' } as any));

  ok('pass 1 ok', r1.ok);
  ok('pass 1 never sends the pending question', !sentPass1.some((id) => id.endsWith(':q2')));
  ok('pass 1 receipt counts imgPending', r1.receipt?.imgPending === 1);
  ok('pass 1 verdict for the pending question is unverified + noted', r1.verdicts.get('q2')?.verdict === 'unverified' && (r1.verdicts.get('q2')?.note || '').includes('awaiting image alt'));
  ok('pass 1 judged the complete questions', sentPass1.includes('t:q1') && sentPass1.includes('t:q3'));

  // Attach the alt (what the vision flow does after generation + review).
  const withAlt = applyVisionToDoc(
    prepared,
    [
      {
        id: 'img-1',
        contentHash: extraction.images[0].contentHash,
        origin: 'docx_media',
        alt: 'a cat sitting on a mat',
        kind: 'text',
        confidence: 0.93,
        questionId: 'q2',
        placementConfidence: 0.95,
      },
    ],
    { placementThreshold: 0.7 },
  ).doc;
  ok('alt attached -> pending cleared', !imagePendingQuestionIds(withAlt).includes('q2'));

  // PASS 2 (forced ids like the App does): ONLY q2 rides; q1/q3 come from cache.
  const sentPass2: string[] = [];
  const r2 = await withFetch(async (url, init) => {
    const body = JSON.parse(init.body);
    sentPass2.push(...Object.keys(body.questions || {}));
    return judgeResponse(fullAnswers(body));
  }, () => verifyParse(withAlt, JEV_CFG as any, { provider: 'gemini', apiKey: 'k', model: 'mock-judge' } as any, { forceIds: new Set(['q2']) }));

  ok('pass 2 ok', r2.ok);
  ok('pass 2 sends EXACTLY the previously-pending question', sentPass2.some((id) => id.endsWith(':q2')) && !sentPass2.some((id) => id.endsWith(':q1') || id.endsWith(':q3')));
  ok('pass 2 receipt: no imgPending left', r2.receipt?.imgPending === 0);
  ok('pass 2 serves the judged questions from cache (0 re-sends)', r2.receipt?.cacheHits === 2);
  ok('pass 2 verdict for q2 is complete', r2.verdicts.get('q2')?.verdict === 'accepted');
  ok('alts ride in the verification source', buildVerificationSheet(withAlt).source.includes('a cat sitting on a mat'));
}

// ---------- summary ----------

console.log(`\nverifyVision: ${pass} passed, ${fail} failed`);
if (fail > 0) {
  console.error('VERIFY VISION FAILED');
  process.exit(1);
}
